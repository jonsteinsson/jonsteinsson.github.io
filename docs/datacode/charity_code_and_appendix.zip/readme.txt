To reproduce the figures in DellaVigna List Malmendier 2012, use the code in the two folders included here. First, see the readme in the "reduced form" code folder. Use the moments generated in this process as inputs to the estimation code in the "structural estimation" folder. See the readme in that folder for more information.

The three sets of moments needed to reproduce the structural estimations are also included in the structural estimation folder so that it is not necessary to run the reduced form code first.

Moments70.mat created from moments010-10 and VarCov010-10.
Moments64.mat created from moments010 and VarCov010.
Moments76.mat created from moments03-37-710 and VarCov03-37-710.

As originally published, the estimates in Online Appendix Tables 3 and 4 relied on an outdated version of the empirical moments. The Online Appendix in this folder is updated to report estimates using the correct moments. 
