clear
set more off
set matsize 10000
set maxvar 10000

*cd your_folder_name_here

capture mkdir output
capture mkdir output/QJE
log using output/QJE/charityMainQJE.log, replace

*****************************************************************************
** "Testing for Altruism and Social Pressure in Charitable Giving"
** by Stefano DellaVigna, John A. List, and Ulrike Malmendier
** Quarterly Journal of Economics
**
** This do file loads the data from the fund-raising field experiment and the
** survey field experiments analyzed in the paper
** It generates the reduced-form results, as well as the moments used in the
** structural estimation
*****************************************************************************


*****************************************
*** STEP 1. Analysis of Response to 2008 Survey ***
**  	for Experimental Design Section ***

use regs/SurveyContent2008Short,clear

** Summary stats on rank of charities
su rank_*
** Summary stats on pledge for favored charity
ta pledge,m

** Summary stats on amount given by charity type
foreach x in dtd phone mail personal {
	gen `x'_pos=`x'_total>0 if `x'_total~=.
	gen `x'_wins=`x'_total
	replace `x'_wins=1000 if `x'_wins>1000 & `x'_wins~=.
	}
gen samplenomiss= (dtd_pos~=. & phone_pos~=. & mail_pos~=. & personal_pos~=.)
** Fund-raisers contacted you in the past 12 months at least X times
* Door-to-door
ta dtd_freq if samplenomiss==1
* Phone
ta phone_freq if samplenomiss==1
* Mail
ta mail_freq if samplenomiss==1
* Personal/other ways
ta personal_freq if samplenomiss==1
** Share that gave money to such fundraisers at least once in past 12 months
su *_pos if samplenomiss==1
** Amount given (both uncapped and capped) to such fundraisers in past 12 months
su *_total *_wins if samplenomiss==1


******************************************************************
*** STEP 2. Reduced-Form Data Analysis of Experimental Results ***

** Load data with experimental observations
use regs/CharityOutputQJE,replace
memory 
su

** Code treatment with 2-week warning (2Ww) together with other Warning (flyer) treatments 
replace treatment="W" if treatment=="2Ww"

** Initial Sample
count
count if (charity=="Ecu" | charity=="LaRabida")
count if (charity=="Sv2008")
count if (charity=="Sv2009")

*** Drop two groups of observations which the solicitors did not contact
* I. Households with no solicitor sign
* II. Households where solicitor could not knock on door (big dog barking, house for sale, etc.)
* Important to eliminate these observations because these households are disproportionally
* in No-Warning treatment (since some are excluded after flyering), 
* and have no giving/no survey completion
* nosolsign==1 indicates that these households have a sign that they do not accept solicitors
count if nosol==1
ta treatment nosol,row
drop if nosol==1
drop nosol
count if toel==1
ta treatment toel,row
drop if toeliminate==1
drop toeliminate
** Drop 5 solicitor-days with serious inconsistencies
** treatment is no-flyer, but solicitors report flyer on door throughout
drop if sol=="Angelena" & (date==mdy(7,27,2008)|date==mdy(7,13,2008))
drop if sol=="Shedora" & (date==mdy(7,27,2008)|date==mdy(8,10,2008))
drop if sol=="Tehmur" & date==mdy(6,1,2008)
drop if sol=="Phillip" & date==mdy(8,9,2008)
drop if sol=="Robert" & date==mdy(7,13,2008) & (hour==11|hour==13)
count

** Final Sample
ta treatment,m
count
count if (charity=="Ecu" | charity=="LaRabida")
count if (charity=="Sv2008")
count if (charity=="Sv2009")

**** Information in Experimental Design Section
* Number of solicitors -- 92
codebook solicitor
* Number of households
ta location year

** Distinguish three waves of charity data
gen month=month(date)
gen dwave=1 if ((month==7 | month==8) & charity =="LaRabida") & year==2008
replace dwave=0 if ((month==4 | month==5 | month==6) | (charity=="Ecu" & month==7)) & year==2008
replace dwave=2 if (month==9 | month==10) & year==2008
* Randomization by wave
ta date dwave
bys dwave: ta treatment charity if charityall=="All", column
bys dwave: ta treatment charity if charityall=="All", row

** Generate fixed effects
egen sodate=concat(solicitor date)
egen treatmentby=concat(treatment charity)
egen byte grsol=group(solicitor)
egen byte grdatloc=group(date location)
egen byte grdatlocsol=group(date location solicitor)
egen byte grhour=group(hour)
egen byte grarea=group(area_rank)
drop solicitor area* hour 

char treatment[omit] "Nw"
replace amt_donate=0 if amt==.

* Save final file
save regs/CharityOutputQJEFinal,replace

cd output/QJE

foreach x in "W" "Oo" {
	gen d`x'=treatment=="`x'"
	gen d`x'Ecu=treatment=="`x'" & charity=="Ecu"
	gen d`x'Lar=treatment=="`x'" & charity=="LaRabida"
	}	
gen dEcu=charity=="Ecu"
foreach x in "0d5m" "0d10m" "5d5m" "5d10m" "10d10m" "10d5m" {
	foreach y in "Nw" "W" "Oo" {
		replace treatment="`y'`x'" if treatment=="`y'-`x'"
		}
	}
foreach x in "Nw0d10m" "W0d10m" "W0d5m" "W10d10m" {
	gen d`x'08=(treatment=="`x'" & year==2008)
	}
foreach x in "Nw0d5m" "Nw5d5m" "W0d10m" "W0d5m" "W10d5m" "W5d5m" "Oo0d5m" "Oo5d5m" {
	gen d`x'09=treatment=="`x'" & year==2009
	}
order dNw0d10m08 dW0d10m08 dW0d5m08 dW10d10m08
order dNw5d5m09 dW0d10m09 dW0d5m09 dW5d5m09 dW10d5m09 dOo0d5m09 dOo5d5m09
* drop omitted category
drop dNw0d10m08 dNw0d5m09
compress

** Generate Summary Stats Table -- Table 1
bys charity: tabstat answer, stats(mean n) by(treatment)
bys charity: tabstat saidyes, stats(mean n) by(treatment)
* Aggregate for ECU and LaRabida
tabstat answer if charityall=="All", stats(mean n) by(treatment)
tabstat saidyes if charityall=="All", stats(mean n) by(treatment)

** Charity Table: Main Table -- Table 2
* Share giving
xi: reg answer dW dOo dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dW dOo dEcu using Table2, ctitle(answer) se  bdec(4) rdec(4) sdec(4) replace
xi: reg answer dWEcu dWLar dOoEcu dOoLar dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dWEcu dOoEcu dWLar dOoLar dEcu using Table2, ctitle(answer) se  bdec(4) rdec(4) sdec(4) append
xi: reg saidyes dW dOo dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dW dOo dEcu using Table2, ctitle(give) se  bdec(4) rdec(4) sdec(4) append
xi: reg saidyes dWEcu dWLar dOoEcu dOoLar dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dWEcu dOoEcu dWLar dOoLar dEcu using Table2, ctitle(give) se  bdec(4) rdec(4) sdec(4) append
* Small and large giving
xi: reg yessmall dW dOo dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dW dOo dEcu using Table2, ctitle(givesm) se  bdec(4) rdec(4) sdec(4) append
xi: reg yessmall dWEcu dOoEcu dWLar dOoLar dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dWEcu dOoEcu dWLar dOoLar dEcu using Table2, ctitle(givesm) se  bdec(4) rdec(4) sdec(4) append
xi: reg yeslarge dW dOo dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dW dOo dEcu using Table2, ctitle(givelg) se  bdec(4) rdec(4) sdec(4) append
xi: reg yeslarge dWEcu dOoEcu dWLar dOoLar dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dWEcu dOoEcu dWLar dOoLar dEcu using Table2, ctitle(givelg) se  bdec(4) rdec(4) sdec(4) append
* Amount given
xi: reg amt dW dOo dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dW dOo dEcu using Table2, ctitle(amt) se  bdec(4) rdec(4) sdec(4) append
xi: reg amt dWEcu dWLar dOoEcu dOoLar dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dWEcu dOoEcu dWLar dOoLar dEcu using Table2, ctitle(amt) se  bdec(4) rdec(4) sdec(4) append

* Mean for LaRabida, no flyer tx
tabstat answer if charity=="LaRabida" & treatment=="Nw", stats(mean n) 
tabstat saidyes if charity=="LaRabida" & treatment=="Nw", stats(mean n) 
tabstat yessmall if charity=="LaRabida" & treatment=="Nw", stats(mean n) 
tabstat yeslarge if charity=="LaRabida" & treatment=="Nw", stats(mean n) 
tabstat amt if charity=="LaRabida" & treatment=="Nw", stats(mean n) 


** Charity Table: Robustness -- Online Appendix Table 1
* First column -- disregard
xi: reg answer dW dOo i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dW dOo using OnlineAppTable1, ctitle(PlaceHolder) se  bdec(4) rdec(4) sdec(4) replace
foreach x in answer saidyes yessmall yeslarge {
	* Benchmark spec.
	xi: reg `x' dW dOo dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
	outreg2 dW dOo dEcu using OnlineAppTable1, ctitle(`x') se  bdec(4) rdec(4) sdec(4) append
	* Spec. without dummy for ECU
	xi: reg `x' dW dOo i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
	outreg2 dW dOo using OnlineAppTable1, ctitle(`x') se  bdec(4) rdec(4) sdec(4) append
	* Spec. with fixed effects for date*location*solicitor
	xi: reg `x' dW dOo i.grdatlocsol i.grhour i.grarea if charityall=="All", robust cluster(sodate)
	outreg2 dW dOo using OnlineAppTable1, ctitle(`x') se  bdec(4) rdec(4) sdec(4) append
	}


** Charity Table: By Each of the Three Waves -- Online Appendix Table 2
* First column -- disregard
xi: reg answer dW dOo i.grsol i.grdatloc i.grhour i.grarea if charityall=="All", robust cluster(sodate)
outreg2 dW dOo using OnlineAppTable2, ctitle(PlaceHolder) se  bdec(4) rdec(4) sdec(4) replace
foreach z in "answer" "saidyes" "yessmall" "yeslarge" {
	foreach x in 0 1 2 {
		xi: reg `z' dW dOo dEcu i.grsol i.grdatloc i.grhour i.grarea if charityall=="All" & dwave==`x', robust cluster(sodate)
		outreg2 dW dOo dEcu using OnlineAppTable2, ctitle(`z',Wave`x') se  bdec(4) rdec(4) sdec(4) append
		}
	}
	
* Mean for LaRabida, no flyer tx
tabstat answer if charity=="LaRabida" & treatment=="Nw", stats(mean n) by(dwave)
tabstat saidyes if charity=="LaRabida" & treatment=="Nw", stats(mean n) by(dwave)
tabstat yessmall if charity=="LaRabida" & treatment=="Nw", stats(mean n) by(dwave)
tabstat yeslarge if charity=="LaRabida" & treatment=="Nw", stats(mean n) by(dwave)



** Survey Table -- Table 3
xi: reg answer d*08 i.grsol i.grdatloc i.grhour i.grarea if charity=="Sv2008", robust cluster(sodate)
outreg2 d*08 using Table3, ctitle(answer) se  bdec(4) rdec(4) sdec(4) replace
xi: reg saidyes d*08 i.grsol i.grdatloc i.grhour i.grarea if charity=="Sv2008", robust cluster(sodate)
outreg2 d*08 using Table3, ctitle(yes) se  bdec(4) rdec(4) sdec(4) append
xi: reg answer d*09 i.grsol i.grdatloc i.grhour i.grarea if charity=="Sv2009", robust cluster(sodate)
outreg2 d*09 using Table3, ctitle(answer) se  bdec(4) rdec(4) sdec(4) append
xi: reg saidyes d*09 i.grsol i.grdatloc i.grhour i.grarea if charity=="Sv2009", robust cluster(sodate)
outreg2 d*09 using Table3, ctitle(yes) se  bdec(4) rdec(4) sdec(4) append

* Mean for 2008 Baseline 0d10m
tabstat answer if charity=="Sv2008" & treatment=="Nw0d10m", stats(mean n) 
tabstat saidyes if charity=="Sv2008" & treatment=="Nw0d10m", stats(mean n) 

* Mean for 2010 Baseline 0d5m
tabstat answer if charity=="Sv2009" & treatment=="Nw0d5m", stats(mean n) 
tabstat saidyes if charity=="Sv2009" & treatment=="Nw0d5m", stats(mean n) 

*****************************************
*** STEP 3. Estimation of moments and variance-covariance matrix
*** For the structural estimation

cd ..
cd ..

*** Set the type of moments to be generated
foreach x in "010" "010-10" "03-37-710" "010-10p" "all" {

use regs/CharityOutputQJEFinal,clear
gen mom="`x'"

* Brief Data cleaning
replace charity="Lar" if charity=="La Rabida"|charity=="LaRabida"
gen optout = dnd
ta treatment,m
foreach x in "0" 5 10 {
	foreach y in 5 10 {
		foreach z in "Nw" "We" "Ooe" "W" "Oo" {
			replace treatment="`z'`x'd`y'm" if treatment=="`z'-`x'd`y'm"
			replace optout =0 if (treatment=="`z'`x'd`y'm" & ~("`z'"=="Oo"))|treatment=="Nw"|treatment=="W"
			foreach yr in "08" "09" {

				replace treatment="`z'`x'd`y'm`yr'" if treatment=="`z'`x'd`y'm" & ("`x'"=="0" & "`z'"=="W" & ("`y'"=="5"|"`y'"=="10") & year==20`yr')
				}
			}
		}
	}
ta treatment,m
* Generate dependent variables
rename saidyes outcomeyes
rename answer outcomeans
rename optout outcomeopt

** This set of moments is to do Figure 5
if mom=="010-10p" {
	gen outcomedon010=amt_don>0 & amt_don<=10 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon10p=amt_don>10 & amt_don~=. if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	}
** This set of moments is to do Figure 6
if mom=="all" {
	gen outcomedon02=amt_don>0 & amt_don<2 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon2=amt_don==2 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon25=amt_don>2 & amt_don<5 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon5=amt_don==5 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon510=amt_don>5 & amt_don<10 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon10=amt_don==10 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon1020=amt_don>10 & amt_don<20 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon20=amt_don==20 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon2050=amt_don>20 & amt_don<50 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon50=amt_don==50 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon50p=amt_don>50 & amt_don~=. if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	}
** This set of moments is for the Online Appendix Tables (less detailed moments)
if mom=="010" {
	gen outcomedon010=amt_don>0 & amt_don<=10 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon1020=amt_don>10 & amt_don<=20 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon2050=amt_don>20 & amt_don<=50 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon50p=amt_don>50 & amt_don~=. if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	}
** Benchmark set of moments
** Use for Figures 4 and 7
if mom=="010-10" {
	gen outcomedon010=amt_don>0 & amt_don<10 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon10=amt_don==10 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon1020=amt_don>10 & amt_don<=20 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon2050=amt_don>20 & amt_don<=50 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon50p=amt_don>50 & amt_don~=. if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	}
** This set of moments is for the Online Appendix Tables (more detailed moments)
if mom=="03-37-710" {
	gen outcomedon03=amt_don>0 & amt_don<=3 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon37=amt_don>3 & amt_don<=7 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon710=amt_don>7 & amt_don<=10 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon1020=amt_don>10 & amt_don<=20 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon2050=amt_don>20 & amt_don<=50 if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	gen outcomedon50p=amt_don>50 & amt_don~=. if treatment=="Nw"|treatment=="W"|treatment=="Oo"
	}
su
keep charity treatment outcome* date location year mom sodate gr*
su


***Begin stacked approach
* Reshape to be able to do calculations of parameters easily
gen id=_n
reshape long outcome, i(id) j(outc) string
* Define new dependent variables as dummies
foreach z in ans yes {
	foreach x in "Nw0d10m" "Nw0d5m" "Nw5d5m" "Oo0d5m" "Oo5d5m" "W0d10m08" "W0d5m08" "W0d10m09" "W0d5m09" "W10d10m" "W10d5m" "W5d5m" {
		gen byte tr`z'`x'=treatment=="`x'" & outc=="`z'"
		}
	foreach x in "Nw" "Oo" "W" {
		foreach y in "Ecu" "Lar" {
			gen byte tr`z'`x'`y'=treatment=="`x'" & charity=="`y'" & outc=="`z'"
			}
		}
	}
foreach z in opt {
	foreach x in "Oo" {
		foreach y in "Ecu" "Lar" {
			gen byte tr`z'`x'`y'=treatment=="`x'" & charity=="`y'" & outc=="`z'"
			}
		}
	foreach x in "Oo0d5m" "Oo5d5m" {
		gen byte tr`z'`x'=treatment=="`x'" & outc=="`z'"
		}
	}

foreach z in "03" "37" "710" "010" "10" "1020" "2050" "50p" "10p" "02" "2" "25" "5" "510" "20" "50" {
		* Here aggregate between ECU and LaRabida to do Figures 5 and 6
		foreach x in "Nw" "Oo" "W" {
		if (mom=="all"|mom=="010-10p") {
			gen byte tr`z'`x'=treatment=="`x'" & outc=="don`z'"
			if (mom=="all" & ("`z'"=="03"|"`z'"=="37"|"`z'"=="710"|"`z'"=="010"|"`z'"=="10p")) | (mom=="010-10p" & ~("`z'"=="010"|"`z'"=="10p")) {
				drop tr`z'`x'`y' 
				}
			}
		if (mom=="010"|mom=="010-10"|mom=="03-37-710") {
			foreach y in "Ecu" "Lar" {
				gen byte tr`z'`x'`y'=treatment=="`x'" & charity=="`y'" & outc=="don`z'"
				if ("`z'"=="10p"|"`z'"=="02"|"`z'"=="2"|"`z'"=="25"|"`z'"=="5"|"`z'"=="510"|"`z'"=="20"|"`z'"=="50") | (mom=="010" & ("`z'"=="03"|"`z'"=="37"|"`z'"=="710"|"`z'"=="10")) | (mom=="010-10" & ("`z'"=="03"|"`z'"=="37"|"`z'"=="710")) | (mom=="03-37-710" & ("`z'"=="010"|"`z'"=="10"))  {
					drop tr`z'`x'`y' 
					}
				}
			}
		}
	}

* Keep only outcomes for relevant treatments
drop if outc=="opt" & ~(treatment=="Oo"|treatment=="Oo0d5m"|treatment=="Oo5d5m")
drop if ~(outc=="ans"|outc=="yes"|outc=="opt") & ~(treatment=="Nw"|treatment=="W"|treatment=="Oo")
if (mom=="all"|mom=="010-10p") {
	drop trans* tryes* tropt* 
	drop if (outc=="ans"|outc=="opt"|outc=="yes")
	}
gen sv="sv08" if charity=="Sv2008"
replace sv="sv09" if charity=="Sv2009"
egen outcsv=concat(outc sv)


memory
drop location charity treatment date sv
su
compress
memory

* Change order of variables
if mom=="010-10p" {
	order tr010Nw tr010Oo tr010W tr10pNw tr10pOo tr10pW
	}
if mom=="all" {
	order tr02Nw tr02Oo tr02W tr2Nw tr2Oo tr2W tr25Nw tr25Oo tr25W tr5Nw tr5Oo tr5W tr510Nw tr510Oo tr510W tr10Nw tr10Oo tr10W /*
	*/ tr1020Nw tr1020Oo tr1020W tr20Nw tr20Oo tr20W tr2050Nw tr2050Oo tr2050W tr50Nw tr50Oo tr50W tr50pNw tr50pOo tr50pW
	}
if mom=="010" {
	order transNwLar transNwEcu transWLar transWEcu transOoLar transOoEcu transNw0d10m transW0d5m08 transW0d10m08 transW10d10m /*
	*/ tryesNwLar tryesNwEcu tryesWLar tryesWEcu tryesOoLar tryesOoEcu tryesNw0d10m tryesW0d5m08 tryesW0d10m08 tryesW10d10m /*
	*/ troptOoLar troptOoEcu /*
	*/ transNw0d5m transNw5d5m transOo0d5m transOo5d5m transW0d10m09 transW0d5m09 transW10d5m transW5d5m /*
	*/ tryesNw0d5m tryesNw5d5m tryesOo0d5m tryesOo5d5m tryesW0d10m09 tryesW0d5m09 tryesW10d5m tryesW5d5m /*
	*/ troptOo0d5m troptOo5d5m  /*
	*/ tr010NwEcu tr010NwLar tr010OoEcu tr010OoLar tr010WEcu tr010WLar /*
	*/ tr1020NwEcu tr1020NwLar tr1020OoEcu tr1020OoLar tr1020WEcu tr1020WLar tr2050NwEcu tr2050NwLar tr2050OoEcu tr2050OoLar tr2050WEcu tr2050WLar /*
	*/ tr50pNwEcu tr50pNwLar tr50pOoEcu tr50pOoLar tr50pWEcu tr50pWLar
	}
if mom=="010-10" {
	order transNwLar transNwEcu transWLar transWEcu transOoLar transOoEcu transNw0d10m transW0d5m08 transW0d10m08 transW10d10m /*
	*/ tryesNwLar tryesNwEcu tryesWLar tryesWEcu tryesOoLar tryesOoEcu tryesNw0d10m tryesW0d5m08 tryesW0d10m08 tryesW10d10m /*
	*/ troptOoLar troptOoEcu /*
	*/ transNw0d5m transNw5d5m transOo0d5m transOo5d5m transW0d10m09 transW0d5m09 transW10d5m transW5d5m /*
	*/ tryesNw0d5m tryesNw5d5m tryesOo0d5m tryesOo5d5m tryesW0d10m09 tryesW0d5m09 tryesW10d5m tryesW5d5m /*
	*/ troptOo0d5m troptOo5d5m  /*
	*/ tr010NwEcu tr010NwLar tr010OoEcu tr010OoLar tr010WEcu tr010WLar tr10NwEcu tr10NwLar tr10OoEcu tr10OoLar tr10WEcu tr10WLar /*
	*/ tr1020NwEcu tr1020NwLar tr1020OoEcu tr1020OoLar tr1020WEcu tr1020WLar tr2050NwEcu tr2050NwLar tr2050OoEcu tr2050OoLar tr2050WEcu tr2050WLar /*
	*/ tr50pNwEcu tr50pNwLar tr50pOoEcu tr50pOoLar tr50pWEcu tr50pWLar
	}
if mom=="03-37-710" {
	order transNwLar transNwEcu transWLar transWEcu transOoLar transOoEcu transNw0d10m transW0d5m08 transW0d10m08 transW10d10m /*
	*/ tryesNwLar tryesNwEcu tryesWLar tryesWEcu tryesOoLar tryesOoEcu tryesNw0d10m tryesW0d5m08 tryesW0d10m08 tryesW10d10m /*
	*/ troptOoLar troptOoEcu /*
	*/ transNw0d5m transNw5d5m transOo0d5m transOo5d5m transW0d10m09 transW0d5m09 transW10d5m transW5d5m /*
	*/ tryesNw0d5m tryesNw5d5m tryesOo0d5m tryesOo5d5m tryesW0d10m09 tryesW0d5m09 tryesW10d5m tryesW5d5m /*
	*/ troptOo0d5m troptOo5d5m  /*
	*/ tr03NwEcu tr03NwLar tr03OoEcu tr03OoLar tr03WEcu tr03WLar tr37NwEcu tr37NwLar tr37OoEcu tr37OoLar tr37WEcu tr37WLar tr710NwEcu tr710NwLar tr710OoEcu tr710OoLar tr710WEcu tr710WLar /*
	*/ tr1020NwEcu tr1020NwLar tr1020OoEcu tr1020OoLar tr1020WEcu tr1020WLar tr2050NwEcu tr2050NwLar tr2050OoEcu tr2050OoLar tr2050WEcu tr2050WLar /*
	*/ tr50pNwEcu tr50pNwLar tr50pOoEcu tr50pOoLar tr50pWEcu tr50pWLar
	}

su tr*

*** Moments and VC matrix without controls
reg outcome tr*, nocons robust cluster(sodate)
if mom=="010-10p" {
	outreg2 tr* using output/QJE/moments010-10p, ctitle(Mom,NoCtrl) se  bdec(4) rdec(4) sdec(4) replace
	}
if mom=="all" {
	outreg2 tr* using output/QJE/momentsall, ctitle(Mom,NoCtrl) se  bdec(4) rdec(4) sdec(4) replace
	}
if mom=="010" {
	outreg2 tr* using output/QJE/moments010, ctitle(Mom,NoCtrl) se  bdec(4) rdec(4) sdec(4) replace
	}
if mom=="010-10" {
	outreg2 tr* using output/QJE/moments010-10, ctitle(Mom,NoCtrl) se  bdec(4) rdec(4) sdec(4) replace
	}
if mom=="03-37-710" {
	outreg2 tr* using output/QJE/moments03-37-710, ctitle(Mom,NoCtrl) se  bdec(4) rdec(4) sdec(4) replace
	}
save regs/cleanShortQJE,replace	

*** Demeaning the control variables to get the moments evaluated at the mean value of the parameters
clear
use regs/cleanShortQJE,clear
foreach x in sol datloc hour area {
	local j=92*("`x'"=="sol")+53*("`x'"=="datloc")+6*("`x'"=="hour")+8*("`x'"=="area")
	forvalues i=1/`j'{
		gen byte gr`x'`i'=gr`x'==`i'
		if mom=="010-10p" | mom=="all" {
			foreach z in don03 don37 don710 don010 don10 don1020 don2050 don50p don10p don02 don2 don25 don5 don510 don20 don50 {
				if (mom=="all" & ~("`z'"=="don03"|"`z'"=="don37"|"`z'"=="don710"|"`z'"=="don010"|"`z'"=="don10p")) | (mom=="010-10p" & ("`z'"=="don010"|"`z'"=="don10p")) {
					gen byte gr`z'`x'`i'=(gr`x'==`i' & outcsv=="`z'")
					egen mgr`z'`x'`i'=mean(gr`z'`x'`i') if outcsv=="`z'"
					gen dgr`z'`x'`i'=gr`z'`x'`i'-mgr`z'`x'`i'
					replace dgr`z'`x'`i'=0 if dgr`z'`x'`i'==.
					drop gr`z'`x'`i' mgr`z'`x'`i'
					}
				}
			}
		if (mom=="010"|mom=="010-10"|mom=="03-37-710") {
			foreach z in ans anssv08 anssv09 opt optsv09 yes yessv08 yessv09 don03 don37 don710 don010 don10 don1020 don2050 don50p don10p don02 don2 don25 don5 don510 don20 don50 {
				if ("`z'"=="ans"|"`z'"=="anssv08"|"`z'"=="anssv09"|"`z'"=="opt"|"`z'"=="optsv09"|"`z'"=="yes"|"`z'"=="yessv08"|"`z'"=="yessv09") | (mom=="010" & ("`z'"=="don010"|"`z'"=="don1020"|"`z'"=="don2050"|"`z'"=="don50p")) | (mom=="010-10" & ("`z'"=="don010"|"`z'"=="don10"|"`z'"=="don1020"|"`z'"=="don2050"|"`z'"=="don50p")) | (mom=="03-37-710" & ("`z'"=="don03"|"`z'"=="don37"|"`z'"=="don710"|"`z'"=="don1020"|"`z'"=="don2050"|"`z'"=="don50p"))  {
					gen byte gr`z'`x'`i'=(gr`x'==`i' & outcsv=="`z'")
					egen mgr`z'`x'`i'=mean(gr`z'`x'`i') if outcsv=="`z'"
					gen dgr`z'`x'`i'=gr`z'`x'`i'-mgr`z'`x'`i'
					replace dgr`z'`x'`i'=0 if dgr`z'`x'`i'==.
					drop gr`z'`x'`i' mgr`z'`x'`i'
					}
				}
			}
		compress
		}
	}

*** Generate all the moments and variance-covariance matrix that we use in the minimum-distance estimation (with controls)
xi: reg outcome tr* dgr*, nocons robust cluster(sodate)
if mom=="010-10p" {
	outreg2 tr* using output/QJE/moments010-10p, ctitle(Mom,Ctrl) se  bdec(4) rdec(4) sdec(4) append
	}
else if mom=="all" {
	outreg2 tr* using output/QJE/momentsall, ctitle(Mom,Ctrl) se  bdec(4) rdec(4) sdec(4) append
	}
else if mom=="010" {
	outreg2 tr* using output/QJE/moments010, ctitle(Mom,Ctrl) se  bdec(4) rdec(4) sdec(4) append
	matrix VCE=e(V)
	matrix VCEsub=VCE[1..64,1..64]
	svmat VCEsub, names(eqcol)
	keep _*
	keep if _transNwLar~=.
	outsheet using output/QJE/VarCov010.csv, comma replace
	}
else if mom=="010-10" {
	outreg2 tr* using output/QJE/moments010-10, ctitle(Mom,Ctrl) se  bdec(4) rdec(4) sdec(4) append
	matrix VCE=e(V)
	matrix VCEsub=VCE[1..70,1..70]
	svmat VCEsub, names(eqcol)
	keep _*
	keep if _transNwLar~=.
	outsheet using output/QJE/VarCov010-10.csv, comma replace
	}
else if mom=="03-37-710" {
	outreg2 tr* using output/QJE/moments03-37-710, ctitle(Mom,Ctrl) se  bdec(4) rdec(4) sdec(4) append
	matrix VCE=e(V)
	matrix VCEsub=VCE[1..76,1..76]
	svmat VCEsub, names(eqcol)
	keep _*
	keep if _transNwLar~=.
	outsheet using output/QJE/VarCov03-37-710.csv, comma replace
	}

}

log close
