To generate reduced-form results reported in the paper, run charityMainQJE.do from this folder. Lists of moments and other tables will be produced in output/QJE. Remaining numbers necessary for reproducing tables in the paper can be found in output/QJE/charityMainQJE.log.

Note: The Stata code for Tables 2 and 3 and Online Appendix Tables 1 and 2 produces the unadjusted mean of the dependent variables for the omitted treatment group. These sometimes differ from means reported in the Tables that are adjusted for fixed effects (and in a few instances may be using an outdated version of the data).

See charityMainQJE.do for additional comments.