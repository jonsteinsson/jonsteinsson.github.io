%This estimates the benchmark model using a smaller set of moments that describe the distribution of giving.
%See estimate_benchmark.m for code with more detailed comments.

clc; clear all; 
warning off MATLAB:quad:MinStepSize
outputFile = strcat('est-benchmark-lessdetailed-',datestr(now,'dd-mmm-yyyy-HH_MM'),'.txt');
dataFile = strcat('est-benchmark-lessdetailed-',datestr(now,'dd-mmm-yyyy-HH_MM'),'.mat');
diary(outputFile);
tic;
load Moments64.mat;   
format short g
paramLabels={'h0','r','eta','mu_lar','mu_ecu','mu_svy','sigma_lar','sigma_ecu','sigma_svy','S_lar','S_ecu','S_svy', 'c', 'Gi', 'h_2009'};
fixedParams = [ 0.5; 0.5; 0.05 ; 10; 5; -15; 10.0; 10.0; 20.0; 0.3; 0.1; 5.0 ; 75; 12 ; .5];

allMoments=1:64;
charityMoments=[1:6 11:16 21:22 41:64];
surveyMoments=[7:10 17:20 23:40];
noOfParams=15;
allParams = 1:noOfParams;

TolFun=1e-14;
TolX=1e-12;
maxSSE=1e-9;
fprintf('TolFun = %e  ,  TolX = %e \n',TolFun,TolX);


% =========================================================================
% *************************************************************************
% =========================================================================

paramsToUse=allParams ;
momentsToUse=allMoments;
W=inv(diag(diag(VCcontrol(momentsToUse,momentsToUse))));
noSearchInits=500;

% =========================================================================
% *************************************************************************
% =========================================================================

disp('Params being used = '); disp(paramsToUse);
disp('Moments being used = '); disp(momentsToUse);
fixedParamNames='';
for kk=1:noOfParams 
    if(ismember(kk,paramsToUse)==0)
        fixedParamNames=horzcat(fixedParamNames, sprintf('\t') ,paramLabels{kk}); 
    end
end

searchInits = getSearchInits_benchmark(noSearchInits);
for j=1:noOfParams
    if (ismember(j,paramsToUse)==0)
        searchInits(j,:)=fixedParams(j);
    end
end

paramHats=zeros(noOfParams,noSearchInits);
fval= repmat(-9999,1,noSearchInits);
sse= repmat(-9999,1,noSearchInits);
converged=repmat(-9999,1,noSearchInits);

parfor j=1:noSearchInits
   [paramHats(:,j), fval(j), converged(j), sse(j)] = minSearch_benchmark_lessdetailed(Moments,W,searchInits(:,j), paramsToUse,momentsToUse, TolFun, TolX); 
end

searchInits=searchInits';
paramHats=paramHats';

noOfAcceptableSolutions=sum(converged); % converged estimates
convergedParamHats=repmat(-9999,noOfAcceptableSolutions,noOfParams);
convergedInits=repmat(-9999,noOfAcceptableSolutions,noOfParams);
convergedSse=repmat(-9999,noOfAcceptableSolutions,1);

    
j=0;
for i=1:noSearchInits
    if converged(i)==1 
         j=j+1;
         convergedParamHats(j,:)=paramHats(i,:);
         convergedInits(j,:)=searchInits(i,:);
         convergedSse(j)=sse(i);
    end
end
    
    

    
sseParams=[convergedSse convergedParamHats convergedInits];
sseParamsSorted=sortrows(sseParams);
convergedSse=sseParamsSorted(:,1);
convergedParamHats=sseParamsSorted(:,2:noOfParams+1);    
convergedInits=sseParamsSorted(:,noOfParams+2:noOfParams+1+noOfParams);

 noSmallSSE=sum(convergedSse<maxSSE);

disp(sprintf('\n'));
disp(sprintf('==============================================================='));
if (size(paramsToUse)==noOfParams) 
    disp(sprintf('No Params fixed'));
else
    disp(sprintf('Fixed Params = %s',fixedParamNames));
end


bestEstimate=convergedParamHats(1,:);
m=Moments-simulator_benchmark_lessdetailed(bestEstimate);
sse=m'*W*m;

invVC=inv(VCcontrol(momentsToUse,momentsToUse));
[DFDY_CSD, FAC] =jacobianest(@simulator_benchmark_lessdetailed,bestEstimate);
DFDY_CSD =-DFDY_CSD(momentsToUse,paramsToUse);
A=DFDY_CSD'*W*DFDY_CSD;
B=DFDY_CSD'*W*VCcontrol(momentsToUse,momentsToUse)*W*DFDY_CSD;
VC = inv(A)*B*inv(A);
% VC_CSD = inv(DFDY_CSD'*invVC*DFDY_CSD);
sesTemp=diag(VC).^0.5;
ses = zeros(noOfParams,1);
for i=1:length(paramsToUse)
    ses(paramsToUse(i))=sesTemp(i);
end


disp(' ### ESTIMATES AND STANDARD ERRORS ###');
disp('=============================================================================================================================');
disp('    Estimates      SES      ');    
disp(' [          diag(VC)         ');
disp([ bestEstimate' ses]);
disp('============================================================================================================================');


disp('     Moment_No Emp_Moments  Simulated_Moments ');
disp([ [1:64]' Moments simulator_benchmark_lessdetailed(bestEstimate)]);
disp('=================================================================');
fprintf('                 SSE =        %g     \n', sse);          
disp('=================================================================');



% IMPLIED ESTIMATES
ImpliedEst=impliedParams_benchmark(bestEstimate);
DFDY_temp=jacobianest(@impliedParams_benchmark,bestEstimate');
DFDY_temp =-DFDY_temp(:,paramsToUse);
VC_temp=DFDY_temp*VC*DFDY_temp';
ImpliedEstSES=diag(VC_temp).^(0.5);
disp('=================================================================================================');
disp('Implied Unconditional Mean and Sigma, then mean and sigma cond on a>0 ')
disp('uncondn_mu_lar uncondn_sigma_lar condn_mu_lar condn_sigma_lar uncondn_mu_ecu uncondn_sigma_ecu condn_mu_ecu condn_sigma_ecu p_lar p_ecu');
disp(' ImpliedEst     SES ');
disp([ImpliedEst ImpliedEstSES]);

% PROPORTION HAPPY GIVERS
propGiversHappy=proportionGiversHappyBenchmark(bestEstimate);
DFDY_temp=jacobianest(@proportionGiversHappyBenchmark,bestEstimate');
DFDY_temp =-DFDY_temp(:,paramsToUse);
VC_temp=DFDY_temp*VC*DFDY_temp';
propGiversHappySES=diag(VC_temp).^(0.5);
disp('=================================================================================================');
disp('Proportion Happy Givers')
disp(' PropGiversHappy     SES');
disp([propGiversHappy propGiversHappySES]);

% NO FLYER CASE 
NoFlyerCase=giversAvgUtilBenchmark(bestEstimate);
DFDY_temp=jacobianest(@giversAvgUtilBenchmark,bestEstimate');
DFDY_temp =-DFDY_temp(:,paramsToUse);
VC_temp=DFDY_temp*VC*DFDY_temp';
NoFlyerCaseSES=diag(VC_temp).^(0.5);
disp('=================================================================================================');
disp(' NO FLYER CASE : Average utility compared to case with no solicitation')
disp(' Avg Util     SES');
disp([NoFlyerCase NoFlyerCaseSES]);


fprintf('\n\n\n');
fprintf('DETAILED RESULTS:\n\n');
disp(sprintf('%d out of %d estimates converged \n',noOfAcceptableSolutions,noSearchInits));
disp('[Index sseMoments] and [Estimated Parameters] ='); disp([ [1:noOfAcceptableSolutions]' convergedSse convergedParamHats]);


save(dataFile);
toc;
diary off    
