%This calibrates the model under the assumption that altruism is distributed according to a normal distribution, with
% all negative values assigned to a mass at a=0. That is, this estimates the benchmark model.

clc; clear all; 
warning off MATLAB:quad:MinStepSize
outputFile = strcat('est-benchmark-surveyMoments-',datestr(now,'dd-mmm-yyyy-HH_MM'),'.txt');
dataFile = strcat('est-benchmark-surveyMoments-',datestr(now,'dd-mmm-yyyy-HH_MM'),'.mat');
diary(outputFile);
load Moments70.mat;
format short g

%These parameters will be used in estimations that fix various values.
%Use the first line normally, and the 2nd line when estimating the model with 0 social pressure.
fixedParams = [ 0.5; 0.5; 0.05 ; 10; 5; -15; 10.0; 10.0; 20.0; 0.3; 0.1; 5.0 ; 75; 12 ; .5];
%fixedParams = [ 0.5; 0.5; 0.05 ; 10; 5; -15; 10.0; 10.0; 20.0; 0; 0; 0 ; 75; 12 ; .5];

%Defined in the text of the paper. h_2009 is the probability of being at home in 2009, h0 in 2008.
%S_lar and S_ecu are the cost of donating one dollar less than gs=$10. S_svy is the cost of saying no to the survey.
%Gi is the curvature parameter of the utility function.
paramLabels={'h0','r','eta','mu_lar','mu_ecu','mu_svy','sigma_lar','sigma_ecu','sigma_svy','S_lar','S_ecu','S_svy', 'c', 'Gi', 'h_2009'};

%Different estimations will use different sets of moments, defined here
allMoments=1:70;
charityMoments=[1:6 11:16 21:22 41:70];
surveyMoments=[7:10 17:20 23:40];

%Different estimations estimate different sets of parameters, defined here.
noOfParams=15;
allParams = 1:noOfParams;
noPressureParams = [1:9 13 15];
fixedSurvey =[1:5 7:8 10:11 14];
fixedCharity=[1:3 6 9 12 13 15];


%set tolerance parameters for numerical minimum distance estimation
TolFun=1e-14;
TolX=1e-12;
maxSSE=1e-9;
fprintf('TolFun = %e  ,  TolX = %e \n',TolFun,TolX);

%set paramsToUse to either "allParams" to estimate the full model 
%or "noPressureParams" to estimate model with no social pressure
%or "fixedCharity" to estimate only survey moments
%or "fixedSurvey" to estimate only charity moments
paramsToUse=fixedCharity;

%set to "allMoments" to estimate the full model or
%"charityMoments" to estimate charity moments only or
%"surveymoments" to estimate survey moments only.
momentsToUse=surveyMoments;

%VCcontrol is the empirical variance-covariance matrix in Moments70.mat
%Use first line for all cases except identity weighting matrix.
W=inv(diag(diag(VCcontrol(momentsToUse,momentsToUse))));
%W=eye(length(momentsToUse));

%number of numerical minimizations to run
noSearchInits=500;

% =========================================================================
% *************************************************************************
% =========================================================================

%Names of fixed parameters
fixedParamNames='';
for kk=1:noOfParams 
    if(ismember(kk,paramsToUse)==0)
        fixedParamNames=horzcat(fixedParamNames, sprintf('\t') ,paramLabels{kk}); 
    end
end

%Built matrix of initial search values in the parameter space
searchInits = getSearchInits_benchmark(noSearchInits);
for j=1:noOfParams
    if (ismember(j,paramsToUse)==0)
        searchInits(j,:)=fixedParams(j);
    end
end

%These will store the results of the minimum distance estimations
paramHats=zeros(noOfParams,noSearchInits);
fval= repmat(-9999,1,noSearchInits);
sse= repmat(-9999,1,noSearchInits);
converged=repmat(-9999,1,noSearchInits);

%This loop performs the actual estimations
parfor j=1:noSearchInits
   [paramHats(:,j), fval(j), converged(j), sse(j)] = minSearch_benchmark(Moments,W,searchInits(:,j), paramsToUse,momentsToUse, TolFun, TolX); 
end

searchInits=searchInits';
paramHats=paramHats';

%display some information about the estimates
noOfAcceptableSolutions=sum(converged); % converged estimates
disp('Converged solutions:  '); disp(noOfAcceptableSolutions);
convergedParamHats=repmat(-9999,noOfAcceptableSolutions,noOfParams);
convergedInits=repmat(-9999,noOfAcceptableSolutions,noOfParams);
convergedSse=repmat(-9999,noOfAcceptableSolutions,1);

%We only care about the estimates that converged
j=0;
for i=1:noSearchInits
    if converged(i)==1 
         j=j+1;
         convergedParamHats(j,:)=paramHats(i,:);
         convergedInits(j,:)=searchInits(i,:);
         convergedSse(j)=sse(i);
    end
end
    
sseParams=[convergedSse convergedParamHats convergedInits];
sseParamsSorted=sortrows(sseParams);
convergedSse=sseParamsSorted(:,1);
convergedParamHats=sseParamsSorted(:,2:noOfParams+1);    
convergedInits=sseParamsSorted(:,noOfParams+2:noOfParams+1+noOfParams);

%Number of estimates within the desired SSE range
noSmallSSE=sum(convergedSse<maxSSE);

%Estimate with the smallest SSE
bestEstimate=convergedParamHats(1,:);
m=Moments-simulator_benchmark(bestEstimate);
sse=m(momentsToUse)'*W*m(momentsToUse);

%calculate standard errors
invVC=inv(VCcontrol(momentsToUse,momentsToUse));
[DFDY_CSD, FAC] =jacobianest(@simulator_benchmark,bestEstimate);
DFDY_CSD =-DFDY_CSD(momentsToUse,paramsToUse);
A=DFDY_CSD'*W*DFDY_CSD;
B=DFDY_CSD'*W*VCcontrol(momentsToUse,momentsToUse)*W*DFDY_CSD;
VC = inv(A)*B*inv(A);
sesTemp=diag(VC).^0.5;
ses = zeros(noOfParams,1);
for i=1:length(paramsToUse)
    ses(paramsToUse(i))=sesTemp(i);
end



disp(' ### ESTIMATES AND STANDARD ERRORS ###');
disp('=============================================================================================================================');
disp('    Estimates      SES      ');    
disp(' [          diag(VC)         ');
disp([ bestEstimate' ses]);
disp('============================================================================================================================');


disp('     Moment_No Emp_Moments  Simulated_Moments ');
disp([ [1:70]' Moments simulator_benchmark(bestEstimate)]);
disp('=================================================================');
fprintf('                 SSE =        %g     \n', sse);          
disp('=================================================================');


fprintf('\n\n\n');
fprintf('DETAILED RESULTS:\n\n');
disp(sprintf('%d out of %d estimates converged \n',noOfAcceptableSolutions,noSearchInits));
disp('[Index sseMoments] and [Estimated Parameters] ='); disp([ [1:noOfAcceptableSolutions]' convergedSse convergedParamHats]);

save(dataFile);
diary off    
