%This function generates random starting points for the numerical minimum
%search in the estimate scripts.

function [searchInits] = getSearchInitsLogAtom(noSearchInits)
noOfParams=17;
lb=repmat([0	0	0	-5	-5	-100	0	0	0	0	0	0	0	1.0	0.0	0.0	0.0 ]',1,noSearchInits);
ub=repmat([1	1	1.0	5	5	100	5	5	100	5	5	100	999	999	1.0	1.0	1.0 ]',1,noSearchInits);

searchInits=lb+(ub-lb).*rand(noOfParams,noSearchInits);
end