function [searchInits] = getSearchInits_benchmark_asymmetricSorting(noSearchInits)
noOfParams=16;
lb=repmat([0 0 0 -50 -50 -100 0 0 0 0 0 0 0 1.0 0.0 0.0 ]',1,noSearchInits);
ub=repmat([1 1 1.0 50 50 100 50 50 100 0.99 0.99 0.99 999 1000 1.0 1.0]',1,noSearchInits);
searchInits=lb+(ub-lb).*rand(noOfParams,noSearchInits);
end