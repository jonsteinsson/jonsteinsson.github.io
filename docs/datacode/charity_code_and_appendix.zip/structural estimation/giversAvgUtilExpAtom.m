%This calculates the average utility of people contacted in the no flyer case compared to no solicitation, in the ExpAtom model

function f = giversAvgUtilExpAtom(parameters)

h_0=parameters(1);
h_2009=parameters(13);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_s=parameters(7);
S_lar=parameters(8);
S_ecu=parameters(9);
S_svy=parameters(10);
timeval=parameters(11);
Gi_lar=parameters(12);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
Pzero_lar = parameters(14);
Pzero_ecu = parameters(15);

if sum(parameters([1:5 7:15])<0)>0
    f=NaN(2,1);
    return;
end

if sum(parameters([1:2 13:15])>1)>0
    f=NaN(2,1);
    return;
end

amin_lar = 0;
amax_lar = expinv(0.9999,mu_lar);
amin_ecu = 0;
amax_ecu = expinv(0.9999,mu_ecu);


paramVector_lar = [S_lar gs_lar Gi_lar]';
paramVector_ecu = [S_ecu gs_ecu Gi_ecu]';


U_lar_quadl  = quadl(@(x) h_0*ustarDiff(x,paramVector_lar).*exppdf(x,mu_lar),amin_lar, amax_lar);
U_ecu_quadl  = quadl(@(x) h_0*ustarDiff(x,paramVector_ecu).*exppdf(x,mu_ecu), amin_ecu, amax_ecu);


U_lar = h_0*Pzero_lar*ustarDiff(0,paramVector_lar) + (1-Pzero_lar)*U_lar_quadl;
U_ecu = h_0*Pzero_ecu*ustarDiff(0,paramVector_ecu) + (1-Pzero_ecu)*U_ecu_quadl;


f = [U_lar U_ecu]';

end
