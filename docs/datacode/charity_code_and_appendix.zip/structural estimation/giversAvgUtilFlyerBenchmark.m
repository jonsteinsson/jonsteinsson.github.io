%This calculates the average utility of people contacted in the flyer case compared to no solicitation, in the benchmark model

function f = giversAvgUtilFlyerBenchmark(parameters)

r=parameters(2);

if sum(parameters([1:3 7:15])<0)>0
    f=repmat(NaN,2,1);
    return;
end

if sum(parameters([1:2])>1)>0
    f=repmat(NaN,2,1);
    return;
end

U_quadl = r*giversAvgUtilFlyerRBenchmark(parameters) + (1-r)*giversAvgUtilBenchmark( parameters);


f = [U_quadl(1) U_quadl(2)]';

end
