%This calculates the average utility per household in the no flyer case compared to no solicitation, in the LogAtom model

function f = giversAvgUtilLogAtom(parameters)


h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
h_2009=parameters(15);
Pzero_lar = parameters(16);
Pzero_ecu = parameters(17);
gs_lar=10;
gs_ecu=10;

k=5;
amin_lar = mu_lar - k*sigma_lar;
amax_lar = mu_lar + k*sigma_lar;
amin_ecu = mu_ecu - k*sigma_ecu;
amax_ecu = mu_ecu + k*sigma_ecu;

if sum(parameters([1:3 7:14])<0)>0
    f=repmat(NaN,2,1);
    return;
end

if sum(parameters([1:2])>1)>0
    f=repmat(NaN,2,1);
    return;
end



paramVector_lar = [S_lar gs_lar Gi_lar mu_lar sigma_lar]';
paramVector_ecu = [S_ecu gs_ecu Gi_ecu mu_ecu sigma_ecu]';


if (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
else
    aMinMin_lar = -(S_lar-1)*gs_lar/(Gi_lar*log(1+gs_lar/Gi_lar)+gs_lar*(log(Gi_lar+gs_lar)-1));
    aMin_lar=aMinMin_lar;
    aPlus_lar =  Gi_lar + gs_lar;
end


% For ecu
if (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
else
    aMinMin_ecu = -(S_ecu-1)*gs_ecu/(Gi_ecu*log(1+gs_ecu/Gi_ecu)+gs_ecu*(log(Gi_ecu+gs_ecu)-1));
    aMin_ecu=aMinMin_ecu;
    aPlus_ecu =  Gi_ecu + gs_ecu;
end



U_lar_quadl  = Pzero_lar*h_0*(-S_lar*gs_lar)+(1-Pzero_lar)*quadl(@(x) h_0*ustarDiff(x,paramVector_lar).*lognpdf(x,mu_lar,sigma_lar),exp(amin_lar), exp(amax_lar));
U_ecu_quadl  = Pzero_ecu*h_0*(-S_ecu*gs_ecu)+(1-Pzero_ecu)*quadl(@(x) h_0*ustarDiff(x,paramVector_ecu).*lognpdf(x,mu_ecu,sigma_ecu),exp(amin_ecu), exp(amax_ecu));


f = [U_lar_quadl U_ecu_quadl]';

end



