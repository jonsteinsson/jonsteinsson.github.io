%This calculates the average utility per household in the no flyer case compared to no solicitation, in the benchmark model
% allowing for a fraction 1-p with no social preferences

function f = giversAvgUtilNoSocPrefs(parameters)


N=15;


h_0=parameters(1);
h_2009=parameters(15);
r=parameters(2);
eta_down=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
p=parameters(16); % p = proportion with both social pressure and altruism social preferences
gs_lar=10;
gs_ecu=10;


p_paramVector_lar = [S_lar gs_lar Gi_lar mu_lar sigma_lar]';
p_paramVector_ecu = [S_ecu gs_ecu Gi_ecu mu_ecu sigma_ecu]';




U_lar  = quadl(@(x) p*h_0*ustarDiff(x,p_paramVector_lar).*normpdf(x,mu_lar,sigma_lar),  mu_lar-5*sigma_lar, mu_lar+5*sigma_lar);
U_ecu  = quadl(@(x) p*h_0*ustarDiff(x,p_paramVector_ecu).*normpdf(x,mu_ecu,sigma_ecu),  mu_ecu-5*sigma_ecu, mu_ecu+5*sigma_ecu);


f = [U_lar U_ecu]';

end
