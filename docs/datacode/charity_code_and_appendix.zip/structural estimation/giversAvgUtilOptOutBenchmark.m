%Calculates average utility per household in the opt-out case, benchmark estimates

function f = giversAvgUtilOptOutBenchmark(parameters)


N=15;


h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;



if sum(parameters([1:3 7:14])<0)>0
    f=repmat(NaN,2,1);
    return;
end

if sum(parameters([1:2])>1)>0
    f=repmat(NaN,2,1);
    return;
end

if (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
else
    aMinMin_lar = -(S_lar-1)*gs_lar/(Gi_lar*log(1+gs_lar/Gi_lar)+gs_lar*(log(Gi_lar+gs_lar)-1));
    aMin_lar=aMinMin_lar;
    aPlus_lar =  Gi_lar + gs_lar;
end



% For ecu
if (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
else
    aMinMin_ecu = -(S_ecu-1)*gs_ecu/(Gi_ecu*log(1+gs_ecu/Gi_ecu)+gs_ecu*(log(Gi_ecu+gs_ecu)-1));
    aMin_ecu=aMinMin_ecu;
    aPlus_ecu =  Gi_ecu + gs_ecu;
end

paramVector_lar = [h_0 eta S_lar gs_lar Gi_lar aMinMin_lar aMin_lar aPlus_lar]';
paramVector_ecu = [h_0 eta S_ecu gs_ecu Gi_ecu aMinMin_ecu aMin_ecu aPlus_ecu]';

U_lar_quadl  = quadl(@(x) ustarDiffOptOut(x,paramVector_lar) .* normpdf(x,mu_lar,sigma_lar), mu_lar-5*sigma_lar, mu_lar+5*sigma_lar);
U_ecu_quadl  = quadl(@(x) ustarDiffOptOut(x,paramVector_ecu) .* normpdf(x,mu_ecu,sigma_ecu), mu_ecu-5*sigma_ecu, mu_ecu+5*sigma_ecu);


f = [U_lar_quadl U_ecu_quadl]';

end
