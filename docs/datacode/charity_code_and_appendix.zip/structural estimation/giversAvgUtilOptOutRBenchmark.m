%Calculates average utility per household who see the flyer in the opt-out case, benchmark estimates


function f = giversAvgUtilOptOutRBenchmark(parameters)

r=parameters(2);



if sum(parameters([1:3 7:15])<0)>0
    f=repmat(NaN,2,1);
    return;
end

if sum(parameters([1:2 15])>1)>0
    f=repmat(NaN,2,1);
    return;
end

U_quadl = r*giversAvgUtilOptOutBenchmark(parameters) + (1-r)*giversAvgUtilBenchmark( parameters);


f = [U_quadl(1) U_quadl(2)]';

end
