%compares levels of giving to a hypothetical scenario without social pressure, benchmark model

function f = givingCompareWithNoPressureBenchmark(parameters)

h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;

if sum(parameters([1:3 7:14])<0)>0
    f=repmat(NaN,6,1);
    return;
end

if sum(parameters([1:2])>1)>0
    f=repmat(NaN,6,1);
    return;
end


paramVector_lar = [S_lar gs_lar Gi_lar mu_lar sigma_lar]';
paramVector_ecu = [S_ecu gs_ecu Gi_ecu mu_ecu sigma_ecu]';
paramVectorS0_lar = [0 gs_lar Gi_lar mu_lar sigma_lar]';
paramVectorS0_ecu = [0 gs_ecu Gi_ecu mu_ecu sigma_ecu]';


GS_lar_quadl  = h_0*quadl(@(x) gstar(x,paramVector_lar).*normpdf(x,mu_lar,sigma_lar), -1, mu_lar+5*sigma_lar);
GS0_lar_quadl = h_0*quadl(@(x) gstar(x,paramVectorS0_lar).*normpdf(x,mu_lar,sigma_lar), -1, mu_ecu+5*sigma_ecu);
fracWithoutSoc_lar = GS0_lar_quadl/GS_lar_quadl;
GS_ecu_quadl  = h_0*quadl(@(x) gstar(x,paramVector_ecu).*normpdf(x,mu_ecu,sigma_ecu), -1, mu_lar+5*sigma_lar);
GS0_ecu_quadl = h_0*quadl(@(x) gstar(x,paramVectorS0_ecu).*normpdf(x,mu_ecu,sigma_ecu), -1, mu_ecu+5*sigma_ecu);
fracWithoutSoc_ecu = GS0_ecu_quadl/GS_ecu_quadl;

f = [GS_lar_quadl GS0_lar_quadl fracWithoutSoc_lar GS_ecu_quadl GS0_ecu_quadl fracWithoutSoc_ecu]';

end


