%average unconditional giving in three treatments (no flyer, flyer, and opt-out), benchmark model

function f = givingComparison(parameters)

r=parameters(2);

if sum(parameters([1:3 7:15])<0)>0
    f=repmat(NaN,6,1);
    return;
end

if sum(parameters([1:2 15])>1)>0
    f=repmat(NaN,6,1);
    return;
end


g_nf=givingNoFlyer(parameters);
g_fr1=givingFlyer(parameters);
g_oor1=givingOO(parameters);

g_f= r*g_fr1 + (1-r)*g_nf;
g_oo= r*g_oor1 + (1-r)*g_nf;


f=[ g_nf(1) g_f(1) g_oo(1) g_nf(2) g_f(2) g_oo(2) ]'; 

end
