%average unconditional giving in opt-out treatment, benchmark model

function f = givingOO(parameters)


N=15;


h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;

epsilon=1e-4;


if (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
        if (a0_lar < aMin_lar || a0_lar > aPlus_lar)
        [a0_lar fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_lar*(1-S_lar))) - a0 + Gi_lar*(1-S_lar) - S_lar*gs_lar,[aMinMin_lar-epsilon aMin_lar+epsilon]);
    end
else
    aMinMin_lar = -(S_lar-1)*gs_lar/(Gi_lar*log(1+gs_lar/Gi_lar)+gs_lar*(log(Gi_lar+gs_lar)-1));
    aMin_lar=aMinMin_lar;
    aPlus_lar =  Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
end
if (S_lar==0) aOO_lar=-Inf; else aOO_lar=a0_lar; end


if (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
        if (a0_ecu < aMin_ecu || a0_ecu > aPlus_ecu)
        [a0_ecu fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_ecu*(1-S_ecu))) - a0 + Gi_ecu*(1-S_ecu) - S_ecu*gs_ecu,[aMinMin_ecu-epsilon aMin_ecu+epsilon]);
    end
else
    aMinMin_ecu = -(S_ecu-1)*gs_ecu/(Gi_ecu*log(1+gs_ecu/Gi_ecu)+gs_ecu*(log(Gi_ecu+gs_ecu)-1));
    aMin_ecu=aMinMin_ecu;
    aPlus_ecu =  Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
end
if (S_ecu==0) aOO_ecu=-Inf; else aOO_ecu=a0_ecu; end


paramVector_lar = [h_0 eta S_lar gs_lar Gi_lar aMinMin_lar aMin_lar aPlus_lar aOO_lar]';
paramVector_ecu = [h_0 eta S_ecu gs_ecu Gi_ecu aMinMin_ecu aMin_ecu aPlus_ecu aOO_ecu]';

G_lar_quadl  = quadl(@(x) hstarOO(x,paramVector_lar) .* gstar(x,paramVector_lar(3:5)) .* normpdf(x,mu_lar,sigma_lar), mu_lar-5*sigma_lar, mu_lar+5*sigma_lar);
G_ecu_quadl  = quadl(@(x) hstarOO(x,paramVector_ecu) .* gstar(x,paramVector_ecu(3:5)) .* normpdf(x,mu_ecu,sigma_ecu), mu_ecu-5*sigma_ecu, mu_ecu+5*sigma_ecu);


f = [G_lar_quadl G_ecu_quadl]';

end


