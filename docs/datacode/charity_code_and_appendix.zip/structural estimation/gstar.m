%optimal giving

function [g] = gstar(a, paramVector)


S=paramVector(1);
gs=paramVector(2);
Gi=paramVector(3);



if (S<1)
    aMinMin =(1-S)*Gi;
    aMin = (1-S)*(Gi+gs);
    aPlus = Gi + gs;
    a0= gs/log(1+gs/Gi);
else
    aMinMin = -(S-1)*gs/(Gi*log(1+gs/Gi)+gs*(log(Gi+gs)-1));
    aMin=aMinMin;
    aPlus =  Gi + gs;
end


g=repmat([999], 1, length(a));

for i=1:length(g)
    if a(i)<=aMinMin
        g(i)=0;
    elseif a(i)<=aMin
        g(i)= a(i)/(1-S)-Gi;
    elseif a(i)<=aPlus
        g(i) = gs;
    else
        g(i)=a(i)-Gi;
    end
end    

end