%This function calculates the optimal probability of being at home for
%someone in the opt-out treatment.
function [h] = hstarOO(a, paramVector)

% See simulator code for variable definitions
h_0=paramVector(1);
eta=paramVector(2);
S=paramVector(3);
gs=paramVector(4);
Gi=paramVector(5);
aMinMin=paramVector(6);
aMin=paramVector(7);
aPlus=paramVector(8);
aOO=paramVector(9);

h=repmat([999], 1, length(a));

for i=1:length(h)
    if a(i)<=aMinMin
        h(i)=h_0 - eta * S * gs;
    elseif a(i)<=aMin
        h(i)=h_0 + eta * (a(i) .* log( a(i)/(1-S) ) - a(i) .* ( 1+log(Gi) ) - S*gs + Gi*(1-S) );
    elseif a(i)<=aPlus
        h(i) = h_0 + eta*(a(i).*log(1+gs/Gi)-gs);
    else
        h(i)=h_0 + eta*(Gi - a(i) + a(i).*log(a(i)/Gi));
    end
    if a(i)<=aOO
        h(i)=0;
    end
    h(i)=max(0,min(1,h(i)));
end    


 end
