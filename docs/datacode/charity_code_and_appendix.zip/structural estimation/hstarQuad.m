%See hstar.m for explanatory comments
%This function integrates over hstar

function [h] = hstarQuad(a, paramVector)

h_0=paramVector(1);
eta_down=paramVector(2);
S=paramVector(3);
gs=paramVector(4);
Gi=paramVector(5);
aMinMin=paramVector(6);
aMin=paramVector(7);
aPlus=paramVector(8);
aOO=paramVector(9);
mu=paramVector(10);
sigma=paramVector(11);
if (length(paramVector)>=12) 
    eta_up=paramVector(12); 
else
    eta_up=eta_down;
end

h=repmat([999], 1, length(a));

for i=1:length(h)
    if a(i) <= aOO
        eta=eta_down;
    else
        eta=eta_up;
    end
    if a(i)<=aMinMin
        h(i)=h_0 - eta * S * gs;
    elseif a(i)<=aMin
        if a(i)>=0 
            h(i)=h_0 + eta * (a(i) .* log( a(i)/(1-S) ) - a(i) .* ( 1+log(Gi) ) - S*gs + Gi*(1-S) );
        else 
            h(i)=h_0 + eta * (  (1-S).*(1-log((1-S)*Gi/a(i))) - S*gs - a(i)./Gi);
        end
    elseif a(i)<=aPlus
        if a(i)>=0
            h(i) = h_0 + eta*(a(i).*log(1+gs/Gi)-gs);
        else 
            h(i) = h_0 + eta*(a(i)./Gi.*(exp(gs)-1) - gs);
        end
    else
        h(i)=h_0 + eta*(Gi - a(i) + a(i).*log(a(i)/Gi));
    end
    h(i)=max(0,min(1,h(i)));
end    
    h=h.*normpdf(a,mu,sigma);
end