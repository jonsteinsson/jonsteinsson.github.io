%Log-normal version of hstarQuad

function [h] = hstarQuadLog(a, paramVector)

h_0=paramVector(1);
eta=paramVector(2);
S=paramVector(3);
gs=paramVector(4);
Gi=paramVector(5);
aMinMin=paramVector(6);
aMin=paramVector(7);
aPlus=paramVector(8);
aOO=paramVector(9);
mu=paramVector(10);
sigma=paramVector(11);

h=repmat([999], 1, length(a));

for i=1:length(h)
    if exp(a(i))<=aMinMin
        h(i)=h_0 - eta * S * gs;
    elseif exp(a(i))<=aMin
            h(i)=h_0 + eta * (exp(a(i)) .* log( exp(a(i))/(1-S) ) - exp(a(i)) .* ( 1+log(Gi) ) - S*gs + Gi*(1-S) );
    elseif exp(a(i))<=aPlus
            h(i) = h_0 + eta*(exp(a(i)).*log(1+gs/Gi)-gs);
    else
        h(i)=h_0 + eta*(Gi - exp(a(i)) + exp(a(i)).*log(exp(a(i))/Gi));
    end
    h(i)=max(0,min(1,h(i)));
end
h=h.*normpdf(a,mu,sigma);
end