%optimal probability of being at home in survey treatment

function [h] = hstarSvy(s, paramVector)

h_0=paramVector(1);
eta=paramVector(2);
S=paramVector(3);
c=paramVector(4);
m=paramVector(5);
sbarS=paramVector(6);



h=repmat([999], 1, length(s));

for i=1:length(h)
    if (s<sbarS) 
        h(i) = h_0-eta*S; 
    else
        h(i) = h_0 + eta*(s+m-c);
    end
h(i)=max(0,min(1,h(i)));
end    

end