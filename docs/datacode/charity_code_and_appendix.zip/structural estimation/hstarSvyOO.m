%optimal probability of being at home in opt-out survey treatment

function [h] = hstarSvyOO(s, paramVector)

h_0=paramVector(1);
eta=paramVector(2);
S=paramVector(3);
c=paramVector(4);
m=paramVector(5);
sbarS=paramVector(6);
sbar0=paramVector(7);

%create a list of h*'s, initialized at 999, one for each value of s (baseline utility of doing survey) provided
h=repmat([999], 1, length(s));

%calculate h* for each value of s
for i=1:length(s)
	%if value of doing survey is below threshold, this is h*. otherwise, the next expression.
    if (s<sbarS) 
        h(i) = h_0-eta*S; 
    else
        h(i) = h_0 + eta*(s+m-c);
    end
    %if you don't want to do the survey, opt out. then probability of being home ie answering the door, h*, is 0.
    if s<sbar0 h(i)=0; end
h(i)=max(0,min(1,h(i)));
end    

end