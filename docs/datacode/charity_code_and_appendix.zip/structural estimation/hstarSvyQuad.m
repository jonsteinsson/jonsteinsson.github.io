function [h] = hstarSvyQuad(s, paramVector)

h_0=paramVector(1);
eta_down=paramVector(2);
S=paramVector(3);
c=paramVector(4);
m=paramVector(5);
sbarS=paramVector(6);
sbar0=paramVector(7);
mu=paramVector(8);
sigma=paramVector(9);
if (length(paramVector)>=10) 
    eta_up=paramVector(10); 
else
    eta_up=eta_down;
end


h=repmat([999], 1, length(s));

for i=1:length(h)
    if s(i)<=sbar0
        eta=eta_down;
    else
        eta=eta_up;
    end
    if (s<sbarS) 
        h(i) = h_0-eta*S; 
    else
        h(i) = h_0 + eta*(s(i)+m-c);
    end
h(i)=max(0,min(1,h(i)));
end    
 h=h.*normpdf(s,mu,sigma);
end