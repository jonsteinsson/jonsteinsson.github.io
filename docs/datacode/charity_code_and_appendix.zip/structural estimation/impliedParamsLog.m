%This function converts the model parameters into the parameters listed in
%the tables in the paper (conditional mean altruism, probability of zero 
%altruism,  etc) in log-normal model

function [props] = impliedParamsLog(parameters)


% ================================================================

h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
% mu_lar=parameters(4);
% mu_ecu=parameters(5);
mu_s=parameters(6);
% sigma_lar=parameters(7);
% sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;


[mu_lar var_lar] = lognstat(parameters(4),parameters(7));
sigma_lar = var_lar^0.5;

[mu_ecu var_ecu] = lognstat(parameters(5),parameters(8));
sigma_ecu = var_ecu^0.5;


props=[mu_lar; mu_ecu; sigma_lar;sigma_ecu];

end



