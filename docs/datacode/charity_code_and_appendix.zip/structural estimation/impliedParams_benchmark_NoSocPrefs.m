%This function converts the model parameters into the parameters listed in
%the tables in the paper (conditional mean altruism, probability of zero 
%altruism,  etc) in benchmark model allowing for fractino of population with no social prefs


function [props] = impliedParams_benchmark_NoSocPrefs(parameters)

% =================================================================
% Set Parameters
% ================================================================




% ================================================================

h_0=parameters(1);
h_2009=parameters(15);
r=parameters(2);
eta_down=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
P=parameters(16);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;


share_SposApos_lar = P*(1-normcdf(0, mu_lar, sigma_lar));
share_SposAzero_lar =  P*normcdf(0, mu_lar, sigma_lar);
shareSzeroAzero_lar = (1-P); 

share_SposApos_ecu = P*(1-normcdf(0, mu_ecu, sigma_ecu));
share_SposAzero_ecu =  P*normcdf(0, mu_ecu, sigma_ecu);
shareSzeroAzero_ecu = (1-P); 

alpha_lar = -mu_lar/sigma_lar;
lambda_lar =  normpdf(alpha_lar)/(1-normcdf(alpha_lar));
delta_lar = lambda_lar * (lambda_lar - alpha_lar);
p_lar = normcdf(alpha_lar);

condn_mu_lar = mu_lar + sigma_lar * lambda_lar ;
uncondn_mu_lar = P * (1-p_lar) * condn_mu_lar;
condn_sigma_lar = sigma_lar * (1-delta_lar)^0.5 ;
uncondn_sigma_lar =  ( ((1-P) + P*p_lar)*uncondn_mu_lar^2 + P*(1-p_lar)*condn_sigma_lar^2 )^0.5 ;

alpha_ecu = -mu_ecu/sigma_ecu;
lambda_ecu =  normpdf(alpha_ecu)/(1-normcdf(alpha_ecu));
delta_ecu = lambda_ecu * (lambda_ecu - alpha_ecu);
p_ecu = normcdf(alpha_ecu);

condn_mu_ecu = mu_ecu + sigma_ecu * lambda_ecu ;
uncondn_mu_ecu = P * (1-p_ecu) * condn_mu_ecu;
condn_sigma_ecu = sigma_ecu * (1-delta_ecu)^0.5 ;
uncondn_sigma_ecu =  ( ((1-P) + P*p_ecu)*uncondn_mu_ecu^2 + P*(1-p_ecu)*condn_sigma_ecu^2 )^0.5 ;

mean_uncond_MU0_lar = uncondn_mu_lar/Gi_lar;
sd_uncond_MU0_lar =  uncondn_sigma_lar/Gi_lar;

mean_uncond_MU0_ecu = uncondn_mu_ecu/Gi_ecu;
sd_uncond_MU0_ecu = uncondn_sigma_ecu/Gi_ecu;

share_alt0_lar = (1-P) + P*p_lar;
share_alt0_ecu = (1-P) + P*p_ecu;


props=[shareSzeroAzero_lar; shareSzeroAzero_ecu; condn_mu_lar; condn_sigma_lar;condn_mu_ecu;condn_sigma_ecu; share_alt0_lar; share_alt0_ecu];

end



