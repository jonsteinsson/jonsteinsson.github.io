%This function converts the model parameters into the parameters listed in
%the tables in the paper (conditional mean altruism, probability of zero 
%altruism,  etc) in the benchmark model that additional allows for asymmetric
%sorting costs in or out of the home.
%Variable names are explained in simulator_benchmark

function [props] = impliedParamsEta(parameters)

% =================================================================
% Set Parameters
% ================================================================

h_0=parameters(1);
h_2009=parameters(15);
r=parameters(2);
eta_down=parameters(3);
eta_up=parameters(16);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;

alpha_lar = -mu_lar/sigma_lar;
lambda_lar =  normpdf(alpha_lar)/(1-normcdf(alpha_lar));
delta_lar = lambda_lar * (lambda_lar - alpha_lar);
p_lar = normcdf(alpha_lar);


condn_mu_lar = mu_lar + sigma_lar * lambda_lar ;
uncondn_mu_lar = (1-p_lar) * condn_mu_lar;
condn_sigma_lar = sigma_lar * (1-delta_lar)^0.5 ;
uncondn_sigma_lar =  ( p_lar*uncondn_mu_lar^2 + (1-p_lar)*condn_sigma_lar^2 )^0.5 ;

alpha_ecu = -mu_ecu/sigma_ecu;
lambda_ecu =  normpdf(alpha_ecu)/(1-normcdf(alpha_ecu));
delta_ecu = lambda_ecu * (lambda_ecu - alpha_ecu);
p_ecu = normcdf(alpha_ecu);

condn_mu_ecu = mu_ecu + sigma_ecu * lambda_ecu ;
uncondn_mu_ecu = (1-p_ecu) * condn_mu_ecu;
condn_sigma_ecu = sigma_ecu * (1-delta_ecu)^0.5 ;
uncondn_sigma_ecu =  ( p_ecu*uncondn_mu_ecu^2 + (1-p_ecu)*condn_sigma_ecu^2 )^0.5 ;


props=[uncondn_mu_lar;condn_mu_lar; uncondn_sigma_lar;condn_sigma_lar; ...
    uncondn_mu_ecu;condn_mu_ecu;uncondn_sigma_ecu;condn_sigma_ecu; p_lar; p_ecu];

end
