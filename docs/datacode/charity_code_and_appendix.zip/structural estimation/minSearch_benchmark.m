%Find the minimum distance estimate in the benchmark model

function [theta,fval, converged, sse] = minSearch_benchmark(moments,W,parsinit,paramsToUse, momentsToUse, varargin)

noOfParams=size(parsinit,1);

if size(varargin,2)==2 
    TolFun=varargin{1};
    TolX=varargin{2};
elseif size(varargin,2)==1 
    TolFun=varargin{1};
    TolX=1e-10;
else 
    TolFun=1e-14;
    TolX=1e-10; 
end

%Search space
lowerBound=[0.0001 0.0001 0.0001 -10000 -10000 -9999 0.001 0.001 0.001 0.0001 0.0001 0.0001 0.0001 1.0 0.0];
upperBound=[0.999 1.0 5.0 10000 10000 9999 9999 9999 9999 10.0 10.0 100.0 9999 10000 1.0];

% no of params that the algorithm will optimize over
noOfOptimizationParams=length(paramsToUse);
paramsToOptimize=-9999*ones(noOfOptimizationParams,1);
lb=-9999*ones(noOfOptimizationParams,1);
ub=9999*ones(noOfOptimizationParams,1);

j=0;
for i=1:noOfParams
    if ismember(i,paramsToUse)==1  
        j=j+1;
        paramsToOptimize(j)=parsinit(i);
        lb(j)=lowerBound(i);
        ub(j)=upperBound(i);
    end
end

%Set options for search   
 options=optimset('MaxFunEvals',50000,'MaxIter',50000, 'Display', 'none', 'LargeScale','off', 'TolFun', TolFun, 'TolX', TolX);
 options.Algorithm='interior-point';
 options.AlwaysHonorConstraints='bounds';

%find minimum distance estimate
 converged=-9999;
[thetaTemp,fval, exitFlag] = fmincon(@minimand, paramsToOptimize,[],[],[],[],lb,ub,[],options);
if (exitFlag <= 0) 
    converged=0;
end

if (exitFlag > 0) 
    converged=1;
end



theta=-99999*ones(noOfParams,1);

m=0;
for n=1:noOfParams
    if ismember(n,paramsToUse)==0 
        theta(n)=parsinit(n);
    else
        m=m+1;
        theta(n)=thetaTemp(m);
    end
end

%report the estimate and SSE
mSimOpt=simulator_benchmark(theta);
mTemp=moments-mSimOpt;
mTemp = mTemp(momentsToUse);
sse=mTemp'*W*mTemp;



%This is the objective function to minimize in fmincon above
function  [y] = minimand(paramsToOptimizeArg)    

j=0;
parameters=-9999*ones(noOfParams,1);
for ii=1:noOfParams
    if ismember(ii,paramsToUse)==0
        parameters(ii)=parsinit(ii);
    else
        j=j+1;
        parameters(ii)=paramsToOptimizeArg(j);
    end
end
        
mSim=simulator_benchmark(parameters);
mTemp=moments-mSim;
m=mTemp(momentsToUse);

y=m'*W*m;

end

end

