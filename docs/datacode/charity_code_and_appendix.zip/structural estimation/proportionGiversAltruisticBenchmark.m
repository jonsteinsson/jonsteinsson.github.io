%This calculates the proportion of givers who are altruistic; ie who would give even in the absense of social pressure
%using benchmark model estimates.

function [props] = proportionGiversAltruisticBenchmark(parameters)

% =================================================================
% Set Parameters
% ================================================================

%See simulator_benchmark.m for variable definitions
h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;

%fraction of population who gives without social pressure
PGalt_NF_lar = (1-normcdf( (Gi_lar-mu_lar)/sigma_lar))/(1-normcdf( ( (1-S_lar)*Gi_lar-mu_lar )/sigma_lar)) ;
PGalt_NF_ecu = (1-normcdf( (Gi_ecu-mu_ecu)/sigma_ecu))/(1-normcdf( ( (1-S_ecu)*Gi_ecu-mu_ecu )/sigma_ecu)) ;

props=[PGalt_NF_lar;PGalt_NF_ecu];

end

