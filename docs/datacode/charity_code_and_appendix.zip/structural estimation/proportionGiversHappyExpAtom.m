%See proportionGiversHappyBenchmark.m for more comments.
%This does the same in the ExpAtom model

function [props] = proportionGiversHappyExpAtom(parameters)

% =================================================================
% Set Parameters
% ================================================================

infinity=1000;
N=15;
epsilon=1e-5;

h_0=parameters(1);
h_2009=parameters(13);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_s=parameters(7);
S_lar=parameters(8);
S_ecu=parameters(9);
S_svy=parameters(10);
timeval=parameters(11);
Gi_lar=parameters(12);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;

if sum(parameters([1:5 7:15])<0)>0
    props=repmat(NaN,2,1);
    return;
end

if sum(parameters([1:2 13:15])>1)>0
    props=repmat(NaN,2,1);
    return;
end

% =====================================================================
% Critical Values for Charities
% =====================================================================

% For lar
if (S_lar==0) 
    aMinMin_lar = Gi_lar;
    aMin_lar = (Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    aOO_lar=-Inf;
elseif (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    aOO_lar= gs_lar/log(1+gs_lar/Gi_lar);
    if (aOO_lar < aMin_lar || aOO_lar > aPlus_lar)
        [aOO_lar fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_lar*(1-S_lar))) - a0 + Gi_lar*(1-S_lar) - S_lar*gs_lar,[aMinMin_lar-epsilon aMin_lar+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end
    end
else
    aMinMin_lar = (1-S_lar)*Gi_lar;
    aMin_lar=  (1-S_lar)*Gi_lar*exp(-gs_lar);
    aPlus_lar =  Gi_lar + gs_lar;
    aOO_lar= gs_lar/log(1+gs_lar/Gi_lar);
end


% For ecu
if (S_ecu==0) 
    aMinMin_ecu = Gi_ecu;
    aMin_ecu = (Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    aOO_ecu=-Inf;
elseif (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    aOO_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
    if (aOO_ecu < aMin_ecu || aOO_ecu > aPlus_ecu)
        [aOO_ecu fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_ecu*(1-S_ecu))) - a0 + Gi_ecu*(1-S_ecu) - S_ecu*gs_ecu,[aMinMin_ecu-epsilon aMin_ecu+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end
    end
else
    aMinMin_ecu = (1-S_ecu)*Gi_ecu;
    aMin_ecu=  (1-S_ecu)*Gi_ecu*exp(-gs_ecu);
    aPlus_ecu =  Gi_ecu + gs_ecu;
    aOO_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
end


% NOTE: NOT ROBUST TO S>1 -- doesn't matter for results
PGalt_NF_lar = (1-expcdf( aOO_lar,mu_lar))/(1-expcdf( aMinMin_lar,mu_lar )) ;
PGalt_NF_ecu = (1-expcdf( aOO_ecu,mu_ecu))/(1-expcdf(  aMinMin_ecu,mu_ecu )) ;

props=[PGalt_NF_lar;PGalt_NF_ecu];

end



