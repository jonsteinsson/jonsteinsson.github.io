%See proportionGiversHappyBenchmark.m for more comments.
%This does the same in the Log Atom model

function [props] = proportionGiversHappyLogAtom(parameters)

% =================================================================
% Set Parameters
% ================================================================

infinity=1000;
N=15;
epsilon=1e-5;

h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
h_2009=parameters(15);
Pzero_lar = parameters(16);
Pzero_ecu = parameters(17);
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;

k=5;
amin_lar = mu_lar - k*sigma_lar;
amax_lar = mu_lar + k*sigma_lar;
amin_ecu = mu_ecu - k*sigma_ecu;
amax_ecu = mu_ecu + k*sigma_ecu;

if sum(parameters([1:3 7:14])<0)>0
    props=repmat(NaN,2,1);
    return;
end

if sum(parameters([1:2])>1)>0
    props=repmat(NaN,2,1);
    return;
end

% =====================================================================
% Critical Values for Charities
% =====================================================================

% For lar
if (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
    if (a0_lar < aMin_lar || a0_lar > aPlus_lar)
        [a0_lar fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_lar*(1-S_lar))) - a0 + Gi_lar*(1-S_lar) - S_lar*gs_lar,[aMinMin_lar-epsilon aMin_lar+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end
    end
else
    aMinMin_lar = (1-S_lar)*Gi_lar;
    aMin_lar=  (1-S_lar)*Gi_lar*exp(-gs_lar);
    aPlus_lar =  Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
end
if (S_lar==0) aOO_lar=-Inf; else aOO_lar=a0_lar; end


hParams_lar=[h_0 eta S_lar gs_lar Gi_lar aMinMin_lar aMin_lar aPlus_lar aOO_lar mu_lar sigma_lar];

% For ecu
if (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
    if (a0_ecu < aMin_ecu || a0_ecu > aPlus_ecu)
        [a0_ecu fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_ecu*(1-S_ecu))) - a0 + Gi_ecu*(1-S_ecu) - S_ecu*gs_ecu,[aMinMin_ecu-epsilon aMin_ecu+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end        
    end
else
    aMinMin_ecu = (1-S_ecu)*Gi_ecu;
    aMin_ecu=  (1-S_ecu)*Gi_ecu*exp(-gs_ecu);
    aPlus_ecu =  Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
end
if (S_ecu==0) aOO_ecu=-Inf; else aOO_ecu=a0_ecu; end

hParams_ecu=[h_0 eta S_ecu gs_ecu Gi_ecu aMinMin_ecu aMin_ecu aPlus_ecu aOO_ecu mu_ecu sigma_ecu];

no_happy_givers_lar = (1-Pzero_lar)*(1-logncdf(aOO_lar, mu_lar,sigma_lar));
no_total_givers_lar = (1-Pzero_lar)*(1-logncdf(Gi_lar*(1-S_lar), mu_lar,sigma_lar)) + Pzero_lar*(S_lar>=1);
PGalt_NF_lar = no_happy_givers_lar/no_total_givers_lar;

no_happy_givers_ecu = (1-Pzero_ecu)*(1-logncdf(aOO_ecu, mu_ecu,sigma_ecu));
no_total_givers_ecu = (1-Pzero_ecu)*(1-logncdf(Gi_ecu*(1-S_ecu), mu_ecu,sigma_ecu)) + Pzero_ecu*(S_ecu>=1);
PGalt_NF_ecu = no_happy_givers_ecu/no_total_givers_ecu;

props=[PGalt_NF_lar;PGalt_NF_ecu];

end

