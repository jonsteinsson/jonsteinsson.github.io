%See proportionGiversHappyBenchmark.m for more comments.
%This does the same in the model allowing for a fraction 1-p with no social preferences

function [props] = proportionGiversHappyNoSocPrefs(parameters)

% =================================================================
% Set Parameters
% ================================================================

N=15;
epsilon=1e-5;

h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
p=parameters(15); % p = proportion with both social pressure and altruism social preferences
q=0; % q = proportion with no social pressure but with altruism
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;


if sum(parameters([1:3 7:14])<0)>0
    props=[NaN;NaN];
    return;
end

if sum(parameters([1:2 15])>1)>0
    props=[NaN;NaN];
    return;
end

% =====================================================================
% Critical Values for Charities
% =====================================================================

% For lar
if (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
    if (a0_lar < aMin_lar || a0_lar > aPlus_lar)
        [a0_lar fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_lar*(1-S_lar))) - a0 + Gi_lar*(1-S_lar) - S_lar*gs_lar,[aMinMin_lar-epsilon aMin_lar+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end
    end
else
    aMinMin_lar = -(S_lar-1)*gs_lar/(Gi_lar*log(1+gs_lar/Gi_lar)+gs_lar*(log(Gi_lar+gs_lar)-1));
    aMin_lar=aMinMin_lar;
    aPlus_lar =  Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
end
if (S_lar==0) aOO_lar=-Inf; else aOO_lar=a0_lar; end


% For ecu
if (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
    if (a0_ecu < aMin_ecu || a0_ecu > aPlus_ecu)
        [a0_ecu fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_ecu*(1-S_ecu))) - a0 + Gi_ecu*(1-S_ecu) - S_ecu*gs_ecu,[aMinMin_ecu-epsilon aMin_ecu+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end        
    end
else
    aMinMin_ecu = -(S_ecu-1)*gs_ecu/(Gi_ecu*log(1+gs_ecu/Gi_ecu)+gs_ecu*(log(Gi_ecu+gs_ecu)-1));
    aMin_ecu=aMinMin_ecu;
    aPlus_ecu =  Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
end
if (S_ecu==0) aOO_ecu=-Inf; else aOO_ecu=a0_ecu; end


%Fraction of population, including the 1-p who don't have social preferences and don't give, who seek the fundraiser
noGiversP_lar = p*(1-normcdf( ( (1-S_lar)*Gi_lar-mu_lar )/sigma_lar));
noHappyGiversP_lar = p*(1-normcdf( (a0_lar-mu_lar )/sigma_lar));
PGalt_NF_lar = noHappyGiversP_lar/noGiversP_lar;

noGiversP_ecu = p*(1-normcdf( ( (1-S_ecu)*Gi_ecu-mu_ecu )/sigma_ecu));
noHappyGiversP_ecu = p*(1-normcdf( (a0_ecu-mu_ecu )/sigma_ecu));
PGalt_NF_ecu = noHappyGiversP_ecu/noGiversP_ecu;

props=[PGalt_NF_lar;PGalt_NF_ecu];

end



