%This is a subsidiary simulator file called by the other simulator files.
%It calculates survey moments from 2009 surveys. 2008 survey moments are
%calculated similarly within the main simulator files. These are separate
%moments because h_0 is allowed to be different between 2008 and 2009.

function [simMoments] = simulator_2009Moments(parameters)


% ================================================================

%See simulator_benchmark for variable definitions
h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_s=parameters(4);
sigma_s=parameters(5);
S_svy=parameters(6);
timeval=parameters(7);

% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;


% =============================================================
% Survey Stuff
% =============================================================

% Values of s at which you say yes if asked
sbarS_0d5m = c5-m_0-S_svy;
sbarS_0d10m = c10-m_0-S_svy;
sbarS_5d5m = c5-m_5-S_svy;
sbarS_10d5m = c5-m_10-S_svy;

% Values of s at which you would have said yes, for S=0
sbar0_0d5m = c5 - m_0;
sbar0_5d5m = c5 - m_5;

% Value of s at which you set h=0
sh0_0d5m = c5 - m_0 - h_0/eta;
sh0_0d10m = c10 - m_0 - h_0/eta;
sh0_5d5m = c5 - m_5 - h_0/eta;
sh0_10d5m = c5 - m_10 - h_0/eta;

% Value of s at which you set h=1
sh1_0d5m = c5 - m_0 + (1-h_0)/eta;
sh1_0d10m = c10 - m_0 + (1-h_0)/eta;
sh1_5d5m = c5 - m_5 + (1-h_0)/eta;
sh1_10d5m = c5 - m_10 + (1-h_0)/eta;


% Various evaluations of pdfs and cdf's
pdf_sbarS_0d5m = normpdf((sbarS_0d5m-mu_s)/sigma_s);
pdf_sh1_0d5m = normpdf((sh1_0d5m-mu_s)/sigma_s);
pdf_sh0_0d5m = normpdf((sh0_0d5m-mu_s)/sigma_s);
pdf_sbar0_0d5m = normpdf((sbar0_0d5m-mu_s)/sigma_s);
F_sbarS_0d5m = normcdf((sbarS_0d5m-mu_s)/sigma_s);
F_sh1_0d5m = normcdf((sh1_0d5m-mu_s)/sigma_s);
F_sh0_0d5m = normcdf((sh0_0d5m-mu_s)/sigma_s);
F_sbar0_0d5m = normcdf((sbar0_0d5m-mu_s)/sigma_s);

pdf_sbarS_5d5m = normpdf((sbarS_5d5m-mu_s)/sigma_s);
pdf_sh1_5d5m = normpdf((sh1_5d5m-mu_s)/sigma_s);
pdf_sh0_5d5m = normpdf((sh0_5d5m-mu_s)/sigma_s);
pdf_sbar0_5d5m = normpdf((sbar0_5d5m-mu_s)/sigma_s);
F_sbarS_5d5m = normcdf((sbarS_5d5m-mu_s)/sigma_s);
F_sh1_5d5m = normcdf((sh1_5d5m-mu_s)/sigma_s);
F_sh0_5d5m = normcdf((sh0_5d5m-mu_s)/sigma_s);
F_sbar0_5d5m = normcdf((sbar0_5d5m-mu_s)/sigma_s);

pdf_sbarS_0d10m = normpdf((sbarS_0d10m-mu_s)/sigma_s);
pdf_sh1_0d10m = normpdf((sh1_0d10m-mu_s)/sigma_s);
pdf_sh0_0d10m = normpdf((sh0_0d10m-mu_s)/sigma_s);
F_sbarS_0d10m = normcdf((sbarS_0d10m-mu_s)/sigma_s);
F_sh1_0d10m = normcdf((sh1_0d10m-mu_s)/sigma_s);
F_sh0_0d10m = normcdf((sh0_0d10m-mu_s)/sigma_s);


pdf_sbarS_10d5m = normpdf((sbarS_10d5m-mu_s)/sigma_s);
pdf_sh1_10d5m = normpdf((sh1_10d5m-mu_s)/sigma_s);
pdf_sh0_10d5m = normpdf((sh0_10d5m-mu_s)/sigma_s);
F_sbarS_10d5m = normcdf((sbarS_10d5m-mu_s)/sigma_s);
F_sh1_10d5m = normcdf((sh1_10d5m-mu_s)/sigma_s);
F_sh0_10d5m = normcdf((sh0_10d5m-mu_s)/sigma_s);


dF_sh1sS_0d5m = F_sh1_0d5m-F_sbarS_0d5m;
dF_sh1sS_5d5m = F_sh1_5d5m-F_sbarS_5d5m;
dF_sh1sS_0d10m = F_sh1_0d10m-F_sbarS_0d10m;
dF_sh1sS_10d5m = F_sh1_10d5m-F_sbarS_10d5m;

dF_sh1sh0_0d5m = F_sh1_0d5m-F_sh0_0d5m;
dF_sh1sh0_5d5m = F_sh1_5d5m-F_sh0_5d5m;
dF_sh1sh0_0d10m = F_sh1_0d10m-F_sh0_0d10m;
dF_sh1sh0_10d5m = F_sh1_10d5m-F_sh0_10d5m;

dF_sh1sbar0_0d5m = F_sh1_0d5m-F_sbar0_0d5m;
dF_sh1sbar0_5d5m = F_sh1_5d5m-F_sbar0_5d5m;


% Truncated Expectations multiplied by (cdf-cdf)
E_sSsh1_0d5m = mu_s*(dF_sh1sS_0d5m) + sigma_s*(pdf_sbarS_0d5m-pdf_sh1_0d5m);
E_sh0sh1_0d5m = mu_s*(dF_sh1sh0_0d5m) + sigma_s*(pdf_sh0_0d5m-pdf_sh1_0d5m);
E_s0sh1_0d5m = mu_s*(dF_sh1sbar0_0d5m) + sigma_s*(pdf_sbar0_0d5m-pdf_sh1_0d5m);

E_sSsh1_5d5m = mu_s*(dF_sh1sS_5d5m) + sigma_s*(pdf_sbarS_5d5m-pdf_sh1_5d5m);
E_sh0sh1_5d5m = mu_s*(dF_sh1sh0_5d5m) + sigma_s*(pdf_sh0_5d5m-pdf_sh1_5d5m);
E_s0sh1_5d5m = mu_s*(dF_sh1sbar0_5d5m) + sigma_s*(pdf_sbar0_5d5m-pdf_sh1_5d5m);

E_sSsh1_0d10m = mu_s*(dF_sh1sS_0d10m) + sigma_s*(pdf_sbarS_0d10m-pdf_sh1_0d10m);
E_sh0sh1_0d10m = mu_s*(dF_sh1sh0_0d10m) + sigma_s*(pdf_sh0_0d10m-pdf_sh1_0d10m);

E_sSsh1_10d5m = mu_s*(dF_sh1sS_10d5m) + sigma_s*(pdf_sbarS_10d5m-pdf_sh1_10d5m);
E_sh0sh1_10d5m = mu_s*(dF_sh1sh0_10d5m) + sigma_s*(pdf_sh0_10d5m-pdf_sh1_10d5m);


% ==============================================================
% New Survey Stuff. SOO is the survey opt-out treatment. See
% simulator_benchmark for more variable name explanation.
% ==============================================================

PH_NF_0d5m_new = h_0;
PSV_NF_0d5m_new = h_0*(1-F_sbarS_0d5m);

PH_NF_5d5m_new = h_0;
PSV_NF_5d5m_new = h_0*(1-F_sbarS_5d5m);

PH_SOO_0d5m_new =   (1-r)*h_0 + r*(h_0+eta*(m_0-c5))*dF_sh1sbar0_0d5m + r*eta*E_s0sh1_0d5m +r*(1-F_sh1_0d5m);
PSV_SOO_0d5m_new =  (1-r)*h_0*(1-F_sbarS_0d5m) + r*(h_0+eta*(m_0-c5))*dF_sh1sbar0_0d5m + r*eta*E_s0sh1_0d5m + r*(1-F_sh1_0d5m);
POO_SOO_0d5m_new = r*h_0*F_sbar0_0d5m;

PH_SOO_5d5m_new =   (1-r)*h_0 + r*(h_0+eta*(m_5-c5))*dF_sh1sbar0_5d5m + r*eta*E_s0sh1_5d5m +r*(1-F_sh1_5d5m);
PSV_SOO_5d5m_new =  (1-r)*h_0*(1-F_sbarS_5d5m) + r*(h_0+eta*(m_5-c5))*dF_sh1sbar0_5d5m + r*eta*E_s0sh1_5d5m + r*(1-F_sh1_5d5m);
POO_SOO_5d5m_new = r*h_0*F_sbar0_5d5m;

% PH_F_0d10m_new and PSV_F_0d10m_new
if (h_0-eta*S_svy>0)  
    PH_F_0d10m_new = (1-r)*h_0 + r*(h_0-eta*S_svy)*F_sbarS_0d10m + r*(h_0+eta*(m_0-c10))*dF_sh1sS_0d10m +r*eta*E_sSsh1_0d10m+r*(1-F_sh1_0d10m);
    PSV_F_0d10m_new = (1-r)*h_0*(1-F_sbarS_0d10m) + r*(h_0+eta*(m_0-c10))*dF_sh1sS_0d10m +r*eta*E_sSsh1_0d10m+r*(1-F_sh1_0d10m);
else
    PH_F_0d10m_new = (1-r)*h_0 +  r*(h_0+eta*(m_0-c10))*dF_sh1sh0_0d10m +r*eta*E_sh0sh1_0d10m+r*(1-F_sh1_0d10m);
    PSV_F_0d10m_new =(1-r)*h_0*(1-F_sbarS_0d10m) + r*(h_0+eta*(m_0-c10))*dF_sh1sh0_0d10m +r*eta*E_sh0sh1_0d10m+r*(1-F_sh1_0d10m);
end

% PH_F_0d5m_new and PSV_F_0d5m_new
if (h_0-eta*S_svy>0)  
    PH_F_0d5m_new = (1-r)*h_0 + r*(h_0-eta*S_svy)*F_sbarS_0d5m + r*(h_0+eta*(m_0-c5))*dF_sh1sS_0d5m +r*eta*E_sSsh1_0d5m+r*(1-F_sh1_0d5m);
    PSV_F_0d5m_new = (1-r)*h_0*(1-F_sbarS_0d5m) + r*(h_0+eta*(m_0-c5))*dF_sh1sS_0d5m +r*eta*E_sSsh1_0d5m+r*(1-F_sh1_0d5m);
else
    PH_F_0d5m_new = (1-r)*h_0 +  r*(h_0+eta*(m_0-c5))*dF_sh1sh0_0d5m +r*eta*E_sh0sh1_0d5m+r*(1-F_sh1_0d5m);
    PSV_F_0d5m_new =(1-r)*h_0*(1-F_sbarS_0d5m) + r*(h_0+eta*(m_0-c5))*dF_sh1sh0_0d5m +r*eta*E_sh0sh1_0d5m+r*(1-F_sh1_0d5m);
end

% PH_F_5d5m_new and PSV_F_5d5m_new
if (h_0-eta*S_svy>0)  
    PH_F_5d5m_new = (1-r)*h_0 + r*(h_0-eta*S_svy)*F_sbarS_5d5m + r*(h_0+eta*(m_5-c5))*dF_sh1sS_5d5m +r*eta*E_sSsh1_5d5m+r*(1-F_sh1_5d5m);
    PSV_F_5d5m_new = (1-r)*h_0*(1-F_sbarS_5d5m) + r*(h_0+eta*(m_5-c5))*dF_sh1sS_5d5m +r*eta*E_sSsh1_5d5m+r*(1-F_sh1_5d5m);
else
    PH_F_5d5m_new = (1-r)*h_0 +  r*(h_0+eta*(m_5-c5))*dF_sh1sh0_5d5m +r*eta*E_sh0sh1_5d5m+r*(1-F_sh1_5d5m);
    PSV_F_5d5m_new =(1-r)*h_0*(1-F_sbarS_5d5m) + r*(h_0+eta*(m_5-c5))*dF_sh1sh0_5d5m +r*eta*E_sh0sh1_5d5m+r*(1-F_sh1_5d5m);
end

% PH_F_10d5m_new and PSV_F_10d5m_new
if (h_0-eta*S_svy>0)  
    PH_F_10d5m_new = (1-r)*h_0 + r*(h_0-eta*S_svy)*F_sbarS_10d5m + r*(h_0+eta*(m_10-c5))*dF_sh1sS_10d5m +r*eta*E_sSsh1_10d5m+r*(1-F_sh1_10d5m);
    PSV_F_10d5m_new = (1-r)*h_0*(1-F_sbarS_10d5m) + r*(h_0+eta*(m_10-c5))*dF_sh1sS_10d5m +r*eta*E_sSsh1_10d5m+r*(1-F_sh1_10d5m);
else
    PH_F_10d5m_new = (1-r)*h_0 +  r*(h_0+eta*(m_10-c5))*dF_sh1sh0_10d5m +r*eta*E_sh0sh1_10d5m+r*(1-F_sh1_10d5m);
    PSV_F_10d5m_new =(1-r)*h_0*(1-F_sbarS_10d5m) + r*(h_0+eta*(m_10-c5))*dF_sh1sh0_10d5m +r*eta*E_sh0sh1_10d5m+r*(1-F_sh1_10d5m);
end


% ============================================
% Form Moments
% ============================================

m23	=	PH_NF_0d5m_new	;
m24	=	PH_NF_5d5m_new	;
m25	=	PH_SOO_0d5m_new	;
m26	=	PH_SOO_5d5m_new	;
m29	=	PH_F_0d10m_new	;
m30	=	PH_F_0d5m_new	;
m31	=	PH_F_10d5m_new	;
m32	=	PH_F_5d5m_new	;
m35	=	PSV_NF_0d5m_new	;
m36	=	PSV_NF_5d5m_new	;
m37	=	PSV_SOO_0d5m_new	;
m38	=	PSV_SOO_5d5m_new	;
m41	=	PSV_F_0d10m_new	;
m42	=	PSV_F_0d5m_new	;
m43	=	PSV_F_10d5m_new	;
m44	=	PSV_F_5d5m_new	;
m47	=	POO_SOO_0d5m_new	;
m48	=	POO_SOO_5d5m_new	;

simMoments = [ m23 m24 m25 m26 m29 m30 m31 m32 m35 m36 m37 m38 m41 m42 m43 m44 m47 m48 ]';

end
