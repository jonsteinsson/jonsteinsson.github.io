%Does the same as simulator_2009Moments but for people with a=0.

function [simMoments] = simulator_2009Moments_ZeroAltruism(parameters)

h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_s=parameters(4);
sigma_s=parameters(5);
S_svy=parameters(6);
timeval=parameters(7);
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;

ssvy = -timeval*10/60;

% =============================================================
% Survey Stuff
% =============================================================


% Values of s at which you say yes if asked
sbarS_0d5m = c5-m_0-S_svy;
sbarS_0d10m = c10-m_0-S_svy;
sbarS_5d5m = c5-m_5-S_svy;
sbarS_10d5m = c5-m_10-S_svy;

% Values of s at which you would have said yes, for S=0
sbar0_0d5m = c5 - m_0;
sbar0_5d5m = c5 - m_5;


% ==============================================================
% New Survey Stuff
% ==============================================================

PH_NF_0d5m_new = h_0;
PSV_NF_0d5m_new = h_0*(ssvy>sbarS_0d5m);

PH_NF_5d5m_new = h_0;
PSV_NF_5d5m_new = h_0*(ssvy>sbarS_5d5m);

PH_SOO_0d5m_new =   (1-r)*h_0 + r*hstarSvyOO(ssvy, [h_0 eta S_svy c5 m_0 sbarS_0d5m sbar0_0d5m]);
if  ssvy >= sbarS_0d5m  PSV_SOO_0d5m_new = PH_SOO_0d5m_new; else PSV_SOO_0d5m_new = 0; end
POO_SOO_0d5m_new = r*h_0*(ssvy<sbar0_0d5m);

PH_SOO_5d5m_new =   (1-r)*h_0 + r*hstarSvyOO(ssvy, [h_0 eta S_svy c5 m_5 sbarS_5d5m sbar0_5d5m]);
if  ssvy >= sbarS_5d5m  PSV_SOO_5d5m_new = PH_SOO_5d5m_new; else PSV_SOO_5d5m_new = 0; end
POO_SOO_5d5m_new = r*h_0*(ssvy<sbar0_5d5m);

PH_F_0d10m_new = (1-r)*h_0 + r*hstarSvy(ssvy, [h_0 eta S_svy c10 m_0 sbarS_0d10m]);
if  ssvy >= sbarS_0d10m  PSV_F_0d10m_new = PH_F_0d10m_new; else PSV_F_0d10m_new = 0; end

PH_F_0d5m_new = (1-r)*h_0 + r*hstarSvy(ssvy, [h_0 eta S_svy c5 m_0 sbarS_0d5m]);
if  ssvy >= sbarS_0d5m  PSV_F_0d5m_new = PH_F_0d5m_new; else PSV_F_0d5m_new = 0; end

PH_F_5d5m_new = (1-r)*h_0 + r*hstarSvy(ssvy, [h_0 eta S_svy c5 m_5 sbarS_5d5m]);
if  ssvy >= sbarS_5d5m  PSV_F_5d5m_new = PH_F_5d5m_new; else PSV_F_5d5m_new = 0; end

PH_F_10d5m_new = (1-r)*h_0 + r*hstarSvy(ssvy, [h_0 eta S_svy c5 m_10 sbarS_10d5m]);
if  ssvy >= sbarS_10d5m  PSV_F_10d5m_new = PH_F_10d5m_new; else PSV_F_10d5m_new = 0; end


% ============================================
% Form Moments
% ============================================

m23	=	PH_NF_0d5m_new	;
m24	=	PH_NF_5d5m_new	;
m25	=	PH_SOO_0d5m_new	;
m26	=	PH_SOO_5d5m_new	;
m29	=	PH_F_0d10m_new	;
m30	=	PH_F_0d5m_new	;
m31	=	PH_F_10d5m_new	;
m32	=	PH_F_5d5m_new	;
m35	=	PSV_NF_0d5m_new	;
m36	=	PSV_NF_5d5m_new	;
m37	=	PSV_SOO_0d5m_new	;
m38	=	PSV_SOO_5d5m_new	;
m41	=	PSV_F_0d10m_new	;
m42	=	PSV_F_0d5m_new	;
m43	=	PSV_F_10d5m_new	;
m44	=	PSV_F_5d5m_new	;
m47	=	POO_SOO_0d5m_new	;
m48	=	POO_SOO_5d5m_new	;


simMoments = [m23 m24 m25 m26 m29 m30 m31 m32 m35 m36 m37 m38 m41 m42 m43 m44 m47 m48]';

end
