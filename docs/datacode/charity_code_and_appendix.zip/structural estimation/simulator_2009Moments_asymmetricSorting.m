function [simMoments] = simulator_2009Moments_asymmetricSorting(parameters)


% ================================================================

h_0=parameters(1);
r=parameters(2);
eta_down=parameters(3);
mu_s=parameters(4);
sigma_s=parameters(5);
S_svy=parameters(6);
timeval=parameters(7);
eta_up=parameters(8);
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;


k=5;
amin_svy = mu_s - k*sigma_s;
amax_svy = mu_s + k*sigma_s;


% =============================================================
% Survey Stuff
% =============================================================


% Values of s at which you say yes if asked
sbarS_0d5m = c5-m_0-S_svy;
sbarS_0d10m = c10-m_0-S_svy;
sbarS_5d5m = c5-m_5-S_svy;
sbarS_10d5m = c5-m_10-S_svy;

% Values of s at which you would have said yes, for S=0
sbar0_0d5m = c5 - m_0;
sbar0_5d5m = c5 - m_5;
sbar0_0d10m = c10 - m_0;
sbar0_10d5m = c5 - m_10;

% Value of s at which you set h=1
sh1_0d5m = c5 - m_0 + (1-h_0)/eta_up;
sh1_5d5m = c5 - m_5 + (1-h_0)/eta_up;

% paramVectors for calls to hstarSvy etc.
hParams_0d5m =[h_0 eta_down S_svy c5 m_0 sbarS_0d5m sbar0_0d5m mu_s sigma_s eta_up];
hParams_0d10m =[h_0 eta_down S_svy c10 m_0 sbarS_0d10m sbar0_0d10m mu_s sigma_s eta_up];
hParams_5d5m =[h_0 eta_down S_svy c5 m_5 sbarS_5d5m sbar0_5d5m mu_s sigma_s eta_up];
hParams_10d5m =[h_0 eta_down S_svy c5 m_10 sbarS_10d5m sbar0_10d5m mu_s sigma_s eta_up];

% Various evaluations of pdfs and cdf's
pdf_sh1_0d5m = normpdf((sh1_0d5m-mu_s)/sigma_s);
pdf_sbar0_0d5m = normpdf((sbar0_0d5m-mu_s)/sigma_s);
pdf_sh1_5d5m = normpdf((sh1_5d5m-mu_s)/sigma_s);
pdf_sbar0_5d5m = normpdf((sbar0_5d5m-mu_s)/sigma_s);

F_sh1_0d5m = normcdf((sh1_0d5m-mu_s)/sigma_s);
F_sh1_5d5m = normcdf((sh1_5d5m-mu_s)/sigma_s);
F_sbar0_0d5m = normcdf((sbar0_0d5m-mu_s)/sigma_s);
F_sbar0_5d5m = normcdf((sbar0_5d5m-mu_s)/sigma_s);
F_sbarS_5d5m = normcdf((sbarS_5d5m-mu_s)/sigma_s);
F_sbarS_0d10m = normcdf((sbarS_0d10m-mu_s)/sigma_s);
F_sbarS_10d5m = normcdf((sbarS_10d5m-mu_s)/sigma_s);
F_sbarS_0d5m = normcdf((sbarS_0d5m-mu_s)/sigma_s);

dF_sh1sbar0_0d5m = F_sh1_0d5m-F_sbar0_0d5m;
dF_sh1sbar0_5d5m = F_sh1_5d5m-F_sbar0_5d5m;

% Truncated Expectations multiplied by (cdf-cdf)
E_s0sh1_0d5m = mu_s*(dF_sh1sbar0_0d5m) + sigma_s*(pdf_sbar0_0d5m-pdf_sh1_0d5m);
E_s0sh1_5d5m = mu_s*(dF_sh1sbar0_5d5m) + sigma_s*(pdf_sbar0_5d5m-pdf_sh1_5d5m);


% ==============================================================
% New Survey Stuff
% ==============================================================

PH_NF_0d5m_new = h_0;
PSV_NF_0d5m_new = h_0*(1-F_sbarS_0d5m);

PH_NF_5d5m_new = h_0;
PSV_NF_5d5m_new = h_0*(1-F_sbarS_5d5m);

PH_SOO_0d5m_new =   (1-r)*h_0 + r*(h_0+eta_up*(m_0-c5))*dF_sh1sbar0_0d5m + r*eta_up*E_s0sh1_0d5m +r*(1-F_sh1_0d5m);
PSV_SOO_0d5m_new =  (1-r)*h_0*(1-F_sbarS_0d5m) + r*(h_0+eta_up*(m_0-c5))*dF_sh1sbar0_0d5m + r*eta_up*E_s0sh1_0d5m + r*(1-F_sh1_0d5m);
POO_SOO_0d5m_new = r*h_0*F_sbar0_0d5m;

PH_SOO_5d5m_new =   (1-r)*h_0 + r*(h_0+eta_up*(m_5-c5))*dF_sh1sbar0_5d5m + r*eta_up*E_s0sh1_5d5m +r*(1-F_sh1_5d5m);
PSV_SOO_5d5m_new =  (1-r)*h_0*(1-F_sbarS_5d5m) + r*(h_0+eta_up*(m_5-c5))*dF_sh1sbar0_5d5m + r*eta_up*E_s0sh1_5d5m + r*(1-F_sh1_5d5m);
POO_SOO_5d5m_new = r*h_0*F_sbar0_5d5m;

% PH_F_0d10m_new and PSV_F_0d10m_new
intHF_0d10m = quad( @(X) hstarSvyQuad(X, hParams_0d10m), amin_svy, amax_svy);
intSVF_0d10m = quad( @(X) hstarSvyQuad(X, hParams_0d10m), min(amax_svy,max(sbarS_0d10m,amin_svy)), amax_svy);
PH_F_0d10m_new = (1-r)*h_0 + r* intHF_0d10m;
PSV_F_0d10m_new = (1-r)*h_0*(1-F_sbarS_0d10m) + r*intSVF_0d10m;

% PH_F_0d5m_new and PSV_F_0d5m_new
intHF_0d5m = quad( @(X) hstarSvyQuad(X, hParams_0d5m), amin_svy, amax_svy);
intSVF_0d5m = quad( @(X) hstarSvyQuad(X, hParams_0d5m), min(amax_svy,max(sbarS_0d5m,amin_svy)), amax_svy);
PH_F_0d5m_new = (1-r)*h_0 + r* intHF_0d5m;
PSV_F_0d5m_new = (1-r)*h_0*(1-F_sbarS_0d5m) + r*intSVF_0d5m;

% PH_F_5d5m_new and PSV_F_5d5m_new
intHF_5d5m = quad( @(X) hstarSvyQuad(X, hParams_5d5m), amin_svy, amax_svy);
intSVF_5d5m = quad( @(X) hstarSvyQuad(X, hParams_5d5m), min(amax_svy,max(sbarS_5d5m,amin_svy)), amax_svy);
PH_F_5d5m_new = (1-r)*h_0 + r* intHF_5d5m;
PSV_F_5d5m_new = (1-r)*h_0*(1-F_sbarS_5d5m) + r*intSVF_5d5m;

% PH_F_10d5m_new and PSV_F_10d5m_new
intHF_10d5m = quad( @(X) hstarSvyQuad(X, hParams_10d5m), amin_svy, amax_svy);
intSVF_10d5m = quad( @(X) hstarSvyQuad(X, hParams_10d5m), min(amax_svy,max(sbarS_10d5m,amin_svy)), amax_svy);
PH_F_10d5m_new = (1-r)*h_0 + r* intHF_10d5m;
PSV_F_10d5m_new = (1-r)*h_0*(1-F_sbarS_10d5m) + r*intSVF_10d5m;


% ============================================
% Form Moments
% ============================================

m23	=	PH_NF_0d5m_new	;
m24	=	PH_NF_5d5m_new	;
m25	=	PH_SOO_0d5m_new	;
m26	=	PH_SOO_5d5m_new	;
m29	=	PH_F_0d10m_new	;
m30	=	PH_F_0d5m_new	;
m31	=	PH_F_10d5m_new	;
m32	=	PH_F_5d5m_new	;
m35	=	PSV_NF_0d5m_new	;
m36	=	PSV_NF_5d5m_new	;
m37	=	PSV_SOO_0d5m_new	;
m38	=	PSV_SOO_5d5m_new	;
m41	=	PSV_F_0d10m_new	;
m42	=	PSV_F_0d5m_new	;
m43	=	PSV_F_10d5m_new	;
m44	=	PSV_F_5d5m_new	;
m47	=	POO_SOO_0d5m_new	;
m48	=	POO_SOO_5d5m_new	;



simMoments = [m23	m24	m25	m26	m29	m30	m31	m32	m35	m36	m37	m38	m41	m42	m43	m44	m47	m48]';


end



