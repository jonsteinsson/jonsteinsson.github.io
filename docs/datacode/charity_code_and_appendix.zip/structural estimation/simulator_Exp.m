%This simulates the model under the assumption that a is distributed
%according to an exponential distribution. For more detailed commends, see
%simulator_benchmark.m and simulator_ExpAtom.m

function [simMoments] = simulator_Exp(parameters)

% warning off MATLAB:quad:MinStepSize

% =================================================================
% Set Parameters
% ================================================================

infinity=1000;
g_int_lar = [10.01 20.0]; % below, we will calculate Prob(Giving_lar in [g_int_lar(1) g_int_lar(2)]  ), note closed brackets
a_int_lar = [ -Inf Inf];
g_int_ecu = [10.01 20.0]; % below, we will calculate Prob(Giving_ecu in [g_int_ecu(1) g_int_ecu(2)]  ), note closed brackets
a_int_ecu = [ -Inf Inf];
g_int1_lar = [20.01 50.0]; % below, we will calculate Prob(Giving_lar in [g_int1_lar(1) g_int1_lar(2)]  ), note closed brackets
a_int1_lar = [ -Inf Inf];
g_int1_ecu = [20.01 50.0]; % below, we will calculate Prob(Giving_ecu in [g_int1_ecu(1) g_int1_ecu(2)]  ), note closed brackets
a_int1_ecu = [ -Inf Inf];
g_int2_lar = [50.01 Inf]; % below, we will calculate Prob(Giving_lar in [g_int2_lar(1) g_int2_lar(2)]  ), note closed brackets
a_int2_lar = [ -Inf Inf];
g_int2_ecu = [50.01 Inf]; % below, we will calculate Prob(Giving_ecu in [g_int2_ecu(1) g_int2_ecu(2)]  ), note closed brackets
a_int2_ecu = [ -Inf Inf];
epsilon=1e-4;


% ================================================================

h_0=parameters(1);
h_2009=parameters(13);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_s=parameters(7);
S_lar=parameters(8);
S_ecu=parameters(9);
S_svy=parameters(10);
timeval=parameters(11);
Gi_lar=parameters(12);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;

amin_lar = 0;
amax_lar = expinv(0.9999,mu_lar);
amin_ecu = 0;
amax_ecu = expinv(0.9999,mu_ecu);

if sum(parameters([1:5 7:13])<0)>0
    simMoments=NaN(70,1);
    return;
end

if sum(parameters([1:2 13])>1)>0
    simMoments=NaN(70,1);
    return;
end


% =====================================================================
% Critical Values for Charities
% =====================================================================

% For lar
if (S_lar==0) 
    aMinMin_lar = Gi_lar;
    aMin_lar = (Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    aOO_lar=-Inf;
elseif (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    aOO_lar= gs_lar/log(1+gs_lar/Gi_lar);
    if (aOO_lar < aMin_lar || aOO_lar > aPlus_lar)
        [aOO_lar fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_lar*(1-S_lar))) - a0 + Gi_lar*(1-S_lar) - S_lar*gs_lar,[aMinMin_lar-epsilon aMin_lar+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end
    end
else
    aMinMin_lar = (1-S_lar)*Gi_lar;
    aMin_lar=  (1-S_lar)*Gi_lar*exp(-gs_lar);
    aPlus_lar =  Gi_lar + gs_lar;
    aOO_lar= gs_lar/log(1+gs_lar/Gi_lar);
end
hParams_lar=[h_0 eta S_lar gs_lar Gi_lar aMinMin_lar aMin_lar aPlus_lar aOO_lar mu_lar];


% For ecu
if (S_ecu==0) 
    aMinMin_ecu = Gi_ecu;
    aMin_ecu = (Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    aOO_ecu=-Inf;
elseif (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    aOO_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
    if (aOO_ecu < aMin_ecu || aOO_ecu > aPlus_ecu)
        [aOO_ecu fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_ecu*(1-S_ecu))) - a0 + Gi_ecu*(1-S_ecu) - S_ecu*gs_ecu,[aMinMin_ecu-epsilon aMin_ecu+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end
    end
else
    aMinMin_ecu = (1-S_ecu)*Gi_ecu;
    aMin_ecu=  (1-S_ecu)*Gi_ecu*exp(-gs_ecu);
    aPlus_ecu =  Gi_ecu + gs_ecu;
    aOO_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
end
hParams_ecu=[h_0 eta S_ecu gs_ecu Gi_ecu aMinMin_ecu aMin_ecu aPlus_ecu aOO_ecu mu_ecu];



% =============================================================
% Evaluate CDF's
% =============================================================

F_0_lar = expcdf(0,mu_lar);
if aMinMin_lar<0 ; F_aMinMin_lar = 0; else F_aMinMin_lar = expcdf(aMinMin_lar,mu_lar); end
if aMin_lar<0 ; F_aMin_lar = 0; else F_aMin_lar = expcdf(aMin_lar,mu_lar); end
F_aPlus_lar = expcdf(aPlus_lar,mu_lar);
if aOO_lar <0 ; F_aOO_lar = 0; else F_aOO_lar = expcdf(aOO_lar,mu_lar); end

F_0_ecu = expcdf(0,mu_ecu);
if aMinMin_ecu<0 ; F_aMinMin_ecu = 0; else F_aMinMin_ecu = expcdf(aMinMin_ecu,mu_ecu); end
if aMin_ecu<0 ; F_aMin_ecu = 0; else F_aMin_ecu = expcdf(aMin_ecu,mu_ecu); end
F_aPlus_ecu = expcdf(aPlus_ecu,mu_ecu);
if aOO_ecu <0 ; F_aOO_ecu = 0; else F_aOO_ecu = expcdf(aOO_ecu,mu_ecu); end


% =============================================================
% Survey Stuff
% =============================================================


sbarS_0d5m = c5-m_0-S_svy;
sbarS_0d10m = c10-m_0-S_svy;
sbarS_10d10m = c10-m_10-S_svy;

% Value of s at which you set h=0
sh0_0d5m = c5 - m_0 - h_0/eta;
sh0_0d10m = c10 - m_0 - h_0/eta;
sh0_10d10m = c10 - m_10 - h_0/eta;

% Value of s at which you set h=1
sh1_0d5m = c5 - m_0 + (1-h_0)/eta;
sh1_0d10m = c10 - m_0 + (1-h_0)/eta;
sh1_10d10m = c10 - m_10 + (1-h_0)/eta;

% Various evaluations of pdfs and cdf's
pdf_sbarS_0d5m = normpdf((sbarS_0d5m-mu_s)/sigma_s);
pdf_sh1_0d5m = normpdf((sh1_0d5m-mu_s)/sigma_s);
pdf_sh0_0d5m = normpdf((sh0_0d5m-mu_s)/sigma_s);
F_sbarS_0d5m = normcdf((sbarS_0d5m-mu_s)/sigma_s);
F_sh1_0d5m = normcdf((sh1_0d5m-mu_s)/sigma_s);
F_sh0_0d5m = normcdf((sh0_0d5m-mu_s)/sigma_s);

pdf_sbarS_0d10m = normpdf((sbarS_0d10m-mu_s)/sigma_s);
pdf_sh1_0d10m = normpdf((sh1_0d10m-mu_s)/sigma_s);
pdf_sh0_0d10m = normpdf((sh0_0d10m-mu_s)/sigma_s);
F_sbarS_0d10m = normcdf((sbarS_0d10m-mu_s)/sigma_s);
F_sh1_0d10m = normcdf((sh1_0d10m-mu_s)/sigma_s);
F_sh0_0d10m = normcdf((sh0_0d10m-mu_s)/sigma_s);

pdf_sbarS_10d10m = normpdf((sbarS_10d10m-mu_s)/sigma_s);
pdf_sh1_10d10m = normpdf((sh1_10d10m-mu_s)/sigma_s);
pdf_sh0_10d10m = normpdf((sh0_10d10m-mu_s)/sigma_s);
F_sbarS_10d10m = normcdf((sbarS_10d10m-mu_s)/sigma_s);
F_sh1_10d10m = normcdf((sh1_10d10m-mu_s)/sigma_s);
F_sh0_10d10m = normcdf((sh0_10d10m-mu_s)/sigma_s);

dF_sh1sS_0d5m = F_sh1_0d5m-F_sbarS_0d5m;
dF_sh1sS_0d10m = F_sh1_0d10m-F_sbarS_0d10m;
dF_sh1sS_10d10m = F_sh1_10d10m-F_sbarS_10d10m;
dF_sh1sh0_0d5m = F_sh1_0d5m-F_sh0_0d5m;
dF_sh1sh0_0d10m = F_sh1_0d10m-F_sh0_0d10m;
dF_sh1sh0_10d10m = F_sh1_10d10m-F_sh0_10d10m;

% Truncated Expectations multiplied by (cdf-cdf)
E_sSsh1_0d5m = mu_s*(dF_sh1sS_0d5m) + sigma_s*(pdf_sbarS_0d5m-pdf_sh1_0d5m);
E_sh0sh1_0d5m = mu_s*(dF_sh1sh0_0d5m) + sigma_s*(pdf_sh0_0d5m-pdf_sh1_0d5m);
E_sSsh1_0d10m = mu_s*(dF_sh1sS_0d10m) + sigma_s*(pdf_sbarS_0d10m-pdf_sh1_0d10m);
E_sh0sh1_0d10m = mu_s*(dF_sh1sh0_0d10m) + sigma_s*(pdf_sh0_0d10m-pdf_sh1_0d10m);
E_sSsh1_10d10m = mu_s*(dF_sh1sS_10d10m) + sigma_s*(pdf_sbarS_10d10m-pdf_sh1_10d10m);
E_sh0sh1_10d10m = mu_s*(dF_sh1sh0_10d10m) + sigma_s*(pdf_sh0_10d10m-pdf_sh1_10d10m);


% =============================================================
% Giving in intervals for no-flyer case
%==============================================================
% recall closed brackets

% For LA RABIDA
if (g_int_lar(2)<=0)
    a_int_lar(2)=aMinMin_lar;
elseif (g_int_lar(2)< gs_lar)
        if (S<=1) 
            a_int_lar(2)=(g_int_lar(2)+Gi_lar)*(1-S_lar); 
        else
            a_int_lar(2)= Gi_lar*(1-S_lar)*exp(-g_int_lar(2));
        end
elseif (g_int_lar(2)== gs_lar)
    a_int_lar(2)=aPlus_lar;
else
    a_int_lar(2)=g_int_lar(2)+Gi_lar;
end

if (g_int_lar(1)<=0)
    a_int_lar(1)=-Inf;
elseif (g_int_lar(1)< gs_lar)
        if S_lar<=1 
            a_int_lar(1)=(g_int_lar(1)+Gi_lar)*(1-S_lar);
        else
            a_int_lar(1)= Gi_lar*(1-S_lar)*exp(-g_int_lar(1));
        end
elseif (g_int_lar(1)== gs_lar)
       a_int_lar(1)=aMin_lar;
else
    a_int_lar(1)=g_int_lar(1)+Gi_lar;
end


if (g_int1_lar(2)<=0)
    a_int1_lar(2)=aMinMin_lar;
elseif (g_int1_lar(2)< gs_lar)
        if (S<=1) 
            a_int1_lar(2)=(g_int1_lar(2)+Gi_lar)*(1-S_lar); 
        else
            a_int1_lar(2)= Gi_lar*(1-S_lar)*exp(-g_int1_lar(2));
        end
elseif (g_int1_lar(2)== gs_lar)
    a_int1_lar(2)=aPlus_lar;
else
    a_int1_lar(2)=g_int1_lar(2)+Gi_lar;
end

if (g_int1_lar(1)<=0)
    a_int1_lar(1)=-Inf;
elseif (g_int1_lar(1)< gs_lar)
        if S_lar<=1 
            a_int1_lar(1)=(g_int1_lar(1)+Gi_lar)*(1-S_lar);
        else
            a_int1_lar(1)= Gi_lar*(1-S_lar)*exp(-g_int1_lar(1));
        end
elseif (g_int1_lar(1)== gs_lar)
       a_int1_lar(1)=aMin_lar;
else
    a_int1_lar(1)=g_int1_lar(1)+Gi_lar;
end


if (g_int2_lar(2)<=0)
    a_int2_lar(2)=aMinMin_lar;
elseif (g_int2_lar(2)< gs_lar)
        if (S<=1) 
            a_int2_lar(2)=(g_int2_lar(2)+Gi_lar)*(1-S_lar); 
        else
            a_int2_lar(2)= Gi_lar*(1-S_lar)*exp(-g_int2_lar(2));
        end
elseif (g_int2_lar(2)== gs_lar)
    a_int2_lar(2)=aPlus_lar;
else
    a_int2_lar(2)=g_int2_lar(2)+Gi_lar;
end

if (g_int2_lar(1)<=0)
    a_int2_lar(1)=-Inf;
elseif (g_int2_lar(1)< gs_lar)
        if S_lar<=1 
            a_int2_lar(1)=(g_int2_lar(1)+Gi_lar)*(1-S_lar);
        else
            a_int2_lar(1)= Gi_lar*(1-S_lar)*exp(-g_int2_lar(1));
        end
elseif (g_int2_lar(1)== gs_lar)
       a_int2_lar(1)=aMin_lar;
else
    a_int2_lar(1)=g_int2_lar(1)+Gi_lar;
end

if a_int_lar(1)<0 , F_a_int_lar1=0; else F_a_int_lar1=expcdf(a_int_lar(1),mu_lar); end
if a_int_lar(2)<0 , F_a_int_lar2=0; else  F_a_int_lar2=expcdf(a_int_lar(2),mu_lar); end
if a_int1_lar(1)<0 , F_a_int1_lar1=0; else  F_a_int1_lar1=expcdf(a_int1_lar(1),mu_lar); end
if a_int1_lar(2)<0 , F_a_int1_lar2=0; else F_a_int1_lar2=expcdf(a_int1_lar(2),mu_lar); end
if a_int2_lar(1)<0 , F_a_int2_lar1=0; else  F_a_int2_lar1=expcdf(a_int2_lar(1),mu_lar); end
if a_int2_lar(2)<0 , F_a_int2_lar2=0; else F_a_int2_lar2=expcdf(a_int2_lar(2),mu_lar); end


% For ECU
if (g_int_ecu(2)<=0)
    a_int_ecu(2)=aMinMin_ecu;
elseif (g_int_ecu(2)< gs_ecu)
        if (S<=1) 
            a_int_ecu(2)=(g_int_ecu(2)+Gi_ecu)*(1-S_ecu); 
        else
            a_int_ecu(2)= Gi_ecu*(1-S_ecu)*exp(-g_int_ecu(2));
        end
elseif (g_int_ecu(2)== gs_ecu)
    a_int_ecu(2)=aPlus_ecu;
else
    a_int_ecu(2)=g_int_ecu(2)+Gi_ecu;
end

if (g_int_ecu(1)<=0)
    a_int_ecu(1)=-Inf;
elseif (g_int_ecu(1)< gs_ecu)
        if S_ecu<=1 
            a_int_ecu(1)=(g_int_ecu(1)+Gi_ecu)*(1-S_ecu);
        else
            a_int_ecu(1)= Gi_ecu*(1-S_ecu)*exp(-g_int_ecu(1));
        end
elseif (g_int_ecu(1)== gs_ecu)
       a_int_ecu(1)=aMin_ecu;
else
    a_int_ecu(1)=g_int_ecu(1)+Gi_ecu;
end


if (g_int1_ecu(2)<=0)
    a_int1_ecu(2)=aMinMin_ecu;
elseif (g_int1_ecu(2)< gs_ecu)
        if (S<=1) 
            a_int1_ecu(2)=(g_int1_ecu(2)+Gi_ecu)*(1-S_ecu); 
        else
            a_int1_ecu(2)= Gi_ecu*(1-S_ecu)*exp(-g_int1_ecu(2));
        end
elseif (g_int1_ecu(2)== gs_ecu)
    a_int1_ecu(2)=aPlus_ecu;
else
    a_int1_ecu(2)=g_int1_ecu(2)+Gi_ecu;
end

if (g_int1_ecu(1)<=0)
    a_int1_ecu(1)=-Inf;
elseif (g_int1_ecu(1)< gs_ecu)
        if S_ecu<=1 
            a_int1_ecu(1)=(g_int1_ecu(1)+Gi_ecu)*(1-S_ecu);
        else
            a_int1_ecu(1)= Gi_ecu*(1-S_ecu)*exp(-g_int1_ecu(1));
        end
elseif (g_int1_ecu(1)== gs_ecu)
       a_int1_ecu(1)=aMin_ecu;
else
    a_int1_ecu(1)=g_int1_ecu(1)+Gi_ecu;
end

if (g_int2_ecu(2)<=0)
    a_int2_ecu(2)=aMinMin_ecu;
elseif (g_int2_ecu(2)< gs_ecu)
        if (S<=1) 
            a_int2_ecu(2)=(g_int2_ecu(2)+Gi_ecu)*(1-S_ecu); 
        else
            a_int2_ecu(2)= Gi_ecu*(1-S_ecu)*exp(-g_int2_ecu(2));
        end
elseif (g_int2_ecu(2)== gs_ecu)
    a_int2_ecu(2)=aPlus_ecu;
else
    a_int2_ecu(2)=g_int2_ecu(2)+Gi_ecu;
end

if (g_int2_ecu(1)<=0)
    a_int2_ecu(1)=-Inf;
elseif (g_int2_ecu(1)< gs_ecu)
        if S_ecu<=1 
            a_int2_ecu(1)=(g_int2_ecu(1)+Gi_ecu)*(1-S_ecu);
        else
            a_int2_ecu(1)= Gi_ecu*(1-S_ecu)*exp(-g_int2_ecu(1));
        end
elseif (g_int2_ecu(1)== gs_ecu)
       a_int2_ecu(1)=aMin_ecu;
else
    a_int2_ecu(1)=g_int2_ecu(1)+Gi_ecu;
end


if a_int_ecu(1)<0 , F_a_int_ecu1=0; else F_a_int_ecu1=expcdf(a_int_ecu(1),mu_ecu); end
if a_int_ecu(2)<0 , F_a_int_ecu2=0; else  F_a_int_ecu2=expcdf(a_int_ecu(2),mu_ecu); end
if a_int1_ecu(1)<0 , F_a_int1_ecu1=0; else  F_a_int1_ecu1=expcdf(a_int1_ecu(1),mu_ecu); end
if a_int1_ecu(2)<0 , F_a_int1_ecu2=0; else F_a_int1_ecu2=expcdf(a_int1_ecu(2),mu_ecu); end
if a_int2_ecu(1)<0 , F_a_int2_ecu1=0; else  F_a_int2_ecu1=expcdf(a_int2_ecu(1),mu_ecu); end
if a_int2_ecu(2)<0 , F_a_int2_ecu2=0; else F_a_int2_ecu2=expcdf(a_int2_ecu(2),mu_ecu); end


% ==============================================================
% Calculate PH_NF
% ==============================================================

PH_NF_lar = h_0; % PH_NFlar
PH_NF_ecu = h_0; % PH_NFecu
PH_NF0d10m = h_0; % PH_NF0d10m


% ==============================================================
% Calculate PG_NF
% ==============================================================

PG_NF_lar = h_0*(1-F_aMinMin_lar); % PG_NFlar
PG_NF_ecu = h_0*(1-F_aMinMin_ecu);  % PG_NFecu


%==============================================================
% Calculate PH_flyer
% =============================================================

% For lar

hstar0_lar = hstar(0,hParams_lar);
intHF_lar = quad( @(X) hstarQuadExp(X, hParams_lar), amin_lar, amax_lar);
PH_F_lar = (1-r)*h_0 + r*F_0_lar*hstar0_lar + r*intHF_lar;


% For ecu
hstar0_ecu = hstar(0,hParams_ecu);
intHF_ecu = quad( @(X) hstarQuadExp(X, hParams_ecu), amin_ecu, amax_ecu);
PH_F_ecu = (1-r)*h_0 + r*F_0_ecu*hstar0_ecu + r*intHF_ecu;


% ==============================================================
% Calculate PG_flyer
% ==============================================================
% Recall aL can either be = -Inf or must be > aMinMin ; Can't be in between

% For lar
intGF_lar = quad( @(X) hstarQuadExp(X, hParams_lar), min(amax_lar,max(aMinMin_lar,amin_lar)), amax_lar);
PG_F_lar = r*F_0_lar*hstar0_lar*(aMinMin_lar<0)+ r*intGF_lar + h_0*(1-r)*(1-F_aMinMin_lar); 

% For ecu
intGF_ecu = quad( @(X) hstarQuadExp(X, hParams_ecu), min(amax_ecu,max(aMinMin_ecu,amin_ecu)), amax_ecu);
PG_F_ecu = r*F_0_ecu*hstar0_ecu*(aMinMin_ecu<0)+ r*intGF_ecu + h_0*(1-r)*(1-F_aMinMin_ecu); 


% ==============================================================
% Calculate POO
% ==============================================================

POO_OO_lar =  r*h_0*F_aOO_lar; % P_OO_lar
POO_OO_ecu =  r*h_0*F_aOO_ecu; % P_OO_ecu


%===============================================================
% Calculate PH_OO
% ==============================================================

% For lar
hstar0_OO_lar = hstarOO(0,hParams_lar);
if S_lar==0
   intHOO_lar =intHF_lar;
else
    intHOO_lar = quad( @(X) hstarQuadExp(X, hParams_lar), min(amax_lar,max(aOO_lar,amin_lar)), amax_lar);
end
PH_OO_lar = (1-r)*h_0 + r*F_0_lar*hstar0_OO_lar + r*intHOO_lar;


% For ecu
hstar0_OO_ecu = hstarOO(0,hParams_ecu);
if S_ecu==0
   intHOO_ecu =intHF_ecu;
else
    intHOO_ecu = quad( @(X) hstarQuadExp(X, hParams_ecu), min(amax_ecu,max(aOO_ecu,amin_ecu)), amax_ecu);
end
PH_OO_ecu = (1-r)*h_0 + r*F_0_ecu*hstar0_OO_ecu + r*intHOO_ecu;


% ==============================================================
% Calculate PG_OO
% ==============================================================
% Recall if not opting out, surely giving at door

PG_OO_lar = PH_OO_lar - (1-r)*h_0 + h_0*(1-r)*(1-F_aMinMin_lar); 
PG_OO_ecu = PH_OO_ecu - (1-r)*h_0 + h_0*(1-r)*(1-F_aMinMin_ecu); 


% ==============================================================
% Calculate PG_NF_int
% ==============================================================

PG_NF_0gs_lar = h_0*(F_aMin_lar - F_aMinMin_lar); % Prob(0<G_NF_lar<gs_lar)
PG_NF_0gs_ecu = h_0*(F_aMin_ecu - F_aMinMin_ecu); % Prob(0<G_NF_ecu<gs_ecu)

PG_NF_gs_lar =  h_0*(F_aPlus_lar - F_aMin_lar); % Prob(G_NF_lar=gs_lar)
PG_NF_gs_ecu =  h_0*(F_aPlus_ecu - F_aMin_ecu); % Prob(G_NF_ecu=gs_ecu)

PG_NF_int_lar = h_0*(F_a_int_lar2 - F_a_int_lar1); %  P( g_int_1 <= G* <= g_int_2) 
PG_NF_int_ecu= h_0*(F_a_int_ecu2 - F_a_int_ecu1); %  P( g_int_1 <= G* <= g_int_2) 
PG_NF_int1_lar = h_0*(F_a_int1_lar2 - F_a_int1_lar1); %  P( g_int1_1 <= G* <= g_int1_2) 
PG_NF_int1_ecu = h_0*(F_a_int1_ecu2 - F_a_int1_ecu1); %  P( g_int1_1 <= G* <= g_int1_2) 
PG_NF_int2_lar = h_0*(F_a_int2_lar2 - F_a_int2_lar1); %  P( g_int2_1 <= G* <= g_int2_2) 
PG_NF_int2_ecu = h_0*(F_a_int2_ecu2 - F_a_int2_ecu1); %  P( g_int2_1 <= G* <= g_int2_2) 

% ==============================================================
% Calculate PG_F_int
% ==============================================================

% Want to calculate giving in interval between a_int_lar(1) and
% a_int_lar(2). This will be the integral of h* over this interval.

% For lar
HF_aint_lar = quad( @(X) hstarQuadExp(X, hParams_lar), max(0,a_int_lar(1)), max(0,a_int_lar(2)));
HF_aint1_lar = quad( @(X) hstarQuadExp(X, hParams_lar), max(0,a_int1_lar(1)), max(0,a_int1_lar(2)));
HF_aint2_lar = quadgk( @(X) hstarQuadExp(X, hParams_lar), max(0,a_int2_lar(1)), max(0,a_int2_lar(2)));

PG_F_int_lar = (1-r)*h_0*(F_a_int_lar2 - F_a_int_lar1) + r*F_0_lar*hstar0_lar*( a_int_lar(1)<=0 && a_int_lar(2)>0) + r*HF_aint_lar;
PG_F_int1_lar = (1-r)*h_0*(F_a_int1_lar2 - F_a_int1_lar1) + r*F_0_lar*hstar0_lar*( a_int1_lar(1)<=0 && a_int1_lar(2)>0) + r*HF_aint1_lar;
PG_F_int2_lar = (1-r)*h_0*(F_a_int2_lar2 - F_a_int2_lar1) + r*F_0_lar*hstar0_lar*( a_int2_lar(1)<=0 && a_int2_lar(2)>0) + r*HF_aint2_lar;

PG_F_0gs_lar = (1-r)*h_0*(F_aMin_lar - F_aMinMin_lar) + r*F_0_lar*hstar0_lar*(aMinMin_lar<0 && aMin_lar>0) + r*quad(@(X) hstarQuadExp(X, hParams_lar), max(0,aMinMin_lar) , max(0,aMin_lar)); % Prob(0<G_F_lar<gs_lar)
PG_F_gs_lar =  (1-r)*h_0*(F_aPlus_lar - F_aMin_lar)+ r*F_0_lar*hstar0_lar*(aMin_lar<=0 && aPlus_lar>=0) + r*quad(@(X) hstarQuadExp(X, hParams_lar), max(0,aMin_lar) , max(0,aPlus_lar)); % Prob(G_F_lar=gs_lar)


% For ecu
HF_aint_ecu = quad( @(X) hstarQuadExp(X, hParams_ecu), max(0,a_int_ecu(1)), max(0,a_int_ecu(2)));
HF_aint1_ecu = quad( @(X) hstarQuadExp(X, hParams_ecu), max(0,a_int1_ecu(1)), max(0,a_int1_ecu(2)));
HF_aint2_ecu = quadgk( @(X) hstarQuadExp(X, hParams_ecu), max(0,a_int2_ecu(1)), max(0,a_int2_ecu(2)));

PG_F_int_ecu = (1-r)*h_0*(F_a_int_ecu2 - F_a_int_ecu1) + r*F_0_ecu*hstar0_ecu*( a_int_ecu(1)<=0 && a_int_ecu(2)>0) + r*HF_aint_ecu;
PG_F_int1_ecu = (1-r)*h_0*(F_a_int1_ecu2 - F_a_int1_ecu1) + r*F_0_ecu*hstar0_ecu*( a_int1_ecu(1)<=0 && a_int1_ecu(2)>0) + r*HF_aint1_ecu;
PG_F_int2_ecu = (1-r)*h_0*(F_a_int2_ecu2 - F_a_int2_ecu1) + r*F_0_ecu*hstar0_ecu*( a_int2_ecu(1)<=0 && a_int2_ecu(2)>0) + r*HF_aint2_ecu;

PG_F_0gs_ecu = (1-r)*h_0*(F_aMin_ecu - F_aMinMin_ecu) + r*F_0_ecu*hstar0_ecu*(aMinMin_ecu<0 && aMin_ecu>0) + r*quad(@(X) hstarQuadExp(X, hParams_ecu), max(0,aMinMin_ecu) , max(0,aMin_ecu)); % Prob(0<G_F_ecu<gs_ecu)
PG_F_gs_ecu =  (1-r)*h_0*(F_aPlus_ecu - F_aMin_ecu)+ r*F_0_ecu*hstar0_ecu*(aMin_ecu<=0 && aPlus_ecu>=0) + r*quad(@(X) hstarQuadExp(X, hParams_ecu), max(0,aMin_ecu) , max(0,aPlus_ecu)); % Prob(G_F_ecu=gs_ecu)


% ==============================================================
% Calculate PG_OO_int
% ==============================================================

% Want to calculate giving in interval between a_int_lar(1) and
% a_int_lar(2). This will be the integral of h* over this interval. But now
% we also need to keep in mind aOO

% For lar
HOO_aint_lar =  quad( @(X) hstarQuadExp(X, hParams_lar), max(0,min( max(a_int_lar(1),aOO_lar), a_int_lar(2))) , max(0,a_int_lar(2)) );  
HOO_aint1_lar =  quad( @(X) hstarQuadExp(X, hParams_lar), max(0,min( max(a_int1_lar(1),aOO_lar), a_int1_lar(2))) , max(0,a_int1_lar(2)) ); 
HOO_aint2_lar =  quadgk( @(X) hstarQuadExp(X, hParams_lar), max(0,min( max(a_int2_lar(1),aOO_lar), a_int2_lar(2))) , max(0,a_int2_lar(2)) ); 
PG_OO_int_lar = (1-r)*h_0*(F_a_int_lar2 - F_a_int_lar1) + r*F_0_lar*hstar0_lar*( aOO_lar<0 && a_int_lar(1)<=0 && a_int_lar(2)>0) +  r*HOO_aint_lar;
PG_OO_int1_lar = (1-r)*h_0*(F_a_int1_lar2 - F_a_int1_lar1) + r*F_0_lar*hstar0_lar*( aOO_lar<0 && a_int1_lar(1)<=0 && a_int1_lar(2)>0) +  r*HOO_aint1_lar;
PG_OO_int2_lar = (1-r)*h_0*(F_a_int2_lar2 - F_a_int2_lar1) + r*F_0_lar*hstar0_lar*( aOO_lar<0 && a_int2_lar(1)<=0 && a_int2_lar(2)>0) +  r*HOO_aint2_lar;

PG_OO_0gs_lar = (1-r)*h_0*(F_aMin_lar - F_aMinMin_lar) + r*F_0_lar*hstar0_lar*( aOO_lar<0 && aMinMin_lar<0 && aMin_lar>0) +  r* quad( @(X) hstarQuadExp(X, hParams_lar), max(0,min( max(aMinMin_lar,aOO_lar), aMin_lar)) , max(0,aMin_lar)); % Prob(0<G_OO_lar<gs_lar)
PG_OO_gs_lar =  (1-r)*h_0*(F_aPlus_lar - F_aMin_lar)+ r*F_0_lar*hstar0_lar*( aOO_lar<0 && aMin_lar<=0 && aPlus_lar>=0) + r*quad( @(X) hstarQuadExp(X, hParams_lar),  max(0,min( max(aMin_lar,aOO_lar), aPlus_lar)) ,  max(0,aPlus_lar)) ; % Prob(G_OO_lar=gs_lar)


% For ecu
HOO_aint_ecu =  quad( @(X) hstarQuadExp(X, hParams_ecu), max(0,min( max(a_int_ecu(1),aOO_ecu), a_int_ecu(2))) , max(0,a_int_ecu(2)) );  
HOO_aint1_ecu =  quad( @(X) hstarQuadExp(X, hParams_ecu), max(0,min( max(a_int1_ecu(1),aOO_ecu), a_int1_ecu(2))) , max(0,a_int1_ecu(2)) ); 
HOO_aint2_ecu =  quadgk( @(X) hstarQuadExp(X, hParams_ecu), max(0,min( max(a_int2_ecu(1),aOO_ecu), a_int2_ecu(2))) , max(0,a_int2_ecu(2)) ); 
PG_OO_int_ecu = (1-r)*h_0*(F_a_int_ecu2 - F_a_int_ecu1) + r*F_0_ecu*hstar0_ecu*( aOO_ecu<0 && a_int_ecu(1)<=0 && a_int_ecu(2)>0) +  r*HOO_aint_ecu;
PG_OO_int1_ecu = (1-r)*h_0*(F_a_int1_ecu2 - F_a_int1_ecu1) + r*F_0_ecu*hstar0_ecu*( aOO_ecu<0 && a_int1_ecu(1)<=0 && a_int1_ecu(2)>0) +  r*HOO_aint1_ecu;
PG_OO_int2_ecu = (1-r)*h_0*(F_a_int2_ecu2 - F_a_int2_ecu1) + r*F_0_ecu*hstar0_ecu*( aOO_ecu<0 && a_int2_ecu(1)<=0 && a_int2_ecu(2)>0) +  r*HOO_aint2_ecu;

PG_OO_0gs_ecu = (1-r)*h_0*(F_aMin_ecu - F_aMinMin_ecu) + r*F_0_ecu*hstar0_ecu*( aOO_ecu<0 && aMinMin_ecu<0 && aMin_ecu>0) +  r* quad( @(X) hstarQuadExp(X, hParams_ecu), max(0,min( max(aMinMin_ecu,aOO_ecu), aMin_ecu)) , max(0,aMin_ecu)); % Prob(0<G_OO_ecu<gs_ecu)
PG_OO_gs_ecu =  (1-r)*h_0*(F_aPlus_ecu - F_aMin_ecu)+ r*F_0_ecu*hstar0_ecu*( aOO_ecu<0 && aMin_ecu<=0 && aPlus_ecu>=0) + r*quad( @(X) hstarQuadExp(X, hParams_ecu),  max(0,min( max(aMin_ecu,aOO_ecu), aPlus_ecu)) ,  max(0,aPlus_ecu)) ; % Prob(G_OO_ecu=gs_ecu)


% ==============================================================
% Calculate PH_SV
% ==============================================================

if (h_0-eta*S_svy>0)   % PH_F0d5m
    PH_F0d5m = (1-r)*h_0 + r*(h_0-eta*S_svy)*F_sbarS_0d5m + r*(h_0+eta*(m_0-c5))*dF_sh1sS_0d5m +r*eta*E_sSsh1_0d5m+r*(1-F_sh1_0d5m);
else
    PH_F0d5m = (1-r)*h_0 +  r*(h_0+eta*(m_0-c5))*dF_sh1sh0_0d5m +r*eta*E_sh0sh1_0d5m+r*(1-F_sh1_0d5m);
end

if (h_0-eta*S_svy>0)   % PH_F0d10m
    PH_F0d10m = (1-r)*h_0 + r*(h_0-eta*S_svy)*F_sbarS_0d10m + r*(h_0+eta*(m_0-c10))*dF_sh1sS_0d10m +r*eta*E_sSsh1_0d10m+r*(1-F_sh1_0d10m);
else
    PH_F0d10m = (1-r)*h_0 +  r*(h_0+eta*(m_0-c10))*dF_sh1sh0_0d10m +r*eta*E_sh0sh1_0d10m+r*(1-F_sh1_0d10m);
end

if (h_0-eta*S_svy>0)   % PH_F10d10m
    PH_F10d10m = (1-r)*h_0 + r*(h_0-eta*S_svy)*F_sbarS_10d10m + r*(h_0+eta*(m_10-c10))*dF_sh1sS_10d10m +r*eta*E_sSsh1_10d10m+r*(1-F_sh1_10d10m);
else
    PH_F10d10m = (1-r)*h_0 +  r*(h_0+eta*(m_10-c10))*dF_sh1sh0_10d10m +r*eta*E_sh0sh1_10d10m+r*(1-F_sh1_10d10m);
end


% ==============================================================
% Calculate PSV
% ==============================================================

PSV_NF0d10m = h_0*(1-F_sbarS_0d10m); % PSV_NF0d10m

if (h_0-eta*S_svy>0)   % PSV_F0d5m
    PSV_F0d5m = (1-r)*h_0*(1-F_sbarS_0d5m) + r*(h_0+eta*(m_0-c5))*dF_sh1sS_0d5m +r*eta*E_sSsh1_0d5m+r*(1-F_sh1_0d5m);
else
    PSV_F0d5m = (1-r)*h_0*(1-F_sbarS_0d5m) + r*(h_0+eta*(m_0-c5))*dF_sh1sh0_0d5m +r*eta*E_sh0sh1_0d5m+r*(1-F_sh1_0d5m);
end

if (h_0-eta*S_svy>0)   % PSV_F0d10m
    PSV_F0d10m = (1-r)*h_0*(1-F_sbarS_0d10m) + r*(h_0+eta*(m_0-c10))*dF_sh1sS_0d10m +r*eta*E_sSsh1_0d10m+r*(1-F_sh1_0d10m);
else
    PSV_F0d10m = (1-r)*h_0*(1-F_sbarS_0d10m) + r*(h_0+eta*(m_0-c10))*dF_sh1sh0_0d10m +r*eta*E_sh0sh1_0d10m+r*(1-F_sh1_0d10m);
end

if (h_0-eta*S_svy>0)   % PSV_F10d10m
    PSV_F10d10m = (1-r)*h_0*(1-F_sbarS_10d10m) + r*(h_0+eta*(m_10-c10))*dF_sh1sS_10d10m +r*eta*E_sSsh1_10d10m+r*(1-F_sh1_10d10m);
else
    PSV_F10d10m = (1-r)*h_0*(1-F_sbarS_10d10m) + r*(h_0+eta*(m_10-c10))*dF_sh1sh0_10d10m +r*eta*E_sh0sh1_10d10m+r*(1-F_sh1_10d10m);
end


% ==============================================================
% New Survey Stuff
% ==============================================================

newSurveyMoms=simulator_2009Moments([h_2009 r eta mu_s sigma_s S_svy timeval])';


% ============================================
% Form Moments
% ============================================

m1	=	PH_NF_lar	;
m2	=	PH_NF_ecu	;
m3	=	PH_F_lar	;
m4	=	PH_F_ecu	;
m5	=	PH_OO_lar	;
m6	=	PH_OO_ecu	;
m7	=	PH_NF0d10m	;
m8	=	PH_F0d5m	;
m9	=	PH_F0d10m	;
m10	=	PH_F10d10m	;
m11	=	PG_NF_lar	;
m12	=	PG_NF_ecu	;
m13	=	PG_F_lar	;
m14	=	PG_F_ecu	;
m15	=	PG_OO_lar	;
m16	=	PG_OO_ecu	;
m17	=	PSV_NF0d10m	;
m18	=	PSV_F0d5m	;
m19	=	PSV_F0d10m	;
m20	=	PSV_F10d10m	;
m21	=	POO_OO_lar	;
m22	=	POO_OO_ecu	;
% -----------------------------
m51	=	PG_NF_0gs_ecu 	;
m52	=	PG_NF_0gs_lar 	;
m53	=	PG_OO_0gs_ecu	;
m54	=	PG_OO_0gs_lar 	;
m55	=	PG_F_0gs_ecu 	;
m56	=	PG_F_0gs_lar 	;
m57	=	PG_NF_gs_ecu 	;
m58	=	PG_NF_gs_lar 	;
m59	=	PG_OO_gs_ecu	;
m60	=	PG_OO_gs_lar 	;
m61	=	PG_F_gs_ecu 	;
m62	=	PG_F_gs_lar 	;
m63	=	PG_NF_int_ecu 	;
m64	=	PG_NF_int_lar 	;
m65	=	PG_OO_int_ecu	;
m66	=	PG_OO_int_lar 	;
m67	=	PG_F_int_ecu 	;
m68	=	PG_F_int_lar 	;
m69	=	PG_NF_int1_ecu 	;
m70	=	PG_NF_int1_lar 	;
m71	=	PG_OO_int1_ecu	;
m72	=	PG_OO_int1_lar 	;
m73	=	PG_F_int1_ecu 	;
m74	=	PG_F_int1_lar 	;
m75	=	PG_NF_int2_ecu 	;
m76	=	PG_NF_int2_lar 	;
m77	=	PG_OO_int2_ecu	;
m78	=	PG_OO_int2_lar 	;
m79	=	PG_F_int2_ecu 	;
m80	=	PG_F_int2_lar 	;


simMoments = [m1 m2 m3 m4 m5 m6 m7 m8 m9 m10 m11 m12 m13 m14 m15 m16 m17 m18 m19 m20 m21 m22 newSurveyMoms m51 m52 m53 m54 m55 m56 m57 m58 m59 m60 m61 m62 m63 m64 m65 m66 m67 m68 m69 m70 m71 m72 m73 m74 m75 m76 m77 m78 m79 m80]';

end
