%This simulates the model under the assumption that a is distributed
%according to an exponential distribution with an additional mass at a=0.
%See simulator_benchmark.m for more detailed comments.

function [simMoments] = simulator_ExpAtom(parameters)
warning off MATLAB:quad:MinStepSize
warning off MATLAB:quadgk:MaxIntervalCountReached

%Size of masses at a=0
Pzero_lar = parameters(14);
Pzero_ecu = parameters(15);

%check parameters
if sum(parameters([1:5 7:15])<0)>0
    simMoments=NaN(70,1);
    return;
end

if sum(parameters([1:2 13:15])>1)>0
    simMoments=NaN(70,1);
    return;
end

%moments for two populations (a=0 and a>0)
momsExp = simulator_Exp(parameters);
momsAlt0 = simulator_Exp_ZeroAltruism(parameters);

% charityMoments=[1:6 11:16 21:22 51:80];
lar_Moments = [1:2:5 11:2:15 21 42:2:70];
ecu_Moments = [2:2:6 12:2:16 22 41:2:69];

simMoments = momsExp;
simMoments(lar_Moments) = (1-Pzero_lar)*momsExp(lar_Moments) + Pzero_lar*momsAlt0(lar_Moments);
simMoments(ecu_Moments) = (1-Pzero_ecu)*momsExp(ecu_Moments) + Pzero_ecu*momsAlt0(ecu_Moments);

end



