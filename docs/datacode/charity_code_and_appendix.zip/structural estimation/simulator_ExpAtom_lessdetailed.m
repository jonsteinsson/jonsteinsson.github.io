%See simulator_ExpAtom.m and simulator_benchmark.m for more comments. This does the same in
%the ExpAtom model with a smaller set of moments that provide less detailed information
%about the distribution of giving.

function [simMoments] = simulator_ExpAtom_lessdetailed(parameters)
warning off MATLAB:quad:MinStepSize
warning off MATLAB:quadgk:MaxIntervalCountReached

Pzero_lar = parameters(14);
Pzero_ecu = parameters(15);

if sum(parameters([1:5 7:15])<0)>0
    simMoments=NaN(64,1);
    return;
end

if sum(parameters([1:2 13:15])>1)>0
    simMoments=NaN(64,1);
    return;
end

momsExp = simulator_Exp_lessdetailed(parameters);
momsAlt0 = simulator_Exp_ZeroAltruism_lessdetailed(parameters);

lar_Moments = [1:2:5 11:2:15 21 42:2:64];
ecu_Moments = [2:2:6 12:2:16 22 41:2:63];

simMoments = momsExp;
simMoments(lar_Moments) = (1-Pzero_lar)*momsExp(lar_Moments) + Pzero_lar*momsAlt0(lar_Moments);
simMoments(ecu_Moments) = (1-Pzero_ecu)*momsExp(ecu_Moments) + Pzero_ecu*momsAlt0(ecu_Moments);

end



