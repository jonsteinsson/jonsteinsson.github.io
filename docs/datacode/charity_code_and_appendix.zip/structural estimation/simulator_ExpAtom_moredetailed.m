%See simulator_ExpAtom and simulator_benchmark.m for more comments.
%Does the same in the ExpAtom model with a larger set of moments describing
%more of the distribution of giving.


function [simMoments] = simulator_ExpAtom_moredetailed(parameters)
warning off MATLAB:quad:MinStepSize
warning off MATLAB:quadgk:MaxIntervalCountReached

Pzero_lar = parameters(14);
Pzero_ecu = parameters(15);

if sum(parameters([1:5 7:15])<0)>0
    simMoments=NaN(76,1);
    return;
end

if sum(parameters([1:2 13:15])>1)>0
    simMoments=NaN(76,1);
    return;
end

momsExp = simulator_Exp_moredetailed(parameters);
momsAlt0 = simulator_Exp_ZeroAltruism_moredetailed(parameters);

% charityMoments=[1:6 11:16 21:22 41:76];
lar_Moments = [1:2:5 11:2:15 21 42:2:76];
ecu_Moments = [2:2:6 12:2:16 22 41:2:75];

simMoments = momsExp;
simMoments(lar_Moments) = (1-Pzero_lar)*momsExp(lar_Moments) + Pzero_lar*momsAlt0(lar_Moments);
simMoments(ecu_Moments) = (1-Pzero_ecu)*momsExp(ecu_Moments) + Pzero_ecu*momsAlt0(ecu_Moments);

end



