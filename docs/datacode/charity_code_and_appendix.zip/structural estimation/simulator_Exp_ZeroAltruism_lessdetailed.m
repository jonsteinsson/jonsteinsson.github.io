%This simulates moments in the ExpAtom model for the population with a=0, generating
%a smaller set of moments that provides less detailed information about the distribution of giving.
%See simulator_ExpAtom.m and simulator_benchmark.m for more detailed comments.


function [simMoments] = simulator_Exp_ZeroAltruism_lessdetailed(parameters)
% =================================================================
% Set Parameters
% ================================================================

infinity=100000;
g_int_lar = [10.01 20.0]; % below, we will calculate Prob(Giving_lar in [g_int_lar(1) g_int_lar(2)]  ), note closed brackets
a_int_lar = [ -Inf Inf];
g_int_ecu = [10.01 20.0]; % below, we will calculate Prob(Giving_ecu in [g_int_ecu(1) g_int_ecu(2)]  ), note closed brackets
a_int_ecu = [ -Inf Inf];
g_int1_lar = [20.01 50.0]; % below, we will calculate Prob(Giving_lar in [g_int1_lar(1) g_int1_lar(2)]  ), note closed brackets
a_int1_lar = [ -Inf Inf];
g_int1_ecu = [20.01 50.0]; % below, we will calculate Prob(Giving_ecu in [g_int1_ecu(1) g_int1_ecu(2)]  ), note closed brackets
a_int1_ecu = [ -Inf Inf];
g_int2_lar = [50.01 Inf]; % below, we will calculate Prob(Giving_lar in [g_int2_lar(1) g_int2_lar(2)]  ), note closed brackets
a_int2_lar = [ -Inf Inf];
g_int2_ecu = [50.01 Inf]; % below, we will calculate Prob(Giving_ecu in [g_int2_ecu(1) g_int2_ecu(2)]  ), note closed brackets
a_int2_ecu = [ -Inf Inf];
epsilon=1e-4;


% ================================================================

h_0=parameters(1);
h_2009=parameters(13);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_s=parameters(7);
S_lar=parameters(8);
S_ecu=parameters(9);
S_svy=parameters(10);
timeval=parameters(11);
Gi_lar=parameters(12);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;

ssvy = -timeval*10/60;
a_lar = 0;
a_ecu = 0;

% =====================================================================
% Critical Values for Survey
% =====================================================================


% Values of s at which you say yes if asked
sbarS_0d5m = c5-m_0-S_svy;
sbarS_0d10m = c10-m_0-S_svy;
sbarS_10d10m = c10-m_10-S_svy;


% =====================================================================
% Critical Values for Charities
% =====================================================================

% For lar
if (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
    if (a0_lar < aMin_lar || a0_lar > aPlus_lar)
        [a0_lar fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_lar*(1-S_lar))) - a0 + Gi_lar*(1-S_lar) - S_lar*gs_lar,[aMinMin_lar-epsilon aMin_lar+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end
    end
else
    aMinMin_lar = -0.1;
    aMin_lar= -0.0001;
    aPlus_lar =  Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
end
if (S_lar==0) aOO_lar=-Inf; else aOO_lar=a0_lar; end

H_aMinMin_lar = h_0 - eta*S_lar*gs_lar;
H_aMin_lar = h_0 + eta*((1-S_lar)*(Gi_lar+gs_lar)*log(1+gs_lar/Gi_lar) - gs_lar );
H_aPlus_lar = h_0 + eta*((Gi_lar+gs_lar)*log(1+gs_lar/Gi_lar) - gs_lar );

hParams_lar=[h_0 eta S_lar gs_lar Gi_lar aMinMin_lar aMin_lar aPlus_lar aOO_lar mu_lar 0];

% [aMinMin_lar; aMin_lar ; aPlus_lar ; aOO_lar]

% For ecu
if (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
    if (a0_ecu < aMin_ecu || a0_ecu > aPlus_ecu)
        [a0_ecu fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_ecu*(1-S_ecu))) - a0 + Gi_ecu*(1-S_ecu) - S_ecu*gs_ecu,[aMinMin_ecu-epsilon aMin_ecu+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end        
    end
else
    aMinMin_ecu = -0.1;
    aMin_ecu=-0.0001;
    aPlus_ecu =  Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
end
if (S_ecu==0) aOO_ecu=-Inf; else aOO_ecu=a0_ecu; end

H_aMinMin_ecu = h_0 - eta*S_ecu*gs_ecu;
H_aMin_ecu = h_0 + eta*((1-S_ecu)*(Gi_ecu+gs_ecu)*log(1+gs_ecu/Gi_ecu) - gs_ecu );
H_aPlus_ecu = h_0 + eta*((Gi_ecu+gs_ecu)*log(1+gs_ecu/Gi_ecu) - gs_ecu );

hParams_ecu=[h_0 eta S_ecu gs_ecu Gi_ecu aMinMin_ecu aMin_ecu aPlus_ecu aOO_ecu mu_ecu 0];



% ============================================
% Charity Moments
% ============================================



PH_NF_lar = h_0;
PH_F_lar = (1-r)*h_0 + r*hstar(a_lar,hParams_lar);
PH_OO_lar = (1-r)*h_0 + r*hstarOO(a_lar,hParams_lar);
if  a_lar >= aMinMin_lar
    PG_NF_lar = PH_NF_lar; 
    PG_F_lar = PH_F_lar;
    PG_OO_lar = PH_OO_lar;
else
    PG_NF_lar = 0;
    PG_F_lar = 0;
    PG_OO_lar = 0;
end
POO_OO_lar =  r*h_0*(a_lar<aOO_lar);

PG_NF_0gs_lar = 0;
PG_NF_gs_lar = (S_lar>=1)*PH_NF_lar;
PG_NF_int_lar = 0;
PG_NF_int1_lar = 0;
PG_NF_int2_lar = 0;
PG_F_0gs_lar = 0;
PG_F_gs_lar = (S_lar>=1)*PH_F_lar;
PG_F_int_lar = 0;
PG_F_int1_lar = 0;
PG_F_int2_lar = 0;
PG_OO_0gs_lar = 0;
PG_OO_gs_lar = (S_lar>=1)*PH_OO_lar;
PG_OO_int_lar = 0;
PG_OO_int1_lar = 0;
PG_OO_int2_lar = 0;


PH_NF_ecu = h_0;
PH_F_ecu = (1-r)*h_0 + r*hstar(a_ecu,hParams_ecu);
PH_OO_ecu = (1-r)*h_0 + r*hstarOO(a_ecu,hParams_ecu);
if  a_ecu >= aMinMin_ecu
    PG_NF_ecu = PH_NF_ecu; 
    PG_F_ecu = PH_F_ecu;
    PG_OO_ecu = PH_OO_ecu;
else
    PG_NF_ecu = 0;
    PG_F_ecu = 0;
    PG_OO_ecu = 0;
end
POO_OO_ecu =  r*h_0*(a_ecu<aOO_ecu);

PG_NF_0gs_ecu = 0;
PG_NF_gs_ecu = (S_ecu>=1)*PH_NF_ecu;
PG_NF_int_ecu = 0;
PG_NF_int1_ecu = 0;
PG_NF_int2_ecu = 0;
PG_F_0gs_ecu = 0;
PG_F_gs_ecu = (S_ecu>=1)*PH_F_ecu;
PG_F_int_ecu = 0;
PG_F_int1_ecu = 0;
PG_F_int2_ecu = 0;
PG_OO_0gs_ecu = 0;
PG_OO_gs_ecu = (S_ecu>=1)*PH_OO_ecu;
PG_OO_int_ecu = 0;
PG_OO_int1_ecu = 0;
PG_OO_int2_ecu = 0;


% ============================================
% Survey Moments
% ============================================


PH_NF0d10m = h_0;
PH_F0d5m = hstarSvy(ssvy, [h_0 eta S_svy c5 m_0 sbarS_0d5m]);
PH_F0d10m = hstarSvy(ssvy, [h_0 eta S_svy c10 m_0 sbarS_0d10m]);
PH_F10d10m = hstarSvy(ssvy, [h_0 eta S_svy c10 m_10 sbarS_10d10m]);
if  ssvy >= sbarS_0d10m  PSV_NF0d10m = PH_NF0d10m; else PSV_NF0d10m = 0; end
if  ssvy >= sbarS_0d5m  PSV_F0d5m = PH_F0d5m; else PSV_F0d5m = 0; end
if  ssvy >= sbarS_0d10m  PSV_F0d10m = PH_F0d10m; else PSV_F0d10m = 0; end
if  ssvy >= sbarS_10d10m  PSV_F10d10m = PH_F10d10m; else PSV_F10d10m = 0; end

newSurveyMoms=simulator_2009Moments_ZeroAltruism([h_2009 r eta mu_s sigma_s S_svy timeval])';



% ============================================
% Form Moments
% ============================================


m1	=	PH_NF_lar	;
m2	=	PH_NF_ecu	;
m3	=	PH_F_lar	;
m4	=	PH_F_ecu	;
m5	=	PH_OO_lar	;
m6	=	PH_OO_ecu	;
m7	=	PH_NF0d10m	;
m8	=	PH_F0d5m	;
m9	=	PH_F0d10m	;
m10	=	PH_F10d10m	;
m11	=	PG_NF_lar	;
m12	=	PG_NF_ecu	;
m13	=	PG_F_lar	;
m14	=	PG_F_ecu	;
m15	=	PG_OO_lar	;
m16	=	PG_OO_ecu	;
m17	=	PSV_NF0d10m	;
m18	=	PSV_F0d5m	;
m19	=	PSV_F0d10m	;
m20	=	PSV_F10d10m	;
m21	=	POO_OO_lar	;
m22	=	POO_OO_ecu	;
% -----------------------------
m51	=	PG_NF_0gs_ecu + PG_NF_gs_ecu 	;
m52	=	PG_NF_0gs_lar +PG_NF_gs_lar	;
m53	=	PG_OO_0gs_ecu + PG_OO_gs_ecu	;
m54	=	PG_OO_0gs_lar + PG_OO_gs_lar	;
m55	=	PG_F_0gs_ecu + PG_F_gs_ecu	;
m56	=	PG_F_0gs_lar + PG_F_gs_lar	;
m57	=	PG_NF_int_ecu 	;
m58	=	PG_NF_int_lar 	;
m59	=	PG_OO_int_ecu	;
m60	=	PG_OO_int_lar 	;
m61	=	PG_F_int_ecu 	;
m62	=	PG_F_int_lar 	;
m63	=	PG_NF_int1_ecu 	;
m64	=	PG_NF_int1_lar 	;
m65	=	PG_OO_int1_ecu	;
m66	=	PG_OO_int1_lar 	;
m67	=	PG_F_int1_ecu 	;
m68	=	PG_F_int1_lar 	;
m69	=	PG_NF_int2_ecu 	;
m70	=	PG_NF_int2_lar 	;
m71	=	PG_OO_int2_ecu	;
m72	=	PG_OO_int2_lar 	;
m73	=	PG_F_int2_ecu 	;
m74	=	PG_F_int2_lar 	;


simMoments = [m1	m2	m3	m4	m5	m6	m7	m8	m9	m10	m11	m12	m13	m14	m15	m16	m17	m18	m19	m20	m21	m22	newSurveyMoms	m51	m52	m53	m54	m55	m56	m57	m58	m59	m60	m61	m62	m63	m64	m65	m66	m67	m68	m69	m70	m71	m72	m73	m74]';


end








