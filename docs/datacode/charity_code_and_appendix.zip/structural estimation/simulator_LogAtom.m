%This simulates the model under the assumption that a is distributed
%according to a lognormal distribution with an additional mass at 0.
%See simulator_benchmark.m for more comments

function [simMoments] = simulator_LogAtom(parameters)
warning off MATLAB:quad:MinStepSize
warning off MATLAB:quadgk:MaxIntervalCountReached

%Size of the masses at 0 in the distrubutions for La Rabida and ECU
Pzero_lar = parameters(16);
Pzero_ecu = parameters(17);

%Check parameters
if sum(parameters([1:3 7:17])<0)>0
    simMoments=NaN(70,1);
    return;
end

if sum(parameters([1:2 15:17])>1)>0
    simMoments=NaN(70,1);
    return;
end

%moments for the population with a>0 and the population with a=0
momsLog = simulator_Log(parameters);
momsAlt0 = simulator_ZeroAltruism(parameters);

% charityMoments=[1:6 11:16 21:22 51:70];
lar_Moments = [1:2:5 11:2:15 21 42:2:70];
ecu_Moments = [2:2:6 12:2:16 22 41:2:69];

% overall moments are averages of those populations
simMoments = momsLog;
simMoments(lar_Moments) = (1-Pzero_lar)*momsLog(lar_Moments) + Pzero_lar*momsAlt0(lar_Moments);
simMoments(ecu_Moments) = (1-Pzero_ecu)*momsLog(ecu_Moments) + Pzero_ecu*momsAlt0(ecu_Moments);

end



