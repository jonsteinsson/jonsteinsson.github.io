%See simulator_benchmark.m for more comments. This simulates moments for the
%population with no social preferences, a=0 and S=0. Subsidiary function to
%simulator_benchmark_NoSocPrefs.m

function [simMoments] = simulator_NoSocPrefs(parameters)

h_0=parameters(1);
h_2009=parameters(15);

simMoments = [ repmat(h_0,1,10)	zeros(1,12) repmat(h_2009,1,8)	zeros(1,40) ]';


end






