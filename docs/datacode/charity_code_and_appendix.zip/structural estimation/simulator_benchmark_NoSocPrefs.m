%See simulator_benchmark.m for more comments. This does the same for the model
%that allows a fraction 1-p with no social preferences, a=0 and S=0.

function [simMoments] = simulator_benchmark_NoSocPrefs(parameters)

h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_svy=parameters(6);
timeval=parameters(13);
h_01=parameters(15);
p=parameters(16); % p = proportion with both social pressure and altruism social preferences

c10 = 0;
c5 = -timeval*5/60;
cB = timeval*10/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;

% no social prefs survey stuff

simNoSoc = simulator_NoSocPrefs(parameters);

if size(parameters,1)==1
    simP = simulator_benchmark([ parameters(1:14)  h_01] );
else
    simP = simulator_benchmark([ parameters(1:14) ; h_01] );
end

simMoments = p*simP + (1-p)*simNoSoc ; 

end






