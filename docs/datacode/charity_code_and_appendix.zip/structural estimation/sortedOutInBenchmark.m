%Calculates the fraction of the population that sort out of the household, and the fraction that sort in.

function [props] = sortedOutInBenchmark(parameters)
h_0=parameters(1);
r=parameters(2);
eta=parameters(3);
mu_lar=parameters(4);
mu_ecu=parameters(5);
mu_s=parameters(6);
sigma_lar=parameters(7);
sigma_ecu=parameters(8);
sigma_s=parameters(9);
S_lar=parameters(10);
S_ecu=parameters(11);
S_svy=parameters(12);
timeval=parameters(13);
Gi_lar=parameters(14);
Gi_ecu=Gi_lar;
gs_lar=10;
gs_ecu=10;
% values of time delta_c. note that survey baseline is 10 mins
% Assume extra time utility from survey that takes < 10 mins
c10 = 0;
c5 = -timeval*5/60;
m_0 = 0; % value of money
m_5 = 5;
m_10 = 10;
epsilon=1e-4;
infinity=1000;

if sum(parameters([1:3 7:15])<0)>0
    props=repmat(NaN,4,1);
    return;
end

if sum(parameters([1:2])>1)>0
    props=repmat(NaN,4,1);
    return;
end

% =====================================================================
% Critical Values for Charities
% =====================================================================

% For lar
if (S_lar<1)
    aMinMin_lar =(1-S_lar)*Gi_lar;
    aMin_lar = (1-S_lar)*(Gi_lar+gs_lar);
    aPlus_lar = Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
    if (a0_lar < aMin_lar || a0_lar > aPlus_lar)
        [a0_lar fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_lar*(1-S_lar))) - a0 + Gi_lar*(1-S_lar) - S_lar*gs_lar,[aMinMin_lar-epsilon aMin_lar+epsilon]);
    end
else
    aMinMin_lar = -(S_lar-1)*gs_lar/(Gi_lar*log(1+gs_lar/Gi_lar)+gs_lar*(log(Gi_lar+gs_lar)-1));
    aMin_lar=aMinMin_lar;
    aPlus_lar =  Gi_lar + gs_lar;
    a0_lar= gs_lar/log(1+gs_lar/Gi_lar);
end
if (S_lar==0) aOO_lar=-Inf; else aOO_lar=a0_lar; end
H_aMinMin_lar = h_0 - eta*S_lar*gs_lar;
H_aMin_lar = h_0 + eta*((1-S_lar)*(Gi_lar+gs_lar)*log(1+gs_lar/Gi_lar) - gs_lar );
H_aPlus_lar = h_0 + eta*((Gi_lar+gs_lar)*log(1+gs_lar/Gi_lar) - gs_lar );
hParams_lar=[h_0 eta S_lar gs_lar Gi_lar aMinMin_lar aMin_lar aPlus_lar aOO_lar mu_lar sigma_lar];

% For ecu
if (S_ecu<1)
    aMinMin_ecu =(1-S_ecu)*Gi_ecu;
    aMin_ecu = (1-S_ecu)*(Gi_ecu+gs_ecu);
    aPlus_ecu = Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
    if (a0_ecu < aMin_ecu || a0_ecu > aPlus_ecu)
        [a0_ecu fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi_ecu*(1-S_ecu))) - a0 + Gi_ecu*(1-S_ecu) - S_ecu*gs_ecu,[aMinMin_ecu-epsilon aMin_ecu+epsilon]);
        if exitflag==-10
            disp('Endpoint Vals were same sign');
            disp('Params = '); disp(parameters);
        end        
    end
else
    aMinMin_ecu = -(S_ecu-1)*gs_ecu/(Gi_ecu*log(1+gs_ecu/Gi_ecu)+gs_ecu*(log(Gi_ecu+gs_ecu)-1));
    aMin_ecu=aMinMin_ecu;
    aPlus_ecu =  Gi_ecu + gs_ecu;
    a0_ecu= gs_ecu/log(1+gs_ecu/Gi_ecu);
end
if (S_ecu==0) aOO_ecu=-Inf; else aOO_ecu=a0_ecu; end
H_aMinMin_ecu = h_0 - eta*S_ecu*gs_ecu;
H_aMin_ecu = h_0 + eta*((1-S_ecu)*(Gi_ecu+gs_ecu)*log(1+gs_ecu/Gi_ecu) - gs_ecu );
H_aPlus_ecu = h_0 + eta*((Gi_ecu+gs_ecu)*log(1+gs_ecu/Gi_ecu) - gs_ecu );
hParams_ecu=[h_0 eta S_ecu gs_ecu Gi_ecu aMinMin_ecu aMin_ecu aPlus_ecu aOO_ecu mu_ecu sigma_ecu];

% to find aL: cutoff value of altruism that sets h*=0
if (H_aMinMin_lar > 0)
    aL_lar=-Inf;
elseif  (H_aMin_lar>0)
    % then aL is between aMinMin and aMin
    if (S_lar > 1)
        aL_lar=aMin_lar;
    else
        aL_lar = fzero(@(a) h_0 + eta * (a * log( a/(1-S_lar) ) - a * ( 1+log(Gi_lar) ) - S_lar*gs_lar + Gi_lar*(1-S_lar) ),[aMinMin_lar-epsilon aMin_lar+epsilon]);
    end
elseif (H_aPlus_lar>0)
    aL_lar = (gs_lar - h_0/eta) / log(1+gs_lar/Gi_lar);
else
    aL_lar = fzero(@(a) h_0 + eta * (Gi_lar - a + a*log(a/Gi_lar)),[aPlus_lar-epsilon infinity]);
end

% to find aH: cutoff value of altruism that sets h*=1
if (H_aMin_lar > 1)
    if (S_lar > 1)
        aH_lar=aMin_lar;
    else
        aH_lar = fzero(@(a) -1 + h_0 + eta * (a * log( a/(1-S_lar) ) - a * ( 1+log(Gi_lar) ) - S_lar*gs_lar + Gi_lar*(1-S_lar) ),[aMinMin_lar-epsilon aMin_lar+epsilon]);
    end
elseif (H_aPlus_lar > 1)
    aH_lar = (gs_lar +(1-h_0)/eta) / log(1+gs_lar/Gi_lar);
else
    if  h_0+eta*(Gi_lar - infinity + infinity*log(infinity/Gi_lar)) < 1.0
        aH_lar=infinity;
    else
        aH_lar = fzero(@(a) -1 + h_0 + eta * (Gi_lar - a + a*log(a/Gi_lar)),[aPlus_lar-epsilon infinity]);
    end
end

% to find aL cutoff value of altruism that sets h*=0
if (H_aMinMin_ecu > 0)
    aL_ecu=-Inf;
elseif  (H_aMin_ecu>0)
    % then aL is between aMinMin and aMin
    if (S_ecu > 1)
        aL_ecu=aMin_ecu;
    else
        aL_ecu = fzero(@(a) h_0 + eta * (a * log( a/(1-S_ecu) ) - a * ( 1+log(Gi_ecu) ) - S_ecu*gs_ecu + Gi_ecu*(1-S_ecu) ),[ (aMinMin_ecu-epsilon) (aMin_ecu+epsilon)]);
    end
elseif (H_aPlus_ecu>0)
    aL_ecu = (gs_ecu - h_0/eta) / log(1+gs_ecu/Gi_ecu);
else
    aL_ecu = fzero(@(a) h_0 + eta * (Gi_ecu - a + a*log(a/Gi_ecu)),[aPlus_ecu-epsilon infinity]);
end

% to find aH cutoff value of altruism that sets h*=1
if (H_aMin_ecu > 1)
    if (S_ecu > 1)
        aH_ecu=aMin_ecu;
    else
        aH_ecu = fzero(@(a) -1 + h_0 + eta * (a * log( a/(1-S_ecu) ) - a * ( 1+log(Gi_ecu) ) - S_ecu*gs_ecu + Gi_ecu*(1-S_ecu) ),[aMinMin_ecu-epsilon aMin_ecu+epsilon]);
    end
elseif (H_aPlus_ecu > 1)
    aH_ecu = (gs_ecu +(1-h_0)/eta) / log(1+gs_ecu/Gi_ecu);
else
    if  h_0+eta*(Gi_ecu - infinity + infinity*log(infinity/Gi_ecu)) < 1.0
        aH_ecu=infinity;
    else
        aH_ecu = fzero(@(a) -1 + h_0 + eta * (Gi_ecu - a + a*log(a/Gi_ecu)),[aPlus_ecu-epsilon infinity]);
    end
end


F_aMinMin_lar = normcdf((aMinMin_lar-mu_lar)/sigma_lar);
F_a0_lar = normcdf((a0_lar-mu_lar)/sigma_lar);
F_aH_lar = normcdf((aH_lar-mu_lar)/sigma_lar);

F_aMinMin_ecu = normcdf((aMinMin_ecu-mu_ecu)/sigma_ecu);
F_a0_ecu = normcdf((a0_ecu-mu_ecu)/sigma_ecu);
F_aH_ecu = normcdf((aH_ecu-mu_ecu)/sigma_ecu);

intHFin_lar = quad( @(X) hstarQuad(X, hParams_lar), a0_lar, aH_lar) +   (1-F_aH_lar);
intHFin_ecu = quad( @(X) hstarQuad(X, hParams_ecu), a0_ecu, aH_ecu) +   (1-F_aH_ecu);

if aL_lar==-Inf
    intHFout_lar = H_aMinMin_lar*F_aMinMin_lar + quad( @(X) hstarQuad(X, hParams_lar), aMinMin_lar, a0_lar);
else
    intHFout_lar = quad( @(X) hstarQuad(X, hParams_lar), aL_lar, a0_lar);
end

if aL_ecu==-Inf
    intHFout_ecu = H_aMinMin_ecu*F_aMinMin_ecu + quad( @(X) hstarQuad(X, hParams_ecu), aMinMin_ecu, a0_ecu);
else
    intHFout_ecu = quad( @(X) hstarQuad(X, hParams_ecu), aL_ecu, a0_ecu);
end

SortOut_lar = r*h_0*F_a0_lar - r*intHFout_lar;
SortIn_lar = r*intHFin_lar - r*h_0*(1-F_a0_lar);
SortOut_ecu = r*h_0*F_a0_ecu - r*intHFout_ecu;
SortIn_ecu = r*intHFin_ecu - r*h_0*(1-F_a0_ecu);


props=[SortOut_lar;SortOut_ecu ; SortIn_lar ; SortIn_ecu];

end



