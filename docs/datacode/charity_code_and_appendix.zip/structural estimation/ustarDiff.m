%Utility of contacted household compared to no solicitation, no flyer case

function [udiff] = ustarDiff(a, paramVector)

S=paramVector(1);
gs=paramVector(2);
Gi=paramVector(3);

if (S<1)
    aMinMin =(1-S)*Gi;
    aMin = (1-S)*(Gi+gs);
    aPlus = Gi + gs;
else
    aMinMin = (1-S)*Gi;
    aMin=  (1-S)*Gi*exp(-gs);
    aPlus =  Gi + gs;
end

g=repmat([999], 1, length(a));
udiff=repmat([999], 1, length(a));

for i=1:length(g)
    if a(i)<=aMinMin
        g(i)=0;
    elseif a(i)<=aMin
        g(i)= a(i)/(1-S)-Gi;
    elseif a(i)<=aPlus
        g(i) = gs;
    else
        g(i)=a(i)-Gi;
    end
    udiff(i) = -g(i) + a(i)*log(g(i)+Gi) - S*(gs-g(i))*(g(i)<gs) - a(i)*log(Gi);
end    



end