%This calculates the difference in utility from no solicitation in the flyer treatment, for someone who sees the flyer.

function [udiff] = ustarDiffFlyer(a, paramVector)

h_0=paramVector(1);
eta=paramVector(2);
S=paramVector(3);
gs=paramVector(4);
Gi=paramVector(5);

if (S<1)
    aMinMin =(1-S)*Gi;
    aMin = (1-S)*(Gi+gs);
    aPlus = Gi + gs;
else
    aMinMin = -(S-1)*gs/(Gi*log(1+gs/Gi)+gs*(log(Gi+gs)-1));
    aMin=aMinMin;
    aPlus =  Gi + gs;
end



g=repmat([999], 1, length(a));
h=repmat([999], 1, length(a));
udiff=repmat([999], 1, length(a));

for i=1:length(g)
    if a(i)<=aMinMin
        g(i)=0;
        h(i)=h_0 - eta * S * gs;
    elseif a(i)<=aMin
        g(i)= a(i)/(1-S)-Gi;
        h(i)=h_0 + eta * (a(i) .* log( a(i)/(1-S) ) - a(i) .* ( 1+log(Gi) ) - S*gs + Gi*(1-S) );
    elseif a(i)<=aPlus
        g(i) = gs;
        h(i) = h_0 + eta*(a(i).*log(1+gs/Gi)-gs);
    else
        g(i)=a(i)-Gi;
        h(i)=h_0 + eta*(Gi - a(i) + a(i).*log(a(i)/Gi));
    end
    h(i)=max(0,min(1,h(i)));
    udiff(i) = h(i)*(-g(i) + a(i)*log(g(i)+Gi) - S*(gs-g(i))*(g(i)<gs) - a(i)*log(Gi))- (h_0-h(i))^2/(2*eta);
end    



end