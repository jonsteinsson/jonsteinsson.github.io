%Difference in utility of a contacted household compared to no solicitation in the opt-out treatment

function [udiff] = ustarDiffOptOut(a, paramVector)

h_0=paramVector(1);
eta=paramVector(2);
S=paramVector(3);
gs=paramVector(4);
Gi=paramVector(5);
epsilon=1e-5;

if (S<1)
    aMinMin =(1-S)*Gi;
    aMin = (1-S)*(Gi+gs);
    aPlus = Gi + gs;
    if S == 0 
        a0 = aMinMin;
    else
        a0= gs/log(1+gs/Gi);
        if (a0 < aMin || a0 > aPlus)
           [a0 fval exitflag output]= fzero(@(a0) a0*log(a0/(Gi*(1-S))) - a0 + Gi*(1-S) - S*gs,[aMinMin-epsilon aMin+epsilon]);
        end
    end
else
    aMinMin = -(S-1)*gs/(Gi*log(1+gs/Gi)+gs*(log(Gi+gs)-1));
    aMin=aMinMin;
    aPlus =  Gi + gs;
    a0= gs/log(1+gs/Gi);
end
if (S==0) aOO=-Inf; else aOO=a0; end


g=repmat([999], 1, length(a));
h=repmat([999], 1, length(a));
udiff=repmat([999], 1, length(a));

for i=1:length(g)
    if a(i)<=aMinMin
        g(i)=0;
        h(i)=h_0 - eta * S * gs;
    elseif a(i)<=aMin
        g(i)= a(i)/(1-S)-Gi;
        h(i)=h_0 + eta * (a(i) .* log( a(i)/(1-S) ) - a(i) .* ( 1+log(Gi) ) - S*gs + Gi*(1-S) );
    elseif a(i)<=aPlus
        g(i) = gs;
        h(i) = h_0 + eta*(a(i).*log(1+gs/Gi)-gs);
    else
        g(i)=a(i)-Gi;
        h(i)=h_0 + eta*(Gi - a(i) + a(i).*log(a(i)/Gi));
    end
    h(i)=max(0,min(1,h(i)));
    if a(i) <= aOO
        udiff(i) = 0;
    else
        udiff(i) = h(i)*(-g(i) + a(i)*log(g(i)+Gi) - S*(gs-g(i))*(g(i)<gs) - a(i)*log(Gi))- (h_0-h(i))^2/(2*eta);
    end
       
end    



end