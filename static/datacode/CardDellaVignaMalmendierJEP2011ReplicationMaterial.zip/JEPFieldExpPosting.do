set more off

** Do file for replication of results in
** The Role of Theory in Field Experiments
** David Card, Stefano DellaVigna, and Ulrike Malmendier
** Journal of Economic Perspectives�Volume 25, Number 3�Summer 2011�Pages 39�62

* Set right directory
cd C:\Users\sdellavi\Documents\Brief\Research\old\JEP\posting

*** Generate summary stats for paper
use JEPFieldExpPosting.dta, clear
* Counts and examples by decades of field experiments
count if field==1 & year<1985
list article journal year if field==1 & year<1985
count if field==1 & year>=1985 & year<1995
list article journal year if field==1 & year>=1985 & year<1995
bys year: count if field==1
ta field
* Counts and examples by decades of lab experiments
bys year: count if lab==1
count if lab==1 & year>=1985 & year<=1995
count if field==1 & year>=1985 & year<=1995
ta lab if year==2010
ta lab
ta journal if lab==1
ta journal if field==1
* Role of theory for field experiments by 5-year period
ta theory if field==1 & year<1985
ta theory if field==1 & year>=1985 & year<=1994
ta theory if field==1 & year>=1995 & year<=1999
ta theory if field==1 & year>=2000 & year<=2004
list article author journal year if theory~="Desc" & field==1 & year>=2000 & year<=2004
ta theory if field==1 & year>=2005 & year<=2010
ta theory if field==1
bys journal: ta theory if field==1
bys journal: ta theory if field==1 & year>=2000
* Role of theory for lab experiments
ta theory if lab==1
bys journal: ta theory if lab==1
bys journal: ta theory if lab==1 & year>=2000


*** Generate Figures
local journal="Five Top Journals"
by year, sort: egen total=count(year)
by year, sort: egen count_temp=count(lab) if lab==1	
by year, sort: egen count_lab=mean(count_temp)	
gen share_lab=count_lab/total	
by year journal, sort: egen totaljournal=count(year)
by year journal, sort: egen count_tempjournal=count(lab) if lab==1	
by year journal, sort: egen count_labjournal=mean(count_tempjournal)	
drop count_temp*
la var count_lab "Number of lab experiments"	
la var count_labjournal "Number of lab experiments"	

by year, sort: egen count_temp=count(field) if field==1	
by year, sort: egen count_field=mean(count_temp)	
gen share_field=count_field/total	
by year journal, sort: egen count_tempjournal=count(field) if field==1	
by year journal, sort: egen count_fieldjournal=mean(count_tempjournal)	
la var count_field "Number of field experiments"	
la var count_fieldjournal "Number of field experiments"	
	
recode count_field* share_field count_lab* share_lab (.=0)	
preserve	
by year, sort: drop if _n>1	
	
twoway (line count_lab year, lpattern(dash)) 	///
	(line count_field year, lpattern(solid)), xsc(r(1975 2010)) ysc(r(0 25)) 		///
	ytitle(Number per year) xtitle(Year) title(Count of Experiments Published in `journal') ///
	saving("`journal'_total", replace) 
restore	

gen tag=.														
replace tag=1 if year>=1975 & year<=1984														
replace tag=2 if year>=1985 & year<=1989														
replace tag=3 if year>=1990 & year<=1994														
replace tag=4 if year>=1995 & year<=1999														
replace tag=5 if year>=2000 & year<=2004														
replace tag=6 if year>=2005 & year<=2010														
														
label define tag_label 1 "75-84" 2 "85-89" 3 "90-94" 4 "95-99" 5 "00-04" 6 "05-10"														
la val tag tag_label		
													
keep if year>=1975														
foreach exp in lab field{														
local journal="Top-5 Journals"
														
	foreach type in desc null nullalt param {													
														
		cap drop test												
		gen test=(`exp'+`type'==2)												
		recode test 0=.												
														
		by tag, sort: egen count_`type'=count(test)												
	}													
														
		la var count_desc "Descriptive"												
		la var count_null "Single Model"	
		la var count_nullalt "Competing Models"												
		la var count_param "Parameter estim."												
														
		preserve												
		by tag, sort: drop if _n>1												
		* outsheet using `journal'_`exp', replace												
		twoway (line count_desc tag, lpattern(shortdash_dot_dot)) 	///											
			(line count_null tag, lpattern(longdash_dot)) 			///								
			(line count_nullalt tag, lpattern(dash)) 				///							
			(line count_param tag, lpattern(solid)), 				///							
			ytitle(Number) 											/// yscale(range(0 30))
			xtitle(Period) xlabel(, valuelabel) 					///						
			title("Count of `exp' experiments by theoretical content") saving("`journal'_`exp'", replace)											
		restore												
														
		drop count_desc count_null count_nullalt count_param												
}														

														
*** Save list of all field experiments 																																										
keep if field==1
replace theory="Descriptive" if theory=="Desc"
replace theory="Single Model" if theory=="Null"
replace theory="Competing Models" if theory=="NullAlt"
replace theory="Parameter Estim." if theory=="Param"

keep journal year month journal author article pages theory
replace pages=trim(proper(subinstr(pages, "pp.","",.)))
replace pages=subinstr(pages,"--","-",.)
order year month journal page author article theory
sort year month pages
outsheet using listfieldexpMay11.out,replace
list

*** Count of most common authors
split author,p(" ")
foreach z in "List" "Heckman" "Duflo" "Saez" "Karlan" "Angrist" "Bertrand" "Mullainathan" "Katz" "Gneezy" "Kling" "Charness" "Liebman" "Kremer" "Zinman" "Landry" "Ashraf" "Lange" "Price" "Shapiro" "Mobius" "Ariely" "Fehr" "Iyengar" "Ludwig" "Meier" {
	gen d`z'=0
	}
forvalues x=1/15 {
	replace author`x'=subinstr(author`x',",","",.)
	replace author`x'=subinstr(author`x',".","",.)
	replace author`x'=trim(proper(author`x'))
	ta author`x'
	foreach z in "List" "Heckman" "Duflo" "Saez" "Karlan" "Angrist" "Bertrand" "Mullainathan" "Katz" "Gneezy" "Kling" "Charness" "Liebman" "Kremer" "Zinman" "Landry" "Ashraf" "Lange" "Price" "Shapiro" "Mobius" "Ariely" "Fehr" "Iyengar" "Ludwig" "Meier" {
		replace d`z'=1 if author`x'=="`z'"
		}
	}
foreach z in "List" "Heckman" "Duflo" "Saez" "Karlan" "Angrist" "Bertrand" "Mullainathan" "Katz" "Gneezy" "Kling" "Charness" "Liebman" "Kremer" "Zinman" "Landry" "Ashraf" "Lange" "Price" "Shapiro" "Mobius" "Ariely" "Fehr" "Iyengar" "Ludwig" "Meier" {
	ta d`z' if year>=1995
	}
forvalues x=1/15 {
count if author`x'=="Lucking-Reiley"|author`x'=="Reiley"
	}

*** Load Table 2a and 2b to summarize facts by field
insheet using Table2a.csv, clear
save Table2a, replace
insheet using Table2b.csv, clear
append using Table2a
drop if year==.

** Fields
ta field if year<=1994
ta field if year>1994

list author year google classification if google>=200 & year>=1995 & year<=2004
** 1995-2004
ta classification if google>=200 & year>=1995 & year<=2004
ta classification if year>=1995 & year<=2004
** 2005 on
list author year google classification if google>=100 & year>=2005
ta classification if google>=100 & year>=2005
ta classification if year>=2005
