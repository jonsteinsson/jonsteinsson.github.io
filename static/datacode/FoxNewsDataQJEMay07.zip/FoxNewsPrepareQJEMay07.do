clear
set mem 100m
set matsize 3000

set more off

* cd c:/Brief/Research/mediabias
cap log close
cap log using mediapolPrepareSampleQJE,replace


use FoxNewsDataQJEMay07, clear


*******************************************************************************
* GENERATE SOME ADDITIONAL VARIABLES NEEDED
*******************************************************************************

*** CENSUS DATA. Generate Census variables in changes and label them
foreach y in pop hs hsp college male black hisp empl unempl married income urban {
	gen `y'00m90=`y'2000-`y'1990
	}
foreach x in "00m90" {
	if ("`x'"=="1990" | "`x'"==`"2000"') local y = `" in year `x'"'
	else if ("`x'"=="00m90") local y = `", 2000 minus 1990"' 
	label var pop`x' "Population of place`y' -- Census"
	label var hs`x' "Fraction with high-school degree`y' -- Census"
	label var hsp`x' "Fraction with some college`y' -- Census"
	label var college`x' "Fraction with college degree`y' -- Census"
	label var male`x' "Fraction male`y' -- Census"
	label var black`x' "Fraction African American`y' -- Census"
	label var hisp`x' "Fraction Hispanic`y' -- Census"
	label var empl`x' "Fraction employed`y' -- Census"
	label var unempl`x' "Unemployment rate`y' -- Census"
	label var married`x' "Fraction married`y' -- Census"
	label var income`x' "Median Income`y' -- Census"
	label var urban`x' "Fraction living in urban area`y' -- Census"
	}

* Renormalize scale of variables for summary statistics
gen noch2000stat=10*noch2000
label var noch2000stat "No. of Channels, measured with original scale (1 = 1 channel)"
foreach x in poptot2000 pop2000 pop00m90 {
	gen `x'stat=10000*`x'
	label var `x'stat "Variable `x', with original scale"
	}

*** Generate region data and use it to generate sample with high coverage of election data
g region="Northeast" if state=="Ct"|state=="Ma"|state=="Me"|state=="Nh"|state=="Nj"|state=="Ny"|state=="Pa"|state=="Ri"|state=="Vt"
replace region="Midwest" if state=="Ia"|state=="Id"|state=="Il"|state=="In"|state=="Mi"|state=="Mn"|state=="Mo"|state=="Nd"|state=="Oh"|state=="Wi"
replace region="West" if state=="Ak"|state=="Ca"|state=="Hi"|state=="Mt"|state=="Or"|state=="Ut"|state=="Wy"
replace region="South" if state=="Al"|state=="Ar"|state=="De"|state=="Fl"|state=="Md"|state=="Ok"|state=="Sc"|state=="Tn"|state=="Va"
label var region "Census Region where town is located"



*** ELECTION DATA. Generate vote share variables
foreach xyr in 1988 1992 1996 2000 2004 {
	foreach xrc in "pres" "sen" {
		gen rep`xrc'fv`xyr'=rep`xrc'votes`xyr'/tot`xrc'votes`xyr' if rep`xrc'votes`xyr'~=0 & rep`xrc'votes`xyr'~=demrep`xrc'votes`xyr'
		gen rep`xrc'fv2p`xyr'=rep`xrc'votes`xyr'/demrep`xrc'votes`xyr' if rep`xrc'votes`xyr'~=0 & rep`xrc'votes`xyr'~=demrep`xrc'votes`xyr'
		gen tot`xrc'lv`xyr'=log(tot`xrc'votes`xyr') if rep`xrc'votes`xyr'~=0 & rep`xrc'votes`xyr'~=demrep`xrc'votes`xyr'
		if ("`xrc'"=="pres") local yrc="Presidential"
		if ("`xrc'"=="sen") local yrc="US Senate"
		label var rep`xrc'fv`xyr' "Rep. all-party vote share in `yrc' elections in `xyr'"
		label var rep`xrc'fv2p`xyr' "Rep. 2-party vote share in `yrc' elections in `xyr'"
		label var tot`xrc'lv`xyr' "Log of total votes cast in `yrc' elections in `xyr'"
		}
	}

*** Generate change in vote share variables for Presidential elections
gen reppresfv2p04m00=reppresfv2p2004-reppresfv2p2000
label var reppresfv2p04m00 "Change in Rep. 2-party vote share in Presidential elections, 2004 - 2000"
gen reppresfv2p00m96=reppresfv2p2000-reppresfv2p1996
label var reppresfv2p00m96 "Change in Rep. 2-party vote share in Presidential elections, 2000 - 1996"
gen reppresfv2p96m92=reppresfv2p1996-reppresfv2p1992
label var reppresfv2p96m92 "Change in Rep. 2-party vote share in Presidential elections, 1996 - 1992"
gen reppresfv2p92m88=reppresfv2p1992-reppresfv2p1988
label var reppresfv2p92m88 "Change in Rep. 2-party vote share in Presidential elections, 1992 - 1988"
gen reppresfv00m96=reppresfv2000-reppresfv1996
label var reppresfv00m96 "Change in Rep. all-party vote share in Presidential elections, 2000 - 1996"

*** Generate change in turnout variables for Presidential elections
gen totpreslv00m96=totpreslv2000-totpreslv1996
label var totpreslv00m96 "Change in log of votes cast in Presidential elections, 2000 - 1996"
gen lpop18p00m96=log(pop18p2000)-log(pop18p1996)
label var lpop18p00m96 "Change in log population of age 18 and older, 2000 - 1996"

* Generate the second turnout variable (log votes minus log voting-age population) in levels for 1996 and 2000
gen totpreslvpop1996=totpreslv1996-log(pop18p1996)
label var totpreslvpop1996 "Log of votes cast in Pres. elections minus log voting-age population in 1996"
gen totpreslvpop2000=totpreslv2000-log(pop18p2000)
label var totpreslvpop2000 "Log of votes cast in Pres. elections minus log voting-age population in 2000"

*** States with high coverage of election data
gen delectwnvot=(region=="Northeast"|state=="Ca"|state=="Mi"|state=="Mn"|state=="Mt"|state=="Oh"|state=="Pa"|state=="Wi"|state=="Wy")
label var delectwnvot "States with election coverage above 50 percent"




*** CABLE DATA. Generate measure of important races, that is, races emphasized by Fox News
* 2000: Hillary Clinton
gen dimp2000=(state=="Ny")
label var dimp2000 "Dummy for Senate race covered by for News in 2000: NY State"

*** generate interactions with FOXNEWS measures
gen foxnews2000dimp=foxnews2000*dimp2000
label var foxnews2000dimp "Interaction term: Fox News 2000 * NY State (Important Senate race)"
gen foxnews2000urban=foxnews2000*urban2000
label var foxnews2000urban "Interaction term: Fox News 2000 * Share urban"
gen foxnews2000noch=foxnews2000*noch2000
label var foxnews2000noch "Interaction term: Fox News 2000 * Number of Cable channels available"

*** locality dummy variables
* Check what happens if district missing
egen diststate=group(state district2000)
label var diststate "US House Districts, numbered 1 to N"
egen countystate=group(state county)
label var countystate "Counties, numbered 1 to N"

*** Generate macros of controls
foreach tc in "2000" "00m90" {
	global contrcens`tc'= "pop`tc' hs`tc' hsp`tc' college`tc' male`tc' black`tc' hisp`tc' empl`tc' unempl`tc' married`tc' income`tc' urban`tc'"
	global contrcenssh`tc'= "pop`tc' hsp`tc' college`tc' black`tc' hisp`tc' unempl`tc' urban`tc'"
}
foreach tc in "2000" {
global contrcbl`tc'= "poptot`tc'd2-poptot`tc'd10 noch`tc'd2-noch`tc'd10"
}



*******************************************************************************8
* DETERMINE FINAL SAMPLE FOR FOR NEWS (QJE, 2007) RESULTS
*******************************************************************************8

count
* Original sample -- 48,949 obs.

count if ddelect==1 & reppresfv2p2000~=. & reppresfv2p1996~=.
* Observations with non-missing election data -- 23,787 obs.
count if ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.
* Observations with non-missing election and cable data (for the year 2000)-- 10,479 obs.

** Drop if...
count if (ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==0
* Eliminate if no matching Census data -- 353 obs.
count if (ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & foxnews2000==.
* Eliminate towns with multiple cable systems, some of which carry Fox News and others do not
* In this case, the condition ddcable==1 is satisfied, but the variable foxnews2000 is set to missing -- 289 obs.
count if (ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & foxnews2000~=. & cnn2000~=1
* Eliminate if CNN not available in the cable system in the year 2000 -- 324 obs.
count if (ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & foxnews2000~=. & cnn2000==1 & /*
		*/ ~(noprec2000>=.8*noprec1996 & noprec2000<=1.2*noprec1996 | /*
		*/ state=="Mi" | state=="Nh" | state=="Ny" | state=="Oh" | state=="Ri" | state=="Ut") 
* Eliminate if the number of precincts changes between 1996 and 2000 (except in States in which this comparison cannot be made) -- 238 obs.
count if (ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & foxnews2000~=. & cnn2000==1 & /*
		*/ (noprec2000>=.8*noprec1996 & noprec2000<=1.2*noprec1996 | /*
		*/ state=="Mi" | state=="Nh" | state=="Ny" | state=="Oh" | state=="Ri" | state=="Ut") & /*
		*/ abs(totpreslv2000-totpreslv1996)>1
* Eliminate if turnout changes by more than 100 log points between 1996 and 2000 -- 19 obs. del.

** Final sample
gen sample12000=((ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & foxnews2000~=. & cnn2000==1 & /*
		*/ (noprec2000>=.8*noprec1996 & noprec2000<=1.2*noprec1996 | /*
		*/ state=="Mi" | state=="Nh" | state=="Ny" | state=="Oh" | state=="Ri" | state=="Ut") & /*
		*/ abs(totpreslv2000-totpreslv1996)<=1)
label var sample12000 "Benchmark sample"
count if sample12000==1
* final sample: 9256 obs.


*** Generate weighted vote share variable at the district level -- Need to do this before dropping observations
bys state district2000: egen temp1=total(reppresvotes2000)
bys state district2000: egen temp3=total(demreppresvotes2000)
gen reppresfv2pwdst2000=temp1/temp3
label var reppresfv2pwdst2000 "2-party Rep. vote share in Pres. elections at District level"
drop temp*
** Generate thirds (across towns) of 2-party Republican vote share
xtile reppresfv2pwdst2000pc=reppresfv2pwdst2000 if sample12000==1, nq(3)
gen reppresfv2pwdstd22000=(reppresfv2pwdst2000pc==2) if reppresfv2pwdst2000pc~=.
label var reppresfv2pwdstd22000 "Swing District: District in Middle group according to Rep. Vote share"
gen reppresfv2pwdstd32000=(reppresfv2pwdst2000pc==3) if reppresfv2pwdst2000pc~=.
label var reppresfv2pwdstd32000 "Republican District: District in Top group according to Rep. Vote share"
drop reppresfv2pwdst2000pc
su reppresfv2pwdst2000 if reppresfv2pwdstd22000==0 & reppresfv2pwdstd32000==0
su reppresfv2pwdst2000 if reppresfv2pwdstd22000==1
su reppresfv2pwdst2000 if reppresfv2pwdstd32000==1
** Generate interactions with Fox News variable
gen fox2000reppresfv2pwdstd22000=foxnews2000*reppresfv2pwdstd22000
label var fox2000reppresfv2pwdstd22000 "Interaction term: Fox News in 2000* Swing District"
gen fox2000reppresfv2pwdstd32000=foxnews2000*reppresfv2pwdstd32000
label var fox2000reppresfv2pwdstd32000 "Interaction term: Fox News in 2000* Republican District"


*** Keep sample that includes basic sample (sample12000==1) as well as sample used for checks in Appendix III
keep if (ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1


*** Propensity score to do construct optimal trimming sample
probit foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 reppresfv2p1996 if sample12000==1
predict pfox1
label var pfox1 "Propensity Score"
probit foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1
predict pfox1b
label var pfox1b "Propensity Score, Version b"

* SAMPLE OptTr -- Use only observations inside the propensity score bounds from Guido Imbens
gen sampleOptTr2000= sample12000==1 & (pfox1>.1 & pfox1<1-.1)
label var sampleOptTr2000 "Subsample optimally trimmed according to Crump et al. (2005)"
gen sampleOptTrb2000= sample12000==1 & (pfox1b>.1 & pfox1b<1-.1)
label var sampleOptTrb2000 "Subsample optimally trimmed according to Crump et al. (2005) -- Version b"

*** save main file
compress
sort state county town
save FoxNewsFinalDataQJE,replace
