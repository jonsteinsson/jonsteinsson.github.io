***************************************************************** 
***************************************************************** 
* Replicates the regressions in the Tables of DellaVigna and Kaplan (QJE, 2007) Fox News paper
***************************************************************** 
***************************************************************** 

clear
set mem 500m
set matsize 3000
set more off

*cd c:/Brief/Research/mediabias
cap log close
cap log using mediapolregsQJE,replace


use FoxNewsFinalDataQJE,clear

*** Generate macros of controls
** Census Controls
foreach tc in "2000" "00m90" {
	global contrcens`tc'= "pop`tc' hs`tc' hsp`tc' college`tc' male`tc' black`tc' hisp`tc' empl`tc' unempl`tc' married`tc' income`tc' urban`tc'"
	global contrcenssh`tc'stat= "pop`tc'stat hsp`tc' college`tc' black`tc' hisp`tc' unempl`tc' urban`tc'"
}
** Cable Controls
foreach tc in "2000" {
	global contrcbl`tc'= "poptot`tc'd2-poptot`tc'd10 noch`tc'd2-noch`tc'd10"
	}

*cd c:/Brief/Research/mediabias/output/TablesMay07

** Keep only basic sample
keep if sample12000==1


***************************************************************** 
***************************************************************** 
* Regressions in Tables of DellaVigna and Kaplan (QJE, 2007) Fox News paper
*****************************************************************
***************************************************************** 


* Table I -- Summary Statistics on Audience Data
*** Not available due to confidentiality of Scarborough audience data -- Regression results of Table VIII available below


* Table II -- Summary Statistics on Voting and Cable Data
*** Summary Statistics for overall sample -- Unweighted
tabstat noch2000stat poptot2000stat reppresfv2p1996 reppresfv2p2000 totpreslvpop1996 totpreslvpop2000 $contrcenssh2000stat /*
*/ $contrcenssh00m90stat if sample12000==1, stats(mean sd co) column(sta) by(foxnews2000) long

*** Define sample of mixed House districts and mixed counties in which at least one
*** This is the sample that provides identification for the Fox News effect in the regressions with district and county f.e.
foreach x in dist county {
bys `x'state: egen fox`x'2000=sum(foxnews2000) if sample12000==1
bys `x'state: egen sum`x'2000=count(foxnews2000) if sample12000==1
sort `x'state
gen foxavg`x'2000=fox`x'2000/sum`x'2000 if `x'state~=`x'state[_n-1]
bys `x'state: egen foxavg2`x'2000=max(foxavg`x'2000)
}
*** Summary Statistics for mixed-district and mixed-county subsets -- Unweighted 
foreach x in dist county {
tabstat noch2000stat poptot2000stat reppresfv2p1996 reppresfv2p2000 totpreslvpop1996 totpreslvpop2000 $contrcenssh2000stat /*
*/ $contrcenssh00m90stat if sample12000==1&foxavg2`x'2000~=0 &foxavg2`x'2000~=1&foxavg2`x'2000~=., /*
*/ stats(mean sd co) column(sta) by(foxnews2000) long not
}


* Table III -- Presidential Effects -- Selection -- Inlcude F Tests of significance of coefficients
* No controls (Col. 1)
reg foxnews2000 reppresfv2p1996 totpreslvpop1996 if sample12000==1 [aweight=totpresvotes1996], robust cluster(account2000)
outreg reppresfv2p1996 totpreslvpop1996 using TableIII, title(Table III) ctitle(fv2p,cens) se 3aster bdec(4) rdec(4)  replace
* Census controls (Col. 1)
reg foxnews2000 reppresfv2p1996 totpreslvpop1996 $contrcens2000 $contrcens00m90 if sample12000==1 [aweight=totpresvotes1996], robust cluster(account2000)
outreg reppresfv2p1996 totpreslvpop1996 using TableIII, ctitle(fv2p,cens) se 3aster bdec(4) rdec(4)  append
test $contrcens2000 $contrcens00m90 
* Census and cable controls (Col. 2)
reg foxnews2000 reppresfv2p1996 totpreslvpop1996 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], robust cluster(account2000)
outreg reppresfv2p1996 totpreslvpop1996 using TableIII, ctitle(fv2p,cncbl) se 3aster bdec(4) rdec(4)  append
test $contrcens2000 $contrcens00m90 
test poptot2000d2 poptot2000d3 poptot2000d4 poptot2000d5 poptot2000d6 poptot2000d7 poptot2000d8 poptot2000d9 /*
*/ poptot2000d10 noch2000d2 noch2000d3 noch2000d4 noch2000d5 noch2000d6 noch2000d7 noch2000d8 noch2000d9 noch2000d10 
* District f.e. (Col. 3)
areg foxnews2000 reppresfv2p1996 totpreslvpop1996 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg reppresfv2p1996 totpreslvpop1996 using TableIII, ctitle(fv2p,i.dst) se 3aster bdec(4) rdec(4)  append
test $contrcens2000 $contrcens00m90 
test poptot2000d2 poptot2000d3 poptot2000d4 poptot2000d5 poptot2000d6 poptot2000d7 poptot2000d8 poptot2000d9 /*
*/ poptot2000d10 noch2000d2 noch2000d3 noch2000d4 noch2000d5 noch2000d6 noch2000d7 noch2000d8 noch2000d9 noch2000d10 
* County f.e. (Col. 4)
areg foxnews2000 reppresfv2p1996 totpreslvpop1996 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(countystate) robust cluster(account2000)
outreg reppresfv2p1996 totpreslvpop1996 using TableIII, ctitle(fv2p,i.cst2) se 3aster bdec(4) rdec(4)  append
test $contrcens2000 $contrcens00m90 
test poptot2000d2 poptot2000d3 poptot2000d4 poptot2000d5 poptot2000d6 poptot2000d7 poptot2000d8 poptot2000d9 /*
*/ poptot2000d10 noch2000d2 noch2000d3 noch2000d4 noch2000d5 noch2000d6 noch2000d7 noch2000d8 noch2000d9 noch2000d10 
* Same with previous trends
areg foxnews2000 reppresfv2p1996 totpreslvpop1996 reppresfv2p92m88 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg totpreslvpop1996 reppresfv2p1996 reppresfv2p92m88 using TableIII, ctitle(fv2p,i.dst) se 3aster bdec(4) rdec(4)  append
test $contrcens2000 $contrcens00m90 
test poptot2000d2 poptot2000d3 poptot2000d4 poptot2000d5 poptot2000d6 poptot2000d7 poptot2000d8 poptot2000d9 /*
*/ poptot2000d10 noch2000d2 noch2000d3 noch2000d4 noch2000d5 noch2000d6 noch2000d7 noch2000d8 noch2000d9 noch2000d10 
areg foxnews2000 reppresfv2p1996 totpreslvpop1996 reppresfv2p92m88 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(countystate) robust cluster(account2000)
outreg reppresfv2p1996 totpreslvpop1996 reppresfv2p92m88 using TableIII, ctitle(fv2p,i.cst2) se 3aster bdec(4) rdec(4)  append
test $contrcens2000 $contrcens00m90 
test poptot2000d2 poptot2000d3 poptot2000d4 poptot2000d5 poptot2000d6 poptot2000d7 poptot2000d8 poptot2000d9 /*
*/ poptot2000d10 noch2000d2 noch2000d3 noch2000d4 noch2000d5 noch2000d6 noch2000d7 noch2000d8 noch2000d9 noch2000d10 


* Table IV -- Presidential Effects -- Main Table
* No controls
reg reppresfv2p00m96 foxnews2000 if sample12000==1 [aweight=totpresvotes1996], robust cluster(account2000)
outreg foxnews2000 using TableIV, title(Table IV) ctitle(fv2p,cens) se 3aster bdec(4) rdec(4) replace
* Census controls
reg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 if sample12000==1 [aweight=totpresvotes1996], robust cluster(account2000)
outreg foxnews2000 using TableIV, ctitle(fv2p,cens) se 3aster bdec(4) rdec(4) append
* Census and cable controls
reg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], robust cluster(account2000)
outreg foxnews2000 using TableIV, ctitle(fv2p,cncbl) se 3aster bdec(4) rdec(4) append
* District f.e.
areg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 using TableIV, ctitle(fv2p,i.dst) se 3aster bdec(4) rdec(4) append
* County f.e.
areg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(countystate) robust cluster(account2000)
outreg foxnews2000 using TableIV, ctitle(fv2p,i.cst2) se 3aster bdec(4) rdec(4) append
* Same with previous trends 92m88
areg reppresfv2p00m96 foxnews2000 reppresfv2p92m88 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 reppresfv2p92m88 using TableIV, ctitle(fv2p,i.dst) se 3aster bdec(4) rdec(4) append
areg reppresfv2p00m96 foxnews2000 reppresfv2p92m88 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(countystate) robust cluster(account2000)
outreg foxnews2000 reppresfv2p92m88 using TableIV, ctitle(fv2p,i.cst2) se 3aster bdec(4) rdec(4) append


* Table V -- Presidential Effects -- Robustness and Presidential Delayed Effects
* Lagged vote share
areg reppresfv2p2000 reppresfv2p1996 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 reppresfv2p1996 using TableV, title(Table V) ctitle(fv2p,i.dst) se 3aster bdec(4) rdec(4) nocons replace
* All-party
areg reppresfv00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 using TableV, ctitle(fv,i.dst) se 3aster bdec(4) rdec(4) nocons append
* High coverage
areg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 & delectwnvot==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000) 
outreg foxnews2000 using TableV, ctitle(fv2p,selectpop1,i.dst) se 3aster bdec(4) rdec(4) nocons append
* Towns with turnout of at least 2,000
areg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 & totpresvotes2000>=2000, a(diststate) robust cluster(account2000)
outreg foxnews2000 using TableV, ctitle(>2000w2000,i.dst) se 3aster bdec(4) rdec(4) nocons append
* Leave room for matching estimator  -- RUN BELOW SINCE TAKES A LONG TIME TO RUN
outreg foxnews2000 using TableV, ctitle(empty) se 3aster bdec(4) rdec(4) nocons append
* Delayed Effects
areg reppresfv2p04m00 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 using TableV, ctitle(04m000,i.dst) se 3aster bdec(4) rdec(4) nocons append


* Table VI -- Interactions and Placeboes
areg reppresfv2p00m96 foxnews2000 foxnews2000urban foxnews2000noch noch2000 fox2000reppresfv2pwdstd22000 reppresfv2pwdstd22000 /*
*/ fox2000reppresfv2pwdstd32000 reppresfv2pwdstd32000 /*
*/ $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 foxnews2000urban foxnews2000noch fox2000reppresfv2pwdstd22000 fox2000reppresfv2pwdstd32000 using TableVI, title(Table VI) ctitle(fv2p,i.dst) se 3aster bdec(4) rdec(4) nocons replace
areg reppresfv2p00m96 foxnews2000 foxnews2000urban foxnews2000noch noch2000 fox2000reppresfv2pwdstd22000 reppresfv2pwdstd22000 /*
*/ fox2000reppresfv2pwdstd32000 reppresfv2pwdstd32000 /*
*/ $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(countystate) robust cluster(account2000)
outreg foxnews2000 foxnews2000urban foxnews2000noch fox2000reppresfv2pwdstd22000 fox2000reppresfv2pwdstd32000 using TableVI, ctitle(fv2p,i.cst) se 3aster bdec(4) rdec(4) nocons append
* Do 96-00 with foxnews2003
areg reppresfv2p00m96 foxnews2000 foxnews2003 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 foxnews2003 using TableVI, ctitle(0096,i.dst) se 3aster bdec(4) rdec(4) nocons append
* Main 92-96
areg reppresfv2p96m92 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 using TableVI, ctitle(9296,i.dst) se 3aster bdec(4) rdec(4) nocons append
* Main 88-92
areg reppresfv2p92m88 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 using TableVI, ctitle(8892,i.dst) se 3aster bdec(4) rdec(4) nocons append


* Table VII -- Turnout + Senate
** Turnout
* Share of population in logs controlled
areg totpreslv00m96 lpop18p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg foxnews2000 lpop18p00m96 using TableVII, title(Table VII) ctitle(lvlpop,i.dst) se 3aster bdec(4) rdec(4) nocons replace
areg totpreslv00m96 lpop18p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(countystate) robust cluster(account2000) 
outreg foxnews2000 lpop18p00m96 using TableVII, ctitle(lvlpop,i.cst) se 3aster bdec(4) rdec(4) nocons append
* Interaction previous votes Measure 2
areg totpreslv00m96 lpop18p00m96 foxnews2000 fox2000reppresfv2pwdstd22000 reppresfv2pwdstd22000 fox2000reppresfv2pwdstd32000 /*
*/ reppresfv2pwdstd32000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000) 
outreg foxnews2000 lpop18p00m96 fox2000reppresfv2pwdstd22000 fox2000reppresfv2pwdstd32000 using TableVII, ctitle(lv,i.dst) se 3aster bdec(4) rdec(4) nocons append
** Senate
areg repsenfv2p2000 reppresfv2p1996 foxnews2000 foxnews2000dimp $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg reppresfv2p1996 foxnews2000 foxnews2000dimp using TableVII, ctitle(ContrPres96,i.dst) se 3aster bdec(4) rdec(4) nocons append
areg repsenfv2p2000 reppresfv2p1996 foxnews2000 foxnews2000dimp $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(countystate) robust cluster(account2000) 
outreg reppresfv2p1996 foxnews2000 foxnews2000dimp using TableVII, ctitle(ContrPres96,i.cst) se 3aster bdec(4) rdec(4) nocons append
* Interaction previous votes Measure 2
areg repsenfv2p2000 reppresfv2p1996 foxnews2000 foxnews2000dimp fox2000reppresfv2pwdstd22000 reppresfv2pwdstd22000 fox2000reppresfv2pwdstd32000 /*
*/ reppresfv2pwdstd32000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg reppresfv2p1996 foxnews2000 foxnews2000dimp fox2000reppresfv2pwdstd22000 fox2000reppresfv2pwdstd32000 using TableVII, ctitle(ContrPres96,inter,i.dst) se 3aster bdec(4) rdec(4) nocons append


* Table VIII -- Audience Data and Persuasion Rates
* See Below for Persuasion Rate Computations
* No Controls
reg foxanyScar foxnews2000 if sample12000==1 [aweight=auddiaryScar], robust cluster(account2000)
outreg foxnews2000 using TableVIII, title(Table VIII) ctitle(foxany,s1) se 3aster bdec(4) rdec(4) replace
* Baseline Spec.
areg foxanyScar foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=auddiaryScar], a(diststate) robust cluster(account2000)
outreg foxnews2000 using TableVIII, ctitle(foxany,i.dst,s1) se 3aster bdec(4) rdec(4) append
areg foxanyScar foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=auddiaryScar], a(countystate) robust cluster(account2000)
outreg foxnews2000 using TableVIII, ctitle(foxany,i.c2st,s1) se 3aster bdec(4) rdec(4) append
* Placebo with 2004 Fox News
areg foxanyScar foxnews2000 foxnews2003 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=auddiaryScar], a(diststate) robust cluster(account2000)
outreg foxnews2000 foxnews2003 using TableVIII, ctitle(foxany,i.dst,s1) se 3aster bdec(4) rdec(4) append
*** Placebo with CNN
reg cnnanyScar foxnews2000 if sample12000==1 [aweight=auddiaryScar], robust cluster(account2000)
outreg foxnews2000 using TableVIII, ctitle(cnnany,s1) se 3aster bdec(4) rdec(4) append
areg cnnanyScar foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=auddiaryScar], a(diststate) robust cluster(account2000)
outreg foxnews2000 using TableVIII, ctitle(cnnany,i.dst,s1) se 3aster bdec(4) rdec(4) append
areg cnnanyScar foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=auddiaryScar], a(countystate) robust cluster(account2000)
outreg foxnews2000 using TableVIII, ctitle(cnnany,i.c2st,s1) se 3aster bdec(4) rdec(4) append


* Table IX -- Summary of Literature
* Summary of other papers -- See text


* Appendix II -- Coefficients on Controls
** From Table III
* District f.e.
areg foxnews2000 reppresfv2p1996 totpreslvpop1996 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg $contrcens2000 $contrcens00m90 $contrcbl2000 using AppendixII, title (Appendix II) ctitle(Table3,i.dst) se 3aster bdec(4) rdec(4) replace
** From Table IV
* District f.e.
areg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1 [aweight=totpresvotes1996], a(diststate) robust cluster(account2000)
outreg $contrcens2000 $contrcens00m90 $contrcbl2000 using AppendixII, ctitle(Table4,i.dst) se 3aster bdec(4) rdec(4) append


* Appendix III -- Comparison with Earlier Results
** Reload data since need larger sample
use C:/Brief/Research/mediabias/FoxNewsFinalDataQJE,clear
*** Generate macros of controls
** Census Controls
foreach tc in "2000" "00m90" {
	global contrcens`tc'= "pop`tc' hs`tc' hsp`tc' college`tc' male`tc' black`tc' hisp`tc' empl`tc' unempl`tc' married`tc' income`tc' urban`tc'"
	global contrcenssh`tc'stat= "pop`tc'stat hsp`tc' college`tc' black`tc' hisp`tc' unempl`tc' urban`tc'"
}
** Cable Controls
foreach tc in "2000" {
	global contrcbl`tc'= "poptot`tc'd2-poptot`tc'd10 noch`tc'd2-noch`tc'd10"
	}
* Unweighted
areg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1, a(diststate) robust cluster(account2000)
outreg foxnews2000 using AppendixIII, title(Appendix III) ctitle(unw,i.dst) se 3aster bdec(4) rdec(4) nocons replace
areg reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if sample12000==1, a(countystate) robust cluster(account2000)
outreg foxnews2000 using AppendixIII, ctitle(unw,i.cst) se 3aster bdec(4) rdec(4) nocons append
* Unweighted + foxnewsmix + Do not clean voting data
areg reppresfv2p00m96 foxnewsmix2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if ((ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & cnn2000==1), a(diststate) robust cluster(account2000)
outreg foxnewsmix2000 using AppendixIII, ctitle(unw,Foxold,measer,i.dst) se 3aster bdec(4) rdec(4) nocons append
areg reppresfv2p00m96 foxnewsmix2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if ((ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & cnn2000==1), a(countystate) robust cluster(account2000)
outreg foxnewsmix2000 using AppendixIII, ctitle(unw,Foxold,measer,i.cst) se 3aster bdec(4) rdec(4) nocons append
* Unweighted + foxnewsmix + Do not clean voting data + Only old States
areg reppresfv2p00m96 foxnewsmix2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if ((ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & cnn2000==1) & state~="Nj" & state~="Hi" & state~="Nd" & state~="Wy", a(diststate) robust cluster(account2000)
outreg foxnewsmix2000 using AppendixIII, ctitle(unw,Foxold,measer,oldst,i.dst) se 3aster bdec(4) rdec(4) nocons append
areg reppresfv2p00m96 foxnewsmix2000 $contrcens2000 $contrcens00m90 $contrcbl2000 if ((ddelect==1 & ddcable==1 & reppresfv2p2000~=. & reppresfv2p1996~=.) & ddcensus==1 & cnn2000==1) & state~="Nj" & state~="Hi" & state~="Nd" & state~="Wy", a(countystate) robust cluster(account2000)
outreg foxnewsmix2000 using AppendixIII, ctitle(unw,Foxold,measer,oldst,i.cst) se 3aster bdec(4) rdec(4) nocons append



* Table V -- Presidential Effects -- Robustness and Presidential Delayed Effects
* Column (5) -- Nearest-neighbour matching
* Calculation takes long -- make sample as small as possible
keep if sample12000==1
keep reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 noch2000 poptot2000 diststate sample12000
xi: nnmatch reppresfv2p00m96 foxnews2000 $contrcens2000 $contrcens00m90 noch2000 poptot2000 i.diststate if sample12000==1, tc(att) m(4) bias(bias)
dsa
*/

* Table VIII -- Persuasion Rates
*** Reshape to compute standard errors for persuasion rate using Stata -- 
*** This takes into account the correlation between the two estimate (audience data and voting data)
gen deppol=reppresfv2p00m96
gen depaud=foxanyScar
reshape long dep, i(town county state) j(depname) string

gen daud=(depname=="aud")
gen dpol=(depname=="pol")

** Fully interact all the variables
foreach tc in "2000" "00m90" {
		foreach z in pop`tc' hs`tc' hsp`tc' college`tc' male`tc' black`tc' hisp`tc' empl`tc' unempl`tc' married`tc' income`tc' urban`tc' {
			gen `z'aud=daud*`z'
			gen `z'pol=dpol*`z'
			}
	global contrcens`tc'aud= "pop`tc'aud hs`tc'aud hsp`tc'aud college`tc'aud male`tc'aud black`tc'aud hisp`tc'aud empl`tc'aud unempl`tc'aud married`tc'aud income`tc'aud urban`tc'aud"
	global contrcens`tc'pol= "pop`tc'pol hs`tc'pol hsp`tc'pol college`tc'pol male`tc'pol black`tc'pol hisp`tc'pol empl`tc'pol unempl`tc'pol married`tc'pol income`tc'pol urban`tc'pol"
	}
foreach tc in "2000" {
	foreach z in noch`tc'd2 noch`tc'd3 noch`tc'd4 noch`tc'd5 noch`tc'd6 noch`tc'd7 noch`tc'd8 noch`tc'd9 noch`tc'd10 {
		gen `z'aud=daud*`z'
		}
	foreach z in noch`tc'd2 noch`tc'd3 noch`tc'd4 noch`tc'd5 noch`tc'd6 noch`tc'd7 noch`tc'd8 noch`tc'd9 noch`tc'd10 {
		gen `z'pol=dpol*`z'
		}
	foreach z in poptot`tc'd2 poptot`tc'd3 poptot`tc'd4 poptot`tc'd5 poptot`tc'd6 poptot`tc'd7 poptot`tc'd8 poptot`tc'd9 poptot`tc'd10 {
		gen `z'aud=daud*`z'
		}
	foreach z in poptot`tc'd2 poptot`tc'd3 poptot`tc'd4 poptot`tc'd5 poptot`tc'd6 poptot`tc'd7 poptot`tc'd8 poptot`tc'd9 poptot`tc'd10 {
		gen `z'pol=dpol*`z'
		}
	global contrcbl`tc'aud="poptot`tc'd2aud-poptot`tc'd10aud noch`tc'd2aud-noch`tc'd10aud"
	global contrcbl`tc'pol="poptot`tc'd2pol-poptot`tc'd10pol noch`tc'd2pol-noch`tc'd10pol"
	}
foreach x in aud pol {
	foreach y in diststate countystate foxnews2000 foxnews2003 {
		gen `y'`x'=`y'*d`x'
		}
	}
foreach y in diststate countystate {
	gen `y'both=10000*`y'pol+`y'aud
	}
gen weight=auddiaryScar if daud==1
replace weight=totpresvotes1996 if dpol==1

*** Persuasion Rates
** Spec. with District f.e. (Table VIII, Column (2))
areg dep daud dpol foxnews2000aud foxnews2000pol $contrcens2000aud $contrcens2000pol $contrcens00m90aud $contrcens00m90pol $contrcbl2000aud $contrcbl2000pol if sample12000==1 [aweight=weight], a(diststateboth) robust cluster(account2000)
display "District f.e., Estimate of Persuasion Rates for (Predicted) Recall Audience"
nlcom 1.024*(_b[foxnews2000pol]/_b[foxnews2000aud])
display "District f.e., Estimate of Persuasion Rates for Diary Audience"
nlcom 1.024*(_b[foxnews2000pol]/_b[foxnews2000aud])/3.42
** Spec. with County f.e. (Table VIII, Column (3))
areg dep daud dpol foxnews2000aud foxnews2000pol $contrcens2000aud $contrcens2000pol $contrcens00m90aud $contrcens00m90pol $contrcbl2000aud $contrcbl2000pol if sample12000==1 [aweight=weight], a(countystateboth) robust cluster(account2000)
display "District f.e., Estimate of Persuasion Rates for (Predicted) Recall Audience"
nlcom 1.024*(_b[foxnews2000pol]/_b[foxnews2000aud])
display "District f.e., Estimate of Persuasion Rates for Diary Audience"
nlcom 1.024*(_b[foxnews2000pol]/_b[foxnews2000aud])/3.42
