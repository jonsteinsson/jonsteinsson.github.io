** REPLICATION DATA FOR DELLAVIGNA AND KAPLAN (QJE, 2007) FOX NEWS PAPER **

Files:

1. FoxNewsDataQJEMay07.dta -- Initial Stata .dta file

2. FoxNewsPrepareQJEMay07.do -- Do file that takes the file FoxNewsDataQJEMay07.dta
   				and transforms it into the final file:

3. FoxNewsFinalDataQJEMay07.dta -- Final ready for the regressions in the paper

4. FoxNewsPrepareQJEMay07.do -- Do file that reproduces all the results in the paper
				(except Table I, for confidentiality reasons)

The variables in the Stata .dta files are labelled. Contact the authors for any
further explanation.

