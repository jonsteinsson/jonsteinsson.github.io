"PAYING NOT TO GO TO THE GYM"

*** Stata FILE DataGymAERMar06.do ***

Explanation of selected variables and values.
Alphabetical by variable name.

club � one of the three health clubs
=11 corresponds to club 1 in the paper
=13 corresponds to club 2 in the paper
=16 corresponds to club 3 in the paper

begsp2 - spell number
=1 if it is the first spell
=2 if it is the second or a later spell
=3 if free attendances before start of spell

contrac2 - simplified contract type
=1 if monthly contract
=2 if yearly contract

contract - detailed contract type (CHECK: needs to be checked)
=0 if no contract
=1 if monthly
=2 if annual
=7 if contract frozen or cancelled in the middle of month
=11 if pro-rated monthly (1st month of a monthly)
=14* if first month of a montly with some attendances before(due to short-term contracts)
=15** if last month of a monthly with some attendances after (due to short-term contracts)
=19*** if both 14 and 15 (rare)
=111 if first month of a monthly, but with no payment (i.e. promotional)
=20 if at most two months of transition (with no payment) between end of annual contract and subsequent contract
=21 if pro-rated annual (first or last month of an annual)
=24* if first month of an annual with some attendances before (due to short-term contracts)
=25** if last month of an annual with some attendances after (due to short-term contracts)
=27 if annual contract is frozen
=70 if defaulted (cancelled due to non-payment for the month)
=77 if intervening month between two contracts with no payment (usually only one month)

endatt - the last month in which attendance is observed

endcontp � the last month in which contract data is observed

endcont - the month before (CHECK: the month before endcontp??)

endsp2 - indicator of the end of a spell
=2 is a spell that continues with some free attendances
=3 is a censoring indicator

spellprob � unusual circumstances within a spell, usually with yearly spells.
=600 - very problematic contracts, yearly mixed with monthly
=10 - individual with short-term monthly contracts and grp==1

time - first day of the month in MATLAB notation


* NOTE: included in "left-censored" spells
** NOTE: included in "right-censored" spells
*** NOTE: included in both "right-censored" and "left-censored" spells



*** Matlab FILE SimulationCancellation.do ***

This files simulates the cancellation behavior for exponential, sophisticated, and naive agents
The file requires the subroutines fun_sop and fun_exp

