
*Output the list of 10 states that are most sensitive to aggregate military buildups

clear all
set memory 300000
set more off
set logtype text
capture log close 

* NOTE: You need to fix local statements in preamble do file also!!
*local dircode "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\do files\"
*local dirout "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
*local dirlog "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

local dircode "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\do files\"
local dirout "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
local dirlog "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"


log using "`dirlog'Table I", replace text

******************************************************
***** Prepare for regressions in Table II, Row 1 *****
do "`dircode'Table II_III Row 1 preamble_states.do"
******************************************************

***********************************************************
* First Stage Regression
***********************************************************
xi: areg Drcapspend, absorb(state)
predict dem_Drcapspend, resid

xi: areg Drcapspend i.statenum*Drcapspend_nat, absorb(year)
predict dem_Drcapspend_pred, xbd

exit

* save the coefficients on (state dummies)*(aggregate spendings)
foreach i of numlist 2(1)51 {

	local b`i' = _b[_IstaXDrca_`i']
	
}


*** create a list that order the states by sensitivity to aggregate buildups
preserve

	clear
	set obs 51
	gen coeff = .
	gen statenumber = .
	foreach i of numlist 2(1)51 {
		local j = `i' - 1
		replace coeff = `b`i'' in  `j'
		replace statenumber = `i' in  `j'
	}
	
	* sort coefficients from the largest to the smallest
	gsort -coeff
	* generate their ranks 
	g order = _n
	* only keep the top 10
	drop if order>10
	
	tempfile top10
	sa `top10', replace

restore


*** find the state names corresponding to the list of 10
keep state 
duplicates drop  
g statenumber = _n
merge 1:1 statenumber using `top10'
keep if _merge==3
drop _merge

*** sort by descending order
sort order
list state


log close
