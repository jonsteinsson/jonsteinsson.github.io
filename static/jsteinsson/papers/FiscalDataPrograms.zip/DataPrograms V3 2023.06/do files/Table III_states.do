
*State fiscal regressions

clear all
set memory 300000
set more off
set logtype text
capture log close 

* NOTE: You need to fix local statements in preamble do file also!!
*local dircode "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\do files\"
*local dirout "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
*local dirlog "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

local dircode "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\do files\"
local dirout "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
local dirlog "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

log using "`dirlog'Table III_states", replace text


*******************************************************
***** Prepare for regressions in Table III, Row 1 *****
do "`dircode'Table II_III Row 1 preamble_states.do"
*******************************************************

* fed funds rate - state level CPI *
xi: ivregress 2sls Dcpi_state (Drcapspend = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
predict Dcpi_state_pred, xb
gen Dcpi_state_impute = Dcpi_state
replace Dcpi_state_impute = Dcpi_state_pred if Dcpi_state==.
tsset statenum year
replace realint = fedfunds - F.Dcpi_state_impute

* fed funds rate - aggregate CPI *
g realint2 = fedfunds - cpi

***********************************************************
* Regressions with Alternative Specifications
***********************************************************

***** Output - Level Instruments, Predetermined *****
xi: ivregress 2sls Drcapout (Drcapspend  = Dpredict_spend2) i.year i.statenum
estat firststage

xi: ivregress 2sls Drcapout (Drcapspend  = Dpredict_spend2) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 1_states",word se bdec(2) replace

***** Employment - Level Instruments, Predetermined *****
xi: ivregress 2sls Demp (Drcapspend  = Dpredict_spend2) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 1_states",word se bdec(2) append

***** Output per Working Age *****
xi: ivregress 2sls Drcapout_work (Drcapspend_work  = i.statenum*Drcapspend_nat_work) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend_work using "`dirout'Table III Row 1_states",word se bdec(2) append

***** Output - OLS ******
xi: areg  Drcapout Drcapspend i.year , absorb(state) vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 1_states",word se bdec(2) append

***** State Output w/ Oil *****
xi: ivregress 2sls Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum*Doilprice, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 1_states",word se bdec(2) append

***** State Output w/ Monetary Policy *****
*xi: ivregress 2sls Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum*realint, vce(cl statenum)
*outreg2 Drcapspend using "`dirout'Table III Row 1_states",word se bdec(2) append

*aggregate real interest rate
xi: ivreg2 Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum*realint2, partial(i.year i.statenum _IstaXreal*) cl(statenum)
outreg2 Drcapspend using "`dirout'Table III Row 1_states",word se bdec(2) append

***** State Output -- LIML *****
xi: ivregress liml Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 1_states",word se bdec(2) append

***** BEA Employment  *****
xi: ivregress 2sls  Dempbea (Drcapspend= i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 1_states",word se bdec(2) append



*******************************************************
***** Prepare for regressions in Table III, Row 2 *****
do "`dircode'Table II_III Row 2 preamble_states.do"
*******************************************************

* fed funds rate - state level CPI *
xi: ivregress 2sls Dcpi_state (Drcapspend = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
predict Dcpi_state_pred, xb
gen Dcpi_state_impute = Dcpi_state
replace Dcpi_state_impute = Dcpi_state_pred if Dcpi_state==.
tsset statenum year
replace realint = fedfunds - F.Dcpi_state_impute

* fed funds rate - aggregate CPI *
g realint2 = fedfunds - cpi

***********************************************************
* Regressions with Alternative Specifications
***********************************************************

***** Output - Level Instruments, Predetermined *****
xi: ivregress 2sls Drcapout (Drcapspend  = Dpredict_spend2) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 2_states",word se bdec(2) replace

***** Employment - Level Instruments, Predetermined *****
xi: ivregress 2sls Demp (Drcapspend  = Dpredict_spend2) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 2_states",word se bdec(2) append

***** Output per Working Age *****
xi: ivregress 2sls Drcapout_work (Drcapspend_work  = i.statenum*Drcapspend_nat_work) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend_work using "`dirout'Table III Row 2_states",word se bdec(2) append

***** Output - OLS ******
xi: areg  Drcapout Drcapspend i.year , absorb(state) vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 2_states",word se bdec(2) append

***** State Output w/ Oil *****
xi: ivreg2 Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum*Doilprice, partial(i.year i.statenum _IstaXDoil*) cl(statenum)
outreg2 Drcapspend using "`dirout'Table III Row 2_states",word se bdec(2) append

***** State Output w/ Monetary Policy *****
*xi: ivreg2 Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum*realint, cl(statenum)
*outreg2 Drcapspend using "`dirout'Table III Row 2_states",word se bdec(2) append

* aggregate real interst rate
xi: ivreg2 Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum*realint2, partial(i.year i.statenum _IstaXreal*) cl(statenum)
outreg2 Drcapspend using "`dirout'Table III Row 2_states",word se bdec(2) append

***** State Output -- LIML *****
xi: ivregress liml Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 2_states",word se bdec(2) append

***** BEA Employment  *****
xi: ivregress 2sls  Dempbea (Drcapspend= i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table III Row 2_states",word se bdec(2) append





