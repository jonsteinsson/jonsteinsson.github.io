
* File for reading in data and defining variables for biannual state case

clear
set more off

*local dir1 "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\coded data\"
*local dir2 "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\for regressions\"

local dir1 "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\coded data\"
local dir2 "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\for regressions\"

u "`dir1'fiscal_stimulus_coded.dta", clear

***********************************************************
* Clean Dataset
***********************************************************

**** Deal with state names
drop if state==""
drop if state=="US" | state=="Puerto Rico" | state=="Virgin Island"

drop if year==2007
drop if year<1966 

***********************************************************
* Select Output, Employment, Spending amd
* Population Variable to Use
***********************************************************

**** Select Output Variable
gen out = Total_GSP*10^6
*gen out = state_output*10^3
*gen out = spi*10^3

**** Select Employment Variable
** Employment from CES (BLS establishment survey)
gen emp = employ_CES*1000
** Employment from BEA (1969-2006)
*gen emp = beaemp
** Employment from CPS (1976-2006)
*gen emp = employment_CPS
** Covered employment
*gen emp = CE

**** Select Spending Variable
gen spend = totalpma
*gen spend = totalpma + mil*1000

**** Select Population Variable for Per Capita Use
gen pop = population
*gen pop = pop_working

**** Select Population Variable for Use as Dependent Variable
gen popyy = population
*gen popyy = pop_working

***********************************************************
* Aggregate to Regions
***********************************************************

egen statenum = group(state)
tsset statenum year  

**** Create state groupings
gen stategroup= .
local list1 = "CT MA ME NH RI VT"
local list2 = "NY NJ PA"
local list3 = "DC DE MD VA WV"
local list4 = "NC SC GA FL"
local list5 = "MI OH IL IN WI"
local list6 = "TN AL MS KY"
local list7 = "TX OK LA AR"
local list8 = "MO KS IA NE MN SD ND"
local list9 = "CO AZ NM UT NV WY MT ID"
local list10 = "CA WA OR AK HI"

foreach listnum of numlist 1(1)10 {
	local temp = "list`listnum'"
	foreach statename of local `temp' {
	quietly: replace stategroup = `listnum' if state=="`statename'"
	}
}

**** Convert to regional analysis
collapse (sum) out spend gvtvalueshipment pop pop_working popyy emp beaemp *GSP_NAICS *GSP_SIC (mean) iur iur_nat unemploymentrate cpi oilprice stock_return fedfunds emp_pop_hp iur_hp, by(stategroup year)
rename stategroup state
gen statenum = state
gen emp_pop = emp/pop


foreach var of varlist * {
replace `var' = . if `var'==0
}
	
tsset statenum year

***********************************************************
* Input CPI variables and select one to use
***********************************************************

**** Merge Del Negro CPI data 
sort statenum year
merge statenum year using "`dir1'cpi_delnegro_reg"
drop _merge

**** Merge NS data 
sort statenum year
merge statenum year using "`dir1'cpi_regional2"
drop _merge

**** Merge ACCRA CPI data 
sort statenum year
merge statenum year using "`dir1'cpi_ACCRA_reg"
drop if _merge==2
drop _merge

**** Fisher-Peters instruments
bysort year: egen temp = mean(stock_return)
replace stock_return = temp
drop temp

drop if year>2006

*keep statenum year Dcpi Dcpi_delneg Dcpi_regNS Dcpi_ACCRA
*hi

****Fill in missing data
*replace Dcpi_ACCRA = Dcpi_regNS if year<=1995
replace Dcpi_ACCRA = Dcpi_delneg if year<=1995

**** Choose CPI variable to use
gen Dcpi_state = Dcpi_ACCRA
*gen Dcpi_state = Dcpi_delneg
*gen Dcpi_state = Dcpi_regNS

***********************************************************
* Create Relevant Variables
***********************************************************

tsset statenum year

**** Per capita output growth (in levels, not logs)
gen rout = out/cpi
	la var rout "real output"
gen rcapout = rout/(pop)
	la var rcapout "real output per capita"
gen rcapout_work = rout/pop_working
	la var rcapout_work "real output per working age"    // for alternative specifications
gen Drcapout_work = (rcapout_work - l2.rcapout_work)/l2.rcapout_work
	la var Drcapout_work "percent change of real output per working age (L2)" // for alternative specifications
gen Drcapout = (rcapout - l2.rcapout)/l2.rcapout
	la var Drcapout "percent change of real output per capita (L2)"
gen Drout = (rout - l2.rout)/l2.rout
	la var Drout "percent change of real output (L2)"
gen Drcapout_lev = (rcapout - l2.rcapout)
	la var Drcapout_lev "level change of real output per capita (L2)"
gen Drout_lev = (rout - l2.rout)
	la var Drout_lev "level change of real output (L2)"
	

**** Per capita pma growth
gen rspend = spend/cpi
	la var rspend "real spending"
gen rcapspend = rspend/pop
	la var rcapspend "real spending per capita"
gen rcapspend_work = rspend/pop_working             //for alternative specifications
	la var rcapspend_work "real spending per working age"
gen Drcapspend_work = (rcapspend_work - l2.rcapspend_work)/l2.rcapout_work  //for alternative specifications
	la var Drcapspend_work "real spending change as % of real output (work) (L2)"
gen Drcapspend = (rcapspend - l2.rcapspend)/l2.rcapout
	la var Drcapspend "real p.c.spending change as % of real p.c. output (L2)"
gen Drspend = (rspend - l2.rspend)/l2.rout
	la var Drspend "real spending change as % of real output (L2)"
gen Drcapspend_lev = (rcapspend - l2.rcapspend)
	la var Drcapspend_lev "level change of real spending per capita (L2)"
gen Drspend_lev = (rspend - l2.rspend)
	la var Drspend_lev "level change of real spendding (L2)"

**** Total national out and population
bysort year: egen rout_nat = sum(rout)
	la var rout_nat "national total real output"
bysort year: egen pop_nat = sum(pop)
	la var pop_nat "national total population"
bysort year: egen pop_nat_work = sum(pop_working)
	la var pop_nat_work "national total working population"	  //alternative
bysort year: egen popyy_nat = sum(popyy)
	la var popyy_nat "national total population"
tsset statenum year  
gen rcapout_nat = rout_nat/pop_nat
	la var rcapout_nat "real national output/national population"
gen rcapout_nat_work = rout_nat/pop_nat_work
	la var rcapout_nat_work "real national output/national working age opulation"  //alternative
	
gen Drcapout_nat = (rcapout_nat-l2.rcapout_nat)/ l2.rcapout_nat
	la var Drcapout_nat "% change of real national output per capita (L2)"
gen Drout_nat = (rout_nat-l2.rout_nat)/ l2.rout_nat
	la var Drout_nat "% change of real output (L2)"

**** Total national spending and population
bysort year: egen rspend_nat = sum(rspend)
	la var rspend_nat "total national spendings"
tsset statenum year  
gen rcapspend_nat = rspend_nat/pop_nat
	la var rcapspend_nat "total national real spending per capita"
gen Drcapspend_nat = (rcapspend_nat - l2.rcapspend_nat)/l2.rcapout_nat
	la var Drcapspend_nat "change of national real p.c. spending as % of real national output p.c. (L2)"
tsset statenum year  	
gen rcapspend_nat_work = rspend_nat/pop_nat_work
	la var rcapspend_nat_work "total national real spending per capita (working pop)"    //alternative
gen Drcapspend_nat_work = (rcapspend_nat_work - l2.rcapspend_nat_work)/l2.rcapout_nat_work
	la var Drcapspend_nat_work "change of national real (work) p.c. spending as % of real national output p.c. (L2)"  //alternative

gen Drspend_nat = (rspend_nat - l2.rspend_nat)/l2.rout_nat
	la var Drspend_nat "change of national real spending as % of real national output (L2)"
gen Drcapspend_nat_lev = (rcapspend_nat - l2.rcapspend_nat)
	la var Drcapspend_nat_lev "change of national reap p.c. spending (L2)"
gen Drspend_nat_lev = (rspend_nat - l2.rspend_nat)
	la var Drspend_nat_lev "change of national real spending (L2)"

**** Population
gen Dpop = (popyy-l2.popyy)/l2.popyy
	la var Dpop "% change of population (L2)"
gen Dpop_nat = (popyy_nat-l2.popyy_nat)/l2.popyy_nat
	la var Dpop_nat "% change of total national population (L2)"

**** Employment
gen emprate = emp/pop
	la var emprate "employment rate"
gen Demprate = emprate - l2.emprate
	la var Demprate "change in employment rate (L2)"
gen Demp = (emp/pop - l2.emp/l2.pop)/(l2.emp/l2.pop)
	la var Demp "% change in employment rate (L2)"
gen Dempbea = (beaemp/pop - l2.beaemp/l2.pop)/(l2.beaemp/l2.pop)    //for alternative specification
	la var Dempbea "% change in BEA employment rate (L2)"
gen nonemprate = (pop-emp)/pop
	la var nonemprate "non-employment rate"
gen Dnonemprate = nonemprate - l2.nonemprate
	la var Dnonemprate "change in non-employment rate (L2)"

**** BEA Unemployment
gen iur2 = iur/100
	la var iur2 "insured unemployment rate"
gen Diur2 = iur2 - l2.iur2
	la var Diur2 "change of insured unemployment rate (L2)"
gen unemp = unemploymentrate/100
	la var unemp "unemployment rate"
gen Dunemp = unemp - l2.unemp
	la var Dunemp "change of unemployment rate (L2)"

**** Subcontracting stuff
gen purchases =  gvtvalueshipment * 10^6
	la var purchases "value of government purchases"
gen Dpurchases= purchases - l2.purchases
	la var Dpurchases "change in government purchases (L2)"
gen Dspend = spend - l2.spend
	la var Dspend "change in spending (L2)"

**** Fisher-Peters Stock Returns
tsset statenum year
gen Dstock_return = (stock_return - l2.stock_return)/l2.stock_return
	la var Dstock_return "% change in stock return (L2)"

**** Fraction of total military expenditures and predicted military expenditures
*gen temp = rcapspend/rcapspend_nat
*bysort state: egen fracmil = mean(temp)
*drop temp
*gen Dpredict_spend = Drcapspend_nat * fracmil

**** Fraction of total military expenditures and predicted military expenditures
bysort state: egen temp = mean(rcapspend)
bysort state: egen temp2 = mean(rcapspend_nat)
gen fracmil = temp/temp2
	la var fracmil "state real p.c. spendings as % of national"
drop temp*
gen Dpredict_spend = Drcapspend_nat * fracmil
	la var Dpredict_spend "predicted military expenditures"

***** Predetermined Fraction of Military Spending
bysort state: egen temp = mean(rcapspend) if year < 1972 & year > 1965
bysort state: egen avrcapspend = mean(temp) if year > 1959
	la var avrcapspend "average per capita spendings"
bysort state: egen temp2 = mean(rcapspend_nat) if year < 1972 & year > 1965
bysort state: egen avrcapspend_nat = mean(temp2) if year > 1959
	la var avrcapspend_nat "average national per capita spendings"
tsset statenum year
gen fracmil2 = avrcapspend/avrcapspend_nat
	la var fracmil2 "% of state averate per capita spendings"
gen Dpredict_spend2 = Drcapspend_nat * fracmil2
	la var Dpredict_spend2 "predicted military expenditures 2"
gen Dpredict_return = Dstock_return * fracmil2
	la var Dpredict_return "predicted stock return"
drop temp*

***** For alternative speficications: Predetermined Fraction of Military Spending
bysort state: egen temp = mean(rcapspend_work) if year < 1972 & year > 1965
bysort state: egen avrcapspend_work = mean(temp) if year > 1959
	la var avrcapspend "average per working age spendings"
tsset statenum year
gen fracmil2_work = avrcapspend_work/avrcapspend_nat
	la var fracmil2_work "% of state averate per capita spendings"
gen Dpredict_spend2_work = Drcapspend_nat * fracmil2_work
drop temp*


**** Oil Price Variable
tsset statenum year
gen temp = log(oilprice/cpi)
gen Doilprice = D.temp
	la var Doilprice "change in real oil price"
drop temp

**** Real interest rate
gen realint= fedfunds - Dcpi_state
	la var realint "real interest rate"

****Aggregate CPI
tsset statenum year
gen Dcpi = (cpi- L2.cpi)/L2.cpi
	la var Dcpi "% change of CPI (L2)"

**** Slackness variables
foreach var of varlist iur emp_pop iur_hp emp_pop_hp iur_nat {
	bysort state: egen temp = mean(`var') if year>=1966 & year<=2006
	gen slack_`var' = `var' - temp
	drop temp
}
	la var slack_iur "slackness of insured unemployment rate"
	la var slack_emp_pop "slackness of CES employment/population ratio"
	la var slack_iur_hp "slackness of HP filtered insured unemployment rate"
	la var slack_emp_pop_hp "slackness of HP filtered CES emp/pop ratio"
	la var slack_iur_nat "slackness of national insured unemployment rate"
	
**** Mean Fraction Construction/Mean Insured Unemployment Rate
gen fracconst = Const_GSP_NAICS/ Total_GSP_NAICS
replace fracconst = Const_GSP_SIC/ Total_GSP_SIC if fracconst == .
	la var fracconst "fraction of construction"
bysort state: egen meanfracconst = mean(fracconst)
	la var meanfracconst "mean of fraction of construction"
bysort state: egen meaniur = mean(iur)
	la var meaniur "mean of insured unemployment rate"

**** Mean Population
bysort state: egen avpop = mean(pop)
	la var avpop "mean population"

drop if year>2006

**** Save file
tsset statenum year  
save "`dir2'regionfiscal", replace

***********************************************************
* Make biannual

rename spend spendold
gen spend = (spendold + l.spendold)/2
	la var spend "biannual spendings"
rename purchases purchasesold
gen purchases = (purchasesold + l.purchasesold)/2
	la var purchases "biannual purchases"

**** NOTICE: Level variables need to be averaged (two years) if they are to be kept *****

keep year state statenum rcapspend_nat fracmil fracmil2 realint fedfunds rcapout Drcapout Drcapout_work Drout Drcapout_nat Drout_nat Drcapout_lev Drout_lev Drcapspend Drcapspend_work Drcapspend_nat_work Drspend Drcapspend_lev Drspend_lev Drcapspend_nat Drspend_nat Drcapspend_nat_lev Drspend_nat_lev Dpop Dpop_nat Demprate Demp Dempbea Dnonemprate Dunemp Dpurchases Dspend Dpredict_spend Dpredict_spend2 Dpredict_spend2_work Dstock_return spend purchases Dcpi cpi Dcpi_state Doilprice Dpredict_return stock_return slack* meanfracconst meaniur avpop

**** Save file
tsset statenum year  
save "`dir2'regionfiscal_bi", replace

*gen odd = mod(year,2)
*keep if odd == 0
*drop odd
*tsset statenum year
