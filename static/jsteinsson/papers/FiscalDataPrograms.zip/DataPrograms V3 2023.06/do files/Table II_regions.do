
*Region fiscal regressions

clear all
set memory 300000
set more off
set logtype text
capture log close 

* NOTE: You need to fix local statements in fiscal_bi_reg2_preamble also!!
*local dircode "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\do files\"
*local dirout "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
*local dirlog "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

local dircode "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\do files\"
local dirout "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
local dirlog "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"


log using "`dirlog'Table II_regions", replace text

******************************************************
***** Prepare for regressions in Table II, Row 1 *****
do "`dircode'Table II_III Row 1 preamble_regions.do"
******************************************************

***********************************************************
* First Stage Regression
***********************************************************

xi: areg Drcapspend, absorb(state)
predict dem_Drcapspend, resid

xi: areg Drcapspend i.statenum*Drcapspend_nat, absorb(year)
predict dem_Drcapspend_pred, xbd

***********************************************************
* Regressions with instruments
***********************************************************

***** State Output *****
xi: ivregress 2sls Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum
estat firststage

xi: ivregress 2sls Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table II Row 1_regions",word se bdec(2) replace

***** State Output Deflated by CPI *****
* 2nd version: Impute first few values using fitted values from CPI equation
xi: ivregress 2sls Dcpi_state (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
predict Dcpi_state_pred, xb
gen Dcpi_state_impute = Dcpi_state
replace Dcpi_state_impute = Dcpi_state_pred if Dcpi_state==.
gen Drcaprout2 = (1 + Drcapout)/(1+ Dcpi_state_impute) -1
xi: ivregress 2sls Drcaprout2 (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table II Row 1_regions",word se bdec(2) append

***** Employment *****
xi: ivregress 2sls  Demp (Drcapspend= i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table II Row 1_regions",word se bdec(2) append

***** CPI *****
xi: ivregress 2sls Dcpi_state (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table II Row 1_regions",word se bdec(2) append


******************************************************
***** Prepare for regressions in Table II, Row 2 *****
do "`dircode'Table II_III Row 2 preamble_regions.do"
******************************************************

***********************************************************
* First Stage Regression
***********************************************************

xi: areg Drcapspend, absorb(state)
predict dem_Drcapspend, resid

xi: areg Drcapspend i.statenum*Drcapspend_nat, absorb(year)
predict dem_Drcapspend_pred, xbd

***********************************************************
* Regressions with instruments
***********************************************************

***** State Output *****
xi: ivregress 2sls Drcapout (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table II Row 2_regions",word se bdec(2) replace

***** State Output Deflated by CPI *****
* 2nd version: Impute first few values using fitted values from CPI equation
xi: ivregress 2sls Dcpi_state (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
predict Dcpi_state_pred, xb
gen Dcpi_state_impute = Dcpi_state
replace Dcpi_state_impute = Dcpi_state_pred if Dcpi_state==.
gen Drcaprout2 = (1 + Drcapout)/(1+ Dcpi_state_impute) -1
xi: ivregress 2sls Drcaprout2 (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table II Row 2_regions",word se bdec(2) append

***** Employment *****
xi: ivregress 2sls  Demp (Drcapspend= i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table II Row 2_regions",word se bdec(2) append

***** CPI *****
xi: ivregress 2sls Dcpi_state (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
outreg2 Drcapspend using "`dirout'Table II Row 2_regions",word se bdec(2) append

log close


