/* Program to call in create_delnegro_data_2010.12.13.do
			    create_accra_data_2010.12.13.do
			    create_inflation_data_2010.12.13.do
Then merge with Fiscal_stimulus_2010.12.07.dta for
1. state version: fiscal_region_orig 
2. run regressions for sector by region
*/
set logtype text
set more off
capture log close

*local dir1 "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\coded data\"
*local dirout "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
*local dirlog "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

local dir1 "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\coded data\"
local dirout "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
local dirlog "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

log using "`dirlog'Table IV_regions", replace text


u "`dir1'fiscal_stimulus_coded.dta", clear

***********************************************************
* Clean Dataset
***********************************************************

**** Deal with state names
drop if state==""
drop if state=="US" | state=="Puerto Rico" | state=="Virgin Island"

drop if year>2006
drop if year<1966

***********************************************************
* Select Output, Employment, Spending amd
* Population Variable to Use
***********************************************************
***********************************************************

**** Select Output Variable
gen out = Total_GSP*10^6
*gen out = state_output*10^3
*gen out = spi*10^3


**** Select Spending Variable
gen spend = totalpma
*gen spend = totalpma + military*1000

**** Select Population Variable for Per Capita Use
gen pop = population
*gen pop = pop_working


***********************************************************
* Aggregate to Regions
***********************************************************

egen statenum = group(state)
tsset statenum year  

**** Create state groupings
gen stategroup= .
local list1 = "CT MA ME NH RI VT"
local list2 = "NY NJ PA"
local list3 = "DC DE MD VA WV"
local list4 = "NC SC GA FL"
local list5 = "MI OH IL IN WI"
local list6 = "TN AL MS KY"
local list7 = "TX OK LA AR"
local list8 = "MO KS IA NE MN SD ND"
local list9 = "CO AZ NM UT NV WY MT ID"
local list10 = "CA WA OR AK HI"

foreach listnum of numlist 1(1)10 {
	local temp = "list`listnum'"
	foreach statename of local `temp' {
	quietly: replace stategroup = `listnum' if state=="`statename'"
	}
}
**** Weigh the growth rate by the share for each industry
tsset statenum year
foreach sector in Mining Const Agri Manuf transportation Wholesale Retail fire services fed_civi fed_mil gov state_local educ health{
	bysort year stategroup: egen `sector'_totaloutput_NAICS = sum(`sector'_GSP_NAICS) if year>=1997
	bysort year stategroup: egen `sector'_totaloutput_SIC = sum(`sector'_GSP_SIC) if year<=1997
	
}

tsset statenum year

foreach sector in Mining Const Agri Manuf transportation Wholesale Retail fire services fed_civi fed_mil gov state_local educ health{
	gen `sector'_outputshare = `sector'_GSP_NAICS/`sector'_totaloutput_NAICS if year>1997
	replace `sector'_outputshare = `sector'_GSP_SIC/`sector'_totaloutput_SIC if year<=1997
	gen D`sector'_GSP_reg_adj = 1/2*D`sector'_GSP*(`sector'_outputshare[_n-2]+`sector'_outputshare[_n])
}

tsset statenum year


**** Convert to regional analysis
collapse (sum) out spend gvtvalueshipment pop D*adj (mean) iur unemploymentrate cpi, by(stategroup year)
rename stategroup state
gen statenum = state

foreach var of varlist * {
replace `var' = . if `var'==0
}
	
tsset statenum year


***********************************************************
* Input CPI variables and select one to use
***********************************************************

**** Merge Del Negro CPI data 
sort statenum year
merge statenum year using "`dir1'cpi_delnegro_reg"
drop _merge

**** Merge NS data 
sort statenum year
merge statenum year using "`dir1'cpi_regional2"
drop _merge

**** Merge ACCRA CPI data 
sort statenum year
merge statenum year using "`dir1'cpi_ACCRA_reg"
drop if _merge==2
drop _merge

drop if year>2006

*keep statenum year Dcpi Dcpi_delneg Dcpi_regNS Dcpi_ACCRA
*hi

****Fill in missing data
*replace Dcpi_ACCRA = Dcpi_regNS if year<=1995
replace Dcpi_ACCRA = Dcpi_delneg if year<=1995
*replace Dcpi_delneg = Dcpi_regNS if Dcpi_delneg==.

**** Choose CPI variable to use
gen Dcpi_state = Dcpi_ACCRA
*gen Dcpi_state = Dcpi_regNS
*gen Dcpi_state = Dcpi_delneg

***********************************************************
* Create Relevant Variables
***********************************************************

tsset statenum year

**** Per capita output growth (in levels, not logs)
gen rout = out/cpi
gen rcapout = rout/(pop)
gen Drcapout = (rcapout - l2.rcapout)/l2.rcapout
gen Drout = (rout - l2.rout)/l2.rout

**** Per capita pma growth
gen rspend = spend/cpi
gen rcapspend = rspend/pop
gen Drcapspend = (rcapspend - l2.rcapspend)/l2.rcapout
gen Drspend = (rspend - l2.rspend)/l2.rout

**** Total national out and population
bysort year: egen rout_nat = sum(rout)
bysort year: egen pop_nat = sum(pop)
tsset statenum year  
gen rcapout_nat = rout_nat/pop_nat
gen Drcapout_nat = (rcapout_nat-l2.rcapout_nat)/ l2.rcapout_nat
gen Drout_nat = (rout_nat-l2.rout_nat)/ l2.rout_nat

**** Total national spending and population
bysort year: egen rspend_nat = sum(rspend)
tsset statenum year  
gen rcapspend_nat = rspend_nat/pop_nat
gen Drcapspend_nat = (rcapspend_nat - l2.rcapspend_nat)/l2.rcapout_nat
gen Drspend_nat = (rspend_nat - l2.rspend_nat)/l2.rout_nat

drop if year>2006

*** REAL sector output growth per capita
* Biannual inflation rate and population growth rate
	 gen Dcpi = (cpi/l2.cpi)-1
	 gen Dpop = pop/l2.pop-1
    
    * Select sectors
	foreach sector in Mining Const Agri Manuf transportation Wholesale Retail fire services fed_civi fed_mil gov state_local educ health{
		gen Drcap`sector'_output = (1+D`sector'_GSP)/((1+Dcpi)*(1+Dpop))-1
	}


tsset statenum year  

***********************************************************
* Make biannual

rename spend spendold
gen spend = (spendold + l.spendold)/2

**** NOTICE: Level variables need to be averaged (two years) if they are to be kept *****

keep year state statenum  Drcap* Drcapout Drout Drcapout_nat Drout_nat Drcapspend Drspend Drcapspend_nat Drspend_nat  
*gen odd = mod(year,2)
*keep if odd == 0
*drop odd
*tsset statenum year

*************************************
************ REGRESSION *************
*************************************

tsset statenum year

* Sectors
foreach sector in Const Manuf Retail services Wholesale Mining Agri transportation fire  gov fed_mil {

	if "`sector'" == "Const" {
		xi: ivregress 2sls  Drcap`sector'_output (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
		outreg2 Drcapspend using "`dirout'Table IV_regions",word se bdec(2) replace
	}
	else {
		xi: ivregress 2sls  Drcap`sector'_output (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
		outreg2 Drcapspend using "`dirout'Table IV_regions",word se bdec(2) append
	}
}



log close
