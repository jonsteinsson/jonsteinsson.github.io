
/*This do file 1. generate the weights of sectors as in the first column of Table IV
               2. does states analysis as in the second column of Table IV
*/


capture log close
set more off
clear all

*local dir1 "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\coded data\"
*local dirout "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
*local dirlog "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

local dir1 "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\coded data\"
local dirout "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
local dirlog "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

log using "`dirlog'Table IV_states", replace text


***********************************************************
* Generate the Weights used in the first column
***********************************************************
u "`dir1'outputshare.dta", clear
quietly{
foreach sector in Const Manuf Retail services Wholesale Mining Agri transportation fire gov fed_mil {

	sum `sector'_GSP_share
	local `sector'_share = r(mean)
	noi di "Weight of `sector': " ``sector'_share'

}
}

u "`dir1'fiscal_stimulus_coded.dta", clear

***********************************************************
* Clean Dataset
***********************************************************

**** Deal with state names
drop if state==""
drop if state=="US" | state=="Puerto Rico" | state=="Virgin Island"

drop if year>2006
drop if year<1966


********************************
* REGRESSION PREPARATION
********************************
egen statenum = group(state)
tsset statenum year

* Calculate the biannual growth rate in real terms for sector output per capita
	
	* Biannual inflation rate and population growth rate
	 gen Dcpi = (cpi/l2.cpi)-1
	 gen pop = population
	 gen Dpop = pop/l2.pop-1
    
    * Select sectors
	foreach sector in Mining Const Agri Manuf transportation Wholesale Retail fire services fed_civi fed_mil gov state_local educ health{
		gen Drcap`sector'_output = (1+D`sector'_GSP)/((1+Dcpi)*(1+Dpop))-1
	}

* Select Total GSP, and PMA spending 
		
		gen out = Total_GSP*10^6 

		gen spend = totalpma

		**** Per capita output growth (in levels, not logs)
		gen rout = out/cpi
		gen rcapout = rout/(pop)
		gen Drcapout = (rcapout - l2.rcapout)/l2.rcapout
		gen Drout = (rout - l2.rout)/l2.rout

		**** Per capita pma growth
		gen rspend = spend/cpi
		gen rcapspend = rspend/pop
		gen Drcapspend = (rcapspend - l2.rcapspend)/l2.rcapout
		gen Drspend = (rspend - l2.rspend)/l2.rout

		* Calculate total national spending per capita
		bysort year: egen rout_nat = sum(rout)
		bysort year: egen pop_nat = sum(pop)
		tsset statenum year  

		gen rcapout_nat = rout_nat/pop_nat
		gen Drcapout_nat = (rcapout_nat-l2.rcapout_nat)/ l2.rcapout_nat
		gen Drout_nat = (rout_nat-l2.rout_nat)/ l2.rout_nat

		tsset statenum year  
		bysort year: egen rspend_nat = sum(rspend)
		tsset statenum year  
		gen rcapspend_nat = rspend_nat/pop_nat
		gen Drcapspend_nat = (rcapspend_nat - l2.rcapspend_nat)/l2.rcapout_nat
		gen Drspend_nat = (rspend_nat - l2.rspend_nat)/l2.rout_nat

********* make biannual for spending
tsset statenum year
rename spend spendold 
gen spend = (spendold+ l.spendold)/2

*keep Dr* spend year state statenum
tsset statenum year

*************************************
************ REGRESSION *************
*************************************
	
* Sectors
foreach sector in Const Manuf Retail services Wholesale Mining Agri transportation fire  gov fed_mil {

	if "`sector'" == "Const" {
		xi: ivregress 2sls  Drcap`sector'_output (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
		outreg2 Drcapspend using "`dirout'Table IV_states",word se bdec(2) replace
	}
	else {
		xi: ivregress 2sls  Drcap`sector'_output (Drcapspend  = i.statenum*Drcapspend_nat) i.year i.statenum, vce(cl statenum)
		outreg2 Drcapspend using "`dirout'Table IV_states",word se bdec(2) append
	}
}


log close
