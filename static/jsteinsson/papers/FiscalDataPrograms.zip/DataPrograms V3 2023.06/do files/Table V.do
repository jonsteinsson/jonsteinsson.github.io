
*** This do file creates results in Table V ***
*** Use states data only. To create the data set, use preamble for Table II/III, Row 1 ***

capture log close
set more off
clear all

*local dir1 "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\coded data\"
*local dircode "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\do files\"
*local dirout "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
*local dirlog "C:\Users\hy2347\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"

local dir1 "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\coded data\"
local dircode "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\do files\"
local dirout "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\tables\"
local dirlog "d:\mydocs\Dropbox\Fiscal\Data and Programs\2013 publishing\log files\"


log using "`dirlog'Table V", replace text

********* Prepare data set for regressions ****************
do "`dircode'Table II_III Row 1 preamble_states.do"              //the data set needed is the same

***********************************************************
* First Stage Regression
***********************************************************

xi: areg Drcapspend, absorb(state)
predict dem_Drcapspend, resid

xi: areg Drcapspend i.statenum*Drcapspend_nat, absorb(year)
predict dem_Drcapspend_pred, xbd

***********************************************************

*** code up - national ***
gen FDrcapspend_nat = F2.Drcapspend_nat
gen defslack = L2.slack_iur_nat
summarize defslack, detail
summarize slack_iur_nat, detail
*gen dum = (defslack>0)
gen dum = (defslack>-0.11)
*gen dum = (defslack>-0.21)
gen Drcapspendhi = Drcapspend*dum
gen Drcapspendlo = Drcapspend*(1-dum)
gen insthi  = dem_Drcapspend_pred * dum
gen instlo  = dem_Drcapspend_pred * (1-dum)
egen clustergroup = group(dum state)

*** code up - states ***
gen defslack2 = L2.slack_iur
summarize defslack2, detail
summarize slack_iur, detail
*gen dum2 = (defslack2>0)
gen dum2 = (defslack2>-0.18)
*gen dum2 = (defslack2>-0.23)
gen Drcapspendhi2 = Drcapspend*dum2
gen Drcapspendlo2 = Drcapspend*(1-dum2)
gen insthi2  = dem_Drcapspend_pred * dum2
gen instlo2  = dem_Drcapspend_pred * (1-dum2)
egen clustergroup2 = group(dum2 state)

***********************************************************
* Regressions with instruments
***********************************************************

***** State Output - National *****
xi: ivregress 2sls Drcapout (Drcapspend Drcapspendlo  = dem_Drcapspend_pred instlo) i.year i.statenum, vce(cl statenum)
*lincom Drcapspendhi-Drcapspendlo
outreg2 Drcapspend Drcapspendlo using "`dirout'Table V",word se bdec(2) replace

***** State Output - State *****
xi: ivregress 2sls Drcapout (Drcapspend Drcapspendlo2  = dem_Drcapspend_pred instlo2) i.year*dum2 i.statenum*dum2, vce(cl clustergroup2)
*lincom Drcapspendhi2-Drcapspendlo2
outreg2 Drcapspend Drcapspendlo2 using "`dirout'Table V",word se bdec(2) append

***** Employment - National *****
xi: ivregress 2sls  Demp (Drcapspend Drcapspendlo  = dem_Drcapspend_pred instlo) i.year i.statenum, vce(cl statenum)
*lincom Drcapspendhi-Drcapspendlo
outreg2 Drcapspend Drcapspendlo using "`dirout'Table V",word se bdec(2) append

***** Employment - State *****
xi: ivregress 2sls Demp (Drcapspend Drcapspendlo2  = dem_Drcapspend_pred instlo2) i.year*dum2 i.statenum*dum2, vce(cl clustergroup2)
*lincom Drcapspendhi2-Drcapspendlo2
outreg2 Drcapspend Drcapspendlo2 using "`dirout'Table V",word se bdec(2) append

log close
