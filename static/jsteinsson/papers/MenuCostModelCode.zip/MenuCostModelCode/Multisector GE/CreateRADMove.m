% Creates RADMove
%
% Jon Steinsson and Emi Nakamura, July 2006
%**************************************************************

function RADMove = CreateRADMove(shift,rad);

radgridsize = size(rad,1);

RADMove = zeros(radgridsize);
for ii = 1:radgridsize
    MoveTo = ii + shift;
    if MoveTo < 1
        MoveTo = 1;
    elseif MoveTo > radgridsize
        MoveTo = radgridsize;
    end
    RADMove(ii,MoveTo) = 1;
end