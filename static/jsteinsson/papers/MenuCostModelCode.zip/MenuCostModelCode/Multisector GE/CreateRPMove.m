% Creates RPMove
%
% Jon Steinsson and Emi Nakamura, July 2006
%**************************************************************

function RPMove = CreateRPMove(shift,rp);

rpgridsize = size(rp,1);

RPMove = zeros(rpgridsize);
for ii = 1:rpgridsize
    MoveTo = ii + shift;
    if MoveTo < 1
        MoveTo = 1;
    elseif MoveTo > rpgridsize
        MoveTo = rpgridsize;
    end
    RPMove(ii,MoveTo) = 1;
end