% Performs one dimensional Kernel Estimation
%
% Inputs: hh  -- bandwidth
%         xx  -- x-values of points to be smoothed
%         yy  -- y-values of points to be smoothed
%         xxsmooth  -- new x-values
%
% Outputs: yysmooth  -- new y-values
%
% Jon Steinsson, July 2006
%***********************************************

function yysmooth = KernelSmoother(hh,xx,yy,xxsmooth);

N = size(xx,1);
Ns = size(xxsmooth,1);

yysmooth = zeros(Ns,1);

for i = 1:Ns
    xxtemp = xxsmooth(i,1)*ones(N,1);
    K = ep_kernel((xxtemp-xx)/hh);
    sumK = sum(K);
    yysmooth(i,1) = K'*yy(:,1)/sumK;
end


