% Calculates statistics about price changes from the stationary 
% distribution
%
% Jon Steinsson and Emi Nakamura, July 2006
%**************************************************************

function PCStats = RigidityStatsMultiSector(Q,F,SectorWeights,a,rp,rad)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

NSector = size(SectorWeights,1);

rpBig = repmat(rp,[1 agridsize radgridsize]);
rpBig = permute(rpBig,[2 1 3]);
rpBig = reshape(rpBig,[Ssize 1]);

for ii = 1:NSector

    % Calculate frequency of price change
    %***************************************************************

    PriceChange = (rpBig ~= F(ii).F);
    PCStats.freq(ii) = sum(PriceChange.*Q(ii).Q);

    % Calculate fraction of price changes that are increases
    %***************************************************************

    PriceIncrease = (F(ii).F > rpBig);
    PriceDecrease = (F(ii).F < rpBig);

    PCStats.fracup(ii) = sum(PriceIncrease.*Q(ii).Q)/PCStats.freq(ii);

    % Calculate absolute size of price changes, price increases and
    % price decreases
    %****************************************************************

    AbsSizePC  = abs(F(ii).F-rpBig);

    PCStats.sizepc(ii) = sum(AbsSizePC.*Q(ii).Q)/PCStats.freq(ii);
    PCStats.sizeup(ii) = sum(AbsSizePC.*Q(ii).Q.*PriceIncrease)/(PCStats.freq(ii)*PCStats.fracup(ii));
    PCStats.sizedw(ii) = sum(AbsSizePC.*Q(ii).Q.*PriceDecrease)/(PCStats.freq(ii)*(1-PCStats.fracup(ii)));
end

PCStats.avfreq = SectorWeights'*PCStats.freq';
PCStats.avfracup = SectorWeights'*PCStats.fracup';
PCStats.avsizepc = SectorWeights'*PCStats.sizepc';
PCStats.avsizeup = SectorWeights'*PCStats.sizeup';
PCStats.avsizedw = SectorWeights'*PCStats.sizedw';