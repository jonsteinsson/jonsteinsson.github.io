% Calculates statistics about price changes from the stationary 
% distribution
%
% Jon Steinsson and Emi Nakamura, July 2006
%**************************************************************

function PCStats = RigidityStatsMultiSectorCalvoPlus(Q,F,F2,alphaCalvo,...
    SectorWeights,a,rp,rad)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

NSector = size(SectorWeights,1);

rpBig = repmat(rp,[1 agridsize radgridsize]);
rpBig = permute(rpBig,[2 1 3]);
rpBig = reshape(rpBig,[Ssize 1]);

for ii = 1:NSector

    % Calculate frequency of price change
    %***************************************************************

    PriceChange1 = (rpBig ~= F(ii).F);
    PriceChange2 = (rpBig ~= F2(ii).F2);
    PCStats.freq1(ii) = sum(PriceChange1.*Q(ii).Q);
    PCStats.freq2(ii) = sum(PriceChange2.*Q(ii).Q);
    PCStats.freq(ii) = alphaCalvo(ii)*PCStats.freq1(ii) ...
        + (1-alphaCalvo(ii))*PCStats.freq2(ii);

    % Calculate fraction of price changes that are increases
    %***************************************************************

    PriceIncrease1 = (F(ii).F > rpBig);
    PriceDecrease1 = (F(ii).F < rpBig);
    PriceIncrease2 = (F2(ii).F2 > rpBig);
    PriceDecrease2 = (F2(ii).F2 < rpBig);

    PCStats.fracup1(ii) = sum(PriceIncrease1.*Q(ii).Q)/PCStats.freq1(ii);
    PCStats.fracup2(ii) = sum(PriceIncrease2.*Q(ii).Q)/PCStats.freq2(ii);
    PCStats.fracup(ii) = (alphaCalvo(ii)*PCStats.freq1(ii)/PCStats.freq(ii))*PCStats.fracup1(ii) ...
        + ((1-alphaCalvo(ii))*PCStats.freq2(ii)/PCStats.freq(ii))*PCStats.fracup2(ii);


    % Calculate absolute size of price changes, price increases and
    % price decreases
    %****************************************************************

    AbsSizePC1  = abs(F(ii).F-rpBig);
    AbsSizePC2  = abs(F2(ii).F2-rpBig);

    PCStats.sizepc1(ii) = sum(AbsSizePC1.*Q(ii).Q)/PCStats.freq1(ii);
    PCStats.sizepc2(ii) = sum(AbsSizePC2.*Q(ii).Q)/PCStats.freq2(ii);
    PCStats.sizepc(ii) = (alphaCalvo(ii)*PCStats.freq1(ii)/PCStats.freq(ii))*PCStats.sizepc1(ii) ...
        + ((1-alphaCalvo(ii))*PCStats.freq2(ii)/PCStats.freq(ii))*PCStats.sizepc2(ii);

    PCStats.sizeup1(ii) = sum(AbsSizePC1.*Q(ii).Q.*PriceIncrease1)/(PCStats.freq1(ii)*PCStats.fracup1(ii));
    PCStats.sizeup2(ii) = sum(AbsSizePC2.*Q(ii).Q.*PriceIncrease2)/(PCStats.freq2(ii)*PCStats.fracup2(ii));
    PCStats.sizeup(ii) = (alphaCalvo(ii)*PCStats.freq1(ii)/PCStats.freq(ii))*PCStats.sizeup1(ii) ...
        + ((1-alphaCalvo(ii))*PCStats.freq2(ii)/PCStats.freq(ii))*PCStats.sizeup2(ii);

    PCStats.sizedw1(ii) = sum(AbsSizePC1.*Q(ii).Q.*PriceDecrease1)/(PCStats.freq1(ii)*(1-PCStats.fracup1(ii)));
    PCStats.sizedw2(ii) = sum(AbsSizePC2.*Q(ii).Q.*PriceDecrease2)/(PCStats.freq2(ii)*(1-PCStats.fracup2(ii)));
    PCStats.sizedw(ii) = (alphaCalvo(ii)*PCStats.freq1(ii)/PCStats.freq(ii))*PCStats.sizedw1(ii) ...
        + ((1-alphaCalvo(ii))*PCStats.freq2(ii)/PCStats.freq(ii))*PCStats.sizedw2(ii);
end

PCStats.avfreq1 = SectorWeights'*PCStats.freq1';
PCStats.avfracup1 = SectorWeights'*PCStats.fracup1';
PCStats.avsizepc1 = SectorWeights'*PCStats.sizepc1';
PCStats.avsizeup1 = SectorWeights'*PCStats.sizeup1';
PCStats.avsizedw1 = SectorWeights'*PCStats.sizedw1';

PCStats.avfreq2 = SectorWeights'*PCStats.freq2';
PCStats.avfracup2 = SectorWeights'*PCStats.fracup2';
PCStats.avsizepc2 = SectorWeights'*PCStats.sizepc2';
PCStats.avsizeup2 = SectorWeights'*PCStats.sizeup2';
PCStats.avsizedw2 = SectorWeights'*PCStats.sizedw2';

PCStats.avfreq = SectorWeights'*PCStats.freq';
PCStats.avfracup = SectorWeights'*PCStats.fracup';
PCStats.avsizepc = SectorWeights'*PCStats.sizepc';
PCStats.avsizeup = SectorWeights'*PCStats.sizeup';
PCStats.avsizedw = SectorWeights'*PCStats.sizedw';