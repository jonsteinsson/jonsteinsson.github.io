% Calculates the variance of output from the stationary distribution
%
% Jon Steinsson and Emi Nakamura, Oct 2006
%*************************************************************************

clear;
tic

% Load Data
%*************************************************************************

load GENModel

a = GENModel.a;
rp = GENModel.rp;
rad = GENModel.rad;
Q = GENModel.Q;
SectorWeights = GENModel.SectorWeights;

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

NSectors = size(SectorWeights,1);

% Calculate variance of output
%*************************************************************************

Qrad = zeros(radgridsize,1);
for ii = 1:NSectors
    Qtemp = reshape(Q(ii).Q,[agridsize*rpgridsize radgridsize]);
    Qrad = Qrad + SectorWeights(ii)*sum(Qtemp)';
end

Erad = rad'*Qrad;
VARrad = Qrad'*((rad-Erad).^2);

% Print Results
%**************************************************************************

fprintf('St.Dev of output = %5.5f (x10^-2)\n',(VARrad^(1/2))*100)
fprintf('Variance of output = %5.9f (x10^-4)\n\n',VARrad*10000)

toc
