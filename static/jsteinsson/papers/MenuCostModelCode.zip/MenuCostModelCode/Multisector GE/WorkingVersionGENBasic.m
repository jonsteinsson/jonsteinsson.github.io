% Multisector general equilibrium CalvoPlus model
%
% The state vector is three dimensional. We vectorize it using the
% reshape command. The order of the state variables when they are 
% reshaped is (a, rp, rad)
%
% The structure of this program is very similar to the structure of 
% 'ge1CalvoPlus.m' in the 'One Sector GE' folder. See that file for more 
% detailed documentation.
%
% Jon Steinsson and Emi Nakamura, August 2006
%
% Jake Weber updated June, 2021: added random seed + alert at the end.
% changed parameters to match size/freq values given correct
% CalculateGradInd file. Renamed from geNCalvoPlus to geNbasic.m
%**************************************************************
clear;
tic
rng('default') % set random seed to help with replicability 

% Set Fixed Parameters
%**************************************************************

theta = 4;    % Elasticity of demand
psi = 0;     % One over the Frisch elasticity of labor supply
gamma = 1;   % coefficient of relative risk aversion
FlexSSL = 1/3; % Steady State labor under flexible prices
beta = 0.96^(1/12);   % Discount factor

% Parameters of the process followed by nominal aggregate demand
% log(S_t) - log(S_t-1) = mu + nu_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
mu = 0.0028;
sigma_eta = 0.0065;

% Set sector specific parameters
%***************************************************************
% NB: Edges of the rad grid need to be extra padded in the multi-sector 
% model because the sectors have different mean rad.
% 




% Median Frequency

% DONE
% NSectors = 1;
% sm = 0.7;
% K             = 0.0162  ; % edit here %%%%% 
% sigma_eps     =  0.063 ; % edit here %%%%% 
% alphaCalvo    = 1-0.085;
% rho           =  0.7 ;
% SectorWeights = 1;
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.021;
% slope = 9; levelshift = 2;
% agridsize = 40;
% rpgridsize = 400;
% radgridsize = 50;

% target frequency = 8.7 (from the paper). It targets the HIGH COST STATE %%%%%% (median calibration)
% target size = 8.1 - 8.6. It targets the OVERALL

% High Cost State
% Frequency of Price Change:
%    0.0805     ||   0.0805
% Overall: 
% Size of Price Changes:
%    0.0884     ||   0.0884 
% St.Dev of output = 0.84684 (x10^-2)
% Variance of output = 0.717133210 (x10^-4)


% DONE
% NSectors = 1;
% sm = 0;
% K             = 0.05  ;  % edit here %%%%% 0.13  (old)
% sigma_eps     =  0.06 ; % edit here %%%%% 0.067 (old)
% alphaCalvo    = 1-0.085;
% rho           =  0.7 ;
% SectorWeights = 1;
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.021;
% slope = 9; levelshift = 2;
% agridsize = 40;
% rpgridsize = 400;
% radgridsize = 50;

% target frequency = 8.7 (from the paper). It targets the HIGH COST STATE %%%%%% (median calibration)
% target size = 8.1 - 8.6. It targets the OVERALL


% High Cost State
% Frequency of Price Change:
%    0.0860     ||   0.0860 
% Overall: 
% Size of Price Changes:
%    0.0861     ||   0.0861 
% St.Dev of output = 0.47468 (x10^-2)
% Variance of output = 0.225325269 (x10^-4)


% Mean Frequency

% DONE
% NSectors = 1;
% sm = 0.7;
% K             = 0.006  ; % edit here
% sigma_eps     =  0.065 ;  % edit here 
% alphaCalvo    = 1-0.228;
% rho           =  0.7 ;
% SectorWeights = 1;
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.021;
% slope = 9; levelshift = 2;
% agridsize = 40;
% rpgridsize = 400;
% radgridsize = 50;

% target frequency = 21.1 (from the paper). It targets the HIGH COST STATE %%%%%% (mean calibration)
% target size = 8.1 - 8.6. It targets the OVERALL

% High Cost State
% Frequency of Price Change:
%    0.2105     ||   0.2105 
% Overall: 
% Size of Price Changes:
%    0.0831     ||   0.0831 
% St.Dev of output = 0.48573 (x10^-2)
% Variance of output = 0.235938476 (x10^-4)


% DONE
% NSectors = 1;
% sm = 0;
% K             = 0.024  ;  % edit here %%%%% 
% sigma_eps     =  0.07 ;  % edit here %%%%% 
% alphaCalvo    = 1-0.228;
% rho           =  0.7 ;
% SectorWeights = 1;
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.021;
% slope = 9; levelshift = 2;
% agridsize = 40;
% rpgridsize = 400;
% radgridsize = 50;

% target frequency = 21.1 (from the paper). It targets the HIGH COST STATE %%%%%% (mean calibration)
% target size = 8.1 - 8.6. It targets the OVERALL

% High Cost State
% Frequency of Price Change:
%    0.2102     ||   0.2102 
% Overall: 
% Size of Price Changes:
%    0.0897     ||   0.0897 
% St.Dev of output = 0.23624 (x10^-2)
% Variance of output = 0.055808605 (x10^-4)



% DONE
% NSectors = 6;
% sm = 0.7;
% K             = [0.000021    0.00368  0.01    0.0119  0.00863   0.0392]'; %%%%% Edit here
% sigma_eps     = [0.051     0.0722    0.091    0.0613  0.045    0.086]'; %%%%% Edit here
% alphaCalvo    = [  1-0.089   1-0.045   1-0.013   1-0.02    1-0.02  1-0.079]';
% rho           = [    0.7       0.7       0.7       0.7       0.7       0.7]';
% SectorWeights = [ 0.0766    0.1909    0.0592    0.1368    0.3853    0.1512]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.021;
% slope = 9; levelshift = 2;
% agridsize = 62;
% rpgridsize = 400;
% radgridsize = 40;
% Targets 
% 0.916   0.355   0.254   0.119   0.088   0.052 % TARGET K: FREQ HIGH COST
% 0.049   0.109   0.159   0.114   0.083   0.111 % TARGET sig: SIZE OVERALL

% High Cost State
% Frequency of Price Change:
%    0.9119    0.3500    0.2535    0.1174    0.0885    0.0570     ||   0.2105 
% Overall: 
% Size of Price Changes:
%    0.0481    0.1091    0.1545    0.1137    0.0839    0.1131     ||   0.0986 
% St.Dev of output = 0.70147 (x10^-2)
% Variance of output = 0.492056522 (x10^-4)


% DONE
% NSectors = 6;
% sm = 0.0;
% K             = [0.000064    0.012    0.034    0.045    0.031   0.14]'; % 
% sigma_eps     = [ 0.051    0.071    0.09    0.063     0.045   0.086]'; %  
% rho           = [0.7       0.7       0.7       0.7        0.7      0.7]'; 
% alphaCalvo    = [  1-0.089   1-0.045   1-0.013   1-0.02    1-0.02  1-0.079]';
% SectorWeights = [   0.0766    0.1909	  0.0592    0.1368     0.3853   0.1512]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.0218;
% slope = 9; levelshift = 2;
% agridsize = 62;
% rpgridsize = 400;
% radgridsize = 50;

% Targets 
% 0.916   0.355   0.254   0.119   0.088   0.052 % TARGET K: FREQ HIGH COST
% 0.049   0.109   0.159   0.114   0.083   0.111 % TARGET sig: SIZE OVERALL

% High Cost State
% Frequency of Price Change:
%    0.9175    0.3580    0.2546    0.1157    0.0880    0.0556     ||   0.2118 
% Overall: 
% Size of Price Changes:
%    0.0480    0.1070    0.1529    0.1173    0.0846    0.1124     ||   0.0988 
% St.Dev of output = 0.37414 (x10^-2)
% Variance of output = 0.139983791 (x10^-4)


% DONE
% NSectors = 9;
% sm = 0.7;
% K             = [0.000016    0.0058    0.0165   0.00146    0.021   0.011   0.02    0.036    0.06     ]'; 
% rho           = [ 0.7     0.7       0.7       0.7       0.7       0.7       0.7      0.7       0.7    ]';
% sigma_eps     = [  0.048    0.094    0.122     0.03    0.083    0.048    0.06   0.079     0.087      ]';
% alphaCalvo    = [1-0.916   1-0.355   1-0.254   1-0.197  1-0.119   1-0.076   1-0.055   1-0.052   1-0.032]';
% SectorWeights = [0.0766198	0.1909496	0.0592052	0.0920136	0.1367988	0.0961692	0.0997467	0.1511725	0.0973246]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.0132;
% slope = 9; levelshift = 1;
% agridsize = 83;
% rpgridsize = 400;
% radgridsize = 40;
% Targets 
%  HIT      HIT     HIT    HIT   HIT     HIT    HIT    HIT   HIT
% 0.916   0.355   0.254  0.197  0.119  0.076  0.055  0.052  0.032 % TARGET K: FREQ HIGH COST
% 0.049   0.109   0.159  0.046  0.114  0.072  0.081  0.111  0.128 % TARGET sig: SIZE OVERALL
%  HIT      HIT     HIT    HIT    HIT    HIT    HIT    HIT    HIT

% High Cost State
% Frequency of Price Change:
%    0.9174    0.3524    0.2553    0.1975    0.1131    0.0719    0.0587    0.0540    0.0328     ||   0.2105 
% Overall: 
% Size of Price Changes:
%    0.0430    0.1087    0.1514    0.0415    0.1170    0.0701    0.0886    0.1151    0.1230     ||   0.0978 
% St.Dev of output = 0.78754 (x10^-2)
% Variance of output = 0.620211609 (x10^-4)


% DONE
NSectors = 9;                          
sm = 0.0;     
K             = [0.00006    0.0176    0.06     0.0053    0.066   0.044   0.06    0.11    0.23     ]'; 
rho           = [ 0.7     0.7       0.7       0.7       0.7       0.7       0.7      0.7       0.7    ]';
sigma_eps     = [  0.048    0.089    0.124     0.03    0.08    0.052    0.055   0.075     0.0915     ]';
alphaCalvo    = [1-0.916   1-0.355   1-0.254   1-0.197   1-0.119   1-0.076   1-0.055   1-0.052   1-0.032]';
SectorWeights = [0.0766198	0.1909496	0.0592052	0.0920136	0.1367988	0.0961692	0.0997467	0.1511725	0.0973246]';
SectorWeights = SectorWeights/(sum(SectorWeights));
rad_shift = 0.005;
slope = 4; levelshift = 1;
agridsize = 84; 
rpgridsize = 400;
radgridsize = 40;

% Targets 
%  HIT      HIT     HIT    HIT   HIT     HIT    HIT    HIT   HIT
% 0.916   0.355   0.254  0.197  0.119  0.076  0.055  0.052  0.032 % TARGET K: FREQ HIGH COST
% 0.049   0.109   0.159  0.046  0.114  0.072  0.081  0.111  0.128 % TARGET sig: SIZE OVERALL
%  HIT      HIT     HIT    HIT    HIT    HIT    HIT    HIT    HIT

% High Cost State
% Frequency of Price Change:
%    0.9145    0.3559    0.2512    0.1945    0.1154    0.0735    0.0580    0.0561    0.0324     ||   0.2111 
% Overall: 
% Size of Price Changes:
%    0.0433    0.1032    0.1540    0.0423    0.1133    0.0766    0.0820    0.1109    0.1292     ||   0.0964 
% St.Dev of output = 0.39194 (x10^-2)
% Variance of output = 0.153616145 (x10^-4)


% DONE 
% NSectors = 14; 
% sm = 0.7;          
% K           = [.000022    .00127   .0132    0.018   0.006    0.00185     0.02    .0086     0.026    0.019   0.0250   0.025   0.055  .1 ]'; 
% rho         = [0.7  0.7      0.7     0.7     0.7     0.7     0.7     0.7      0.7       0.7     0.7     0.7      0.7      .7 ]';
% sigma_eps   = [0.055     0.063      0.175     0.125    0.065   0.036      0.08    0.045    0.072     0.06    0.07    0.061    0.087   .103 ]';
% alphaCalvo  = [1-0.916   1-0.494   1-0.437   1-0.254   1-0.213  1-0.217   1-0.119   1-0.084   1-0.065   1-0.062   1-0.061   1-0.049   1-0.036   1-0.029]';
% SectorWeights = [0.0766198	0.0531759	0.0546954	0.0592052	0.0830783	0.0768462	0.1367988	0.0750842	0.0500672	0.0782608	0.0363348	0.0763454	0.0647705	0.0787175]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.0135;
% slope = 10; levelshift = 1;
% agridsize = 106;
% rpgridsize = 400;
% radgridsize = 40;

% Targets 
%  1        2       3       4       5       6      7      8         9       10       11     12       13      14                  
%  HIT      HIT    HIT     HIT     HIT     HIT     HIT    HIT      HIT     HIT      HIT    HIT      HIT     HIT   
% 0.916   0.494   0.437   0.254   0.213   0.217   0.119   0.084   0.065   0.062   0.061   0.049   0.036   0.029 % TARGET K: FREQ HIGH COST
% 0.049   0.064   0.184   0.159   0.089   0.04    0.114   0.067   0.101   0.088   0.102   0.081   0.124   0.135 % TARGET sig: SIZE OVERALL
%  HIT      HIT    HIT     HIT     HIT     HIT     HIT     HIT     HIT    HIT     HIT      HIT      HIT     HIT     

% High Cost State
% Frequency of Price Change:
%    0.9136    0.4988    0.4321    0.2518    0.2150    0.2162    0.1103    0.0826    0.0658    0.0628    0.0646    0.0451    0.0379    0.0239     ||   0.2092 
% Overall: 
% Size of Price Changes:
%    0.0496    0.0670    0.1874    0.1567    0.0861    0.0488    0.1130    0.0669    0.1056    0.0883    0.1035    0.0871    0.1259    0.1357     ||   0.0997 
% St.Dev of output = 0.77383 (x10^-2)
% Variance of output = 0.598807809 (x10^-4)



% DONE        
% NSectors = 14;
% sm = 0.0;
% K           = [.00008   .0044   .0440   0.062    0.02    .0065    0.064    .0300     0.091    .0650    .0870   0.085    0.200   .35 ]'; 
% rho        = [ 0.7    0.7      0.7       0.7     0.7       0.7       0.7       0.7       0.7       0.7        0.7        0.7       0.7        0.7 ]';
% sigma_eps   = [.055   .063      .175     0.125    0.065   0.036      0.08    0.045    0.072     0.06    0.07    0.061    0.087   .102 ]';
% alphaCalvo    = [1-0.916   1-0.494   1-0.437   1-0.254   1-0.213  1-0.217   1-0.119   1-0.084   1-0.065   1-0.062   1-0.061   1-0.049   1-0.036   1-0.029]';
% SectorWeights = [0.0766198	0.0531759	0.0546954	0.0592052	0.0830783	0.0768462	0.1367988	0.0750842	0.0500672	0.0782608	0.0363348	0.0763454	0.0647705	0.0787175]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.01;
% slope = 4; levelshift = 2;
% agridsize = 127;
% rpgridsize = 400;
% radgridsize = 48;
% Targets 
%  1        2       3       4       5       6       7       8       9       10      11     12       13      14                  
%  INC      HIT    HIT     HIT     HIT     HIT     HIT     HIT     HIT     HIT     HIT     HIT     HIT     HIT   
% 0.916   0.494   0.437   0.254   0.213   0.217   0.119   0.084   0.065   0.062   0.061   0.049   0.036   0.029 % TARGET K: FREQ HIGH COST
% 0.049   0.064   0.184   0.159   0.089   0.04    0.114   0.067   0.101   0.088   0.102   0.081   0.124   0.135 % TARGET sig: SIZE OVERALL
%  HIT      HIT    HIT     HIT     HIT     HIT     HIT     HIT     HIT    HIT     HIT      HIT      HIT     HIT     

% High Cost State
% Frequency of Price Change:
%    0.9105    0.4967    0.4367    0.2505    0.2194    0.2108    0.1189    0.0826    0.0644    0.0635    0.0637    0.0465    0.0345    0.0225     ||   0.2098 
% Frac Up:
% Size of Price Changes:
%    0.0494    0.0671    0.1873    0.1569    0.0863    0.0496    0.1144    0.0676    0.1050    0.0892    0.1035    0.0884    0.1229    0.1313     ||   0.0996 
% St.Dev of output = 0.40664 (x10^-2)
% Variance of output = 0.165354170 (x10^-4)




if abs(sum(SectorWeights)-1)> 10^(-10), error('SectorWeights do not sum to one!'), end

% Maximum number of iterations on G
MaxItOnG = 60;

Ssize = agridsize*rpgridsize*radgridsize;

K2 = K*0;

% Solve for the flexible price steady state 
%****************************************************************

par1 = sm*(theta-1)/(theta-sm*(theta-1));

FlexSSC = FlexSSL*par1^(sm/(1-sm))*(1+par1)^(-1/(1-sm));
FlexSSM = par1*FlexSSC;
FlexSSY = FlexSSC + FlexSSM;

omega = (theta-1)/theta*(1-sm)*(1+par1)*FlexSSL^(-psi-1)*FlexSSC^(1-gamma); % Level parameter on disutility of labor
omega2 = omega*(FlexSSL)^psi; % Marginal disutility of changing prices

K = K*FlexSSY;
K2 = K2*FlexSSY;

FlexSSL = log(FlexSSL);
FlexSSC = log(FlexSSC);
if sm > 0
    FlexSSM = log(FlexSSM);
end
FlexSSY = log(FlexSSY);

% Print Out Parameters
%****************************************************************

fprintf('\n')
fprintf('theta:    %5.5f\n',theta)
fprintf('psi:      %5.5f\n',psi)
fprintf('gamma:    %5.5f\n',gamma)
fprintf('sm:       %5.5f\n',sm)
fprintf('\n')
fprintf('Size of State Space: %10.0f\n\n',Ssize)

fprintf('\n')
fprintf('K:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',K(ii)/exp(FlexSSY))
end
fprintf('\n')
fprintf('rho:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',rho(ii))
end
fprintf('\n')
fprintf('sigma_eps:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',sigma_eps(ii))
end
fprintf('\n\n')

% Set gridsizes and grid max and min
%****************************************************************

MaxUncondVar = max(((sigma_eps.^2)./(1-rho.^2)).^(1/2));
MinUncondVar = min(((sigma_eps.^2)./(1-rho.^2)).^(1/2));
MinUncondVar = max(MinUncondVar,sigma_eta);

trunc_eps = 2.5;
amax = trunc_eps*MaxUncondVar;
amin = -trunc_eps*MaxUncondVar;
ainc = (amax-amin)/(agridsize-1) - mod((amax-amin)/(agridsize-1),10^(-5));
amin = amin - mod(amin,10^(-5));
amax = amin + (agridsize-1)*ainc;

fprintf('Gridpoints for "a" off of which the least volatile sector is simulated:\n')
fprintf('2*trunc_eps*MinUncondVar/ainc = %5.3f\n\n',...
    2*trunc_eps*MinUncondVar/ainc)
if 2*trunc_eps*MinUncondVar/ainc < 20
    error('2*trunc_eps*MinUncondVar/ainc < 20: Results unreliable!',...
        2*trunc_eps*MinUncondVar/ainc) %#ok<CTPCT>
end

% rp denotes the real price
% np denotes the nominal price
% The rp grid is a grid for the log of the real price
pimult = 200; % Determines sensitivity of pigrid to mu
rpmax = -amin*(1+pimult*abs(mu));
rpmin = -amax*(1+pimult*abs(mu));
if rpmax < 0.15
    rpmax = 0.15;
    rpmin = -0.15;
end
rpinc = (rpmax-rpmin)/(rpgridsize-1) - mod((rpmax-rpmin)/(rpgridsize-1),10^(-5));
rpmin = rpmin - mod(rpmin,10^(-5));
rpmax = rpmin + (rpgridsize-1)*rpinc;

if rpinc > 0.0075
    error('rpinc > 0.0075: Results unreliable')
end

radmin = FlexSSC - radgridsize/2*rpinc + rad_shift;

% Create the real price and idiosyncratic productivity vectors
%**************************************************************

a = amin:ainc:amax; a = a';

rp = zeros(rpgridsize,1);
rp(1) = rpmin;
for ii = 2:rpgridsize
    rp(ii) = rp(ii-1) + rpinc;
end

rad = zeros(radgridsize,1);
rad(1) = radmin;
for ii = 2:radgridsize
    rad(ii) = rad(ii-1) + rpinc;
end

% Create Probability Distribution for the idiosyncratic shock
%**************************************************************
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)

for ii = 1:NSectors
    Proba(ii).Proba = CreateProba(rho(ii),sigma_eps(ii),a);
end

% Create probability distribution for nominal aggregate demand
%***************************************************************

ProbNgr = CreateProbNgr(mu,sigma_eta,rad);

% Guess a matrix G which gives the log inflation rate given S_t/P_t-1
%**************************************************************

G = zeros(radgridsize,1);
%G = (rp(2)-rp(1))*ones(radgridsize,1);
G(1,1) = -(radgridsize/(2*slope)-mod(radgridsize/(2*slope),1))*(rp(2)-rp(1)) ...
    + levelshift*(rp(2)-rp(1));
for ii = 2:radgridsize
    if mod(ii,slope) == 0
        G(ii,1) = G(ii-1,1) + rp(2) - rp(1);
    else
        G(ii,1) = G(ii-1,1);
    end
end

% Calculate the profit function
%**************************************************************

par1 = psi+1;
par2 = gamma;
par3 = exp(FlexSSC)/exp(FlexSSY);
par4 = exp(FlexSSM)/exp(FlexSSY) - sm;
par5 = 1-sm;

a3d = repmat(a,[1 rpgridsize radgridsize]);

rp3d = repmat(rp,[1 agridsize radgridsize]);
rp3d = permute(rp3d, [2 1 3]);

rad3d = repmat(rad,[1 agridsize rpgridsize]);
rad3d = permute(rad3d,[2 3 1]);

if sm > 0
    l3d = FlexSSL + (par3+par2*par4)/(par5-par1*par4)*(rad3d-FlexSSC);
    m3d = FlexSSM + par1*(l3d - FlexSSL) + par2*(rad3d-FlexSSC);
else
    l3d = FlexSSL + (rad3d-FlexSSC);
    m3d = 0*rad3d;
end

rPi3d = exp(rad3d + m3d).*exp(rp3d).^(1-theta) ...
    - (1-sm)^(sm-1)*sm^(-sm)*omega^(1-sm)*exp(l3d).^(psi*(1-sm)).*exp(rad3d).^(gamma*(1-sm)).*exp(-a3d).*exp(rad3d+m3d).*exp(rp3d).^(-theta);
rPi = reshape(rPi3d,[Ssize 1]);

for ii = 1:NSectors
    menucost(ii).menucost = reshape(omega2*K(ii)*exp(rad3d).^gamma,[Ssize 1]);
end

for ii = 1:NSectors
    menucost2(ii).menucost2 = reshape(omega2*K2(ii)*exp(rad3d).^gamma,[Ssize 1]);
end

clear a3d rp3d rad3d rPi3d l3d m3d

% Calculate the ratio of marginal utility
%**************************************************************
% The (i,j)th element of RMU is the ratio of marginal utility in 
% state j of period t+1 to the marginal utility in state i of
% period t.

RMU = ((1./exp(rad))*(exp(rad)')).^(-gamma);

% Initialize ErV matrix (Expected Value next period)
%**************************************************************

for ii = 1:NSectors
    rV(ii).rV = 1.5*ones(Ssize, 1)*max(0,mean(rPi)/(1-beta));
end

rPi3d = reshape(rPi,[agridsize rpgridsize radgridsize]);
tolV = 0.005*rPi3d(floor(agridsize/2),floor(rpgridsize/2),floor(radgridsize/2))/(1-beta);
clear rPi3d
%tolV = 0.03;

% Initialize stationary distribution Q
%**************************************************************

for ii = 1:NSectors
    Q(ii).Q = ones(Ssize,1)/Ssize;
end

tolQ = Q(1).Q(1)/10;

% Solve for the Equilibrium
%**************************************************************

[G,rV,F,F2,Q] = EqSolverGeNCalvoPlus(rPi,menucost,menucost2,RMU,alphaCalvo,...
    beta,theta,a,rp,rad,Proba,ProbNgr,rV,Q,G,SectorWeights,tolV,tolQ,MaxItOnG,1);

GError = CalcGErrorMultiSectorCalvoPlus(Q,F,F2,G,alphaCalvo,a,rp,rad,theta,...
    Proba,ProbNgr,SectorWeights);

PCStats = RigidityStatsMultiSectorCalvoPlus(Q,F,F2,alphaCalvo,...
    SectorWeights,a,rp,rad);


fprintf('\n')
fprintf('GeN CalvoPlus\n\n')
fprintf('theta:     %5.5f\n',theta)
fprintf('psi:       %5.5f\n',psi)
fprintf('gamma:     %5.5f\n',gamma)
fprintf('sm:        %5.5f\n',sm)
fprintf('mu:        %5.5f\n',mu)
fprintf('sigma_eta: %5.5f\n',sigma_eta)
fprintf('FlexSSC:   %5.5f\n',exp(FlexSSC))

fprintf('K(i)/FlexSSY:  ')
for ii = 1:NSectors
    fprintf('   %5.4f ',K(ii)/exp(FlexSSY))
end
fprintf('\n')

fprintf('K2(i)/FlexSSY: ')
for ii = 1:NSectors
    fprintf('   %5.4f ',K2(ii)/exp(FlexSSY))
end
fprintf('\n')

fprintf('1-alphaCalvo:  ')
for ii = 1:NSectors
    fprintf('   %5.4f ',1-alphaCalvo(ii))
end
fprintf('\n')

fprintf('rho:           ')
for ii = 1:NSectors
    fprintf('   %5.4f ',rho(ii))
end
fprintf('\n')

fprintf('sigma_eps:     ')
for ii = 1:NSectors
    fprintf('   %5.4f ',sigma_eps(ii))
end
fprintf('\n')

fprintf('Sector Weights:')
for ii = 1:NSectors
    fprintf('   %5.4f ',SectorWeights(ii))
end
fprintf('\n')

fprintf('Overall: \n')
fprintf('Frequency of Price Change:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.freq(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfreq)
fprintf('Frac Up:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.fracup(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfracup)
fprintf('Size of Price Changes:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizepc(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizepc)
fprintf('Size of Price Increases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizeup(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizeup)
fprintf('Size of Price Decreases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizedw(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizedw)
fprintf('\n')

fprintf('High Cost State\n')
fprintf('Frequency of Price Change:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.freq1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfreq1)
fprintf('Frac Up:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.fracup1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfracup1)
fprintf('Size of Price Changes:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizepc1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizepc1)
fprintf('Size of Price Increases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizeup1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizeup1)
fprintf('Size of Price Decreases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizedw1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizedw1)
fprintf('\n')

fprintf('Low Cost State\n')
fprintf('Frequency of Price Change:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.freq2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfreq2)
fprintf('Frac Up:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.fracup2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfracup2)
fprintf('Size of Price Changes:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizepc2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizepc2)
fprintf('Size of Price Increases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizeup2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizeup2)
fprintf('Size of Price Decreases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizedw2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizedw2)
fprintf('\n')

fprintf('Fraction of Price Changes in Low Cost State:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',(1-alphaCalvo(ii))*PCStats.freq2(ii)/PCStats.freq(ii))
end

% Save Model Input and Output
%**************************************************************

% Inputs
GENModel.a = a;
GENModel.rp = rp;
GENModel.rad = rad;
GENModel.K = K;
GENModel.K2 = K2;
GENModel.beta = beta;
GENModel.theta = theta;
GENModel.sm = sm;
GENModel.gamma = gamma;
GENModel.omega = omega;
GENModel.omega2 = omega2;
GENModel.rho = rho;
GENModel.sigma_eps = sigma_eps;
GENModel.mu = mu;
GENModel.sigma_eta = sigma_eta;
GENModel.SectorWeights = SectorWeights;
GENModel.alphaCalvo = alphaCalvo;

% Outputs
GENModel.G = G;
%GENModel.rV = rV;
GENModel.F = F;
GENModel.F2 = F2;
GENModel.Q = Q;
GENModel.GError = GError;
GENModel.freq = PCStats.freq1;
% GENModel.fracup = PCStats.fracup1;
GENModel.sizepc = PCStats.sizepc1;
% GENModel.sizeup = PCStats.sizeup1;
% GENModel.sizedw = PCStats.sizedw1;
% GENModel.avfreq = PCStats.avfreq1;
% GENModel.avfracup = PCStats.avfracup1;
% GENModel.avsizepc = PCStats.avsizepc1;
% GENModel.avsizeup = PCStats.avsizeup1;
% GENModel.avsizedw = PCStats.avsizedw1;
% GENModel.freq = PCStats.freq2;
% GENModel.fracup = PCStats.fracup2;
% GENModel.sizepc = PCStats.sizepc2;
% GENModel.sizeup = PCStats.sizeup2;
% GENModel.sizedw = PCStats.sizedw2;
% GENModel.avfreq = PCStats.avfreq2;
% GENModel.avfracup = PCStats.avfracup2;
% GENModel.avsizepc = PCStats.avsizepc2;
% GENModel.avsizeup = PCStats.avsizeup2;
% GENModel.avsizedw = PCStats.avsizedw2;
% GENModel.freq = PCStats.freq;
% GENModel.fracup = PCStats.fracup;
% GENModel.sizepc = PCStats.sizepc;
% GENModel.sizeup = PCStats.sizeup;
% GENModel.sizedw = PCStats.sizedw;
% GENModel.avfreq = PCStats.avfreq;
% GENModel.avfracup = PCStats.avfracup;
% GENModel.avsizepc = PCStats.avsizepc;
% GENModel.avsizeup = PCStats.avsizeup;
% GENModel.avsizedw = PCStats.avsizedw;

% save('GENModel','GENModel')

toc


fprintf('Overall: \n')
fprintf('Frequency of Price Change:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.freq(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfreq)
fprintf('Size of Price Changes:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizepc(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizepc)


VarFromQ

beep on; beep; beep off;  % alerts user program has finished running