% The Epanechnikov Kernel
%
% J�n Steinsson, July 2006
%***************************************

function W = ep_kernel(u)

W = (abs(u) <= 1).*((3/4)*(1-u.^2));


