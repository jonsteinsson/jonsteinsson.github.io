% Multisector general equilibrium menu cost model
%
% The state vector is three dimensional. We vectorize it using the
% reshape command. The order of the state variables when they are 
% reshaped is (a, rp, rad)
%
% The structure of this program is very similar to the structure of 
% 'ge1Basic.m' in the 'One Sector GE' folder. See that file for more 
% detailed documentation.
%
% Jon Steinsson and Emi Nakamura, August 2006
%**************************************************************

clear;
tic

% Set a random seed for the replicability
rng('default') 

% Set Fixed Parameters
%**************************************************************

theta = 4;    % Elasticity of demand
psi = 0;     % One over the Frisch elasticity of labor supply
gamma = 1;   % coefficient of relative risk aversion
FlexSSL = 1/3; % Steady State labor under flexible prices
beta = 0.96^(1/12);   % Discount factor

mu = 0.0028;
sigma_eta = 0.0065;

% Set sector specific parameters
%***************************************************************
% NB: Edges of the rad grid need to be extra padded in the multi-sector 
% model because the sectors have different mean rad.
 
NSectors = 6;
sm = 0.7;
K =  [  0.0000202    0.00327    0.0101    0.01025     0.00705   0.01869]'; 
sigma_eps = [ 0.0519   0.0689    0.0937    0.0568     0.0399   0.0532]';
rho           = [    0.7       0.7       0.7       0.7       0.7       0.7]';
SectorWeights = [ 0.0766    0.1909    0.0592    0.1368    0.3853    0.153]';
SectorWeights = SectorWeights/(sum(SectorWeights));
rad_shift = 0.021;
slope = 4; levelshift = 2;
agridsize = 60;
rpgridsize = 1200;
radgridsize = 60;

% Frequency of Price Change:
%    0.91525    0.35684    0.26241    0.11956    0.08903    0.05280     ||   0.21212 
% Size of Price Changes:
%    0.04904    0.10926    0.16144    0.11464    0.08370    0.11147     ||   0.09898 
% 
% St.Dev of output = 0.67606 (x10^-2)
% Variance of output = 0.457054450 (x10^-4)


% NSectors = 6;
% sm = 0.0;
% rho           = [      0.7       0.7       0.7       0.7        0.7      0.7]';
% K =  [  0.000070    0.01157    0.0353    0.036     0.0247   0.066]'; 
% sigma_eps = [   0.0519   0.0689    0.0935    0.0565     0.0395   0.053]';
% SectorWeights = [   0.0766    0.1909	0.0592    0.1368     0.3853   0.1512]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.5*mu+0.003;
% slope = 2; levelshift = 3;
% agridsize = 60;
% rpgridsize = 1200;
% radgridsize = 60;

% Frequency of Price Change:
%    0.91622    0.35625    0.26284    0.11971    0.09007    0.05325     ||   0.21288 
% Size of Price Changes:
%    0.04916    0.10964    0.16131    0.11470    0.08384    0.11180     ||   0.09914 
% 
% St.Dev of output = 0.36904 (x10^-2)
% Variance of output = 0.136193063 (x10^-4)


%  NSectors = 9;
%  sm = 0.70;
%  K =  [  0.00002    0.00327    0.01005   0.00106  0.0102   0.0059   0.01    0.0188 0.039]'; 
%  sigma_eps = [ 0.0519   0.0689    0.0937    0.02402    0.0567    0.0335    0.0378    0.0535    0.065]';
%  rho           = [    0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7]';
%  SectorWeights = [0.0766198	0.1909496	0.0592052	0.0920136	0.1367988	0.0961692	0.0997467	0.1511725	0.0973246]';
%  SectorWeights = SectorWeights/(sum(SectorWeights));
%  rad_shift = 0.018;
%  slope = 2; levelshift = 3;
%  agridsize = 90;
%  rpgridsize = 1100;
%  radgridsize = 64;

% Frequency of Price Change:
%    0.91559    0.35638    0.26294    0.19875    0.11936    0.07783    0.05621    0.05283    0.03306     ||   0.21268 
% Size of Price Changes:
%    0.04897    0.10923    0.16129    0.04659    0.11436    0.07210    0.08174    0.11194    0.13147     ||   0.09889 

% St.Dev of output = 0.70490 (x10^-2)
% Variance of output = 0.496878974 (x10^-4)

 
% NSectors = 9;
% sm = 0.0;
% K =  [ 0.000070    0.01157    0.0353    0.00368  0.036   0.021   0.0358    0.066 0.135]'; 
% sigma_eps = [  0.0519   0.0689    0.0935     0.0232    0.0565    0.033    0.0374    0.053    0.0645]';
% rho           = [    0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7]';
% SectorWeights = [0.0766198	0.1909496	0.0592052	0.0920136	0.1367988	0.0961692	0.0997467	0.1511725	0.0973246]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.5*mu+0.003;
% slope = 2; levelshift = 3;
% agridsize = 90;
% rpgridsize = 800;
% radgridsize = 60;

% Frequency of Price Change:
%    0.91608    0.35609    0.26282    0.19916    0.11959    0.07827    0.05640    0.05322    0.03375     ||   0.21291 
% Size of Price Changes:
%    0.04918    0.10962    0.16128    0.04645    0.11460    0.07229    0.08211    0.11175    0.13151     ||   0.09903 
%
% St.Dev of output = 0.39937 (x10^-2)
% Variance of output = 0.159496189 (x10^-4)

% NSectors = 14;
% sm = 0.7;
% K               = [  0.00002    0.000715    0.00712    0.01009  0.00368   0.000707 0.01005    0.0048  0.0132   .0104  .01395  .0111  .0315  .0462]';
% rho           = [    0.7       0.7       0.7       0.7       0.7      0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7]';
% sigma_eps     = [  0.0519    0.0458    0.1292    0.091    0.0483   0.0208    0.0566    0.0315    0.0485    0.0415    0.0488    0.0375    0.0606    0.0679]';
% SectorWeights = [0.0766198	0.0531759	0.0546954	0.0592052	0.0830783	0.0768462	0.1367988	0.0750842	0.0500672	0.0782608	0.0363348	0.0763454	0.0647705	0.0787175]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.01875;
% slope = 5; levelshift = 2;
% agridsize = 150;
% rpgridsize = 400;
% radgridsize = 60;

% Frequency of Price Change:
%    0.91416    0.49361    0.44470    0.25488    0.21329    0.21750    0.12045    0.08536    0.06523    0.06286    0.06195    0.05015    0.03687    0.02985     ||   0.21203 
% Size of Price Changes:
%    0.04903    0.06394    0.18467    0.15942    0.08920    0.03981    0.11403    0.06779    0.10163    0.08808    0.10240    0.08176    0.12433    0.13587     ||   0.09855 
% 
% St.Dev of output = 0.82787 (x10^-2)
% Variance of output = 0.685365499 (x10^-4)


% NSectors = 14;
% sm = 0.0;
% K             = [  0.000070    0.00254    0.0252   0.0355  0.0128   0.0025 0.0355    0.017  0.047   .0375  .049  .04  .115  .17]';
% rho           = [    0.7       0.7       0.7       0.7       0.7      0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7]';
% sigma_eps     = [ 0.0519    0.0458    0.1299   0.091    0.0477   0.02    0.056    0.0304    0.048    0.0410    0.048    0.0365    0.0605    0.0675]';
% SectorWeights = [0.0766198	0.0531759	0.0546954	0.0592052	0.0830783	0.0768462	0.1367988	0.0750842	0.0500672	0.0782608	0.0363348	0.0763454	0.0647705	0.0787175]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.5*mu+0.003;
% slope = 3; levelshift = 2;
% agridsize = 150;
% rpgridsize = 600;
% radgridsize = 60;

% Frequency of Price Change:
%    0.91546    0.49348    0.44540    0.25506    0.21335    0.21844    0.11915    0.08396    0.06481    0.06217    0.06175    0.04927    0.03604    0.02872     ||   0.21167 
% Size of Price Changes:
%    0.04923    0.06438    0.18569    0.15979    0.08871    0.03990    0.11357    0.06716    0.10161    0.08841    0.10197    0.08154    0.12468    0.13535     ||   0.09849 
% 
% St.Dev of output = 0.43016 (x10^-2)
% Variance of output = 0.185039104 (x10^-4)





if abs(sum(SectorWeights)-1)> 10^(-10), error('SectorWeights do not sum to one!'), end

% Maximum number of iterations on G
MaxItOnG = 60;

Ssize = agridsize*rpgridsize*radgridsize;

% Solve for the flexible price steady state 
%****************************************************************

par1 = sm*(theta-1)/(theta-sm*(theta-1));

FlexSSC = FlexSSL*par1^(sm/(1-sm))*(1+par1)^(-1/(1-sm));
FlexSSM = par1*FlexSSC;
FlexSSY = FlexSSC + FlexSSM;

omega = (theta-1)/theta*(1-sm)*(1+par1)*FlexSSL^(-psi-1)*FlexSSC^(1-gamma); % Level parameter on disutility of labor
omega2 = omega*(FlexSSL)^psi; % Marginal disutility of changing prices

K = K*FlexSSY;

FlexSSL = log(FlexSSL);
FlexSSC = log(FlexSSC);
if sm > 0
    FlexSSM = log(FlexSSM);
end
FlexSSY = log(FlexSSY);

% Print Out Parameters
%****************************************************************

fprintf('\n')
fprintf('theta:    %5.5f\n',theta)
fprintf('psi:      %5.5f\n',psi)
fprintf('gamma:    %5.5f\n',gamma)
fprintf('sm:       %5.5f\n',sm)
fprintf('\n')
fprintf('Size of State Space: %10.0f\n\n',Ssize)

fprintf('\n')
fprintf('K:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',K(ii)/exp(FlexSSY))
end
fprintf('\n')
fprintf('rho:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',rho(ii))
end
fprintf('\n')
fprintf('sigma_eps:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',sigma_eps(ii))
end
fprintf('\n\n')

% Set gridsizes and grid max and min
%****************************************************************

MaxUncondVar = max(((sigma_eps.^2)./(1-rho.^2)).^(1/2));
MinUncondVar = min(((sigma_eps.^2)./(1-rho.^2)).^(1/2));
MinUncondVar = max(MinUncondVar,sigma_eta);

trunc_eps = 2.5;
amax = trunc_eps*MaxUncondVar;
amin = -trunc_eps*MaxUncondVar;
ainc = (amax-amin)/(agridsize-1) - mod((amax-amin)/(agridsize-1),10^(-5));
amin = amin - mod(amin,10^(-5));
amax = amin + (agridsize-1)*ainc;

fprintf('Gridpoints for "a" off of which the least volatile sector is simulated:\n')
fprintf('2*trunc_eps*MinUncondVar/ainc = %5.3f\n\n',...
    2*trunc_eps*MinUncondVar/ainc)
if 2*trunc_eps*MinUncondVar/ainc < 22
    error('2*trunc_eps*MinUncondVar/ainc < 22: Results unreliable!',...
        2*trunc_eps*MinUncondVar/ainc) %#ok<CTPCT>
end

% rp denotes the real price
% np denotes the nominal price
% The rp grid is a grid for the log of the real price
pimult = 200; % Determines sensitivity of pigrid to mu
rpmax = -amin*(1+pimult*abs(mu));
rpmin = -amax*(1+pimult*abs(mu));
if rpmax < 0.15
    rpmax = 0.15;
    rpmin = -0.15;
end
rpinc = (rpmax-rpmin)/(rpgridsize-1) - mod((rpmax-rpmin)/(rpgridsize-1),10^(-5));
rpmin = rpmin - mod(rpmin,10^(-5));
rpmax = rpmin + (rpgridsize-1)*rpinc;

if rpinc > 0.0075
    error('rpinc > 0.0075: Results unreliable')
end

radmin = FlexSSC - radgridsize/2*rpinc + rad_shift;

% Create the real price and idiosyncratic productivity vectors
%**************************************************************

a = amin:ainc:amax; a = a';

rp = zeros(rpgridsize,1);
rp(1) = rpmin;
for ii = 2:rpgridsize
    rp(ii) = rp(ii-1) + rpinc;
end

rad = zeros(radgridsize,1);
rad(1) = radmin;
for ii = 2:radgridsize
    rad(ii) = rad(ii-1) + rpinc;
end

% Create Probability Distribution for the idiosyncratic shock
%**************************************************************
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)

for ii = 1:NSectors
    Proba(ii).Proba = CreateProba(rho(ii),sigma_eps(ii),a);
end

% Create probability distribution for nominal aggregate demand
%***************************************************************

ProbNgr = CreateProbNgr(mu,sigma_eta,rad);

% Guess a matrix G which gives the log inflation rate given S_t/P_t-1
%**************************************************************

G = zeros(radgridsize,1);
%G = (rp(2)-rp(1))*ones(radgridsize,1);
G(1,1) = -(radgridsize/(2*slope)-mod(radgridsize/(2*slope),1))*(rp(2)-rp(1)) ...
    + levelshift*(rp(2)-rp(1));
for ii = 2:radgridsize
    if mod(ii,slope) == 0
        G(ii,1) = G(ii-1,1) + rp(2) - rp(1);
    else
        G(ii,1) = G(ii-1,1);
    end
end

% Calculate the profit function
%**************************************************************

par1 = psi+1;
par2 = gamma;
par3 = exp(FlexSSC)/exp(FlexSSY);
par4 = exp(FlexSSM)/exp(FlexSSY) - sm;
par5 = 1-sm;

a3d = repmat(a,[1 rpgridsize radgridsize]);

rp3d = repmat(rp,[1 agridsize radgridsize]);
rp3d = permute(rp3d, [2 1 3]);

rad3d = repmat(rad,[1 agridsize rpgridsize]);
rad3d = permute(rad3d,[2 3 1]);

if sm > 0
    l3d = FlexSSL + (par3+par2*par4)/(par5-par1*par4)*(rad3d-FlexSSC);
    m3d = FlexSSM + par1*(l3d - FlexSSL) + par2*(rad3d-FlexSSC);
else
    l3d = FlexSSL + (rad3d-FlexSSC);
    m3d = 0*rad3d;
end

rPi3d = exp(rad3d + m3d).*exp(rp3d).^(1-theta) ...
    - (1-sm)^(sm-1)*sm^(-sm)*omega^(1-sm)*exp(l3d).^(psi*(1-sm)).*exp(rad3d).^(gamma*(1-sm)).*exp(-a3d).*exp(rad3d+m3d).*exp(rp3d).^(-theta);
rPi = reshape(rPi3d,[Ssize 1]);

for ii = 1:NSectors
    menucost(ii).menucost = reshape(omega2*K(ii)*exp(rad3d).^gamma,[Ssize 1]);
end
clear a3d rp3d rad3d rPi3d l3d m3d

% Calculate the ratio of marginal utility
%**************************************************************
% The (i,j)th element of RMU is the ratio of marginal utility in 
% state j of period t+1 to the marginal utility in state i of
% period t.

RMU = ((1./exp(rad))*(exp(rad)')).^(-gamma);

% Initialize ErV matrix (Expected Value next period)
%**************************************************************

for ii = 1:NSectors
    rV(ii).rV = 1.5*ones(Ssize, 1)*max(0,mean(rPi)/(1-beta));
end

rPi3d = reshape(rPi,[agridsize rpgridsize radgridsize]);
tolV = 0.005*rPi3d(floor(agridsize/2),floor(rpgridsize/2),floor(radgridsize/2))/(1-beta);
clear rPi3d
%tolV = 0.03;

% Initialize stationary distribution Q
%**************************************************************

for ii = 1:NSectors
    Q(ii).Q = ones(Ssize,1)/Ssize;
end

tolQ = Q(1).Q(1)/10;

% Solve for the Equilibrium
%**************************************************************

[G,rV,F,Q] = EqSolverGeNBasic(rPi,menucost,RMU,beta,theta,a,rp,rad,...
    Proba,ProbNgr,rV,Q,G,SectorWeights,tolV,tolQ,MaxItOnG,1);

GError = CalcGErrorMultiSector(Q,F,G,a,rp,rad,theta,...
    Proba,ProbNgr,SectorWeights);

PCStats = RigidityStatsMultiSector(Q,F,SectorWeights,a,rp,rad);

fprintf('agridsize:   %5.2f\n',agridsize)
fprintf('rpgridsize:  %5.2f\n',rpgridsize)
fprintf('radgridsize: %5.2f\n',radgridsize)
fprintf('Ssize:       %5.2f\n\n',Ssize)

fprintf('\n')
fprintf('K:\n')
for ii = 1:NSectors
    fprintf('   %5.5f ',K(ii)/exp(FlexSSY))
end
fprintf('\n')
fprintf('rho:\n')
for ii = 1:NSectors
    fprintf('   %5.5f ',rho(ii))
end
fprintf('\n')
fprintf('sigma_eps:\n')
for ii = 1:NSectors
    fprintf('   %5.5f ',sigma_eps(ii))
end
fprintf('\n\n')

fprintf('\n')
fprintf('Frequency of Price Change:\n')
for ii = 1:NSectors
    fprintf('   %5.5f ',PCStats.freq(ii))
end
fprintf('    ||   %5.5f \n',PCStats.avfreq)
fprintf('Frac Up:\n')
for ii = 1:NSectors
    fprintf('   %5.5f ',PCStats.fracup(ii))
end
fprintf('    ||   %5.5f \n',PCStats.avfracup)
fprintf('Size of Price Changes:\n')
for ii = 1:NSectors
    fprintf('   %5.5f ',PCStats.sizepc(ii))
end
fprintf('    ||   %5.5f \n',PCStats.avsizepc)
fprintf('Size of Price Increases:\n')
for ii = 1:NSectors
    fprintf('   %5.5f ',PCStats.sizeup(ii))
end
fprintf('    ||   %5.5f \n',PCStats.avsizeup)
fprintf('Size of Price Decreases:\n')
for ii = 1:NSectors
    fprintf('   %5.5f ',PCStats.sizedw(ii))
end
fprintf('    ||   %5.5f \n',PCStats.avsizedw)
fprintf('\n')

% Save Model Input and Output
%**************************************************************

% Inputs
GENModel.a = a;
GENModel.rp = rp;
GENModel.rad = rad;
GENModel.K = K;
GENModel.beta = beta;
GENModel.theta = theta;
GENModel.gamma = gamma;
GENModel.omega = omega;
GENModel.omega2 = omega2;
GENModel.rho = rho;
GENModel.sigma_eps = sigma_eps;
GENModel.mu = mu;
GENModel.sigma_eta = sigma_eta;
GENModel.SectorWeights = SectorWeights;

% Outputs
GENModel.G = G;
GENModel.rV = rV;
GENModel.F = F;
GENModel.Q = Q;
GENModel.GError = GError;
GENModel.freq = PCStats.freq;
GENModel.fracup = PCStats.fracup;
GENModel.sizepc = PCStats.sizepc;
GENModel.sizeup = PCStats.sizeup;
GENModel.sizedw = PCStats.sizedw;
GENModel.avfreq = PCStats.avfreq;
GENModel.avfracup = PCStats.avfracup;
GENModel.avsizepc = PCStats.avsizepc;
GENModel.avsizeup = PCStats.avsizeup;
GENModel.avsizedw = PCStats.avsizedw;

save('GENModel','GENModel')


toc

VarFromQ