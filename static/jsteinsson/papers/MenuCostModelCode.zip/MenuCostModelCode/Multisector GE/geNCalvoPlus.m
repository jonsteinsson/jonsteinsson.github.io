% Multisector general equilibrium CalvoPlus model
%
% The state vector is three dimensional. We vectorize it using the
% reshape command. The order of the state variables when they are 
% reshaped is (a, rp, rad)
%
% The structure of this program is very similar to the structure of 
% 'ge1CalvoPlus.m' in the 'One Sector GE' folder. See that file for more 
% detailed documentation.
%
% Jon Steinsson and Emi Nakamura, August 2006
%**************************************************************

clear;
tic

% Set a random seed for the replicability
rng('default') 

% Set Fixed Parameters
%**************************************************************

theta = 4;    % Elasticity of demand
psi = 0;     % One over the Frisch elasticity of labor supply
gamma = 1;   % coefficient of relative risk aversion
FlexSSL = 1/3; % Steady State labor under flexible prices
beta = 0.96^(1/12);   % Discount factor

% Parameters of the process followed by nominal aggregate demand
% log(S_t) - log(S_t-1) = mu + nu_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
mu = 0.0028;
sigma_eta = 0.0065;

% Set sector specific parameters
%***************************************************************
% NB: Edges of the rad grid need to be extra padded in the multi-sector 
% model because the sectors have different mean rad.

NSectors = 6;
sm = 0.7;
K             = [0.00028    0.019    0.0570    0.054    0.0392    0.0789]'; 
sigma_eps     = [ 0.05    0.0855    0.1230    0.088    0.0684    0.090]';
alphaCalvo    = [ 1-0.916  1-0.355   1-0.254   1-0.119   1-0.088   1-0.052]';
rho           = [    0.7       0.7       0.7       0.7       0.7       0.7]';
SectorWeights = [ 0.0766    0.1909    0.0592    0.1368    0.3853    0.1512]';
SectorWeights = SectorWeights/(sum(SectorWeights));
rad_shift = 0.021;
slope = 9; levelshift = 2;
agridsize = 62;
rpgridsize = 1100;
radgridsize = 64;

% Overall: 
% Frequency of Price Change:
%    0.9179    0.3560    0.2553    0.1184    0.0889    0.0567     ||   0.2124 
% Size of Price Changes:
%    0.0470    0.1075    0.1579    0.1118    0.0860    0.1150     ||   0.0993 
% St.Dev of output = 1.13585 (x10^-2)
% Variance of output = 1.290147536 (x10^-4)


% NSectors = 6;
% sm = 0.0;
% K             = [   0.00135    0.0680    0.2060    0.2030     0.1295   0.3205]'; 
% rho           = [      0.7       0.7       0.7       0.7        0.7      0.7]';
% sigma_eps     = [   0.0516    0.0863    0.1240    0.0917     0.0673   0.0943]';
% alphaCalvo    = [  1-0.916   1-0.355   1-0.254   1-0.119    1-0.088  1-0.052]';
% SectorWeights = [   0.0766    0.1909	  0.0592    0.1368     0.3853   0.1512]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.0118;
% slope = 4; levelshift = 3;
% agridsize = 50;
% rpgridsize = 1200;
% radgridsize = 50;

% Overall: 
% Frequency of Price Change:
%    0.9138    0.3561    0.2542    0.1201    0.0921    0.0547     ||   0.2132 
% Size of Price Changes:
%    0.0489    0.1089    0.1593    0.1182    0.0875    0.1179     ||   0.1017 
% St.Dev of output = 0.64199 (x10^-2)
% Variance of output = 0.412145444 (x10^-4)


% NSectors = 9;
% sm = 0.7;
% % K             = [0.00033    0.02    0.055    0.00579    0.0536    0.0325    0.0517    0.0875    0.1476]'; 
% K             = [0.00037    0.02    0.058    0.00589    0.0566    0.0349    0.0517    0.0875    0.1476]'; 
% rho           = [    0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7]';
% sigma_eps     = [ 0.052    0.0870    0.1243    0.0343    0.089    0.061    0.0710    0.0942    0.113]';
% alphaCalvo    = [1-0.916   1-0.355   1-0.254   1-0.197   1-0.119   1-0.076   1-0.055   1-0.052   1-0.032]';
% SectorWeights = [0.0766198	0.1909496	0.0592052	0.0920136	0.1367988	0.0961692	0.0997467	0.1511725	0.0973246]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.0132;
% slope = 9; levelshift = 1;
% agridsize = 76;
% rpgridsize = 1100;
% radgridsize = 70; 

% Overall: 
% Frequency of Price Change:
%    0.9170    0.3540    0.2555    0.1987    0.1165    0.0769    0.0589    0.0556    0.0360     ||   0.2124 
% Size of Price Changes:
%    0.0488    0.1092    0.1596    0.0458    0.1118    0.0765    0.0899    0.1186    0.1358     ||   0.1010 
% St.Dev of output = 1.21341 (x10^-2)
% Variance of output = 1.472359163 (x10^-4)


% NSectors = 9;
% sm = 0.0;
% K             = [ 0.0013    0.0691    0.2060    0.0228    0.2003    0.115    0.1610    0.317    0.5705]'; 
% rho           = [    0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7]';
% sigma_eps     = [ 0.0520    0.0863    0.1240   0.035    0.0895    0.058    0.066    0.094    0.11]';
% alphaCalvo    = [1-0.916   1-0.355   1-0.254   1-0.197   1-0.119   1-0.076   1-0.055   1-0.052   1-0.032]';
% SectorWeights = [0.0766198	0.1909496	0.0592052	0.0920136	0.1367988	0.0961692	0.0997467	0.1511725	0.0973246]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.005;
% slope = 4; levelshift = 1;
% agridsize = 73;
% rpgridsize = 1000;
% radgridsize = 72;

% Overall: 
% Frequency of Price Change:
%    0.9197    0.3547    0.2543    0.1979    0.1179    0.0779    0.0603    0.0550    0.0331     ||   0.2126 
% Size of Price Changes:
%    0.0489    0.1087    0.1593    0.0478    0.1138    0.0745    0.0859    0.1178    0.1220     ||   0.0993 St.Dev of output = 0.67872 (x10^-2)
% Variance of output = 0.460664970 (x10^-4)


% NSectors = 14;
% sm = 0.7;
% K             = [0.00036   0.00453    0.048    0.0573    0.0209   0.0047    0.0544    0.0262    0.0675    0.0535    0.0705    0.065    0.1353    0.21]'; 
% rho           = [    0.7       0.7       0.7       0.7       0.7      0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7]';
% sigma_eps     = [ 0.0526    0.05313    0.152    0.1223    0.0682   0.032    0.0890    0.051    0.085    0.0747    0.0861    0.0720    0.1065    0.1191]';
% alphaCalvo    = [1-0.916   1-0.494   1-0.437   1-0.254   1-0.213  1-0.217   1-0.119   1-0.084   1-0.065   1-0.062   1-0.061   1-0.049   1-0.036   1-0.029]';
% SectorWeights = [0.0766198	0.0531759	0.0546954	0.0592052	0.0830783	0.0768462	0.1367988	0.0750842	0.0500672	0.0782608	0.0363348	0.0763454	0.0647705	0.0787175]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.0135;
% slope = 10; levelshift = 1;
% agridsize = 96;
% rpgridsize = 1000;
% radgridsize = 66;

% Overall: 
% Frequency of Price Change:
%    0.9194    0.4952    0.4320    0.2557    0.2140    0.2188    0.1194    0.0812    0.0668    0.0652    0.0635    0.0493    0.0392    0.0299     ||   0.2120 
% Size of Price Changes:
%    0.0492    0.0633    0.1834    0.1586    0.0886    0.0428    0.1138    0.0635    0.1061    0.0941    0.1079    0.0868    0.1322    0.1360     ||   0.1000 
% St.Dev of output = 1.25462 (x10^-2)
% Variance of output = 1.574068901 (x10^-4)


% NSectors = 14;
% sm = 0.0;
% K             = [ 0.001389    0.0157    0.162    0.2090    0.0726   0.0145    0.1920    0.098    0.2310    0.1802    0.2475    0.200    0.4380    0.638]';
% rho           = [    0.7       0.7       0.7       0.7       0.7      0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7       0.7]';
% sigma_eps     = [ 0.0525    0.0528    0.1537    0.1238    0.0678   0.0300    0.089    0.0555    0.084    0.072    0.0857    0.070    0.101    0.114]';
% alphaCalvo    = [1-0.916   1-0.494   1-0.437   1-0.254   1-0.213  1-0.217   1-0.119   1-0.084   1-0.065   1-0.062   1-0.061   1-0.049   1-0.036   1-0.029]';
% SectorWeights = [0.0766198	0.0531759	0.0546954	0.0592052	0.0830783	0.0768462	0.1367988	0.0750842	0.0500672	0.0782608	0.0363348	0.0763454	0.0647705	0.0787175]';
% SectorWeights = SectorWeights/(sum(SectorWeights));
% rad_shift = 0.01;
% slope = 4; levelshift = 2;
% agridsize = 104;
% rpgridsize = 1100;
% radgridsize = 68;
% 
% Overall: 
% Frequency of Price Change:
%    0.9162    0.4955    0.4388    0.2543    0.2146    0.2243    0.1199    0.0865    0.0680    0.0653    0.0640    0.0526    0.0394    0.0316     ||   0.2135 
% Size of Price Changes:
%    0.0495    0.0633    0.1857    0.1605    0.0888    0.0418    0.1145    0.0721    0.1064    0.0916    0.1083    0.0887    0.1254    0.1375     ||   0.1006 
% 
% St.Dev of output = 0.67940 (x10^-2)
% Variance of output = 0.461589170 (x10^-4)



if abs(sum(SectorWeights)-1)> 10^(-10), error('SectorWeights do not sum to one!'), end

% Maximum number of iterations on G
MaxItOnG = 60;

Ssize = agridsize*rpgridsize*radgridsize;

K2 = K/40;

% Solve for the flexible price steady state 
%****************************************************************

par1 = sm*(theta-1)/(theta-sm*(theta-1));

FlexSSC = FlexSSL*par1^(sm/(1-sm))*(1+par1)^(-1/(1-sm));
FlexSSM = par1*FlexSSC;
FlexSSY = FlexSSC + FlexSSM;

omega = (theta-1)/theta*(1-sm)*(1+par1)*FlexSSL^(-psi-1)*FlexSSC^(1-gamma); % Level parameter on disutility of labor
omega2 = omega*(FlexSSL)^psi; % Marginal disutility of changing prices

K = K*FlexSSY;
K2 = K2*FlexSSY;

FlexSSL = log(FlexSSL);
FlexSSC = log(FlexSSC);
if sm > 0
    FlexSSM = log(FlexSSM);
end
FlexSSY = log(FlexSSY);

% Print Out Parameters
%****************************************************************

fprintf('\n')
fprintf('theta:    %5.5f\n',theta)
fprintf('psi:      %5.5f\n',psi)
fprintf('gamma:    %5.5f\n',gamma)
fprintf('sm:       %5.5f\n',sm)
fprintf('\n')
fprintf('Size of State Space: %10.0f\n\n',Ssize)

fprintf('\n')
fprintf('K:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',K(ii)/exp(FlexSSY))
end
fprintf('\n')
fprintf('rho:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',rho(ii))
end
fprintf('\n')
fprintf('sigma_eps:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',sigma_eps(ii))
end
fprintf('\n\n')

% Set gridsizes and grid max and min
%****************************************************************

MaxUncondVar = max(((sigma_eps.^2)./(1-rho.^2)).^(1/2));
MinUncondVar = min(((sigma_eps.^2)./(1-rho.^2)).^(1/2));
MinUncondVar = max(MinUncondVar,sigma_eta);

trunc_eps = 2.5;
amax = trunc_eps*MaxUncondVar;
amin = -trunc_eps*MaxUncondVar;
ainc = (amax-amin)/(agridsize-1) - mod((amax-amin)/(agridsize-1),10^(-5));
amin = amin - mod(amin,10^(-5));
amax = amin + (agridsize-1)*ainc;

fprintf('Gridpoints for "a" off of which the least volatile sector is simulated:\n')
fprintf('2*trunc_eps*MinUncondVar/ainc = %5.3f\n\n',...
    2*trunc_eps*MinUncondVar/ainc)
if 2*trunc_eps*MinUncondVar/ainc < 20
    error('2*trunc_eps*MinUncondVar/ainc < 20: Results unreliable!',...
        2*trunc_eps*MinUncondVar/ainc) %#ok<CTPCT>
end

% rp denotes the real price
% np denotes the nominal price
% The rp grid is a grid for the log of the real price
pimult = 200; % Determines sensitivity of pigrid to mu
rpmax = -amin*(1+pimult*abs(mu));
rpmin = -amax*(1+pimult*abs(mu));
if rpmax < 0.15
    rpmax = 0.15;
    rpmin = -0.15;
end
rpinc = (rpmax-rpmin)/(rpgridsize-1) - mod((rpmax-rpmin)/(rpgridsize-1),10^(-5));
rpmin = rpmin - mod(rpmin,10^(-5));
rpmax = rpmin + (rpgridsize-1)*rpinc;

if rpinc > 0.0075
    error('rpinc > 0.0075: Results unreliable')
end

radmin = FlexSSC - radgridsize/2*rpinc + rad_shift;

% Create the real price and idiosyncratic productivity vectors
%**************************************************************

a = amin:ainc:amax; a = a';

rp = zeros(rpgridsize,1);
rp(1) = rpmin;
for ii = 2:rpgridsize
    rp(ii) = rp(ii-1) + rpinc;
end

rad = zeros(radgridsize,1);
rad(1) = radmin;
for ii = 2:radgridsize
    rad(ii) = rad(ii-1) + rpinc;
end

% Create Probability Distribution for the idiosyncratic shock
%**************************************************************
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)

for ii = 1:NSectors
    Proba(ii).Proba = CreateProba(rho(ii),sigma_eps(ii),a);
end

% Create probability distribution for nominal aggregate demand
%***************************************************************

ProbNgr = CreateProbNgr(mu,sigma_eta,rad);

% Guess a matrix G which gives the log inflation rate given S_t/P_t-1
%**************************************************************

G = zeros(radgridsize,1);
%G = (rp(2)-rp(1))*ones(radgridsize,1);
G(1,1) = -(radgridsize/(2*slope)-mod(radgridsize/(2*slope),1))*(rp(2)-rp(1)) ...
    + levelshift*(rp(2)-rp(1));
for ii = 2:radgridsize
    if mod(ii,slope) == 0
        G(ii,1) = G(ii-1,1) + rp(2) - rp(1);
    else
        G(ii,1) = G(ii-1,1);
    end
end

% Calculate the profit function
%**************************************************************

par1 = psi+1;
par2 = gamma;
par3 = exp(FlexSSC)/exp(FlexSSY);
par4 = exp(FlexSSM)/exp(FlexSSY) - sm;
par5 = 1-sm;

a3d = repmat(a,[1 rpgridsize radgridsize]);

rp3d = repmat(rp,[1 agridsize radgridsize]);
rp3d = permute(rp3d, [2 1 3]);

rad3d = repmat(rad,[1 agridsize rpgridsize]);
rad3d = permute(rad3d,[2 3 1]);

if sm > 0
    l3d = FlexSSL + (par3+par2*par4)/(par5-par1*par4)*(rad3d-FlexSSC);
    m3d = FlexSSM + par1*(l3d - FlexSSL) + par2*(rad3d-FlexSSC);
else
    l3d = FlexSSL + (rad3d-FlexSSC);
    m3d = 0*rad3d;
end

rPi3d = exp(rad3d + m3d).*exp(rp3d).^(1-theta) ...
    - (1-sm)^(sm-1)*sm^(-sm)*omega^(1-sm)*exp(l3d).^(psi*(1-sm)).*exp(rad3d).^(gamma*(1-sm)).*exp(-a3d).*exp(rad3d+m3d).*exp(rp3d).^(-theta);
rPi = reshape(rPi3d,[Ssize 1]);

for ii = 1:NSectors
    menucost(ii).menucost = reshape(omega2*K(ii)*exp(rad3d).^gamma,[Ssize 1]);
end

for ii = 1:NSectors
    menucost2(ii).menucost2 = reshape(omega2*K2(ii)*exp(rad3d).^gamma,[Ssize 1]);
end

clear a3d rp3d rad3d rPi3d l3d m3d

% Calculate the ratio of marginal utility
%**************************************************************
% The (i,j)th element of RMU is the ratio of marginal utility in 
% state j of period t+1 to the marginal utility in state i of
% period t.

RMU = ((1./exp(rad))*(exp(rad)')).^(-gamma);

% Initialize ErV matrix (Expected Value next period)
%**************************************************************

for ii = 1:NSectors
    rV(ii).rV = 1.5*ones(Ssize, 1)*max(0,mean(rPi)/(1-beta));
end

rPi3d = reshape(rPi,[agridsize rpgridsize radgridsize]);
tolV = 0.005*rPi3d(floor(agridsize/2),floor(rpgridsize/2),floor(radgridsize/2))/(1-beta);
clear rPi3d
%tolV = 0.03;

% Initialize stationary distribution Q
%**************************************************************

for ii = 1:NSectors
    Q(ii).Q = ones(Ssize,1)/Ssize;
end

tolQ = Q(1).Q(1)/10;

% Solve for the Equilibrium
%**************************************************************

[G,rV,F,F2,Q] = EqSolverGeNCalvoPlus(rPi,menucost,menucost2,RMU,alphaCalvo,...
    beta,theta,a,rp,rad,Proba,ProbNgr,rV,Q,G,SectorWeights,tolV,tolQ,MaxItOnG,1);

GError = CalcGErrorMultiSectorCalvoPlus(Q,F,F2,G,alphaCalvo,a,rp,rad,theta,...
    Proba,ProbNgr,SectorWeights);

PCStats = RigidityStatsMultiSectorCalvoPlus(Q,F,F2,alphaCalvo,...
    SectorWeights,a,rp,rad);


fprintf('\n')
fprintf('GeN CalvoPlus\n\n')
fprintf('theta:     %5.5f\n',theta)
fprintf('psi:       %5.5f\n',psi)
fprintf('gamma:     %5.5f\n',gamma)
fprintf('sm:        %5.5f\n',sm)
fprintf('mu:        %5.5f\n',mu)
fprintf('sigma_eta: %5.5f\n',sigma_eta)
fprintf('FlexSSC:   %5.5f\n',exp(FlexSSC))

fprintf('K(i)/FlexSSY:  ')
for ii = 1:NSectors
    fprintf('   %5.4f ',K(ii)/exp(FlexSSY))
end
fprintf('\n')

fprintf('K2(i)/FlexSSY: ')
for ii = 1:NSectors
    fprintf('   %5.4f ',K2(ii)/exp(FlexSSY))
end
fprintf('\n')

fprintf('1-alphaCalvo:  ')
for ii = 1:NSectors
    fprintf('   %5.4f ',1-alphaCalvo(ii))
end
fprintf('\n')

fprintf('rho:           ')
for ii = 1:NSectors
    fprintf('   %5.4f ',rho(ii))
end
fprintf('\n')

fprintf('sigma_eps:     ')
for ii = 1:NSectors
    fprintf('   %5.4f ',sigma_eps(ii))
end
fprintf('\n')

fprintf('Sector Weights:')
for ii = 1:NSectors
    fprintf('   %5.4f ',SectorWeights(ii))
end
fprintf('\n')

fprintf('Overall: \n')
fprintf('Frequency of Price Change:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.freq(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfreq)
fprintf('Frac Up:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.fracup(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfracup)
fprintf('Size of Price Changes:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizepc(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizepc)
fprintf('Size of Price Increases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizeup(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizeup)
fprintf('Size of Price Decreases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizedw(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizedw)
fprintf('\n')

fprintf('High Cost State\n')
fprintf('Frequency of Price Change:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.freq1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfreq1)
fprintf('Frac Up:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.fracup1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfracup1)
fprintf('Size of Price Changes:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizepc1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizepc1)
fprintf('Size of Price Increases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizeup1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizeup1)
fprintf('Size of Price Decreases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizedw1(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizedw1)
fprintf('\n')

fprintf('Low Cost State\n')
fprintf('Frequency of Price Change:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.freq2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfreq2)
fprintf('Frac Up:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.fracup2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avfracup2)
fprintf('Size of Price Changes:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizepc2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizepc2)
fprintf('Size of Price Increases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizeup2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizeup2)
fprintf('Size of Price Decreases:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',PCStats.sizedw2(ii))
end
fprintf('    ||   %5.4f \n',PCStats.avsizedw2)
fprintf('\n')

fprintf('Fraction of Price Changes in Low Cost State:\n')
for ii = 1:NSectors
    fprintf('   %5.4f ',(1-alphaCalvo(ii))*PCStats.freq2(ii)/PCStats.freq(ii))
end

% Save Model Input and Output
%**************************************************************

% Inputs
GENModel.a = a;
GENModel.rp = rp;
GENModel.rad = rad;
GENModel.K = K;
GENModel.K2 = K2;
GENModel.beta = beta;
GENModel.theta = theta;
GENModel.sm = sm;
GENModel.gamma = gamma;
GENModel.omega = omega;
GENModel.omega2 = omega2;
GENModel.rho = rho;
GENModel.sigma_eps = sigma_eps;
GENModel.mu = mu;
GENModel.sigma_eta = sigma_eta;
GENModel.SectorWeights = SectorWeights;
GENModel.alphaCalvo = alphaCalvo;

% Outputs
GENModel.G = G;
%GENModel.rV = rV;
GENModel.F = F;
GENModel.F2 = F2;
GENModel.Q = Q;
GENModel.GError = GError;
GENModel.freq = PCStats.freq1;
GENModel.fracup = PCStats.fracup1;
GENModel.sizepc = PCStats.sizepc1;
GENModel.sizeup = PCStats.sizeup1;
GENModel.sizedw = PCStats.sizedw1;
GENModel.avfreq = PCStats.avfreq1;
GENModel.avfracup = PCStats.avfracup1;
GENModel.avsizepc = PCStats.avsizepc1;
GENModel.avsizeup = PCStats.avsizeup1;
GENModel.avsizedw = PCStats.avsizedw1;
GENModel.freq = PCStats.freq2;
GENModel.fracup = PCStats.fracup2;
GENModel.sizepc = PCStats.sizepc2;
GENModel.sizeup = PCStats.sizeup2;
GENModel.sizedw = PCStats.sizedw2;
GENModel.avfreq = PCStats.avfreq2;
GENModel.avfracup = PCStats.avfracup2;
GENModel.avsizepc = PCStats.avsizepc2;
GENModel.avsizeup = PCStats.avsizeup2;
GENModel.avsizedw = PCStats.avsizedw2;
GENModel.freq = PCStats.freq;
GENModel.fracup = PCStats.fracup;
GENModel.sizepc = PCStats.sizepc;
GENModel.sizeup = PCStats.sizeup;
GENModel.sizedw = PCStats.sizedw;
GENModel.avfreq = PCStats.avfreq;
GENModel.avfracup = PCStats.avfracup;
GENModel.avsizepc = PCStats.avsizepc;
GENModel.avsizeup = PCStats.avsizeup;
GENModel.avsizedw = PCStats.avsizedw;

save('GENModel.mat','GENModel', '-v7.3')

toc

VarFromQ