% Creates the probability distribution for movements in real aggregate 
% demand due to movements in nominal aggregate demand
%
% ProbNgr is a matrix that gives the transition probabilities of 
% the real aggregate demand due to changes in nominal aggregate demand 
% for a fixed nominal price level
%
% ProbNgr give the probabilities of going from state rad to state 
% rad', i.e. ProbNgr(i,j) = Prob(rad' = j | rad = i)
%
% The evolution of the nominal aggregate demand is governed by:
% log(S_t) - log(S_t-1) = mu + eta_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
%
% The exact distribution is approximated using a 
% method analogous to the Tauchen (1986) method for AR models
%
% The three imputs are:
% 1. Average growth rate of nominal aggregate demand
% 2. St. Dev. of shocks to the growth rate of nominal aggregate deamnd (sigma_eta)
% 3. Grid for rad
%
% Jon Steinsson and Emi Nakamura, July 2006
%*************************************************************

function ProbNgr = CreateProbNgr(mu,sigma_eta,rad_grid)

radgridsize = size(rad_grid,1);

rad_old = repmat(rad_grid+mu,1,radgridsize-1);
sigma_eta_matrix = repmat(sigma_eta,radgridsize,radgridsize-1);

rad_j = (rad_grid(1:end-1,1)+rad_grid(2:end,1))/2;
rad_j_matrix = repmat(rad_j',radgridsize,1);

rad_norm = normcdf(rad_j_matrix,rad_old,sigma_eta_matrix);

rad_norm_up = [rad_norm ones(radgridsize,1)];
rad_norm_dwn = [zeros(radgridsize,1) rad_norm];

ProbNgr = rad_norm_up - rad_norm_dwn;

ProbNgr = ProbNgr.*(ProbNgr > 10^(-6));
ProbNgr = ProbNgr./(sum(ProbNgr')'*(ones(1,radgridsize)));
