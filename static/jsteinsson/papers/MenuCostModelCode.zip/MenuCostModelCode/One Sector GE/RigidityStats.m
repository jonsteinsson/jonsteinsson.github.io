% Calculates statistics about price changes from the stationary 
% distribution
%
% Jon Steinsson and Emi Nakamura, July 2006
%**************************************************************

function PCStats = RigidityStats(Q,F,a,rp,rad)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

Q = reshape(Q,[Ssize 1]);
F = reshape(F,[Ssize 1]);

% Calculate frequency of price change
%***************************************************************

rpBig = repmat(rp,[1 agridsize radgridsize]);
rpBig = permute(rpBig,[2 1 3]);
rpBig = reshape(rpBig,[Ssize 1]);

PriceChange = (rpBig ~= F);

PCStats.freq = sum(PriceChange.*Q);

% Calculate fraction of price changes that are increases
%***************************************************************

PriceIncrease = (F > rpBig);
PriceDecrease = (F < rpBig);

PCStats.frequp = sum(PriceIncrease.*Q);
PCStats.freqdw = sum(PriceDecrease.*Q);
PCStats.fracup = sum(PriceIncrease.*Q)/PCStats.freq;
if PCStats.fracup == 1
    PCStats.fracup = 0.9999;
elseif PCStats.fracup == 0
    PCStats.fracup = 0.0001;
end

% Calculate absolute size of price changes, price increases and 
% price decreases
%****************************************************************

AbsSizePC  = abs(F-rpBig);

PCStats.sizepc = sum(AbsSizePC.*Q)/PCStats.freq;
PCStats.sizeup = sum(AbsSizePC.*Q.*PriceIncrease)/(PCStats.freq*PCStats.fracup);
PCStats.sizedw = sum(AbsSizePC.*Q.*PriceDecrease)/(PCStats.freq*(1-PCStats.fracup));
