% Calculates statistics about price changes from the stationary 
% distribution
%
% Jon Steinsson and Emi Nakamura, August 2006
%**************************************************************

function PCStats = RigidityStatsCalvoPlus(Q,F,F2,alphaCalvo,a,rp,rad)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

Q = reshape(Q,[Ssize 1]);
F = reshape(F,[Ssize 1]);
F2 = reshape(F2,[Ssize 1]);

% Calculate frequency of price change
%***************************************************************

rpBig = repmat(rp,[1 agridsize radgridsize]);
rpBig = permute(rpBig,[2 1 3]);
rpBig = reshape(rpBig,[Ssize 1]);

PriceChange_mc = (rpBig ~= F);
PriceChange_mc2 = (rpBig ~= F2);

PCStats.freq_mc = sum(PriceChange_mc.*Q);
PCStats.freq_mc2 = sum(PriceChange_mc2.*Q);;
PCStats.freq = alphaCalvo*PCStats.freq_mc + (1-alphaCalvo)*PCStats.freq_mc2;

% Calculate fraction of price changes that are increases
%***************************************************************

PriceIncrease_mc = (F > rpBig);
PriceDecrease_mc = (F < rpBig);

PriceIncrease_mc2 = (F2 > rpBig);
PriceDecrease_mc2 = (F2 < rpBig);

PCStats.fracup_mc = sum(PriceIncrease_mc.*Q)/PCStats.freq_mc;
PCStats.fracup_mc2 = sum(PriceIncrease_mc2.*Q)/PCStats.freq_mc2;

PCStats.fracup = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.fracup_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.fracup_mc2;

% Calculate absolute size of price changes, price increases and 
% price decreases
%****************************************************************

AbsSizePC_mc  = abs(F-rpBig);
AbsSizePC_mc2  = abs(F2-rpBig);

PCStats.sizepc_mc = sum(AbsSizePC_mc.*Q)/PCStats.freq_mc;
PCStats.sizepc_mc2 = sum(AbsSizePC_mc2.*Q)/PCStats.freq_mc2;
PCStats.sizepc = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.sizepc_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.sizepc_mc2;

PCStats.sizeup_mc = sum(AbsSizePC_mc.*Q.*PriceIncrease_mc)/(PCStats.freq_mc*PCStats.fracup_mc);
PCStats.sizeup_mc2 = sum(AbsSizePC_mc2.*Q.*PriceIncrease_mc2)/(PCStats.freq_mc2*PCStats.fracup_mc2);
PCStats.sizeup = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.sizeup_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.sizeup_mc2;

PCStats.sizedw_mc = sum(AbsSizePC_mc.*Q.*PriceDecrease_mc)/(PCStats.freq_mc*(1-PCStats.fracup_mc));
PCStats.sizedw_mc2 = sum(AbsSizePC_mc2.*Q.*PriceDecrease_mc2)/(PCStats.freq_mc2*(1-PCStats.fracup_mc2));
PCStats.sizedw = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.sizedw_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.sizedw_mc2;
