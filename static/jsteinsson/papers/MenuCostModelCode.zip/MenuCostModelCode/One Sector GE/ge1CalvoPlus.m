% One sector general equilibrium hybrid menu cost/Calvo model
%
% 1. I.i.d. growth in nominal aggregate demand (non-zero mean)
% 2. AR(1)-normal idiosyncratic productivity shocks
% 3. Homoskedastic errors to idiosyncratic shocks
% 4. Cobb-Douglas productions function
% 5. Power utility of consumption and power disutility of labor
% 6. Homogeneous labor market
%
% The state vector is three dimensional. We vectorize it using the
% reshape command. The order of the state variables when they are 
% reshaped is (a, rp, rad)
%
% Jon Steinsson and Emi Nakamura, August 2006
%**************************************************************

clear;
tic

% Set a random seed for the replicability
rng('default')

% Set Parameters
%**************************************************************

theta = 4;    % Elasticity of demand
psi = 0;     % One over the Frisch elasticity of labor supply
gamma = 1;   % coefficient of relative risk aversion
FlexSSL = 1/3; % Steady State labor under flexible prices
beta = 0.96^(1/12);   % Discount factor

% Parameters of the process followed by nominal aggregate demand
% log(S_t) - log(S_t-1) = mu + nu_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
mu = 0.0028;
sigma_eta = 0.0065;

% Parameters of the idiosyncratic productivity process (log A_it)
% log(A_it) = rho*log(A_it-1) + eps_it
% where eps_it ~ N(0,sigma_eps^2), i.i.d. 
% The process is truncated at +/- trunc_eps multiples of the unconditional 
% standard deviation of log(A) 
rho = 0.7;
% sigma_eps is set below

% Intermediate inputs share in production
% sm is set below

% Menu cost
% K denotes the menu cost in the high menu cost state
% K2 denotes the menu cost in the low menu cost state
% K is set below
% Notice: In the notation of the paper this is "K/Y_ss"
% while menu cost reported in table 6-9 in the paper is 
% "((theta-1)/theta)*(K/Y_ss)". So the numbers in the tables
% should be multiplied by theta/(theta-1) when plugged in here
% to replicate the results in the paper.

% 1 minus frequency of "free" price changes
% alphaCalvo is set below

% Location of the middle of the rad grid relative to the no-uncertainty 
% steady state value of rad
% rad_shift is set below. 

% The slope and level of the initial guess for the function G function
% i.e. the function Gamma in our Multi-Sector Menu Cost paper.
% The initial guess is a step function. "slope" gives the number of grid
% points on the rad grid between steps in this step function. This means
% that the slope is greater for lower values of "slope".
% If levelshift = 0 the Gamma function take a value of zero (in logs) in 
% the middle of the grid. More generally, if levelshift = N the Gamma
% function takes a value N gridpoints above zero in the middle of the grid.
% slope and levelshift are set below. 

% Number of points on the grid for each of the three state variables
% agridsize, rpgridsize and radgridsize are set below.


% Select the model to run by commenting / uncommenting 
% the corresponding calibration

% Calibration to the mean
%************************
sm = 0.7;
K             = 0.014  ;
sigma_eps     =  0.062 ; 
alphaCalvo    = 1-0.185;
rad_shift = 0.021;
slope = 9; levelshift = 2;
agridsize = 80;
rpgridsize = 600;
radgridsize = 60; 

% Frequency of Price Change:   0.083  0.791  |  0.214
% Size of Price Changes:       0.135  0.061  |  0.085

% St.Dev of output = 0.00615
% Variance of output = 0.378755262 (x10^-4)

% sm = 0;
% K             = 0.051  ;
% sigma_eps     =  0.061 ; 
% alphaCalvo    = 1-0.185;
% rad_shift = 0.021;
% slope = 9; levelshift = 2;
% agridsize = 80;
% rpgridsize = 600;
% radgridsize = 60;
% 
% Frequency of Price Change:   0.078  0.787  |  0.209
% Size of Price Changes:       0.135  0.060  |  0.083
% 
% St.Dev of output = 0.00389
% Variance of output = 0.150974462 (x10^-4)


% Calibration to the median
%**************************
% sm = 0.7;
% K             = 0.038  ; 
% sigma_eps     =  0.069 ;
% alphaCalvo    = 1-0.085;
% rad_shift = 0.021;
% slope = 9; levelshift = 2;
% agridsize = 40;
% rpgridsize = 400;
% radgridsize = 50;

% Frequency of Price Change:   0.027  0.730  |  0.086
% Size of Price Changes:       0.148  0.059  |  0.084
% 
% St.Dev of output = 0.01236
% Variance of output = 1.528559277 (x10^-4)

% sm = 0;
% K             = 0.13  ; 
% sigma_eps     =  0.067 ;
% alphaCalvo    = 1-0.085;
% rad_shift = 0.021;
% slope = 9; levelshift = 2;
% agridsize = 40;
% rpgridsize = 400;
% radgridsize = 50;

% Frequency of Price Change:   0.028  0.736  |  0.088
% Size of Price Changes:       0.145  0.058  |  0.083
% 
% St.Dev of output = 0.00755
% Variance of output = 0.570181257 (x10^-4)



K2 = K/40 ; 
% Maximum number of iterations on G
MaxItOnG = 100;

Ssize = agridsize*rpgridsize*radgridsize;

% Solve for the flexible price steady state 
%****************************************************************

par1 = sm*(theta-1)/(theta-sm*(theta-1));

FlexSSC = FlexSSL*par1^(sm/(1-sm))*(1+par1)^(-1/(1-sm));
FlexSSM = par1*FlexSSC;
FlexSSY = FlexSSC + FlexSSM;

omega = (theta-1)/theta*(1-sm)*(1+par1)*FlexSSL^(-psi-1)*FlexSSC^(1-gamma); % Level parameter on disutility of labor
omega2 = omega*(FlexSSL)^psi; % Marginal disutility of changing prices

K = K*FlexSSY;
K2 = K2*FlexSSY;

FlexSSL = log(FlexSSL);
FlexSSC = log(FlexSSC);
if sm > 0
    FlexSSM = log(FlexSSM);
end
FlexSSY = log(FlexSSY);


% Print Out Parameters
%****************************************************************

fprintf('\n')
fprintf('ge1sc4CalvoPlus2')
fprintf('\n')
fprintf('theta:          %5.5f\n',theta)
fprintf('psi:            %5.5f\n',psi)
fprintf('gamma:          %5.5f\n',gamma)
fprintf('sm:             %5.5f\n',sm)
fprintf('K:              %5.5f\n',K)
fprintf('K2:              %5.6f\n',K2)
fprintf('1-alphaCalvo:   %5.5f\n',1-alphaCalvo)
fprintf('rho:            %5.5f\n',rho)
fprintf('sigma:          %5.5f\n',sigma_eps)
fprintf('FlexSSC:        %5.5f\n',exp(FlexSSC))
fprintf('K/FlexSSY:      %5.5f\n',K/exp(FlexSSY))
fprintf('K2/FlexSSY:      %5.6f\n\n',K2/exp(FlexSSY))
fprintf('Size of State Space: %10.0f\n\n',Ssize)

% Set grid parameters
%****************************************************************

if agridsize < 22
    error('agridsize < 22: Results unreliable!')
end

trunc_eps = 2.5;
amax = trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
amin = -trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
ainc = (amax-amin)/(agridsize-1) - mod((amax-amin)/(agridsize-1),10^(-5));
amin = amin - mod(amin,10^(-5));
amax = amin + (agridsize-1)*ainc;

% rp denotes the real price
% np denotes the nominal price
% The rp grid is a grid for the log of the real price
pimult = 200; % Determines sensitivity of pigrid to mu
rpmax = -amin*(1+pimult*abs(mu));
rpmin = -amax*(1+pimult*abs(mu));
if rpmax < 0.15
    rpmax = 0.15;
    rpmin = -0.15;
end
rpinc = (rpmax-rpmin)/(rpgridsize-1) - mod((rpmax-rpmin)/(rpgridsize-1),10^(-5));
rpmin = rpmin - mod(rpmin,10^(-5));
rpmax = rpmin + (rpgridsize-1)*rpinc;

if rpinc > 0.0075
    error('rpinc > 0.0075: Results unreliable')
end

radmin = FlexSSC - radgridsize/2*rpinc + rad_shift;

% Create the real price and idiosyncratic productivity vectors
%**************************************************************

a = amin:ainc:amax; a = a';

rp = zeros(rpgridsize,1);
rp(1) = rpmin;
for ii = 2:rpgridsize
    rp(ii) = rp(ii-1) + rpinc;
end

rad = zeros(radgridsize,1);
rad(1) = radmin;
for ii = 2:radgridsize
    rad(ii) = rad(ii-1) + rpinc;
end

% Create Probability Distribution for the idiosyncratic shock
%**************************************************************
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)

Proba = CreateProba(rho,sigma_eps,a);

%fprintf('Proba(1:8,1:8) ')
%Proba(1:8,1:8)

% Create probability distribution for nominal aggregate demand
%***************************************************************

ProbNgr = CreateProbNgr(mu,sigma_eta,rad);

%fprintf('ProbaNgr(1:8,1:8) ')
%ProbNgr(1:8,1:8)

% Guess a matrix G which gives the log inflation rate given S_t/P_t-1
%**************************************************************

G = zeros(radgridsize,1);
%G = (rp(2)-rp(1))*ones(radgridsize,1);
G(1,1) = -(radgridsize/(2*slope)-mod(radgridsize/(2*slope),1))*(rp(2)-rp(1)) ...
    + levelshift*(rp(2)-rp(1));
for ii = 2:radgridsize
    if mod(ii,slope) == 0
        G(ii,1) = G(ii-1,1) + rp(2) - rp(1);
    else
        G(ii,1) = G(ii-1,1);
    end
end
%figure(99)
%plot(rad,G)

% Calculate the profit function
%**************************************************************

par1 = psi+1;
par2 = gamma;
par3 = exp(FlexSSC)/exp(FlexSSY);
par4 = exp(FlexSSM)/exp(FlexSSY) - sm;
par5 = 1-sm;

a3d = repmat(a,[1 rpgridsize radgridsize]);

rp3d = repmat(rp,[1 agridsize radgridsize]);
rp3d = permute(rp3d, [2 1 3]);

rad3d = repmat(rad,[1 agridsize rpgridsize]);
rad3d = permute(rad3d,[2 3 1]);

if sm > 0
    l3d = FlexSSL + (par3+par2*par4)/(par5-par1*par4)*(rad3d-FlexSSC);
    m3d = FlexSSM + par1*(l3d - FlexSSL) + par2*(rad3d-FlexSSC);
else
    l3d = FlexSSL + (rad3d-FlexSSC);
    m3d = 0*rad3d;
end

rPi3d = exp(rad3d + m3d).*exp(rp3d).^(1-theta) ...
    - (1-sm)^(sm-1)*sm^(-sm)*omega^(1-sm)*exp(l3d).^(psi*(1-sm)).*exp(rad3d).^(gamma*(1-sm)).*exp(-a3d).*exp(rad3d+m3d).*exp(rp3d).^(-theta);
rPi = reshape(rPi3d,[Ssize 1]);

menucost3d = omega2*K*exp(rad3d).^gamma;
menucost = reshape(menucost3d,[Ssize 1]);

menucost3d = omega2*K2*exp(rad3d).^gamma;
menucost2 = reshape(menucost3d,[Ssize 1]);

clear a3d rp3d rad3d rPi3d menucost3d l3d m3d

% figure(4)
% rPi_plot = reshape(rPi,[agridsize rpgridsize radgridsize]);
% rPi_plot = squeeze(rPi_plot(:,:,1));
% surf(a,rp,rPi_plot')
% title('Profit Function')
% xlabel('a')
% ylabel('rp')

% Calculate the ratio of marginal utility
%**************************************************************
% The (i,j)th element of RMU is the ratio of marginal utility in 
% state j of period t+1 to the marginal utility in state i of
% period t.

RMU = ((1./exp(rad))*(exp(rad)')).^(-gamma);

% Initialize ErV matrix (Expected Value next period)
%**************************************************************

ErV = 1.5*ones(Ssize, 1)*max(0,mean(rPi)/(1-beta));
rPi3d = reshape(rPi,[agridsize rpgridsize radgridsize]);
tolV = 0.001*rPi3d(floor(agridsize/2),floor(rpgridsize/2),floor(radgridsize/2))/(1-beta);
clear rPi3d

fprintf('tolV:     %10.6f\n',tolV)

% Initialize stationary distribution Q
%**************************************************************

Qinit = ones(Ssize,1)/Ssize;
tolQ = Qinit(1)/15;

% Solve for the Equilibrium
%**************************************************************

[G,rV,F,F2,Q] = EqSolverGE1CalvoPlus(rPi,menucost,menucost2,alphaCalvo,...
    RMU,beta,theta,a,rp,rad,Proba,ProbNgr,ErV,Qinit,G,tolV,tolQ,MaxItOnG,1);

GError = CalcGErrorCalvoPlus(G,F,F2,Q,a,rp,rad,alphaCalvo,theta,Proba,ProbNgr);

PCStats = RigidityStatsCalvoPlus(Q,F,F2,alphaCalvo,a,rp,rad);

fprintf('\n')
fprintf('ge1GECalvoPlus')
fprintf('\n')
fprintf('theta:          %5.5f\n',theta)
fprintf('psi:            %5.5f\n',psi)
fprintf('gamma:          %5.5f\n',gamma)
fprintf('sm:             %5.5f\n',sm)
fprintf('K:              %5.5f\n',K)
fprintf('K2:              %5.6f\n',K2)
fprintf('1-alphaCalvo:   %5.5f\n',1-alphaCalvo)
fprintf('rho:            %5.5f\n',rho)
fprintf('sigma:          %5.5f\n',sigma_eps)
fprintf('FlexSSC:        %5.5f\n',exp(FlexSSC))
fprintf('K/FlexSSY:      %5.5f\n',K/exp(FlexSSY))
fprintf('K2/FlexSSY:      %5.6f\n\n',K2/exp(FlexSSY))
fprintf('Size of State Space: %10.0f\n\n',Ssize)
fprintf('radinc: %10.5f\n\n',rad(2)-rad(1))
fprintf('\n')
fprintf('Frequency of Price Change:   %5.3f  %5.3f  |  %5.3f\n',...
    PCStats.freq_mc,PCStats.freq_mc2,PCStats.freq)
fprintf('Frac Up:                     %5.3f  %5.3f  |  %5.3f\n',...
    PCStats.fracup_mc,PCStats.fracup_mc2,PCStats.fracup)
fprintf('Size of Price Changes:       %5.3f  %5.3f  |  %5.3f\n',...
    PCStats.sizepc_mc,PCStats.sizepc_mc2,PCStats.sizepc)
fprintf('Size of Price Increases:     %5.3f  %5.3f  |  %5.3f\n',...
    PCStats.sizeup_mc,PCStats.sizeup_mc2,PCStats.sizeup)
fprintf('Size of Price Increases:     %5.3f  %5.3f  |  %5.3f\n',...
    PCStats.sizedw_mc,PCStats.sizedw_mc2,PCStats.sizedw)
fprintf('Fraction of Price Changes:   %5.3f  %5.3f  |  %5.3f\n',...
    alphaCalvo*PCStats.freq_mc/PCStats.freq,(1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq,100)
fprintf('\n')

% Save Model Input and Output
%**************************************************************

% Inputs
GE1Model.a = a;
GE1Model.rp = rp;
GE1Model.rad = rad;
GE1Model.K = K;
GE1Model.K2 = K2;
GE1Model.alphaCalvo = alphaCalvo;
GE1Model.beta = beta;
GE1Model.theta = theta;
GE1Model.psi = psi;
GE1Model.sm = sm;
GE1Model.gamma = gamma;
GE1Model.omega = omega;
GE1Model.omega2 = omega2;
GE1Model.rho = rho;
GE1Model.sigma_eps = sigma_eps;
GE1Model.mu = mu;
GE1Model.sigma_eta = sigma_eta;

% Outputs
GE1Model.G = G;
GE1Model.rV = rV;
GE1Model.F = F;
GE1Model.F2 = F2;
GE1Model.Q = Q;
GE1Model.GError = GError;
GE1Model.freq = PCStats.freq;
GE1Model.fracup = PCStats.fracup;
GE1Model.sizepc = PCStats.sizepc;
GE1Model.sizeup = PCStats.sizeup;
GE1Model.sizedw = PCStats.sizedw;

save('GE1Model','GE1Model')

toc

SimboG1S