% Solves a simple partial equilibrium menu cost model by Bellman function 
% iteration on a grid.
%
% 1. Constant aggregate demand
% 2. I.i.d. growth of the price level (non-zero mean)
% 3. AR(1)-normal idiosyncratic productivity shocks
% 4. Homoskedastic errors
%
% This model has two state variables: the idiosyncratic level of
% productivity and the firms own relative price.
%
% Jon Steinsson and Emi Nakamura, April 2006
%**************************************************************

clear;
tic

% Set Parameters
%**************************************************************

C = 1;      % Aggregate demand
theta = 4;    % Elasticity of demand
beta = 0.96^(1/12);   % Discount factor

% Menu Cost
K = 0.018799*C;

% Parameters of the idiosyncratic productivity process (log A_it)
% log(A_it) = rho*log(A_it-1) + eps_it
% where eps_it ~ N(0,sigma_eps^2), i.i.d. 
% The process is truncated at +/- trunc_eps multiples of the unconditional 
% standard deviation of log(A) 
rho = 0.7;
sigma_eps = 0.0425;
trunc_eps = 3.2;

% Parameters of the process followed by the inflation rate (log(P_t/P_t-1))
% log(P_t) - log(P_t-1) = mu + nu_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
mu = 0.002;
sigma_eta = 0.0032;
inflationrate = (1+mu)^12-1;

% Number of points on the grid for the two state variables
agridsize = 30;
rpgridsize = 150;

% Max and Min point for the grid of "a"
amax = trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
amin = -trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);

% rp denotes the real price
% The rp grid is a grid for the log of the real price
pimult = 200; % Determines sensitivity of pigrid to mu
rpmax = -amin*(1+pimult*mu);
rpmin = -amax*(1+pimult*mu);

if sigma_eps < 0.01
    rpmax = 0.12*(1+pimult*mu);
    rpmin = -0.12*(1+pimult*mu);
end

fprintf('\n')
fprintf('Inflation Rate: %3.1f percent \n',inflationrate*100)
fprintf('sigma_eta:       %5.4f \n',sigma_eta)
fprintf('rho:            %5.4f \n',rho)
fprintf('sigma_eps:      %5.4f \n\n',sigma_eps)
fprintf('amax = %5.4f   amin = %5.4f\n',amax,amin)
fprintf('rpmax = %5.4f  prmin = %5.4f\n',rpmax,rpmin)
fprintf('\n')

% Create the real price and idiosyncratic productivity vectors
%**************************************************************

a = amin:((amax-amin)/(agridsize-1)):amax; a = a';
rp = rpmin:((rpmax-rpmin)/(rpgridsize-1)):rpmax; rp = rp';

% Create Probability Distribution for the idiosyncratic shock
%**************************************************************
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)

Proba = prob_dist_a_hom(rho,sigma_eps,a);

% fprintf('Proba(1:8,1:8) ')
% Proba(1:8,1:8)

%figure(5)
%surf(a,a,Proba)

% Create Probability Distribution for movements in the real price
% due to inflation
%**************************************************************
% ProbInfl is a matrix that gives the transition probabilities of 
% the real price due to inflation when the nominal price is fixed
%
% ProbInfl gives the probabilities of going from state rp to state 
% rp', i.e. ProbInfl(i,j) = Prob(pr' = j | pr = i)
% 
% The exact distribution is approximated using a 
% method analogous to the Tauchen (1986) method for AR models

ProbInfl = prob_dist_infl(mu,sigma_eta,rp);

% fprintf('ProbInfl(1:8,1:8) ')
% ProbInfl(1:8,1:8)

%figure(50)
%surf(rp,rp,ProbInfl)

% Calculate Profit function matrix
%**************************************************************
% Prices vary as one moves down each column
% Productivity varies as one moves across each row

rPi = C*(exp(rp).^(-theta+1)*ones(1,agridsize)...
    -exp(rp).^(-theta)*((theta-1)/theta)*(1./exp(a')));

%figure(4)
%surf(a,rp,rPi)
%title('Profit Function')

% Initialize ErV matrix (Expected Value next period)
%**************************************************************

ErV = ones(rpgridsize,agridsize)*max(0,mean(mean(rPi))/(1-beta));

tolerance = 0.001;

%fprintf('tolerance:     %10.6f\n',tolerance)
%fprintf('min start ErV: %10.2f\n',min(min(ErV)))
%fprintf('max start ErV: %10.2f\n',max(max(ErV)))


% Bellman function iteration
%**************************************************************
% Here we iterate ErV

[rV,F] = VFIterationBasic(rPi,ErV,beta,K,theta,rp,Proba,ProbInfl,...
    tolerance,1,1);

%fprintf('Max rV: %8.3f\n',max(max(rV)))
%fprintf('Min rV: %8.3f\n',min(min(rV)))
%fprintf('Max Dif rV: %8.3f\n',max(max(rV))-min(min(rV)))

%figure(3)
%surf(a,rp,rV)
%title('Value Function');

figure(2)
surf(1./exp(a),exp(rp),exp(F))
title('Policy Function');

%figure(12)
%[C,h] = contour(1./exp(a),exp(rp),exp(F));
%clabel(C,h);
%title('Policy Function');

% Simulate Data Set from the model
%************************************************************

NSim = 250000;
burnin = 100;

[aSim,InflSim,rpSim,npSim,ncostSim,InflSim_sum] ...
    = DataSimBasic(NSim,burnin,a,rp,rho,sigma_eps,mu,sigma_eta,F,1,1);


% Calculate a Kaplin-Meier estimate of the Hazard Function of 
% price changes
%************************************************************
 
% Chop off left-sensored spell
np_firstspell = npSim(1,1);
for i = 2:size(npSim,1)
    if abs(np_firstspell - npSim(i,1)) > 10^(-8)
        npSim = npSim(i:end,1);
        ncostSim = ncostSim(i:end,1);
        rpSim = rpSim(i:end,1);
        aSim = aSim(i:end,1);
        InflSim = InflSim(i:end,1);
        InflSim_sum = InflSim_sum(i:end,1);
        break
    end
end

% Create duration data
%**************************

% Create number of spells by duration data
max_duration = 25;
spells_bydur = zeros(max_duration,1);
updown_pc = zeros(2,1); % first element is number of price increases
% second element is number of price decreases
dur = 1;
for i = 2:size(npSim,1)
    if abs(npSim(i,1)-npSim(i-1,1)) < 0.00000001
        dur = dur + 1;
    else
        if dur > max_duration
            dur = max_duration;
        end
        spells_bydur(dur,1) = spells_bydur(dur,1) + 1;
        if npSim(i,1) > npSim(i-1,1)
            updown_pc(1,1) = updown_pc(1,1) + 1;
        else
            updown_pc(2,1) = updown_pc(2,1) + 1;
        end
        dur = 1;
    end
end

% Calculate risk set data
risk_set = zeros(max_duration,1);
for i = 1:max_duration
    risk_set(i,1) = sum(spells_bydur(i:end,1));
end

% Calculation of Kaplan-Meier Hazard
KM_hazard = zeros(max_duration-1,1);
for i = 1:(max_duration-1)
    if risk_set(i,1) ~= 0
        KM_hazard(i,1) = (risk_set(i,1)-risk_set(i+1,1))/risk_set(i,1);
    end
end

figure(10)
plot(KM_hazard,'LineWidth',2)
title('Kaplan-Meier Hazard Function of Price Change')
set(gca,'FontName','times')
xlabel('Months')
ylabel('Hazard')

% Calculate distribution of real price
%****************************************

[SD SD_post] = StaDist(rpSim,aSim,InflSim,rp,a);

[maxSD_rp maxSD_rp_I] = max(SD_post,[],1);
maxSD_rp = maxSD_rp';
maxSD_rp_I = maxSD_rp_I';
maxSD_a_I = (1:1:size(a,1))';
[maxSD_rp maxSD_rp_I maxSD_a_I];
SD_post2 = SD_post;
for i = 1:agridsize
    xx_pos = maxSD_rp_I(i) + 1;
    xx_neg = maxSD_rp_I(i) - 1;
    yy_pos = maxSD_a_I(i) + 1;
    yy_neg = maxSD_a_I(i) - 1;
    if i == 1
        yy_neg = yy_pos;
    end
    if i == agridsize
        yy_pos = yy_neg;
    end
    if xx_neg == 0
        xx_neg = 2;
    end
    if xx_pos == rpgridsize+1
        xx_pos = xx_pos-2;
    end

    SD_post2(maxSD_rp_I(i),maxSD_a_I(i)) = (SD_post(xx_pos,maxSD_a_I(i)) ...
        + SD_post(xx_neg,maxSD_a_I(i)) + SD_post(maxSD_rp_I(i),yy_pos) ...
        + SD_post(maxSD_rp_I(i),yy_neg))/4;
end


% Calculate inflation rate
InflationRate12m = InflSim_sum(13:end,1) - InflSim_sum(1:end-12,1);

% Calculate frequency of price change, fraction of price changes
% that are increases and average size of price changes
%**************************************************

Npc = 0;
Nupc = 0;
av_size = 0;

for i = 2:size(npSim,1)
    if abs(npSim(i,1)-npSim(i-1,1)) > 0.00000001
        Npc = Npc + 1;
        if npSim(i,1) > npSim(i-1,1)
            Nupc = Nupc + 1;
        end
        size_temp = abs(npSim(i,1)-npSim(i-1,1));
        av_size = (Npc-1)/Npc*av_size + 1/Npc*size_temp;
    end
end

freq_pc = Npc/(size(npSim,1)-1);
frac_up = Nupc/Npc;

fprintf('\n')
fprintf('Frequency of Price Change:     %5.3f\n',freq_pc*100)
fprintf('Fraction Up:                   %5.3f\n',frac_up*100)
fprintf('Average Size of Price Changes: %5.3f\n',av_size*100)
fprintf('\n')

Nplot = 144;
dt = 1/12:1/12:Nplot/12;
dt = dt';

% figure(11)
% plot(dt,exp(rpSim(13:Nplot+12,1)),'b-',...
%     dt,exp(-aSim(13:Nplot+12)),'r-','LineWidth',2)
% title('Real Price and Real Costs')

figure(111)
fig_legend = ['Price       ';'A(z) inverse';'Price Level '];
plot(dt,exp(npSim(13:Nplot+12,1)),'b-',...
    dt,exp(ncostSim(13:Nplot+12)),'r-',...
    dt,exp(InflSim_sum(13:Nplot+12,1)),'g-','LineWidth',2)
%title('Nominal Price and Nominal Costs')
leg1 = legend(fig_legend(1,:),fig_legend(2,:),fig_legend(3,:));
set(gca,'FontName','times')
set(leg1,'FontName','times')
xlabel('Years')
ylabel('Price')

% figure(211)
% fig_legend = ['Price      ';'Price Level'];
% plot(dt,exp(npSim(13:Nplot+12,1)),'b-',...
%     dt,exp(InflSim_sum(13:Nplot+12,1)),'g--','LineWidth',2)
% %title('Nominal Price and Nominal Costs')
% leg1 = legend(fig_legend(1,:),fig_legend(2,:));
% set(gca,'FontName','times')
% set(leg1,'FontName','times')
% xlabel('Years')
% ylabel('Price')

%figure(147)
%plot(dt,InflationRate12m(1:Nplot,1),'b-','LineWidth',2)
%title('Inflation Rate')

%figure(152)
%plot(rp_obs,rp_dist,'b-','LineWidth',2)
%title('Distribution of Real Prices')

%figure(153)
%plot(relp_obs,relp_dist,'b-','LineWidth',2)
%title('Distribution of Prices Relative to Desired Price')

%figure(154)
%surf(1./exp(a),exp(rp),SD)
%title('Stationary Distribution (before change)');

%figure(155)
%surf(1./exp(a),exp(rp(:,1)),SD_post2(:,:))
%title('Stationary Distribution (after change without spikes)');

% figure(156)
% v = [1 25 100 250 500 750 1000 1500];
% [C,h] = contour(1./exp(a),exp(rp(:,1)),SD(:,:),v);
% clabel(C,h);
% title('Stationary Distribution (before change)');
% 
% figure(157)
% v = [1 25 100 250 500 750 1000 1500];
% [C,h] = contour(1./exp(a),exp(rp(:,1)),SD_post(:,:),v);
% clabel(C,h);
% title('Stationary Distribution (after change)');

% Nfigure158 = size(rpSim,1)-1;
% whichcolumn = 25;
% figure(158)
% plot(exp(rp(100:600)),SD_post(100:600,whichcolumn)/Nfigure158,'Color',[1 0.5 0],'LineWidth',2)
% line(exp(rp(100:600)),SD(100:600,whichcolumn)/Nfigure158,...
%     'Color',[0 0 1],'LineStyle','-','LineWidth',2)
% %title('Distribution of real prices conditional on a A_t value (before and after price change)')
% ylim([0 0.0008])
% xlim([0.92 1.15])

toc