% Calculates the stationary distribution of the firm over the
% state space in our menu cost model before and after the decision
% about whether to adjust the price
%
% Output:
%   SD: Is the distribution over (p_t-1(z)/P_t, A_t), i.e. before the
%          decision to change the price is made
%   SD_post: Is the distribution over (p_t(z)/P_t, A_t), i.e. after the
%          decision to change the price is made

% The state variables in our menu cost model are p_t-1(z)/P_t and A_t
%
% Jon Steinsson and Emi Nakamura, June 2006
%*************************************************************

function [SD SD_post] = StaDist(rpSim,aSim,InflSim,rp,a);

rpgridsize = size(rp,1);
agridsize = size(a,1);

SD = zeros(rpgridsize,agridsize);
SD_post = zeros(rpgridsize,agridsize);

rpint = rp(2)-rp(1);
aint = a(2)-a(1);

rp_ind = int32((rpSim - rp(1))/rpint)+1;
rp_ind_post = rp_ind(2:end);
Infl_ind = int32(InflSim/rpint);
rp_ind = rp_ind(1:end-1) - Infl_ind(2:end);
a_ind = int32((aSim - a(1))/aint)+1;
a_ind = a_ind(2:end);

for i = 1:size(rpSim,1)-1
    SD(rp_ind(i),a_ind(i)) = SD(rp_ind(i),a_ind(i)) + 1;
    SD_post(rp_ind_post(i),a_ind(i)) = SD_post(rp_ind_post(i),a_ind(i)) + 1;
end
