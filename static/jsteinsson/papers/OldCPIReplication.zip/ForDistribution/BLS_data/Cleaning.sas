LIBNAME ALL 'C:\SCOS output\All raw output';

*Create data set in which an observation correponds to a row in the scanned images
Variable structure is as follows:
Cper: Collection period (by which image folders are grouped)
Fol: Folder number, each collection period consisting of 5-9 folders of images
Img: Image number
Imord: Row within the image
PSU: Primary Sampling Unit, or the location identifier;
PROC SORT DATA = ALL.Master OUT = ALL.Rows (KEEP = Cper Fol Img Imord ELI PSU Outlet QTE VER) NODUPKEY;
BY Cper Fol Img Imord;
RUN;

*In certain collection periods, images seem to have been scanned in reverse order, so that
images must be sorted in reverse order to restore the original structure of observations. 
The following data step implements this;
DATA ALL.Rows;
SET ALL.Rows;
IF (Cper = 7706 & (Fol = 1 | Fol = 2 | Fol = 4)) |
(Cper = 7707 & (Fol = 3 | Fol = 4 | Fol = 5)) |
(Cper GE 7708 & Cper LE 7712) | (Cper GE 7801 & Cper LE 7812)
THEN Img = Img;
ELSE Img = -Img;
RUN; 

*Fix PSU;
*Here, use code to check PSU's against official list;
PROC SORT DATA = ALL.Rows OUT = PSUs NODUPKEY;
BY PSU;
RUN;

DATA PSUs (KEEP = PSU Pcheck);
SET PSUs;
Pcheck = 0;
RUN;

*Pcheck is a macro that creates a flag in the PSUs data set for whether the PSU
is in the list of possible PSUs provided by the BLS;
%Pcheck;

*Sort and merge master data set to get Pcheck variable, set PSU to
missing if Pcheck = 0 (i.e. if the PSU does not correspond to a real PSU);
PROC SORT DATA = ALL.Rows;
BY PSU;
RUN;


DATA ALL.Rows;
MERGE ALL.Rows PSUs;
BY PSU;
IF Pcheck = 0 THEN PSU = '';
RUN;

PROC SORT DATA = ALL.Rows;
BY Cper Fol Img Imord;
RUN;

*The following steps fill in missing PSU values using
the values of preceding and following observation, and the fact
that within Cper-ELI blocks, observations should be sorted by PSU;
DATA ALL.Rows (DROP = Leli Lcper);
RETAIN lastpsu;
SET ALL.Rows;
Leli = LAG(ELI);
Lcper = LAG(Cper);
IF PSU ~= '' THEN lastpsu = PSU;
IF PSU = '' & ELI = Leli & Cper = Lcper THEN lastpsu = lastpsu;
IF PSU = '' & (ELI ~= Leli | Cper ~= Lcper) THEN lastpsu = '';
RUN;

PROC SORT DATA = ALL.Rows;
BY Cper DESCENDING Fol DESCENDING Img DESCENDING Imord;
RUN;

DATA ALL.Rows (DROP = Ldeli Ldcper);
RETAIN nextpsu;
SET ALL.Rows;
Ldeli = LAG(ELI);
Ldcper = LAG(Cper);
IF PSU ~= '' THEN nextpsu = PSU;
IF PSU = '' & ELI = Ldeli & Cper = Ldcper THEN nextpsu = nextpsu;
IF PSU = '' & (ELI ~= Ldeli | Cper ~= Ldcper) THEN nextpsu = '';
RUN;


DATA ALL.Rows (DROP = lastpsu nextpsu Pcheck);
SET ALL.Rows;
IF PSU = '' & (lastpsu = nextpsu) THEN PSU = lastpsu;
RUN;

PROC SORT DATA = ALL.Rows;
BY Cper Fol Img Imord;
RUN;

*Fill in PSU's by filling in based on values from same Outlet in other
Cper's, folders, or images;
PROC SORT DATA = ALL.Rows (KEEP = Outlet PSU) OUT = Outletpsu;
BY Outlet PSU;
RUN;


*Within each Outlet, count how many times each occurring PSU appears;
PROC MEANS NOPRINT DATA = Outletpsu;
BY Outlet PSU;
OUTPUT OUT = PSUcount SUM(X) = Nobs;
RUN;

*Count how many PSU's appear in an outlet;
PROC MEANS NOPRINT DATA = PSUcount;
BY Outlet;
Output OUT = PSUcount2 N(Nobs) = Npsus;
RUN;

*Merge these two count variables, delete missing PSU's when there's also
at least one non-missing PSU for the outlet;
DATA PSUcount;
MERGE PSUcount PSUcount2;
BY Outlet;
IF PSU = '' & Npsus GT 1 THEN DELETE;
RUN;

*Sort counts so that get most common PSU first for each outlet;
PROC SORT DATA = PSUcount OUT = InPSU NODUPKEY;
BY Outlet DESCENDING Nobs;
RUN;

*Keep only most common PSU for each outlet;
DATA InPSU (KEEP = Outlet PSU2);
SET InPSU (RENAME = (PSU = PSU2));
BY Outlet;
IF FIRST.Outlet = 1;
RUN;

PROC SORT DATA = ALL.Rows;
BY Outlet;
RUN;

*Merge accepted PSU's back into master data;
DATA ALL.Rows (DROP = PSU2 _TYPE_ _FREQ_);
MERGE ALL.Rows InPSU;
BY Outlet;
PSU = PSU2;
RUN;

*Clean Outlet, quote, version variables in Rows dataset to prepare to fill in using adjacent 
observations;
DATA ALL.Rows (DROP = Oul Ql Vl Oun Oun2 Outdash Outdashl Dash Qn Vn Outsusp Qtesusp Versusp);
SET ALL.Rows;
Outlet = TRANWRD(Outlet,'O','0'); Outlet = TRANWRD(Outlet,'U','0');
QTE = TRANWRD(QTE,'O','0'); QTE = TRANWRD(QTE,'U','0');
VER = TRANWRD(VER,'O','0'); VER = TRANWRD(VER,'U','0');
Oul = LENGTH(Outlet);
Ql = LENGTH(QTE);
Vl = LENGTH(VER);
Oun = NOTDIGIT(Outlet);
Oun2 = NOTDIGIT(Outlet,2);
Outdash = SUBSTR(Outlet,1,1);
Outdashl = SUBSTR(Outlet,7,1);
Dash = INDEX(Outlet,'-');
IF Oul = 7 & ((Oun > 7) | (Outdash = '-' & Oun2 > 7) | (Oun = 7 & Outdashl = '-'))
	THEN Outsusp = 0;
ELSE IF Oul = 8 & Dash > 0 & Outdashl = '-' THEN DO;
	Outlet = TRANWRD(Outlet,'-','');
	Outlet = CATS(Outlet,'-');
	Outsusp = 0;
END;
ELSE IF Oul = 8 & Dash > 0 & Outdashl ~= '-' THEN DO;
	Outlet = TRANWRD(Outlet,'-','');
	Outsusp = 0;
END;
ELSE Outsusp = 1;
Qn = NOTDIGIT(QTE);
Vn = NOTDIGIT(VER);
IF (Ql = 3 & Qn > 3) THEN Qtesusp = 0;
ELSE IF QTE ~= '' THEN Qtesusp = 1;
IF (Vl = 3 & Vn > 3) THEN Versusp = 0;
ELSE IF VER ~= '' THEN Versusp = 1;
IF Outsusp ~= 0 THEN Outlet = '';
IF Qtesusp ~= 0 THEN QTE = '';
IF Versusp ~= 0 THEN VER = '';
RUN;

*Fix Outlet;
PROC SORT DATA = ALL.Rows;
BY Cper ELI  PSU Fol Img Imord;
RUN;

**Create blocks within which to work;
DATA ALL.Rows (DROP = Lcper Leli Lpsu);
SET ALL.Rows;
Lcper = LAG(Cper);
Leli = LAG(ELI);
Lpsu = LAG(PSU);
IF (Cper ~= Lcper) | (Leli ~= ELI) | (Lpsu ~= PSU) THEN Ngroup = 1;
ELSE Ngroup = 0;
Lngroup = LAG(Ngroup);
RUN;

DATA ALL.Rows;
RETAIN Block 0;
SET ALL.Rows;
Block = Block + Ngroup;
RUN;

*Sort by outlet within blocks, to create outlet value;
PROC SORT DATA = ALL.Rows;
BY Block Outlet Fol Img Imord;
RUN;

DATA ALL.Rows (DROP = Lagout Lagblock Lag2block);
RETAIN Outval 0;
SET ALL.Rows;
Lagout = LAG(Outlet);
Lagblock = LAG(Block);
Lag2block = LAG2(Block);
IF (Block ~= Lagblock) | (Lagout = '' & Outlet ~= '') THEN Outval = 0;
ELSE IF Block = Lagblock & Outlet = Lagout THEN Outval = Outval;
ELSE Outval = Outval +1;
IF Outlet = '' THEN Outval = .;
RUN;

*Sort by image order;
PROC SORT DATA = ALL.Rows;
BY Block Fol Img Imord;
RUN;

DATA ALL.Rows (DROP = Lagblock Lag2block);
SET ALL.Rows;
Lout = LAG(Outval);
L2out = LAG2(Outval);
Lagblock = LAG(Block);
Lag2block = LAG2(Block);
IF Block ~= Lagblock THEN DO;
Lout = .; L2out = .;
END;
IF Block ~= Lag2block & Block = Lagblock THEN L2out = .;
RUN;

*Sort reverse order to get leads;
PROC SORT DATA = ALL.Rows;
BY Block DESCENDING Fol DESCENDING Img DESCENDING Imord;
RUN;

DATA ALL.Rows (DROP = Ldblock Ld2block );
SET ALL.Rows;
Ldout = LAG(Outval);
Ld2out = LAG2(Outval);
Ldblock = LAG(Block);
Ld2block = LAG2(Block);
IF Block ~= Ldblock THEN DO;
Ldout = .; Ld2out = .;
END;
IF Block = Ldblock & Block ~= Ld2block THEN Ld2out = .;
RUN;

PROC SORT DATA = ALL.Rows;
BY Block Fol Img Imord;
RUN;

*Set outlet to missing if (outlet is higher than lag and lead, or if lower than lag and lead) &
(excluding current outlet makes sequence of 2 previous and 2 next monotonic), also replaces
outlet if previous and next are same, but different from current;
DATA ALL.Rows (DROP = Loutlet Lagblock Outval  Lngroup Lout L2out Ldout Ld2out Loutlet Lagblock Ngroup);
SET ALL.Rows;
Loutlet = LAG(Outlet);
Lagblock = LAG(Block);
NM = ((Outval < Lout) | (Outval > Ldout)) & (Outval ~= . & Lout ~= . & Ldout ~= .);
IF NM = 1 THEN exclude = (Ld2out >= Ldout & Ldout >= Lout & Lout >= L2out);
ELSE exclude = .;
IF NM = 0 | (NM = 1 & exclude = 0) | PSU = '' | ELI = '' THEN Outletc = Outlet;
ELSE Outletc = .;
IF Block = Lagblock & (Lout = Ldout & Outval ~= Lout) & (Loutlet ~= '') THEN Outletc = Loutlet;
RUN;


*Fix QTE;
PROC SORT DATA = ALL.Rows;
BY Block Outlet Fol Img Imord;
RUN;

DATA ALL.Rows (DROP = Loutlet Lagblock);
SET ALL.Rows;
Loutlet = LAG(Outlet);
Lagblock = LAG(Block);
IF Block ~= Lagblock | Outlet ~= Loutlet THEN Ngroup = 1;
ELSE Ngroup = 0;
RUN;

DATA AlL.Rows (DROP = Ngroup);
RETAIN Block2 0;
SET ALL.Rows;
Block2 = Block2 + Ngroup;
RUN;

PROC SORT DATA = ALL.Rows;
BY Block2 Fol Img Imord;
RUN;

DATA ALL.Rows;
SET ALL.Rows;
Lqte = LAG(QTE);
*L2qte = LAG2(QTE);
Lblock = LAG(Block2);
*L2block = LAG2(Block);
*IF Block2 ~= Lblock THEN DO;
*Lqte = . & L2qte = .;
*END;
IF Block2 ~= Lblock THEN Lqte = .;
RUN; 

PROC SORT DATA = ALL.Rows;
BY Block2 DESCENDING Fol DESCENDING Img DESCENDING Imord;
RUN;

DATA ALL.Rows (DROP = Ldblock);
SET ALL.Rows;
Ldqte = LAG(QTE);
*Ld2qte = LAG2(QTE);
Ldblock = LAG(Block2);
*Ld2block = LAG2(Block2);
IF Block2 ~= Ldblock THEN Ldqte = .;
RUN;

PROC SORT DATA = ALL.Rows;
BY Block2 Fol Img Imord;
RUN;

DATA ALL.Rows (DROP = NM exclude Lblock Lqte Ldqte Ldblock Block);
SET ALL.Rows;
NMq = ((QTE > Ldqte | QTE < Lqte) & (QTE ~= . & Ldqte ~=. & Lqte ~= .));
IF NMq = 1 THEN excludeq = (NMq = 1 & (Ldtqe GE Lqte));
ELSE excludeq = .;
IF NMq = 0 | (NMq = 1 & excludeq = 0) | PSU = '' | ELI = ''| Outlet = '' THEN qtec = QTE;
ELSE qtec = .;
IF Block2 = Lblock & (Lqte = Ldqte) & (Lqte ~= '') THEN QTE = Lqte;
RUN;

*Fix VER;
PROC SORT DATA = ALL.Rows;
BY Block2 QTE Fol Img Imord;
RUN;

DATA ALL.Rows (DROP = Lqte Lagblock);
SET ALL.Rows;
Lqte = LAG(QTE);
Lagblock = LAG(Block2);
IF QTE ~= Lqte | Block2 ~= Lagblock THEN Ngroup = 1;
ELSE Ngroup = 0;
RUN;

DATA ALL.Rows (DROP = Ngroup Block2);
SET ALL.Rows;
RETAIN Block3 0;
Block3 = Block3 + Ngroup;
RUN;

PROC SORT DATA = ALL.Rows;
BY Block3 Fol Img Imord;
RUN;

DATA ALL.Rows;
SET ALL.Rows;
Lver = LAG(VER);
Lblock = LAG(Block3);
IF Block3 ~= Lblock THEN Lver = .;
RUN;

PROC SORT DATA = ALL.Rows;
BY Block3 DESCENDING Fol DESCENDING Img DESCENDING Imord;
RUN;

DATA ALL.Rows (DROP = Ldblock);
SET ALL.Rows;
Ldver = LAG(VER);
Ldblock = LAG(Block3);
IF Block3 ~= Ldblock THEN Ldver = .;
RUN;

PROC SORT DATA = ALL.Rows;
BY Block3 Fol Img Imord;
RUN;

DATA ALL.Rows ;
SET ALL.Rows;
NMv = ((VER < Lver | VER > Ldver) & (VER ~= '' & Lver ~= . & Ldver ~= .));
IF NMv = 1 THEN excludev = (Ldver GE Lver);
ELSE excludev = 0;
IF NMv = 0 | (NMv = 1 & excludec = 0) | PSU = '' | ELI = '' | Outlet = '' | QTE = '' THEN verc = ver;
ELSE  verc = .;
RUN;


DATA ALL.Rows (RENAME = (Outletc = Outlet qtec = QTE verc = VER ));
SET ALL.Rows (DROP = NMq excludeq Block3 NMv excludev excludec Lver Lblock Ldver Outlet QTE VER Ldtqe);
IF (Cper = 7706 & (Fol = 1 | Fol = 2 | Fol = 4)) |
(Cper = 7707 & (Fol = 3 | Fol = 4 | Fol = 5)) |
(Cper GE 7708 & Cper LE 7712) | (Cper GE 7801 & Cper LE 7812)
THEN Img = Img;
ELSE Img = -Img;
RUN; 



PROC SORT DATA = ALL.Master;
BY Cper Fol Img Imord;
RUN;

PROC SORT DATA = ALL.Rows;
BY Cper Fol Img Imord;
RUN;

DATA ALL.Rowsc;
SET ALL.Rows;
IF Cper = . | Fol = . | Img = . | Imord = . THEN DELETE;
RUN;

*Merge in cleaned and filled Outlet, quote, version values into the master dataset;
DATA ALL.Masterclean;
MERGE ALL.Master (DROP = Outlet QTE VER) ALL.Rowsc;
BY Cper Fol Img Imord;
IF Outlet = '' | Outlet = .| QTE = . | QTE = '' | VER = .| VER = '' THEN DELETE;
RUN; 

*Clean month, price, and percentage change variables;
DATA ALL.Masterclean (DROP = Num Numc M1 M3 Le Pper Plet Plet2 Lec Cn Clet Clet2 P Pctchng Outletc Ldqte qtec verc);
SET ALL.Masterclean;
Month = TRANWRD(Month,'U','0'); Month = TRANWRD(Month,'O','0');
M1 = SUBSTR(Month,1,1); M3 = SUBSTR(Month,2,3);
IF M1 = '1' THEN Month = CAT('7',M3);
P = TRANWRD(P,'..','.'); P = TRANWRD(P,'...','.'); P = TRANWRD(P,'. .','.');
P = TRANWRD(P,'U','0'); P = TRANWRD(P,'O','0');
P = LEFT(P);
P = TRIM(P);
IF P = '-' THEN P = '';
IF Pctchng = '-' THEN Pctchng = '';
Le = LENGTH(P);
Pper = INDEX(P,'.');
Plet = NOTDIGIT(P);
Plet2 = NOTDIGIT(P,Pper + 1);
IF (Pper = Plet & Plet2 > Le & P ~='') THEN Num = 1;
ELSE IF P = '' THEN Num = .;
ELSE Num = 0;
Lec = LENGTH(Pctchng);
Cn = SUBSTR(Pctchng,1,1);
Clet = NOTDIGIT(Pctchng);
Clet2 = NOTDIGIT(Pctchng,2);
IF (Clet > Lec & Pctchng ~= '') THEN Numc = 1;
ELSE IF (Cn = '-' & Clet2 > Lec & Pctchng ~= '') THEN Numc = 1;
ELSE IF Pctchng ~= '' THEN Numc = 0;
ELSE Numc = .;
IF Num = 1 THEN Price = INPUT(P,9.4);
ELSE Price = .;
IF Numc = 1 THEN Pctchange = INPUT(Pctchng,9.0);
ELSE Pctchange = .; 
RUN;


**Complete ELI's using observations from same product;
PROC SORT DATA = ALL.Rowsc ;
BY Outlet QTE ELI;
RUN;

DATA ALL.Rowsc;
SET ALL.Rowsc;
C = (ELI ~= '');
RUN;

*Counts how many times a particular ELI (non-missing) shows up, saved in ELIcount;
PROC MEANS NOPRINT DATA = ALL.Rowsc;
BY Outlet Qte ELI;
OUTPUT OUT = ELIcount SUM(C) = N;
RUN;

*Create dataset where observation is product-ELI combo, called Mastereli;
PROC SORT DATA = ALL.Rowsc OUT = Mastereli NODUPKEY;
BY Outlet QTE ELI;
RUN;

*Next 2 steps count how many non-missing ELI's a product has, saved in Nelis;
DATA Mastereli;
SET Mastereli;
Ce = (ELI ~= '');
RUN;


PROC MEANS NOPRINT DATA = Mastereli;
BY Outlet QTE;
OUTPUT OUT = Nelis SUM(Ce) = Ne;
RUN;

*Merging count of non-missing ELIs per product with list of product-ELI combos;
DATA Mastereli (DROP = _FREQ_ _TYPE);
MERGE Mastereli Nelis;
BY Outlet QTE;
IF ELI = '' & Ne GE 1 THEN DELETE;
RUN;

*Now merge with count of how many times a non-missing ELI appears;
DATA Mastereli (DROP = _FREQ _TYPE_);
MERGE Mastereli ELIcount;
BY Outlet QTE ELI;
RUN;

*Sort so that in each product most common ELI comes up first, and then non-missing ELI's show up first;
PROC SORT DATA = Mastereli;
BY Outlet QTE DESCENDING N DESCENDING ELI;
RUN;

*Next two steps keep first obs for each product in Mastereli (most common one);
DATA Mastereli (Keep = Outlet QTE ELI N Npro Lpro);
SET Mastereli;
BY Outlet QTE;
Npro = FIRST.QTE;
Lpro = LAST.QTE;
RUN;

DATA ALL.Mastereli2 (RENAME = (ELI = ELI2));
SET Mastereli;
IF Npro = 1;
RUN;
