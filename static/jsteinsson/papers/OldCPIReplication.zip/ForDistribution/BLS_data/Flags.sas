

LIBNAME Mastall 'C:\SCOS output\All raw output';

DATA Mastall.Flagall;
SET Mastall.Masterclean (KEEP = ELI Outlet QTE VER Month Flag Cper Fol Img);
RUN;

DATA Mastall.Flagall (DROP = Flagfirst Flagsecond Flagthird hashtag1 hashtag2 F1 F2 F3 F4 F5 F6 F7);
SET Mastall.Flagall;
*New sales flag;
SALE = INDEX(Flag,'B');* > 0 if there is a B;
Flagfirst = SUBSTR(Flag,1,1);
Flagsecond = SUBSTR(Flag,2,1);
Flagthird = SUBSTR(Flag,3,1);
hashtag1 = (SUBSTR(Flag,1,1) = '#');
hashtag2 = (SUBSTR(Flag,2,1) = '#');
*Sale = 1 if it flag has a B, or if one or two #'s followed by set of characters
"C" is included because indicates clearance sales, other characters are probably
OCR errors that should be B's (these should not show up in the flag in this position);
Sale =  ((Sale > 0) | 
(hashtag1 = 1 & (Flagsecond = '0' |Flagsecond = 'O' |Flagsecond = '8' |
Flagsecond = 'C' |Flagsecond = '0' |Flagsecond = '9' |Flagsecond = '6'))|
(hashtag1 = 1 & hashtag2 = 1 & (Flagthird = '0' |Flagthird = 'O' |Flagthird = '8' |
Flagthird = 'C' |Flagthird = '0' |Flagthird = '9' |Flagthird = '6')));

*Valid observation flag (meant to drop imputed prices);
*First, if first character is bad flag;
Flagfirst = SUBSTR(Flag,1,1);
Bad1 = ((Flagfirst = 'A' & LENGTH(Flag) > 3)|Flagfirst = 'U'|Flagfirst = 'T'|Flagfirst = 'D'|Flagfirst = 'S');
*Second, if second character is bad flag, following a #, or if third
character is bad flag, following two #'s;
Flagsecond = SUBSTR(Flag,2,1);
Flagthird = SUBSTR(Flag,3,1);
Bad2 = ((Flagfirst = '#' & (Flagsecond = 'U' |Flagsecond = 'T' |Flagsecond = 'D'|Flagfirst = 'S'))|
(Flagfirst = '#' & Flagsecond = '#' & (Flagthird = 'U' | Flagthird = 'T' | Flagthird = 'D'|Flagfirst = 'S')));
*Third, if string contains "I", the imputation flag;
Bad3 = (INDEX(Flag,'I')>0);
*Fourth, if string has two numbers next to each other, the second being
a 1 (most likely error, should have been an I at the end);
F1 = SUBSTR(Flag,1,1);
F2 = SUBSTR(Flag,2,1);
F3 = SUBSTR(Flag,3,1);
F4 = SUBSTR(Flag,4,1);
F5 = SUBSTR(Flag,5,1);
F6 = SUBSTR(Flag,6,1);
F7 = SUBSTR(Flag,7,1);
Bad4 = ((ANYDIGIT(F1) = 1 & F2 = '1') |
		(ANYDIGIT(F2) = 1 & F3 = '1') |
		(ANYDIGIT(F3) = 1 & F4 = '1') |
		(ANYDIGIT(F4) = 1 & F5 = '1') |
		(ANYDIGIT(F5) = 1 & F6 = '1') |
		(ANYDIGIT(F6) = 1 & F7 = '1'));
Bad = ((Bad1 = 1| Bad2 = 1 | Bad3 = 1 | Bad4 = 1) & Flag ~= '');
IF Flag = 'AAI' THEN Bad = 0;
IF Flag = '' THEN Bad = .;
RUN;

*This step here is added to create a missing flag variable,
which will help distinguish between prices
that were missing because of schedule, or other reason;
DATA Mastall.Flagall;
SET Mastall.Flagall;
Miss = (Flag = '');
RUN;

DATA flags;
SET Mastall.Flagall (KEEP = Outlet QTE VER Month Bad Miss);
RUN; 

PROC SORT DATA = flags;
BY Outlet QTE VER Month;
RUN;

PROC MEANS NOPRINT DATA = flags;
BY Outlet QTE VER MOnth;
OUTPUT OUT = Badsum SUM(Bad) = Totbad N(Bad) = Ns SUM(Miss) = Totmiss N(Miss) = Nms;
RUN;

DATA Mastall.Useflag;
SET Badsum (DROP = _FREQ_ _TYPE_);
Use = ((Totbad/Ns) < 0.5 & Ns GE 1);
Usec = ((Totbad/Ns) < 0.5 & Totbad LT 2 & Ns GE 1);
Missflag = ((Totmiss/Nms) >= 0.5);
RUN; 

*For each PM, determine if any observation of it has 
Sale flag = 1;
PROC SORT DATA = Mastall.Flagall OUT = sale (KEEP = Outlet QTE VER Month Sale) NODUPKEY;
BY Outlet QTE VER Month DESCENDING Sale;
RUN;

DATA sale;
SET sale (KEEP = Outlet QTE VER Month Sale);
BY Outlet QTE VER Month;
IF FIRST.Month = 1;
RUN;

*Merge sales and use flags;
DATA Mastall.Useflag (DROP = Totbad Ns Totmiss Nms);
MERGE Mastall.Useflag sale;
BY Outlet QTE VER Month;
RUN;


