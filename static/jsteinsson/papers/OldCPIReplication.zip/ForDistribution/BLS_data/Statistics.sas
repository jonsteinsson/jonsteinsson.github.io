*Set path for library "ALL", where Masteraccept and other data sets are saved;
LIBNAME ALL "";

*Merge in Mastereli2, which contains ELI for each product based on previous rounds of cleaning;
DATA ALL.Masteraccept (DROP = ELI2);
MERGE ALL.Masteraccept ALL.Mastereli2 (DROP = N Npro Lpro);
BY Outlet QTE;
ELI = ELI2;
IF Cper = . THEN DELETE;
RUN;

*Merge in variables for sale and useability (based on whether price was imputed or not) from Useflag;
DATA ALL.Masteraccept;
MERGE ALL.Masteraccept ALL.Useflag ;*(DROP = Totbad Ns);
BY Outlet QTE VER Month;
RUN;

*Clean months;
DATA ALL.Masteracceptchanges (DROP = M1 Mr Lm yearok monthok);
SET ALL.Masteraccept;
M1 = SUBSTR(Month,1,1);
Mr = SUBSTR(Month,2,3);
IF M1 = '6' THEN MONTH = CATS('8',Mr);
Lm = LENGTH(Month);
M12 = SUBSTR(Month,1,2);
M34 = SUBSTR(Month,3,2);
yearok = (M12 = '76' | M12 = '77'| M12 = '78'| M12 = '79'| M12 = '80'| 
	M12 = '81'| M12 = '82'| M12 = '83'| M12 = '84'| 
	M12 = '85'| M12 = '86');
monthok = (M34 = '01'| M34 = '02'| M34 = '03'| M34 = '04'
	| M34 = '05'| M34 = '06'| M34 = '07'| M34 = '08'| 
	M34 = '09'| M34 = '10'| M34 = '11'| M34 = '12');
IF yearok = 1 & monthok = 1 & Lm = 4;
RUN;

*To make data set smaller, only keep observations where either price or lagged price is observed;
DATA ALL.Masteracceptchanges (DROP = Pricea Cper Fol Img Accept Lprod);
SET ALL.Masteracceptchanges;
BY Outlet QTE VER;
Price = Pricea + 0;
Nprod = FIRST.VER;
Lagprice = LAG(Price);
IF Nprod = 1 THEN Lagprice = .;
IF Price = . & Lagprice = . & Nprod = 0 THEN DELETE;
RUN;

*Create flag for whether previous observation is from one month before (Note: "Month" variable
is in the format YYMM, so includes the year);
DATA ALL.Masteracceptchanges (DROP = Lmonth L2month Lyear L2year m y Pctchange Lagprice);
SET ALL.Masteracceptchanges (RENAME = (M12 = y M34 = m));
BY Outlet QTE VER;
Nprod = FIRST.VER;
Lmonth = LAG(m);
L2month = LAG2(m);
Lyear = LAG(y);
L2year = LAG2(y);
IF Nprod = 1 THEN DO;
	Lmonth = .;
	L2month = .;
	Lyear = .;
	L2year = .;
END;
IF ((m = Lmonth +1) & (y = Lyear)) | ((m = 1 & Lmonth = 12) & (y = Lyear + 1))
	THEN Mondif1 = 1;
ELSE IF Nprod ~= 1 THEN Mondif1 = 0;
ELSE Mondif1 = .;
RUN;

*Use ELI correspondence to convert ELIs to format of 1988 revision;
PROC SORT DATA = ALL.Masteracceptchanges;
BY ELI;
RUN;

PROC SORT DATA = ALL.ELI7788;
BY ELI;
RUN;

DATA ALL.Masteracceptchanges;
MERGE ALL.Masteracceptchanges ALL.ELI7788;
BY ELI;
IF ELI2 = '' THEN ELI2 = ELI;
RUN;


PROC SORT DATA = ALL.Masteracceptchanges;
BY ELI2;
RUN;

*Use other correspondence to convert to format of 1998 revision, which will be the format we use;
DATA ALL.Masteracceptchanges (DROP = ELI2);
MERGE ALL.Masteracceptchanges ALL.Eliconv;
BY ELI2;
IF ELInew = '' THEN ELInew = ELI;
RUN;

*Sort by product month;
PROC SORT DATA = ALL.Masteracceptchanges;
BY Outlet QTE VER Month;
RUN;


*Create price change variables;
DATA ALL.Masteracceptchanges (DROP = Lag2pusens Lag2puse Lmondif Lnprod Lagprice);
SET ALL.Masteracceptchanges ;*(DROP = bimns) ;
BY Outlet QTE VER;
Nprod = FIRST.VER;
Lagprice = LAG(Price);
puse = Price;
IF (Price = 0 | Price LE 0.004 | Use ~= 1) THEN puse = .;
pusens = puse;
IF Sale = 1 THEN pusens = .;
lagpuse = LAG(puse);
lagpusens = LAG(pusens);
IF Nprod = 1 | puse = . THEN lagpuse = .;
IF Nprod = 1 | pusens = . THEN lagpusens = .;
pc = .; pcns = .; pchange = .; pchangens = .; apchange = .; apchangens = .;
IF puse ~= lagpuse & Nprod = 0 & puse ~= . & lagpuse ~= . & Mondif1 = 1 THEN DO;
	pc = 1;
	pchange = LOG(puse)-LOG(lagpuse);
	apchange = ABS(pchange);
END;
IF puse = lagpuse & Nprod = 0 & puse ~= . & lagpuse ~= . & Mondif1 = 1 THEN pc = 0;
IF apchange > 1 | puse = . | lagpuse = . THEN DO;
	pc = .;
	pchange = .;
	apchange = .;
END;
IF pusens ~= lagpusens & Nprod = 0 & pusens ~= . & lagpusens ~= . & Mondif1 = 1 THEN DO;
	pcns = 1;
	pchangens = LOG(pusens) - LOG(lagpusens);
	apchangens = ABS(pchangens);
END;
IF pusens = lagpusens & Nprod = 0 & pusens ~= . & lagpusens ~= . & Mondif1 = 1 THEN pcns = 0;
IF apchangens > 1 & pcns = 1 THEN bigpcns = 1;
IF apchangens LE 1 | pcns ~= 1 THEN bigpcns = 0;
IF apchangens > 1 | pusens = . | lagpusens = . THEN DO;
	pcns = .;
	pchangens = .;
	apchangens = .;
	pcupns = .;
END;
IF pcns = 1 & pchangens > 0 THEN pcupns = 1;
ELSE IF pcns = 1 THEN pcupns = 0;
ELSE pcupns = .;
logp = LOG(puse);
logpns = LOG(pusens);
Lag2pusens = LAG2(pusens);
Lag2puse = LAG2(puse);
Lmondif = LAG(Mondif1);
Lnprod = LAG(Nprod);
IF pusens ~= . & lagpusens = . & Lag2pusens ~= . & Nprod = 0 & Lnprod = 0 & Mondif1 = 1 & Lmondif = 1 THEN DO;
bimns = 1;
lagpusens = Lag2pusens;
END;
IF bimns = 1 & pusens = lagpusens THEN pcns = 0;
IF bimns = 1 & pusens ~= lagpusens THEN DO;
pcns = 1;
pchangens = LOG(pusens) - LOG(lagpusens);
apchangens = ABS(pchangens);
END;
IF bimns = 1 & pcns = 1 & pchangens > 0 THEN pcupns = 1;
IF apchangens > 1 & bimns = 1 THEN DO;
pcns = .;
pchangens = .;
apchangens = .;
pcupns = .;
END;
IF puse ~= . & lagpuse = . & Lag2pusens ~= . & Nprod = 0 & Lnprod = 0 & Mondif1 = 1 & Lmondif = 1 THEN DO;
bim = 1;
lagpuse = Lag2puse;
END;
IF bim = 1 & puse = lagpuse THEN pc = 0;
IF bim = 1 & puse ~= lagpuse THEN DO;
pc = 1;
pchange = LOG(puse) - LOG(lagpuse);
apchange = ABS(pchange);
END;
IF bim = 1 & pc = 1 & pchange > 0 THEN pcup = 1;
IF apchange > 1 & bim = 1 THEN DO;
pc = .;
pchange = .;
apchange = .;
pcup = .;
END;
RUN;


*Standard statistics, by ELI under new categorization;
PROC SORT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
RUN;

*Frequency excluding sales;
PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT= Freqns MEAN(pcns) = Freqns 
MEAN(pcupns) = Fracupns N(pcns) = obsns 
STDDEV(pchangens) = Dispns MEAN(apchangens) = absns
SUM(pcns) = changesns SUM(pcupns) = changesupns;
WHERE ELInew ~= '' & bimns ~= 1;
RUN;

*Frequency including sales;
PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT= Freqs MEAN(pc) = Freqs N(pc) = obs 
MEAN(apchange) = abs SUM(pc) = changes ;
WHERE ELInew ~= '' & bim ~= 1;
RUN;


*Size of price increases;
PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT = Frequp MEAN(apchangens) = absupns STDDEV(pchangens) = Dispupns;
WHERE pcupns = 1 & ELInew ~= '' & bimns ~= 1;
RUN;

*Size of price decreases;
PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT = Freqdw MEAN(apchangens) = absdwns STDDEV(pchangens) = Dispdwns;
WHERE pcupns = 0 & ELInew ~= '' & bimns ~= 1;
RUN;

*Price dispersion (excluding cases where previous months price not observed);
PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT = Pricedisp STDDEV(logp) = pricedisp QRANGE(logp) = priceiqr 
STDDEV(logpns) = pricedispns QRANGE(logpns) = priceiqrns N(logp) = pobs N(logpns) = pobsns;
WHERE ELInew ~= '' & bimns ~= 1;
RUN;

*Price dispersion including all observed prices;
PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT = Pricedispall STDDEV(logp) = pricedispall QRANGE(logp) = priceiqrall 
STDDEV(logpns) = pricedispnsall QRANGE(logpns) = priceiqrnsall N(logp) = pobsall N(logpns) = pobsnsall;
WHERE ELInew ~= '';
RUN;


DATA ALL.Freq (DROP = _FREQ_ _TYPE_);
MERGE Freqns Freqs Frequp Freqdw Pricedisp Pricedispall Smallcpns Smallcp;
BY ELInew Month;
RUN;

*For bi-monthly changes;
PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT= Freqbins MEAN(pcns) = Freqns 
MEAN(pcupns) = Fracupns N(pcns) = obsns STDDEV(pchangens) = Dispns 
MEAN(apchangens) = absns SUM(pcns) = changesns SUM(pcupns) = changesupns
MEAN(smallcpns) = fracsmallns SUM(smallcpns) = smallchangesns;
WHERE ELInew ~= '' & bimns = 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT= Freqbi MEAN(pc) = Freq 
N(pc) = obs  MEAN(apchange) = abs SUM(pc) = changes 
MEAN(smallcp) = fracsmall SUM(smallcp) = smallchanges;
WHERE ELInew ~= '' & bim = 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT = Frequpbi MEAN(apchangens) = absupns STDDEV(pchangens) = Dispupns;
WHERE pcupns = 1 & ELInew ~= '' & bimns = 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteracceptchanges;
BY ELInew Month;
OUTPUT OUT = Freqdwbi MEAN(apchangens) = absdwns STDDEV(pchangens) = Dispdwns;
WHERE pcupns ~= 1 & ELInew ~= '' & bimns = 1;
RUN;

DATA ALL.Freqbi;
MERGE Freqbins Freqbi Frequpbi Freqdwbi;
BY ELInew Month;
RUN;

*Size squared and cubed statistics;
DATA Sizes (KEEP = apchangens ELInew Month Outlet QTE VER pchangens bimns Size2 Size3);
SET ALL.Masteracceptchanges;
Size2 = pchangens**2;
Size3 = pchangens**3;
Sizea3 = apchangens**3;
RUN;

PROC SORT DATA = Sizes;
BY ELInew Month;
RUN;

PROC MEANS NOPRINT DATA = Sizes;
BY ELInew Month;
OUTPUT OUT = Size77 MEAN(pchangens) = Size1 MEAN(Size2) = Size2 MEAN(Size3) = Size3 N(Size2) = Sizeobs;
WHERE ELInew ~= '';
RUN; 

PROC MEANS NOPRINT DATA = Sizes;
BY ELInew Month;
OUTPUT OUT = Sizenobim MEAN(pchangens) = Size1nobim MEAN(Size2) = Size2nobim MEAN(Size3)= Size3nobim N(Size2) = Sizeobsnobim;
WHERE ELInew ~= '' & bimns ~= 1;
RUN; 

DATA Size77;
MERGE Size77 Sizenobim;
BY ELInew Month;
RUN;

