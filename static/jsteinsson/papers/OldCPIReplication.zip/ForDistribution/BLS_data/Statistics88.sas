*This code computes the price change statistics used in the paper from the CPI RDB data set (for the period
1987 onwards).  It uses the data sets Masterrdb88 and Masterrdb98. These are data sets containing 
all the observations from the BLS' Outlet, Quote, and Version monthly data files (separated into the 87-97 
and 98-onwards periods). The variables that should be included are those mentioned in the code below.
The variables to be extracted, along with the names in the code below, are the following:
From Vers files:
coll_salreg&Mon = Sale coll_qty&Mon = Qty coll_size&Mon = Size fullsamp_effpr_witx&Mon = Eprice 
	coll_price&Mon = Price der_ver_avl&Mon = Avl basepr_method = BPmeth price_admnt_cd = AdjCode price_adjmnt_value = AdjVal
From Quot files: 
indx_psu = psu basic_wt = BW final_wt&Mon = FW coll_qt_status&Mon = Collstatus der_qt_status&Mon = Derstatus 
	whether_to_price&Mon = whether comp_cd&Mon = Comp
From Otlt files:
coll_interview_cd&Mon = interview;

*Set path for library "ALL";
LIBNAME ALL '';

PROC SORT DATA = ALL.Masterrdb88;
BY eli;
RUN;

DATA ALL.Masterrdb88 (RENAME = (ELInew = eli ELI2 = ELI88));
MERGE ALL.Masterrdb88 (RENAME = (eli = ELI2)) ALL.ELIconv;
BY ELI2;
RUN;

DATA ALL.Masterrdb88 (DROP = ELI88);
SET ALL.Masterrdb;
eliold = ELI88;
RUN;

DATA ALL.Masterrdb;
SET ALL.Masterrdb88 ALL.Masterrdb98;
IF eli = '' THEN eli = eliold;
RUN;

*Sort data set to form a panel;
PROC SORT DATA = ALL.Masterrdb;
BY outlet_cd qt_cd ver_cd Year Month;
RUN;

*Create a month difference variable
"Price" is collected price
"Eprice" is "effective price";
DATA ALL.Masteruserdb;
SET ALL.Masterrdb;
BY outlet_cd qt_cd ver_cd;
Nprod = FIRST.ver_cd;
mondif = ydiff*12+mdiff ;
Lmondif = LAG(mondif);
IF Nprod = 1 THEN DO;
	mondif = .; Lmondif = .;
Lagprice = LAG(Price);
lageprice = LAG(Eprice);
IF Price = . & Lagprice = . & Nprod = 0 & Eprice = . & lageprice = . THEN DELETE;
RUN;

DATA ALL.MasteruseRDB (DROP = Lag2puse Lag2pusens Lmondif Lnprod Lagsale);
SET ALL.MasteruseRDB (DROP = Sale mdiff ydiff);
puse = Price;
IF (whether ~= 'P' & (Year ~= 1987 | Month ~= 11)) | Price = 0 | Interview ~= 11 | Avl ~= 1 THEN puse = .;
lagpuse = LAG(puse);
pusens = puse;
IF S = 1 THEN DO;
	pusens = .;
END;
Lagsale = LAG(S);
lagpusens = LAG(pusens);
IF Nprod = 1 | puse = . THEN lagpuse = .;
IF Nprod = 1 | pusens = . THEN lagpusens = .;
IF puse ~= lagpuse & Nprod = 0 & puse ~= . & lagpuse ~= . & mondif = 1 THEN DO;
	cp = 1;
	changep = LOG(puse)-LOG(lagpuse);
	achangep = ABS(changep);
END;
IF puse = lagpuse & Nprod = 0 & puse ~= . & lagpuse ~= . & mondif = 1 THEN cp = 0;
IF pusens ~= lagpusens & Nprod = 0 & pusens ~= . & lagpusens ~= . & mondif = 1 THEN DO;
	cpns = 1;
	changepns = LOG(pusens)-LOG(lagpusens);
	achangepns = ABS(changepns);
END;
IF pusens = lagpusens & Nprod = 0 & pusens ~= . & lagpusens ~= . & mondif = 1 THEN cpns = 0;
IF cpns = 1 & changepns > 0 THEN cpupns = 1;
ELSE IF cpns = 1 THEN cpupns = 0;
ELSE cpupns = .;
IF achangep > 1 & achangep ~= . THEN DO;
cp = .; changep = .; achangep = .; cpup = .;
END;
IF achangepns > 1 & achangepns ~= . THEN DO;
cpns = .; changepns = .; achangepns = .; cpupns = .;
END;
logp = LOG(puse);
logpns = LOG(pusens);
Lag2pusens = LAG2(pusens);
Lag2puse = LAG2(puse);
Lnprod = LAG(Nprod);
IF pusens ~= . & lagpusens = . & Lag2pusens ~= . & Nprod = 0 & Lnprod = 0 & Mondif = 1 & Lmondif = 1 THEN DO;
bimns = 1;
lagpusens = Lag2pusens;
END;
IF bimns = 1 & pusens = lagpusens THEN DO;
	cpns = 0; dcnprice = 0;
END;
IF bimns = 1 & pusens ~= lagpusens THEN DO;
cpns = 1;
changepns = LOG(pusens) - LOG(lagpusens);
achangepns = ABS(changepns);
END;
IF bimns = 1 & cpns = 1 & changepns > 0 THEN cpupns = 1;
IF achangepns > 1 & bimns = 1 THEN DO;
cpns = .;
changepns = .;
achangepns = .;
cpupns = .;
END;
IF puse ~= . & lagpuse = . & Lag2pusens ~= . & Nprod = 0 & Lnprod = 0 & Mondif = 1 & Lmondif = 1 THEN DO;
bim = 1;
lagpuse = Lag2puse;
END;
IF bim = 1 & puse = lagpuse THEN cp = 0;
IF bim = 1 & puse ~= lagpuse THEN DO;
cp = 1;
changep = LOG(puse) - LOG(lagpuse);
achangep = ABS(changep);
END;
IF achangep > 1 & bim = 1 THEN DO;
cp = .;
changep = .;
achangep = .;
END;
IF achangep < 1E-6 & achangep ~= . THEN DO;
cp = 0; changep = .; achangep = .; cpup = .;
END;
IF achangepns < 1E-6 & achangepns ~= . THEN DO;
cpns = 0; changepns = .; achangepns = .; cpupns = .;
END;
RUN;


*ELI-month statistics;
*Only monthly;
PROC SORT DATA =ALL.Masteruserdb;
BY eli Year Month;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT= Freqns MEAN(cpns) = Freqns 
MEAN(cpupns) = Fracupns N(cpns) = obsns 
STDDEV(changepns) = Dispns MEAN(achangepns) = absns
SUM(cpns) = changesns SUM(cpupns) = changesupns;
WHERE eli ~= '' & bimns ~= 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT= Freqs MEAN(cp) = Freqs N(cp) = obs 
MEAN(achangep) = abs SUM(cp) = changes ;
WHERE eli ~= '' & bim ~= 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT = Frequp MEAN(achangepns) = absupns STDDEV(changepns) = Dispupns;
WHERE cpupns = 1 & eli ~= '' & bimns ~= 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT = Freqdw MEAN(achangepns) = absdwns STDDEV(changepns) = Dispdwns;
WHERE cpupns = 0 & eli ~= '' & bimns ~= 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT = Pricedisp STDDEV(logp) = pricedisp QRANGE(logp) = priceiqr 
STDDEV(logpns) = pricedispns QRANGE(logpns) = priceiqrns N(logp) = pobs N(logpns) = pobsns;
WHERE eli ~= '' & bimns ~= 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT = Pricedispall STDDEV(logp) = pricedispall QRANGE(logp) = priceiqrall 
STDDEV(logpns) = pricedispnsall QRANGE(logpns) = priceiqrnsall N(logp) = pobsall N(logpns) = pobsnsall;
WHERE eli ~= '';
RUN;


DATA ALL.Freq88 (DROP = _FREQ_ _TYPE_);
MERGE Freqns Freqs Frequp Freqdw Pricedisp Pricedispall Smallcpns Smallcp;
BY eli Year Month;
RUN;

*Bi-monthly;
PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT= Freqbins MEAN(cpns) = Freqns 
MEAN(cpupns) = Fracupns N(cpns) = obsns STDDEV(changepns) = Dispns 
MEAN(achangepns) = absns SUM(cpns) = changesns SUM(cpupns) = changesupns;
WHERE eli ~= '' & bimns = 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT= Freqbi MEAN(cp) = Freq 
N(cp) = obs  MEAN(achangep) = abs SUM(cp) = changes ;
WHERE eli ~= '' & bim = 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT = Frequpbi MEAN(achangepns) = absupns STDDEV(changepns) = Dispupns;
WHERE cpupns = 1 & eli ~= '' & bimns = 1;
RUN;

PROC MEANS NOPRINT DATA =ALL.Masteruserdb;
BY eli Year Month;
OUTPUT OUT = Freqdwbi MEAN(achangepns) = absdwns STDDEV(changepns) = Dispdwns;
WHERE cpupns ~= 1 & eli ~= '' & bimns = 1;
RUN;

DATA ALL.Freqbi88;
MERGE Freqbins Freqbi Frequpbi Freqdwbi;
BY eli Year Month;
RUN;


*Size squared and cubed statistics;
DATA Mastersize;
SET ALL.Masteruserdb (KEEP = Price outlet_cd qt_cd ver_cd Year Month pusens lagpusens cpns changepns bimns eli);
Size2 = changepns**2;
Size3 = changepns**3;
Sizea3 = ABS(changepns)**3;
RUN;


PROC SORT DATA = Mastersize;
BY eli Year Month;
RUN;

PROC MEANS NOPRINT DATA = Mastersize;
BY eli Year Month;
OUTPUT OUT = Size MEAN(changepns) = Size1 MEAN(Size2) = Size2 MEAN(Size3) = Size3 MEAN(Sizea3) = Sizea3 N(Size2) = Sizeobs;
WHERE eli ~= '';
RUN; 

PROC MEANS NOPRINT DATA = Mastersize;
BY eli Year Month;
OUTPUT OUT = Sizenobim MEAN(changepns) = Size1nobim MEAN(Size2) = Size2nobim MEAN(Size3)= Size3nobim MEAN(Sizea3) = Sizea3 N(Size2) = Sizeobsnobim;
WHERE eli ~= '' & bimns ~= 1;
RUN; 

DATA Size;
MERGE Size Sizenobim;
BY eli Year Month;
RUN;

