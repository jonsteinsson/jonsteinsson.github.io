*Set pat for library "ALL";
LIBNAME ALL 'C:\SCOS output\All raw output';


*** First round of accepting, based on duplicates;

PROC SORT DATA = ALL.masterclean OUT = ALL.mastercleansm (DROP = PSU Flag Fol Img Imord C Pctchange) ;
BY Outlet QTE VER Month Price;
RUN;

* Number of times a particular price of a product month is observed. Product is a unique combination of
Outlet, QTE (quote), and VER (version);
PROC MEANS NOPRINT DATA = ALL.mastercleansm;
BY Outlet QTE VER Month Price;
OUTPUT OUT = ALL.N N(Cper) = Num;
RUN;

*Count how many prices observed more than once in each PM;
DATA ALL.N;
SET ALL.N (DROP = _TYPE_ _FREQ_);
C = (Num > 1);
Mis = (Price = . & C = 1);
RUN;

PROC MEANS NOPRINT DATA = ALL.N;
BY Outlet QTE VER Month;
VAR C Mis;
OUTPUT OUT = ALL.Count SUM(C) = Count SUM(Mis) = M;
RUN;

*If "missing" and some non-missing price each  appear more than once among duplicates  for a product-month, delete "missing";
DATA ALL.Mastersum;
MERGE ALL.N ALL.Count;
BY Outlet QTE VER Month;
IF Mis = 1 & Count = 2 THEN DELETE;
RUN;

* Number of times mode price occurs in a PM, accept the mode price (only if it is the only non-missing
price that appears more than once);
PROC MEANS NOPRINT DATA = ALL.Mastersum;
BY Outlet QTE VER Month;
VAR Num;
OUTPUT OUT = ALL.Max MAX(Num) = Maxx;
RUN;

DATA ALL.Mastersum (DROP = _FREQ_ _TYPE_ C);
MERGE ALL.Max ALL.Mastersum;
BY Outlet QTE VER Month;
Mode = (Num = Maxx);
Accept = (Mode = 1 & (Count = 1 | (Count = 2 & M = 1)));
RUN;

* Create dataset with only accepted prices;
DATA ALL.Accept1;
SET ALL.mastersum;
IF Accept = 1;
RUN;

PROC MEANS NOPRINT DATA = ALL.Accept1;
BY Outlet QTE VER Month;
OUTPUT OUT = ALL.Naccepts N(Price) = Naccepted;
RUN;

* Keeps only one price observation per PM;
DATA ALL.Accept1 (RENAME = (Price = Pricea) DROP = Maxx Mis M Num Count Mode);
MERGE ALL.Accept1 ALL.Naccepts;
BY Outlet QTE VER Month;
IF Naccepted GT 1 THEN DELETE;
RUN;


PROC SORT DATA = ALL.Masterclean;
BY Outlet QTE VER Month;
RUN;

DATA ALL.Masterclean (DROP = Pricea);
MERGE ALL.Accept1 ALL.Masterclean;
BY Outlet QTE VER Month;
IF Accept = 1 THEN Price = Pricea;
IF Accept = . THEN Accept = 0;
RUN;


*Start of second accepting algorithm, based on percentage change variable;

* Sort by image, product first to create lags and Dis variable;
PROC SORT DATA=ALL.Masterclean OUT = ALL.Mastercleansm (DROP = ELI PSU Flag Imord C) ;
BY Cper Fol Img Outlet QTE VER Month;
RUN;

*Create variable that indicates a discrepancy between price change variable and
price change calculated based on consecute price observations. Allows for 0.5%
margin of error, and only considers absolute value of percentage change;
DATA ALL.mastercleansm (DROP = Lnprod Lag2price Lag2change);
SET ALL.mastercleansm;
BY Cper Fol Img Outlet QTE VER;
Nprod = FIRST.VER;
Lprod = LAST.VER;
Lagprice = LAG(Price);
Lnprod = LAG(Nprod);
Lag2price = LAG2(Price);
Lagchange = Lag(Pctchange);
Lag2change = LAG2(Pctchange);
IF Nprod = 1 THEN DO;
	Lagprice = .;
	Lagchange = .;
END;
IF Lnprod = 1 & Lagprice = . THEN DO;
	Nprod = 1;
	Lagchange = .;
END;
IF Lagprice = . & Nprod ~= 1 THEN DO;
	Lagprice = Lag2price;
	Lagchange = Lag2change;
END;
IF Price = . THEN Lagprice = .;
IF Pctchange = . THEN Lagchange = .;
IF Lagprice ~= . & Lagprice ~= 0 THEN Change = ((Price - Lagprice)/Lagprice)*100;
IF (ABS(ABS(Change)-ABS(Pctchange)) > 0.505 & Lagprice ~= . )  THEN
		Dis = 1;
ELSE IF (Change = . | Pctchange = .) THEN Dis = . ;
ELSE Dis = 0;
RUN;

* Sort in reverse month order to create leads;
PROC SORT DATA = ALL.Mastercleansm;
BY Cper Fol Img Outlet QTE VER DESCENDING Month;
RUN;

DATA ALL.Mastercleansm (DROP = Llprod Lead2price Lead2change);
SET ALL.Mastercleansm;
Disn = Lag(Dis);
Llprod = LAG(Lprod);
Leadchange = Lag(Pctchange);
Leadprice = Lag(Price);
Lead2change = LAG2(Pctchange);
Lead2price = LAG2(Price);
IF Lprod = 1 THEN DO;
	Leadprice = .;
	Leadchange = .;
	Disn = .;
END;
IF Llprod = 1 & Leadprice = . THEN DO;
	Lprod = 1;
	Leadchange = .;
END;
IF (Leadprice = .) & (Lprod ~= 1) THEN DO;
	Leadprice = Lead2price;
	Leadchange = Lead2change;
END;
IF Price = . THEN Leadprice = .;
IF Pctchange = . THEN Leadchange = .;
RUN;

*Accept prices consistent with pattern of disagreements;
DATA ALL.Mastercleansm;
SET ALL.Mastercleansm;
Accept2 = .;
IF DIS = 1 & (Pctchange = 4 | Pctchange = 44 | Pctchange = 444)
	THEN Dis = .;
IF (Nprod = 1) & (
	Disn = 0 | Disn = .) THEN
	Accept2 = 1;
ELSE IF (Nprod = 1 & Lprod = 0) &
	Disn = 1 THEN
	Accept2 = 0;
ELSE IF (Nprod = 0 & Lprod = 0) & (
	Dis = 0 | 
	(Dis = . & Disn = 0) |
	(Dis = 1 & Disn = 0)) THEN
	Accept2 = 1;
ELSE IF (Nprod = 0 & Lprod = 0) & (
	(Dis = . & Disn = 1) |
	(Dis = 1 & Disn = .) | (Dis = . & Disn = .) |
	(Dis = 1 & Disn = 1 & Pctchange ~= 0))
	THEN Accept2 = 0;
ELSE IF (Nprod = 0 & Lprod = 0) & (
	Dis = 1 & Disn = 1 & Pctchange = 0
	& Lagchange = 0 & Leadchange = 0)
	THEN DO;
	Price = Lagprice;
	Accept2 = 1;
	END;
ELSE IF (Nprod = 0 & Lprod = 0) &
	(Dis = 1 & Disn = 1) THEN
	Accept2 = 0;
ELSE IF (Lprod = 1) & (Dis = 0 |
	Dis = .) THEN Accept2 = 1;
ELSE IF (Lprod = 1) & (Dis = 1)
	THEN Accept2 = 0;
Disag = 0;
IF Accept = 1 & Accept2 = 1 & (Pricea ~= Price) THEN Disag = 1;
IF (Accept = 1 | Accept2 = 1) THEN Pricea = Price;
ELSE IF (Accept = . | Accept = 0) THEN Pricea = .;
RUN;

*Delete observations where two different prices are accepted, merging with previous round of accepting;
PROC SORT DATA = ALL.Mastercleansm OUT = ALL.Masteraccept NODUPKEY;
BY Outlet QTE VER Month Pricea;
RUN;

PROC MEANS NOPRINT DATA = ALL.Masteraccept;
BY Outlet QTE VER Month ;
OUTPUT OUT = ALL.Naccept2 N(Pricea) = Naccept2;
RUN;

DATA ALL.Masteraccept (DROP = Price Lagprice Lagchange Change Dis Disn Leadprice Leadchange);
MERGE ALL.Masteraccept ALL.Naccept2;
BY Outlet QTE VER Month ;
Accept1 = Accept;
IF Naccept2 GT 1 THEN DELETE;
IF Accept2 = 1 THEN Accept = 1;
*BY Outlet QTE VER Month Pricea;
*	nprice = First.Pricea;
RUN;

PROC SORT DATA = ALL.Masteraccept OUT = ALL.Masteraccept;
BY Outlet QTE VER Month Accept;
RUN;

*Keep only one observaton per product month, and always keep accepted
observation where available;
DATA ALL.Masteraccept (DROP = nprice);
SET ALL.Masteraccept;
BY Outlet QTE VER Month;
	IF LAST.Month = 1;
RUN;


