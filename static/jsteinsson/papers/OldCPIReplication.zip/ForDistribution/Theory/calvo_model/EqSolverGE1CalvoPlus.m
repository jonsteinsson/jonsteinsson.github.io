% Iterates on G
%
% Jon Steinsson and Emi Nakamura, August 2006
%*************************************************

function [G,rV,F,F2,Q,hitMaxItOnG] = EqSolverGE1CalvoPlus(rPi,menucost,menucost2,...
    alphaCalvo,RMU,beta,theta,a,rp,rad,...
    Proba,ProbNgr,rV,Q,G,tolV,tolQ,MaxItOnG,yesprint)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

rpinc = rp(2)-rp(1);

supDifG = 2*rpinc;
GMove = zeros(radgridsize,1);
i = 1;
while (supDifG >= 0.99*rpinc & i <= MaxItOnG)
    fprintf('######## %5.3f #########\n\n',i)
%    figure(65)
%    plot(rad,G)

    G_old = G;
    
    % Bellman function iteration
    [rV,F,F2] = VFIterationGECalvoPlus(rPi,menucost,menucost2,alphaCalvo,rV,RMU,...
        beta,a,rp,rad,Proba,ProbNgr,G,tolV,yesprint,yesprint);
    
    % Calculate the stationary distribution
    Q = StaDistGECalvoPlus(Q,alphaCalvo,Proba,ProbNgr,F,F2,G,...
        a,rp,rad,tolQ,yesprint);
    
    totWeight = sum(reshape(Q,[agridsize*rpgridsize radgridsize]))';
    
    if i > 10
        StageForG = 2;
    end
    
    % Update G
    [G W_SPold supDifG G_resid GMove] = UpdateGCalvoPlus(Q,F,F2,G,a,rp,rad,...
        alphaCalvo,theta,Proba,ProbNgr,GMove);
    
    if yesprint == 1
        [supDifG rpinc]
        [rad G (G-G_old) G_resid totWeight W_SPold]
        fprintf('      rad       G     (G-G_old)    G_resid   totWeight    W_SPold\n')
    end
    
    i = i + 1;
end

if i > MaxItOnG 
    hitMaxItOnG = 1;
else
    hitMaxItOnG = 0;
end


