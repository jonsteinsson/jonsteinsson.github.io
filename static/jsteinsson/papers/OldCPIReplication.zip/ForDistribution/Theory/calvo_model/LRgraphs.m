%% Long-run Menu Cost (computing moments from stationary distribution)
load('Stats.mat');
pi = linspace(0,0.01,20);
maingraph = 1;
if maingraph == 1
    subplot(2,2,1)
    scatter(pi,Stats.freq); xlabel('Steady-state inflation, monthly'); ylabel('Fraction of prices that change');
    subplot(2,2,2)
    scatter(pi,Stats.sizepc); xlabel('Steady-state inflation, monthly'); ylabel('Average size of price change');
    subplot(2,2,3)
    scatter(pi,Stats.disprp); xlabel('Steady-state inflation, monthly'); ylabel('Std Dev_z log(p(z)/P)');
    subplot(2,2,4)
    scatter(pi,Stats.disppce); xlabel('Steady-state inflation, monthly'); ylabel('Std Dev_z \pi(z), only price changes');
else
    subplot(2,2,1)
    scatter(pi,Stats.sizeup); xlabel('Steady-state inflation,monthly'); ylabel('Mean size of price increases');
    subplot(2,2,2)
    scatter(pi,Stats.sizedw);xlabel('Steady-state inflation, monthly'); ylabel('Mean size of price decreases');
    subplot(2,2,3)
    scatter(pi,Stats.fracup);xlabel('Steady-state inflation, monthly'); ylabel('Fraction of Price Changes That Are Increases');
    subplot(2,2,4)
    scatter(pi,Stats.skewpce);xlabel('Steady-state inflation, monthly'); ylabel('Skew_z \pi(z) , only price changes');
end
%subplot(2,2,4)
%scatter(pi,Stats.skewpce); xlabel('Steady-state inflation, monthly'); ylabel('Skew_z \pi(z), only price changes');
%%
subplot(2,2,1)
scatter(pi,Stats.freq); xlabel('Steady-state inflation, monthly'); ylabel('Fraction of prices that change'); title('Menu Cost, Frequency');
subplot(2,2,2)
scatter(pi,Stats.disppce); xlabel('Steady-state inflation, monthly'); ylabel('Std Dev_z \pi(z), only price changes'); title('Menu Cost, Dispersion');
subplot(2,2,3)
scatter(pi,StatsCalvo.freq); xlabel('Steady-state inflation, monthly'); ylabel('Fraction of prices that change'); title('CalvoPlus, Frequency');
subplot(2,2,4)
scatter(pi,StatsCalvo.disppc); xlabel('Steady-state inflation, monthly'); ylabel('Std Dev_z \pi(z), only price changes'); title('CalvoPlus, Dispersion');




%% Long Run Calvo
load('StatsCalvo.mat');
pi = linspace(0,0.01,20);
maingraph = 1;
if maingraph == 1
    subplot(2,2,1)
    scatter(pi,StatsCalvo.freq); xlabel('Steady-state inflation, monthly'); ylabel('Fraction of prices that change');
    subplot(2,2,2)
    scatter(pi,StatsCalvo.sizepc); xlabel('Steady-state inflation, monthly'); ylabel('Average size of price change');
    subplot(2,2,3)
    scatter(pi,StatsCalvo.disprp); xlabel('Steady-state inflation, monthly'); ylabel('Std Dev_z log(p(z)/P)');
    subplot(2,2,4)
    scatter(pi,StatsCalvo.disppc); xlabel('Steady-state inflation, monthly'); ylabel('Std Dev_z \pi(z), only price changes');
else
    subplot(2,2,1)
    scatter(pi,StatsCalvo.sizeup); xlabel('Steady-state inflation,monthly'); ylabel('Mean size of price increases');
    subplot(2,2,2)
    scatter(pi,StatsCalvo.sizedw);xlabel('Steady-state inflation, monthly'); ylabel('Mean size of price decreases');
    subplot(2,2,3)
    scatter(pi,StatsCalvo.fracup);xlabel('Steady-state inflation, monthly'); ylabel('Fraction of Price Changes That Are Increases');
    subplot(2,2,4)
    scatter(pi,StatsCalvo.skewpc);xlabel('Steady-state inflation, monthly'); ylabel('Skew_z \pi(z) , only price changes');
end



