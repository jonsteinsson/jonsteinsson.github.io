clear;clc;
% Figure Format
PRESENTATION = false;
if PRESENTATION
    Format.FontSize = 16;
    Format.colors = {'k','r','k','r'};
    Format.barcolors = {[0 0 0], [0.55 0.55 0.55],[0 0 0],[0.55 0.55 0.55]};
    Format.widths = {2,2,2,2};
    Format.styles = {'-','-','-.','-.'};
    Format.figsize = [460 200 700 525];
    Format.figsize2 = [460 200 1200 450];
    Format.figsize4 = [460 200 1025 825];
    Format.figsize6 = [460 200 875 875];
    Format.FontSize = 14;
    Format.FontSizeAxes = 12;
    Format.fontweight = 'bold';
    Format.XTick = [1975 1980 1985 1990 1995 2000 2005 2010 2015] ;
    Format.Xlim =[1975 2015] ;
    Format.Shade = 0.8 ;
    Format.ScatterSize = [50,50] ;
    Format.ScatterMarker = {'o','s'} ;
else
    Format.colors = {[0 0 0], [0.55 0.55 0.55],[0 0 0],[0.55 0.55 0.55]};
    Format.barcolors = {[0 0 0], [0.55 0.55 0.55],[0 0 0],[0.55 0.55 0.55]};
    Format.styles = {'-','-','-.','-.'};
    Format.widths = {1,1,1,1};
    Format.figsize = [460 200 500 400];
    Format.figsize2 = [460 200 1000 400];
    Format.figsize4 = [460 200 800 660];
    Format.figsize6 = [460 200 675 775];
    Format.FontSize = 15;
    Format.FontSizeAxes = 14;
    Format.fontweight = 'normal';
    Format.XTick = [1975 1980 1985 1990 1995 2000 2005 2010 2015] ;
    Format.Xlim =[1975 2015] ;
    Format.Shade = 0.8 ;
    Format.ScatterSize = [50,50] ;
    Format.ScatterMarker = {'o','s'} ;

end


sigma_eps = 0.0368;
rho = 0.7 ;
theta = 4 ;
X = (-2:0.001:2)' ; Y = normpdf(X,0,sqrt(sigma_eps^2/(1-rho^2))) ; dX = (X(2) - X(1)) ;
Af = (sum(exp(X).^(theta-1).*Y)*dX)^(1/(theta-1)) ;
SM = (0.05:0.001:0.95)' ;
for ii=1:length(SM)
    sm = SM(ii) ;
    Z = 1/((1-sm)^(1-sm)*(sm^sm)) ;
    FlexSSC(ii) = (((theta-1)/theta)*Af/Z)^(1/(1-sm)) ;
    f = @(Output) OutputResidual(Output,FlexSSC(ii),sm,Af);
    options = optimoptions('fsolve','Display','iter-detailed');
    % OLDVERSION options = optimset('Display','iter-detailed');
    [FlexSSY(ii),err,exitflag] = fsolve(f,1.1*FlexSSC(ii),options);
    FlexSSM(ii) = FlexSSY(ii) - FlexSSC(ii) ;
    FlexSSL(ii) = (FlexSSY(ii)*FlexSSC(ii)^(-sm)/1)*((1-sm)/sm)^sm;
end
f3 = figure('Position',Format.figsize4);
subplot(2,2,1)
p1 = plot(SM,FlexSSL); 
for linei = 1:1
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
xlabel('sm','FontSize',Format.FontSize)
xlim([SM(1) SM(end)])
set(gca,'FontSize',Format.FontSizeAxes)
title('L','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

subplot(2,2,2)
p1 = plot(SM,FlexSSY); 
for linei = 1:1
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
xlabel('sm','FontSize',Format.FontSize)
xlim([SM(1) SM(end)])
set(gca,'FontSize',Format.FontSizeAxes)
title('Y','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

subplot(2,2,3)
p1 = plot(SM,FlexSSC); 
for linei = 1:1
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
xlabel('sm','FontSize',Format.FontSize)
xlim([SM(1) SM(end)])
set(gca,'FontSize',Format.FontSizeAxes)
title('C','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

subplot(2,2,4)
p1 = plot(SM,FlexSSM); 
for linei = 1:1
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
xlabel('sm','FontSize',Format.FontSize)
xlim([SM(1) SM(end)])
set(gca,'FontSize',Format.FontSizeAxes)
title('M','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

set(f3,'PaperPositionMode', 'auto')
if PRESENTATION
    print(f3,'LofSM','-depsc2');
else
    print(f3,'Output/LofSM','-depsc2');
end
