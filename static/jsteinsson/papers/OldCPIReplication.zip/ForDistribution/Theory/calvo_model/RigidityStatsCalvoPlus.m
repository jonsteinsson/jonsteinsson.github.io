% Calculates statistics about price changes from the stationary 
% distribution
%
% Jon Steinsson and Emi Nakamura, August 2006
%**************************************************************

function PCStats = RigidityStatsCalvoPlus(Q,F,F2,alphaCalvo,a,rp,rad,theta,FlexSSC,menucost,menucost2)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

Q = reshape(Q,[Ssize 1]);
F = reshape(F,[Ssize 1]);
F2 = reshape(F2,[Ssize 1]);

% Calculate frequency of price change
%***************************************************************

rpBig = repmat(rp,[1 agridsize radgridsize]);
rpBig = permute(rpBig,[2 1 3]);
rpBig = reshape(rpBig,[Ssize 1]);

PriceChange_mc = (rpBig ~= F);
PriceChange_mc2 = (rpBig ~= F2);

PCStats.freq_mc = sum(PriceChange_mc.*Q);
PCStats.freq_mc2 = sum(PriceChange_mc2.*Q);
PCStats.freq = alphaCalvo*PCStats.freq_mc + (1-alphaCalvo)*PCStats.freq_mc2;

PCStats.fracfree = (1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq;

% Calculate frequency of price increases, frequency of price decreases,
% and fraction of price changes that are increases
%***************************************************************

PriceIncrease_mc = (F > rpBig);
PriceDecrease_mc = (F < rpBig);

PriceIncrease_mc2 = (F2 > rpBig);
PriceDecrease_mc2 = (F2 < rpBig);

PCStats.frequp_mc = sum(PriceIncrease_mc.*Q);
PCStats.freqdw_mc = sum(PriceDecrease_mc.*Q);

PCStats.frequp_mc2 = sum(PriceIncrease_mc2.*Q);
PCStats.freqdw_mc2 = sum(PriceDecrease_mc2.*Q);

PCStats.frequp = alphaCalvo*PCStats.frequp_mc + (1-alphaCalvo)*PCStats.frequp_mc2;
PCStats.freqdw = alphaCalvo*PCStats.freqdw_mc + (1-alphaCalvo)*PCStats.freqdw_mc2;

if PCStats.freq_mc == 0
    PCStats.fracup_mc = 0;
else
    PCStats.fracup_mc = sum(PriceIncrease_mc.*Q)/PCStats.freq_mc;
end
PCStats.fracup_mc2 = sum(PriceIncrease_mc2.*Q)/PCStats.freq_mc2;
PCStats.fracup = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.fracup_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.fracup_mc2;
PCStats.fracup2 = PCStats.frequp/PCStats.freq;

% Calculate absolute size of price changes, price increases and 
% price decreases
%****************************************************************

AbsSizePC_mc  = abs(F-rpBig);
AbsSizePC_mc2  = abs(F2-rpBig);

if PCStats.freq_mc == 0
    PCStats.abssizepc_mc = 0;
else
    PCStats.abssizepc_mc = sum(AbsSizePC_mc.*Q)/PCStats.freq_mc;
end
PCStats.abssizepc_mc2 = sum(AbsSizePC_mc2.*Q)/PCStats.freq_mc2;
PCStats.abssizepc = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.abssizepc_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.abssizepc_mc2;

if PCStats.freq_mc*PCStats.fracup_mc == 0
    PCStats.sizeup_mc = 0;
else
    PCStats.sizeup_mc = sum(AbsSizePC_mc.*Q.*PriceIncrease_mc)/(PCStats.freq_mc*PCStats.fracup_mc);
end
PCStats.sizeup_mc2 = sum(AbsSizePC_mc2.*Q.*PriceIncrease_mc2)/(PCStats.freq_mc2*PCStats.fracup_mc2);
PCStats.sizeup = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.sizeup_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.sizeup_mc2;

if PCStats.freq_mc*(1-PCStats.fracup_mc) == 0
    PCStats.sizedw_mc = 0;
else
    PCStats.sizedw_mc = sum(AbsSizePC_mc.*Q.*PriceDecrease_mc)/(PCStats.freq_mc*(1-PCStats.fracup_mc));
end
PCStats.sizedw_mc2 = sum(AbsSizePC_mc2.*Q.*PriceDecrease_mc2)/(PCStats.freq_mc2*(1-PCStats.fracup_mc2));
PCStats.sizedw = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.sizedw_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.sizedw_mc2;

% Calculate size of price change and powers of size of price change
%*********************************************************************

SizePC_mc  = F-rpBig;
SizePC_mc2  = F2-rpBig;

if PCStats.freq_mc == 0
    PCStats.sizepcnotabs_mc = 0;
else
    PCStats.sizepcnotabs_mc = sum(SizePC_mc.*Q)/PCStats.freq_mc;
end
PCStats.sizepcnotabs_mc2 = sum(SizePC_mc2.*Q)/PCStats.freq_mc2;
PCStats.sizepcnotabs = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.sizepcnotabs_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.sizepcnotabs_mc2;

if PCStats.freq_mc == 0
    PCStats.sizepcsquared_mc = 0;
else
    PCStats.sizepcsquared_mc = sum(SizePC_mc.^2.*Q)/PCStats.freq_mc;
end
PCStats.sizepcsquared_mc2 = sum(SizePC_mc2.^2.*Q)/PCStats.freq_mc2;
PCStats.sizepcsquared = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.sizepcsquared_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.sizepcsquared_mc2;

if PCStats.freq_mc == 0
    PCStats.sizepccubed_mc = 0;
else
    PCStats.sizepccubed_mc = sum(SizePC_mc.^3.*Q)/PCStats.freq_mc;
end
PCStats.sizepccubed_mc2 = sum(SizePC_mc2.^3.*Q)/PCStats.freq_mc2;
PCStats.sizepccubed = (alphaCalvo*PCStats.freq_mc/PCStats.freq)*PCStats.sizepccubed_mc + ((1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq)*PCStats.sizepccubed_mc2;

% Calculate inefficient price dispersion and effect of
% price dispersion on productivity
%*********************************************************************

aBig = repmat(a,[1 rpgridsize radgridsize]);
aBig = reshape(aBig,[Ssize 1]);

radBig = repmat(rad,[1 agridsize rpgridsize]);
radBig = permute(radBig,[2 3 1]);
radBig = reshape(radBig,[Ssize 1]);

% Inefficint price dispersion
PCStats.meanRprice_mc = sum((exp(F).*exp(aBig)).*Q);
PCStats.meanRprice_mc2 = sum((exp(F2).*exp(aBig)).*Q);
PCStats.meanRprice = alphaCalvo*PCStats.meanRprice_mc + (1-alphaCalvo)*PCStats.meanRprice_mc2;
PCStats.ineffpdisp_mc = sum(((exp(F).*exp(aBig)-PCStats.meanRprice_mc).^2).*Q);
PCStats.ineffpdisp_mc2 = sum(((exp(F2).*exp(aBig)-PCStats.meanRprice_mc2).^2).*Q);
PCStats.ineffpdisp = (alphaCalvo*PCStats.ineffpdisp_mc + (1-alphaCalvo)*PCStats.ineffpdisp_mc2)^(1/2);

% Effect of price dispersion on productivity
PCStats.lprod_mc = sum(((exp(F).*exp(aBig).^(1/theta)).^(-theta)).*Q)^(-1);
PCStats.lprod_mc2 = sum(((exp(F2).*exp(aBig).^(1/theta)).^(-theta)).*Q)^(-1);
PCStats.lprod = (alphaCalvo*PCStats.lprod_mc^(-1) + (1-alphaCalvo)*PCStats.lprod_mc2^(-1))^(-1);

% 2nd order approx of inefficient price dispersion and labor productivity
%************************************************************************
% (Here we take averages first within rad states and then across these
% states)

aBig = reshape(aBig,[agridsize rpgridsize radgridsize]);
F    = reshape(F   ,[agridsize rpgridsize radgridsize]);
F2    = reshape(F2   ,[agridsize rpgridsize radgridsize]);
Q    = reshape(Q   ,[agridsize rpgridsize radgridsize]);

Qrad = sum(sum(Q));
Qrad = reshape(Qrad, [radgridsize 1]);
Qrad = repmat(Qrad,[1 agridsize rpgridsize]);
Qrad = permute(Qrad, [2 3 1]);
Qnorm = Q./Qrad;

logX  = F  + (1/theta)*aBig;   % For labor productivity (high cost)
logX2 = F2  + (1/theta)*aBig;  % For labor productivity (low cost)
logZ  = F  + aBig;             % For inefficient price dispersion (high cost)
logZ2 = F2  + aBig;            % For inefficient price dispersion (low cost)

lprod2nd_mc = exp((theta*(theta+1)/2)*sum(sum(logX.^2.*Qnorm))).^(-1);
lprod2nd_mc = reshape(lprod2nd_mc, [radgridsize 1]);
lprod2nd_mc(isnan(lprod2nd_mc)) = 0;

lprod2nd_mc2 = exp((theta*(theta+1)/2)*sum(sum(logX2.^2.*Qnorm))).^(-1);
lprod2nd_mc2 = reshape(lprod2nd_mc2, [radgridsize 1]);
lprod2nd_mc2(isnan(lprod2nd_mc2)) = 0;

ineffpdisp2nd_mc = exp((theta*(theta+1)/2)*sum(sum(logZ.^2.*Qnorm))).^(-1);
ineffpdisp2nd_mc = reshape(ineffpdisp2nd_mc, [radgridsize 1]);
ineffpdisp2nd_mc(isnan(ineffpdisp2nd_mc)) = 0;

ineffpdisp2nd_mc2 = exp((theta*(theta+1)/2)*sum(sum(logZ2.^2.*Qnorm))).^(-1);
ineffpdisp2nd_mc2 = reshape(ineffpdisp2nd_mc2, [radgridsize 1]);
ineffpdisp2nd_mc2(isnan(ineffpdisp2nd_mc2)) = 0;

Qrad = sum(sum(Q));
Qrad = reshape(Qrad, [radgridsize 1]);

lprod2nd_mc = sum(lprod2nd_mc.*Qrad);
lprod2nd_mc2 = sum(lprod2nd_mc2.*Qrad);

ineffpdisp2nd_mc = sum(ineffpdisp2nd_mc.*Qrad);
ineffpdisp2nd_mc2 = sum(ineffpdisp2nd_mc2.*Qrad);

PCStats.lprod2nd_mc = lprod2nd_mc;
PCStats.lprod2nd_mc2 = lprod2nd_mc2;

PCStats.ineffpdisp2nd_mc = ineffpdisp2nd_mc;
PCStats.ineffpdisp2nd_mc2 = ineffpdisp2nd_mc2;

PCStats.lprod2nd = alphaCalvo*PCStats.lprod2nd_mc + (1-alphaCalvo)*PCStats.lprod2nd_mc2;
PCStats.ineffpdisp2nd = alphaCalvo*PCStats.ineffpdisp2nd_mc + (1-alphaCalvo)*PCStats.ineffpdisp2nd_mc2;

aBig = reshape(aBig,[Ssize 1]);
F    = reshape(F   ,[Ssize 1]);
F2   = reshape(F2   ,[Ssize 1]);
Q    = reshape(Q   ,[Ssize 1]);

% Standard deviation of Output
%**********************************************************************

Q = reshape(Q,[agridsize rpgridsize radgridsize]);
Qrad = sum(sum(Q));
Qrad = reshape(Qrad,[radgridsize 1]);
meanOutput = sum(rad.*Qrad);
PCStats.stdLogOutput = (sum(((rad-meanOutput).^2).*Qrad))^(1/2);
PCStats.meanLogOutput = meanOutput;

% Productivity in flex price case
%**********************************************************************

Qnorm = reshape(Qnorm,[Ssize 1]);
lprodFlex2 = (exp(aBig).^(theta-1)).*Qnorm;
lprodFlex2(isnan(lprodFlex2)) = 1;
lprodFlex2 = reshape(lprodFlex2,[agridsize rpgridsize radgridsize]);
lprodFlex2 = sum(sum(lprodFlex2)).^(-1/(theta-1));
lprodFlex2 = reshape(lprodFlex2,[radgridsize 1]);
PCStats.lprodFlex2 = sum(lprodFlex2.*Qrad)^(-1);
Q    = reshape(Q   ,[Ssize 1]);

% Effect of price dispersion on labor productivity (productivity wedge)
PCStats.lprodFlex = sum((exp(aBig).^(theta-1)).*Q)^(1/(theta-1));

% Flex price output
%***********************************************************************

PCStats.FlexLogOutput = log((theta-1)/theta*PCStats.lprodFlex);

% Productivity Wedge
%***********************************************************************

PCStats.prodwedge = PCStats.lprod/PCStats.lprodFlex;

% Average Relative Prices
%***********************************************************************

PCStats.meanp_mc = sum(sum(sum(exp(F).^(1-theta).*Q)))^(1/(1-theta));
PCStats.meanp_mc2 = sum(sum(sum(exp(F2).^(1-theta).*Q)))^(1/(1-theta));
PCStats.meanp = (alphaCalvo*PCStats.meanp_mc^(1-theta) + (1-alphaCalvo)*PCStats.meanp_mc2^(1-theta))^(1/(1-theta));

% Cost of Changing Prices
%***********************************************************************

PCStats.pccost_mc  = sum(menucost.*PriceChange_mc.*Q);
PCStats.pccost_mc2 = sum(menucost2.*PriceChange_mc2.*Q);
PCStats.pccost     = alphaCalvo*PCStats.pccost_mc + (1-alphaCalvo)*PCStats.pccost_mc2;

% Mean labor 
%***********************************************************************

PCStats.meanL = exp(PCStats.meanLogOutput)/PCStats.lprod + PCStats.pccost;

% Flex price labor supply
%***********************************************************************

PCStats.FlexLabor = (theta-1)/theta;

% Average Markup
%***********************************************************************

PCStats.avmarkup = PCStats.lprod/exp(PCStats.meanLogOutput);

% Welfare Loss (relative to flex price) 
%***********************************************************************
% Ignoring uncertainty !!!!!!!!!!!!!!!!!!!!!!!!!!!

PCStats.welfareLossIgnoreUncert = (exp(PCStats.FlexLogOutput) - PCStats.FlexLabor + PCStats.meanL)...
                                 ./exp(PCStats.meanLogOutput) - 1;
                             
% PCStats.welfareLossUncert = Bisect(rad,Qrad,PCStats.FlexLogOutput,PCStats.FlexLabor,PCStats.meanL) ;

end

function [Optim,Err] = Bisect(rad,Qrad,FlexLogOutput,FlexLabor,meanL)
    Conv = 1e-08 ;
    Low = 0 ;
    High = 1 ;
    mid = 0.5*(Low + High) ;
    fl = Welfare(rad,Low,Qrad,FlexLogOutput,FlexLabor,meanL) ;
    fm = Welfare(rad,mid,Qrad,FlexLogOutput,FlexLabor,meanL) ;
    fh = Welfare(rad,High,Qrad,FlexLogOutput,FlexLabor,meanL) ;    
Delta = abs(fh - fl) ;
    while Delta> Conv
        Low = mid*(fm<0) + Low*(fm>=0) ;
        fl = Welfare(rad,Low,Qrad,FlexLogOutput,FlexLabor,meanL) ;
        High = mid*(fm>=0) + High*(fm<0) ;
        fh = Welfare(rad,High,Qrad,FlexLogOutput,FlexLabor,meanL) ;
        mid = 0.5*(Low + High) ;
        fm = Welfare(rad,mid,Qrad,FlexLogOutput,FlexLabor,meanL) ;
        Delta = abs(fm) ;
        
    end
    Optim = mid ;
    Err = fm ;
end

function J = Welfare(rad,lambda,Qrad,FlexLogOutput,FlexLabor,meanL)
% This function takes the inputs from the model and a guess
% for the welfare cost and returns the difference between the welfare of
% the sticky price economy versus the flexible price economy.

J = sum(log(exp(rad)*(1+lambda)).*Qrad) - FlexLogOutput + FlexLabor - meanL ;

end





