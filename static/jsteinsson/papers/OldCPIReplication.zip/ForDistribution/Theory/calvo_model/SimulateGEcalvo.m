%% Simulate one sector GE model for N firms, T periods
time1 = cputime;
sm = 0;

%Load objects from model solution
load('GE1ModelC.mat');
G = GE1ModelC.G;
alphaCalvo = GE1ModelC.alphaCalvo;
F = GE1ModelC.F;%Policy function when menu cost is high
F2 = GE1ModelC.F2;%When menu cost is low
Q = GE1ModelC.Q;
theta = GE1ModelC.theta;
mu = GE1ModelC.mu;
sigma_eta = GE1ModelC.sigma_eta;
sigma_eps = GE1ModelC.sigma_eps;
rho = GE1ModelC.rho;
a = GE1ModelC.a;
rp = GE1ModelC.rp;
rad = GE1ModelC.rad;
GInd = CalculateGInd(a,rp,rad,G);

T = 1000;%Number periods
N = 20000;%Number of firms
burnin = 200;%Periods of burning to be discarded

%Grid parameters
amax = a(end,1);
amin = a(1,1);
agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
rpmax = rp(end,1);
rpmin = rp(1,1);
rpinc = (rpmax-rpmin)/(rpgridsize-1);
radmax = rad(end,1);
radmin = rad(1,1);

%% Smooth G and rad
nhh = 2.2; % bandwidth of kernel smoother (number of rad points/2)
radincsmooth = 10^(-6);
GError = GE1ModelC.GError;
radinc = rad(2)-rad(1);
hh = nhh*radinc;
AddN = hh/radinc - mod(hh/radinc,1);
radLong = rad;
GplusError = G + GError;
GLong = GplusError;
for i = 1:AddN
    radLong = [rad(1)-i*radinc; radLong; rad(end)+i*radinc];
    GLong = [GplusError(1) - GplusError(1+i) + GplusError(1); ...
        GLong; GplusError(end) - GplusError(end-i) + GplusError(end)];
end

Nsmooth = (rad(end)-rad(1))/radincsmooth + 1;
radSmooth = (rad(1):radincsmooth:rad(end))';
GSmooth = KernelSmoother(hh,radLong,GLong,radSmooth);

% Put GSmooth on radSmooth grid
%********************************************************
 
radSmoothinc = radSmooth(2) - radSmooth(1);
GSmooth_mod = mod(GSmooth,radSmoothinc);
GSmooth_mod_up = (GSmooth_mod > radSmoothinc/2);
GSmooth = GSmooth + GSmooth_mod_up.*(radSmoothinc-GSmooth_mod) ...
    - (1-GSmooth_mod_up).*GSmooth_mod;

%%
%Simulate time series for a for each firm
%***************************

aSim = zeros(T+burnin+1,N);%Simulated value of logA
a_inc = (amax-amin)/(agridsize-1);
eps_a = sigma_eps*randn(T+burnin,N);%Series of a shocks
aSim(1,:) = repmat(a(agridsize/2 -mod(agridsize/2,1) + 1,:),1,N);
for i = 1:(T+burnin)%Sequentially create value of a, adjusted to be a value in grid
    delta_a = (rho-1)*aSim(i,:) + eps_a(i,:);
    delta_a_mod = mod(delta_a,a_inc);
    delta_a_mod_big = (a_inc/2 < delta_a_mod);
    delta_a_mod_small = (a_inc/2 >= delta_a_mod);
    delta_a_grid = delta_a - delta_a_mod_small.*delta_a_mod ...
        + delta_a_mod_big.*(a_inc-delta_a_mod);
    aSim(i+1,:) = aSim(i,:) + delta_a_grid;
    aSim(i+1,:) = min(aSim(i+1,:),amax);
    aSim(i+1,:) = max(aSim(i+1,:),amin);
end
aSim_ind = int32((aSim - amin*ones(T+burnin+1,N))/a_inc + 1);%Index on a grid corresponding to simulated values
clear eps_a delta_a delta_a_mod delta_a_mod_big delta_a_mod_small delta_a_grid

%Simulate Calvo Fairy
%*********************
MC1 = (rand(T+burnin+1,N) < alphaCalvo); 

%Simulate inflation & RAD
%******************
radinc = (radmax - radmin)/(radgridsize - 1);
eps_eta = sigma_eta*randn(T+burnin+1,1); %NAD shocks
P = zeros(T + burnin + 1,1);%initialize price level, inflation, RAD vectors
Pi = zeros(T + burnin + 1,1);
Simrad = zeros(T + burnin + 1,1);
rad_init = rad(ceil(radgridsize/2));%RAD in t=-1
dS = zeros(T + burnin + 1,1);
dS(1,1) = mu + eps_eta(1,1);%Initial NAD innovation, adjusted to be on grid
dS_mod = mod(dS(1,1),radinc);
dS_mod_big = radinc/2 < dS_mod;
dS_mod_small = radinc/2 >= dS_mod;
dS_grid = dS(1,1) - dS_mod_small*dS_mod + dS_mod_big*(radinc - dS_mod);
rad_pre = zeros(T+burnin+1,1);
%Calculate S_0/P_-1 to predict P_0/P_-1 using G
rad_pre(1,1) = dS_grid + rad_init;
rad_pre(1,1) = min(radmax,rad_pre(1,1));
rad_pre(1,1) = max(radmin,rad_pre(1,1));
Pi(1,1) = G(int32((rad_pre(1,1)-radmin)/radinc + 1));
P(1,1) = Pi(1,1);
Simrad(1,1) = rad_pre(1,1) - Pi(1,1);
Simrad(1,1) = min(radmax,Simrad(1,1));
Simrad(1,1) = max(radmin,Simrad(1,1));
for i = 2:(T+burnin+1)
    dS(i,1) = mu + eps_eta(i,1);%Current period's NAD innovation
    dS_mod = mod(dS(i,1),radinc);%Made to fit on grid
    dS_mod_big = radinc/2 < dS_mod;
    dS_mod_small = radinc/2 >= dS_mod;
    dS_grid = dS(i,1) - dS_mod_small*dS_mod + dS_mod_big*(radinc-dS_mod);
    rad_pre(i,1) = dS_grid + Simrad(i-1,1);%Added to last period's RAD
    rad_pre(i,1) = min(radmax,rad_pre(i,1));
    rad_pre(i,1) = max(radmin,rad_pre(i,1));
    Pi(i,1) = G(int32((rad_pre(i,1)-radmin)/radinc + 1));%Inflation calculated using G
    P(i,1) = Pi(i,1) + P(i-1,1);
    Simrad(i,1) = rad_pre(i,1) - Pi(i,1);
    Simrad(i,1) = min(radmax,Simrad(i,1));
    Simrad(i,1) = max(radmin,Simrad(i,1));
end
clear eps_eta rad_init dS_mod dS_mod_big dS_mod_small dS_grid
%Indexes of RAD and S_t/P_t-1 (used to predict inflation) on grid
rad_pre_ind = int32((rad_pre-radmin)/radinc + 1);
rad_ind = int32((Simrad-radmin)/radinc + 1);

%Get smooth inflation series
SimradSmooth = zeros(T + burnin + 1,1);
PiSmooth = zeros(T + burnin + 1,1);
PSmooth = zeros(T + burnin + 1,1);
rad_preSmooth = zeros(T + burnin + 1,1);
radinit = rad(ceil(radgridsize/2));
dS_mod = mod(dS(1,1),radSmoothinc);
dS_mod_big = radSmoothinc/2 < dS_mod;
dS_mod_small = radSmoothinc/2 >= dS_mod;
dS_grid = dS(1,1) - dS_mod_small*dS_mod + dS_mod_big*(radSmoothinc - dS_mod);
rad_preSmooth(1,1) = dS_grid + radinit;
rad_preSmooth(1,1) = min(radmax,rad_preSmooth(1,1));
rad_preSmooth(1,1) = max(radmin,rad_preSmooth(1,1));
PiSmooth(1,1) = GSmooth(int32((rad_preSmooth(1,1)-radmin)/radSmoothinc + 1));
PSmooth(1,1) = Pi(1,1);
SimradSmooth(1,1) = rad_preSmooth(1,1) -PiSmooth(1,1);
SimradSmooth(1,1) = min(radmax,SimradSmooth(1,1));
SimradSmooth(1,1) = max(radmin,SimradSmooth(1,1));
for i = 2:(T + burnin + 1)
    dS_mod = mod(dS(i,1),radSmoothinc);
    dS_mod_big = radSmoothinc/2 < dS_mod;
    dS_mod_small = radSmoothinc/2 >= dS_mod;
    dS_grid = dS(i,1) - dS_mod_small*dS_mod + dS_mod_big*(radSmoothinc - dS_mod);
    rad_preSmooth(i,1) = dS_grid + SimradSmooth(i-1,1);
    rad_preSmooth(i,1) = min(radmax,rad_preSmooth(i,1));
    rad_preSmooth(i,1) = max(radmin,rad_preSmooth(i,1));
    PiSmooth(i,1) = GSmooth(int32((rad_preSmooth(i,1)-radmin)/radSmoothinc + 1));
    PSmooth(i,1) = Pi(i,1) + PSmooth(i-1,1);
    SimradSmooth(i,1) = rad_preSmooth(i,1)- PiSmooth(i,1);
    SimradSmooth(i,1) = min(radmax,SimradSmooth(i,1));
    SimradSmooth(i,1) = max(radmin,SimradSmooth(i,1));
end

%Simulate firm prices
%********************
rpSim = zeros(T+burnin+1,N);
state_pre_ind = sub2ind([agridsize rpgridsize radgridsize],int32((aSim_ind(1,:))'),int32(repmat(ceil(rpgridsize/2),N,1)),int32(repmat(rad_pre_ind(1,1),N,1)));
state_post_ind = GInd(state_pre_ind);
rpSim(1,:) = MC1(1,:).*(F(state_post_ind)') + (1 - MC1(1,:)).*(F2(state_post_ind)');
for i = 2:(T+burnin+1)
    state_pre_ind = sub2ind([agridsize rpgridsize radgridsize], int32(aSim_ind(i,:)'),int32((rpSim(i-1,:)'-rpmin)/rpinc + 1),int32(repmat(rad_pre_ind(i,1),N,1)));
    state_post_ind = GInd(state_pre_ind);
    rpSim(i,:) = MC1(i,:).*(F(state_post_ind)') + (1 - MC1(i,:)).*(F2(state_post_ind)');
end
npSim = rpSim + repmat(P,1,N);
ndpSim = npSim(2:end,:)-npSim(1:end-1,:);
xSim = exp(-theta*rpSim-aSim);
clear rad_pre rad_pre_ind aSim

%Desired price & gap
Simchange = (abs(ndpSim) > 1e-8);
Despsim = zeros(T + burnin + 1,N);
Despsim(1,:) = npSim(1,:);
for t = 2:(T+burnin+1)
    for i = 1:N
        if Simchange(t-1,i) == 1 
            Despsim(t,i) = npSim(t,i);
        elseif Simchange(t-1,i) == 0 
            Despsim(t,i) = Despsim(t-1,i) + Pi(t,1);
        end
    end
end
Gapsim = npSim - Despsim;

%Keep series without burnin
PSim = P(burnin + 2:end,:);
PiSim = Pi(burnin + 2:end,:);
PiSimSmooth = PiSmooth(burnin + 2:end,:);
SimradSmooth = SimradSmooth(burnin + 2:end,:);
Simrad = Simrad(burnin + 2:end,:);
rpSim = rpSim(burnin + 2:end,:);
xSim = xSim(burnin + 2:end,:);
npSim = npSim(burnin + 2:end,:);
ndpSim = ndpSim(burnin + 1:end,:);
Despsim = Despsim(burnin + 2:end,:);
Gapsim = Gapsim(burnin + 2:end,:);
Simchange = Simchange(burnin + 2:end,:);
MC1 = MC1(burnin + 2:end,:);


timeofsimulation = cputime - time1


%% Calculate price change statistics for each period
Simchange = (abs(ndpSim) > 1e-8);
Fail = MC1.*Simchange;
Failpct = sum(Fail,2)./sum(MC1,2);
freqchange = sum(Simchange,2)*(1/N);
frequp = sum((ndpSim > 1e-8),2)*(1/N);
fracup = (sum((ndpSim > 1e-8),2)*(1/N))./freqchange;
fracdown = (sum((ndpSim < -1e-8),2)*(1/N))./freqchange;
%Calculate statistics based only on prices that change
ndpstats = sort(ndpSim,2);
Nup = sum((ndpSim > 1e-8),2);
Ndown = sum((ndpSim < -1e-8),2);
Nchange = sum(Simchange,2);
Meanabs = zeros(T,1);
Meanup = zeros(T,1);
Meandown = zeros(T,1);
SDrp = zeros(T,1);
SDpi = zeros(T,1);
SDup = zeros(T,1);
SDdown = zeros(T,1);
SKrp = zeros(T,1);
SKpi = zeros(T,1);
IQRpi = zeros(T,1);
for i = 1:T
    Meanabs(i,1) = mean(abs([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]));
    Meandown(i,1) = mean(abs(ndpstats(i,1:Ndown(i,1))));
    Meanup(i,1) = mean(ndpstats(i,N-Nup(i,1)+1:end));
    SDpi(i,1) = std([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]);
    SDdown(i,1) = std(ndpstats(i,1:Ndown(i,1)));
    SDup(i,1) = std(ndpstats(i,N-Nup(i,1)+1:end));
    SKpi(i,1) = skewness([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]);
    IQRpi(i,1) = iqr([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]);
end
%Moments of real prices (p/P), first select only real prices with price
%change
rpstats = log(sort(exp(rpSim).*Simchange,2));
for i = 1:T
    SDrp(i,1) = std(rpstats(i,N-Nchange(i,1)+1:end));
    SKrp(i,1) = skewness(rpstats(i,N-Nchange(i,1)+1:end));
end
%Moments of real prices (p/P) and price changes, including prices that don't change
SDrpall = std(rpSim,0,2);
SKrpall = skewness(rpSim,1,2);
SDpiall = std(ndpSim,0,2);
SKpiall = skewness(ndpSim,1,2);
SDgap = std(Gapsim,0,2);
Meangap = mean(Gapsim,2);
P10gap = prctile(Gapsim,10,2);
P25gap = prctile(Gapsim,25,2);
P50gap = prctile(Gapsim,50,2);
P75gap = prctile(Gapsim,75,2);
P90gap = prctile(Gapsim,90,2);
Dist = mean(xSim,2);
Distgap = mean((exp(Gapsim).^(-theta)),2);


%% Figures, set dispi*** = 1 to display and save each figure
% Inflation time series plot
disppits = 1;
if disppits == 1
 h = plot(PiSimSmooth,'b-');title('Time Series Plot of Simulated Inflation');xlabel('Time (Months)');ylabel('Monthly Inflation');saveas(h,'Graphs\Calvo\pits.png');
end

% Time series plot of relative price and price gap dispersion
dispts = 1;
if dispts == 1;
    ind = (1:T)';
    cor = corr(SDrp,SDgap);
    plot(ind,SDrp,'b-',ind,SDgap,'r-');title(strcat('Time Series Plot of Relative Price & Price Gap Dispersion; Corr = ',num2str(cor)));xlabel('Time (Months)');
    legend('Relative Price Dispersion','Desired Price Gap Dispersion','Location','Best');saveas(gcf,'Graphs\Calvo\dispts.png');
end

dispdistts = 1;
if dispdistts == 1;
    plot(Dist,'b-');title('Time Series plot of Price Distortion Meausure');xlabel('Time (Months)');saveas(gcf,'Graphs\Calvo\distts.png');
end

%Scatter plots of moments with inflation
%Frequency
dispfreq = 1;
if dispfreq == 1
h = scatter(PiSimSmooth,freqchange,2);title('\pi and Frequency of Price Change'); xlabel('\pi_t'); ylabel('Frequency');saveas(h,'Graphs\Calvo\freq.png');
end
%Mean size of price change
dispabs = 1;
if dispabs == 1
    h = scatter(PiSimSmooth,Meanabs,2);title('\pi and Mean Size Price Change');xlabel('\pi_t');ylabel('Mean size of price change');saveas(h,'Graphs\Calvo\abs.png');
end
%Mean size of price increases
dispmeanup = 1;
if dispmeanup == 1;
    h = scatter(PiSimSmooth,Meanup,2);title('\pi and Mean Size of Price Increase');xlabel('\pi_t');ylabel('Mean size of price increase');saveas(h,'Graphs\Calvo\meanup.png');
end
%Mean size of price decreases
dispmeandw = 1;
if dispmeandw == 1;
    h = scatter(PiSimSmooth,Meandown,2);title('\pi and Mean Size of Price Decrease');xlabel('\pi_t');ylabel('Mean size of price decrease');saveas(h,'Graphs\Calvo\meandw.png');
end
%Inflation dispersion
dispsdpi = 1;
if dispsdpi == 1
    h = scatter(PiSimSmooth,SDpi,2);title('\pi and Inflation Dispersion, excluding zero price changes');xlabel('\pi_t');ylabel('Std Dev_z \pi(z)');saveas(h,'Graphs\Calvo\sdpi.png');
end
%Price increase dispersion
dispsdup = 1;
if dispsdup == 1;
    h = scatter(PiSimSmooth,SDup,2);title('\pi and Inflation Dispersion, only increases');xlabel('\pi_t');ylabel('Std Dev_z \pi(z)');saveas(h,'Graphs\Calvo\sdup.png');
end

%Price descrease dispersion
dispsddw = 1;
if dispsddw == 1;
    h = scatter(PiSimSmooth,SDdown,2);title('\pi and Inflation Dispersion, only decreases');xlabel('\pi_t');ylabel('Std Dev_z \pi(z)');saveas(h,'Graphs\Calvo\sddw.png');
end
%Real price dispersion
dispsdrp = 1;
if dispsdrp == 1;
    h = scatter(PiSimSmooth,SDrpall,2);title('\pi and Relative Price Dispersion, including zero price changes');xlabel('\pi_t');ylabel('Std Dev_z log(p(z)/P)');saveas(h,'Graphs\Calvo\sdrp.png');
end
%Inflation skewness
dispskpi = 1;
if dispskpi == 1;
    h = scatter(PiSimSmooth,SKpi,2);title('\pi and Skewness of Price Changes, excluding zero price changes');xlabel('\pi_t');ylabel('Skew_z \pi(z)');saveas(h,'Graphs\Calvo\skpi.png');
end

%Price distortions & Inflation;
dispdist = 1;
if dispdist == 1;
    scatter(PiSimSmooth,Dist,2);title('\pi and Distortions from Relative Price Misalignments');xlabel('\pi_t');ylabel('Mean of (p(z)A(z)/P)^{-\theta} ');
    saveas(gcf,'Graphs\Calvo\Dist.png');
end

%Price gap distortions & Inflation;
dispdist = 1;
if dispdist == 1;
    scatter(PiSimSmooth,Distgap,2);title('\pi and Price Gap Distortion');xlabel('\pi_t');ylabel('Price gap measure of Distortion');
    saveas(gcf,'Graphs\Calvo\Distgap.png');
end

%Desired Price Gap dispersion
dispsdgap = 1;
if dispsdgap == 1;
    h = scatter(PiSimSmooth,SDgap,2);title('\pi and Dispersion of Desired Price Gap, all prices');xlabel('\pi_t');ylabel('Standard Deviation');saveas(h,'Graphs\MC\sdgap.png');
end

%Time series of price gap percentiles
dispgapd = 1;
if dispgapd == 1;
    ind = (1:T)';
    plot(ind,P10gap,'k',ind,P25gap,'b',ind,P50gap,'r',ind,P75gap,'m',ind,P90gap,'g');xlabel('Time (Months)');ylabel('Desired Price Gap');
    title('Percentiles (10,25,50,75,90) of Desired Price Gap distribution');saveas(gcf,'Graphs\Calvo\Gapdistts.png');
end

%Correlations of percentiles with inflation
dispgapscatter = 1;
if dispgapscatter == 1;
    scatter(PiSimSmooth,P10gap,50);title('\pi and 10^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 10^{th} Pctile');
    saveas(gcf,'Graphs\Calvo\Gap10infl.png');
    scatter(PiSimSmooth,P25gap,50);title('\pi and 25^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 25^{th} Pctile');
    saveas(gcf,'Graphs\Calvo\Gap25infl.png');
    scatter(PiSimSmooth,P50gap,50);title('\pi and 50^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 50^{th} Pctile');
    saveas(gcf,'Graphs\Calvo\Gap50infl.png');
    scatter(PiSimSmooth,P75gap,50);title('\pi and 75^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 75^{th} Pctile');
    saveas(gcf,'Graphs\Calvo\Gap75infl.png');
    scatter(PiSimSmooth,P90gap,50);title('\pi and 90^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 90^{th} Pctile');
    saveas(gcf,'Graphs\Calvo\Gap90infl.png');
end


%Table of frequency, size, inflation & real price dispersion scatter plots
disptable1 = 1;
if disptable1 == 1
    subplot(2,2,1);
    scatter(PiSimSmooth,freqchange,2);title('\pi and Frequency of Price Change'); xlabel('\pi_t'); ylabel('Frequency');
    subplot(2,2,2)
    scatter(PiSimSmooth,Meanabs,2);title('\pi and Mean Size Price Change');xlabel('\pi_t');ylabel('Mean size of price change');
    subplot(2,2,3)
    scatter(PiSimSmooth,SDrpall,2);title('\pi and Relative Price Dispersion, including zero price changes');xlabel('\pi_t');ylabel('Std Dev_z log(p(z)/P)');
    h = subplot(2,2,4);
    scatter(PiSimSmooth,SDpi,2);title('\pi and Inflation Dispersion, excluding zero price changes');xlabel('\pi_t');ylabel('Std Dev_z \pi(z)');saveas(h,'Graphs\Calvo\table1.png')
end

%Table of fraction of changes that are increases, size of increases, size
%of decreases, skewness
disptable = 2;
if disptable == 2
    subplot(2,2,1)
    scatter(PiSimSmooth,Meanup,2);title('\pi and Mean Size of Price Increase'); xlabel('\pi_t'); ylabel('Mean Size');
    subplot(2,2,2)
    scatter(PiSimSmooth,Meandown,2);title('\pi and Mean Size of Price Decrease');xlabel('\pi_t');ylabel('Mean Size');
    subplot(2,2,3)
    scatter(PiSimSmooth,fracup,2);title('\pi and Fracion of Changes that are Increases');xlabel('\pi_t');ylabel('Fraction');
    h = subplot(2,2,4);
    scatter(PiSimSmooth,SKpi,2);title('\pi and Skewness of Price Changes, excluding zero price changes');xlabel('\pi_t');ylabel('Skew_z \pi(z)');saveas(h,'Graphs\Calvo\table2.png');
end



%Histogram of price changes for periods of different inflation
disphistpc = 1;
if disphistpc == 1
    [Pisort, I] = sort(PiSimSmooth);
    tneg = I(1);
    tpos = I(T);
    tpos2 = I(T-200);
    [Pisort, I ] = sort(abs(PiSimSmooth));
    tzero = I(1);
    tlow = I(200);
    clear Pisort I;
    tizero = strcat(' \pi = ',num2str(PiSimSmooth(tzero,1)), ',SDpi = ',num2str(SDpi(tzero,1)),' Freq = ',num2str(freqchange(tzero,1)),', Skew=',num2str(SKpi(tzero,1)));
    tilow = strcat(' \pi = ',num2str(PiSimSmooth(tlow,1)), ',SDpi = ',num2str(SDpi(tlow,1)),' Freq = ',num2str(freqchange(tlow,1)),', Skew=',num2str(SKpi(tlow,1)));
    tipos = strcat(' \pi = ',num2str(PiSimSmooth(tpos,1)), ',SDpi = ',num2str(SDpi(tpos,1)),' Freq = ',num2str(freqchange(tpos,1)),', Skew=',num2str(SKpi(tpos,1)));
    tipos2 = strcat(' \pi = ',num2str(PiSimSmooth(tpos2,1)), ',SDpi = ',num2str(SDpi(tpos2,1)),' Freq = ',num2str(freqchange(tpos2,1)),', Skew=',num2str(SKpi(tpos2,1)));
    subplot(2,2,1)
    hist([ndpstats(tzero,1:Ndown(tzero,1)) ndpstats(tzero,N-Nup(tzero,1)+1:end)],2000); title(tizero);
    subplot(2,2,2)
    hist([ndpstats(tlow,1:Ndown(tlow,1)) ndpstats(tlow,N-Nup(tlow,1)+1:end)],2000); title(tilow);
    subplot(2,2,3)
    hist([ndpstats(tpos2,1:Ndown(tpos2,1)) ndpstats(tpos2,N-Nup(tpos2,1)+1:end)],2000); title(tipos2);
    h = subplot(2,2,4);
    hist([ndpstats(tpos,1:Ndown(tpos,1)) ndpstats(tpos,N-Nup(tpos,1)+1:end)],2000); title(tipos);saveas(h,'Graphs\Calvo\histpc.png');
end

%Histogram of real prices for periods of different inflation
disphistrp = 1;
if disphistrp == 1
    [Pisort, I] = sort(PiSimSmooth);
    tneg = I(1);
    tpos = I(T);
    tpos2 = I(T-200);
    [Pisort, I ] = sort(abs(PiSimSmooth));
    tzero = I(1);
    tlow = I(200);
    clear Pisort I;
    tizero = strcat('Real price dispersion, all, \pi = ',num2str(PiSimSmooth(tzero,1)), ',SDrp = ',num2str(SDrpall(tzero,1)));
    tilow = strcat('Real price dispersion, all, \pi = ',num2str(PiSimSmooth(tlow,1)), ',SDrp = ',num2str(SDrpall(tlow,1)));
    tipos = strcat('Real price dispersion, all,  \pi = ',num2str(PiSimSmooth(tpos,1)), ',SDrp = ',num2str(SDrp(tpos,1)));
    tipos2 = strcat('Real price dispersion, all, \pi = ',num2str(PiSimSmooth(tpos2,1)), ',SDrp = ',num2str(SDrp(tpos,1)));
    subplot(2,2,1)
    hist(rpSim(tzero,:),100);title(tizero);
    subplot(2,2,2)
    hist(rpSim(tlow,:),100);title(tilow)
    subplot(2,2,3)
    hist(rpSim(tpos2,:),100);title(tipos2);
    h = subplot(2,2,4);
    hist(rpSim(tpos,:),100);title(tipos); saveas(h,'Graphs\Calvo\histrp.png');
end




    