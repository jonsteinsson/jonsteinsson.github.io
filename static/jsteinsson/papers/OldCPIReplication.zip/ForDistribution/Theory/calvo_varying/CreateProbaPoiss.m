% Creates a probability distribution for the idiosyncratic shock, 
% under Midrigan's Poisson process
%
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The evolution of log (A_it) is governed by:
% log(A_it) = rho*log(A_it-1) + eps_it , with Prob = pa
%           = log(A_it-1) , with Prob = 1 -pa
% where eps_it ~ N(0,sigma_eps^2), i.i.d. 
%
% What variable varies along what dimension:
% 1st dimension: a_t-1
% 2nd dimension: a_t
%
% So Proba(i,j) = Prob(a_t = k | a_t-1 = j)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)
%
% The three imputs are:
% 1. Autoregressive coefficient for a_t in different regimes
% 2. sigma_eps
% 3. Probability of receiving a shock
% 3. Grid for a
%
% Jon Steinsson and Emi Nakamura, May 2006
% Edited by Daniel Villar, July 2013
%*************************************************************

function Proba = CreateProbaPoiss(rho,sigma_eps,pa,a)

agridsize = size(a,1);

a_old = repmat(rho*a,1,agridsize-1);
sigma_eps_matrix = repmat(sigma_eps,agridsize,agridsize-1);

a_j = (a(1:end-1,1)+a(2:end,1))/2;
a_j_matrix = repmat(a_j',agridsize,1);

a_norm = normcdf(a_j_matrix,a_old,sigma_eps_matrix);

a_norm_up = [a_norm ones(agridsize,1)];
a_norm_dwn = [zeros(agridsize,1) a_norm];

Proba = a_norm_up - a_norm_dwn;

Proba = Proba.*(Proba > 10^(-6));
Proba = Proba./(sum(Proba')'*(ones(1,agridsize)));
Proba = pa*Proba + (1-pa)*eye(agridsize);
