% Creates a probability distribution for the idiosyncratic shock
%
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The evolution of log (A_it) is governed by:
% log(A_it) = rho*log(A_it-1) + eps_it
% where eps_it ~ N(0,sigma_eps^2), i.i.d. 
%
% What variable varies along what dimension:
% 1st dimension: a_t-1
% 2nd dimension: a_t
%
% So Proba(i,j) = Prob(a_t = k | a_t-1 = j)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)
%
% The three imputs are:
% 1. Autoregressive coefficient for a_t in different regimes
% 2. sigma_eps
% 3. Grid for a
%
% Jon Steinsson and Emi Nakamura, May 2006
%*************************************************************

function ProbdS = CreateProbdS(mu,rho,sigma_eps,dS)

gridsize = size(a,1);

dS_old = repmat(mu + rho*dS,1,gridsize-1);
sigma_eps_matrix = repmat(sigma_eps,gridsize,gridsize-1);

dS_j = (dS(1:end-1,1)+dS(2:end,1))/2;
dS_j_matrix = repmat(dS_j',gridsize,1);

dS_norm = normcdf(dS_j_matrix,dS_old,sigma_eps_matrix);

dS_norm_up = [dS_norm ones(agridsize,1)];
dS_norm_dwn = [zeros(gridsize,1) dS_norm];

ProbdS = dS_norm_up - dS_norm_dwn;

ProbdS = ProbdS.*(ProbdS > 10^(-6));
ProbdS = Proba./(sum(ProbdS')'*(ones(1,gridsize)));
