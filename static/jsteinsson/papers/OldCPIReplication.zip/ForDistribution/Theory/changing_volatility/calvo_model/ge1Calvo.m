% One sector general equilibrium Calvo model
% (More precisely, limit of CalvoPlus model with very few high cost price
% changes)
%
% 1. I.i.d. growth in nominal aggregate demand (non-zero mean)
% 2. AR(1)-normal idiosyncratic productivity shocks
% 3. Homoskedastic errors to idiosyncratic shocks
% 4. Cobb-Douglas productions function
% 5. Power utility of consumption and power disutility of labor
% 6. Homogeneous labor market
%
% The state vector is three dimensional. We vectorize it using the
% reshape command. The order of the state variables when they are 
% reshaped is (a, rp, rad)
%
% Jon Steinsson and Emi Nakamura, August 2006
%**************************************************************

clear; close all;
tic

%% Set Parameters
%**************************************************************

theta = 4;              % Elasticity of demand
psi = 0;                % One over the Frisch elasticity of labor supply
gamma = 1;              % coefficient of relative risk aversion
FlexSSL = 1;            % Steady State labor under flexible prices
beta = 0.96^(1/12);     % Discount factor

% Parameters of the process followed by nominal aggregate demand
% log(S_t) - log(S_t-1) = mu + nu_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
mu = 0;
sigma_eta = 0.0037;

% Parameters of the idiosyncratic productivity process (log A_it)
% log(A_it) = rho*log(A_it-1) + eps_it
% where eps_it ~ N(0,sigma_eps^2), i.i.d. 
% The process is truncated at +/- trunc_eps multiples of the unconditional 
% standard deviation of log(A) 
rho = 0.7;
sigma_eps = 0.0425;

% Intermediate inputs share in production
sm = 0.0;

% Menu cost
% K denotes the menu cost in the high menu cost state
% K2 denotes the menu cost in the low menu cost state
K = 10^10;
K2 = 0;
% Notice: In the notation of the paper this is "K/Y_ss"
% while menu cost reported in table 6-9 in the paper is 
% "((theta-1)/theta)*(K/Y_ss)". So the numbers in the tables
% should be multiplied by theta/(theta-1) when plugged in here
% to replicate the results in the paper.

% 1 minus frequency of "free" price changes
alphaCalvo = 1 - 0.1;

% Location of the middle of the rad grid relative to the no-uncertainty 
% steady state value of rad
%rad_shift = -0.02;
%rad_shift = 0.005-2.5*mu;
rad_shift = -0.02;

% Span of rp grid relative to a grid
rp_Infspanup = 50;  % numer of months of inflation on the upside
rp_Infspandw = 150; % numer of months of inflation on the downside
rp_Aspanup = 1.5;
rp_Aspandw = 1.5;

% Number of points on the grid for each of the three state variables
agridsize = 50;
rpgridsize = 440;
radgridsize = 23; %floor(25*rpgridsize/200);
% The following values:
% agridsize = 40 which gives ainc = 0.0143
% rpgridsize = 200 which gives rpinc = 0.0036
% radgridsize = 25.
% yield reliable results for price change stats (freq, size, etc) 
% when the model is calibrated as follow:
% theta=4, psi=0, gamma=1,
% sigma_eta = 0.0037; mu = 0.002;
% rho = 0.7, sigma_eps = 0.0665;
% sm = 0, K = 0.069, K2 = K/40.
% Note: To get reliable result for stdOutput one might need roughly
% rpgridsize = 800 and radgridsize = floor(25*rpgridsize/200)
% radgridsize needs to expand proportionately with rpgridsize
% sm > 0 implies one needs a larger radgridsize

% The slope and level of the initial guess for the function G function
% i.e. the function Gamma in our Multi-Sector Menu Cost paper.
% The initial guess is a step function. "slope" gives the number of grid
% points on the rad grid between steps in this step function. This means
% that the slope is greater for lower values of "slope".
% If levelshift = 0 the Gamma function take a value of zero (in logs) in 
% the middle of the grid. More generally, if levelshift = N the Gamma
% function takes a value N gridpoints above zero in the middle of the grid.
slope = 13; levelshift = 2;
%slope = floor(10*rpgridsize/400); levelshift = floor((12*mu/0.06)*(1+1.25*(rpgridsize/400-1)));

% Maximum number of iterations on G
MaxItOnG = 25;

Ssize = agridsize*rpgridsize*radgridsize;

% Solve for the flexible price steady state 
%****************************************************************

par1 = sm*(theta-1)/(theta-sm*(theta-1));

FlexSSC = FlexSSL*par1^(sm/(1-sm))*(1+par1)^(-1/(1-sm));
FlexSSM = par1*FlexSSC;
FlexSSY = FlexSSC + FlexSSM;

omega = (theta-1)/theta*(1-sm)*(1+par1)*FlexSSL^(-psi-1)*FlexSSC^(1-gamma); % Level parameter on disutility of labor
omega2 = omega*(FlexSSL)^psi; % Marginal disutility of changing prices

K = K*FlexSSY;
K2 = K2*FlexSSY;

FlexSSL = log(FlexSSL);
FlexSSC = log(FlexSSC);
if sm > 0
    FlexSSM = log(FlexSSM);
end
FlexSSY = log(FlexSSY);


% Print Out Parameters
%****************************************************************

fprintf('\n')
fprintf('ge1sc4CalvoPlus2')
fprintf('\n')
fprintf('theta:          %5.5f\n',theta)
fprintf('psi:            %5.5f\n',psi)
fprintf('gamma:          %5.5f\n',gamma)
fprintf('sm:             %5.5f\n',sm)
fprintf('K:              %5.5f\n',K)
fprintf('K2:              %5.6f\n',K2)
fprintf('1-alphaCalvo:   %5.5f\n',1-alphaCalvo)
fprintf('rho:            %5.5f\n',rho)
fprintf('sigma:          %5.5f\n',sigma_eps)
fprintf('FlexSSC:        %5.5f\n',exp(FlexSSC))
fprintf('K/FlexSSY:      %5.5f\n',K/exp(FlexSSY))
fprintf('K2/FlexSSY:      %5.6f\n',K2/exp(FlexSSY))
fprintf('Size of State Space: %10.0f\n\n',Ssize)

% Set grid parameters
%****************************************************************

% if agridsize < 30
%     error('agridsize < 30: Results unreliable!')
% end
% 
trunc_eps = 3.2;
amax = trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
amin = -trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);

ainc = (amax-amin)/(agridsize-1) - mod((amax-amin)/(agridsize-1),10^(-7));
amin = amin - mod(amin,10^(-7));
amax = amin + (agridsize-1)*ainc;

% rp denotes the real price
% np denotes the nominal price
% The rp grid is a grid for the log of the real price
rpmax = rp_Infspanup*mu - amin*rp_Aspanup;
rpmin = -rp_Infspandw*mu - amax*rp_Aspandw;
if rpmax < 0.15
    rpmax = 0.15;
    rpmin = -0.15;
end
rpinc = (rpmax-rpmin)/(rpgridsize-1) - mod((rpmax-rpmin)/(rpgridsize-1),10^(-7));
rpmin = rpmin - mod(rpmin,10^(-7));
rpmax = rpmin + (rpgridsize-1)*rpinc;



fprintf('amax  : %5.6f\n',amax)
fprintf('amin  : %5.6f\n',amin)
fprintf('rpmax : %5.6f\n',rpmax)
fprintf('rpmin : %5.6f\n',rpmin)
fprintf('N years drift : %5.6f\n\n',-rpmin/mu/12)
fprintf('rpinc : %5.6f\n',rpinc)
fprintf('mu    : %5.6f\n\n',mu)
fprintf('mu/rpinc : %5.6f\n\n',mu/rpinc)



if rpinc > 0.0075
    error('rpinc > 0.0075: Results unreliable')
end

radmin = FlexSSC - (radgridsize-1)/2*rpinc + rad_shift;

% Create the real price and idiosyncratic productivity vectors
%**************************************************************

a = amin:ainc:amax; a = a';

rp = zeros(rpgridsize,1);
rp(1) = rpmin;
for ii = 2:rpgridsize
    rp(ii) = rp(ii-1) + rpinc;
end

rad = zeros(radgridsize,1);
rad(1) = radmin;
for ii = 2:radgridsize
    rad(ii) = rad(ii-1) + rpinc;
end

% Create Probability Distribution for the idiosyncratic shock
%**************************************************************
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)

Proba = CreateProba(rho,sigma_eps,a);

%fprintf('Proba(1:8,1:8) ')
%Proba(1:8,1:8)

% Create probability distribution for nominal aggregate demand
%***************************************************************

ProbNgr = CreateProbNgr(mu,sigma_eta,rad);

%fprintf('ProbaNgr(1:8,1:8) ')
%ProbNgr(1:8,1:8)

% Guess a matrix G which gives the log inflation rate given S_t/P_t-1
%**************************************************************

G = zeros(radgridsize,1);
%G = (rp(2)-rp(1))*ones(radgridsize,1);
G(1,1) = -(radgridsize/(2*slope)-mod(radgridsize/(2*slope),1))*(rp(2)-rp(1)) ...
    + levelshift*(rp(2)-rp(1));
for ii = 2:radgridsize
    if mod(ii,slope) == 0
        G(ii,1) = G(ii-1,1) + rp(2) - rp(1);
    else
        G(ii,1) = G(ii-1,1);
    end
end
%figure(99)
%plot(rad,G)

% Calculate the profit function
%**************************************************************

par1 = psi+1;
par2 = gamma;
par3 = exp(FlexSSC)/exp(FlexSSY);
par4 = exp(FlexSSM)/exp(FlexSSY) - sm;
par5 = 1-sm;

a3d = repmat(a,[1 rpgridsize radgridsize]);

rp3d = repmat(rp,[1 agridsize radgridsize]);
rp3d = permute(rp3d, [2 1 3]);

rad3d = repmat(rad,[1 agridsize rpgridsize]);
rad3d = permute(rad3d,[2 3 1]);

if sm > 0
    l3d = FlexSSL + (par3+par2*par4)/(par5-par1*par4)*(rad3d-FlexSSC);
    m3d = FlexSSM + par1*(l3d - FlexSSL) + par2*(rad3d-FlexSSC);
else
    l3d = FlexSSL + (rad3d-FlexSSC);
    m3d = 0*rad3d;
end

rPi3d = exp(rad3d + m3d).*exp(rp3d).^(1-theta) ...
  - (1-sm)^(sm-1)*sm^(-sm)*omega^(1-sm)*exp(l3d).^(psi*(1-sm))...
  .*exp(rad3d).^(gamma*(1-sm)).*exp(-a3d).*exp(rad3d+m3d).*exp(rp3d).^(-theta);


% Partial equilibrium profit function !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
% rPi3d = (exp(rp3d).^(-theta+1) - exp(rp3d).^(-theta).*((theta-1)/theta).*exp(-a3d));


rPi = reshape(rPi3d,[Ssize 1]);

menucost3d = omega2*K*exp(rad3d).^gamma;
menucost = reshape(menucost3d,[Ssize 1]);

menucost3d = omega2*K2*exp(rad3d).^gamma;
menucost2 = reshape(menucost3d,[Ssize 1]);

clear a3d rp3d rad3d rPi3d menucost3d l3d m3d

figure(12)
rPi_plot = reshape(rPi,[agridsize rpgridsize radgridsize]);
rPi_plot = squeeze(rPi_plot(:,:,1));
surf(a,rp,rPi_plot')
title('Profit Function (GE)')
xlabel('a')
ylabel('rp')

figure(13)
rPi_plot2 = reshape(rPi,[agridsize rpgridsize radgridsize]);
p1 = plot(rp(floor(rpgridsize/1.7):end),rPi_plot2(floor(agridsize/2),floor(rpgridsize/1.7):end,max(floor(radgridsize/2)-2,1))', ...
          rp(floor(rpgridsize/1.7):end),rPi_plot2(floor(agridsize/2),floor(rpgridsize/1.7):end,max(floor(radgridsize/2),1))', ...
          rp(floor(rpgridsize/1.7):end),rPi_plot2(floor(agridsize/2),floor(rpgridsize/1.7):end,max(floor(radgridsize/2)+2,1))', ...
          rp(floor(rpgridsize/1.7):end),rPi_plot2(floor(agridsize/2),floor(rpgridsize/1.7):end,max(floor(radgridsize/2)+4,1))');
title('Profit Function (GE)')


% Calculate the ratio of marginal utility
%**************************************************************
% The (i,j)th element of RMU is the ratio of marginal utility in 
% state j of period t+1 to the marginal utility in state i of
% period t.

RMU = ((1./exp(rad))*(exp(rad)')).^(-gamma);
%RMU = ((1./exp(rad))*(exp(rad)')).^(-gamma).^0; % Use to "turn of RMU !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

% Initialize ErV matrix (Expected Value next period)
%**************************************************************

ErV = ones(Ssize, 1)*max(0,mean(rPi)/(1-beta));
rPi3d = reshape(rPi,[agridsize rpgridsize radgridsize]);
tolV = 0.001*rPi3d(floor(agridsize/2),floor(rpgridsize/2),max(floor(radgridsize/2),1))/(1-beta);
tolV = max([tolV 0.001]);
clear rPi3d

fprintf('tolV:     %10.6f\n',tolV)
fprintf('min start ErV: %10.2f\n',min(ErV))
fprintf('max start ErV: %10.2f\n',max(ErV))

% Initialize stationary distribution Q
%**************************************************************

Qinit = ones(Ssize,1)/Ssize;
tolQ = Qinit(1)/150;

% Solve for the Equilibrium
%**************************************************************

[G,rV,F,F2,Q] = EqSolverGE1CalvoPlus(rPi,menucost,menucost2,alphaCalvo,...
    RMU,beta,theta,a,rp,rad,Proba,ProbNgr,ErV,Qinit,G,tolV,tolQ,MaxItOnG,1);

GError = CalcGErrorCalvoPlus(G,F,F2,Q,a,rp,rad,alphaCalvo,theta,Proba,ProbNgr);

PCStats = RigidityStatsCalvoPlus(Q,F,F2,alphaCalvo,a,rp,rad,theta,FlexSSC,K,K2);

fprintf('\n')
fprintf('ge1GECalvoPlus')
fprintf('\n')
fprintf('theta:          %5.5f\n',theta)
fprintf('psi:            %5.5f\n',psi)
fprintf('gamma:          %5.5f\n',gamma)
fprintf('sm:             %5.5f\n',sm)
fprintf('K:              %5.5f\n',K)
fprintf('K2:              %5.6f\n',K2)
fprintf('1-alphaCalvo:   %5.5f\n',1-alphaCalvo)
fprintf('rho:            %5.5f\n',rho)
fprintf('sigma:          %5.5f\n',sigma_eps)
fprintf('FlexSSC:        %5.5f\n',exp(FlexSSC))
fprintf('K/FlexSSY:      %5.5f\n',K/exp(FlexSSY))
fprintf('K2/FlexSSY:      %5.6f\n\n',K2/exp(FlexSSY))
fprintf('Size of State Space: %10.0f\n\n',Ssize)
%fprintf('radinc: %10.5f\n\n',rad(2)-rad(1))
fprintf('                           highcost lowcost |  average\n')
fprintf('Frequency of Price Change:   %5.3f   %5.3f  |  %5.3f\n',...
    PCStats.freq_mc,PCStats.freq_mc2,PCStats.freq)
fprintf('Frac Up:                     %5.3f   %5.3f  |  %5.3f\n',...
    PCStats.fracup_mc,PCStats.fracup_mc2,PCStats.fracup)
fprintf('Size of Price Changes:       %5.3f   %5.3f  |  %5.3f\n',...
    PCStats.abssizepc_mc,PCStats.abssizepc_mc2,PCStats.abssizepc)
fprintf('Size of Price Increases:     %5.3f   %5.3f  |  %5.3f\n',...
    PCStats.sizeup_mc,PCStats.sizeup_mc2,PCStats.sizeup)
fprintf('Size of Price Decreases:     %5.3f   %5.3f  |  %5.3f\n',...
    PCStats.sizedw_mc,PCStats.sizedw_mc2,PCStats.sizedw)
fprintf('Fraction of Price Changes:   %5.3f   %5.3f  |  %5.3f\n',...
    alphaCalvo*PCStats.freq_mc/PCStats.freq,(1-alphaCalvo)*PCStats.freq_mc2/PCStats.freq,100)
fprintf('Av. Relative Price:          %5.3f   %5.3f  |  %5.3f\n',...
    PCStats.meanp_mc,PCStats.meanp_mc2,PCStats.meanp)
fprintf('Labor Productivity:          %5.3f   %5.3f  |  %5.3f\n',...
    PCStats.lprod_mc,PCStats.lprod_mc2,PCStats.lprod)
fprintf('Labor Productivity (2nd):    %5.3f   %5.3f  |  %5.3f\n',...
    PCStats.lprod2nd_mc,PCStats.lprod2nd_mc2,PCStats.lprod2nd)
fprintf('Standard Deviation of Output:       %5.5f\n',...
    PCStats.stdOutput)
fprintf('Average of Output:                  %5.5f\n',...
    PCStats.meanOutput)
fprintf('Labor Prod. Flex:                   %5.5f\n',...
    PCStats.lprodFlex)
fprintf('\n')

% Save Model Input and Output
%**************************************************************

% Inputs
GE1ModelCalvoPlus.a = a;
GE1ModelCalvoPlus.rp = rp;
GE1ModelCalvoPlus.rad = rad;
GE1ModelCalvoPlus.K = K;
GE1ModelCalvoPlus.K2 = K2;
GE1ModelCalvoPlus.alphaCalvo = alphaCalvo;
GE1ModelCalvoPlus.beta = beta;
GE1ModelCalvoPlus.theta = theta;
GE1ModelCalvoPlus.psi = psi;
GE1ModelCalvoPlus.sm = sm;
GE1ModelCalvoPlus.gamma = gamma;
GE1ModelCalvoPlus.omega = omega;
GE1ModelCalvoPlus.omega2 = omega2;
GE1ModelCalvoPlus.rho = rho;
GE1ModelCalvoPlus.sigma_eps = sigma_eps;
GE1ModelCalvoPlus.mu = mu;
GE1ModelCalvoPlus.sigma_eta = sigma_eta;

% Outputs
GE1ModelCalvoPlus.G = G;
GE1ModelCalvoPlus.rV = rV;
GE1ModelCalvoPlus.F = F;
GE1ModelCalvoPlus.F2 = F2;
GE1ModelCalvoPlus.Q = Q;
GE1ModelCalvoPlus.GError = GError;
GE1ModelCalvoPlus.freq = PCStats.freq;
GE1ModelCalvoPlus.fracup = PCStats.fracup;
GE1ModelCalvoPlus.abssizepc = PCStats.abssizepc;
GE1ModelCalvoPlus.sizeup = PCStats.sizeup;
GE1ModelCalvoPlus.sizedw = PCStats.sizedw;
GE1ModelCalvoPlus.stdOutput = PCStats.stdOutput;

save('Output/GE1ModelCalvoPlus','GE1ModelCalvoPlus')

figure(14)
Q = reshape(Q,[agridsize rpgridsize radgridsize]);
% sum(sum(Q))
p1 = surf(a,rp,Q(:,:,max(floor(radgridsize/2),1))');
% p1 = surf(a,rp,Q(:,:,5)');

% figure(15)
% F = reshape(F,[agridsize rpgridsize radgridsize]);
% p1 = surf(a,rp,F(:,:,max(floor(radgridsize/2),1))');
% title('Policy Function 1 (GE)')
% 
% figure(16)
% F2 = reshape(F2,[agridsize rpgridsize radgridsize]);
% p1 = surf(1./exp(a),exp(rp),exp(F2(:,:,max(floor(radgridsize/2),1)))');
% title('Policy Function 2 (GE)')
% 
figure(17)
rV = reshape(rV,[agridsize rpgridsize radgridsize]);
p1 = surf(a,rp,rV(:,:,max(floor(radgridsize/2),1))');
title('Value Function (GE)')

figure(18)
rV = reshape(rV,[agridsize rpgridsize radgridsize]);
p1 = plot(rp(floor(rpgridsize/1.5):end),rV(floor(agridsize/2),floor(rpgridsize/1.5):end,max(floor(radgridsize/2),1))');
title('Value Function (GE)')

figure(28)
rV = reshape(rV,[agridsize rpgridsize radgridsize]);
yy = rV(floor(agridsize/2),floor(rpgridsize/2),:);
yy = reshape(yy,[radgridsize 1]);
p1 = plot(rad,yy);
title('Value Function (GE)')

F2 = reshape(F2,[agridsize rpgridsize radgridsize]);
figure(19)
p1 = plot(a,F2(:,floor(rpgridsize/2),max(floor((radgridsize+1)/2),1)),a,F2(:,floor(rpgridsize/2),max(floor((radgridsize+1)/2)+11,1)));
title('F2 (GE)')
% figure(19)
% p1 = plot(a,F2(:,floor(rpgridsize/2),max(floor((radgridsize+1)/2),1)));
% title('F2 (GE)')

% [a(1:10) F2(1:10,floor(rpgridsize/2),max(floor((radgridsize+1)/2),1)) ...
%     F2(1:10,floor(rpgridsize/2),max(floor((radgridsize+1)/2)+3,1)) ...
%     (F2(1:10,floor(rpgridsize/2),max(floor((radgridsize+1)/2),1)) - ...
%     F2(1:10,floor(rpgridsize/2),max(floor((radgridsize+1)/2)+3,1))) ]


toc

%SimboG1S