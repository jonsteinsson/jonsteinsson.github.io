% One sector general equilibrium Calvo model
% (More precisely, limit of CalvoPlus model with very few high cost price
% changes)
%
% 1. I.i.d. growth in nominal aggregate demand (non-zero mean)
% 2. AR(1)-normal idiosyncratic productivity shocks
% 3. Homoskedastic errors to idiosyncratic shocks
% 4. Cobb-Douglas productions function
% 5. Power utility of consumption and power disutility of labor
% 6. Homogeneous labor market
%
% The state vector is three dimensional. We vectorize it using the
% reshape command. The order of the state variables when they are 
% reshaped is (a, rp, rad)
%
% Calculates various statistics for different levels of average inflation
% by solving the model many times for different values of average growth in
% nominal aggregate demand.
%
% Emi Nakamura, Jon Steinsson, Patrick Sun, Daniel Villar 
% July 2015 (based on code written for Nakamura and Steinsson (QJE 2010)
%**************************************************************

clear; close all;
tic

%% Set Parameters
%**************************************************************

theta = 4;            % Elasticity of demand
psi = 0;              % One over the Frisch elasticity of labor supply
gamma = 1;            % Coefficient of relative risk aversion
FlexSSL = (theta-1)/theta; % Steady State labor under flexible prices
beta = 0.96^(1/12);   % Discount factor

% Parameters of the process followed by nominal aggregate demand
% log(S_t) - log(S_t-1) = mu + nu_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
sigma_eta = 0.0039 ;% sigma_eta = 0.0037;
% 
% mu_vec = (0.00/12):(0.0025/12):(0.04/12);
% mu_vec = [mu_vec (0.045/12):(0.005/12):(0.08/12)];
% mu_vec = [mu_vec (0.12/12):(0.01/12):(0.16/12)];

mu_vec =0;

muLength = length(mu_vec);

% Parameters of the idiosyncratic productivity process (log A_it)
% log(A_it) = rho*log(A_it-1) + eps_it
% where eps_it ~ N(0,sigma_eps^2), i.i.d.
% The process is truncated at +/- trunc_eps multiples of the unconditional
% standard deviation of log(A)
rho = 0.7;
sigma_eps = 0.5*0.0365 ;% sigma_eps = 0.0425;

sm = 0.0;  % Intermediate input share in the production function

% Menu cost
% K denotes the menu cost in the high menu cost state
% K2 denotes the menu cost in the low menu cost state
K = 10^10;
K2 = 0;
% Notice: In the notation of the paper this is "K/Y_ss"

% 1 minus frequency of "free" price changes



alphaCalvo = 1 - 0.101;

% Maximum number of iterations on G
MaxItOnG = 100;

% Figure Format
PRESENTATION = true;

if PRESENTATION
    Format.FontSize = 16;
    Format.colors = {'k','r','g'};
    Format.widths = {2,2,2};
    Format.styles = {'-','-','-'};
    Format.figsize = [460 200 700 525];
else
    Format.colors = {[0 0 0], [0 0 0], [0 0 0]};
    Format.styles = {'-','--','-.'};
    Format.widths = {1,1,1};
    Format.figsize = [460 200 560 420];
    Format.FontSize = 12;
end

%% Print Out Parameters
%****************************************************************

fprintf('\n')
fprintf('theta:     %5.5f\n',theta)
fprintf('psi:       %5.5f\n',psi)
fprintf('gamma:     %5.5f\n',gamma)
fprintf('sm:        %5.5f\n',sm)
fprintf('K:         %5.5f\n',K)
fprintf('K2:        %5.5f\n',K2)
fprintf('alphaCalvo:%5.5f\n',alphaCalvo)
fprintf('rho:       %5.5f\n',rho)
fprintf('sigma_eps: %5.5f\n',sigma_eps)
fprintf('sigma_eta: %5.5f\n',sigma_eta)
fprintf('\n')

%% Loop that solves model for each values of mu
%**************************************************************************

for mm = 1:muLength
    
    % Inflation rate
    mu = mu_vec(mm);
    fprintf('**************************************\n')
    fprintf('Annual average inflation:     %5.2f\n\n',mu*12*100)
    
    % Location of the middle of the rad grid relative to the no-uncertainty
    % steady state value of rad
    rad_shift = 0.005 - 5*mu/3 - 300*mu^2;
    
    % Number of points on the grid for each of the three state variables
    agridsize = 40;
    rpgridsize = max(500,floor(500*(1+0.5*(mu/(0.02/12)-1))));

    radgridsize = max(25,floor(25*rpgridsize/200/(1+0.3*(mu/(0.02/12)-1))));
%     agridsize = 40;
%     rpgridsize = max(300,floor(200*(1+0.5*(mu/(0.02/12)-1))));
%     radgridsize = max(18,floor(18*rpgridsize/200/(1+0.2*(mu/(0.02/12)-1))));
    
    Ssize = agridsize*rpgridsize*radgridsize;
    
    fprintf('agridsize:           %5.0f\n',agridsize)
    fprintf('rpgridsize:          %5.0f\n',rpgridsize)
    fprintf('radgridsize:         %5.0f\n',radgridsize)
    fprintf('Size of State Space: %10.0f\n\n',Ssize)
    
    % Span of rp grid relative to a grid
    rp_Infspanup = 50;  % numer of months of inflation on the upside
    rp_Infspandw = 150; % numer of months of inflation on the downside
    rp_Aspanup = 1.5;
    rp_Aspandw = 1.5;
    
    
    % Span of rp grid relative to a grid
    if mu >= 0
        rp_spanup = 1.5;
        rp_spandw = 3.5;
    else
        rp_spanup = 3.5;
        rp_spandw = 1.5;
    end
    
    % Solve for the flexible price steady state
    %****************************************************************
    
    par1 = sm*(theta-1)/(theta-sm*(theta-1));
    
    FlexSSC = FlexSSL*par1^(sm/(1-sm))*(1+par1)^(-1/(1-sm));
    FlexSSM = par1*FlexSSC;
    FlexSSY = FlexSSC + FlexSSM;
    
    omega = (theta-1)/theta*(1-sm)*(1+par1)*FlexSSL^(-psi-1)*FlexSSC^(1-gamma); % Level parameter on disutility of labor
    omega2 = omega*(FlexSSL)^psi; % Marginal disutility of changing prices    
    
    % Set grid parameters
    %****************************************************************
    
    if agridsize < 30
        error('agridsize < 30: Results unreliable!')
    end
    
    trunc_eps = 3.2;
    amax = trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
    amin = -trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
    
    ainc = (amax-amin)/(agridsize-1) - mod((amax-amin)/(agridsize-1),10^(-7));
    amin = amin - mod(amin,10^(-7));
    amax = amin + (agridsize-1)*ainc;
    
    % rp denotes the real price
    % np denotes the nominal price
    % The rp grid is a grid for the log of the real price
    rpmax = rp_Infspanup*mu - amin*rp_Aspanup;
    rpmin = -rp_Infspandw*mu - amax*rp_Aspandw;
    if rpmax < 0.15
        rpmax = 0.15;
        rpmin = -0.15;
    end
    rpinc = (rpmax-rpmin)/(rpgridsize-1) - mod((rpmax-rpmin)/(rpgridsize-1),10^(-7));
    rpmin = rpmin - mod(rpmin,10^(-7));
    rpmax = rpmin + (rpgridsize-1)*rpinc;
    
    if rpinc > 0.0075
        error('rpinc > 0.0075: Results unreliable')
    end
    
    radmin = log(FlexSSC) - radgridsize/2*rpinc + rad_shift;

    fprintf('ainc  : %5.4f\n',ainc)
    fprintf('amax  : %5.6f\n',amax)
    fprintf('amin  : %5.6f\n\n',amin)
    fprintf('rpmax : %5.6f\n',rpmax)
    fprintf('rpmin : %5.6f\n',rpmin)
    fprintf('N years drift : %5.6f\n\n',-rpmin/mu/12)
    fprintf('rpinc : %5.6f\n',rpinc)
    fprintf('mu    : %5.6f\n',mu)
    fprintf('mu/rpinc : %5.6f\n\n',mu/rpinc)
    
    % Create the real price and idiosyncratic productivity vectors
    %**************************************************************
    
    a = amin:ainc:amax; a = a';
    
    rp = zeros(rpgridsize,1);
    rp(1) = rpmin;
    for ii = 2:rpgridsize
        rp(ii) = rp(ii-1) + rpinc;
    end
    
    rad = zeros(radgridsize,1);
    rad(1) = radmin;
    for ii = 2:radgridsize
        rad(ii) = rad(ii-1) + rpinc;
    end
    
    % The slope and level of the initial guess for the function G function
    % i.e. the function Gamma in our Multi-Sector Menu Cost paper.
    % The initial guess is a step function. "slope" gives the number of grid
    % points on the rad grid between steps in this step function. This means
    % that the slope is greater for lower values of "slope".
    % If levelshift = 0 the Gamma function take a value of zero (in logs) in
    % the middle of the grid. More generally, if levelshift = N the Gamma
    % function takes a value N gridpoints above zero in the middle of the grid.
    % slope = 10; levelshift = 1+floor(12*abs(mu)/0.06);
    slope = floor(6*0.0024/rpinc); 
    levelshift = floor(12*mu/0.04);
    
    % Create Probability Distribution for the idiosyncratic shock
    %**************************************************************
    % Proba is a matrix that gives transition probabilities of going
    % from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
    %
    % The procedure of Tauchen (1986) is used to approximate the
    % AR(1) process for log(A_it)
    
    Proba = CreateProba(rho,sigma_eps,a);
    
    %fprintf('Proba(1:8,1:8) ')
    %Proba(1:8,1:8)
    
    % Create probability distribution for nominal aggregate demand
    %***************************************************************
    
    ProbNgr = CreateProbNgr(mu,sigma_eta,rad);
    
    %fprintf('ProbaNgr(1:8,1:8) ')
    %ProbNgr(1:8,1:8)
    
    % Guess a matrix G which gives the log inflation rate given S_t/P_t-1
    %**************************************************************
    
    G = zeros(radgridsize,1);
    %G = (rp(2)-rp(1))*ones(radgridsize,1);
    G(1,1) = -(radgridsize/(2*slope)-mod(radgridsize/(2*slope),1))*(rp(2)-rp(1)) ...
        + levelshift*(rp(2)-rp(1));
    for ii = 2:radgridsize
        if mod(ii,slope) == 0
            G(ii,1) = G(ii-1,1) + rp(2) - rp(1);
        else
            G(ii,1) = G(ii-1,1);
        end
    end
    %figure(99)
    %plot(rad,G)
    
    % Calculate the profit function
    %**************************************************************
    
    par1 = psi+1;
    par2 = gamma;
    par3 = FlexSSC/FlexSSY;
    par4 = FlexSSM/FlexSSY - sm;
    par5 = 1-sm;
    
    a3d = repmat(a,[1 rpgridsize radgridsize]);
    
    rp3d = repmat(rp,[1 agridsize radgridsize]);
    rp3d = permute(rp3d, [2 1 3]);
    
    rad3d = repmat(rad,[1 agridsize rpgridsize]);
    rad3d = permute(rad3d,[2 3 1]);
    
    if sm > 0
        l3d = log(FlexSSL) + (par3+par2*par4)/(par5-par1*par4)*(rad3d-log(FlexSSC));
        m3d = log(FlexSSM) + par1*(l3d - log(FlexSSL)) + par2*(rad3d-log(FlexSSC));
    else
        l3d = log(FlexSSL) + (rad3d-log(FlexSSC));
        m3d = 0*rad3d;
    end
    
    rPi3d = exp(rad3d + m3d).*exp(rp3d).^(1-theta) ...
        - (1-sm)^(sm-1)*sm^(-sm)*omega^(1-sm)*exp(l3d).^(psi*(1-sm)) ...
        .*exp(rad3d).^(gamma*(1-sm)).*exp(-a3d).*exp(rad3d+m3d).*exp(rp3d).^(-theta);
    rPi = reshape(rPi3d,[Ssize 1]);
    
    menucost3d = omega2*K*FlexSSY*exp(rad3d).^gamma;
    menucost = reshape(menucost3d,[Ssize 1]);
    
    menucost3d = omega2*K2*FlexSSY*exp(rad3d).^gamma;
    menucost2 = reshape(menucost3d,[Ssize 1]);
    
    clear a3d rp3d rad3d rPi3d menucost3d l3d m3d
    
    % figure(4)
    % rPi_plot = reshape(rPi,[agridsize rpgridsize radgridsize]);
    % rPi_plot = squeeze(rPi_plot(:,:,1));
    % surf(a,rp,rPi_plot')
    % title('Profit Function')
    % xlabel('a')
    % ylabel('rp')
    
    % Calculate the ratio of marginal utility
    %**************************************************************
    % The (i,j)th element of RMU is the ratio of marginal utility in
    % state j of period t+1 to the marginal utility in state i of
    % period t.
    
    RMU = ((1./exp(rad))*(exp(rad)')).^(-gamma);
    
    % Initialize ErV matrix (Expected Value next period)
    %**************************************************************
    
    ErV = 1.5*ones(Ssize, 1)*max(0,mean(rPi)/(1-beta));
    rPi3d = reshape(rPi,[agridsize rpgridsize radgridsize]);
    tolV = 0.001*rPi3d(floor(agridsize/2),floor(rpgridsize/2),floor(radgridsize/2))/(1-beta);
    tolV = max([tolV 0.001]);
    clear rPi3d
    
    fprintf('tolV:     %10.6f\n',tolV)
    
    % Initialize stationary distribution Q
    %**************************************************************
    
    Qinit = ones(Ssize,1)/Ssize;
    tolQ = Qinit(1)/150;
    
    % Solve for the Equilibrium
    %**************************************************************
    
    [G,rV,F,F2,Q,hitMaxItOnG] = EqSolverGE1CalvoPlus(rPi,menucost,menucost2,alphaCalvo,...
        RMU,beta,theta,a,rp,rad,Proba,ProbNgr,ErV,Qinit,G,tolV,tolQ,MaxItOnG,1);
    
    GError = CalcGErrorCalvoPlus(G,F,F2,Q,a,rp,rad,alphaCalvo,theta,Proba,ProbNgr);
    
    PCStats = RigidityStatsCalvoPlus(Q,F,F2,alphaCalvo,a,rp,rad,theta,log(FlexSSC),menucost,menucost2);
    
    StatsCalvo.theta                = theta;
    StatsCalvo.agridsize(mm,1)      = agridsize;
    StatsCalvo.rpgridsize(mm,1)     = rpgridsize;
    StatsCalvo.radgridsize(mm,1)    = radgridsize;
    StatsCalvo.hitMaxItOnG(mm,1)    = hitMaxItOnG;
    
    StatsCalvo.infl(mm,1)           = mu*12;
    StatsCalvo.freq(mm,1)           = PCStats.freq;
    StatsCalvo.frequp(mm,1)         = PCStats.frequp;
    StatsCalvo.freqdw(mm,1)         = PCStats.freqdw;
    StatsCalvo.fracup(mm,1)         = PCStats.fracup;
    StatsCalvo.fracfree(mm,1)       = PCStats.fracfree;        % Fraction of price changes in low menu cost state
    StatsCalvo.abssizepc(mm,1)      = PCStats.abssizepc;
    StatsCalvo.sizeup(mm,1)         = PCStats.sizeup;
    StatsCalvo.sizedw(mm,1)         = PCStats.sizedw;
    StatsCalvo.sizepcnotabs(mm,1)   = PCStats.sizepcnotabs;    % size as opposed to absolute size
    StatsCalvo.sizepcsquared(mm,1)  = PCStats.sizepcsquared;
    StatsCalvo.sizepccubed(mm,1)    = PCStats.sizepccubed;
    
    StatsCalvo.meanRprice(mm,1)     = PCStats.meanRprice; 
    StatsCalvo.ineffpdisp(mm,1)     = PCStats.ineffpdisp;
    StatsCalvo.ineffpdisp2nd(mm,1)  = PCStats.ineffpdisp2nd;
    StatsCalvo.lprod(mm,1)          = PCStats.lprod;
    StatsCalvo.lprod2nd(mm,1)       = PCStats.lprod2nd;
    StatsCalvo.lprodFlex(mm,1)      = PCStats.lprodFlex;
    StatsCalvo.lprodFlex2(mm,1)     = PCStats.lprodFlex2;
    StatsCalvo.stdLogOutput(mm,1)   = PCStats.stdLogOutput;
    StatsCalvo.meanLogOutput(mm,1)  = PCStats.meanLogOutput;
    StatsCalvo.FlexLogOutput(mm,1)  = PCStats.FlexLogOutput;
    StatsCalvo.FlexLabor(mm,1)      = PCStats.FlexLabor;
    StatsCalvo.prodwedge(mm,1)      = PCStats.prodwedge;
    StatsCalvo.meanp(mm,1)          = PCStats.meanp;
    StatsCalvo.meanL(mm,1)          = PCStats.meanL;
    StatsCalvo.pccost(mm,1)         = PCStats.pccost;
    StatsCalvo.avmarkup(mm,1)       = PCStats.avmarkup;
    StatsCalvo.welfareLossIgnoreUncert(mm,1) = PCStats.welfareLossIgnoreUncert;

%     Stats.welfareLossUncert(mm,1) = PCStats.welfareLossUncert ;
end
display( StatsCalvo.freq)
display( StatsCalvo.abssizepc)