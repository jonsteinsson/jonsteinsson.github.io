% Iterates on G
%
% Jon Steinsson and Emi Nakamura, July 2006
%*************************************************

function [G,rV,F,F_c,Q,hitMaxItOnG] = EqSolverGE1Basic(rPi,menucost,RMU,beta,theta,a,rp,rad,...
    Proba,ProbNgr,rV,Q,G,tolV,tolQ,MaxItOnG,yesprint)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

rpinc = rp(2)-rp(1);

supDifG = 2*rpinc;
GMove = zeros(radgridsize,1);
i = 1;
while (supDifG >= 0.99*rpinc & i <= MaxItOnG)
    fprintf('######## %5.3f #########\n\n',i)
%    figure(65)
%    plot(rad,G)

    
    G_old = G;
    
    % Bellman function iteration
    [rV,F,F_c] = VFIterationGEBasic(rPi,menucost,rV,RMU,beta,a,rp,rad,...
        Proba,ProbNgr,G,tolV,yesprint,yesprint);
    
    % Calculate the stationary distribution
    Q = StaDistGEBasic(Q,Proba,ProbNgr,F,G,a,rp,rad,tolQ,yesprint);
    
    totWeight = sum(reshape(Q,[agridsize*rpgridsize radgridsize]))';
    
    % Update G
    [G W_SPold supDifG G_resid GMove] = UpdateG(Q,F,G,a,rp,rad,...
        theta,Proba,ProbNgr,GMove);
    
    if yesprint == 1
        [supDifG rpinc]
        [rad G (G-G_old) G_resid totWeight W_SPold]
        fprintf('      rad       G     (G-G_old)    G_resid   totWeight    W_SPold\n')
    end
    
    i = i + 1;
end

if i > MaxItOnG 
    hitMaxItOnG = 1;
else
    hitMaxItOnG = 0;
end

