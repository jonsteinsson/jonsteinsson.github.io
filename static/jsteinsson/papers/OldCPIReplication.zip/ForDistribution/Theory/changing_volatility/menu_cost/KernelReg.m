function [InfExt,StatsSmooth] = KernelReg(Stats,h,finalinf)

StatsSmooth.ineffpdisp = ksr(Stats.infl,Stats.ineffpdisp,h);
temp = find(ismember(StatsSmooth.ineffpdisp.x,Stats.infl)==1) ;
[StatsSmooth.ineffpdisp.x,Index] = unique(StatsSmooth.ineffpdisp.x(temp)) ;
StatsSmooth.ineffpdisp.f = StatsSmooth.ineffpdisp.f(temp) ;
StatsSmooth.ineffpdisp.f = StatsSmooth.ineffpdisp.f(Index) ;
slope = (StatsSmooth.ineffpdisp.f(end) - StatsSmooth.ineffpdisp.f(end-1))/(StatsSmooth.ineffpdisp.x(end) - StatsSmooth.ineffpdisp.x(end-1)) ;
StatsSmooth.ineffpdisp.f(length(StatsSmooth.ineffpdisp.f)+1) = StatsSmooth.ineffpdisp.f(end) + (finalinf - StatsSmooth.ineffpdisp.x(end))*slope ;
InfExt = [StatsSmooth.ineffpdisp.x finalinf] ;
StatsSmooth.ineffpdisp = StatsSmooth.ineffpdisp.f ;


StatsSmooth.lprod = ksr(Stats.infl,Stats.lprod,h);
temp = find(ismember(StatsSmooth.lprod.x,Stats.infl)==1) ;
[StatsSmooth.lprod.x,Index] = unique(StatsSmooth.lprod.x(temp)) ;
StatsSmooth.lprod.f = StatsSmooth.lprod.f(temp) ;
StatsSmooth.lprod.f = StatsSmooth.lprod.f(Index) ;
slope = (StatsSmooth.lprod.f(end) - StatsSmooth.lprod.f(end-1))/(StatsSmooth.lprod.x(end) - StatsSmooth.lprod.x(end-1)) ;
StatsSmooth.lprod.f(length(StatsSmooth.lprod.f)+1) = StatsSmooth.lprod.f(end) + (finalinf - StatsSmooth.lprod.x(end))*slope ;
StatsSmooth.lprod.x = [StatsSmooth.lprod.x finalinf] ;
StatsSmooth.lprod = StatsSmooth.lprod.f ;

StatsSmooth.lprod2nd = ksr(Stats.infl,Stats.lprod2nd,h);
temp = find(ismember(StatsSmooth.lprod2nd.x,Stats.infl)==1) ;
[StatsSmooth.lprod2nd.x,Index] = unique(StatsSmooth.lprod2nd.x(temp)) ;
StatsSmooth.lprod2nd.f = StatsSmooth.lprod2nd.f(temp) ;
StatsSmooth.lprod2nd.f = StatsSmooth.lprod2nd.f(Index) ;
slope = (StatsSmooth.lprod2nd.f(end) - StatsSmooth.lprod2nd.f(end-1))/(StatsSmooth.lprod2nd.x(end) - StatsSmooth.lprod2nd.x(end-1)) ;
StatsSmooth.lprod2nd.f(length(StatsSmooth.lprod2nd.f)+1) = StatsSmooth.lprod2nd.f(end) + (finalinf - StatsSmooth.lprod2nd.x(end))*slope ;
StatsSmooth.lprod2nd.x = [StatsSmooth.lprod2nd.x finalinf] ;
StatsSmooth.lprod2nd = StatsSmooth.lprod2nd.f ;


StatsSmooth.lprodFlex = ksr(Stats.infl,Stats.lprodFlex,h);
temp = find(ismember(StatsSmooth.lprodFlex.x,Stats.infl)==1) ;
[StatsSmooth.lprodFlex.x,Index] = unique(StatsSmooth.lprodFlex.x(temp)) ;
StatsSmooth.lprodFlex.f = StatsSmooth.lprodFlex.f(temp) ;
StatsSmooth.lprodFlex.f = StatsSmooth.lprodFlex.f(Index) ;
slope = (StatsSmooth.lprodFlex.f(end) - StatsSmooth.lprodFlex.f(end-1))/(StatsSmooth.lprodFlex.x(end) - StatsSmooth.lprodFlex.x(end-1)) ;
StatsSmooth.lprodFlex.f(length(StatsSmooth.lprodFlex.f)+1) = StatsSmooth.lprodFlex.f(end) + (finalinf - StatsSmooth.lprodFlex.x(end))*slope ;
StatsSmooth.lprodFlex.x = [StatsSmooth.lprodFlex.x finalinf] ;
StatsSmooth.lprodFlex = StatsSmooth.lprodFlex.f ;

StatsSmooth.stdLogOutput = ksr(Stats.infl,Stats.stdLogOutput,h);
temp = find(ismember(StatsSmooth.stdLogOutput.x,Stats.infl)==1) ;
[StatsSmooth.stdLogOutput.x,Index] = unique(StatsSmooth.stdLogOutput.x(temp)) ;
StatsSmooth.stdLogOutput.f = StatsSmooth.stdLogOutput.f(temp) ;
StatsSmooth.stdLogOutput.f = StatsSmooth.stdLogOutput.f(Index) ;
slope = (StatsSmooth.stdLogOutput.f(end) - StatsSmooth.stdLogOutput.f(end-1))/(StatsSmooth.stdLogOutput.x(end) - StatsSmooth.stdLogOutput.x(end-1)) ;
StatsSmooth.stdLogOutput.f(length(StatsSmooth.stdLogOutput.f)+1) = StatsSmooth.stdLogOutput.f(end) + (finalinf - StatsSmooth.stdLogOutput.x(end))*slope ;
StatsSmooth.stdLogOutput.x = [StatsSmooth.stdLogOutput.x finalinf] ;
StatsSmooth.stdLogOutput = StatsSmooth.stdLogOutput.f ;


StatsSmooth.meanLogOutput = ksr(Stats.infl,Stats.meanLogOutput,h);
temp = find(ismember(StatsSmooth.meanLogOutput.x,Stats.infl)==1) ;
[StatsSmooth.meanLogOutput.x,Index] = unique(StatsSmooth.meanLogOutput.x(temp)) ;
StatsSmooth.meanLogOutput.f = StatsSmooth.meanLogOutput.f(temp) ;
StatsSmooth.meanLogOutput.f = StatsSmooth.meanLogOutput.f(Index) ;
slope = (StatsSmooth.meanLogOutput.f(end) - StatsSmooth.meanLogOutput.f(end-1))/(StatsSmooth.meanLogOutput.x(end) - StatsSmooth.meanLogOutput.x(end-1)) ;
StatsSmooth.meanLogOutput.f(length(StatsSmooth.meanLogOutput.f)+1) = StatsSmooth.meanLogOutput.f(end) + (finalinf - StatsSmooth.meanLogOutput.x(end))*slope ;
StatsSmooth.meanLogOutput.x = [StatsSmooth.meanLogOutput.x finalinf] ;
StatsSmooth.meanLogOutput = StatsSmooth.meanLogOutput.f ;



StatsSmooth.FlexLogOutput = ksr(Stats.infl,Stats.FlexLogOutput,h);
temp = find(ismember(StatsSmooth.FlexLogOutput.x,Stats.infl)==1) ;
[StatsSmooth.FlexLogOutput.x,Index] = unique(StatsSmooth.FlexLogOutput.x(temp)) ;
StatsSmooth.FlexLogOutput.f = StatsSmooth.FlexLogOutput.f(temp) ;
StatsSmooth.FlexLogOutput.f = StatsSmooth.FlexLogOutput.f(Index) ;
slope = (StatsSmooth.FlexLogOutput.f(end) - StatsSmooth.FlexLogOutput.f(end-1))/(StatsSmooth.FlexLogOutput.x(end) - StatsSmooth.FlexLogOutput.x(end-1)) ;
StatsSmooth.FlexLogOutput.f(length(StatsSmooth.FlexLogOutput.f)+1) = StatsSmooth.FlexLogOutput.f(end) + (finalinf - StatsSmooth.FlexLogOutput.x(end))*slope ;
StatsSmooth.FlexLogOutput.x = [StatsSmooth.FlexLogOutput.x finalinf] ;
StatsSmooth.FlexLogOutput = StatsSmooth.FlexLogOutput.f ;

StatsSmooth.FlexLabor = ksr(Stats.infl,Stats.FlexLabor,h);
temp = find(ismember(StatsSmooth.FlexLabor.x,Stats.infl)==1) ;
[StatsSmooth.FlexLabor.x,Index] = unique(StatsSmooth.FlexLabor.x(temp)) ;
StatsSmooth.FlexLabor.f = StatsSmooth.FlexLabor.f(temp) ;
StatsSmooth.FlexLabor.f = StatsSmooth.FlexLabor.f(Index) ;
slope = (StatsSmooth.FlexLabor.f(end) - StatsSmooth.FlexLabor.f(end-1))/(StatsSmooth.FlexLabor.x(end) - StatsSmooth.FlexLabor.x(end-1)) ;
StatsSmooth.FlexLabor.f(length(StatsSmooth.FlexLabor.f)+1) = StatsSmooth.FlexLabor.f(end) + (finalinf - StatsSmooth.FlexLabor.x(end))*slope ;
StatsSmooth.FlexLabor.x = [StatsSmooth.FlexLabor.x finalinf] ;
StatsSmooth.FlexLabor = StatsSmooth.FlexLabor.f ;

StatsSmooth.prodwedge = ksr(Stats.infl,Stats.prodwedge,h);
temp = find(ismember(StatsSmooth.prodwedge.x,Stats.infl)==1) ;
[StatsSmooth.prodwedge.x,Index] = unique(StatsSmooth.prodwedge.x(temp)) ;
StatsSmooth.prodwedge.f = StatsSmooth.prodwedge.f(temp) ;
StatsSmooth.prodwedge.f = StatsSmooth.prodwedge.f(Index) ;
slope = (StatsSmooth.prodwedge.f(end) - StatsSmooth.prodwedge.f(end-1))/(StatsSmooth.prodwedge.x(end) - StatsSmooth.prodwedge.x(end-1)) ;
StatsSmooth.prodwedge.f(length(StatsSmooth.prodwedge.f)+1) = StatsSmooth.prodwedge.f(end) + (finalinf - StatsSmooth.prodwedge.x(end))*slope ;
StatsSmooth.prodwedge.x = [StatsSmooth.prodwedge.x finalinf] ;
StatsSmooth.prodwedge = StatsSmooth.prodwedge.f ;

StatsSmooth.meanp = ksr(Stats.infl,Stats.meanp,h);
temp = find(ismember(StatsSmooth.meanp.x,Stats.infl)==1) ;
[StatsSmooth.meanp.x,Index] = unique(StatsSmooth.meanp.x(temp)) ;
StatsSmooth.meanp.f = StatsSmooth.meanp.f(temp) ;
StatsSmooth.meanp.f = StatsSmooth.meanp.f(Index) ;
slope = (StatsSmooth.meanp.f(end) - StatsSmooth.meanp.f(end-1))/(StatsSmooth.meanp.x(end) - StatsSmooth.meanp.x(end-1)) ;
StatsSmooth.meanp.f(length(StatsSmooth.meanp.f)+1) = StatsSmooth.meanp.f(end) + (finalinf - StatsSmooth.meanp.x(end))*slope ;
StatsSmooth.meanp.x = [StatsSmooth.meanp.x finalinf] ;
StatsSmooth.meanp = StatsSmooth.meanp.f ;

StatsSmooth.meanL = ksr(Stats.infl,Stats.meanL,h);
temp = find(ismember(StatsSmooth.meanL.x,Stats.infl)==1) ;
[StatsSmooth.meanL.x,Index] = unique(StatsSmooth.meanL.x(temp)) ;
StatsSmooth.meanL.f = StatsSmooth.meanL.f(temp) ;
StatsSmooth.meanL.f = StatsSmooth.meanL.f(Index) ;
slope = (StatsSmooth.meanL.f(end) - StatsSmooth.meanL.f(end-1))/(StatsSmooth.meanL.x(end) - StatsSmooth.meanL.x(end-1)) ;
StatsSmooth.meanL.f(length(StatsSmooth.meanL.f)+1) = StatsSmooth.meanL.f(end) + (finalinf - StatsSmooth.meanL.x(end))*slope ;
StatsSmooth.meanL.x = [StatsSmooth.meanL.x finalinf] ;
StatsSmooth.meanL = StatsSmooth.meanL.f ;

StatsSmooth.pccost = ksr(Stats.infl,Stats.pccost,h);
temp = find(ismember(StatsSmooth.pccost.x,Stats.infl)==1) ;
[StatsSmooth.pccost.x,Index] = unique(StatsSmooth.pccost.x(temp)) ;
StatsSmooth.pccost.f = StatsSmooth.pccost.f(temp) ;
StatsSmooth.pccost.f = StatsSmooth.pccost.f(Index) ;
slope = (StatsSmooth.pccost.f(end) - StatsSmooth.pccost.f(end-1))/(StatsSmooth.pccost.x(end) - StatsSmooth.pccost.x(end-1)) ;
StatsSmooth.pccost.f(length(StatsSmooth.pccost.f)+1) = StatsSmooth.pccost.f(end) + (finalinf - StatsSmooth.pccost.x(end))*slope ;
StatsSmooth.pccost.x = [StatsSmooth.pccost.x finalinf] ;
StatsSmooth.pccost = StatsSmooth.pccost.f ;

StatsSmooth.avmarkup = ksr(Stats.infl,Stats.avmarkup,h);
temp = find(ismember(StatsSmooth.avmarkup.x,Stats.infl)==1) ;
[StatsSmooth.avmarkup.x,Index] = unique(StatsSmooth.avmarkup.x(temp)) ;
StatsSmooth.avmarkup.f = StatsSmooth.avmarkup.f(temp) ;
StatsSmooth.avmarkup.f = StatsSmooth.avmarkup.f(Index) ;
slope = (StatsSmooth.avmarkup.f(end) - StatsSmooth.avmarkup.f(end-1))/(StatsSmooth.avmarkup.x(end) - StatsSmooth.avmarkup.x(end-1)) ;
StatsSmooth.avmarkup.f(length(StatsSmooth.avmarkup.f)+1) = StatsSmooth.avmarkup.f(end) + (finalinf - StatsSmooth.avmarkup.x(end))*slope ;
StatsSmooth.avmarkup.x = [StatsSmooth.avmarkup.x finalinf] ;
StatsSmooth.avmarkup = StatsSmooth.avmarkup.f ;

StatsSmooth.welfareLossIgnoreUncert = ksr(Stats.infl,Stats.welfareLossIgnoreUncert,h);
temp = find(ismember(StatsSmooth.welfareLossIgnoreUncert.x,Stats.infl)==1) ;
[StatsSmooth.welfareLossIgnoreUncert.x,Index] = unique(StatsSmooth.welfareLossIgnoreUncert.x(temp)) ;
StatsSmooth.welfareLossIgnoreUncert.f = StatsSmooth.welfareLossIgnoreUncert.f(temp) ;
StatsSmooth.welfareLossIgnoreUncert.f = StatsSmooth.welfareLossIgnoreUncert.f(Index) ;
slope = (StatsSmooth.welfareLossIgnoreUncert.f(end) - StatsSmooth.welfareLossIgnoreUncert.f(end-1))/(StatsSmooth.welfareLossIgnoreUncert.x(end) - StatsSmooth.welfareLossIgnoreUncert.x(end-1)) ;
StatsSmooth.welfareLossIgnoreUncert.f(length(StatsSmooth.welfareLossIgnoreUncert.f)+1) = StatsSmooth.welfareLossIgnoreUncert.f(end) + (finalinf - StatsSmooth.welfareLossIgnoreUncert.x(end))*slope ;
StatsSmooth.welfareLossIgnoreUncert.x = [StatsSmooth.welfareLossIgnoreUncert.x finalinf] ;
StatsSmooth.welfareLossIgnoreUncert = StatsSmooth.welfareLossIgnoreUncert.f ;
