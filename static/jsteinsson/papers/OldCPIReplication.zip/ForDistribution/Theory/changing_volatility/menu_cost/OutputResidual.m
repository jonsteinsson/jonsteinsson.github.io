
function Residual = OutputResidual(Y,C,sm,Af)
% This function takes the inputs from the model and a guess
% for the welfare cost and returns the difference between the welfare of
% the sticky price economy versus the flexible price economy.

Residual = Y*C^(1-sm) - ((1-sm)/sm)^(1-sm)*Af*(Y-C) ;

end

