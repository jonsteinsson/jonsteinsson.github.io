% Calculates statistics about price changes from the stationary 
% distribution
%
% Jon Steinsson and Emi Nakamura, July 2006
%**************************************************************

function PCStats = RigidityStats(Q,F,a,rp,rad,theta,FlexSSC,menucost)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

Q = reshape(Q,[Ssize 1]);
F = reshape(F,[Ssize 1]);

% Calculate frequency of price change
%***************************************************************

rpBig = repmat(rp,[1 agridsize radgridsize]);
rpBig = permute(rpBig,[2 1 3]);
rpBig = reshape(rpBig,[Ssize 1]);

PriceChange = (rpBig ~= F);

PCStats.freq = sum(PriceChange.*Q);

% Calculate frequency of price increases, frequency of price decreases,
% and fraction of price changes that are increases
%***************************************************************

PriceIncrease = (F > rpBig);
PriceDecrease = (F < rpBig);

PCStats.frequp = sum(PriceIncrease.*Q);
PCStats.freqdw = sum(PriceDecrease.*Q);
PCStats.fracup = sum(PriceIncrease.*Q)/PCStats.freq;
if PCStats.fracup == 1
    PCStats.fracup = 0.9999;
elseif PCStats.fracup == 0
    PCStats.fracup = 0.0001;
end

% Calculate absolute size of price changes, price increases and 
% price decreases
%****************************************************************

AbsSizePC  = abs(F-rpBig);

PCStats.abssizepc = sum(AbsSizePC.*Q)/PCStats.freq;
PCStats.sizeup = sum(AbsSizePC.*Q.*PriceIncrease)/(PCStats.freq*PCStats.fracup);
PCStats.sizedw = sum(AbsSizePC.*Q.*PriceDecrease)/(PCStats.freq*(1-PCStats.fracup));

% Calculate size of price change and powers of size of price change
%*********************************************************************

SizePC  = F-rpBig;
PCStats.sizepcnotabs = sum(SizePC.*Q)/PCStats.freq;
PCStats.sizepcsquared = sum(SizePC.^2.*Q)/PCStats.freq;
PCStats.sizepccubed = sum(SizePC.^3.*Q)/PCStats.freq;

% Calculate inefficient price dispersion and effect of
% price dispersion on productivity
%*********************************************************************

aBig = repmat(a,[1 rpgridsize radgridsize]);
aBig = reshape(aBig,[Ssize 1]);

radBig = repmat(rad,[1 agridsize rpgridsize]);
radBig = permute(radBig,[2 3 1]);
radBig = reshape(radBig,[Ssize 1]);

% Inefficient price dispersion
PCStats.meanRprice = sum((exp(F).*exp(aBig)).*Q);
PCStats.ineffpdisp = (sum(((exp(F).*exp(aBig)-PCStats.meanRprice).^2).*Q))^(1/2);

% Effect of price dispersion on labor productivity (productivity wedge)
PCStats.lprod = sum(((exp(F).*exp(aBig).^(1/theta)).^(-theta)).*Q)^(-1);

% 2nd order approx of inefficient price dispersion and labor productivity
%************************************************************************
% (Here we take averages first within rad states and then across these
% states)

aBig = reshape(aBig,[agridsize rpgridsize radgridsize]);
F    = reshape(F   ,[agridsize rpgridsize radgridsize]);
Q    = reshape(Q   ,[agridsize rpgridsize radgridsize]);

Qrad = sum(sum(Q));
Qrad = reshape(Qrad, [radgridsize 1]);
Qrad = repmat(Qrad,[1 agridsize rpgridsize]);
Qrad = permute(Qrad, [2 3 1]);
Qnorm = Q./Qrad;

logX = F  + (1/theta)*aBig;  % For labor productivity
logZ = F  + aBig;            % For inefficient price dispersion

lprod2nd      = exp((theta*(theta+1)/2)*sum(sum(logX.^2.*Qnorm))).^(-1);
ineffpdisp2nd = exp((theta*(theta+1)/2)*sum(sum(logZ.^2.*Qnorm))).^(-1);

lprod2nd      = reshape(lprod2nd, [radgridsize 1]);
ineffpdisp2nd = reshape(ineffpdisp2nd, [radgridsize 1]);

lprod2nd(isnan(lprod2nd)) = 0;
ineffpdisp2nd(isnan(ineffpdisp2nd)) = 0;

Qrad = sum(sum(Q));
Qrad = reshape(Qrad, [radgridsize 1]);

lprod2nd      = sum(lprod2nd.*Qrad);
ineffpdisp2nd = sum(ineffpdisp2nd.*Qrad);

PCStats.lprod2nd      = lprod2nd;
PCStats.ineffpdisp2nd = ineffpdisp2nd;

aBig = reshape(aBig,[Ssize 1]);
F    = reshape(F   ,[Ssize 1]);
Q    = reshape(Q   ,[Ssize 1]);

% Mean and standard deviation of output
%**********************************************************************

Q = reshape(Q,[agridsize rpgridsize radgridsize]);
Qrad = sum(sum(Q));
Qrad = reshape(Qrad,[radgridsize 1]);
meanOutput = sum(rad.*Qrad);
PCStats.stdLogOutput = (sum(((rad-meanOutput).^2).*Qrad))^(1/2);
PCStats.meanLogOutput = meanOutput;

% Productivity in flex price case
%**********************************************************************

Qnorm = reshape(Qnorm,[Ssize 1]);
lprodFlex2 = (exp(aBig).^(theta-1)).*Qnorm;
lprodFlex2(isnan(lprodFlex2)) = 1;
lprodFlex2 = reshape(lprodFlex2,[agridsize rpgridsize radgridsize]);
lprodFlex2 = sum(sum(lprodFlex2)).^(-1/(theta-1));
lprodFlex2 = reshape(lprodFlex2,[radgridsize 1]);
PCStats.lprodFlex2 = sum(lprodFlex2.*Qrad)^(-1);
Q    = reshape(Q   ,[Ssize 1]);

% Effect of price dispersion on labor productivity (productivity wedge)
PCStats.lprodFlex = sum((exp(aBig).^(theta-1)).*Q)^(1/(theta-1));

% Flex price output
%***********************************************************************

PCStats.FlexLogOutput = log((theta-1)/theta*PCStats.lprodFlex);

% Productivity Wedge
%***********************************************************************

PCStats.prodwedge = PCStats.lprod/PCStats.lprodFlex;

% Average Relative Prices
%***********************************************************************

PCStats.meanp = sum(sum(sum(exp(F).^(1-theta).*Q)))^(1/(1-theta));

% Cost of Changing Prices
%***********************************************************************

PCStats.pccost = sum(menucost.*PriceChange.*Q);

% Mean labor 
%***********************************************************************

PCStats.meanL = exp(PCStats.meanLogOutput)/PCStats.lprod + PCStats.pccost;

% Flex price labor supply
%***********************************************************************

PCStats.FlexLabor = (theta-1)/theta;

% Average Markup
%***********************************************************************

PCStats.avmarkup = PCStats.lprod/exp(PCStats.meanLogOutput);

% Welfare Loss (relative to flex price) 
%***********************************************************************
% Ignoring uncertainty !!!!!!!!!!!!!!!!!!!!!!!!!!!

PCStats.welfareLossIgnoreUncert = exp(PCStats.FlexLogOutput - PCStats.FlexLabor + PCStats.meanL)...
                                 ./exp(PCStats.meanLogOutput) - 1;

% lambda0 = PCStats.welfareLossIgnoreUncert ; % Take as initial guess the welfare cost without uncertainty
% PCStats.welfareLossUncert = Bisect(rad,Qrad,PCStats.FlexLogOutput,PCStats.FlexLabor,PCStats.meanL) ;


end

function [Optim,Err] = Bisect(rad,Qrad,FlexLogOutput,FlexLabor,meanL)
    Conv = 1e-08 ;
    Low = 0 ;
    High = 1 ;
    mid = 0.5*(Low + High) ;
    fl = Welfare(rad,Low,Qrad,FlexLogOutput,FlexLabor,meanL) ;
    fm = Welfare(rad,mid,Qrad,FlexLogOutput,FlexLabor,meanL) ;
    fh = Welfare(rad,High,Qrad,FlexLogOutput,FlexLabor,meanL) ;    
Delta = abs(fh - fl) ;
    while Delta> Conv
        Low = mid*(fm<0) + Low*(fm>=0) ;
        fl = Welfare(rad,Low,Qrad,FlexLogOutput,FlexLabor,meanL) ;
        High = mid*(fm>=0) + High*(fm<0) ;
        fh = Welfare(rad,High,Qrad,FlexLogOutput,FlexLabor,meanL) ;
        mid = 0.5*(Low + High) ;
        fm = Welfare(rad,mid,Qrad,FlexLogOutput,FlexLabor,meanL) ;
        Delta = abs(fm) ;
        
    end
    Optim = mid ;
    Err = fm ;
end

function J = Welfare(rad,lambda,Qrad,FlexLogOutput,FlexLabor,meanL)
% This function takes the inputs from the model and a guess
% for the welfare cost and returns the difference between the welfare of
% the sticky price economy versus the flexible price economy.

J = sum(log(exp(rad)*(1+lambda)).*Qrad) - FlexLogOutput + FlexLabor - meanL ;

end




