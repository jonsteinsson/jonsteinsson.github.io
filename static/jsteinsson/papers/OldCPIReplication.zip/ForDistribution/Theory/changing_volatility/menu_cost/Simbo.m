% Calculates st.dev and var of output based on G
%
% Jon Steinsson and Emi Nakamura, September 2006
%
% Modified January 2010 to simulate data from a given process
% for S
% mode = 0  corresponds to a forced dataset for S
% mode = 1  corresponds to a simulated dataset for S
%********************************************************

function [GE1SimboG] = Simbo(GE1Model,NSim,burnin,nomGDP,mode)

% Set Parameters
%********************************************************

% NSim = 25000;
% burnin = 20;
NPeriods = NSim + burnin;

Nimp = 400;
% SizeOfShock will be one standard deviation of RAD

nhh = 2.2; % bandwidth of kernel smoother (number of rad points/2)
radincsmooth = 10^(-8);

% Get G and rad
%********************************************************

G = GE1Model.G;
GError = GE1Model.GError;
rad = GE1Model.rad;
radgridsize = size(rad,1);
mu = GE1Model.mu;
sigma_eta = GE1Model.sigma_eta;

% Create a Kernel Smoothed version of G
%********************************************************

radinc = rad(2)-rad(1);
hh = nhh*radinc;
AddN = hh/radinc - mod(hh/radinc,1);
radLong = rad;
GplusError = G + GError;
GLong = GplusError;
for i = 1:AddN
    radLong = [rad(1)-i*radinc; radLong; rad(end)+i*radinc];
    GLong = [GplusError(1) - GplusError(1+i) + GplusError(1); ...
        GLong; GplusError(end) - GplusError(end-i) + GplusError(end)];
end

Nsmooth = (rad(end)-rad(1))/radincsmooth + 1;
radSmooth = (rad(1):radincsmooth:rad(end))';
GSmooth = KernelSmoother(hh,radLong,GLong,radSmooth);

% Put GSmooth on radSmooth grid
%********************************************************
 
radSmoothinc = radSmooth(2) - radSmooth(1);
GSmooth_mod = mod(GSmooth,radSmoothinc);
GSmooth_mod_up = (GSmooth_mod > radSmoothinc/2);
GSmooth = GSmooth + GSmooth_mod_up.*(radSmoothinc-GSmooth_mod) ...
    - (1-GSmooth_mod_up).*GSmooth_mod;

%figure(1)
%plot(rad,G,'r-',radSmooth,GSmooth,'b-')

GE1SimboG.radSmooth = radSmooth;
GE1SimboG.GSmooth = GSmooth;
GE1SimboG.rad = rad;
GE1SimboG.G = G;
GE1SimboG.GError = GError;

% Simulate series for S
%********************************************************

if mode == 1 % simulated mode
dS = mu + sigma_eta*randn(NPeriods,1);
% Put dS on the radSmooth grid
dS_mod = mod(dS,radSmoothinc);
dS_mod_up = (dS_mod > radSmoothinc/2);
dS = dS + dS_mod_up.*(radSmoothinc-dS_mod) ...
    - (1-dS_mod_up).*dS_mod;

S = zeros(NPeriods+1,1);
for ii = 1:NPeriods
    S(ii+1,1) = S(ii,1) + dS(ii,1);
end

else % forced mode

% S needs to be of length Nperiods+1 starting at S_0
if length(nomGDP) ~= (Nperiods +1)
    fprintf('S is not the right size')
    return;
else
S = nomGDP;
dS = diff(S);

% Put dS on the radSmooth grid
dS_mod = mod(dS,radSmoothinc);
dS_mod_up = (dS_mod > radSmoothinc/2);
dS = dS + dS_mod_up.*(radSmoothinc-dS_mod) ...
    - (1-dS_mod_up).*dS_mod;

S = zeros(NPeriods+1,1);
for ii = 1:NPeriods
    S(ii+1,1) = S(ii,1) + dS(ii,1);
end

end

end
S = S(2:end,1);

% Calculate the steady state of S/P
%********************************************************

S = S + radSmooth(floor(Nsmooth/2),1);

% Simulate Economy
%*********************************************************

SPm = zeros(NPeriods,1);
SP = zeros(NPeriods,1);
P = zeros(NPeriods+1,1);
Pi = zeros(NPeriods,1);

for ii = 1:NPeriods
    SPm(ii,1) = S(ii,1) - P(ii,1);
    if SPm(ii,1) < radSmooth(1,1)
        SPm(ii,1) = radSmooth(1,1);
    elseif SPm(ii,1) > radSmooth(end,1)
        SPm(ii,1) = radSmooth(end,1);
    end
    %int32(SPm(ii,1)*10^6)
    %min(abs(int32(SPm(ii,1)*10^6)*int32(ones(Nsmooth,1))-int32(radSmooth*10^6)))
    [dummy,IndInf] = ismember(int32(SPm(ii,1)*10^8),int32(radSmooth*10^8));
    clear dummy
    %IndInf = match(int32(SPm(ii,1)*10^6),int32(radSmooth*10^6));
    P(ii+1,1) = P(ii,1) + GSmooth(IndInf,1);
    Pi(ii,1) = P(ii+1,1) - P(ii,1);
    SP(ii,1) = S(ii,1) - P(ii+1,1);
end
P = P(2:end);

S = S((burnin+1):end,1);
SPm = SPm((burnin+1):end,1);
SP = SP((burnin+1):end,1);
P = P((burnin+1):end,1);
Pi = Pi((burnin+1):end,1);

% Save Results
%*****************************************************************

GE1SimboG.G = G;
GE1SimboG.GSmooth = GSmooth;
GE1SimboG.rad = rad;
GE1SimboG.radSmooth = radSmooth;

GE1SimboG.S = S;
GE1SimboG.SPm = SPm;
GE1SimboG.SP = SP;
GE1SimboG.P = P;
GE1SimboG.Pi = Pi;
save('GE1SimboG','GE1SimboG')

% Print st.dev(SP) and var(SP)
%*****************************************************************

fprintf('St.Dev of output = %5.5f\n',std(SP))
fprintf('Variance of output = %5.9f (x10^-4)\n\n',var(SP)*10000)

toc