%This program simluates the one sector GE menu cost model for N firms and
%T periods. It uses the output ge1Basic.m (GE1Model.mat) to take the
%parameters and policy function of the model to simulate it. Finally, the
%program computes various statistics of the price/price change distribution
%by period. It runs in parts, with each successive cell doing different
%parts of the simulation. The last cell has code to create various scatter
%plots of inflation versus the different moments, as well as some
%histograms. 

%% Set-up, loading the parameters and policy function
time1 = cputime;

%Load objects from model solution
load('GE1Model.mat');
G = GE1Model.G;
F = GE1Model.F;
F_c = GE1Model.F_c;
Q = GE1Model.Q;
theta = GE1Model.theta;
mu = GE1Model.mu;
sigma_eta = GE1Model.sigma_eta;
sigma_eps = GE1Model.sigma_eps;
rho = GE1Model.rho;
a = GE1Model.a;
rp = GE1Model.rp;
rad = GE1Model.rad;
GInd = CalculateGInd(a,rp,rad,G);

T = 1000;%Number periods
N = 20000;%Number of firms
burnin = 200;%Periods of burning to be discarded

%Grid parameters
amax = a(end,1);
amin = a(1,1);
agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
rpmax = rp(end,1);
rpmin = rp(1,1);
rpinc = (rpmax-rpmin)/(rpgridsize-1);
radmax = rad(end,1);
radmin = rad(1,1);

%% Smooth G and rad, to obtain a smooth inflation grid
nhh = 2.2; % bandwidth of kernel smoother (number of rad points/2)
radincsmooth = 10^(-6);
GError = GE1Model.GError;
radinc = rad(2)-rad(1);
hh = nhh*radinc;
AddN = hh/radinc - mod(hh/radinc,1);
radLong = rad;
GplusError = G + GError;
GLong = GplusError;
for i = 1:AddN
    radLong = [rad(1)-i*radinc; radLong; rad(end)+i*radinc];
    GLong = [GplusError(1) - GplusError(1+i) + GplusError(1); ...
        GLong; GplusError(end) - GplusError(end-i) + GplusError(end)];
end

Nsmooth = (rad(end)-rad(1))/radincsmooth + 1;
radSmooth = (rad(1):radincsmooth:rad(end))';
GSmooth = KernelSmoother(hh,radLong,GLong,radSmooth);

% Put GSmooth on radSmooth grid
%********************************************************
 
radSmoothinc = radSmooth(2) - radSmooth(1);
GSmooth_mod = mod(GSmooth,radSmoothinc);
GSmooth_mod_up = (GSmooth_mod > radSmoothinc/2);
GSmooth = GSmooth + GSmooth_mod_up.*(radSmoothinc-GSmooth_mod) ...
    - (1-GSmooth_mod_up).*GSmooth_mod;

%%
%Simulate time series for a for each firm
%***************************

aSim = zeros(T+burnin+1,N);%Simulated value of logA
a_inc = (amax-amin)/(agridsize-1);
eps_a = sigma_eps*randn(T+burnin,N);%Series of a shocks
aSim(1,:) = repmat(a(agridsize/2 -mod(agridsize/2,1) + 1,:),1,N);
for i = 1:(T+burnin)%Sequentially create value of a, adjusted to be a value in grid
    delta_a = (rho-1)*aSim(i,:) + eps_a(i,:);
    delta_a_mod = mod(delta_a,a_inc);
    delta_a_mod_big = (a_inc/2 < delta_a_mod);
    delta_a_mod_small = (a_inc/2 >= delta_a_mod);
    delta_a_grid = delta_a - delta_a_mod_small.*delta_a_mod ...
        + delta_a_mod_big.*(a_inc-delta_a_mod);
    aSim(i+1,:) = aSim(i,:) + delta_a_grid;
    aSim(i+1,:) = min(aSim(i+1,:),amax);
    aSim(i+1,:) = max(aSim(i+1,:),amin);
end
aSim_ind = int32((aSim - amin*ones(T+burnin+1,N))/a_inc + 1);%Index on a grid corresponding to simulated values
clear eps_a delta_a delta_a_mod delta_a_mod_big delta_a_mod_small delta_a_grid

%Simulate inflation & RAD
%******************
radinc = (radmax - radmin)/(radgridsize - 1);
eps_eta = sigma_eta*randn(T+burnin+1,1); %NAD shocks
P = zeros(T + burnin + 1,1);%initialize price level, inflation, RAD vectors
Pi = zeros(T + burnin + 1,1);
Simrad = zeros(T + burnin + 1,1);
rad_init = rad(ceil(radgridsize/2));%RAD in t=-1
dS = zeros(T + burnin + 1,1);
dS(1,1) = mu + eps_eta(1,1);%Initial NAD innovation, adjusted to be on grid
dS_mod = mod(dS(1,1),radinc);
dS_mod_big = radinc/2 < dS_mod;
dS_mod_small = radinc/2 >= dS_mod;
dS_grid = dS(1,1) - dS_mod_small*dS_mod + dS_mod_big*(radinc - dS_mod);
rad_pre = zeros(T+burnin+1,1);
%Calculate S_0/P_-1 to predict P_0/P_-1 using G
rad_pre(1,1) = dS_grid + rad_init;
rad_pre(1,1) = min(radmax,rad_pre(1,1));
rad_pre(1,1) = max(radmin,rad_pre(1,1));
Pi(1,1) = G(int32((rad_pre(1,1)-radmin)/radinc + 1));
P(1,1) = Pi(1,1);
Simrad(1,1) = rad_pre(1,1) - Pi(1,1);
Simrad(1,1) = min(radmax,Simrad(1,1));
Simrad(1,1) = max(radmin,Simrad(1,1));
for i = 2:(T+burnin+1)
    dS(i,1) = mu + eps_eta(i,1);%Current period's NAD innovation
    dS_mod = mod(dS(i,1),radinc);%Made to fit on grid
    dS_mod_big = radinc/2 < dS_mod;
    dS_mod_small = radinc/2 >= dS_mod;
    dS_grid = dS(i,1) - dS_mod_small*dS_mod + dS_mod_big*(radinc-dS_mod);
    rad_pre(i,1) = dS_grid + Simrad(i-1,1);%Added to last period's RAD
    rad_pre(i,1) = min(radmax,rad_pre(i,1));
    rad_pre(i,1) = max(radmin,rad_pre(i,1));
    Pi(i,1) = G(int32((rad_pre(i,1)-radmin)/radinc + 1));%Inflation calculated using G
    P(i,1) = Pi(i,1) + P(i-1,1);
    Simrad(i,1) = rad_pre(i,1) - Pi(i,1);
    Simrad(i,1) = min(radmax,Simrad(i,1));
    Simrad(i,1) = max(radmin,Simrad(i,1));
end
clear eps_eta rad_init dS_mod dS_mod_big dS_mod_small dS_grid
%Indexes of RAD and S_t/P_t-1 (used to predict inflation) on grid
rad_pre_ind = int32((rad_pre-radmin)/radinc + 1);
rad_ind = int32((Simrad-radmin)/radinc + 1);

%Get smooth inflation series
SimradSmooth = zeros(T + burnin + 1,1);
PiSmooth = zeros(T + burnin + 1,1);
PSmooth = zeros(T + burnin + 1,1);
rad_preSmooth = zeros(T + burnin + 1,1);
radinit = rad(ceil(radgridsize/2));
dS_mod = mod(dS(1,1),radSmoothinc);
dS_mod_big = radSmoothinc/2 < dS_mod;
dS_mod_small = radSmoothinc/2 >= dS_mod;
dS_grid = dS(1,1) - dS_mod_small*dS_mod + dS_mod_big*(radSmoothinc - dS_mod);
rad_preSmooth(1,1) = dS_grid + radinit;
rad_preSmooth(1,1) = min(radmax,rad_preSmooth(1,1));
rad_preSmooth(1,1) = max(radmin,rad_preSmooth(1,1));
PiSmooth(1,1) = GSmooth(int32((rad_preSmooth(1,1)-radmin)/radSmoothinc + 1));
PSmooth(1,1) = Pi(1,1);
SimradSmooth(1,1) = rad_preSmooth(1,1) -PiSmooth(1,1);
SimradSmooth(1,1) = min(radmax,SimradSmooth(1,1));
SimradSmooth(1,1) = max(radmin,SimradSmooth(1,1));
for i = 2:(T + burnin + 1)
    dS_mod = mod(dS(i,1),radSmoothinc);
    dS_mod_big = radSmoothinc/2 < dS_mod;
    dS_mod_small = radSmoothinc/2 >= dS_mod;
    dS_grid = dS(i,1) - dS_mod_small*dS_mod + dS_mod_big*(radSmoothinc - dS_mod);
    rad_preSmooth(i,1) = dS_grid + SimradSmooth(i-1,1);
    rad_preSmooth(i,1) = min(radmax,rad_preSmooth(i,1));
    rad_preSmooth(i,1) = max(radmin,rad_preSmooth(i,1));
    PiSmooth(i,1) = GSmooth(int32((rad_preSmooth(i,1)-radmin)/radSmoothinc + 1));
    PSmooth(i,1) = Pi(i,1) + PSmooth(i-1,1);
    SimradSmooth(i,1) = rad_preSmooth(i,1)- PiSmooth(i,1);
    SimradSmooth(i,1) = min(radmax,SimradSmooth(i,1));
    SimradSmooth(i,1) = max(radmin,SimradSmooth(i,1));
end

%Simulate firm prices
%********************
rpSim = zeros(T+burnin+1,N);
rpcSim = zeros(T+burnin+1,N);
state_pre_ind = sub2ind([agridsize rpgridsize radgridsize],int32((aSim_ind(1,:))'),int32(repmat(ceil(rpgridsize/2),N,1)),int32(repmat(rad_pre_ind(1,1),N,1)));
state_post_ind = GInd(state_pre_ind);
rpSim(1,:) = F(state_post_ind');
rpcSim(1,:) = F_c(state_post_ind');
for i = 2:(T+burnin+1)
    state_pre_ind = sub2ind([agridsize rpgridsize radgridsize], int32(aSim_ind(i,:)'),int32((rpSim(i-1,:)'-rpmin)/rpinc + 1),int32(repmat(rad_pre_ind(i,1),N,1)));
    state_post_ind = GInd(state_pre_ind);
    rpSim(i,:) = F(state_post_ind');
    rpcSim(i,:) = F_c(state_post_ind');
end
npSim = rpSim + repmat(P,1,N);
npcSim = rpcSim + repmat(P,1,N);
ndpSim = npSim(2:end,:)-npSim(1:end-1,:);
ndpcSim = npcSim(2:end,:) - npSim(1:end-1,:);
xSim = exp(-theta*rpSim -aSim);
clear rad_pre rad_pre_ind aSim

%Desired price gap, reset prices
%Here, a firm's desired price is inflation cumulatively added
%to the price since the last change, period by period
%********************
Simchange = (abs(ndpSim) > 1e-8);
Despsim = zeros(T + burnin + 1,N);
Despsim(1,:) = npSim(1,:);
%Respsim = zeros(T+burnin+1,N);
%Respi = zeros(T+burnin+1,1);
%Cyet = (cumsum(Simchange,1) > 0);
%Cnfirst = (cumsum(Simchange,1) ~= 1);
%Cuse = Cyet.*Cnfirst.*Simchange;
%for t = 2:(T+burnin+1)
%    if sum(Cuse(t-1,:)) > 0
%        Respi(t,1) = ((npSim(t,:)-Respsim(t-1,:))*(Cuse(t-1,:)'))*(1/sum(Cuse(t-1,:)));
%    else
%        Respi(t,1) = 0;
%    end

%    for i = 1:N
%        if Simchange(t-1,i) == 1 
%            Respsim(t,i) = npSim(t,i);
%        elseif Simchange(t-1,i) == 0 && Cyet(t-1,i) == 1
%            Respsim(t,i) = Respsim(t-1,i) + Respi(t,1);
%        elseif Simchange(t-1,i) == 0 && Cyet(t-1,i) == 0
%            Respsim(t,i) = 0;
%        end
%    end
%end
for t = 2:(T+burnin+1)
    for i = 1:N
        if Simchange(t-1,i) == 1 
            Despsim(t,i) = npSim(t,i);
        elseif Simchange(t-1,i) == 0 
            Despsim(t,i) = Despsim(t-1,i) + Pi(t,1);
        end
    end
end
Gapsim = npSim - Despsim;
%Resdpsim = Respsim(2:end,:) - Respsim(1:end-1,:);


%Keep series without burnin
PSim = P(burnin + 2:end,:);%Price level
PiSim = Pi(burnin + 2:end,:);%Inflation
%Respi = Respi(burnin + 2:end,:);%Reset price inflation (aggregate)
PiSimSmooth = PiSmooth(burnin + 2:end,:);%Smoothed inflation
SimradSmooth = SimradSmooth(burnin + 2:end,:);%Smoothed RAD
Simrad = Simrad(burnin + 2:end,:);%Smoothed RAD
rpSim = rpSim(burnin + 2:end,:);%Real price panel
xSim = xSim(burnin + 2:end,:);
npSim = npSim(burnin + 2:end,:);%Nominal price
npcSim = npcSim(burnin + 2:end,:);%Optimal nominal price
ndpSim = ndpSim(burnin + 1:end,:);%Nominal price change
ndpcSim = ndpcSim(burnin+1:end,:);%Optimal nominal price change
Despsim = Despsim(burnin + 2:end,:);%Desired price 
Gapsim = Gapsim(burnin + 2:end,:);%Gap with desired price
%Resdpsim = Resdpsim(burnin + 1:end,:);%Change in reset price
Simchange = Simchange(burnin + 1:end,:);%Price change dummy


timeofsimulation = cputime - time1


%% Calculate price change statistics for each period
freqchange = sum(Simchange,2)*(1/N);
frequp = sum((ndpSim > 1e-8),2)*(1/N);
fracup = (sum((ndpSim > 1e-8),2)*(1/N))./freqchange;
fracdown = (sum((ndpSim < -1e-8),2)*(1/N))./freqchange;
%Calculate statistics based only on prices that change
ndpstats = sort(ndpSim,2);
Nup = sum((ndpSim > 1e-8),2);
Ndown = sum((ndpSim < -1e-8),2);
Nchange = sum(Simchange,2);
Meanabs = zeros(T,1);
Meanup = zeros(T,1);
Meandown = zeros(T,1);
SDrp = zeros(T,1);
SDpi = zeros(T,1);
SDup = zeros(T,1);
SDdown = zeros(T,1);
SKrp = zeros(T,1);
SKpi = zeros(T,1);
SKpic = zeros(T,1);
Leftband = zeros(T,1);
Rightband = zeros(T,1);
Meanpi = zeros(T,1);
Medpi = zeros(T,1);
for i = 1:T
    Meanabs(i,1) = mean(abs([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]));
    Meandown(i,1) = mean(abs(ndpstats(i,1:Ndown(i,1))));
    Meanup(i,1) = mean(ndpstats(i,N-Nup(i,1)+1:end));
    SDpi(i,1) = std([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]);
    SDdown(i,1) = std(ndpstats(i,1:Ndown(i,1)));
    SDup(i,1) = std(ndpstats(i,N-Nup(i,1)+1:end));
    SKpi(i,1) = skewness([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]);
    SKpic(i,1) = skewness(ndpcSim(i,:));
    Leftband(i,1) = max(ndpstats(i,1:Ndown(i,1)));
    Rightband(i,1) = min(ndpstats(i,N-Nup(i,1)+1:end));
    Meanpi(i,1) = mean([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]);
    Medpi(i,1) = median([ndpstats(i,1:Ndown(i,1)) ndpstats(i,N-Nup(i,1)+1:end)]);
end
PSKpi = (Meanpi - Medpi)./SDpi;
%Moments of real prices (p/P), first select only real prices with price
%change
rpstats = log(sort(exp(rpSim).*Simchange,2));
for i = 1:T
    SDrp(i,1) = std(rpstats(i,N-Nchange(i,1)+1:end));
    SKrp(i,1) = skewness(rpstats(i,N-Nchange(i,1)+1:end));
end
%Moments of real prices (p/P) and price changes, including prices that don't change
SDrpall = std(rpSim,0,2);
SKrpall = skewness(rpSim,1,2);
SDpiall = std(ndpSim,0,2);
SKpiall = skewness(ndpSim,1,2);
SDgap = std(Gapsim,0,2);
P10gap = prctile(Gapsim,10,2);
P25gap = prctile(Gapsim,25,2);
P50gap = prctile(Gapsim,50,2);
P75gap = prctile(Gapsim,75,2);
P90gap = prctile(Gapsim,90,2);
Dist = mean(xSim,2);
Distgap = mean((exp(Gapsim).^(-theta)),2);
SDlogp = std(npSim,0,2);

%% Figures, set dispi*** = 1 to display and save each figure
% Inflation time series plot
disppits = 1;
if disppits == 1
 h = plot(PiSimSmooth,'b-');title('Time Series Plot of Simulated Inflation');xlabel('Time (Months)');ylabel('Monthly Inflation');saveas(h,'Graphs\MC\pits.png');
end

dispts = 1;
if dispts == 1;
    ind = (1:T)';
    cor = corr(SDrp,SDgap);
    plot(ind,SDrp,'b-',ind,SDgap,'r-');title(strcat('Time Series Plot of Relative Price & Price Gap Dispersion; Corr = ',num2str(cor)));xlabel('Time (Months)');
    legend('Relative Price Dispersion','Desired Price Gap Dispersion','Location','Best');saveas(gcf,'Graphs\MC\dispts.png');
end

dispdistts = 1;
if dispdistts == 1;
    plot(Dist,'b-');title('Time Series plot of Price Distortion Meausure');xlabel('Time (Months)');saveas(gcf,'Graphs\MC\distts.png');
end

%Scatter plots of moments with inflation
%Frequency
dispfreq = 1;
if dispfreq == 1
h = scatter(PiSimSmooth,freqchange,2);title('\pi and Frequency of Price Change'); xlabel('\pi_t'); ylabel('Frequency');saveas(h,'Graphs\MC\freq.png');
end
%Mean size of price change
dispabs = 1;
if dispabs == 1
    h = scatter(PiSimSmooth,Meanabs,2);title('\pi and Mean Size Price Change');xlabel('\pi_t');ylabel('Mean size of price change');saveas(h,'Graphs\MC\abs.png');
end
%Mean size of price increases
dispmeanup = 1;
if dispmeanup == 1;
    h = scatter(PiSimSmooth,Meanup,2);title('\pi and Mean Size of Price Increase');xlabel('\pi_t');ylabel('Mean size of price increase');saveas(h,'Graphs\MC\meanup.png');
end
%Mean size of price decreases
dispmeandw = 1;
if dispmeandw == 1;
    h = scatter(PiSimSmooth,Meandown,2);title('\pi and Mean Size of Price Decrease');xlabel('\pi_t');ylabel('Mean size of price decrease');saveas(h,'Graphs\MC\meandw.png');
end
%Inflation dispersion
dispsdpi = 1;
if dispsdpi == 1
    h = scatter(PiSimSmooth,SDpi,2);title('\pi and Inflation Dispersion, excluding zero price changes');xlabel('\pi_t');ylabel('Std Dev_z \pi(z)');saveas(h,'Graphs\MC\sdpi.png');
end
%Price increase dispersion
dispsdup = 1;
if dispsdup == 1;
    h = scatter(PiSimSmooth,SDup,2);title('\pi and Inflation Dispersion, only increases');xlabel('\pi_t');ylabel('Std Dev_z \pi(z)');saveas(h,'Graphs\MC\sdup.png');
end
%Price descrease dispersion
dispsddw = 1;
if dispsddw == 1;
    h = scatter(PiSimSmooth,SDdown,2);title('\pi and Inflation Dispersion, only decreases');xlabel('\pi_t');ylabel('Std Dev_z \pi(z)');saveas(h,'Graphs\MC\sddw.png');
end
%Real price dispersion
dispsdrp = 1;
if dispsdrp == 1;
    h = scatter(PiSimSmooth,SDrpall,2);title('\pi and Relative Price Dispersion, including zero price changes');xlabel('\pi_t');ylabel('Std Dev_z log(p(z)/P)');saveas(h,'Graphs\MC\sdrp.png');
end
%Inflation skewness
dispskpi = 1;
if dispskpi == 1;
    h = scatter(PiSimSmooth,SKpi,2);title('\pi and Skewness of Price Changes, excluding zero price changes');xlabel('\pi_t');ylabel('Skew_z \pi(z)');saveas(h,'Graphs\MC\skpi.png');
end

%Desired Price Gap dispersion
dispsdgap = 1;
if dispsdgap == 1;
    h = scatter(PiSimSmooth,SDgap,2);title('\pi and Dispersion of Desired Price Gap, all prices');xlabel('\pi_t');ylabel('Standard Deviation');saveas(h,'Graphs\MC\sdgap.png');
end

%Ss band over time;
dispss = 1;
if dispss == 1;
plot((1:T)',Leftband,'r',(1:T)',Rightband,'b');title('Ss Band for Each Period');xlabel('t');ylabel('Smallest Price Change');legend('Decreases (left band)','Increases (right band)','Location','Best');saveas(gcf,'Graphs/MC/Ss.png');
end

%Price gap distortions & Inflation;
dispdist = 1;
if dispdist == 1;
    scatter(PiSimSmooth,Distgap,2);title('\pi and Price Gap Distortion');xlabel('\pi_t');ylabel('Price gap measure of Distortion');
    saveas(gcf,'Graphs\MC\Distgap.png');
end

%Price distortions & Inflation;
dispdist = 1;
if dispdist == 1;
    scatter(PiSimSmooth,Dist,2);title('\pi and Distortions from Relative Price Misalignments');xlabel('\pi_t');ylabel('Mean of (p(z)A(z)/P)^{-\theta} ');
    saveas(gcf,'Graphs\MC\Dist.png');
end

%Time series of price gap percentiles
dispgapd = 1;
if dispgapd == 1;
    ind = (1:T)';
    plot(ind,P10gap,'k',ind,P25gap,'b',ind,P50gap,'r',ind,P75gap,'m',ind,P90gap,'g');xlabel('Time (Months)');ylabel('Desired Price Gap');
    title('Percentiles (10,25,50,75,90) of Desired Price Gap distribution');saveas(gcf,'Graphs\MC\Gapdistts.png');
end

%Correlations of percentiles with inflation
dispgapscatter = 1;
if dispgapscatter == 1;
    scatter(PiSimSmooth,P10gap,50);title('\pi and 10^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 10^{th} Pctile');
    saveas(gcf,'Graphs\MC\Gap10infl.png');
    scatter(PiSimSmooth,P25gap,50);title('\pi and 25^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 25^{th} Pctile');
    saveas(gcf,'Graphs\MC\Gap25infl.png');
    scatter(PiSimSmooth,P50gap,50);title('\pi and 50^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 50^{th} Pctile');
    saveas(gcf,'Graphs\MC\Gap50infl.png');
    scatter(PiSimSmooth,P75gap,50);title('\pi and 75^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 75^{th} Pctile');
    saveas(gcf,'Graphs\MC\Gap75infl.png');
    scatter(PiSimSmooth,P90gap,50);title('\pi and 90^{th} Percentile of Price Gap Distribution');xlabel('\pi_t');ylabel('Price Gap 90^{th} Pctile');
    saveas(gcf,'Graphs\MC\Gap90infl.png');
end


%Table of frequency, size, inflation & real price dispersion scatter plots
disptable1 = 1;
if disptable1 == 1
    subplot(2,2,1);
    scatter(PiSimSmooth,freqchange,2);title('\pi and Frequency of Price Change'); xlabel('\pi_t'); ylabel('Frequency');
    subplot(2,2,2)
    scatter(PiSimSmooth,Meanabs,2);title('\pi and Mean Size Price Change');xlabel('\pi_t');ylabel('Mean size of price change');
    subplot(2,2,3)
    scatter(PiSimSmooth,SDrpall,2);title('\pi and Relative Price Dispersion, including zero price changes');xlabel('\pi_t');ylabel('Std Dev_z log(p(z)/P)');
    h = subplot(2,2,4);
    scatter(PiSimSmooth,SDpi,2);title('\pi and Inflation Dispersion, excluding zero price changes');xlabel('\pi_t');ylabel('Std Dev_z \pi(z)');saveas(h,'Graphs\MC\table1.png')
end


%Table of fraction of changes that are increases, size of increases, size
%of decreases, skewness
disptable = 2;
if disptable == 2
    subplot(2,2,1)
    scatter(PiSimSmooth,Meanup,2);title('\pi and Mean Size of Price Increase'); xlabel('\pi_t'); ylabel('Mean Size');
    subplot(2,2,2)
    scatter(PiSimSmooth,Meandown,2);title('\pi and Mean Size of Price Decrease');xlabel('\pi_t');ylabel('Mean Size');
    subplot(2,2,3)
    scatter(PiSimSmooth,fracup,2);title('\pi and Fracion of Changes that are Increases');xlabel('\pi_t');ylabel('Fraction');
    h = subplot(2,2,4);
    scatter(PiSimSmooth,SKpi,2);title('\pi and Skewness of Price Changes, excluding zero price changes');xlabel('\pi_t');ylabel('Skew_z \pi(z)');saveas(h,'Graphs\MC\table2.png');
end

%Table of price gap statistics
dispgap = 1;
if dispgap == 1
    subplot(2,2,1)
    scatter(PiSimSmooth,SDgap,2);title('\pi and Desired Price Gap Dispersion');xlabel('\pi_t');
    subplot(2,2,2)
    scatter(PiSimSmooth,P25gap,2);title('\pi and 25th Pctile of Desired Price Gap Distribution');xlabel('\pi_t');
    subplot(2,2,3)
    scatter(PiSimSmooth,P50gap,2);title('\pi and Desired Price Gap Median');xlabel('\pi_t');
    subplot(2,2,4)
    scatter(PiSimSmooth,P75gap,2);title('\pi and 75th Pctile of Desired Price Gap Distribution');xlabel('\pi_t');
    saveas(gcf,'Graphs\MC\Gaptable.png');
end

%Histogram of price changes for periods of different inflation
disphistpc = 1;
if disphistpc == 1
    [Pisort, I] = sort(PiSimSmooth);
    tneg = I(1);
    tpos = I(T);
    tpos2 = I(T-200);
    [Pisort, I ] = sort(abs(PiSimSmooth));
    tzero = I(1);
    tlow = I(200);
    clear Pisort I;
    tizero = strcat(' \pi = ',num2str(PiSimSmooth(tzero,1)));
    tilow = strcat(' \pi = ',num2str(PiSimSmooth(tlow,1)));
    tipos = strcat(' \pi = ',num2str(PiSimSmooth(tpos,1)));
    tipos2 = strcat(' \pi = ',num2str(PiSimSmooth(tpos2,1)));
    subplot(2,2,1)
    hist([ndpstats(tzero,1:Ndown(tzero,1)) ndpstats(tzero,N-Nup(tzero,1)+1:end)],2000); title(tizero);
    subplot(2,2,2)
    hist([ndpstats(tlow,1:Ndown(tlow,1)) ndpstats(tlow,N-Nup(tlow,1)+1:end)],2000); title(tilow);
    subplot(2,2,3)
    hist([ndpstats(tpos2,1:Ndown(tpos2,1)) ndpstats(tpos2,N-Nup(tpos2,1)+1:end)],2000); title(tipos2);
    h = subplot(2,2,4);
    hist([ndpstats(tpos,1:Ndown(tpos,1)) ndpstats(tpos,N-Nup(tpos,1)+1:end)],2000); title(tipos);saveas(gcf,'Graphs\MC\histpc.png');
end



%Histogram of real prices for periods of different inflation
disphistrp = 1;
if disphistrp == 1
    [Pisort, I] = sort(PiSimSmooth);
    tneg = I(1);
    tpos = I(T);
    tpos2 = I(T-200);
    [Pisort, I ] = sort(abs(PiSimSmooth));
    tzero = I(1);
    tlow = I(200);
    clear Pisort I;
    tizero = strcat('Real price dispersion, all, \pi = ',num2str(PiSimSmooth(tzero,1)), ',SDrp = ',num2str(SDrpall(tzero,1)));
    tilow = strcat('Real price dispersion, all, \pi = ',num2str(PiSimSmooth(tlow,1)), ',SDrp = ',num2str(SDrpall(tlow,1)));
    tipos = strcat('Real price dispersion, all,  \pi = ',num2str(PiSimSmooth(tpos,1)), ',SDrp = ',num2str(SDrp(tpos,1)));
    tipos2 = strcat('Real price dispersion, all, \pi = ',num2str(PiSimSmooth(tpos2,1)), ',SDrp = ',num2str(SDrp(tpos,1)));
    subplot(2,2,1)
    hist(rpSim(tzero,:),100);title(tizero);
    subplot(2,2,2)
    hist(rpSim(tlow,:),100);title(tilow)
    subplot(2,2,3)
    hist(rpSim(tpos2,:),100);title(tipos2);
    h = subplot(2,2,4);
    hist(rpSim(tpos,:),100);title(tipos); saveas(h,'Graphs\MC\histrp.png');
end

%Sample price path
plot((1:300),npSim(401:700,3050),'r',(1:300),PSim(401:700,1),'b');xlabel('Period');ylabel('Price');title('Model Sample Price Path');Legend('P_{t}(i)','P_t','Location','SouthEast');saveas(gcf,'C:\Users\Daniel\Documents\Advanced Macro TA\GLpricepath.jpg')


 
    