
function [stdx,iqrx] = SimulateRelativesRRKillingProds(GE1Model)


%% Set-up, loading the parameters and policy function
time1 = cputime;

%Load objects from model solution
G = GE1Model.G;
F = GE1Model.F;
F_c = GE1Model.F_c;
Q = GE1Model.Q;
theta = GE1Model.theta;
mu = GE1Model.mu;
sigma_eta = GE1Model.sigma_eta;
sigma_eps = GE1Model.sigma_eps;
rho = GE1Model.rho;
a = GE1Model.a;
rp = GE1Model.rp;
rad = GE1Model.rad;
GInd = CalculateGInd(a,rp,rad,G);
T = 30;%Number periods
N = 300;%Number of firms
burnin = 200;%Periods of burning to be discarded
Die = zeros(T+burnin+1,N) ;
Die(1,:) = ones(1,N) ;
rndm = rand(T+burnin+1,N) ;
for tt=2:T+burnin+1
            Die(tt,:) = (rndm(tt,:)<0.0277) ; % Retrieve products.
end

%Grid parameters
amax = a(end,1);
amin = a(1,1);
agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
rpmax = rp(end,1);
rpmin = rp(1,1);
rpinc = (rpmax-rpmin)/(rpgridsize-1);
radmax = rad(end,1);
radmin = rad(1,1);

%% Smooth G and rad, to obtain a smooth inflation grid
nhh = 2.2; % bandwidth of kernel smoother (number of rad points/2)
radincsmooth = 10^(-6);
GError = GE1Model.GError;
radinc = rad(2)-rad(1);
hh = nhh*radinc;
AddN = hh/radinc - mod(hh/radinc,1);
radLong = rad;
GplusError = G + GError;
GLong = GplusError;
for i = 1:AddN
    radLong = [rad(1)-i*radinc; radLong; rad(end)+i*radinc];
    GLong = [GplusError(1) - GplusError(1+i) + GplusError(1); ...
        GLong; GplusError(end) - GplusError(end-i) + GplusError(end)];
end

Nsmooth = (rad(end)-rad(1))/radincsmooth + 1;
radSmooth = (rad(1):radincsmooth:rad(end))';
GSmooth = KernelSmoother(hh,radLong,GLong,radSmooth);

% Put GSmooth on radSmooth grid
%********************************************************
 
radSmoothinc = radSmooth(2) - radSmooth(1);
GSmooth_mod = mod(GSmooth,radSmoothinc);
GSmooth_mod_up = (GSmooth_mod > radSmoothinc/2);
GSmooth = GSmooth + GSmooth_mod_up.*(radSmoothinc-GSmooth_mod) ...
    - (1-GSmooth_mod_up).*GSmooth_mod;

%%
%Simulate time series for a for each firm
%***************************

aSim = zeros(T+burnin+1,N);%Simulated value of logA
a_inc = (amax-amin)/(agridsize-1);
eps_a = sigma_eps*randn(T+burnin,N);%Series of a shocks
aSim(1,:) = repmat(a(agridsize/2 -mod(agridsize/2,1) + 1,:),1,N);
for i = 1:(T+burnin)%Sequentially create value of a, adjusted to be a value in grid
    delta_a = (rho-1)*aSim(i,:) + eps_a(i,:);
    delta_a_mod = mod(delta_a,a_inc);
    delta_a_mod_big = (a_inc/2 < delta_a_mod);
    delta_a_mod_small = (a_inc/2 >= delta_a_mod);
    delta_a_grid = delta_a - delta_a_mod_small.*delta_a_mod ...
        + delta_a_mod_big.*(a_inc-delta_a_mod);
    aSim(i+1,:) = aSim(i,:) + delta_a_grid;
    aSim(i+1,:) = min(aSim(i+1,:),amax);
    aSim(i+1,:) = max(aSim(i+1,:),amin).*(1-Die(i+1,:)) + Die(i+1,:).*max(min(randn(1,N)*sqrt(sigma_eps^2/(1-rho^2)),amax),amin);
end
aSim_ind = int32((aSim - amin*ones(T+burnin+1,N))/a_inc + 1);%Index on a grid corresponding to simulated values
clear eps_a delta_a delta_a_mod delta_a_mod_big delta_a_mod_small delta_a_grid

%Simulate inflation & RAD
%******************
radinc = (radmax - radmin)/(radgridsize - 1);
eps_eta = sigma_eta*randn(T+burnin+1,1); %NAD shocks
P = zeros(T + burnin + 1,1);%initialize price level, inflation, RAD vectors
Pi = zeros(T + burnin + 1,1);
Simrad = zeros(T + burnin + 1,1);
rad_init = rad(ceil(radgridsize/2));%RAD in t=-1
dS = zeros(T + burnin + 1,1);
dS(1,1) = mu + eps_eta(1,1);%Initial NAD innovation, adjusted to be on grid
dS_mod = mod(dS(1,1),radinc);
dS_mod_big = radinc/2 < dS_mod;
dS_mod_small = radinc/2 >= dS_mod;
dS_grid = dS(1,1) - dS_mod_small*dS_mod + dS_mod_big*(radinc - dS_mod);
rad_pre = zeros(T+burnin+1,1);
%Calculate S_0/P_-1 to predict P_0/P_-1 using G
rad_pre(1,1) = dS_grid + rad_init;
rad_pre(1,1) = min(radmax,rad_pre(1,1));
rad_pre(1,1) = max(radmin,rad_pre(1,1));
Pi(1,1) = G(int32((rad_pre(1,1)-radmin)/radinc + 1));
P(1,1) = Pi(1,1);
Simrad(1,1) = rad_pre(1,1) - Pi(1,1);
Simrad(1,1) = min(radmax,Simrad(1,1));
Simrad(1,1) = max(radmin,Simrad(1,1));
for i = 2:(T+burnin+1)
    dS(i,1) = mu + eps_eta(i,1);%Current period's NAD innovation
    dS_mod = mod(dS(i,1),radinc);%Made to fit on grid
    dS_mod_big = radinc/2 < dS_mod;
    dS_mod_small = radinc/2 >= dS_mod;
    dS_grid = dS(i,1) - dS_mod_small*dS_mod + dS_mod_big*(radinc-dS_mod);
    rad_pre(i,1) = dS_grid + Simrad(i-1,1);%Added to last period's RAD
    rad_pre(i,1) = min(radmax,rad_pre(i,1));
    rad_pre(i,1) = max(radmin,rad_pre(i,1));
    Pi(i,1) = G(int32((rad_pre(i,1)-radmin)/radinc + 1));%Inflation calculated using G
    P(i,1) = Pi(i,1) + P(i-1,1);
    Simrad(i,1) = rad_pre(i,1) - Pi(i,1);
    Simrad(i,1) = min(radmax,Simrad(i,1));
    Simrad(i,1) = max(radmin,Simrad(i,1));
end
clear eps_eta rad_init dS_mod dS_mod_big dS_mod_small dS_grid
%Indexes of RAD and S_t/P_t-1 (used to predict inflation) on grid
rad_pre_ind = int32((rad_pre-radmin)/radinc + 1);
rad_ind = int32((Simrad-radmin)/radinc + 1);

%Get smooth inflation series
SimradSmooth = zeros(T + burnin + 1,1);
PiSmooth = zeros(T + burnin + 1,1);
PSmooth = zeros(T + burnin + 1,1);
rad_preSmooth = zeros(T + burnin + 1,1);
radinit = rad(ceil(radgridsize/2));
dS_mod = mod(dS(1,1),radSmoothinc);
dS_mod_big = radSmoothinc/2 < dS_mod;
dS_mod_small = radSmoothinc/2 >= dS_mod;
dS_grid = dS(1,1) - dS_mod_small*dS_mod + dS_mod_big*(radSmoothinc - dS_mod);
rad_preSmooth(1,1) = dS_grid + radinit;
rad_preSmooth(1,1) = min(radmax,rad_preSmooth(1,1));
rad_preSmooth(1,1) = max(radmin,rad_preSmooth(1,1));
PiSmooth(1,1) = GSmooth(min(int32((rad_preSmooth(1,1)-radmin)/radSmoothinc + 1),length(GSmooth)));
PSmooth(1,1) = Pi(1,1);
SimradSmooth(1,1) = rad_preSmooth(1,1) -PiSmooth(1,1);
SimradSmooth(1,1) = min(radmax,SimradSmooth(1,1));
SimradSmooth(1,1) = max(radmin,SimradSmooth(1,1));
for i = 2:(T + burnin + 1)
    dS_mod = mod(dS(i,1),radSmoothinc);
    dS_mod_big = radSmoothinc/2 < dS_mod;
    dS_mod_small = radSmoothinc/2 >= dS_mod;
    dS_grid = dS(i,1) - dS_mod_small*dS_mod + dS_mod_big*(radSmoothinc - dS_mod);
    rad_preSmooth(i,1) = dS_grid + SimradSmooth(i-1,1);
    rad_preSmooth(i,1) = min(radmax,rad_preSmooth(i,1));
    rad_preSmooth(i,1) = max(radmin,rad_preSmooth(i,1));
    disp(int32((rad_preSmooth(i,1)-radmin)/radSmoothinc + 1));
    PiSmooth(i,1) = GSmooth(min(int32((rad_preSmooth(i,1)-radmin)/radSmoothinc + 1),length(GSmooth)));
    PSmooth(i,1) = Pi(i,1) + PSmooth(i-1,1);
    SimradSmooth(i,1) = rad_preSmooth(i,1)- PiSmooth(i,1);
    SimradSmooth(i,1) = min(radmax,SimradSmooth(i,1));
    SimradSmooth(i,1) = max(radmin,SimradSmooth(i,1));
end

%Simulate firm prices
%********************
rpSim = zeros(T+burnin+1,N);
rpcSim = zeros(T+burnin+1,N);
state_pre_ind = sub2ind([agridsize rpgridsize radgridsize],int32((aSim_ind(1,:))'),int32(repmat(ceil(rpgridsize/2),N,1)),int32(repmat(rad_pre_ind(1,1),N,1)));
state_post_ind = GInd(state_pre_ind);
rpSim(1,:) = F(state_post_ind');
rpcSim(1,:) = F_c(state_post_ind');
rpSimDef(1,:) = rpSim(1,:) ;
for i = 2:(T+burnin+1)
    state_pre_ind = sub2ind([agridsize rpgridsize radgridsize], int32(aSim_ind(i,:)'),int32((rpSim(i-1,:)'-rpmin)/rpinc + 1),int32(repmat(rad_pre_ind(i,1),N,1)));
    state_post_ind = GInd(state_pre_ind);
    rpSim(i,:) = F(state_post_ind');
    rpcSim(i,:) = F_c(state_post_ind');
    rpSimDef(i,:) =  rpSim(i,:).*(1-Die(i,:)) + rpcSim(i,:).*Die(i,:) ;
end
npSimDef = rpSimDef + repmat(P,1,N);
npcSim = rpcSim + repmat(P,1,N);
x1 = npSimDef -  repmat(P,1,N) - repmat(log(mean(exp(npSimDef)./exp(repmat(P,1,N)))),[T+burnin+1,1]) ;

stdx = median(std(x1')');
iqrx = median(prctile(x1',75)' - prctile(x1',25)') ;
scatter_to_save = [reshape(rpSim(burnin:end,:),[numel(rpSim(burnin:end,:)) 1]) reshape(rpcSim(burnin:end,:),[numel(rpSim(burnin:end,:)) 1]) reshape(x1(burnin:end,:),[numel(rpSim(burnin:end,:)) 1])] ;

save('output_codes/fixed_effect_price_gap','scatter_to_save')



