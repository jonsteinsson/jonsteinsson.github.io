% Smooth output from models using polynomial regression
%
% Emi Nakamura and Jon Steinsson, Oct 2015
%**********************************************************************

function StatsSmooth = SmoothStats(Stats,dd)

XX = Stats.infl.^0;
for jj = 1:dd
    XX = [XX Stats.infl.^jj];
end

bb = regress(Stats.ineffpdisp,XX);
StatsSmooth.ineffpdisp = XX*bb;

bb = regress(Stats.lprod,XX);
StatsSmooth.lprod = XX*bb;

bb = regress(Stats.lprod2nd,XX);
StatsSmooth.lprod2nd = XX*bb;

bb = regress(Stats.lprodFlex,XX);
StatsSmooth.lprodFlex = XX*bb;

bb = regress(Stats.stdLogOutput,XX);
StatsSmooth.stdLogOutput = XX*bb;

bb = regress(Stats.meanLogOutput,XX);
StatsSmooth.meanLogOutput = XX*bb;

bb = regress(Stats.FlexLogOutput,XX);
StatsSmooth.FlexLogOutput = XX*bb;

bb = regress(Stats.FlexLabor,XX);
StatsSmooth.FlexLabor = XX*bb;

bb = regress(Stats.lprodFlex,XX);
StatsSmooth.lprodFlex = XX*bb;

bb = regress(Stats.prodwedge,XX);
StatsSmooth.prodwedge = XX*bb;

bb = regress(Stats.meanp,XX);
StatsSmooth.meanp = XX*bb;

bb = regress(Stats.meanL,XX);
StatsSmooth.meanL = XX*bb;

bb = regress(Stats.pccost,XX);
StatsSmooth.pccost = XX*bb;

bb = regress(Stats.avmarkup,XX);
StatsSmooth.avmarkup = XX*bb;

bb = regress(Stats.welfareLossIgnoreUncert,XX);
StatsSmooth.welfareLossIgnoreUncert = XX*bb;
