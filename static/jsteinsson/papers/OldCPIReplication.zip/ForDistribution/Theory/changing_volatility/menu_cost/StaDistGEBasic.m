% Calculates the stationary distribution for the menu cost model
%
% Q_old is the initial probability distribution.
% 
% Jon Steinsson and Emi Nakamura, July 2006
%***************************************************************

function Q_new = StaDistGEBasic(Q_old,Proba,ProbNgr,F,G,a,rp,rad,...
    tol,yesprint)

agridsize = size(a,1);
rpgridsize = size(rp,1);
radgridsize = size(rad,1);
Ssize = agridsize*rpgridsize*radgridsize;

Q_old = reshape(Q_old,[Ssize 1]);
F = reshape(F,[Ssize 1]);

% Calculate GInd
%**********************************************************************
% GInd is a vector that describes how dividing by inflation moves firms 
% in certain states to new states.

GInd = CalculateGInd(a,rp,rad,G);

% Calculate Find
%**********************************************************************
% FInd is a vector that describes how applying F moves firms in certain
% states to new states.

QaInd = repmat((1:agridsize)',rpgridsize*radgridsize,1);

QradInd = repmat((1:radgridsize)',[1 agridsize rpgridsize]);
QradInd = permute(QradInd,[2 3 1]);
QradInd = reshape(QradInd,[Ssize 1]);

[dummy,QrpInd] = ismember(int32(F*10^8),int32(rp*10^8));
clear dummy
%QrpInd = match(int32(F*10^6),int32(rp*10^6));
FInd = sub2ind([agridsize rpgridsize radgridsize],QaInd,QrpInd,QradInd);
clear QaInd QrpInd QradInd

% Sort GInd and FInd
%**********************************************************************

OldFInd = (1:Ssize)';

[GInd iGInd] = sort(GInd);
OldGInd = OldFInd(iGInd);

[FInd iFInd] = sort(FInd);
OldFInd = OldFInd(iFInd);

% Calculate stationary distribution
%**********************************************************************

time23 = clock;
Q_new = Q_old;
i = 1;
supDifQ = 2*tol;
while supDifQ > tol
    %fprintf('supDifQ = %5.10f  tol = %5.10f\n',supDifQ,tol)
    Q_old = Q_new;

    % Apply F
    Q_new = accumarray(FInd,Q_new(OldFInd));
    Q_new = [Q_new; zeros(size(Q_old,1)-size(Q_new,1),1)];
    
    % Apply Proba
    Q_new = ((reshape(Q_new,agridsize,rpgridsize*radgridsize)')*Proba)';
    
    % Apply ProbNgr
    Q_new = reshape(Q_new,[agridsize*rpgridsize radgridsize])*ProbNgr;
    Q_new = reshape(Q_new,[Ssize 1]);    
    
    % Apply G
    Q_new = accumarray(GInd,Q_new(OldGInd));
    Q_new = [Q_new; zeros(size(Q_old,1)-size(Q_new,1),1)];
    
    supDifQ = max(abs(Q_old-Q_new));
    
    if yesprint == 1
        if mod(i,5) == 0
            fprintf('$')
        end
        if mod(i,400) == 0
            fprintf('\n')
        end
    end
    i = i + 1;
end
if yesprint == 1
    time24 = clock;
    fprintf('\n\n')
    fprintf('Time of Loop: %8.3f\n\n',etime(time24,time23))
end

    
    

