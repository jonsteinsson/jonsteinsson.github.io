% Creates the probability distribution for movements in the real price
% due to inflation
%
% ProbInfl is a matrix that gives the transition probabilities of 
% the real price due to inflation for a fixed nominal price
%
% ProbInfl give the probabilities of going from state rp to state 
% rp', i.e. ProbInfl(i,j) = Prob(rp' = j | rp = i)
%
% The evolution of the price level is governed by:
% log(P_t) - log(P_t-1) = mu + eta_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
%
% The exact distribution is approximated using a 
% method analogous to the Tauchen (1986) method for AR models
%
% The three imputs are:
% 1. Average inflation rate
% 2. St. Dev. of shocks to inflation (sigma_eta)
% 3. Grid for rp
%
% Jon Steinsson and Emi Nakamura, May 2006
%*************************************************************

function ProbInfl = CreateProbInfl(mu,sigma_eta,rp_grid)

rpgridsize = size(rp_grid,1);

rp_old = repmat(rp_grid-mu,1,rpgridsize-1);
sigma_eta_matrix = repmat(sigma_eta,rpgridsize,rpgridsize-1);

rp_j = (rp_grid(1:end-1,1)+rp_grid(2:end,1))/2;
rp_j_matrix = repmat(rp_j',rpgridsize,1);

rp_norm = normcdf(rp_j_matrix,rp_old,sigma_eta_matrix);

rp_norm_up = [rp_norm ones(rpgridsize,1)];
rp_norm_dwn = [zeros(rpgridsize,1) rp_norm];

ProbInfl = rp_norm_up - rp_norm_dwn;

ProbInfl = ProbInfl.*(ProbInfl > 10^(-6));

