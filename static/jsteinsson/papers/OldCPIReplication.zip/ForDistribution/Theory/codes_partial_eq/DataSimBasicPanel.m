% Simulates data from the menu cost model with:
%
% 1. Constant aggregate demand
% 2. I.i.d. normal growth of the price level (non-zero mean)
% 3. AR(1)-normal idiosyncratic productivity shocks with homoskedastic errors
%
% Inputs:
%   Nfirms: Number of firms for which the model is simulated
%   Inflation: The time path of aggregate inflation over the simulation
%       period
%   burnin: Number of time periods at the start of the simulation that are
%      dropped
%   a: Grid for a (idiosyncratic tech shock)
%   rp: Grid for the real price
%   rho: Autoregressive coefficient in process for a_t
%   sigma_eps: Standard deviation of shocks to a_t process
%   mu: Average monthly inflation rate
%   sigma_eta: Standard deviation of shocks to the price level
%   F: The policy function
%   tfunc: If tfunc == 1 then the function prints out the time it takes to run
%   yesprint: If yesprint == 1 then the function prints 'progress reports'
%
% Outputs: XXXXX Revise this XXXXX
%   aSim: Simulated series for a (idiosyncratic tech shock)
%   InflSim: Simulated series for monthly inflation
%   rpSim: Simulated series for the real price
%   npSim: Simulated series for the nominal price
%   ncostSim: Simulated series for log(P_t)-log(A_it)
%   InflSim_sum: Simulated series for the nominal price level
%
% Notice: If this function starts printing out 'x' or 'y' it means that
% the grid for rp does not cover a large enough area.
%
% Jon Steinsson and Emi Nakamura, May 2006
%**********************************************************

function modelOut = DataSimBasicPanel(Nfirms,InflReal,Tburn,aa,rp,rho, ...
                         sigma_eps,mu,sigma_eta,F,tfunc,yesprint)

time1 = cputime;

% Total number of periods to simulate
TSim = size(InflReal,1);
TT   = TSim + Tburn;

% Calculate gridsize for aa
amax = aa(end,1);
amin = aa(1,1);
agridsize = size(aa,1);

% Calculate gridsize for rp
rpmax = rp(end,1);
rpmin = rp(1,1);
rpgridsize = size(rp,1);

if yesprint == 1
    fprintf('\n')
    fprintf('Data Simulation Starts\n')
end

%% Create Inflation Series 
%******************************

% Simulate a time series for inflation for burnin period 
% and put it on the grid
Infl_inc = (rpmax-rpmin)/(rpgridsize-1);
nu = sigma_eta*randn(Tburn,1);
InflSim = mu + nu;
InflSim_mod = mod(InflSim,Infl_inc);
InflSim_mod_big = Infl_inc/2 < InflSim_mod;
InflSim_mod_small = Infl_inc/2 >= InflSim_mod;
InflSim = InflSim - InflSim_mod_small.*InflSim_mod ...
    + InflSim_mod_big.*(Infl_inc-InflSim_mod);
InflSim_num = int32(InflSim/Infl_inc);

% Put real world inflation on the grid
modelOut.Infl = InflReal;   % SAVE real inflation
InflReal_mod = mod(InflReal,Infl_inc);
InflReal_mod_big = Infl_inc/2 < InflReal_mod;
InflReal_mod_small = Infl_inc/2 >= InflReal_mod;
InflReal = InflReal - InflReal_mod_small.*InflReal_mod ...
    + InflReal_mod_big.*(Infl_inc-InflReal_mod);
InflReal_num = int32(InflReal/Infl_inc);
modelOut.InflGrid = InflReal; % SAVE real inflation on grid

% Combine InflSim and InflReal
Infl = [InflSim; InflReal];
Infl_num = [InflSim_num; InflReal_num];

%% Simulate a time series for a
%******************************

aSim = zeros(TT,Nfirms);
a_inc = (amax-amin)/(agridsize-1);
eps_a = sigma_eps*randn(TT,Nfirms);
aSim(1,:) = aa((agridsize/2 - mod(agridsize/2,1) + 1),1);
for ii = 2:TT
    delta_a = (rho-1)*aSim(ii-1,:) + eps_a(ii,:);
    delta_a_mod = mod(delta_a,a_inc);
    delta_a_mod_big = a_inc/2 < delta_a_mod;
    delta_a_mod_small = a_inc/2 >= delta_a_mod;
    delta_a_grid = delta_a - delta_a_mod_small.*delta_a_mod ...
        + delta_a_mod_big.*(a_inc-delta_a_mod);
    aSim(ii,:) = aSim(ii-1,:) + delta_a_grid;
    aSim(ii,:) = min(amax,aSim(ii,:));
    aSim(ii,:) = max(amin,aSim(ii,:));
end
aSim_num = int32((aSim - amin*ones(TT,Nfirms))/a_inc+1);

%% Simulate a time series for rp
%*****************************

rpSim = zeros(TT,Nfirms);
rpSim_num = zeros(TT,Nfirms);
rp_inc = (rpmax-rpmin)/(rpgridsize-1);
rpSim(1,:) = rp((rpgridsize/2 - mod(rpgridsize/2,1) + 1),1);
rpSim_num(1,:) = (rpSim(1,1) - rpmin)/rp_inc+1;
for ii = 2:TT
    % Adjust for inflation
    pre_adj_rp_num = rpSim_num(ii-1,:) - double(Infl_num(ii,1));
    if pre_adj_rp_num > rpgridsize
        pre_adj_rp_num = rpgridsize;
        fprintf('x ')
    end
    if pre_adj_rp_num < 1
        pre_adj_rp_num = 1;
        fprintf('y ')
    end
    
    % Calculate new price
    Findex = sub2ind(size(F),int32(pre_adj_rp_num),int32(aSim_num(ii,:)));
    rpSim(ii,:) = F(Findex);
    rpSim_num(ii,:) = int32((rpSim(ii,:) - rpmin)/rp_inc+1);
end

%% Create Nominal Price Data
%**************************

npSim = zeros(TT,Nfirms);
ncostSim = zeros(TT,Nfirms);
Infl_sum = zeros(TT,1);
npSim(1,:) = rpSim(1,:);
ncostSim(1,:) = -aSim(1,:);
for ii = 2:TT
    Infl_sum(ii,1) = Infl_sum(ii-1,1) + Infl(ii,1);
end
npSim(2:end,:) = rpSim(2:end,:) + repmat(Infl_sum(2:end,1),1,Nfirms);
ncostSim(2:end,:) = -aSim(2:end,:) + repmat(Infl_sum(2:end,1),1,Nfirms);

if tfunc == 1
    fprintf('\n')
    fprintf('Time of Data Simulation: %5.2f\n',cputime - time1)
end
if yesprint == 1
    fprintf('Data Simulation Ends\n')
end

% Plot an example
% figure(101)
% plot(1:TT,npSim(:,100),'b-',1:TT,ncostSim(:,100),'r-',1:TT,Infl_sum,'g-')

%% Drop burnin
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We leave the last burnin period so as to be able to create price change
% data for the first real data period

aSim     = aSim(Tburn:end,:);
rpSim    = rpSim(Tburn:end,:);
npSim    = npSim(Tburn:end,:);
ncostSim = ncostSim(Tburn:end,:);
Infl_sum = Infl_sum(Tburn:end,:);

%% Save output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

modelOut.aSim = aSim;
modelOut.rpSim = rpSim;
modelOut.npSim = npSim;
modelOut.ncostSim = ncostSim;
modelOut.cpiGrid = Infl_sum;


