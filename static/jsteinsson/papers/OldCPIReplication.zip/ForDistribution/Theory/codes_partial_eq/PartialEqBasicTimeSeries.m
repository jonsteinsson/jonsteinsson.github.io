% Solves a simple partial equilibrium menu cost model by Bellman function 
% iteration on a grid.
%
% Calculates time series plots of the frequency and size of price changes
% in the data and the model.
%
% 1. Constant aggregate demand
% 2. I.i.d. growth of the price level (non-zero mean)
% 3. AR(1)-normal idiosyncratic productivity shocks
% 4. Homoskedastic errors
%
% This model has two state variables: the idiosyncratic level of
% productivity and the firms own relative price.
%
% Emi Nakamura, Jon Steinsson, Daniel Villar, Patrick Sun
% April 2015
%**************************************************************

clear; close all;
tic

%% Set Parameters
%**************************************************************

% Simulation Parameters
Nfirms = 20000;       % Number of firms to be simulated
Tburn  = 50;          % Number of periods of burnin

% Model Parameters
theta = 4;            % Elasticity of demand
beta = 0.96^(1/12);   % Discount factor
K = 0.018; %0.019;         % Menu Cost

% Parameters of the idiosyncratic productivity process (log A_it)
% log(A_it) = rho*log(A_it-1) + eps_it
% where eps_it ~ N(0,sigma_eps^2), i.i.d. 
% The process is truncated at +/- trunc_eps multiples of the unconditional 
% standard deviation of log(A) 
rho = 0.7;
sigma_eps = 0.0365 ;%0.037;
trunc_eps = 3.2;

fprintf('\n')
fprintf('Idiosyncratic shocks:\n')
fprintf('rho:            %5.4f \n',rho)
fprintf('sigma_eps:      %5.4f \n\n',sigma_eps)

% Import aggregate inflation data
% Sample period 1947:01-2015:09
PP = xlsread('Data/CPInoshelt_full.xlsx'); % non-shelter CPI
cpi = log(PP(:,3));
cpi = cpi(156:816,1); % Keep data for 1959:12 - 2014:12.

Tyears = 2014-1959;   % Number of years to simulate
TTyears = 1978:2014;  % List of years to plot
TTyearsNN = (1978-1959):1:(2014-1959); % Years to plot from output

% Parameters of the process followed by the inflation rate (log(P_t/P_t-1))
% log(P_t) - log(P_t-1) = mu + nu_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
mu = mean(cpi(2:end,1)-cpi(1:end-1,1));
sigma_eta = std(cpi(2:end,1)-cpi(1:end-1,1));
inflationrate = (1+mu)^12-1;
minfl = cpi(2:end,1)-cpi(1:end-1,1) ;


fprintf('Inflation:\n')
fprintf('Annual inflation rate:     %3.2f percent \n',inflationrate*100)
fprintf('mu:                        %5.5f \n',mu)
fprintf('sigma_eta:                 %5.5f \n\n',sigma_eta)

% Number of points on the grid for the two state variables
% a denotes idiosyncratic productivity
% rp denotes the real price
agridsize = 50;
rpgridsize = 1000;

%% Create the real price and idiosyncratic productivity vectors
%**************************************************************

% Max and Min point for the grid of "a"
amax = trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
amin = -trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
ainc = (amax-amin)/(agridsize-1) - mod((amax-amin)/(agridsize-1),10^(-7));
amin = amin - mod(amin,10^(-7));
amax = amin + (agridsize-1)*ainc;

% Span of rp grid relative to a grid
rp_span = 1.5;

% rp denotes the real price
% np denotes the nominal price
% The rp grid is a grid for the log of the real price
rpmax = -amin*rp_span;
rpmin = -amax*rp_span;
if rpmax < 0.15
    rpmax = 0.15;
    rpmin = -0.15;
end
rpinc = (rpmax-rpmin)/(rpgridsize-1) - mod((rpmax-rpmin)/(rpgridsize-1),10^(-7));
rpmin = rpmin - mod(rpmin,10^(-7));
rpmax = rpmin + (rpgridsize-1)*rpinc;

a = amin:ainc:amax; a = a';
rp = rpmin:rpinc:rpmax; rp = rp';

fprintf('amax = %5.4f   amin = %5.4f\n',amax,amin)
fprintf('rpmax = %5.4f  prmin = %5.4f\n\n',rpmax,rpmin)

%% Create Probability Distribution for the idiosyncratic shock
%**************************************************************
% Proba is a matrix that gives transition probabilities of going
% from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
% 
% The procedure of Tauchen (1986) is used to approximate the 
% AR(1) process for log(A_it)

Proba = CreateProba(rho,sigma_eps,a);

% fprintf('Proba(1:8,1:8) ')
% Proba(1:8,1:8)
%figure(101)
%surf(a,a,Proba)

%% Create Probability Distribution for movements in the real price
% due to inflation
%**************************************************************
% ProbInfl is a matrix that gives the transition probabilities of 
% the real price due to inflation when the nominal price is fixed
%
% ProbInfl gives the probabilities of going from state rp to state 
% rp', i.e. ProbInfl(i,j) = Prob(pr' = j | pr = i)
% 
% The exact distribution is approximated using a 
% method analogous to the Tauchen (1986) method for AR models

ProbInfl = CreateProbInfl(mu,sigma_eta,rp);

% fprintf('ProbInfl(1:8,1:8) ')
% ProbInfl(1:8,1:8)
%figure(102)
%surf(rp,rp,ProbInfl)

%% Calculate Profit function matrix
%**************************************************************
% Prices vary as one moves down each column
% Productivity varies as one moves across each row

rPi = (exp(rp).^(-theta+1)*ones(1,agridsize)...
    -exp(rp).^(-theta)*((theta-1)/theta)*(1./exp(a')));

%figure(103)
%surf(a,rp,rPi)
%title('Profit Function')

%% Initialize ErV matrix (Expected Value next period)
%**************************************************************

ErV = ones(rpgridsize,agridsize)*max(0,mean(mean(rPi))/(1-beta));

tolerance = 0.001;

% %fprintf('tolerance:     %10.6f\n',tolerance)
% %fprintf('min start ErV: %10.2f\n',min(min(ErV)))
% %fprintf('max start ErV: %10.2f\n',max(max(ErV)))


%% Bellman function iteration
%**************************************************************
% Here we iterate ErV

[rV,F] = VFIterationBasic(rPi,ErV,beta,K,theta,rp,Proba,ProbInfl,...
    tolerance,1,1);

%fprintf('Max rV: %8.3f\n',max(max(rV)))
%fprintf('Min rV: %8.3f\n',min(min(rV)))
%fprintf('Max Dif rV: %8.3f\n',max(max(rV))-min(min(rV)))

%figure(104)
%surf(a,rp,rV)
%title('Value Function');

% figure(105)
% surf(1./exp(a),exp(rp),exp(F))
% title('Policy Function');

%figure(106)
%[C,h] = contour(1./exp(a),exp(rp),exp(F));
%clabel(C,h);
%title('Policy Function');

%% Create inflation rate on the grid
%*****************************************************************

inflation = zeros(size(cpi,1)-1,1);
cum_inflation = zeros(size(cpi,1)-1,1);
rpint = rp(2)-rp(1);

cum_inflation(1) = cpi(2)-cpi(1);
inflation(1) = cum_inflation(1) - mod(cum_inflation(1),rpint);
for ii = 2:size(inflation,1)
    cum_inflation(ii) = cpi(ii+1)-cpi(1);
    inflation(ii) = cum_inflation(ii) - mod(cum_inflation(ii),rpint)...
        - sum(inflation(1:ii-1));
end

%% Simulate Data Set from the model
%************************************************************

modelOut = DataSimBasicPanel(Nfirms,inflation,Tburn,a,rp,rho, ...
                               sigma_eps,mu,sigma_eta,F,1,1);

%% Create Monthly Frequency Statistics
%***************************************************************

verySmall = 10^-8;

TT = size(modelOut.Infl,1);

modelOut.pc = (abs(modelOut.npSim(2:end,:)- modelOut.npSim(1:end-1,:)) > verySmall); % price change indicator
modelOut.pu = (modelOut.npSim(2:end,:) - modelOut.npSim(1:end-1,:) > verySmall);  % price increase indicator
modelOut.pd = (modelOut.npSim(1:end-1,:) - modelOut.npSim(2:end,:) > verySmall);  % price increase indicator
modelOut.sz = abs(modelOut.npSim(2:end,:) - modelOut.npSim(1:end-1,:)) ...
                 .*(abs(modelOut.npSim(2:end,:)- modelOut.npSim(1:end-1,:)) > verySmall); % Size of price changes
modelOut.szsqrd = modelOut.sz.^2 ;
modelOut.su = abs(modelOut.npSim(2:end,:) - modelOut.npSim(1:end-1,:)) ...
                 .*(modelOut.npSim(2:end,:) - modelOut.npSim(1:end-1,:) > verySmall); % Size of price increases
modelOut.sd = abs(modelOut.npSim(2:end,:) - modelOut.npSim(1:end-1,:)) ...
                 .*(modelOut.npSim(1:end-1,:) - modelOut.npSim(2:end,:) > verySmall); % Size of price increases
                           
%% Create Annual Output
%***************************************************************

modelOut.AnFreq = zeros(Tyears,1);
for ii = 1:Tyears
    firstPos = 12*(ii-1)+1;
    lastPos = 12*ii;
    modelOut.AnFreq(ii,1) = mean(mean(modelOut.pc(firstPos:lastPos,:)));
    modelOut.AnFreqUp(ii,1) = mean(mean(modelOut.pu(firstPos:lastPos,:)));
    modelOut.AnFreqDw(ii,1) = mean(mean(modelOut.pd(firstPos:lastPos,:)));
    tempSize = modelOut.sz(firstPos:lastPos,:);
    modelOut.AnAbsSize(ii,1) = mean(mean(tempSize(modelOut.pc(firstPos:lastPos,:))));
    tempSizeSqrd = modelOut.szsqrd(firstPos:lastPos,:); % added by Juan
    modelOut.AnAbsSizeSqrd(ii,1) = mean(mean(tempSizeSqrd(modelOut.pc(firstPos:lastPos,:)))); % Added by Juan
    modelOut.AnStdSize(ii,1) = (modelOut.AnAbsSizeSqrd(ii,1) - modelOut.AnAbsSize(ii,1)^2)^0.5 ; % Added by Juan
    tempSize = modelOut.su(firstPos:lastPos,:);
    modelOut.AnSizeUp(ii,1) = mean(mean(tempSize(modelOut.pu(firstPos:lastPos,:))));
    tempSize = modelOut.sd(firstPos:lastPos,:);
    modelOut.AnSizeDw(ii,1) = mean(mean(tempSize(modelOut.pd(firstPos:lastPos,:))));
    modelOut.AnInf(ii,1) = mean(modelOut.Infl(firstPos:lastPos)) ;
end
modelOut.AnInf = (modelOut.AnInf+1).^12 -1 ;
%% Input Data on Frequency and Size in the US economy
%*****************************************************************

% Average frequency and size over entire period by Major Group
Data = csvread('Data/MGmeans.csv');
FreqMGdata = Data(:,2);
SizeMGdata = Data(:,3);

freqseries = csvread('Data/Freqall.csv',1,1);
DataOut.AnFreq   = freqseries(2:end,1); % Freq by year for all goods in the US data
DataOut.AnFreqUp = freqseries(2:end,2); % FreqUp by year for all goods in the US data
DataOut.AnFreqDw = freqseries(2:end,3); % FreqDw by year for all goods in the US data
DataOut.AnAbsSize= freqseries(2:end,4); % Size by year for all goods in the US data
DataOut.AnSizeUp = freqseries(2:end,5); % SizeUp by year for all goods in the US data
DataOut.AnSizeDw = freqseries(2:end,6); % SizeDw by year for all goods in the US data

%% Plot and Print Output
%********************************************************************

fprintf('\n')
fprintf('           Data     Model\n')
fprintf('Freq     = %5.2f    %5.2f\n',FreqMGdata(14,1),mean(modelOut.AnFreq))
fprintf('Abs Size = %5.2f    %5.2f\n',SizeMGdata(14,1),mean(modelOut.AnAbsSize))
fprintf('\n')

% Code to use gridLegend for multicolum legends
%legend_str = ['Freq Model     ';'Freq Up Model  ';'Freq Down Model'; ...
%       'Freq Data      '; 'Freq Up Data   ' ;'Freq Down Data '];
%legHdl = gridLegend(p,3,legend_str,'location','north');

% Plot an example
figure(1)
subplot(2,3,1)
p1 = plot(TTyears,modelOut.AnFreq(TTyearsNN,1),'b-',TTyears,DataOut.AnFreq,'r-');    
legend('Freq Model','Freq Data','Location','NorthEast')
set(p1,'LineWidth',2)
ylim([0 0.2])
xlim([TTyears(1) TTyears(end)])

subplot(2,3,2)
p2 = plot(TTyears,modelOut.AnFreqUp(TTyearsNN,1),'b-',TTyears,DataOut.AnFreqUp,'r-');    
legend('Freq Up Model','Freq Up Data','Location','NorthEast')
set(p2,'LineWidth',2)
ylim([0 0.2])
xlim([TTyears(1) TTyears(end)])

subplot(2,3,3)
p3 = plot(TTyears,modelOut.AnFreqDw(TTyearsNN,1),'b-',TTyears,DataOut.AnFreqDw,'r-');    
legend('Freq Down Model','Freq Down Data','Location','NorthEast')
set(p3,'LineWidth',2)
ylim([0 0.2])
xlim([TTyears(1) TTyears(end)])

subplot(2,3,4)
p4 = plot(TTyears,modelOut.AnAbsSize(TTyearsNN,1),'b-',TTyears,DataOut.AnAbsSize,'r-');    
legend('Size Model','Location','NorthEast')
set(p4,'LineWidth',2)
ylim([0 0.2])
xlim([TTyears(1) TTyears(end)])

subplot(2,3,5)
p5 = plot(TTyears,modelOut.AnSizeUp(TTyearsNN,1),'b-',TTyears,DataOut.AnSizeUp,'r-');    
legend('Size Up Model','Location','NorthEast')
set(p5,'LineWidth',2)
ylim([0 0.2])
xlim([TTyears(1) TTyears(end)])

subplot(2,3,6)
p6 = plot(TTyears,modelOut.AnSizeDw(TTyearsNN,1),'b-',TTyears,DataOut.AnSizeDw,'r-');    
legend('Size Down Model','Location','NorthEast')
set(p6,'LineWidth',2)
ylim([0 0.2])
xlim([TTyears(1) TTyears(end)])
savefig('output_codes/Fig15.fig')


figure(2)
p7 = scatter(modelOut.AnInf,modelOut.AnFreq) ;
savefig('output_codes/ScatterFreqBasic.fig')

figure(3)
p8 = scatter(modelOut.AnInf,modelOut.AnAbsSize) ;
savefig('output_codes/ScatterSizeBasic.fig')

figure(4)
p8 = scatter(modelOut.AnInf,modelOut.AnStdSize) ;
savefig('output_codes/ScatterStdBasic.fig')

toc



