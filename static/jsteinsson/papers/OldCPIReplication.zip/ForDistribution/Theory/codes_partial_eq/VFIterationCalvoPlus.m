% Value Function Iteration for a CalvoPlus model with:
%
% 1. Constant aggregate demand
% 2. I.i.d. normal growth of the price level (non-zero mean)
% 3. AR(1)-normal idiosyncratic productivity shocks with homoskedastic errors
%
% Inputs:
%    rPi: The profit function
%    ErV: An initial guess for ErV (the expected value function)
%    beta: the discount factor
%    K: The menu cost in high menu cost state
%    K2: The menu cost in low menu cost state
%    alphaCalvo: 1 minus probability of low menu cost state
%    theta: Elasticity of demand
%    rp: The grid for the real price
%    Proba: The probability transition matrix for a (the idiosyncratic shock)
%    probInfl: The probability transition matrix for the real price
%       conditional on no nominal price change
%    tolerance: The error tolerance level of the iteration loop
%    tloop: If one the program prints the time the loop took
%    yesprint: If yesprint == 1 then the function prints 'progress reports'
%
% Outputs:
%    rV: The real valued value function
%    F:  The policy function in high menu cost state (log price)
%    F2: The policy function in low menu cost state (log price)
%
% Jon Steinsson and Emi Nakamura, August 2015
%********************************************************

function [rV,F,F2] = VFIterationCalvoPlus(rPi,ErV,beta,K,K2,alphaCalvo,theta,a,rp,Proba,ProbInfl,...
    tolerance,tloop,yesprint)

if yesprint == 1
    fprintf('Start Value Function Iteration \n')
end

rpgridsize = size(ProbInfl,1);
agridsize = size(Proba,1);

time1 = cputime;
i = 1;
ErV_new = ErV;
ErV_old = zeros(rpgridsize,agridsize);
Vsubopt = 4*tolerance;
while Vsubopt/2 > tolerance
    ErV_old = ErV_new;
    % Expected value if nominal price is not changed
    ErV_notchange = rPi + beta*ErV_old;
    % Expected value if nominal price is changed in high menu cost state
    ErV_change = ones(rpgridsize,1)*max(rPi-(theta-1)*K/theta+beta*ErV_old);
    % Expected value if nominal price is changed in low menu cost state
    ErV_change2 = ones(rpgridsize,1)*max(rPi-(theta-1)*K2/theta+beta*ErV_old);
    % Compare change vs no change and choose the higher for high menu cost state
    ErV_compare = zeros(2,rpgridsize,agridsize);
    ErV_compare(1,:,:) = ErV_notchange; 
    ErV_compare(2,:,:) = ErV_change;
    ErV_new = squeeze(max(ErV_compare));
    % Compare change vs no change and choose the higher for high menu cost state
    ErV_compare2 = zeros(2,rpgridsize,agridsize);
    ErV_compare2(1,:,:) = ErV_notchange; 
    ErV_compare2(2,:,:) = ErV_change2;
    ErV_new2 = squeeze(max(ErV_compare2));
    % Take a weighted average
    ErV_new = alphaCalvo*ErV_new + (1-alphaCalvo)*ErV_new2;
    % Take expectations
    ErV_new = ProbInfl*ErV_new*Proba';
    
%     figure(7)
%     plot(rp(floor(rpgridsize/1.5):end),ErV_new(floor(rpgridsize/1.5):end,floor(agridsize/2)))
%     title('ErV_new (PE)');
    
%     [repmat(a(2),[rpgridsize 1]) rp ErV_new(:,2,1)]
    
    Vdifmax = (beta/(1-beta))*max(max(ErV_new - ErV_old));
    Vdifmin = (beta/(1-beta))*min(min(ErV_new - ErV_old));
    Vsubopt = Vdifmax-Vdifmin;
   
    if Vsubopt/2 <= tolerance
        Vadj = (Vdifmax+Vdifmin)/2;
    end
    if yesprint == 1
        if mod(i,5) == 0
            fprintf('.')
        end
        if mod(i,400) == 0
            fprintf('\n')
        end
    end
    i = i + 1;    
end
%ErV = ErV_new + Vadj;
ErV = ErV_new; %!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

if tloop == 1
    fprintf('\n')
    fprintf('Time of Loop: %8.2f\n',cputime - time1)
end
if yesprint==1
    fprintf('End Value Function Iteration \n')
end

rV_notchange = rPi + beta*ErV;
[rV_change rp_change] = max(rPi-(theta-1)*K/theta+beta*ErV);
rV_change = ones(rpgridsize,1)*rV_change;
rV_dif = rV_change - rV_notchange;
F_change = (rV_dif>0);
F_notchange = (F_change==0);
F = F_notchange.*(rp*ones(1,agridsize))+F_change.*(ones(rpgridsize,1)*rp(rp_change,1)');

[rV_change2 rp_change2] = max(rPi-(theta-1)*K2/theta+beta*ErV);
rV_change2 = ones(rpgridsize,1)*rV_change2;
rV_dif2 = rV_change2 - rV_notchange;
F_change2 = (rV_dif2>0);
F_notchange2 = (F_change2==0);
F2 = F_notchange2.*(rp*ones(1,agridsize))+F_change2.*(ones(rpgridsize,1)*rp(rp_change2,1)');

rV = alphaCalvo*(F_notchange.*rV_notchange + F_change.*rV_change) ...
       + (1-alphaCalvo)*(F_notchange2.*rV_notchange + F_change2.*rV_change2);

% rV_change2_old = rPi - (theta-1)*K2/theta + beta*ErV;
% [repmat(a(2),[rpgridsize 1]) rp rV(:,2,1)]
   
% figure(8)
% plot(rp(floor(rpgridsize/1.5):end),F2(floor(rpgridsize/1.5):end,floor(agridsize/2)))
% %[rp(floor(rpgridsize/1.5):end) F(floor(rpgridsize/1.5):end,floor(agridsize/2))]
% title('F2 (PE)');
