% Create Figures
%
%***************************************************************

clear; close all;

% Figure Format
    Format.colors = {[0 0 0], [0.55 0.55 0.55],[0 0 0],[0.55 0.55 0.55],[0 0 0]};
    Format.barcolors = {[0 0 0], [0.55 0.55 0.55],[0 0 0],[0.55 0.55 0.55]};
    Format.styles = {'-','-','-.','-.','--'};
    Format.widths = {1,1,1,1,1};
    Format.figsize = [460 200 500 400];
    Format.figsize2 = [460 200 1000 400];
    Format.figsize4 = [460 200 800 660];
    Format.figsize6 = [460 200 675 775];
    Format.FontSize = 15;
    Format.FontSizeAxes = 14;
    Format.fontweight = 'normal';
    Format.XTick = [1975 1980 1985 1990 1995 2000 2005 2010 2015] ;
    Format.Xlim =[1975 2015] ;
    Format.Shade = 0.8 ;
    Format.ScatterSize = [50,50] ;
    Format.ScatterMarker = {'o','s'} ;

%% Load data and smooth data
menucost_4 = load('menu_cost_model/output_codes/Stats_4.mat') ;
menucost_7 = load('menu_cost_model/output_codes/Stats_7.mat') ;
calvo_4 = load('calvo_model/output_codes/Stats_4.mat') ;
calvo_7 = load('calvo_model/output_codes/Stats_7.mat') ;
calvo_varying_4 = load('calvo_varying/output_codes/Stats4.mat') ;




degree = 3 ;
menucost_4_smth =   SmoothStats(menucost_4.Stats,degree);
menucost_7_smth = SmoothStats(menucost_7.Stats,degree);
calvo_4_smth =   SmoothStats(calvo_4.StatsCalvo,degree);
calvo_7_smth =   SmoothStats(calvo_7.StatsCalvo,degree);
calvo_varying_4_smth =  SmoothStats(calvo_varying_4.StatsCalvo,degree);



menucost_4.Stats.stdabssizepc = (menucost_4.Stats.sizepcsquared - menucost_4.Stats.abssizepc.^2).^(1/2);
calvo_4.StatsCalvo.stdabssizepc = (calvo_4.StatsCalvo.sizepcsquared - calvo_4.StatsCalvo.abssizepc.^2).^(1/2);
calvo_varying_4.StatsCalvo.stdabssizepc = (calvo_varying_4.StatsCalvo.sizepcsquared - calvo_varying_4.StatsCalvo.abssizepc.^2).^(1/2);


%% Figure 2. Welfare Loss


f1 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4_smth.welfareLossIgnoreUncert,calvo_4.StatsCalvo.infl,calvo_4_smth.welfareLossIgnoreUncert,menucost_7.Stats.infl,menucost_7_smth.welfareLossIgnoreUncert,calvo_7.StatsCalvo.infl(1:29),calvo_7_smth.welfareLossIgnoreUncert(1:29));
for linei = 1:4
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
legend('Menu Cost Model \theta=4','Calvo Model \theta=4','Menu Cost Model \theta=7','Calvo Model \theta=7','Location','NorthWest')
xlabel('Annual Inflation','FontSize',Format.FontSize)
ylabel('Fraction of Flex Price Consumption','FontSize',Format.FontSize)
ylim([0.00 0.10])
xlim([0 0.16])
set(gca,'FontSize',Format.FontSizeAxes)
title('Welfare Loss','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

set(f1,'PaperPositionMode', 'auto')
print(f1,'figures/WelfareCostAll','-depsc2');

%% Figure 3. Output and Labor Supply(1:30) 


% Main figure
f3 = figure('Position',Format.figsize2);
subplot(1,2,1)
p1 = plot(menucost_4.Stats.infl,menucost_4_smth.meanLogOutput-menucost_4_smth.FlexLogOutput,...
          calvo_4.StatsCalvo.infl,calvo_4_smth.meanLogOutput-calvo_4_smth.FlexLogOutput);
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
legend('Menu Cost Model','Calvo Model','Location','NorthWest')
xlabel('Annual Inflation','FontSize',Format.FontSize)
ylabel('Log Change from Flex Price Value','FontSize',Format.FontSize)
ylim([-0.10 0.05])
xlim([0 0.16])
set(gca,'FontSize',Format.FontSizeAxes)
title('Output','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

subplot(1,2,2)
p1 = plot(menucost_4.Stats.infl,log(menucost_4_smth.meanL)-log(menucost_4_smth.FlexLabor),...
          calvo_4.StatsCalvo.infl,log(calvo_4_smth.meanL)-log(calvo_4_smth.FlexLabor));
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
xlabel('Annual Inflation','FontSize',Format.FontSize)
ylabel('Log Change from Flex Price Value','FontSize',Format.FontSize)
ylim([-0.10 0.05])
xlim([0 0.16])
set(gca,'FontSize',Format.FontSizeAxes)
title('Labor','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

set(f3,'PaperPositionMode','auto','PaperOrientation','landscape')
print(f1,'figures/output_labor','-depsc2');



%% Figure 4. Labor Productivity and Aggregate Markup
f4 = figure('Position',Format.figsize2);
subplot(1,2,1)
p1 = plot(menucost_4.Stats.infl,log(menucost_4_smth.lprod)-log(menucost_4_smth.lprodFlex),...
          calvo_4.StatsCalvo.infl,log(calvo_4_smth.lprod)-log(calvo_4_smth.lprodFlex));
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
legend('Menu Cost Model','Menu Cost sm = 0.7','Location','SouthWest')
xlabel('Annual Inflation','FontSize',Format.FontSize)
ylabel('Log Change from Flex Price Value','FontSize',Format.FontSize)
ylim([-0.10 0.02])
xlim([0 0.16])
set(gca,'FontSize',Format.FontSizeAxes)
title('Labor Productivity','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

subplot(1,2,2)
p1 = plot(menucost_4.Stats.infl,menucost_4_smth.avmarkup-menucost_4.Stats.theta(1)/(menucost_4.Stats.theta(1)-1),...
          calvo_4.StatsCalvo.infl,calvo_4_smth.avmarkup-calvo_4.StatsCalvo.theta(1)/(calvo_4.StatsCalvo.theta(1)-1));
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
xlabel('Annual Inflation','FontSize',Format.FontSize)
ylabel('Change from Flex Price Value','FontSize',Format.FontSize)
ylim([-0.10 0.02])
xlim([0 0.16])
set(gca,'FontSize',Format.FontSizeAxes)
title('Aggregate Markup','FontSize',Format.FontSize,'FontWeight',Format.fontweight)
set(f4,'PaperPositionMode','auto','PaperOrientation','landscape')
print(f4,'figures/prod_markup','-depsc2');


%% Figure 5: Inefficient Price Dispersion


% Main figure
f5 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4_smth.ineffpdisp,calvo_4.StatsCalvo.infl,calvo_4_smth.ineffpdisp);
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
legend('Menu Cost Model','Calvo Model','Location','NorthWest')
xlabel('Annual Inflation','FontSize',Format.FontSize)
ylim([0.00 0.16])
xlim([0 0.16])
set(gca,'FontSize',Format.FontSizeAxes)
title('Inefficient Price Dispersion','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

set(f5,'PaperPositionMode', 'auto')
print(f5,'figures/inefficient_pdisp','-depsc2');




%% Figure 7. Scatter Plot x versus price gap

load('menu_cost_model/output_codes/ScatterPlot.mat')
f7 = figure('Position',Format.figsize);
scatter(scatter_to_save(:,1) - scatter_to_save(:,2),scatter_to_save(:,3),Format.ScatterSize(1),Format.colors{1},Format.ScatterMarker{1})
xlabel('True Price Gap','FontSize',Format.FontSize)
ylabel('Fixed-effects Price Gap','FontSize',Format.FontSize)
% ylim([0.03 0.07])
%     xlim([0 0.12001])
set(gca,'FontSize',Format.FontSizeAxes)
title('True price gap versus fixed-effects price gap','FontSize',Format.FontSize,'FontWeight',Format.fontweight)
set(f7,'PaperPositionMode', 'auto')
print(f7,'figures/scatter_pricegap','-depsc2');




%% Figure 8. Mean Absolute Size of Price Changes




scat1 = openfig('codes_partial_eq/output_codes/ScatterSizeBasic.fig') ;
datax1 = get(findobj(scat1,'Type','Scatter'),'Xdata');
datay1 = get(findobj(scat1,'Type','Scatter'),'Ydata') ;
close
scat2 = openfig('codes_partial_eq/output_codes/ScatterSizeCalvo.fig') ;
datax2 = get(findobj(scat2,'Type','Scatter'),'Xdata');
datay2 = get(findobj(scat2,'Type','Scatter'),'Ydata') ;
close


f8 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4.Stats.abssizepc,calvo_4.StatsCalvo.infl,calvo_4.StatsCalvo.abssizepc) ;
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
hold on
scatter(datax1,datay1,Format.ScatterSize(1),Format.colors{1},Format.ScatterMarker{1})
scatter(datax2,datay2,Format.ScatterSize(2),Format.colors{2},Format.ScatterMarker{2})
legend('Menu Cost, Steady State','Calvo, Steady State','Menu Cost, Observed Inflation','Calvo, Observed Inflation','Location','SouthEast')
xlim([-0.02 0.16001])
ylim([0 0.179999])
xlabel('Inflation','FontSize',Format.FontSize)
ylabel('Fraction of Original Price','FontSize',Format.FontSize)
set(gca,'FontSize',Format.FontSizeAxes)
title('Frequency of Price Change','FontSize',Format.FontSize,'FontWeight',Format.fontweight)
set(f8,'PaperPositionMode', 'auto')
print(f8,'figures/size_pege','-depsc2');


%% Figure 10. Standard Deviations of Absolute Size of Price Changes



scat1 = openfig('codes_partial_eq/output_codes/ScatterStdBasic.fig') ;
datax1 = get(findobj(scat1,'Type','Scatter'),'Xdata');
datay1 = get(findobj(scat1,'Type','Scatter'),'Ydata') ;
close
scat2 = openfig('codes_partial_eq/output_codes/ScatterStdCalvo.fig') ;
datax2 = get(findobj(scat2,'Type','Scatter'),'Xdata');
datay2 = get(findobj(scat2,'Type','Scatter'),'Ydata') ;
close

f10 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4.Stats.stdabssizepc,calvo_4.StatsCalvo.infl,calvo_4.StatsCalvo.stdabssizepc) ;
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
hold on
scatter(datax1,datay1,Format.ScatterSize(1),Format.colors{1},Format.ScatterMarker{1})
scatter(datax2,datay2,Format.ScatterSize(2),Format.colors{2},Format.ScatterMarker{2})
legend('Menu Cost, Steady State','Calvo, Steady State','Menu Cost, Observed Inflation','Calvo, Observed Inflation','Location','NorthWest')
xlim([-0.02 0.16001])
ylim([0 0.179999])
xlabel('Inflation','FontSize',Format.FontSize)
ylabel('Fraction of Original Price','FontSize',Format.FontSize)
set(gca,'FontSize',Format.FontSizeAxes)
title('Standard Deviations of Absolute Size of Price Changes','FontSize',Format.FontSize,'FontWeight',Format.fontweight)
set(f10,'PaperPositionMode', 'auto')
print(f10,'figures/std_pege','-depsc2');




%% Figure 12. IQR of Fixed-Effects Price Gap

DataInfl = importdata('auxiliary_data/Figure11.csv') ;
DataStat = importdata('auxiliary_data/iqr_eli_reg_dummies.csv') ;
DataStat.data(:,4) = [DataInfl.data(2:10,2) ; DataInfl.data(12:end,2)] ;

XX = calvo_4.StatsCalvo.infl.^0;
for jj = 1:4
    XX = [XX calvo_4.StatsCalvo.infl.^jj];
end

bb = regress(calvo_4.StatsCalvo.iqrxCtH,XX);
calvo_4.StatsCalvo.iqrxCtHSmooth = XX*bb;

XX = menucost_4.Stats.infl.^0;
for jj = 1:4
    XX = [XX menucost_4.Stats.infl.^jj];
end

bb = regress(menucost_4.Stats.iqrx,XX);
menucost_4.Stats.iqrxSmooth = XX*bb;


f3 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4.Stats.iqrxSmooth,calvo_4.StatsCalvo.infl,calvo_4.StatsCalvo.iqrxCtHSmooth);
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
hold on
scatter(DataStat.data(:,4),DataStat.data(:,3),Format.ScatterSize(1),Format.colors{1},Format.ScatterMarker{1})

legend('Menu Cost','Calvo Model','Data','Location','NorthWest')
xlabel('Annual Inflation','FontSize',Format.FontSize)
ylabel('IQR of Fixed-Effects Price Gap','FontSize',Format.FontSize)
% ylim([0.03 0.07])
%     xlim([0 0.12001])
set(gca,'FontSize',Format.FontSizeAxes)
title('IQR of Fixed-Effects Price Gap','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

set(f3,'PaperPositionMode', 'auto')
print(f3,'figures/fixed_effect_pricegap','-depsc2');





%% Figure 13. Frequency of Price Changes




scat1 = openfig('codes_partial_eq/output_codes/ScatterFreqBasic.fig') ;
datax1 = get(findobj(scat1,'Type','Scatter'),'Xdata');
datay1 = get(findobj(scat1,'Type','Scatter'),'Ydata') ;
close
scat2 = openfig('codes_partial_eq/output_codes/ScatterFreqCalvo.fig') ;
datax2 = get(findobj(scat2,'Type','Scatter'),'Xdata');
datay2 = get(findobj(scat2,'Type','Scatter'),'Ydata') ;
close

f13 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4.Stats.freq,calvo_4.StatsCalvo.infl,calvo_4.StatsCalvo.freq) ;
for linei = 1:2
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
hold on
scatter(datax1,datay1,Format.ScatterSize(1),Format.colors{1},Format.ScatterMarker{1})
scatter(datax2,datay2,Format.ScatterSize(2),Format.colors{2},Format.ScatterMarker{2})
legend('Menu Cost, Steady State','Calvo, Steady State','Menu Cost, Observed Inflation','Calvo, Observed Inflation','Location','NorthWest')
xlim([-0.02 0.16001])
ylim([0 0.179999])
xlabel('Inflation','FontSize',Format.FontSize)
ylabel('Fraction of Original Price','FontSize',Format.FontSize)
set(gca,'FontSize',Format.FontSizeAxes)
title('Frequency of Price Changes','FontSize',Format.FontSize,'FontWeight',Format.fontweight)
set(f13,'PaperPositionMode', 'auto')
print(f13,'figures/freq_pege','-depsc2');




%% Figure  A.5

f1 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4_smth.welfareLossIgnoreUncert,calvo_4.StatsCalvo.infl,calvo_4_smth.welfareLossIgnoreUncert,menucost_7.Stats.infl,menucost_7_smth.welfareLossIgnoreUncert,calvo_7.StatsCalvo.infl,calvo_7_smth.welfareLossIgnoreUncert,calvo_varying_4.StatsCalvo.infl,calvo_varying_4_smth.welfareLossIgnoreUncert);
for linei = 1:5
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end
legend('Menu Cost Model \theta=4','Calvo Model \theta=4','Menu Cost Model \theta=7','Calvo Model \theta=7','Location','NorthWest')
xlabel('Annual Inflation','FontSize',Format.FontSize)
ylabel('Fraction of Flex Price Consumption','FontSize',Format.FontSize)
ylim([0.00 0.10])
xlim([0 0.16])
set(gca,'FontSize',Format.FontSizeAxes)
title('Welfare Loss','FontSize',Format.FontSize,'FontWeight',Format.fontweight)

set(f1,'PaperPositionMode', 'auto')
print(f1,'figures/WelfareCostApp','-depsc2');






%% Figure A.6. Mean Absolute Size of Price Changes


f8 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4.Stats.abssizepc,calvo_4.StatsCalvo.infl,calvo_4.StatsCalvo.abssizepc,calvo_varying_4.StatsCalvo.infl,calvo_varying_4.StatsCalvo.abssizepc) ;
for linei = 1:3
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end

legend('Menu Cost Model','Calvo Model','Calvo Varying','Location','NorthWest')
xlim([0 0.16001])
ylim([0 0.179999])
xlabel('Inflation','FontSize',Format.FontSize)
ylabel('Fraction of Original Price','FontSize',Format.FontSize)
set(gca,'FontSize',Format.FontSizeAxes)
title('Mean Absolute Size of Price Changes','FontSize',Format.FontSize,'FontWeight',Format.fontweight)
set(f8,'PaperPositionMode', 'auto')
print(f8,'figures/size_app','-depsc2');




%% Figure A.7. Standard Deviations of Absolute Size of Price Changes


f8 = figure('Position',Format.figsize);
p1 = plot(menucost_4.Stats.infl,menucost_4.Stats.stdabssizepc,calvo_4.StatsCalvo.infl,calvo_4.StatsCalvo.stdabssizepc,calvo_varying_4.StatsCalvo.infl,calvo_varying_4.StatsCalvo.stdabssizepc) ;
for linei = 1:3
    set(p1(linei),'LineStyle',Format.styles{linei})
    set(p1(linei),'color',Format.colors{linei})
    set(p1(linei),'linewidth',Format.widths{linei})
end

legend('Menu Cost Model','Calvo Model','Calvo Varying','Location','NorthWest')
xlim([0 0.16001])
ylim([0 0.179999])
xlabel('Inflation','FontSize',Format.FontSize)
ylabel('Fraction of Original Price','FontSize',Format.FontSize)
set(gca,'FontSize',Format.FontSizeAxes)
title('Standard Deviations of Absolute Size of Price Changes','FontSize',Format.FontSize,'FontWeight',Format.fontweight)
set(f8,'PaperPositionMode', 'auto')
print(f8,'figures/size_app','-depsc2');


