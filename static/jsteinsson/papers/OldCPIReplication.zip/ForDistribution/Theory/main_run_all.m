%% What to run

% Calvo Model
cd ./calvo_model

ge1CalvoLongRun ; % Calvo Model - Theta = 4
ge1CalvoLongRun_7 ; % Calvo Model - Theta = 7

% Menu Cost Model
cd ../

cd ./menu_cost_model
ge1BasicLongRun ; % Menu Cost Model - Theta = 4
ge1BasicLongRun_7 ; % Menu Cost Model - Theta = 7
ge1Basic; % Menu Cost Model - Theta = 4 - Low Inflation
SimulateRelativesRRKillingProds ; % Simulate the Fixed-Effects Price Gap

% Calvo Varying

cd ../
cd ./calvo_varying
ge1_CalvoLongRun_VaryingAlpha % Calvo Model Varying alpha.



cd ../
cd ./codes_partial_eq
PartialEqBasicTimeSeries
PartialEqCalvoTimeSeries



create_figures
