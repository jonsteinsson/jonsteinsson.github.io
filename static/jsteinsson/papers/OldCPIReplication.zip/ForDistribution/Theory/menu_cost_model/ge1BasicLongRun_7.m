% One sector general equilibrium menu cost model
%
% The state vector is three dimensional:
% a: idiosyncratic productivity
% rp: real price
% rad: real aggregate demand
%
% We vectorize it using the reshape command. The order of the state 
% variables when they are reshaped is (a, rp, rad)
%
% Calculates various statistics for different levels of average inflation
% by solving the model many times for different values of average growth in
% nominal aggregate demand.
%
% Emi Nakamura, Jon Steinsson, Patrick Sun, Daniel Villar 
% July 2015 (based on code written for Nakamura and Steinsson (QJE 2010)
%**************************************************************

clear all; close all;
tic

%% Set Parameters
%**************************************************************

theta = 7;            % Elasticity of demand
psi = 0;              % One over the Frisch elasticity of labor supply
gamma = 1;            % coefficient of relative risk aversion
FlexSSL = (theta-1)/theta; % Steady State labor under flexible prices
beta = 0.96^(1/12);   % Discount factor

% Parameters of the process followed by nominal aggregate demand
% log(S_t) - log(S_t-1) = mu + nu_t
% where nu_t ~ N(0,sigma_eta^2), i.i.d.
sigma_eta = 0.0039 ; % sigma_eta = 0.0039;
mu_vec = (0.00/12):(0.0025/12):(0.04/12);
mu_vec = [mu_vec (0.045/12):(0.005/12):(0.08/12)];
mu_vec = [mu_vec (0.09/12):(0.01/12):(0.16/12)];
%mu_vec = 0.16/12;
muLength = length(mu_vec);

% Parameters of the idiosyncratic productivity process (log A_it)
% log(A_it) = rho*log(A_it-1) + eps_it
% where eps_it ~ N(0,sigma_eps^2), i.i.d.
% The process is truncated at +/- trunc_eps multiples of the unconditional
% standard deviation of log(A)
rho = 0.7;
sigma_eps = 0.0365; %sigma_eps = 0.0425; 
sm = 0.0;  % Intermediate input share in the production function
K = 0.018;%K = 0.027 ;%  % Menu cost (Notice: In the notation of the paper this is "K/Y_ss")

% Maximum number of iterations on G
MaxItOnG = 100;

% Figure Format
PRESENTATION = true;

if PRESENTATION
    Format.FontSize = 16;
    Format.colors = {'k','r','g'};
    Format.widths = {2,2,2};
    Format.styles = {'-','-','-'};
    Format.figsize = [460 200 700 525];
else
    Format.colors = {[0 0 0], [0 0 0], [0 0 0]};
    Format.styles = {'-','--','-.'};
    Format.widths = {1,1,1};
    Format.figsize = [460 200 560 420];
    Format.FontSize = 12;
end

%% Print Out Parameters
%****************************************************************

fprintf('\n')
fprintf('theta:     %5.5f\n',theta)
fprintf('psi:       %5.5f\n',psi)
fprintf('gamma:     %5.5f\n',gamma)
fprintf('sm:        %5.5f\n',sm)
fprintf('K:         %5.5f\n',K)
fprintf('rho:       %5.5f\n',rho)
fprintf('sigma_eps: %5.5f\n',sigma_eps)
fprintf('sigma_eta: %5.5f\n',sigma_eta)
fprintf('\n')

%% Loop that solves model for each values of mu
%**************************************************************************

for mm = 1:muLength
    mu = mu_vec(mm);
    
    fprintf('**************************************\n')
    fprintf('Annual average inflation:     %5.2f\n\n',mu*12*100)

    % Location of the middle of the rad grid relative to the no-uncertainty
    % steady state value of rad
    rad_shift = 0.5*mu+0.003;
    
    % Number of points on the grid for each of the three state variables
    agridsize   = 50;   %50;
    rpgridsize  = 500;  %500;
    radgridsize = 50;   %50;
    
    Ssize = agridsize*rpgridsize*radgridsize;
    
    fprintf('agridsize:           %5.0f\n',agridsize)
    fprintf('rpgridsize:          %5.0f\n',rpgridsize)
    fprintf('radgridsize:         %5.0f\n',radgridsize)
    fprintf('Size of State Space: %10.0f\n\n',Ssize)
    
    % Span of rp grid relative to a grid
    rp_span = 1.5;
    
    % The slope and level of the initial guess for the function G function
    % i.e. the function Gamma in our Multi-Sector Menu Cost paper.
    % The initial guess is a step function. "slope" gives the number of grid
    % points on the rad grid between steps in this step function. This means
    % that the slope is greater for lower values of "slope".
    % If levelshift = 0 the Gamma function take a value of zero (in logs) in
    % the middle of the grid. More generally, if levelshift = N the Gamma
    % function takes a value N gridpoints above zero in the middle of the grid.
    % slope = 3; levelshift = 2+floor(12*mu/0.02); 
    slope = floor(2*rpgridsize/400); 
    levelshift = floor((12*abs(mu)/0.02)*rpgridsize/400); 
    
    fprintf('slope:         %5.0f\n',slope)
    fprintf('levelshift:    %5.0f\n\n',levelshift)
    
    %% Solve for the flexible price steady state
    %****************************************************************
    
    par1 = sm*(theta-1)/(theta-sm*(theta-1));
    
    FlexSSC = FlexSSL*par1^(sm/(1-sm))*(1+par1)^(-1/(1-sm));
    FlexSSM = par1*FlexSSC;
    FlexSSY = FlexSSC + FlexSSM;
    
    omega = (theta-1)/theta*(1-sm)*(1+par1)*FlexSSL^(-psi-1)*FlexSSC^(1-gamma); % Level parameter on disutility of labor
    omega2 = omega*(FlexSSL)^psi; % Marginal disutility of changing prices
        
    %% Set grid parameters
    %****************************************************************
    
    if agridsize < 30
        error('agridsize < 30: Results unreliable!')
    end
    
    trunc_eps = 3;
    amax = trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
    amin = -trunc_eps*(sigma_eps^2/(1-rho^2))^(1/2);
    ainc = (amax-amin)/(agridsize-1) - mod((amax-amin)/(agridsize-1),10^(-7));
    amin = amin - mod(amin,10^(-7));
    amax = amin + (agridsize-1)*ainc;
    
    % rp denotes the real price
    % np denotes the nominal price
    % The rp grid is a grid for the log of the real price
    rpmax = -amin*rp_span;
    rpmin = -amax*rp_span;
    if rpmax < 0.15
        rpmax = 0.15;
        rpmin = -0.15;
    end
    rpinc = (rpmax-rpmin)/(rpgridsize-1) - mod((rpmax-rpmin)/(rpgridsize-1),10^(-7));
    rpmin = rpmin - mod(rpmin,10^(-7));
    rpmax = rpmin + (rpgridsize-1)*rpinc;
    
    if rpinc > 0.0075
        error('rpinc > 0.0075: Results unreliable')
    end
    
    radmin = log(FlexSSC) - radgridsize/2*rpinc + rad_shift;
    
    fprintf('ainc:           %5.4f\n',ainc)
    fprintf('rpinc:          %5.4f\n\n',rpinc)
    
    %% Create the real price and idiosyncratic productivity vectors
    %**************************************************************
    
    a = amin:ainc:amax; a = a';
    
    rp = zeros(rpgridsize,1);
    rp(1) = rpmin;
    for ii = 2:rpgridsize
        rp(ii) = rp(ii-1) + rpinc;
    end
    
    rad = zeros(radgridsize,1);
    rad(1) = radmin;
    for ii = 2:radgridsize
        rad(ii) = rad(ii-1) + rpinc;
    end
    
    % Create Probability Distribution for the idiosyncratic shock
    %**************************************************************
    % Proba is a matrix that gives transition probabilities of going
    % from state a to state a', i.e. Proba(i,j) = Prob(a' = j | a = i)
    %
    % The procedure of Tauchen (1986) is used to approximate the
    % AR(1) process for log(A_it)
    
    Proba = CreateProba(rho,sigma_eps,a);
    
    %fprintf('Proba(1:8,1:8) ')
    %Proba(1:8,1:8)
    
    % Create probability distribution for nominal aggregate demand
    %***************************************************************
    
    ProbNgr = CreateProbNgr(mu,sigma_eta,rad);
    
    %fprintf('ProbaNgr(1:8,1:8) ')
    %ProbNgr(1:8,1:8)
    
    % Guess a matrix G which gives the log inflation rate given S_t/P_t-1
    %**************************************************************
    
    G = zeros(radgridsize,1);
    %G = (rp(2)-rp(1))*ones(radgridsize,1);
    G(1,1) = -(radgridsize/(2*slope)-mod(radgridsize/(2*slope),1))*(rp(2)-rp(1)) ...
        + levelshift*(rp(2)-rp(1));
    for ii = 2:radgridsize
        if mod(ii,slope) == 0
            G(ii,1) = G(ii-1,1) + rp(2) - rp(1);
        else
            G(ii,1) = G(ii-1,1);
        end
    end
    %figure(99)
    %plot(rad,G)
    
    %% Calculate the profit function
    %**************************************************************
    
    par1 = psi+1;
    par2 = gamma;
    par3 = FlexSSC/FlexSSY;
    par4 = FlexSSM/FlexSSY - sm;
    par5 = 1-sm;
    
    a3d = repmat(a,[1 rpgridsize radgridsize]);
    
    rp3d = repmat(rp,[1 agridsize radgridsize]);
    rp3d = permute(rp3d, [2 1 3]);
    
    rad3d = repmat(rad,[1 agridsize rpgridsize]);
    rad3d = permute(rad3d,[2 3 1]);
    
    if sm > 0
        l3d = log(FlexSSL) + (par3+par2*par4)/(par5-par1*par4)*(rad3d-log(FlexSSC));
        m3d = log(FlexSSM) + par1*(l3d - log(FlexSSL)) + par2*(rad3d-log(FlexSSC));
    else
        l3d = log(FlexSSL) + (rad3d-log(FlexSSC));
        m3d = 0*rad3d;
    end
    
    rPi3d = exp(rad3d + m3d).*exp(rp3d).^(1-theta) ...
        - (1-sm)^(sm-1)*sm^(-sm)*omega^(1-sm)*exp(l3d).^(psi*(1-sm)).*exp(rad3d).^(gamma*(1-sm)).*exp(-a3d).*exp(rad3d+m3d).*exp(rp3d).^(-theta);
    rPi = reshape(rPi3d,[Ssize 1]);
    
    menucost3d = omega2*K*FlexSSY*exp(rad3d).^gamma;
    menucost = reshape(menucost3d,[Ssize 1]);
    
    clear a3d rp3d rad3d rPi3d menucost3d l3d m3d
    
    % figure(4)
    % rPi_plot = reshape(rPi,[agridsize rpgridsize radgridsize]);
    % rPi_plot = squeeze(rPi_plot(:,:,1));
    % surf(a,rp,rPi_plot')
    % title('Profit Function')
    % xlabel('a')
    % ylabel('rp')
    
    % Calculate the ratio of marginal utility
    %**************************************************************
    % The (i,j)th element of RMU is the ratio of marginal utility in
    % state j of period t+1 to the marginal utility in state i of
    % period t.
    
    RMU = ((1./exp(rad))*(exp(rad)')).^(-gamma);
    
    % Initialize ErV matrix (Expected Value next period)
    %**************************************************************
    
    ErV = 1.5*ones(Ssize, 1)*max(0,mean(rPi)/(1-beta));
    rPi3d = reshape(rPi,[agridsize rpgridsize radgridsize]);
    tolV = 0.001*rPi3d(floor(agridsize/2),floor(rpgridsize/2),floor(radgridsize/2))/(1-beta);
    clear rPi3d
    
    %fprintf('tolV:     %10.6f\n',tolV)
    
    % Initialize stationary distribution Q
    %**************************************************************
    
    Qinit = ones(Ssize,1)/Ssize;
    tolQ = Qinit(1)/150;
    
    %% Solve for the Equilibrium
    %**************************************************************
    
    [G,rV,F,F_c,Q,hitMaxItOnG] = EqSolverGE1Basic(rPi,menucost,RMU,beta,theta,a,rp,rad,...
        Proba,ProbNgr,ErV,Qinit,G,tolV,tolQ,MaxItOnG,1);
    
    GError = CalcGError(G,F,Q,a,rp,rad,theta,Proba,ProbNgr);
    
    PCStats = RigidityStats(Q,F,a,rp,rad,theta,log(FlexSSC),menucost);
    
    Stats.theta                = theta;
    Stats.agridsize(mm,1)      = agridsize;
    Stats.rpgridsize(mm,1)     = rpgridsize;
    Stats.radgridsize(mm,1)    = radgridsize;
    Stats.hitMaxItOnG(mm,1)    = hitMaxItOnG;  
    
    Stats.infl(mm,1)           = mu*12;    
    Stats.freq(mm,1)           = PCStats.freq;
    Stats.frequp(mm,1)         = PCStats.frequp;
    Stats.freqdw(mm,1)         = PCStats.freqdw;
    Stats.fracup(mm,1)         = PCStats.fracup;
    Stats.abssizepc(mm,1)      = PCStats.abssizepc;
    Stats.sizeup(mm,1)         = PCStats.sizeup;
    Stats.sizedw(mm,1)         = PCStats.sizedw;
    Stats.sizepcnotabs(mm,1)   = PCStats.sizepcnotabs;    % size as opposed to absolute size
    Stats.sizepcsquared(mm,1)  = PCStats.sizepcsquared;
    Stats.sizepccubed(mm,1)    = PCStats.sizepccubed;
    
    Stats.meanRprice(mm,1)     = PCStats.meanRprice;
    Stats.ineffpdisp(mm,1)     = PCStats.ineffpdisp;
    Stats.ineffpdisp2nd(mm,1)  = PCStats.ineffpdisp2nd;
    Stats.lprod(mm,1)          = PCStats.lprod;
    Stats.lprod2nd(mm,1)       = PCStats.lprod2nd;
    Stats.lprodFlex(mm,1)      = PCStats.lprodFlex;
    Stats.lprodFlex2(mm,1)     = PCStats.lprodFlex2;
    Stats.prodwedge(mm,1)      = PCStats.prodwedge;
    Stats.stdLogOutput(mm,1)   = PCStats.stdLogOutput;
    Stats.meanLogOutput(mm,1)  = PCStats.meanLogOutput;
    Stats.FlexLogOutput(mm,1)  = PCStats.FlexLogOutput;
    Stats.FlexLabor(mm,1)      = PCStats.FlexLabor;
    Stats.lprodFlex(mm,1)      = PCStats.lprodFlex;
    Stats.meanp(mm,1)          = PCStats.meanp;
    Stats.meanL(mm,1)          = PCStats.meanL;
    Stats.pccost(mm,1)         = PCStats.pccost;
    Stats.avmarkup(mm,1)       = PCStats.avmarkup;
    Stats.welfareLossIgnoreUncert(mm,1) = PCStats.welfareLossIgnoreUncert;
    
    
    GE1Model.a = a;
    GE1Model.rp = rp;
    GE1Model.rad = rad;
    GE1Model.K = K;
    GE1Model.beta = beta;
    GE1Model.theta = theta;
    GE1Model.gamma = gamma;
    GE1Model.omega = omega;
    GE1Model.omega2 = omega2;
    GE1Model.rho = rho;
    GE1Model.sigma_eps = sigma_eps;
    GE1Model.mu = mu;
    GE1Model.sigma_eta = sigma_eta;

    % Outputs
    GE1Model.G = G;
    GE1Model.rV = rV;
    GE1Model.F = F;
    GE1Model.F_c = F_c;
    GE1Model.Q = Q;
    GE1Model.GError = GError;
    GE1Model.freq = PCStats.freq;
    GE1Model.fracup = PCStats.fracup;
    GE1Model.sizepc = PCStats.abssizepc;
    GE1Model.sizeup = PCStats.sizeup;
    GE1Model.sizedw = PCStats.sizedw;
    GE1Model.CstdLogOutput = PCStats.stdLogOutput;
    [stdx,iqrx] = SimulateRelativesRR(GE1Model) ;
     Stats.iqrx(mm,1) = iqrx;
     Stats.stdx(mm,1) = stdx;
save('output_codes/Stats_7','Stats')
    
end
                             


% Save as excel table
TT = table(Stats.infl, Stats.freq, Stats.frequp, Stats.freqdw, Stats.fracup, ...
            Stats.abssizepc, Stats.sizeup, Stats.sizedw);
writetable(TT,'output_codes/Basic_StatsLongRun_7.xls')



