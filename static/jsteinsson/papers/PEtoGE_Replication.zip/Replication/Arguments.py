import argparse
parser = argparse.ArgumentParser(usage='Compute GE and PE housing wealth effects, fiscal multiplier and so on, and apply our formula to compare them.')

parser.add_argument('ModelName', help='Name of model file in Models directory')
parser.add_argument('ParameterName', help='Name of parameter file in Parameters directory')

args = parser.parse_args()
