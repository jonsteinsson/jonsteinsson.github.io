from Models.IM import GEModelClass as mod
from Parameters.Baseline import par as par


def GetCalibrationMoments(XLocal, XGlobal, par):
    P,C,I,Y,G,H  = XLocal.unpack(['P','C','I','Y','G','H'])
    interest, = XGlobal.unpack(['interest'])
    delta, = par.unpack(['delta'])

    print('Calibration moments')
    print(f'I/Y = {I/Y}')
    print(f'G/Y = {G/Y}')
    usercost = P*(interest+delta)/(1+interest)
    print(f'Housing expenditure share = {usercost*H/(C+usercost*H)}')


m = mod(par)
m.SteadyState(par)
XLocal, XGlobal, XForeign = m.UnpackX(m.X_SS,par)
GetCalibrationMoments(XLocal,XGlobal,par)
