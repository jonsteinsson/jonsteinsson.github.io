import numpy as np
from numpy import zeros, max, abs
import warnings




def DetSimul(X0,A,B,C,E, eps, maxit=100, Dampening = 1, DampeningThresh = 0):
    """ Deterministic solution to the model represented by StateTrans,ForwardLooking,Static.


    X0 -- initial guess of solution (nx x T)
          Order of variables is state, forwardlooking, static
    A,B,C,E -- System is of the form
            A X_{t+1} + B X_t + C X_{t-1} + E epsilon_t = 0

    eps -- exogenous variables (neps x T)

    maxit -- maximum number of iterations to try

    dampening -- initial scale factor of update: X' = X + dampening * dX

    DampeningThresh -- residual threshold at which dampening is turned off.

    Results:
    X is nx x T  solution with same ordering as X0

    This program implements the algorithm described in Juillard (1996)
    "DYNARE: A program for the resolution and simulation of dynamic models
    with forwardd variables through the use of a relaxation algorithm."

    Alisdair McKay   alisdair.mckay@gmail.com
    Created Saturday, August 1, 2015
    Updated Monday, February 18, 2019
    """

    nx0 = X0.shape[0]
    # print 'nx0 = {}'.format(nx0)

    def eqmwrap(X,eps):

        Y = A@ X[:,[2]] + B@X[:,[1]] + C@X[:,[0]] + E @ eps
        return  Y, C, B, A

    return __Solve__( X0, eps, eqmwrap, maxit, Dampening, DampeningThresh )

def __Solve__( X0, eps, eqmwrap, maxit, Dampening, DampeningThresh):
    """ Deterministic solution to the model represented by eqmwrap.


    X0 -- initial guess of solution (nx x T)
    eps -- exogenous variables (neps x T)
    eqmwrap -- function that gives residuals of model equations
    maxit -- maximum number of iterations to try
    dampening -- initial scale factor of update.
    DampeningThresh -- residual threshold at which dampening is turned off.

    X  = DetSimul( X0, eps, fcn)

    X is nx x T

    This program implements the algorithm described in Juillard (1996)
    "DYNARE: A program for the resolution and simulation of dynamic models
    with forwardd variables through the use of a relaxation algorithm."

    Alisdair McKay
    Saturday, August 1, 2015
    """



    #initializations
    X = X0

    nx, T = X.shape
    C = zeros((nx,nx,T))
    d = zeros((nx,T))
    dX = zeros((nx,T))
    Fx = zeros((nx,T))


    for it in range(maxit+1):

        C[:,:,0] = zeros(nx)
        d[:,0] = zeros(nx)
        for t in range(1,T-1):
            Fx[:,[t]],S_L, S, S_P = eqmwrap(X[:,t-1:t+2],eps[:,[t]])
            C[:,:,t] = np.linalg.solve( S - np.dot(S_L,C[:,:,t-1]),S_P)
            # print Fx[:,[t]].shape
            # print np.dot(S_L,d[:,[t-1]]).shape
            # print S.shape
            # print np.dot(S_L,C[:,:,t-1]).shape
            # print (S - np.dot(S_L,C[:,:,t-1]) ).shape
            d[:,t] = -np.linalg.solve(S - np.dot(S_L,C[:,:,t-1]) ,Fx[:,t] + np.dot(S_L,d[:,t-1]))



        residual = max(abs(Fx.flatten()))
        if residual < 1e-8:
            print('done')
            break
        else:
            print('iteration ' + str(it) + '...residual ' + str(residual))
            if residual < DampeningThresh:
                Dampening = 1





        dX[:,T-1] = zeros(nx)
        for t in range(T-2,0,-1):
            dX[:,t] = d[:,t] - np.dot(C[:,:,t],dX[:,t+1])



        X = X + Dampening * dX


    if it >= maxit:
        warnings.warn('simulation did not converge after {} iterations.'.format(maxit))



    return X
