from Regressions import Get_HWE, Get_FM, Get_PEHWE

def F(mod):
    phiH,phiF,GTradable = mod.par.unpack(['phiH','phiF','GTradable'])
    HWE_elas_Y, HWE_elas_C, Constr_elas, IonC = Get_HWE(mod)
    FM, ConY,  PriceIncomeElas, InflationResponse = Get_FM(mod)
    Actual_PE_HWE = Get_PEHWE(mod)

    if GTradable:
        GTradableAdjustment_Numerator = (phiH+phiF-1)
        GTradableAdjustment_Denom = 1.0
    else:
        GTradableAdjustment_Numerator = 1.0
        GTradableAdjustment_Denom = (phiH+phiF-1)

    # formula
    E = (ConY * HWE_elas_C + IonC*ConY * Constr_elas)
    Implied_PE_HWE = GTradableAdjustment_Numerator*E/ConY/(FM*(1-ConY*GTradableAdjustment_Denom*E*PriceIncomeElas)) - IonC * Constr_elas

    print(f'Implied_PE_wo_Multiplier_Correction = {GTradableAdjustment_Numerator*E/ConY/FM - IonC * Constr_elas}')

    return HWE_elas_C, FM, Constr_elas,  PriceIncomeElas, Implied_PE_HWE, Actual_PE_HWE
