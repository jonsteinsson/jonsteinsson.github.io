import autograd.numpy as np
np.set_printoptions(suppress=True,precision=8)

from Support import ModelClass, Indexer

from Models.CommonModelElements import *
PartialEquilibriumDynamics = PartialEquilibriumDynamicsCM




#---- Indexation


# Indexing
nXLocal = 17
nXGlobal = 4
nX = 2*nXLocal + nXGlobal
nEps = 3



class LocalIndexer(Indexer):
    # Note: make B_pat first
    nX = nXLocal
    L, C, H, P, Y, w, I, M, PM, G, D, T,  piDomestic, pi, Pstar, PA, PB   = range(nXLocal)


class GlobalIndexer(Indexer):
    nX = nXGlobal
    E = 0
    interest = 1
    Omega = 2
    dlogC = 3


# li = LocalIndexer()
# gi = GlobalIndexer()




# ------Dynamics ----

def ConsumptionDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, par  ):

    beta, nu, psi, sigma, delta, kappa = par.unpack(['beta', 'nu', 'psi', 'sigma', 'delta', 'kappa'])

    P,  w, T, C, L, H, D = XLocal.unpack(['P','w','T','C','L','H', 'D'])
    P_P, C_P, L_P, H_P, pi_P = XLocal_P.unpack(['P', 'C', 'L','H','pi'])
    H_L, = XLocal_L.unpack(['H'])
    interest, Omega = XGlobal.unpack(['interest','Omega'])
    interest_L, = XGlobal_L.unpack(['interest'])
    Omega_P, = XGlobal_P.unpack(['Omega'])

    muC = u_C(C,L,H,Omega,par)
    muC_P =  u_C(C_P,L_P,H_P,Omega_P,par)

    muL = u_L(C,L,H,Omega,par)
    muH = u_H(C,L,H,Omega,par)

    res = np.hstack((
        muC - beta * muC_P *  (1+interest)/pi_P,  #Euler equation
        -muH + P * muC - beta*(P_P*(1-delta)*muC_P),# User Cost eqn
        muL + w * muC # Labor supply
    ))
    return res

def MarketClearingDynamics(XLocal,XGlobal,XGlobal_L,XForeign,par):
    phiH,phiF,n,GTradable  = par.unpack(['phiH','phiF','n','GTradable'])

    G, C, I, L, Y, D, w, H, piDomestic = XLocal.unpack(['G', 'C', 'I', 'L', 'Y', 'D', 'w', 'H','piDomestic'])
    Gstar, Cstar, Istar, Lstar, Ystar, Dstar, wstar, Hstar, piForeign = XForeign.unpack(['G', 'C', 'I', 'L', 'Y', 'D', 'w', 'H','piDomestic'])
    Omega, = XGlobal.unpack(['Omega'])
    E, = XGlobal.unpack(['E'])
    E_L, = XGlobal_L.unpack(['E'])

    muC = u_C(C,L,H,Omega,par)
    muCstar = u_C(Cstar,Lstar,Hstar,Omega,par)

    if GTradable:
        Gdemand = phiH  * E**(phiH-1) *  G +  (1-n)/n*(1-phiF) *E**(-phiF)*   Gstar
        Gdemandstar =  phiF *E**(1-phiF) * Gstar  + n/(1-n)* (1-phiH) *E**phiH* G
    else:
        Gdemand = G
        Gdemandstar = Gstar



    return np.hstack((  -D + (E**(1-phiH)*Y-w*L),
                        -L + Y,
                        -Y + phiH  * E**(phiH-1) * (C  + I) + (1-n)/n*(1-phiF) *E**(-phiF)*  (Cstar  + Istar) + Gdemand,
                        -Dstar + (E**(phiF-1)*Ystar-wstar*Lstar),
                        -Lstar + Ystar,
                        -Ystar + phiF *E**(1-phiF)  * (Cstar + Istar)  + n/(1-n)* (1-phiH) *E**phiH* (C + I) + Gdemandstar,
                        -muC + muCstar,
                        -E + E_L*piDomestic/piForeign
    ))




class GEModelClass(ModelClass):
    FixedPrices = False
    CompleteMarkets = True
    Name = "Complete Markets."

    # ---- Packing and unpacking variables -----
    # We do not impose bond market-clearing, but use it to subsitute for one of the bond positions.
    # We do not impose the goods market clearing condition in the foregin economy by Walra's law.
    # Here we define functions that pack and unpack the XLocal, XForeign, and XGlobal into a big vector X.
    # In doing so, we use bond-market-clearing.  This is sort of similar to how I do the Reiter method.


    def PackX(self,XLocal,XGlobal,XForeign):
        return np.hstack(( XLocal.X,  XGlobal.X,XForeign.X))


    def UnpackX1D(self,X,par):
        XLocal = LocalIndexer(X[:nXLocal])
        XGlobal = GlobalIndexer(X[nXLocal:(nXLocal+nXGlobal)])
        XForeign =  LocalIndexer(X[(nXLocal+nXGlobal):] )
        return XLocal, XGlobal, XForeign

    def UnpackX2D(self,X,par):
        return self.UnpackX1D(X,par)

    ## -- Dynamics Functions
    def F(self,X_L,X,X_P,epsilon,par,Regime=1):
        """This function gathers together all the dynamics functions."""
        XLocal, XGlobal, XForeign = self.UnpackX(X,par)
        XLocal_P, XGlobal_P, XForeign_P = self.UnpackX(X_P,par)
        XLocal_L, XGlobal_L, XForeign_L = self.UnpackX(X_L,par)

        IsShort = Regime == 1

        return np.hstack((
            ResInvestmentDynamics(XLocal,XLocal_L, 'Home', IsShort, par  ),
            ResInvestmentDynamics(XForeign,XForeign_L, 'Foreign', IsShort, par  ),
            ConsumptionDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, par  ),
            ConsumptionDynamics(XForeign,XForeign_P,XForeign_L,XGlobal,XGlobal_P,XGlobal_L , par )[1:], # drop Euler equation
            PriceDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, XForeign, 'Home', par  ),
            PriceDynamics(XForeign,XForeign_P,XForeign_L,XGlobal,XGlobal_P,XGlobal_L, XLocal, 'Foreign', par  ),
            ExogDynamics(XLocal,XLocal_L,XForeign,XForeign_L,XGlobal,XGlobal_L,epsilon,par),
            GovernmentDynamics(XLocal,XLocal_L,XGlobal, XForeign, XForeign_L, par  ),
            MarketClearingDynamics(XLocal,XGlobal,XGlobal_L,XForeign,par),
            PartialEquilibriumDynamics(XLocal,XLocal_P,XForeign,XForeign_P, XGlobal, par  ),

        ))

    def SteadyState(self,par):
        par.pack(TSS = brentq(lambda T: CheckT(par,T),0.1,0.3))
        XLocal, XGlobal, par = TestSteadyState(par,XLocal = LocalIndexer(nXLocal),XGlobal= GlobalIndexer(nXGlobal))
        self.epsilon_SS = np.zeros(nEps)
        TestCollection([ResInvestmentDynamics,ConsumptionDynamics,ExogDynamics,GovernmentDynamics,MarketClearingDynamics,PartialEquilibriumDynamics,PriceDynamics],
            XLocal, XGlobal, self.epsilon_SS, par)
        self.X_SS = self.PackX(XLocal,XGlobal,XLocal)

    def PE_dlogC(self,X_L,X):
        L,G,F = self.UnpackX(X,self.par)
        dlogC, = G.unpack(['dlogC'])
        return dlogC
