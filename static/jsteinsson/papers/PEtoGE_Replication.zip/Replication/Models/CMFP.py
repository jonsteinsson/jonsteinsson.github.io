import autograd.numpy as np
np.set_printoptions(suppress=True,precision=8)

from Support import ModelClass, Indexer

from Models.CommonModelElements import *
PartialEquilibriumDynamics = PartialEquilibriumDynamicsCM
GovernmentDynamics = GovernmentDynamicsFP

#---- Indexation


# Indexing
nXLocal = 12
nXGlobal = 3
nX = 2*nXLocal + nXGlobal
nEps = 3



class LocalIndexer(Indexer):
    # Note: make B_pat first
    nX = nXLocal
    L, C, H, P, Y, w, I, M, PM, G, D, T   = range(nXLocal)


class GlobalIndexer(Indexer):
    nX = nXGlobal
    interest = 0
    Omega = 1
    dlogC = 2


# li = LocalIndexer()
# gi = GlobalIndexer()



# ------Dynamics ----

def ConsumptionDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, par  ):

    beta, nu, psi, sigma, delta, kappa = par.unpack(['beta', 'nu', 'psi', 'sigma', 'delta', 'kappa'])

    P,  w, T, C, L, H, D = XLocal.unpack(['P','w','T','C','L','H', 'D'])
    P_P, C_P, L_P, H_P = XLocal_P.unpack(['P', 'C', 'L','H'])
    H_L, = XLocal_L.unpack(['H'])
    interest, Omega = XGlobal.unpack(['interest','Omega'])
    interest_L, = XGlobal_L.unpack(['interest'])
    Omega_P, = XGlobal_P.unpack(['Omega'])

    muC = u_C(C,L,H,Omega,par)
    muC_P =  u_C(C_P,L_P,H_P,Omega_P,par)

    muL = u_L(C,L,H,Omega,par)
    muH = u_H(C,L,H,Omega,par)

    res = np.hstack((
        muC - beta * muC_P *  (1+interest),  #Euler equation
        -muH + P * muC - beta*(P_P*(1-delta)*muC_P),# User Cost eqn
        muL + w * muC # Labor supply
    ))
    return res


def MarketClearingDynamics(XLocal,XGlobal,XGlobal_L,XForeign,par):
    phiH,phiF,n, GTradable  = par.unpack(['phiH','phiF','n','GTradable'])

    G, C, I, L, Y, D, w, H = XLocal.unpack(['G', 'C', 'I', 'L', 'Y', 'D', 'w', 'H'])
    Gstar, Cstar, Istar, Lstar, Ystar, Dstar, wstar, Hstar = XForeign.unpack(['G', 'C', 'I', 'L', 'Y', 'D', 'w', 'H'])
    Omega, = XGlobal.unpack(['Omega'])

    muC = u_C(C,L,H,Omega,par)
    muCstar = u_C(Cstar,Lstar,Hstar,Omega,par)

    if GTradable:
        Gdemand = phiH  *  G +  (1-n)/n*(1-phiF) *   Gstar
        Gdemandstar =  phiF * Gstar  + n/(1-n)* (1-phiH) * G
    else:
        Gdemand = G
        Gdemandstar = Gstar

    return np.hstack((  -D + (Y-w*L),
                        -L + Y,
                        -Y + phiH  * (C  + I ) + (1-n)/n*(1-phiF) * (Cstar  + Istar) + Gdemand,
                        -Dstar + (Ystar-wstar*Lstar),
                        -Lstar + Ystar,
                        -Ystar + phiF  * (Cstar + Istar )  + n/(1-n)* (1-phiH) * (C + I ) + Gdemandstar,
                        -muC + muCstar
    ))






class GEModelClass(ModelClass):
    FixedPrices = True
    CompleteMarkets = True
    Name = "Complete Markets: Fixed Prices."

    # ---- Packing and unpacking variables -----
    # We do not impose bond market-clearing, but use it to subsitute for one of the bond positions.
    # We do not impose the goods market clearing condition in the foregin economy by Walra's law.
    # Here we define functions that pack and unpack the XLocal, XForeign, and XGlobal into a big vector X.
    # In doing so, we use bond-market-clearing.  This is sort of similar to how I do the Reiter method.


    def PackX(self,XLocal,XGlobal,XForeign):
        return np.hstack(( XLocal.X,  XGlobal.X,XForeign.X))


    def UnpackX1D(self,X,par):
        XLocal = LocalIndexer(X[:nXLocal])
        XGlobal = GlobalIndexer(X[nXLocal:(nXLocal+nXGlobal)])
        XForeign =  LocalIndexer(X[(nXLocal+nXGlobal):] )
        return XLocal, XGlobal, XForeign

    def UnpackX2D(self,X,par):
        return self.UnpackX1D(X,par)

    ## -- Dynamics Functions
    def F(self,X_L,X,X_P,epsilon,par,Regime=1):
        """This function gathers together all the dynamics functions.
        Regime = 1 indicates short run
               = 2 indicates long run
        """
        XLocal, XGlobal, XForeign = self.UnpackX(X,par)
        XLocal_P, XGlobal_P, XForeign_P = self.UnpackX(X_P,par)
        XLocal_L, XGlobal_L, XForeign_L = self.UnpackX(X_L,par)

        IsShort = Regime == 1

        return np.hstack((
            ResInvestmentDynamics(XLocal,XLocal_L, 'Home', IsShort, par  ),
            ResInvestmentDynamics(XForeign,XForeign_L, 'Foreign', IsShort, par  ),
            ConsumptionDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, par  ),
            ConsumptionDynamics(XForeign,XForeign_P,XForeign_L,XGlobal,XGlobal_P,XGlobal_L , par )[1:], # drop Euler equation
            ExogDynamics(XLocal,XLocal_L,XForeign,XForeign_L,XGlobal,XGlobal_L,epsilon,par),
            GovernmentDynamics(XLocal,XLocal_L,XGlobal, XForeign, XForeign_L, par  ),
            MarketClearingDynamics(XLocal,XGlobal,XGlobal_L,XForeign,par),
            PartialEquilibriumDynamics(XLocal,XLocal_P,XForeign,XForeign_P, XGlobal, par  )
        ))

    def SteadyState(self,par):
        par.pack(TSS = brentq(lambda T: CheckT(par,T),0.,1.0))
        XLocal, XGlobal, par = TestSteadyState(par,XLocal = LocalIndexer(nXLocal),XGlobal= GlobalIndexer(nXGlobal))
        self.epsilon_SS = np.zeros(nEps)
        TestCollection([ResInvestmentDynamics,ConsumptionDynamics,ExogDynamics,GovernmentDynamics,MarketClearingDynamics,PartialEquilibriumDynamics],
            XLocal, XGlobal, self.epsilon_SS, par)
        self.X_SS = self.PackX(XLocal,XGlobal,XLocal)

    def PE_dlogC(self,X_L,X):
        L,G,F = self.UnpackX(X,self.par)
        dlogC, = G.unpack(['dlogC'])
        return dlogC
