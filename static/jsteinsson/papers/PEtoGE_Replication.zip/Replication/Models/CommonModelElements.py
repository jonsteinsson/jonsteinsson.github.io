import inspect
import autograd.numpy as np
np.set_printoptions(suppress=True,precision=8)
from scipy.optimize import brentq


def u_C(C,L,H,Omega,par):
    psi, nu, kappa, sigma = par.unpack(['psi','nu','kappa','sigma'])
    return ((C-psi*L**(1+nu)/(1+nu))**kappa * (H-Omega)**(1-kappa))**(-sigma) * kappa * (C-psi*L**(1+nu)/(1+nu))**(kappa-1) * (H-Omega)**(1-kappa)


def u_L(C,L,H,Omega,par):
    psi, nu, kappa, sigma = par.unpack(['psi','nu','kappa','sigma'])
    return -u_C(C,L,H,Omega,par) * psi * L**nu

def u_H(C,L,H,Omega,par):
    psi, nu, kappa, sigma = par.unpack(['psi','nu','kappa','sigma'])
    return ((C-psi*L**(1+nu)/(1+nu))**kappa * (H-Omega)**(1-kappa))**(-sigma) * (1-kappa) * (C-psi*L**(1+nu)/(1+nu))**(kappa) * (H-Omega)**(-kappa)



def TestSteadyState(par,XLocal=None,XGlobal = None,Mode='values'):

    TSS, beta, eta, psi, nu, kappa, delta, alpha, gamma, chi, GY = par.unpack(['TSS', 'beta', 'eta', 'psi', 'nu', 'kappa', 'delta', 'alpha', 'gammaShort', 'chi', 'GY'])

    Omega = 0.
    T = TSS
    interest = 1/beta - 1
    pi = 1.0
    w = (eta-1)/eta
    L = (w/psi)**(1./nu)
    Y = L
    D = (Y - w * L)

    # Household block
    P = 1   # fix Mbar so SS price is 1, this is a normalization of a unit of housing
    B = 0.0
    X = (1-kappa)/kappa / P / (1-beta*(1-delta))
    C = (w * L - T + D + interest * B  + delta  * P * X*psi*L**(1+nu)/(1+nu)) / (1+delta*P*X)
    H = X * (C - psi * L**(1+nu)/(1+nu))

    # housing supply
    # H = alpha**(alpha/(1-alpha)) * Mbar * P**(gamma+ alpha/(1-alpha)) / delta
    if alpha > 1e-6:
        Mbar = H / (alpha**(alpha/(1-alpha))  * P**(gamma+ alpha/(1-alpha)) / delta)
        M = Mbar * P**gamma
        PM = (1-alpha)/alpha * (alpha * P)**(1./(1-alpha))
    else:
        Mbar = H / (  P**gamma / delta)
        M = Mbar * P**gamma
        PM = P

    G = GY * Y
    T2 = G - PM * M

    par.pack(GSS = G, Mbar = Mbar, interestSS = interest, CSS = C, LSS = L, wSS = w, DSS = D , HSS  = H, PSS = P)

    if Mode.lower() == 'test':
        return T - T2

    elif Mode.lower() == 'values':
        I = alpha**(1./(1-alpha))*Mbar * P**(gamma + 1./(1-alpha))
        Pstar = 1.0
        PB = Y/(1-chi*beta)
        PA =  PB
        piDomestic = 1.0
        E = 1.0

        XLocal.pack(T=T,w=w,L=L,Y=Y,D=D)
        XLocal.pack(P=P,C=C,H=H,M=M,PM=PM)
        XLocal.pack(G=G,I=I)
        XLocal.pack(pi=pi,piDomestic=piDomestic,PA=PA,PB=PB,Pstar=Pstar)
        XLocal.pack(B = B)

        XGlobal.pack(E = E, interest = interest, Omega = Omega)

        return XLocal, XGlobal ,  par

    else:
        raise RuntimeError('Mode not recognized.')



# --- Solve the Steady State
def CheckT(par,T):
    par.pack(TSS = T)
    return TestSteadyState(par,Mode='test')



def PartialEquilibriumDynamicsCM(XLocal,XLocal_P,XForeign,XForeign_P, XGlobal, par  ):
    '''See notebook for 6/11/19 and PartialEquilibrium.ipynb '''
    nu, psi, sigma, delta, kappa, interestSS, CSS, LSS = par.unpack(['nu', 'psi', 'sigma', 'delta', 'kappa','interestSS','CSS','LSS'])

    P,  = XLocal.unpack(['P'])
    P_P,  = XLocal_P.unpack(['P'])
    Pstar,  = XForeign.unpack(['P'])
    Pstar_P,  = XForeign_P.unpack(['P'])
    dlogC, = XGlobal.unpack(['dlogC'])

    x = (1-kappa)/kappa / (P - (1-delta)*P_P/(1+interestSS))
    xstar = (1-kappa)/kappa / (Pstar - (1-delta)*Pstar_P/(1+interestSS))
    dlogCtilde = (1-kappa)*(1-sigma)/sigma * (np.log(x) - np.log(xstar))
    CtildeBar = CSS - psi * LSS**(1+nu)/(1+nu)
    return -dlogC + CtildeBar/CSS * dlogCtilde



def ResInvestmentDynamics(XLocal,XLocal_L,HomeForeign, IsShort, par  ):
    alpha, gammaShort, gammaShortStar, gammaLong, gammaLongStar, Mbar, delta = par.unpack(['alpha', 'gammaShort', 'gammaShortStar', 'gammaLong', 'gammaLongStar', 'Mbar', 'delta'])

    P, M, I , PM ,H  = XLocal.unpack(['P','M','I','PM','H'])
    H_L, = XLocal_L.unpack(['H'])

    IsForeign = HomeForeign.lower() == 'foreign'  or HomeForeign.lower() == 'f'

    if IsShort and IsForeign:
        gamma_temp = gammaShortStar
    elif IsShort and not IsForeign:
        gamma_temp = gammaShort
    elif not IsShort and IsForeign:
        gamma_temp = gammaLongStar
    elif not IsShort and not IsForeign:
        gamma_temp = gammaLong


    if alpha > 1e-6:
        res = np.hstack((
            -H + (1-delta)*H_L + I**alpha * M**(1-alpha),
            -M + Mbar *P**gamma_temp,
            -I + (alpha * P)**(1./(1-alpha)) * M,
            -PM + (1-alpha)/alpha * (alpha * P)**(1./(1-alpha))
            ))
    else:
        res = np.hstack((
            -H + (1-delta)*H_L +  M,
            -M + Mbar *P**gamma_temp,
            -I,
            -PM +  P
            ))
    return res

def PriceDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, XForeign, HomeForeign, par  ):
    chi, beta, eta, phi, phiF = par.unpack(['chi', 'beta','eta','phiH','phiF'])

    Pstar,PA,PB,Y, piDomestic, pi, w = XLocal.unpack(['Pstar','PA','PB','Y', 'piDomestic', 'pi', 'w'])
    PA_P,PB_P, piDomestic_P = XLocal_P.unpack(['PA','PB','piDomestic'])
    interest,E = XGlobal.unpack(['interest','E'])
    piForeign, = XForeign.unpack([ 'piDomestic'])

    if HomeForeign.lower() == 'foreign'  or HomeForeign.lower() == 'f':
        E = 1./E
        phi = phiF

    return np.hstack((  -Pstar + PA/PB,
                        -PA + eta/(eta-1.0) * w * Y + chi / (1+interest) * piDomestic_P**eta * PA_P,
                        -PB +  Y * E**(1-phi) + chi / (1+interest) * piDomestic_P**(eta-1) * PB_P,
                        -piDomestic**(1-eta) + chi + (1-chi)*(Pstar * piDomestic)**(1-eta),
                        -pi + piDomestic**phi * piForeign**(1-phi)
        ))


def GovernmentDynamics(XLocal,XLocal_L,XGlobal, XForeign, XForeign_L, par  ):
    beta, phi_Y, phi_pi, eta, nu, psi, phiH, phiF,n   = par.unpack(['beta','phi_Y','phi_pi','eta', 'nu', 'psi','phiH', 'phiF', 'n'])

    G,T,PM,M,Y,pi = XLocal.unpack(['G','T','PM','M','Y','pi'])
    Gstar,Tstar,PMstar,Mstar,Ystar,pistar = XForeign.unpack(['G','T','PM','M','Y','pi'])
    interest,E = XGlobal.unpack(['interest','E'])

    Ybar = ((eta-1)/eta/psi)**(1./nu)

    return np.hstack((  -(1+interest) + 1./beta + phi_pi*(n*pi + (1-n)*pistar-1)+  phi_Y*((n*Y + (1-n)*Ystar)-Ybar),
                        -T + n*(G  - PM * M ) + (1-n)*E**(1-phiH-phiF)*(Gstar -PMstar*Mstar),
                        -Tstar + n*E**(phiH+phiF-1)*( G  - PM*M) + (1-n)*( Gstar -  PMstar * Mstar)
                        ))


def GovernmentDynamicsFP(XLocal,XLocal_L,XGlobal, XForeign, XForeign_L, par  ):
    beta, phi_Y, eta, nu, psi, n  = par.unpack(['beta','phi_Y','eta', 'nu', 'psi','n'])

    G,T,PM,M,Y = XLocal.unpack(['G','T','PM','M','Y'])
    Gstar,Tstar,PMstar,Mstar,Ystar = XForeign.unpack(['G','T','PM','M','Y'])
    interest, = XGlobal.unpack(['interest'])

    Ybar = ((eta-1)/eta/psi)**(1./nu)

    return np.hstack((  -(1+interest) + 1./beta + phi_Y*((n*Y+(1-n)*Ystar)-Ybar),
                        -T +n*(G   - PM * M) + (1-n)*(Gstar-PMstar*Mstar),
                        -Tstar +(1-n)*(Gstar - PMstar * Mstar) +n* (G-PM*M)
                        ))


def ExogDynamics(XLocal,XLocal_L,XForeign,XForeign_L,XGlobal,XGlobal_L,epsilon,par):
    rhoG, rhoOmega, GSS = par.unpack(['rhoG', 'rhoOmega', 'GSS'])

    G,  = XLocal.unpack(['G'])
    G_L, = XLocal_L.unpack(['G'])
    Gstar,  = XForeign.unpack(['G'])
    Gstar_L, = XForeign_L.unpack(['G'])
    Omega, = XGlobal.unpack(['Omega'])
    Omega_L, = XGlobal_L.unpack(['Omega'])

    return np.hstack((  -G + (1-rhoG)*GSS + rhoG * G_L + epsilon[0],
                        -Gstar + (1-rhoG)*GSS + rhoG * Gstar_L + epsilon[1],
                        -Omega +  rhoOmega * Omega_L + epsilon[2]
                    ))


def TestCollection(fcns, XLocal, XGlobal, epsilon, par):
    def TestSS(Dynamics):
        """ This function takes a function (Dynamics) as an argument and checks that its output is a zero vector in steady state.
        It inspects the function signature to determine its arguments and then passes
        those arguments out of the global namespace.  An argument whose name starts with `XForei` or `XLocal` is
        passed XLocal.  This includes XLocal_L, XLocal_P, and so on.  Similarly any argument name
        that starts with `XGloba` is matched with XGlobal.  The `name` argument to TestSS is simply used for error reporting.   """

        argToPass = []
        for k in inspect.signature(Dynamics).parameters.keys():
            if k[:6] == 'XLocal':
                argToPass.append(XLocal)
            elif k[:6] == 'XGloba':
                argToPass.append(XGlobal)
            elif k[:6] == 'XForei':
                argToPass.append(XLocal)
            elif k[:6] == 'par':
                argToPass.append(par)
            elif k[:6] == 'HomeFo':
                argToPass.append('Home')
            elif k[:6] == 'epsilo':
                argToPass.append(epsilon)
            elif k[:6] == 'IsShor':
                argToPass.append(True)
            else:
                raise RuntimeError('Parameter not recognized')

        r = Dynamics(*argToPass)
        tst = not np.allclose(r,np.zeros(r.shape))
        if tst:
            print(np.where(np.abs(r)>1e-6))
            raise RuntimeError("Error with SS of "+Dynamics.__name__)
    for f in fcns:
        TestSS(f)


## -- cross-sectional PE difference
def PE_dlogC_IM(X_L,X,mod):
    '''See PartialEquilibrium.ipynb'''

    RegimeSwitchProb, kappa, sigma, delta, i, LSS, CSS, psi, nu, HSS = mod.par.unpack(['RegimeSwitchProb','kappa','sigma','delta','interestSS', 'LSS','CSS','psi','nu','HSS'])
    R = 1+i
    xbar = (i+delta)/R
    Dbar = (1+i)/i
    Ctilbar = (CSS - psi*LSS**(1+nu)/(1+nu))

    XLocal, XGlobal, XForeign = mod.UnpackX(X,mod.par)
    XLocal_L, XGlobal_L, XForeign_L = mod.UnpackX(X_L,mod.par)

    P,  = XLocal.unpack(['P'])
    H_L,B_L  = XLocal_L.unpack(['H','B'])
    Pstar,  = XForeign.unpack(['P'])
    Hstar_L,Bstar_L  = XForeign_L.unpack(['H','B'])


    nn = mod.nX-1
    if RegimeSwitchProb < 1e-6:
        # DhatWork = (1-kappa)*(1-sigma)/sigma/xbar * ( R/(R-1) * (np.eye(nn) - (1-delta)/R * mod.P)
        #             -(1-delta)*np.eye(nn) - delta * np.linalg.inv(np.eye(mod.nX-1) - mod.P/R)
        #         ) @ X

        DhatWork = (1-kappa)*(1-sigma)/sigma/xbar * ( R/(R-1) * (np.eye(nn) - (1-delta)/R * mod.P)
                    -np.linalg.inv(np.eye(nn) - mod.P/R)@(np.eye(nn) - (1-delta)/R * mod.P)
                ) @ X

    else:

        waP = (1-RegimeSwitchProb)*mod.P + RegimeSwitchProb * mod.P2

        Pbar = np.zeros((2*nn,2*nn))
        Pbar[:nn,:nn] = (1-RegimeSwitchProb)*mod.P
        Pbar[nn:,:nn] = RegimeSwitchProb*mod.P2
        Pbar[nn:,nn:] = mod.P2

        summer = np.hstack(( np.eye(nn), np.eye(nn)))

        DhatWork = ((1-kappa)*(1-sigma)/sigma/xbar * ( R/(R-1) * (np.eye(nn) - (1-delta)/R *  waP)
                    -(1-delta)*np.eye(nn) - delta *  summer @ np.linalg.inv(np.eye(2*nn) - Pbar/R) @ np.vstack(( np.eye(nn), np.zeros((nn,nn)) ))
                ) ) @ X

    Dhat = DhatWork[XLocal.P]  # select row for P  (e.g. pre-multiply by S)
    Dhatstar = DhatWork[mod.nXLocal + mod.nXGlobal - 1 + XForeign.P] # select row for Pstar


    What = P * HSS *(1-delta) + 1 * H_L *(1-delta)  + (1+i)*B_L
    Chat = kappa * What / Dbar - Ctilbar * Dhat / Dbar

    Whatstar = Pstar * HSS *(1-delta) + Hstar_L * 1 *(1-delta) + (1+i)*Bstar_L
    Chatstar = kappa  / Dbar * Whatstar - Ctilbar / Dbar * Dhatstar


    dlogC = (1/CSS)*(Chat - Chatstar)

    return dlogC.flatten()
