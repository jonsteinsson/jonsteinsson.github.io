import autograd.numpy as np
np.set_printoptions(suppress=True,precision=8)

from Support import ModelClass, Indexer

from Models.CommonModelElements import *



#---- Indexation


# Indexing
nXLocal = 18
nXGlobal = 3
nX = 2*nXLocal + nXGlobal
nEps = 3



class LocalIndexer(Indexer):
    # Note: make B_pat first
    nX = nXLocal
#   0  1  2  3  4     5  6  7  8  9  10  11 12    13         14   15   16  17
    B, L, C, H, P, Y, w, I, M, PM, G, D, T,  piDomestic, pi, Pstar, PA, PB   = range(nXLocal)
    assert(B == 0)

class GlobalIndexer(Indexer):
    nX = nXGlobal
    E, interest, Omega = range(nXGlobal)
    assert(E == 0)


# li = LocalIndexer()
# gi = GlobalIndexer()




# ------Dynamics ----

def ConsumptionDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, par  ):

    beta, nu, psi, sigma, delta, kappa,PortfolioAdjustmentCost  = par.unpack(['beta', 'nu', 'psi', 'sigma', 'delta', 'kappa', 'PortfolioAdjustmentCost'])

    P,  w, T, C, L, H, B, D, pi = XLocal.unpack(['P','w','T','C','L','H','B', 'D','pi'])
    P_P, C_P, L_P, H_P, pi_P = XLocal_P.unpack(['P', 'C', 'L','H','pi'])
    B_L, H_L = XLocal_L.unpack(['B','H'])
    interest, Omega = XGlobal.unpack(['interest','Omega'])
    interest_L, = XGlobal_L.unpack(['interest'])
    Omega_P, = XGlobal_P.unpack(['Omega'])

    muC = u_C(C,L,H,Omega,par)
    muC_P =  u_C(C_P,L_P,H_P,Omega_P,par)

    muL = u_L(C,L,H,Omega,par)
    muH = u_H(C,L,H,Omega,par)

    res = np.hstack((
        muC*(1+PortfolioAdjustmentCost*B) - beta * muC_P *  (1+interest)/pi_P,
        -muH + P * muC - beta*(P_P*(1-delta)*muC_P),# User Cost eq
        C + P * H + B - (w * L - T + (1+interest_L)/pi*B_L + P * H_L*(1-delta) + D - PortfolioAdjustmentCost/2*B**2 ),# Budget
        muL + w * muC, # Labor supply
    ))
    return res


def MarketClearingDynamics(XLocal,XGlobal,XGlobal_L,XForeign,par):
    phiH,phiF,n, CSS, GTradable  = par.unpack(['phiH','phiF','n','CSS','GTradable'])

    G, C, I, L, Y, D, w, H, piDomestic = XLocal.unpack(['G', 'C', 'I', 'L', 'Y', 'D', 'w', 'H','piDomestic'])
    Gstar, Cstar, Istar, Lstar, Ystar, Dstar, wstar, Hstar, piForeign = XForeign.unpack(['G', 'C', 'I', 'L', 'Y', 'D', 'w', 'H','piDomestic'])
    E, = XGlobal.unpack(['E'])
    E_L, = XGlobal_L.unpack(['E'])

    if GTradable:
        Gdemand = phiH  * E**(phiH-1) *  G +  (1-n)/n*(1-phiF) *E**(-phiF)*   Gstar
        Gdemandstar =  phiF *E**(1-phiF) * Gstar  + n/(1-n)* (1-phiH) *E**phiH* G
    else:
        Gdemand = G
        Gdemandstar = Gstar

    return np.hstack((  -D + (E**(1-phiH)* Y-w*L),
                        -L + Y,
                        -Y + phiH * E**(phiH-1) * (C  + I) + (1-n)/n* (1-phiF)*E**(-phiF) * (Cstar + Istar) + Gdemand ,
                        -Dstar + (E**(phiF-1)*Ystar-wstar*Lstar),
                        -Lstar + Ystar,
                        -E + E_L*piDomestic/piForeign
    ))




class GEModelClass(ModelClass):
    FixedPrices = False
    CompleteMarkets = False
    nXLocal = nXLocal
    nXGlobal = nXGlobal
    nX = nX
    nEps = nEps

    Name = "Incomplete Markets."

    # ---- Packing and unpacking variables -----
    # We do not impose bond market-clearing, but use it to subsitute for one of the bond positions.
    # We do not impose the goods market clearing condition in the foregin economy by Walra's law.
    # Here we define functions that pack and unpack the XLocal, XForeign, and XGlobal into a big vector X.
    # In doing so, we use bond-market-clearing.  This is sort of similar to how I do the Reiter method.


    def PackX(self,XLocal,XGlobal,XForeign):
        return np.hstack(( XLocal.X,  XGlobal.X,XForeign.X[1:]))


    def UnpackX1D(self,X,par):
        n, phiH, phiF = par.unpack(['n','phiH','phiF'])
        XLocal = LocalIndexer(X[:nXLocal])
        XGlobal = GlobalIndexer(X[nXLocal:(nXLocal+nXGlobal)])
        E = X[nXLocal] +1  # 1 is steady state of E
        #This is where bond market clearing is imposed
        XForeign =  LocalIndexer(np.hstack((  -X[0]*n/(1-n)*E**(phiH+phiF-1), X[(nXLocal+nXGlobal):] )))
        return XLocal, XGlobal, XForeign

    def UnpackX2D(self,X,par):
        n, phiH, phiF = par.unpack(['n','phiH','phiF'])
        XLocal = LocalIndexer(X[:nXLocal])
        XGlobal = GlobalIndexer(X[nXLocal:(nXLocal+nXGlobal)])
        E = X[nXLocal]+1  # 1 is steady state of E
        #This is where bond market clearing is imposed
        XForeign =  LocalIndexer(np.vstack((  -X[0]*n/(1-n)*E**(phiH+phiF-1), X[(nXLocal+nXGlobal):] )))
        return XLocal, XGlobal, XForeign

    ## -- Dynamics Functions
    def F(self,X_L,X,X_P,epsilon,par,Regime=1):
        """This function gathers together all the dynamics functions."""
        XLocal, XGlobal, XForeign = self.UnpackX(X,par)
        XLocal_P, XGlobal_P, XForeign_P = self.UnpackX(X_P,par)
        XLocal_L, XGlobal_L, XForeign_L = self.UnpackX(X_L,par)

        IsShort = Regime == 1

        return np.hstack((
            ResInvestmentDynamics(XLocal,XLocal_L, 'Home', IsShort, par  ),
            ResInvestmentDynamics(XForeign,XForeign_L, 'Foreign', IsShort, par  ),
            ConsumptionDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, par  ),
            ConsumptionDynamics(XForeign,XForeign_P,XForeign_L,XGlobal,XGlobal_P,XGlobal_L , par ),
            ExogDynamics(XLocal,XLocal_L,XForeign,XForeign_L,XGlobal,XGlobal_L,epsilon,par),
            GovernmentDynamics(XLocal,XLocal_L,XGlobal, XForeign, XForeign_L, par  ),
            MarketClearingDynamics(XLocal,XGlobal,XGlobal_L,XForeign,par),
            PriceDynamics(XLocal,XLocal_P,XLocal_L,XGlobal,XGlobal_P,XGlobal_L, XForeign, 'Home', par  ),
            PriceDynamics(XForeign,XForeign_P,XForeign_L,XGlobal,XGlobal_P,XGlobal_L, XLocal, 'Foreign', par  )
        ))
    ## -- Solve for steady state
    def SteadyState(self,par):
        par.pack(TSS = brentq(lambda T: CheckT(par,T),-0.1,1.0))
        XLocal, XGlobal, par = TestSteadyState(par,XLocal = LocalIndexer(nXLocal),XGlobal= GlobalIndexer(nXGlobal))
        self.epsilon_SS = np.zeros(nEps)
        TestCollection([ResInvestmentDynamics,ConsumptionDynamics,ExogDynamics,GovernmentDynamics,MarketClearingDynamics,PriceDynamics],
            XLocal, XGlobal, self.epsilon_SS, par)
        self.X_SS = self.PackX(XLocal,XGlobal,XLocal)

    def PE_dlogC(self,X_L,X):
        return PE_dlogC_IM(X_L,X,self)
