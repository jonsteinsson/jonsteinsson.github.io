from dataclasses import dataclass
from numpy import nan




@dataclass
class ParamClass:
    n: float
    rhoG: float
    rhoOmega: float
    phiH: float
    phiF: float
    eta: float
    alpha: float
    RegimeSwitchProb: float
    gammaShort: float
    gammaShortStar: float
    gammaLong: float
    gammaLongStar: float
    chi: float
    phi_Y: float
    phi_pi: float
    beta: float
    nu: float
    psi: float
    sigma: float
    delta: float
    kappa: float
    Mbar: float
    GY: float
    PortfolioAdjustmentCost: float
    TSS: float
    GSS: float
    interestSS: float
    CSS: float
    LSS: float
    wSS: float
    DSS: float
    HSS: float
    PSS: float
    TimeAggr: int
    Ndiff: int
    GTradable: bool
    Name: str


    def unpack(self,names):
        return [self.__getattribute__(n) for n in names]

    def pack(self,**kwargs):
        for key in kwargs:
            if hasattr(self,key):
                setattr(self, key, kwargs[key])
            else:
                print(f'No attribute {key}. Not packed.')
