from .Baseline import par as par0
from dataclasses import replace
par = replace(par0,alpha = 0., Name ="Regime switching: no construction." )
