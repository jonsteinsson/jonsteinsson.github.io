from .Baseline import par as par0
from dataclasses import replace

gammaLong, gammaLongStar = par0.unpack(['gammaLong','gammaLongStar'])
par = replace(par0,RegimeSwitchProb = 0.,gammaShort = gammaLong,gammaShortStar = gammaLongStar,Name = "With construction.")
