from .NoSwitch import par as par0
from dataclasses import replace

par = replace(par0,alpha = 0.0, Name = "No construction.")
