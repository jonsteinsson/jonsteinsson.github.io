from .Baseline import par as par0
from dataclasses import replace
robustness_cases = [replace(par0,rhoG = 0.90, Name ="Robustness 1 rhoG = 0.9" ),
                    replace(par0,rhoOmega = 0.90, Name ="Robustness 2 rhoOmega = 0.9" ),
                    replace(par0,chi = 0.75, phiH = 0.7, phiF = 1 - 0.02/(1-0.02)*(1-0.7), Name ="Robustness 3 chi = 0.75, less open" ),
                    replace(par0,sigma = 1., Name ="Robustness 4 sigma=1." )
                    ]
