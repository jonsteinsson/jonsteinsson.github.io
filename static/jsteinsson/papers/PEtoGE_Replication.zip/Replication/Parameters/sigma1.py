from .Baseline import par as par0
from dataclasses import replace
par = replace(par0,sigma = 1., Name ="sigma=1." )
