import autograd.numpy as np
np.set_printoptions(suppress=True,precision=8)

import statsmodels.api as sm



def myreg(y,x,cons):
    reg1 = sm.OLS(endog=y, exog=np.vstack((x,cons)).T, missing='drop')
    results = reg1.fit()
    return results.params[0], results.bse[0]

def mydiff(x,n):
    assert x.ndim == 1
    return x[n:]-x[:-n]

def GetSimulatedData(mod,Sigma,seed,T):
    TimeAggr, Ndiff = mod.par.unpack(['TimeAggr', 'Ndiff'])

    def transform(x,xstar,x_ss,f):
        dx = mydiff(f(x+x_ss),Ndiff)
        dxstar = mydiff(f(xstar+x_ss),Ndiff)
        dx = np.vstack((dx,dxstar))
        meanx = dx.mean(axis=0)
        return (dx - meanx).flatten(), meanx # demean (time fixed effects)


    np.random.seed(seed)
    Xsim = mod.simulate(T+1,Sigma)

    dlogCPE = mod.PE_dlogC(Xsim[:,:-1],Xsim[:,1:])
    Xsim = Xsim[:,1:]

    # Unpack the simulation
    lnames = ['Y','G','P',"C","I"]
    if not mod.FixedPrices:
        lnames += ['pi']

    L, Glob, F = mod.UnpackX(Xsim,mod.par)
    X = np.array(L.unpack(lnames))
    Xstar = np.array(F.unpack(lnames))
    X_SS = mod.UnpackX(mod.X_SS,mod.par)[0].unpack(lnames)


    # time aggregation
    if TimeAggr > 1:
        Aggr = np.kron(np.eye(int(T/TimeAggr)),(1/TimeAggr)*np.ones((TimeAggr,1)))
        X = X @ Aggr
        Xstar = Xstar @ Aggr
        dlogCPE = dlogCPE @ Aggr

    dlogY = transform(X[0],Xstar[0],X_SS[0],np.log)[0]
    dlogP, meanlogP = transform(X[2],Xstar[2],X_SS[2],np.log)
    dlogC = transform(X[3],Xstar[3],X_SS[3],np.log)[0]
    dlogI = transform(X[4],Xstar[4],np.maximum(X_SS[4],1e-6),np.log)[0]
    dY = transform(X[0],Xstar[0],X_SS[0],lambda x: x)[0]
    dG = transform(X[1],Xstar[1],X_SS[1],lambda x: x)[0]

    # region fixed effects
    cons = np.kron(np.eye(2),np.ones(int(T/TimeAggr) - Ndiff))

    if not mod.FixedPrices:
        dpi = transform(X[5],Xstar[5],X_SS[5],lambda x: x)[0]
        dGnorm = dG/X_SS[0]  # normalize by Y
        Xsim = (dlogY, dlogP, dlogC, dlogI, dY, dG, dlogCPE, dpi,dGnorm)
    else:
        Xsim = (dlogY, dlogP, dlogC, dlogI, dY, dG, dlogCPE)

    return Xsim, cons, X_SS, meanlogP


def Get_FM(mod):
    seed = 863282
    Sigma = np.array((.050,.00,0.0))
    T = 2000

    Xsim, cons, X_SS, meanlogP = GetSimulatedData(mod,Sigma,seed,T)
    dlogY, dlogP, dlogC, dlogI, dY, dG = Xsim[:6]

    ConY = X_SS[3]/X_SS[0]
    print('Steady state C/Y ratio = {0}'.format(ConY))

    PriceIncomeElas, StdErr = myreg(dlogP,dlogY,cons)
    print('Elasticity of home price to income = {0}, s.e. = {1}'.format(PriceIncomeElas,StdErr))

    FM, StErr = myreg(dY,dG,cons)
    print('Fiscal multiplier = {0}, s.e. = {1}'.format(FM,StErr))

    if not mod.FixedPrices:
        dpi,dGnorm = Xsim[7:]
        InflationResponse, StErr = myreg(dpi,dGnorm,cons)
        print('Inflation Response = {0}, s.e. = {1}'.format(InflationResponse,StErr))
    else:
        InflationResponse = np.nan

    return FM, ConY,  PriceIncomeElas, InflationResponse

def Get_HWE(mod):
    seed = 92732
    Sigma = np.array((0.0,0.0,0.001))
    T = 2000
    Xsim, cons, X_SS, meanlogP = GetSimulatedData(mod,Sigma,seed,T)
    dlogY, dlogP, dlogC, dlogI = Xsim[:4]

    IonC = X_SS[4]/X_SS[3]
    print('Steady state I/C = {0}'.format(IonC))

    HWE_elas_Y, StErr = myreg(dlogY,dlogP,cons)
    print('Housing wealth effect (Y) = {0}, s.e. = {1}'.format(HWE_elas_Y,StErr))

    HWE_elas_C, StErr = myreg(dlogC,dlogP,cons)
    print('Housing wealth effect (C) = {0}, s.e. = {1}'.format(HWE_elas_C,StErr))

    Constr_elas, StErr = myreg(dlogI,dlogP,cons)
    print('Construction response = {0}, s.e. = {1}'.format(Constr_elas,StErr))

    return HWE_elas_Y, HWE_elas_C, Constr_elas, IonC



def Get_PEHWE(mod):
    seed = 92732
    Sigma = np.array((0.0,0.0,0.001))
    T = 2000

    TimeAggr, Ndiff = mod.par.unpack(['TimeAggr', 'Ndiff'])

    Xsim, cons, X_SS, meanlogP = GetSimulatedData(mod,Sigma,seed,T)
    dlogY, dlogP, dlogC, dlogI, dY, dG, dlogCPE = Xsim[:7]


    dlogCPE = 0.5 * mydiff(dlogCPE,Ndiff)
    dlogP = dlogP[:(int(T/TimeAggr)-Ndiff)]
    cons = np.ones(int(T/TimeAggr)-Ndiff)

    HWE_elas_C, StErr = myreg(dlogCPE,dlogP,cons)
    print('Housing wealth effect (C) = {0}, s.e. = {1}'.format(HWE_elas_C, StErr))

    return HWE_elas_C
