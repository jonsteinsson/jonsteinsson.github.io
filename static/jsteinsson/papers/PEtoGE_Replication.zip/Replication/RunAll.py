import Formula
import os
from math import fabs as abs
from numpy import isnan

import Models.CM
import Models.IM
import Models.CMFP
import Models.IMFP

import Parameters.Baseline
import Parameters.NoAlpha
import Parameters.NoSwitch
import Parameters.NoSwitchNoAlpha
from Parameters.Robustness import robustness_cases as rbc


Roman = ['i','ii','iii','iv','v','vi','vii','viii','ix','x']
Roman = Roman + ['x'+n for n in Roman] + ['xx'+n for n in Roman]
Roman = ['('+ x + ')' for x in Roman]

class Table:

    def __init__(self,Dat):
        self.c = len(Dat)
        self.r = len(Dat[0])

        self.Dat = [ [Dat[i][j] for i in range(self.c)] for j in range(self.r)]

        self.ColLabels = ['']+Roman[:self.c]
        self.RowLabels = [  "Complete Markets",
                            "Rigid Prices",
                            "Construction",
                            "Long-Run Housing Supply Het.",
                            "Measured Housing Wealth Effect",
                            "Local Fiscal Multiplier",
                            "Construction Response",
                            "Income Elasticity of Home Prices",
                            "Implied P.E.~Housing Wealth Effect",
                            "Actual P.E.~Housing Wealth Effect",
                            "Relative Error"]

        self.RowNums = ['','','','',] + [f'({i})' for i in range(1,10)]

    def format(self,x):
        if type(x) == str:
            return x
        elif type(x) == bool:
            if x:
                return '\checkmark'
            else:
                return ''
        elif type(x) == float and isnan(x):
            return "--"
        else:
            return "{:10.3f}".format(x)

    def write(self,fout,DoRowNums=True):
        fout.write("\\begin{table} \n \\caption{Monte Carlo Analysis of Housing Wealth Elasticity} \n    \\begin{center} \n ")

        if DoRowNums:
            fout.write("\\begin{tabular}{ c l " + self.c*"c " + "} \n \\toprule \n" )
            fout.write(" & "+ " & ".join(self.ColLabels) + "\\\\ \n \\midrule \n")
        else:
            fout.write("\\begin{tabular}{ l " + self.c*"c " + "} \n \\toprule \n" )
            fout.write(" & ".join(self.ColLabels) + "\\\\ \n \\midrule \n")

        for i in range(self.r):
            if DoRowNums:
                fout.write( self.RowNums[i] + ' & ')
            fout.write( self.RowLabels[i] + ' & ')
            fout.write(" & ".join([self.format(r) for r in self.Dat[i]]) + "\\\\ \n")

        fout.write("    \\bottomrule \n  \\end{tabular} \n \\end{center} \n \\label{tab:montecarlo} \n \\end{table} \n" )


RESULTSDIR = 'Results/'


def ProcessPairs(ModParPairs):
        TableData = []
        for (mod,par) in ModParPairs:
            m = mod.GEModelClass(par)
            print(m.Name)
            print(par.Name)
            m.solve()
            results = Formula.F(m)
            measured, implied, actual = results[0], results[-2], results[-1]
            RelativeError = abs(implied-actual)/abs(measured-actual)
            TableData.append([m.CompleteMarkets, m.FixedPrices, m.par.alpha > 1e-6, m.par.RegimeSwitchProb > 1e-6] + [x for x in results] + [RelativeError])

        return Table(TableData)



# Make the main table
ModParPairs = [ [Models.CMFP,   Parameters.NoSwitchNoAlpha.par],
                [Models.IMFP,   Parameters.NoSwitchNoAlpha.par],
                [Models.IM,     Parameters.NoSwitchNoAlpha.par],
                [Models.IM,     Parameters.Baseline.par],
            ]


T = ProcessPairs(ModParPairs)
fout = open(os.path.join(RESULTSDIR,'MonteCarloTable.tex'), "w")
T.write(fout,DoRowNums=True)
fout.close()





# Make the robustness table
ModParPairs = [ [Models.IM,   rbc[i]] for i in range(len(rbc))]

T = ProcessPairs(ModParPairs)

fout = open(os.path.join(RESULTSDIR,'RobustnessTable.tex'), "w")
T.write(fout,DoRowNums=False)
fout.close()
