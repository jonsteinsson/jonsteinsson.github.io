import autograd.numpy as np
np.set_printoptions(suppress=True,precision=8)

from SolveQZ import LinSolve, Linearize, solve


class ModelClass:
    def __init__(self,parArg):
        self.par = parArg
        self.SteadyState(parArg)
        self.nEps = len(self.epsilon_SS)

    def solve(self):
        RegimeSwitchProb, = self.par.unpack(['RegimeSwitchProb'])

        if RegimeSwitchProb > 1e-6:
            self.RS_solve(RegimeSwitchProb)
        else:
            # Linearize and solve
            self.P,self.Q = LinSolve(self.F,self.X_SS,self.epsilon_SS,self.par)

    def RS_solve(self,RegimeSwitchProb):
        self.P2,self.Q2 = LinSolve(self.F,self.X_SS,self.epsilon_SS,self.par,Regime=2)
        A1,B1,C,E = Linearize(self.F,self.X_SS,self.epsilon_SS,self.par,Regime=1)

        A = A1*(1-RegimeSwitchProb)
        B = RegimeSwitchProb * A1 @ self.P2 + B1

        self.P, self.Q = solve(A,B,C,E)

    def simulate(self,T,Sigma):
        # T is number of periods to simulate
        # Sigma is vector of standard deviations for shocks
        X = np.zeros((len(self.X_SS),T+1))
        eps = np.diag(Sigma) @ np.random.randn(self.nEps,T)
        for t in range(1,T+1):
            X[:,[t]] = self.P@X[:,[t-1]]+self.Q@eps[:,[t-1]]

        return X[:,1:]


    def IRF(self,T,Sigma):
        # T is number of periods to simulate
        # Sigma is vector of initial shocks
        X = np.zeros((len(self.X_SS),T))
        X[:,[0]] = self.Q@Sigma
        for t in range(1,T):
            X[:,[t]] = self.P@X[:,[t-1]]

        return X


    def UnpackX(self,X,par):
        if X.ndim == 1:
            return self.UnpackX1D(X,par)
        elif X.ndim == 2:
            return self.UnpackX2D(X,par)





class Indexer():

    def __init__(self,X):
        if type(X) == np.ndarray:
            self.X = X
            if not (X.shape[0] == self.nX):
                print(X.shape[0])
                print(self.nX)

            assert(X.shape[0] == self.nX)
        elif type(X) == np.numpy_boxes.ArrayBox:
            self.X = X
        elif type(X) == int:
            self.X = np.zeros(X)
        else:
            print(type(X))
            raise RuntimeError('type of X not recognized')

    def pack(self,**kwargs):
        for key in kwargs:
            if hasattr(self,key):
                self.X[self.__getattribute__(key)] = kwargs[key]
            else:
                print(f'No attribute {key}. Not packed.')

    def unpack(self,VarList):
        retlist = []
        for v in VarList:
            retlist.append(self.X[self.__getattribute__(v)])
        return retlist

    def copy(self):
        return self.__init__(self.X.copy())
