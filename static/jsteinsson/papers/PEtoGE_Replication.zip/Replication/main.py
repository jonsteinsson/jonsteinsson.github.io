import Formula
import importlib
from Arguments import args

modelmodule = importlib.import_module('Models.'+args.ModelName)
parmodule =  importlib.import_module('Parameters.'+args.ParameterName)

mod = modelmodule.GEModelClass(parmodule.par)
mod.solve()

Implied_PE_HWE, Actual_PE_HWE  = Formula.F(mod)[-2:]
print(f'Implied PE HWE = {Implied_PE_HWE}')
print(f'Actual  PE HWE = {Actual_PE_HWE}')
