% Simulate data from an AR(p) with bootstraped errors
%
% Inputs:
%   b and a: inputs into "filter" function
%   e: error distribution to bootstrap from
%   T: length of simulated sample
%
% Jon Steinsson, October 2006
%****************************************************

function y = CreateSimData(b, a, e, T)

% Bootstrap errors
TT = size(e,1);
row = TT*rand(T,1);
row = row + 1;
row = floor(row);
row = int32(row);
bserror = e(row,1);

y = filter(b,a,bserror);