% Estimas an AR(p) model for the real exchange rate of a number of 
% countries
% 
% A grid-bootstrap is used to calculate a median unbiased
% estimate of alpha (the sum of the coefficients). The other 
% parameters of the AR(p) in augmented Dickey Fuller form are 
% estimates by OLS conditional on alpha. Given these estimates
% of the parameters, statistics such as the half-life, up-life
% quarter-life and impulse response function are calculated.
% 
% Conventional bootstrap confidence intervals are 
% calculated for the statistics of interest as well as p-values
% for certain tests
%
% The program uses:
%   hpf.m written by Marianne Baxter and Robert King
%
% Jon Steinsson, October 2006
%*************************************************************************

clear
tic

diary on
diary('EstRealExchangeRate.log')

% Import Data
%*************************************************************************

% Real Exchange Rate Data BIS (quarterly, 1964:1-2006:3)
load('bisdata200610','bisdata200610')
% Set sample period (1975:1-2006:3)
qdata = bisdata200610(45:end,:);
qdata = -log(qdata);

% Consumption data from IFS (quarterly, 1970:1-2005:4)
load('IFSconsump','IFSconsump')
% Set sample period (1975:1-2005:3)
cdata = IFSconsump(21:end-1,:);
cdata = log(cdata);

% Countries
% 1.  Australia   2.  Austria   3.  Belgium     4.  Canada   5.  Denmark
% 6.  Euro Area   7.  Finland   8.  France      9.  Germany  10. Greece
% 11. Hong Kong   12. Ireland   13. Italy       14. Japan    15. Korea
% 16. Mexico      17. Netherl.  18. New Zealand 19. Norway   20. Portugal
% 21. Singapore   22. Spain     23. Sweden      24. Switzerl.25. Taiwan
% 26. UK          27. US
cNames = ['Australia     ';'Austria       ';'Belgium       ';'Canada        ';'Denmark       ';
          'Euro Area     ';'Finland       ';'France        ';'Germany       ';'Greece        ';
          'Hong Kong     ';'Ireland       ';'Italy         ';'Japan         ';'Korea         ';
          'Mexico        ';'Netherlands   ';'New Zealand   ';'Norway        ';'Portugal      ';
          'Singapore     ';'Spain         ';'Sweden        ';'Switzerland   ';'Taiwan        ';
          'UK            ';'US            '];

% Choose Countries to be estimated
%*************************************************************************
      
% countries = [27]; % Only U.S.
countries = [1; 4; 6; 8; 9; 13; 14; 24; 26; 27]; % Countries in Paper
% countries = (1:27)'; % All countries in dataset

Ncountries = size(countries,1);

% Choose data series to work with
%*****************************************************

qall = qdata(:,countries);
call = cdata(:,countries);

T = size(qall,1);

% Choose Simulation Parameters
%*****************************************************

p = 5; % AR(p) lag-length

% Grid bootstrap parameters (see Hansen (1999))
G = 80;
B = 249;
Gs = 250;
Nboot = 1000;

% Quantiles of statistics to be calulated (confidence intervals)
quantiles = [0.05;0.95];

qlow = quantiles(1,1)*(Nboot+1)-mod(quantiles(1,1)*(Nboot+1),1);
if qlow == 0
    qlow = 1;
end
qhigh = quantiles(2,1)*(Nboot+1)-mod(quantiles(2,1)*(Nboot+1),1);
if qhigh == 0
    qhigh = 1;
end

pl = 0; % Indicator as to whether ar_mu_alpha should create a plot
intpr = 0; %Indicator as to whether ar_mu_alpha should print progress signals

% Estimation
%*************************************************************************

for ii = 1:Ncountries
    fprintf('\n')
    fprintf('******************************************\n')
    fprintf('**        Real Exchange Rate of         **\n')
    fprintf('**              %s          **\n',cNames(countries(ii,1),:))
    fprintf('******************************************\n')

    q = qall(:,ii);
    c = call(:,ii);
    
    % check wheter there are missing values in c
    missing = isnan(c);
    cmissing = 0;
    if max(missing) > 0
        cmissing = 1;
    end

    % Preliminary OLS Estimation
    %******************************************************

    % Variables for the regressions
    qt = q(p+1:end,1);
    qt_1 = q(p:end-1,1);
    TT = size(qt,1);
    Dqt = zeros(TT,p-1);
    for i = 1:(p-1)
        Dqt(:,i) = q(p+1-i:end-i,1)-q(p-i:end-1-i,1);
    end
    YY = qt;
    XX = [ones(TT,1) qt_1 Dqt];
    b_ols = inv(XX'*XX)*XX'*YY;
    alpha_ols = b_ols(2,1);
    psi_ols = b_ols(3:end,1);


    % MU Estimation
    %******************************************************

    fprintf('Majorq -- MU\n')
    fprintf('**********************************\n')
    fprintf('\n')
    fprintf('alpha_ols:  %5.3f\n\n',alpha_ols)
    fprintf('psi_ols:\n\n')
    disp(psi_ols')
    fprintf('\n')

    % Calculate MU estimate of alpha
    alpha_range = [alpha_ols-0.07;1];
    alpha_mu = ar_mu_alpha(q,p,alpha_range,G,B,Gs,pl,intpr);

    % Estimate psi by OLS conditional on alpha
    XX = [ones(TT,1) Dqt];
    YY = qt - alpha_mu*qt_1;
    b = inv(XX'*XX)*XX'*YY;
    psi_mu = b(2:end,1);
    e_mu = YY-XX*b;

    % Convert alpha_mu and psi_mu into b_mu and a_mu to be
    % used as inputs in "filter" function
    b_mu = 1;
    a_mu = zeros(p+1,1);
    a_mu(1,1) = 1;
    a_mu(2,1) = -alpha_mu;
    if p > 0
        a_mu(2,1) = a_mu(2,1) - psi_mu(1,1);
        a_mu(p+1,1) = psi_mu(p-1,1);
    end
    for jj = 2:p-1
        a_mu(jj+1,1) = -psi_mu(jj,1) + psi_mu(jj-1,1);
    end

    % Calculate MU estimates of other statistics
    ar_coeff_mu = adfarcoeff(alpha_mu,psi_mu);
    [hl_mu, ul_mu, ql_mu] = ar_lives(ar_coeff_mu);
    ulhl_mu = ul_mu/hl_mu;
    qlhl_mu = ql_mu - hl_mu;
    thlql_mu = 2*hl_mu - ql_mu;
    log2hlql_mu = log(2*hl_mu/ql_mu);
    irf_mu = ar_irf(ar_coeff_mu,30,0);

    % Calculate CKM statistics
    q_hpc = q-hpf(q,1600);
    rho1_q_hpc = corrcoef(q_hpc(2:end,1),q_hpc(1:end-1,1));
    rho1_q_hpc = rho1_q_hpc(2,1);
    if cmissing == 0
        c_hpc = c-hpf(c,1600);
        rel_std_hpc = std(q_hpc)/std(c_hpc);
    else
        rel_std_hpc = 0;
    end

    % Bootstrap Confidence intervals
    %***************************************************

    % Define variable that hold upper and lower bootstrap quantiles
    Qalpha = zeros(2,1);
    Qhl = zeros(2,1);
    Qul = zeros(2,1);
    Qql = zeros(2,1);
    Qqlhl = zeros(2,1);
    Qulhl = zeros(2,1);
    Q2hlql = zeros(2,1);
    Qlog2hlql = zeros(2,1);
    Qirf = zeros(2,31);
    Qrhohp = zeros(2,1);

    %Define variable that hold distributions
    alphaDist = zeros(Nboot,1);
    hlDist = zeros(Nboot,1);
    ulDist = zeros(Nboot,1);
    qlDist = zeros(Nboot,1);
    qlhlDist = zeros(Nboot,1);
    ulhlDist = zeros(Nboot,1);
    thlqlDist = zeros(Nboot,1);
    log2hlqlDist = zeros(Nboot,1);
    irfDist = zeros(Nboot,31);
    rhohpDist = zeros(Nboot,1);

    % Define variables that hold the number of times a certain variable is
    % defined
    ulhlNum = 0;
    qlhlNum = 0;
    thlqlNum = 0;
    log2hlqlNum = 0;

    for i = 1:Nboot
        % Simulate new data series
        qsim = CreateSimData(b_mu,a_mu,e_mu,T);
        %qsim = ar_simdata_rse(alpha_mu, psi_mu, e_mu, T);
        % Calculate MU estimate of alpha
        alphaDist(i,1) = ar_mu_alpha(qsim,p,alpha_range,G,B,Gs,0,0);
        % Estimate psi by OLS conditional on alpha
        qt = qsim(p+1:end,1);
        qt_1 = qsim(p:end-1,1);
        TT = size(qt,1);
        Dqt = zeros(TT,p-1);
        for j = 1:(p-1)
            Dqt(:,j) = qsim(p+1-j:end-j,1)-qsim(p-j:end-1-j,1);
        end
        XX = [ones(TT,1) Dqt];
        YY = qt - alphaDist(i,1)*qt_1;
        b = inv(XX'*XX)*XX'*YY;
        psiDist = b(2:end,1);
        % Calculate MU estimates of other statistics
        ar_coeff_dist = adfarcoeff(alphaDist(i,1),psiDist);
        [hlDist(i,1), ulDist(i,1), qlDist(i,1)] = ar_lives(ar_coeff_dist);
        if ulDist(i,1) == 1000
            ulhlDist(i,1) = NaN;
            qlhlDist(i,1) = NaN;
            thlqlDist(i,1) = NaN;
            log2hlqlDist(i,1) = NaN;
        elseif hlDist(i,1) == 1000
            ulhlDist(i,1) = 0;
            ulhlNum = ulhlNum + 1;
            qlhlDist(i,1) = NaN;
            thlqlDist(i,1) = NaN;
            log2hlqlDist(i,1) = NaN;
        elseif qlDist(i,1) == 5000
            ulhlDist(i,1) = ulDist(i,1)/hlDist(i,1);
            ulhlNum = ulhlNum + 1;
            qlhlDist(i,1) = 1000;
            qlhlNum = qlhlNum + 1;
            thlqlDist(i,1) = -1000;
            thlqlNum = thlqlNum + 1;
            log2hlqlDist(i,1) = -Inf;
            log2hlqlNum = log2hlqlNum + 1;
        else
            ulhlDist(i,1) = ulDist(i,1)/hlDist(i,1);
            ulhlNum = ulhlNum + 1;
            qlhlDist(i,1) = qlDist(i,1) - hlDist(i,1);
            qlhlNum = qlhlNum + 1;
            thlqlDist(i,1) = 2*hlDist(i,1) - qlDist(i,1);
            thlqlNum = thlqlNum + 1;
            log2hlqlDist(i,1) = log(2*hlDist(i,1)/qlDist(i,1));
            log2hlqlNum = log2hlqlNum + 1;
        end
        irf_dist = ar_irf(ar_coeff_dist,30,0);
        irfDist(i,:) = irf_dist';
        % Calculate autocorrelation of HP-filtered Q
        q_hpc_sim = qsim-hpf(qsim,1600);
        rho1_q_hpc_sim = corrcoef(q_hpc_sim(2:end,1),q_hpc_sim(1:end-1,1));
        rhohpDist(i,1) = rho1_q_hpc_sim(2,1);
        if mod(i,10) == 0
            fprintf('%1.0f ',i)
        end
        if mod(i,100) == 0
            fprintf('\n')
        end
    end
    fprintf('\n\n')

    alphaDist = sort(alphaDist);
    hlDist = sort(hlDist);
    ulDist = sort(ulDist);
    qlDist = sort(qlDist);
    qlhlDist = sort(qlhlDist);
    ulhlDist = sort(ulhlDist);
    thlqlDist = sort(thlqlDist);
    log2hlqlDist = sort(log2hlqlDist);
    irfDist = sort(irfDist);
    rhohpDist = sort(rhohpDist);

    fprintf('ulhlNum: %5.3f\n',ulhlNum)
    fprintf('qlhlNum: %5.3f\n',qlhlNum)
    fprintf('thlqlNum: %5.3f\n',thlqlNum)
    fprintf('log2hlqlNum: %5.3f\n\n',log2hlqlNum)

    qlowulhl = quantiles(1,1)*(ulhlNum+1)-mod(quantiles(1,1)*(ulhlNum+1),1);
    if qlowulhl == 0
        qlowulhl = 1;
    end
    qhighulhl = quantiles(2,1)*(ulhlNum+1)-mod(quantiles(2,1)*(ulhlNum+1),1);
    if qhighulhl == 0
        qhighulhl = 1;
    end

    qlowqlhl = quantiles(1,1)*(qlhlNum+1)-mod(quantiles(1,1)*(qlhlNum+1),1);
    if qlowqlhl == 0
        qlowqlhl = 1;
    end
    qhighqlhl = quantiles(2,1)*(qlhlNum+1)-mod(quantiles(2,1)*(qlhlNum+1),1);
    if qhighqlhl == 0
        qhighqlhl = 1;
    end

    qlowthlql = quantiles(1,1)*(thlqlNum+1)-mod(quantiles(1,1)*(thlqlNum+1),1);
    if qlowthlql == 0
        qlowthlql = 1;
    end
    qhighthlql = quantiles(2,1)*(thlqlNum+1)-mod(quantiles(2,1)*(thlqlNum+1),1);
    if qhighthlql == 0
        qhighthlql = 1;
    end

    qlowlog2hlql = quantiles(1,1)*(log2hlqlNum+1)-mod(quantiles(1,1)*(log2hlqlNum+1),1);
    if qlowlog2hlql == 0
        qlowlog2hlql = 1;
    end
    qhighlog2hlql = quantiles(2,1)*(log2hlqlNum+1)-mod(quantiles(2,1)*(log2hlqlNum+1),1);
    if qhighlog2hlql == 0
        qhighlog2hlql = 1;
    end

    [qlow qhigh;
        qlowulhl qhighulhl;
        qlowqlhl qhighqlhl;
        qlowthlql qhighthlql;
        qlowlog2hlql qhighlog2hlql]


    Qalpha(1,1) = alphaDist(qlow,1); Qalpha(2,1) = alphaDist(qhigh,1);
    Qhl(1,1) = hlDist(qlow,1); Qhl(2,1) = hlDist(qhigh,1);
    Qul(1,1) = ulDist(qlow,1); Qul(2,1) = ulDist(qhigh,1);
    Qql(1,1) = qlDist(qlow,1); Qql(2,1) = qlDist(qhigh,1);
    Qqlhl(1,1) = qlhlDist(qlowqlhl,1); Qqlhl(2,1) = qlhlDist(qhighqlhl,1);
    Qulhl(1,1) = ulhlDist(qlowulhl,1); Qulhl(2,1) = ulhlDist(qhighulhl,1);
    Q2hlql(1,1) = thlqlDist(qlowthlql,1); Q2hlql(2,1) = thlqlDist(qhighthlql,1);
    Qlog2hlql(1,1) = log2hlqlDist(qlowlog2hlql,1); Qlog2hlql(2,1) = log2hlqlDist(qhighlog2hlql,1);
    Qirf(1,:) = irfDist(qlow,:); Qirf(2,:) = irfDist(qhigh,:);
    Qrhohp(1,1) = rhohpDist(qlow,1); Qrhohp(2,1) = rhohpDist(qhigh,1);

    % Calculate p-values
    %********************************************************
    % Hypotheses considered:
    % alpha = 1, hl = infty, ul = infty, ql = infty
    % ulhl = 0, qlhl = hl, thlql = 0, log2hlql = 0

    alpha_pvalue = 0;
    test = 0;
    i = 0;
    while test == 0
        if alphaDist(Nboot-i,1) < 1
            alpha_pvalue = i/Nboot;
            test = 1;
        end
        i = i + 1;
        if i > Nboot-1
            test = 1;
        end
    end

    hl_pvalue = 0;
    test = 0;
    i = 0;
    while test == 0
        if hlDist(Nboot-i,1) < 1000
            hl_pvalue = i/Nboot;
            test = 1;
        end
        i = i + 1;
        if i > Nboot-1
            test = 1;
        end
    end

    ul_pvalue = 0;
    test = 0;
    i = 0;
    while test == 0
        if ulDist(Nboot-i,1) < 1000
            ul_pvalue = i/Nboot;
            test = 1;
        end
        i = i + 1;
        if i > Nboot-1
            test = 1;
        end
    end

    ql_pvalue = 0;
    test = 0;
    i = 0;
    while test == 0
        if qlDist(Nboot-i,1) < 5000
            ql_pvalue = i/Nboot;
            test = 1;
        end
        i = i + 1;
        if i > Nboot-1
            test = 1;
        end
    end

    ulhl_pvalue = 0;
    test = 0;
    i = 1;
    while test == 0
        if ulhlDist(i,1) > 0
            ulhl_pvalue = (i-1)/ulhlNum;
            test = 1;
        end
        i = i + 1;
        if i > Nboot
            test = 1;
        end
    end

    qlhl_pvalue = 0;
    test = 0;
    i = 1;
    while test == 0
        if qlhlDist(i,1) > 0
            qlhl_pvalue = (i-1)/qlhlNum;
            test = 1;
        end
        i = i + 1;
        if i > Nboot
            test = 1;
        end
    end

    thlql_pvalue = 0;
    test = 0;
    i = 1;
    while test == 0
        if thlqlDist(i,1) > 0
            thlql_pvalue = (i-1)/thlqlNum;
            test = 1;
        end
        i = i + 1;
        if i > Nboot
            test = 1;
        end
    end

    log2hlql_pvalue = 0;
    test = 0;
    i = 1;
    while test == 0
        if log2hlqlDist(i,1) > 0
            log2hlql_pvalue = (i-1)/log2hlqlNum;
            test = 1;
        end
        i = i + 1;
        if i > Nboot
            test = 1;
        end
    end

    % Printouts
    %********************************************************

    fprintf('\n')
    fprintf('             median      %2.0f percent CI    P-values\n',...
        (quantiles(2,1)-quantiles(1,1))*100)
    fprintf('alpha:       %5.3f   [%5.3f, %9.3f]    %5.3f\n',...
        alpha_mu,Qalpha(1,1),Qalpha(2,1),alpha_pvalue)
    fprintf('half-life:   %5.3f   [%5.3f, %9.3f]    %5.3f\n',...
        hl_mu,Qhl(1,1),Qhl(2,1),hl_pvalue)
    fprintf('up-life:     %5.3f   [%5.3f, %9.3f]    %5.3f\n',...
        ul_mu,Qul(1,1),Qul(2,1),ul_pvalue)
    fprintf('quarter-life:%5.3f   [%5.3f, %9.3f]    %5.3f\n',...
        ql_mu,Qql(1,1),Qql(2,1),ql_pvalue)
    fprintf('UL/HL:       %5.3f   [%5.3f, %9.3f]    %5.3f\n',...
        ulhl_mu,Qulhl(1,1),Qulhl(2,1),ulhl_pvalue)
    fprintf('QL-HL:       %5.3f   [%5.3f, %9.3f]    %5.3f\n',...
        qlhl_mu,Qqlhl(1,1),Qqlhl(2,1),qlhl_pvalue)
    fprintf('2HL-Ql       %5.3f   [%5.3f, %9.3f]    %5.3f\n',...
        thlql_mu,Q2hlql(1,1),Q2hlql(2,1),thlql_pvalue)
    fprintf('log(2HL/Ql)  %5.3f   [%5.3f, %9.3f]    %5.3f\n',...
        log2hlql_mu,Qlog2hlql(1,1),Qlog2hlql(2,1),log2hlql_pvalue)
    fprintf('Rho_1 of HP  %5.3f   [%5.3f, %9.3f]\n',...
        rho1_q_hpc,Qrhohp(1,1),Qrhohp(2,1))
    fprintf('Rel. St.Dev. %5.3f   \n',rel_std_hpc)
    fprintf('\n')
    for i = 1:p-1
        fprintf('psi_%1.0f:       %6.3f\n',i,psi_mu(i,1))
    end
end

toc
diary off

        