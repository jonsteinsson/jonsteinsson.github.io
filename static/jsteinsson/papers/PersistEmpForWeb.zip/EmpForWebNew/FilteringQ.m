% Jon Steinsson, Sept 2005
%***********************************************

clear
tic

% Import Data
%****************************************************

% Real Exchange Rate Data BIS (quarterly, 1964:1-2006:3)
load('bisdata200610','bisdata200610')
% Set sample period (1975:1-2006:3)
qdata = bisdata200610(45:end,:);
qdata = -log(qdata);

% Consumption data from IFS (quarterly, 1970:1-2005:4)
load('IFSconsump','IFSconsump')
% Set sample period (1975:1-2005:3)
cdata = IFSconsump(21:end-1,:);
cdata = log(cdata);

% Countries
% 1.  Australia   2.  Austria   3.  Belgium     4.  Canada   5.  Denmark
% 6.  Euro Area   7.  Finland   8.  France      9.  Germany  10. Greece
% 11. Hong Kong   12. Ireland   13. Italy       14. Japan    15. Korea
% 16. Mexico      17. Netherl.  18. New Zealand 19. Norway   20. Portugal
% 21. Singapore   22. Spain     23. Sweden      24. Switzerl.25. Taiwan
% 26. UK          27. US
cNames = ['Australia     ';'Austria       ';'Belgium       ';'Canada        ';'Denmark       ';
          'Euro Area     ';'Finland       ';'France        ';'Germany       ';'Greece        ';
          'Hong Kong     ';'Ireland       ';'Italy         ';'Japan         ';'Korea         ';
          'Mexico        ';'Netherlands   ';'New Zealand   ';'Norway        ';'Portugal      ';
          'Singapore     ';'Spain         ';'Sweden        ';'Switzerland   ';'Taiwan        ';
          'UK            ';'US            '];
countries = [1; 4; 6; 8; 9; 13; 14; 24; 26; 27];
%countries = (1:27)';
Ncountries = size(countries,1);

% Choose data series to work with
%*****************************************************

qall = qdata(:,countries);
call = cdata(:,countries);
T = size(qall,1);

% HP filter very low frequency trend
hpbandwidth = 1000000;
qallfilt = zeros(T,Ncountries);
qalltrend = zeros(T,Ncountries);
for ii = 1:Ncountries
    qallfilt(:,ii) = qall(:,ii)-hpf(qall(:,ii),hpbandwidth);
    qalltrend(:,ii) = hpf(qall(:,ii),hpbandwidth);
end

% Plots
%******************************************************

dt = (1975:0.25:2006.5);

cind = 9;

figure(1)
plot(dt,qall(:,cind),'b-',dt,qalltrend(:,cind),'r-')


