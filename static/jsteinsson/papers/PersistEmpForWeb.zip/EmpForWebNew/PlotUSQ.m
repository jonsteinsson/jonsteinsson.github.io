% Plots the U.S. Real Exchange Rate along with its 
% HP-fiilter trend
%
% Jon Steinsson, October 2006
%******************************************************************

clear
tic

% Import Data
%******************************************************************

% Real Exchange Rate Data BIS (quarterly, 1964:1-2006:3)
load('bisdata200610','bisdata200610')
% Set sample period (1975:1-2006:3)
qdata = bisdata200610(45:end,:);
qdata = -log(qdata);
qus = qdata(:,27);

% Calculate HP-filter trend
%******************************************************************

% Calculate CKM statistics
qus_hpt = hpf(qus,1600);

% Plot
%******************************************************************

dt = (1975:0.25:2006.5)';

figure(1)
plot(dt,qus,'k-',dt,qus_hpt,'k:')



toc