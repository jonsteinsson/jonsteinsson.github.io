% Creates an impulse response function for 
% an AR(p) model
%
% Inputs: alpha -- autoregressive coefficients
%         T -- Number of periods to be calculated
%         yesplot -- 1 if plot desired
%
% Outputs: IRF -- T+1x1 vector containing the impulse 
%                 response function
%
% Jon Steinsson, April 2005
%*****************************************

function IRF = ar_irf(alpha,T,yesplot);

p = length(alpha);
A = zeros(p);
A(1,:) = alpha';
for i = 2:p
    A(i,i-1) = 1;
end
impact = zeros(p,1);
impact(1,1) = 1;
shock = 1;
IRF = VarImpulse(A,impact,shock,T);
IRF = IRF(:,1);
if yesplot == 1
    dt = 0:1:T; dt = dt';
    figure(3)
    plot(dt,IRF,'k-')
end