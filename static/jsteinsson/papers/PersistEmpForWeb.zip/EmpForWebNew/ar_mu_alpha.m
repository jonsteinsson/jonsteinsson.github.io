% Calculates a MU estimate of alpha (the sum of the 
% coefficients) in an AR(p) using a Hansen grid-bootstrap
%
% The model is written in ADF form.
%
% Inputs: y  -- (T+p)x1 data series being analyzied
%         p  -- 1x1 number of lags in autoregressive model
%         alpha_range  -- 2x1 range of alphas to be analyzed
%         G  -- 1x1 number of alpha values to be analyzed fully
%         B  -- 1x1 number of simulations for each alpha
%         Gs -- 1x1 number of alpha values to be evaluated using Kernel estimation
%         pl -- 1x1 If pl == 1 then figure is in created
%         intpr -- 1x1 If intpr == 1 then progress signals are printed
%
% Jon Steinsson, Sept 2005
%***********************************************

function Qalpha = ar_mu_alpha(y,p,alpha_range,G,B,Gs,pl,intpr)

Qalpha = zeros(1,1);

qmed = 0.5*(B+1)-mod(0.5*(B+1),1);
if qmed == 0
    qmed = 1;
end

Ty = size(y,1);

% Variables for the regressions
%***********************************************

yt = y(p+1:end,1);
yt_1 = y(p:end-1,1);
T = length(yt);
Dyt = zeros(T,p-1);
for i = 1:(p-1)
    Dyt(:,i) = y(p+1-i:end-i,1)-y(p-i:end-1-i,1);
end
XX = [ones(T,1) Dyt];

% Initial regression
%***********************************************

[alpha_hat,psi_hat,se_alpha_hat] = ar_olsADF(y,p);

% Choose alpha values to evaluate fully
%***********************************************

int = (alpha_range(2,1)-alpha_range(1,1))/(G-1);
alpha_eval = alpha_range(1,1):int:alpha_range(2,1);
alpha_eval = alpha_eval';

% Calculate confidence interval
%***********************************************

alphaf = alpha_eval;
Sf = zeros(G,1); % Variable to store values of test statistic
Qmedf = zeros(G,1); % Variable to store values of median estimate
if p > 1
    psif = zeros(G,p-1); % Variable to store values of psi
end
for i = 1:G
    alpha = alpha_eval(i,1);
    % Estimate psi for alpha
    YY = yt - alpha*yt_1;
    b_ols = inv(XX'*XX)*XX'*YY;
    e = YY-XX*b_ols;
    psi = b_ols(2:end,1);
    if p > 1
        psif(i,:) = psi';
    end
    % Convert alpha and psi into bSim and aSim to be
    % used as inputs in "filter" function
    bSim = 1;
    aSim = zeros(p+1,1);
    aSim(1,1) = 1;
    aSim(2,1) = -alpha;
    if p > 0
        aSim(2,1) = aSim(2,1) - psi(1,1);
        aSim(p+1,1) = psi(p-1,1);
    end
    for ii = 2:p-1
        aSim(ii+1,1) = -psi(ii,1) + psi(ii-1,1);
    end
    % Calculate test statistic for alpha
    S = (alpha_hat-alpha)/se_alpha_hat;
    Sf(i,1) = S;
    DS = zeros(B,1);
    for j = 1:B
        % Simulate a new data series
        y_sim = CreateSimData(bSim,aSim,e,T);
        %y_sim = ar_simdata_rse(alpha, psi, e, Ty);
        %y_sim = ar_simdata(alpha, psi, T);
        % Calculate OLS estimate of alpha for y_sim
        [alpha_star,psi_star,se_alpha_star] = ar_olsADF(y_sim,p);
        DS(j,1) = (alpha_star-alpha)/se_alpha_star;
    end
    DS = sort(DS);
    Qmedf(i,1) = DS(qmed,1);
    if intpr == 1
        if mod(i,1) == 0
            fprintf('%1.0f ',i)
        end
        if mod(i,15) == 0
            fprintf('\n')
        end
    end
end
if intpr == 1
    fprintf('\n\n')
end

% Smooth the Qf's using Kernel estimation
%**********************************************************

int = (alpha_range(2,1)-alpha_range(1,1))/(Gs-1);
alphafs = alpha_range(1,1):int:alpha_range(2,1);
alphafs = alphafs';

h = 40*int;
Qfs = quant_smooth(h,alphaf,Qmedf,alphafs);
Qmedfs = Qfs(:,1);

% Create Sfs
Sfs = zeros(Gs,1);
for i = 1:Gs
    Sfs(i,1) = (alpha_hat-alphafs(i,1))/se_alpha_hat;
end

% Plot the Qf's and Sf
%**********************************************************

if pl == 1
    Z = zeros(size(Sfs,1),1);
    figure(2)
    plot(alphafs,Sfs,'k-',alphafs,Z,'k-',alphafs,Qmedfs(:,1),'k-',...
        alphaf,Qmedf(:,1),'k-.')
    set(gca,'FontName','times','FontSize',12)
    title('Grid Bootstrap for \alpha','FontSize',14,'FontWeight','demi')
    xlim([alpha_range(1,1) alpha_range(2,1)])
end

% Calculate median unbiased estimate of alpha
%**********************************************************

alpha_cand = [];
for i = 1:Gs
    if ((i == 1) & (Qmedfs(i,1)>Sfs(i,1)))
        alpha_cand = [alpha_cand; alphafs(i,1)];
    elseif ((i>1) & (i<Gs) & (((Qmedfs(i-1,1)>Sfs(i-1,1))&(Qmedfs(i,1)<=Sfs(i,1))) | ...
            ((Qmedfs(i-1,1)<=Sfs(i-1,1))&(Qmedfs(i,1)>Sfs(i,1)))))
        alpha_cand = [alpha_cand; (alphafs(i,1)+alphafs(i,1))/2];
    elseif ((i == Gs) & (Qmedfs(i,1)<Sfs(i,1)))
        alpha_cand = [alpha_cand; alphafs(i,1)];
    end
end
%Ncand = size(alpha_cand,1);
%fprintf('Ncand = %3.0f\n',Ncand)
Qalpha(1,1) = median(alpha_cand);
