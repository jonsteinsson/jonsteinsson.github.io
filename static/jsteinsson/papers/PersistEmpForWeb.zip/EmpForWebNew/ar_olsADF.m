% Estimates an AR(p) model in augmented 
% Dickey-Fuller form using OLS
%
% Inputs: y -- The data series to be used for estimation
%         p -- The order of the AR model
%
% Outputs: alpha -- The estimate of alpha
%          psi -- a (p-1)x1 vector with the estimates
%                 of psi
%
% Jon Steinsson, May 2005
%**********************************************

function [alpha,psi,se_alpha] = ar_olsADF(y,p)

% Variables for the regressions
yt = y(p+1:end,1);
yt_1 = y(p:end-1,1);
T = length(yt);
Dyt = zeros(T,p-1);
for i = 1:(p-1)
    Dyt(:,i) = y(p+1-i:end-i,1)-y(p-i:end-1-i,1);
end

YY = yt;
XX = [ones(T,1) yt_1 Dyt];
AA = inv(XX'*XX);
b = AA*XX'*YY;
alpha = b(2,1);
psi = b(3:end,1);
e = YY-XX*b;
s2 = e'*e/(T-p+1);
var_beta = s2*AA;
se_alpha = (var_beta(2,2))^(1/2);