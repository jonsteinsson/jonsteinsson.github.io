% Simulates a new data set from an AR(p)
% model
%
% Jon Steinsson, May 2005
%*****************************************

function y = ar_simdata_rse(alpha, psi, e, T)

p = size(psi,1)+1;

% Bootstrap errors
TT = size(e,1);
row = TT*rand(T,1);
row = row + 1;
row = floor(row);
row = int32(row);
bserror = e(row,1);


y = zeros(p+T,1);
X = zeros(p-1,1);
if length(psi) == 0
    for j = 1:T
        y(p+j,1) = alpha*y(p+j-1,1) + bserror(j,1);
    end
else
    for j = 1:T
        y(p+j,1) = alpha*y(p+j-1,1) + psi'*X + bserror(j,1);
        X(2:end,1) = X(1:end-1,1);
        X(1,1) = y(p+j,1)-y(p+j-1,1);
    end
end
y = y(p+1:end,1);