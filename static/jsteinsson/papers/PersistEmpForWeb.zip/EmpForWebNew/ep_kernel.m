% The Epanechnikov Kernel
%
% J�n Steinsson
%***************************************

function W = ep_kernel(u)

if abs(u) <= 1
    W = 3/4*(1-u^2);
else
    W = 0;
end

