% Smooths estimates of quantile functions using 
% Kernel estimation
%
% Inputs: h  -- bandwidth
%         alphaf  -- alpha values that have been bootstraped
%         Qf  -- quantiles for alphaf
%         alphafs  -- alpha values that quantiles are desired for
%
% Outputs: Qfs  -- quantiles for alphafs
%
% Jon Steinsson, July 2005
%***********************************************

function Qfs = quant_smooth(h,alphaf,Qf,alphafs);

k = size(Qf,2);
N = size(Qf,1);
Ns = size(alphafs,1);

Qfs = zeros(Ns,k);

for i = 1:Ns
    alpha = alphafs(i,1);
    K = zeros(N,1);
    for j = 1:N
        K(j,1) = ep_kernel((alpha-alphaf(j,1))/h);
    end
    sumK = sum(K);
    for j = 1:k
        Qfs(i,j) = K'*Qf(:,j)/sumK;
    end
end


