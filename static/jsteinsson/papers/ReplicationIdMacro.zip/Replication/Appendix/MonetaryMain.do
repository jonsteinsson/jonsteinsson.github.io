clear
version 13
set more off

/*
//////////////////////////////////////////////////////////////////////////////////////////// 
	This do file creates Figure 1 - 2 from the Appendix of "Identification in Macroeconomics".
	Before running this do file, readers should update two directories below: 
	(1) local variable "Home" to where the "ReplicationPackage" folder is located.
	(2) local variable "Matlab" to where readers' Matlab is located. 
	
	All the figures are saved at "ReplicationPackage/Appendix/Output". 
////////////////////////////////////////////////////////////////////////////////////////////
*/

///////////////////////////////////////////////////////////
/* PLEASE UPDATE THE DIRECTORY HERE */
/* For Mac Users */
//local Home  	= "Users/.../Replication"
//local Matlab  = "Applications/MATLAB_R2016b.app/bin/matlab"

/* For Window Users */
//local Home 	= "C:\...\Replication"
//local Matlab  = "C:\Program Files\MATLAB\R2017a\bin\matlab"
///////////////////////////////////////////////////////////


/* Jon's Computer */
local Home   = "D:\Dropbox\Identification in Macro/Replication\Main Figures"
local Matlab = "C:\Program Files\MATLAB\R2017a\bin\matlab"

/* Yeji's Computer */
//local Home   = "/Users/yejisung/Dropbox_old/Dropbox/Identification in Macro/Replication"
//local Matlab = "/Applications/MATLAB_R2016b.app/bin/matlab"

cd "`Home'/Appendix"

/* VAR options */
global begin 	 1970m1
global end 		 1996m12
global laglength 12

run "Program/CoibionShock.do"

local option -nodisplay -nosplash -nodesktop -r
shell "`Matlab'" `option' "cd '`Home'/appendix/Program'; run('runVAR.m'); exit()"

capture confirm file "Program/temp/RomerJordaIRF.csv"
while _rc{
	capture confirm file "Program/temp/RomerJordaIRF.csv"
	}

/* IRF Plot Options */
global lbound  	-5
global IPrange 	range(-5 2.5)
global IPlabel 	-4(2)2
global CPIrange range(-5 2.5)
global CPIlabel -4(2)2

/* IRF Plot */
run "Program/ConvertIRF.do"
run "Program/IRFplot.do"

/* Multiplier Table */
shell "`Matlab'" `option' " cd '`Home'/appendix/Program/matlab'; run('MultiplierTable.m'); exit()"

