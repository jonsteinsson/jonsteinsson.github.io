set more off
set matsize 1000

use "RawData/MonetaryData.dta", clear
preserve 
drop Date
export delimited "Program/temp/MonetaryData.txt", delimit(tab) replace
restore

local method="Coibion"

// Cholesky order 
quietly: var logIP UE logCPI logCMPI FFR if Date>=m($begin) - $laglength & Date<=m($end), lags(1/$laglength) 

/* Take out the structural shocks from the reduced form shocks: 
Relationship: Given reduced-form error u(t) & structural error e(t), 
u(t)=A*e(t) where e(t)~(O,D) and D is a diagonal matrix & diagonal elements of A=1
WANT: e(t)=A^(-1)*u(t) */

// Triangular factorization
mat reduced_var=e(Sigma) 	// reduced-form error variance
mat P=cholesky(reduced_var) // reduced_var=P*P'=A*D*A'. Hence, P=A*D^(1/2)
// Let S = D^(1/2), then S is the diagonal matrix whose elements are from the diagonal of P
// Finallym A=P*S^(-1)
mat S=diag(vecdiag(P)) 
mat A=P*inv(S)

// Construct reduced-form shocks
predict shock1, res equation(#1) // reduced-form shock from logIP(Tx1)
predict shock2, res equation(#2) // reduced-form shock from UE(Tx1)
predict shock3, res equation(#3) // reduced-form shock from logCPI(Tx1)
predict shock4, res equation(#4) // reduced-form shock from logCMPI(Tx1)
predict shock5, res equation(#5) // reduced-form shock from FFR(Tx1)
mkmat shock1 shock2 shock3 shock4 shock5, matrix(ushock) // ushock=[shock1,...shock5] (Tx5)

// Construct structural MP shocks
mat eshock  = ushock*(inv(A))' // using e(t)=A^(-1)*u(t), E'=U'*(A^(-1))'
mat mpshock = eshock[1...,5] // 5th column=FFR
svmat double mpshock, name(VARshock) // Convert matrix into variable
rename VARshock1 CoibionShock

keep Date CoibionShock
save "Program/temp/CoibionShock.dta",replace
drop Date
export delimited "Program/temp/CoibionShock.txt", delimit(tab) replace

import delimited "RawData/RomerShock.txt", clear
export delimited "Program/temp/RomerShock.txt", delimit(tab) replace

