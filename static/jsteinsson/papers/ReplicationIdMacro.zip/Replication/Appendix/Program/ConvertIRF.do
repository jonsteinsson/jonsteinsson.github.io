clear all

foreach shock in "Coibion" "Romer" {
foreach method in "Var" "Jorda" "Romer"{
	import delimited "Program/temp/`shock'`method'IRF.csv", clear
	erase "Program/temp/`shock'`method'IRF.csv"
	rename (v1 v2 v3) (IP IPup IPlow)
	rename (v4 v5 v6) (CPI CPIup CPIlow)
	rename (v7 v8 v9) (IPFFR CPIFFR multiplier)
	
	label var IPFFR "Impulse responses of 
	
	qui gen step=_n-1
	tsset step
	save "Program/temp/`shock'`method'IRF.dta",replace

}
}

foreach shock in "Coibion" "Romer" { 
	foreach method in "Var" "Jorda" "Romer" {
		use "Program/temp/`shock'`method'IRF.dta",clear
		qui gen cumIP  = sum(IP)
		qui gen cumFFR = sum(IPFFR) // IPFFR is a real interest rate
		
		// One percent decrease in cumulative FFR:
		qui replace cumIP      = round(cumIP,0.01)*(-1)
		qui replace cumFFR	   = round(cumFFR,0.01)*(-1)
		qui replace multiplier = round(multiplier,0.01)*(-1)
		
		keep step cumIP cumFFR multiplier 
		qui gen method = "`method'"
		qui gen shock  = "`shock'"
		
		label var step "Horizon"
		label var cumIP "Industrial Production"
		label var cumFFR "Real FFR"
		label var multiplier "Multiplier"
		
		save "Program/temp/`shock'`method'Multiplier.dta",replace
		
		}
		}
		
clear all

foreach shock in Coibion Romer {
	foreach method in Var Jorda Romer {
		append using "Program/temp/`shock'`method'Multiplier.dta", keep(step multiplier method shock)
		}
		}


export delimited "Program/temp/MultiplierTable.txt" if step==36, delimit(tab) replace


