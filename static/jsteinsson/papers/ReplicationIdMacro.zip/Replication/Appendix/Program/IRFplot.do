clear all

set more off

local soption ="medlarge"

capture confirm file "Output/temp"
if _rc{
	mkdir "Output/temp"
	}

local shock  ="Coibion"
local method ="Var"  
use "Program/temp/`shock'`method'IRF.dta",clear

foreach var in IP CPI{ 
	replace `var'low=$lbound if `var'low<$lbound
	twoway  (rarea `var'up `var'low step, color(ltblue) legend(off)) ///
	(line `var' step, lc(dknavy) legend(off) lw(thick))  ///
	(line `var'FFR step, lc(midblue) lp(solid) lw(thick))  ///
	,xtitle("") ytitle("") legend(off) yscale($`var'range) ylabel($`var'label) ///
	graphregion(color(white)) plotregion(lstyle(foreground)) ///
	plotregion(margin(zero)) l1title("VAR Specification",size(`soption')) 
		
graph save "Output/temp/`shock'`method'`var'.gph", replace
}


local shock="Coibion"
local method="Jorda"  
use "Program/temp/`shock'`method'IRF.dta",clear
	
foreach var in IP CPI{ 
	replace `var'low=$lbound if `var'low<$lbound
	twoway  (rarea `var'up `var'low step, color(ltblue) legend(off)) ///
	(line `var' step, lc(dknavy) legend(off) lw(thick))  ///
	(line `var'FFR step, lc(midblue) lp(solid) lw(thick))  ///
	,xtitle("") ytitle("") legend(off) yscale($`var'range) ylabel($`var'label) ///
	graphregion(color(white)) plotregion(lstyle(foreground)) ///
	plotregion(margin(zero)) l1title("`method' Specification",size(`soption')) 
		
graph save "Output/temp/`shock'`method'`var'.gph", replace
}


local shock="Coibion"
local method="Romer"  	
use "Program/temp/`shock'`method'IRF.dta",clear
	
foreach var in IP CPI{ 
		replace `var'low=$lbound if `var'low<$lbound
		twoway  (rarea `var'up `var'low step, color(ltblue) legend(off)) ///
		(line `var' step, lc(dknavy) legend(off) lw(thick))  ///
		(line `var'FFR step, lc(midblue) lp(solid) lw(thick))  ///
		,xtitle("") ytitle("") legend(off) yscale($`var'range) ylabel($`var'label) ///
		graphregion(color(white)) plotregion(lstyle(foreground)) ///
		plotregion(margin(zero)) l1title("Romer-Romer Specification",size(`soption')) 
		
graph save "Output/temp/`shock'`method'`var'.gph", replace
}


local shock="Romer"
local method="Var"
use "Program/temp/`shock'`method'IRF.dta",clear
	
foreach var in IP CPI{ 
	replace `var'low=$lbound if `var'low<$lbound
	twoway  (rarea `var'up `var'low step, color(ltblue) legend(off)) ///
	(line `var' step, lc(dknavy) legend(off) lw(thick))  ///
	(line `var'FFR step, lc(midblue) lp(solid) lw(thick))  ///
	,xtitle("") ytitle("") legend(off) yscale($`var'range) ylabel($`var'label) ///
	graphregion(color(white)) plotregion(lstyle(foreground)) ///
	plotregion(margin(zero)) l1title("  ",size(`soption')) 
	
	graph save "Output/temp/`shock'`method'`var'.gph", replace
}
	

foreach shock in "Romer"{
foreach method in "Jorda" "Romer"{
	use "Program/temp/`shock'`method'IRF.dta",clear
	
	foreach var in IP CPI{ 
		replace `var'low=$lbound if `var'low<$lbound
		twoway  (rarea `var'up `var'low step, color(ltblue) legend(off)) ///
		(line `var' step, lc(dknavy) legend(off) lw(thick))  ///
		(line `var'FFR step, lc(midblue) lp(solid) lw(thick))  ///
		,xtitle("") ytitle("") legend(off) yscale($`var'range) ylabel($`var'label) ///
		graphregion(color(white)) plotregion(lstyle(foreground)) ///
		plotregion(margin(zero)) l1title("  ",size(`soption')) 
		
	graph save "Output/temp/`shock'`method'`var'.gph", replace
	}
	}
	}


foreach var in IP CPI{
	local glist1`var'
	
	foreach shock in "Coibion" {
		foreach method in "Var" "Jorda" "Romer"{
			local glist1`var' `"`glist1`var'' "Output/temp/`shock'`method'`var'.gph" "'
		}
		graph combine `glist1`var'',rows(3) colfirst graphregion(color(white)) xsize(6) ysize(20) ///
		title("           VAR Shocks",size(`soption') pos(12) ring(3) ) iscale(1)
		graph save "Output/temp/`shock'`var'.gph",replace
		}
	local glist2`var'
	foreach shock in "Romer"{
		foreach method in "Var" "Jorda" "Romer"{
			local glist2`var' `"`glist2`var'' "Output/temp/`shock'`method'`var'.gph" "'
		}
		graph combine `glist2`var'',rows(3) colfirst graphregion(color(white)) xsize(6) ysize(20) ///
		title("           Romer-Romer Shocks",size(`soption') pos(12) ring(3) ) iscale(1)
		graph save "Output/temp/`shock'`var'.gph",replace
		}
	
	}

graph combine "Output/temp/CoibionIP.gph" "Output/temp/RomerIP.gph", rows(1) ///
graphregion(color(white)) xsize(13.5) ysize(18) iscale(0.7)
graph export "Output/FigureA1.pdf",replace	

graph combine "Output/temp/CoibionCPI.gph" "Output/temp/RomerCPI.gph", rows(1) ///
graphregion(color(white)) xsize(13.5) ysize(18) iscale(0.7)
graph export "Output/FigureA2.pdf",replace	

