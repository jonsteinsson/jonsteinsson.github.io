function out=CoibionEstimate(Data)
% input
% Data: nYxn where nY: length of sample & n: # of variables

% VAR set-up
p      = 12; % VAR lag
H      = 50; % Impulse response horizon
Data   = Data';        % Transform to nxnY
[n,nY] = size(Data); % n: # of variables. 

%% VAR estimation
vec = @(x) reshape(x,[],1); 
DEP = Data(:,p+1:nY); % Take out p lags.
T   = length(DEP);    % T: # of observations in the dependent variable

% Construct RHS
Z = zeros(1+n*p,T);
for i=1:T
    Z(1,i)=1;
    Z(2:end, i)= vec(fliplr(Data(:,i:i+p-1)));
end

% Estimate VAR
beta = (kron(inv(Z*Z')*Z, eye(n)))*vec(DEP);
A    = reshape(beta, n, 1+n*p); 
V    = (1/(T-n*p-1))*DEP*(eye(T)-Z'*inv(Z*Z')*Z)*DEP';

% VAR residual 
vecu  = vec(DEP)-kron(Z',eye(n))*beta;
res   = reshape(vecu,n,T); % residual nxT
res   = res';              % Transform to residual Txn 
omega = cov(res);        % var-cov of residual TxT

% Cholesky decomposition
P = chol(omega,'lower');
S = diag(diag(P));
D = P*inv(S);

IRY = zeros(n, H);
IRZ = zeros(1+n*p, H);

for t=1:H
    if t==1
        IRY(:,t)=D(:,5); % 1% increase in FFR
    else
        IRY(:,t)=A*IRZ(:,t);
    end
    IRZ(1,t+1)=0;
    IRZ(2:1+n,t+1)=IRY(:,t);
    IRZ(2+n:end,t+1)=IRZ(2:end-n,t);
end

IRy   = IRY(1,:)'; 
IRcpi = IRY(3,:)';
IRffr = IRY(5,:)';
IR    = [IRy IRcpi IRffr];

out.beta=A;
out.res=res;
out.irf=IR;
end
