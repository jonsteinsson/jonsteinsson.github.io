clear; clc; close all;
global path

%% Import Data
% Sample period
% Data          : 1969m1-1996m12 (28 years*12=336)
% Coibion Shock : 1970m1-1996m12 (27 years*12=324)
load('temp/MonetaryData')
load('temp/CoibionShock')
N = 12*27;
CoibionShock = CoibionShock(1:N); % 1970m1-end
Data=[logIP UE logCPI logCMPI FFR];

%% Estimate

% Bootstrap option
bsN = 999; % # of Bootstrap replications 

% (1) VAR Specification
% VAR data: 5-variable system with Cholesky ordering
CoibionVAR(Data(1:N+12,:),bsN,path); % Use data from 1969m1-end 

% (2) Jorda & Romer-Romer Specification
runCoibion(Data(1+12:N+12,:),CoibionShock,path); % Use Data starting from 1970m1


function runCoibion(Data,shock,path)

% Variables of interest
logIP  = Data(:,1); 
logCPI = Data(:,3); 
FFR    = Data(:,5);

%% Romer IRF option:
% ylag            = # of dependent variable in the RHS
% mshocklag       = # of monetary shocks in the RHS
% contemporaneous = 1 if contemporaneous effect is on, =0 else
% level           = 1 if the dependent variable is level, =0 if differenced data
% horizon         = # of impulse response horizon
% iteration       = # of parametric bootstrap iteration

% IRF Specification
% Baseline:
H = 50; % # of impulse response horizon
romerip                = [];
romerip.ylag           = 24; 
romerip.mshocklag      = 36;
romerip.contemporaneous= 0;
romerip.level          = 0; 
romerip.horizon        = H;
romerip.iteration      = 999;

% CPI response to shock
romercpi=romerip;
romercpi.mshocklag   = 48;


% FFR response to shock
romerffr=romerip;
romerffr.level           = 1; 
romerffr.contemporaneous = 1;

fd = @(x) x(2:end)-x(1:end-1);

% Output=RomerVAR(Data,Shock,options)
% Input: 
% Data   : 1970m1-end
% Shock  : 1970m1-end
% options: IRF specification options
% Output : Hx3 matrix with [Point estimates, Upper bound, Lower bound] 

% For industrial production and CPI, the impulse response estimation is
% specified to take first-differenced data.
IRy    = RomerVAR(fd(logIP),shock,romerip)*100;    
IRcpi  = RomerVAR(fd(logCPI),shock,romercpi)*100;
IRffr  = RomerVAR(FFR,shock,romerffr);

% Construct multiplier.
y              = IRy(:,1); 
cpi            = IRcpi(:,1);
ffr            = IRffr(:,1);
infla          = zeros(H,1); 
infla(1:H-1,:) = cpi(2:end)-cpi(1:end-1);
realffr        =  ffr-infla;
ymultiplier    = cumsum(y,1)./cumsum(realffr,1);

IRF = [IRy IRcpi realffr ffr ymultiplier];
out = IRF(1:H-1,:); % Drop last period because we lose the last observation when creating an ex-ante inflation.

csvwrite(fullfile(path,'temp/CoibionRomerIRF.csv'),out);

%% Jorda IRF option:
% nc       = # of lag of the depedent variable and shocks to control
% horizon  = # of impulse response horizon

% IRF Specification
% Baseline:

jorda         = [];
jorda.nc      = 2;
jorda.horizon = H;

% Output=JordaVAR(Y,Data,Shock,options)
% Input: 
% Y      : 1970m1-end, Variable of interest
% Data   : 1970m1-end, Control variables
% Shock  : 1970m1-end
% options: IRF specification options
% Output : Hx3 matrix with [Point estimates, Upper bound, Lower bound] 

IRy    = JordaVAR(logIP,Data,shock,jorda)*100; 
IRcpi  = JordaVAR(logCPI,Data,shock,jorda)*100;
IRffr  = JordaVAR(FFR,Data,shock,jorda);

% Construct multiplier.
y           = IRy(:,1); 
cpi         = IRcpi(:,1);
ffr         = IRffr(:,1);
infla       = zeros(H,1);infla(1:H-1,:)=cpi(2:end)-cpi(1:end-1);
realffr     = ffr-infla;
ymultiplier = cumsum(y,1)./cumsum(realffr,1);

IRF = [IRy IRcpi realffr ffr ymultiplier];
out = IRF(1:H-1,:); 

csvwrite(fullfile(path,'temp/CoibionJordaIRF.csv'),out);

end

