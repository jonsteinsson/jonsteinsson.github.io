function out=CoibionVAR(Data,bsN,path)
% CoibionVAR.m runs CoibionEstimate.m to run a standard VAR
% Input:
% Data       : Data for VAR. nYxn 
%              where n:the # of variables & nY: sample size.
% bsN        : # of bootstrap replication.

%% 
p   = 12; % # of VAR lags
H   = 50; % impulse response horizon
vec = @(x) reshape(x,[],1); 

%% Point estimates of the impulse responses
out  = CoibionEstimate(Data);
beta = out.beta;
res  = out.res; % residual Txn 
IRF  = out.irf;
T    = length(res);
res  = detrend(res,'constant');

% Store results
y   = IRF(:,1)*100; 
cpi = IRF(:,2)*100;
ffr = IRF(:,3);
% Ex-ante inflations
infla =zeros(H,1);
infla(1:H-1,:) = cpi(2:end)-cpi(1:end-1);
% Ex-ante real interest rates
realffr = ffr-infla; 
% Cumulative multiplier
ymultiplier = cumsum(y,1)./cumsum(realffr,1);

% Take out the last observation as we lost one data point when creating an ex-ante inflation.
IRF = [y cpi];
IRF         = IRF(1:H-1,:); 
realffr     = realffr(1:H-1);
ffr         = ffr(1:H-1);
ymultiplier = ymultiplier(1:H-1);


% Wild Bootstrap to get the confidence intervals of the impulse responses
Data   = Data';        % Transform to Data:nxnY
[n,nY] = size(Data);   % n: # of variables. 

bsIRy   = zeros(H,bsN);
bsIRcpi = zeros(H,bsN);
bsIRffr = zeros(H,bsN);
bsData  = zeros(n,nY);
bsData(:,1:p) = Data(:,1:p); % Initial variables

Z          = zeros(1+n*p,T);
Z(1,:)     = 1;
Z(2:end,1) = vec(fliplr(Data(:,1:p)));

for j=1:bsN
    Eta   = 1-2*(rand(T,1)<0.5);    % Perturb sign.
    bsres = res.*repmat(Eta,1,n);   % res: Txn. repmat: Txn
    for i=1:T
       bsData(:,i+p)  = beta*Z(:,i)+bsres(i,:)';
       Z(2:1+n, i+1)  = bsData(:,i+p);
       Z(2+n:end,i+1) = Z(2:end-n,i);
    end
    bsout = CoibionEstimate(bsData');
    bsirf = bsout.irf;
    bsIRy(:,j)   = bsirf(:,1);
    bsIRcpi(:,j) = bsirf(:,2);
    bsIRffr(:,j) = bsirf(:,3);
end

Y   = bsIRy*100;
CPI = bsIRcpi*100;
OUT = [Y CPI] ;
OUT = OUT(1:H-1,:); % Take out the last period. 
out = zeros(H-1,3*2+3);

for i=1:2
    out(:,(i-1)*3+1)=IRF(:,i);
    Upper=zeros(H-1,1);Lower=Upper;
    bsdata=OUT(:,1+(i-1)*bsN:i*bsN);
    % 95% confidence interval
    for h=1:H-1
    Upper(h)=quantile(bsdata(h,:),0.975);
    Lower(h)=quantile(bsdata(h,:),0.025);
    end
    out(:,(i-1)*3+2)=Upper;
    out(:,(i-1)*3+3)=Lower;
end

out(:,7) = realffr;
out(:,8) = ffr;
out(:,9) = ymultiplier;

csvwrite(fullfile(path,'temp/CoibionVarIRF.csv'),out);
end
