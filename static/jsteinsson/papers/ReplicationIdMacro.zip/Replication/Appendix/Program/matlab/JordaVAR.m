function out = JordaVAR(Y,Data,S,jorda)
% JordaVAR.m estimates the impulse response of Y.
% Input:
% Y    : Variable of interest, nYx1
% Data : Control variables   , nYxn
% S    : Monetary policy shock,nYx1
% jorda: IRF options.

% Jorda Specification:
% y(t+k)-y(t) = const+b_k*shock(t)+controls+u(t+k)
% controls    = shock(t-1), ..., shock(t-nc), Data(t-1),..., Data(t-nc)
% b_k is the IRF at horizon k.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nc      =jorda.nc;
H       =jorda.horizon;
[nY,n]  =size(Data);

IRjorda=zeros(H,1); Upper=IRjorda; Lower=IRjorda;
for h=0:H-1
    if nc==0 % No controls
        DEP    =Y(h+2:nY)-Y(1:nY-h-1);  % take 1 to start from 0
        mshock =S(2:nY-h); % take nc for controls
        RHS    =[ones(nY-h-1,1) mshock];
    else 
        DEP      =Y(nc+1+h:nY)-Y(nc:nY-h-1);  % take nc for controls, take 1 to start from 0
        dim      =length(DEP);  % =nY-nc-h
        mshock   =S(nc+1:nY-h); % take nc for controls
        shocklag =zeros(dim,nc); Xk=zeros(dim,nc*n);
        % Lagged shocks
        for k=0:nc-1
            shocklag(:,k+1)=S(nc-k:nY-h-1-k);
        end
        % Lagged macro variables
        for k=1:nc
            Xk(:,1+(k-1)*n:n*k)=Data(k:dim-1+k,:);
        end
        RHS=[ones(dim,1) mshock shocklag Xk];
    end
    NWlag=1+h; % Increase NW lag by one for each horizon
    [bhat,~,se]  = olshac(DEP,RHS,NWlag);
    IRjorda(h+1) = bhat(2);
    % 95% Confidence Intervals
    Upper(h+1)   = bhat(2)+1.96*se(2);
    Lower(h+1)   = bhat(2)-1.96*se(2);
end
out=[IRjorda,Upper,Lower];
end

