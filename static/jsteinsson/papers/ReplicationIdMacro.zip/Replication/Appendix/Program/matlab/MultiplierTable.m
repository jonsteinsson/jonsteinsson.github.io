% MultiplierTable.m takes the multiplier stored in the csv file and exports
% the table into latex file. 

clear all; clc; close all;
path = cd;

input=[];
input.dataFormat = {'% .2f',2};
input.tableRowLabels = {'VAR Specification','Jorda Specification','Romer-Romer Specification'};
input.tableColLabels = {'VAR Shocks','Romer-Romer Shocks'};
input.tableBorders = 1;
input.tablePlacement = 'H';

title=fullfile(path(1:end-length('matlab')),'temp/Multipliertable.txt');
readData=fopen(title,'r');

header=fgetl(readData);
Data=textscan(readData, '%f%f%s%s');
fclose(readData);

header=textscan(header, '%s');
for k=1:length(header{:})
    eval([header{1}{k} '=Data{k};']);
end

Table=reshape(multiplier,3,2);
input.data=Table;
input.tableCaption = strcat('Impulse response horizon:  36');

latex=latexTable(input);
title = fullfile(path(1:end-length('Program/matlab')), 'Output/MultiplierTable.tex');

fid=fopen(title,'w'); 
for q=1:size(latex,1) 
    fprintf(fid, '%s\n', latex{q}); 
end 
fclose(fid);

