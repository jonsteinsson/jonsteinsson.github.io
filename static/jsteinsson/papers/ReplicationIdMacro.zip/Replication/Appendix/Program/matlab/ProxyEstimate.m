function out=ProxyEstimate(instrument,Data)
% ProxyEstimate.m estimates an external instrument VAR.
% Input
% instrument : a single IV for FFR shock.
% Data       : nYxn where nY is data period and n is # of variables.

% Set-up
p = 12; % # of VAR lags
H = 50; % Impulse response horizon.

Data   = Data';
[n,nY] = size(Data); % n: # of variables. 

%% VAR estimation
vec = @(x) reshape(x,[],1); 
DEP = Data(:,p+1:nY); % Take out lags for the first period.
T   = length(DEP);    % T: # of observations in the dependent variable

Z=zeros(1+n*p,T); % Z is the vectorized RHS variable.
for i=1:T
     Z(1,i)      = 1;    % constant 
     Z(2:end, i) = vec(fliplr(Data(:,i:i+p-1))); % lags
end
beta = (kron(inv(Z*Z')*Z, eye(n)))*vec(DEP); % VAR coefficients
A    = reshape(beta, n, 1+n*p); 
V    = (1/(T-n*p-1))*DEP*(eye(T)-Z'*inv(Z*Z')*Z)*DEP';

vecu  = vec(DEP)-kron(Z',eye(n))*beta;
res   = reshape(vecu,n,T); % residual nxT
res   = res';       % residual Txn 
omega = cov(res); % var-cov of residual TxT

%% 2SLS

z = instrument; 
z = z(length(z)+1-T:end);     % Cut out the instrument to have length T. 

% First stage
xz       = [ones(length(z),1) z];
uhat_ffr = xz*inv(xz'*xz)*xz'*res(:,5); % First stage: regress reduced-form FFR residual on IV

% Second stage
S21s11 = zeros(4,1);
xu     = [ones(length(uhat_ffr),1) uhat_ffr];
for i=1:4
    bhat2     = inv(xu'*xu)*xu'*res(:,i);
    S21s11(i) = bhat2(2);
end

% Apply the moment conditions
Sig11  = omega(5,5);
Sig21  = omega(1:4,5);
Sig22  = omega(1:4,1:4);
Q      = S21s11*Sig11*S21s11'-(Sig21*S21s11'+S21s11*Sig21')+Sig22;
S12S12 = (Sig21-S21s11*Sig11)'*inv(Q)*(Sig21-S21s11*Sig11);
sp     = sqrt(Sig11-S12S12);

% Standard deviation
s = [S21s11*sp; sp];

% Impulse response
IRY = zeros(n, H);
IRZ = zeros(1+n*p, H);

for t=1:H
    if t==1
        IRY(:,t)=s/sp; % 1% increase in FFR
    else
        IRY(:,t) = A*IRZ(:,t);
    end
    IRZ(1,t+1)       = 0;
    IRZ(2:1+n,t+1)   = IRY(:,t);
    IRZ(2+n:end,t+1) = IRZ(2:end-n,t);
end

IRy   = IRY(1,:)'; 
IRcpi = IRY(3,:)';
IRffr = IRY(5,:)';
IR    = [IRy IRcpi IRffr];

out.beta = A;
out.res  = res;
out.irf  = IR;
end
