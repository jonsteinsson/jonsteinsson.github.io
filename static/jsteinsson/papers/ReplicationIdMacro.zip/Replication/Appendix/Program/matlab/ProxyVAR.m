function out=ProxyVAR(instrument,Data,bsN,path)
% ProxyVAR.m runs ProxyEstimate.m to run an external instrument VAR
% Input:
% instrument : a single external instrument. 
% Data       : Data for VAR. nYxn 
%              where n:the # of variables & nY: sample size.
% bsN        : # of bootstrap replication.

%% 
p   = 12; % # of VAR lags
H   = 50; % impulse response horizon
vec = @(x) reshape(x,[],1); 

% Run ProxyEstimate.m for given data and instrument
out  = ProxyEstimate(instrument,Data);
beta = out.beta;
res  = out.res; % residual Txn 
IRF  = out.irf;
T    = length(res);
res  = detrend(res,'constant');

% Point estimates of the impulse response from the real data
y           = IRF(:,1)*100; 
cpi         = IRF(:,2)*100;
ffr         = IRF(:,3);
infla       = zeros(H,1); infla(1:H-1,:)=cpi(2:end)-cpi(1:end-1);
realffr     = ffr-infla;
ymultiplier = cumsum(y,1)./cumsum(realffr,1);
IRF         = [y cpi]; 
% Take out the last period because I lost one data point to get inflation.
IRF         = IRF(1:H-1,:); 
realffr     = realffr(1:H-1);
ffr         = ffr(1:H-1);
ymultiplier = ymultiplier(1:H-1);


%% Bootstrap.

Data   = Data';         % Transform to Data:nxnY
[n,nY] = size(Data);  % n: # of variables. 
bsData = zeros(n,nY); % bsData stores bootstrapped pseudo data
bsData(:,1:p) = Data(:,1:p); % Initial variables

bsIRy   = zeros(H,bsN);
bsIRcpi = zeros(H,bsN);
bsIRffr = zeros(H,bsN);

Z          = zeros(1+n*p,T); % Z: RHS variable for the VAR system
Z(1,:)     = 1;         % constant term
Z(2:end,1) = vec(fliplr(Data(:,1:p))); 

z = instrument; 
z = z(length(z)+1-T:end); % cut the instrument variables to have length T

% Bootstrap
for j=1:bsN
    Eta=1-2*(rand(T,1)<0.5);    % Perturb signs
    bsres  = res.*repmat(Eta,1,n); % Bootstrapped residual: Txn.
    bsinst = z.*Eta;              % Bootstrapped instrument
    % Construct pseudo data.
    for i=1:T
       bsData(:,i+p) = beta*Z(:,i)+bsres(i,:)'; % Feed in bootstrapped error.
       Z(2:1+n, i+1) = bsData(:,i+p);          % Update the dependent variables.
       Z(2+n:end,i+1)= Z(2:end-n,i);
    end
    bsout = ProxyEstimate(bsinst,bsData'); % Run ProxyEstimate.m with the pseudo data.
    bsirf = bsout.irf;
    bsIRy(:,j)  = bsirf(:,1);
    bsIRcpi(:,j)= bsirf(:,2);
    bsIRffr(:,j)= bsirf(:,3);
end


% Bootstrapped impulse responses
Y   = bsIRy*100;
CPI = bsIRcpi*100;
OUT = [Y CPI] ;     % realFFR FFR Ymultiplier]; %Hx(5*bsN)
OUT = OUT(1:H-1,:); % Take out the last period because I lost one data point to get inflation.
out = zeros(H-1,3*2+3);

for i=1:2
    out(:,(i-1)*3+1)=IRF(:,i);
    Upper  = zeros(H-1,1);Lower=Upper;
    bsdata = OUT(:,1+(i-1)*bsN:i*bsN);
    % 95% confidence interval
    for h=1:H-1
    Upper(h) = quantile(bsdata(h,:),0.975);
    Lower(h) = quantile(bsdata(h,:),0.025);
    end
    out(:,(i-1)*3+2) = Upper;
    out(:,(i-1)*3+3) = Lower;
end

out(:,7) = realffr;
out(:,8) = ffr;
out(:,9) = ymultiplier;

csvwrite(fullfile(path,'temp/RomerVarIRF.csv'),out);

end
