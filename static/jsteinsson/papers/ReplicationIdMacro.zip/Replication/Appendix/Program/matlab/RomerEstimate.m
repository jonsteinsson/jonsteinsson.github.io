function [bhat,cov]=RomerEstimate(Y,S,romer)
%% Input:
% Romer IRF option:
% ylag            = # of dependent variable in the RHS
% mshocklag       = # of monetary shocks in the RHS
% contemporaneous = 1 if contemporaneous effect is on, =0 else
% level           = 1 if the dependent variable is level, =0 if differenced data
% horizon         = # of impulse response horizon
% iteration       = # of parametric bootstrap iteration

% Jorda IRF option:
% nc              = # of lag of the depedent variable and shocks to control
% H               = # of impulse response horizon


% Romer&Romer/ARMA(I,J) estimation
% contemporaneous=1:
% for each DEP(t), X(t)=[1 Y(t-1),...Y(t-Ylag) S(t) S(t-1),...S(t-mshocklag) ] 
% contemporaneous=0:
% for each DEP(t), X(t)=[1 Y(t-1),...Y(t-Ylag) S(t-1),...S(t-mshocklag)] 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
nY              = length(Y);
ylag            = romer.ylag; 
mshocklag       = romer.mshocklag;
contemporaneous = romer.contemporaneous; % =1 if contemporaneous effect of shock
level           = romer.level;
Lag             = max(ylag,mshocklag); % maximum lag of dependent variables or lags
DEP             = Y(Lag+1:nY,1);       % Take aside "Lag" for controls

% RHS size
if contemporaneous==1
    X=zeros(nY-Lag,2+ylag+mshocklag);
else
    X=zeros(nY-Lag,1+ylag+mshocklag);
end

X(:,1)=1; % constant=1

% Shock size: 
if level==0 % If using a first-differenced data, we lose the first data point
    S=S(2:end);
end

% Fill in RHS
for t=Lag+1:nY
    if contemporaneous==1
        if ylag==0
            X(t-Lag,2:2+ylag+mshocklag)=fliplr(S(t-mshocklag:t)');        % lags of shocks: [S(t), S(t-1), S(t-2),...,S(t-I)]
        else
            X(t-Lag,2:1+ylag)=fliplr(Y(t-ylag:t-1)');                     % lags of Y: [Y(t-1),Y(t-2),...,Y(t-I)]
            X(t-Lag,1+ylag+1:2+ylag+mshocklag)=fliplr(S(t-mshocklag:t)'); % lags of shocks: [S(t), S(t-1), S(t-2),...,S(t-J)]
        end
    else
        if ylag==0
            X(t-Lag,2:1+ylag+mshocklag)=fliplr(S(t-mshocklag:t-1)');      % lags of shocks: [S(t-1), S(t-2),...,S(t-I)]
        else
            X(t-Lag,2:1+ylag)=fliplr(Y(t-ylag:t-1)');                     % lags of Y: [Y(t-1),Y(t-2),...,Y(t-I)]
            X(t-Lag,2+ylag:1+ylag+mshocklag)=fliplr(S(t-mshocklag:t-1)'); % lags of shocks: [S(t-1), S(t-2),...,S(t-J)]
        end
    end

end

% OLS
bhat = inv(X'*X)*X'*DEP;
res=DEP-X*bhat;

% Heteroscediasticity-consistent estimator  
omega=diag(res.^2);                   % Estimated variance of the residuals
cov=inv(X'*X)*(X'*omega*X)*inv(X'*X); % Estimated variance of the OLS coefficients


end
