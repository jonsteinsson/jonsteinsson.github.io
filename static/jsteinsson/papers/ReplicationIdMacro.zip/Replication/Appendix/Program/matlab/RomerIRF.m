function out=RomerIRF(bhat,romer)
% RomerIRF computes the impulse response of the Romer-Romer specification given the estimated coefficients

% Input:
% Romer IRF option:
% ylag            = # of dependent variable in the RHS
% mshocklag       = # of monetary shocks in the RHS
% contemporaneous = 1 if contemporaneous effect is on, =0 else
% level           = 1 if the dependent variable is level, =0 if differenced data
% horizon         = # of impulse response horizon
% iteration       = # of parametric bootstrap iteration

% Jorda IRF option:
% nc              = # of lag of the depedent variable and shocks to control
% H               = # of impulse response horizon

% Romer&Romer/ARMA(I,J) estimation
% contemporaneous=1:
% for each DEP(t), X(t)=[1 Y(t-1),...Y(t-Ylag) S(t) S(t-1),...S(t-mshocklag) ] 
% contemporaneous=0:
% for each DEP(t), X(t)=[1 Y(t-1),...Y(t-Ylag) S(t-1),...S(t-mshocklag)] 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ylag            = romer.ylag; 
mshocklag       = romer.mshocklag;
contemporaneous = romer.contemporaneous; % =1 if contemporaneous effect of shock
level           = romer.level;
H               = romer.horizon;
Lag             = max(ylag,mshocklag); % maximum lag of dependent variables or lags

%% Construct IRF

% Impulse response of the dependent variable
IRromer=zeros(H,1);    

% Each row of X contains the RHS for computing the IRF
if contemporaneous==1
    X=zeros(H+1,2+ylag+mshocklag); 
    X(:,1)=0;           % constant=0 because we are computing impulse response
    X(1,ylag+2)=1;      % S(t)=1 has effects at t
    for h=1:H
        irfy=dot(bhat,X(h,:));       % y(t)=beta'*x(t) where x(t)=[1,lags of y(t),lags of shocks]
        IRromer(h)=irfy;
        X(h+1,2)=irfy;               % Update a lagged depdent variable for next period
        X(h+1,3:ylag+1)=X(h,2:ylag); % Update y(t-2), ... ,y(t-I) for next period
        X(h+1,ylag+2)=0;             % No more new shock
        X(h+1,ylag+3:end)=X(h,ylag+2:end-1); % Update Shock series
    end
else
    X=zeros(H+1,1+ylag+mshocklag); % Each row of X contains the RHS for computing the IRF
    X(:,1)=0;                      % constant=0 because we are computing impulse response
    X(2,ylag+2)=1;                 % S(t)=1 has no effect at t, has effects at t+1
    for h=2:H
        irfy=dot(bhat,X(h,:));     % y(t)=beta'*x(t) where x(t)=[1,lags of y(t),lags of shocks]
        IRromer(h)=irfy;
        X(h+1,2)=irfy;             % Update a lagged depdent variable for next period
        X(h+1,3:ylag+1)=X(h,2:ylag); % Update y(t-2), ... ,y(t-I) for next period
        X(h+1,ylag+2)=0;             % No more new shock
        X(h+1,ylag+3:end)=X(h,ylag+2:end-1); % Update Shock series
    end
end

if level==0                  % if the dependent variable is first-differenced
    IRromer=cumsum(IRromer); % sum up to compute the IRF of the level
end

out=IRromer;
end
