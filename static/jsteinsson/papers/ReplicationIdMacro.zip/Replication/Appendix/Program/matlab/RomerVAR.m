function out=RomerVAR(Data,shock,romer)
% RomerVAR.m estimates the impulse response and its two standard deviation
% confidence intervals.
% Input:
% Data: nYx1 where nY is the length of sample period starting from 1969m1
% Shock: nYx1

% Estimate the coefficients and their joint variance.
[bhat,Vhat] = RomerEstimate(Data,shock,romer); 
% Estimate the point estimates of the impulse response.
IRromer     = RomerIRF(bhat,romer);

% Estimate the confidence interval of the impulse response.
N=romer.iteration;  % Bootstrap replications.
H=romer.horizon;
rng(1);
Ydraws=zeros(H,N);  % Each column is the impulse response of each draw.
K=length(bhat);

% Random draws from the asymptotic distribution
for n=1:N
    b=bhat+Vhat^(1/2)*randn(K,1);
    Ydraws(:,n)=RomerIRF(b,romer);
end

% 95% confidence interval
Upper=zeros(H,1);
Lower=zeros(H,1);
for h=1:H
    Upper(h)=quantile(Ydraws(h,:),0.975);
    Lower(h)=quantile(Ydraws(h,:),0.025);
end


out=[IRromer,Upper,Lower];

end