function [bhat, varb, stdNW] = olshac(y,X,L)

% computes OLS with Robust, Newey-West heteroscedastic-serial consistent standard errors

% Inputs:
%  y = T x 1 vector, left hand variable data
%  X = T x n matrix, right hand variable data
%  L = number of lags to include in NW corrected standard errors

%Estimate Betas and Residuals
[T,n]  = size(X);
bhat   = (inv(X'*X))*X'*y;
res    = y-X*bhat;
res    = res*ones(1,n);
err    = X.*res; %estimating residuals for each beta

%-----------------------------------------------------------------------%
%Calculate NW Corrected Standard Errors
V=err'*err*(1/T);
if L > -1
    for ind_i = (1:L)
        S = err(1:T-ind_i,:)'*err(1+ind_i:T,:)/T;
        V = V + (1-1*ind_i/(L+1))*(S + S');
    end;
end;

D       =   inv((X'*X)/T);
varb = (1/T)*D*V*D;
seb = diag(varb);
stdNW = sign(seb).*(abs(seb).^0.5);

end
