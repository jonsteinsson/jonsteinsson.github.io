clear; clc; close all;
addpath('matlab')
addpath('temp')

% Import Data

% Macrovariables
clear;
readData = fopen('temp/MonetaryData.txt','r');
header   = fgetl(readData);
Data     = textscan(readData, '%f%f%f%f%f');
fclose(readData);

header=textscan(header, '%s');
for k=1:length(header{:})
    eval([header{1}{k} '=Data{k};']);
end 
save 'temp/MonetaryData' logIP UE logCPI logCMPI FFR

% Coibion Shocks
clear;
readData = fopen('temp/CoibionShock.txt','r'); 
header   = fgetl(readData);
Data     = textscan(readData, '%f');
fclose(readData);
header   = textscan(header, '%s');
eval([header{1}{1} '=Data{1};']);
save 'temp/CoibionShock' CoibionShock

% Romer-Romer Shocks
clear;
readData = fopen('temp/RomerShock.txt','r'); 
header   = fgetl(readData);
Data     = textscan(readData, '%f');
fclose(readData);
header   = textscan(header, '%s');
eval([header{1}{1} '=Data{1};']);
RomerShock = romershock;
save 'temp/RomerShock' RomerShock

global path
path = cd; 

run('matlab/CoibionMain.m')
run('matlab/RomerMain.m')