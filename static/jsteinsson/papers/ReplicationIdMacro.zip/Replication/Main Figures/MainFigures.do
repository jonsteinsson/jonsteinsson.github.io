clear
version 13
set more off

/*
//////////////////////////////////////////////////////////////////////////////////////////// 
	This do file creates Figure 1 - 5 from "Identification in Macroeconomics".
	Before running this do file, readers should update the directory below 
	called "Home" to where the "ReplicationPackage" folder is located.
	
	All the figures are saved at "Replication/Main Figures/Output". 
////////////////////////////////////////////////////////////////////////////////////////////
*/

///////////////////////////////////////////////////////////
/* PLEASE UPDATE THE DIRECTORY HERE */
/* For Mac Users */
//local Home  	= "Users/.../Replication"

/* For Window Users */
//local Home 	= "C:\...\Replication"
///////////////////////////////////////////////////////////


/* Jon's Computer */
local Home = "D:\Dropbox\Identification in Macro/Replication"

/* Yeji's Computer */
//local Home = "/Users/yejisung/Dropbox_old/Dropbox/Identification in Macro/Replication"

cd "`Home'/Main Figures"

* ============================================ *
* ================ Figure 1 ================== *
* ============================================ *

// Import data

import excel "RawData/INDPRO.xlsx", cellrange(A11:B1192) firstrow 

rename observation_date 	Date
rename INDPRO 				Production

qui replace Date = mofd(Date)
format Date %tm

// Change the baseline to 1929

qui sum Production if Date == m(1929m7)
local base = r(mean)
qui gen IP = Production*100/`base'
drop Production

// Keep the dates from Friedman and Schwartz (1963) 
// (1) October 1931
local FSDate1 1931m10
// (2) July 1936 - January 1937
gen FSDate2 = 160 if Date>=m(1936m6) & Date<=m(1937m1)

// Keep the date when the U.S. went off gold
local OffGold 1933m4

// Make a plot

twoway (area FSDate2 Date, bcolor(ltblue)) (line IP Date, lc(navy)) if Date>=m(1925m1) & Date<=m(1942m1), ///
tlabel(1925m1(60)1940m1, format(%tmCY)) tmtick(1925m1(12)1940m1) tline(`FSDate1', noextend lcolor(ltblue)) tline(`OffGold', noextend lcolor(black))  ///
xtitle("Year") ytitle("") ylabel(40(40)160) legend(off) graphregion(color(white)) plotregion(lstyle(foreground)) 

graph export "Output/Figure1.pdf", replace
save "Output/StataData/Figure1.dta", replace

* ============================================ *
* ================ Figure 2 ================== *
* ============================================ *

// Import data

import excel "RawData/CPIAUCSL.xlsx", clear cellrange(A11:B856) firstrow
tempfile temp
save `temp'

import excel "RawData/FEDFUNDS.xlsx", clear cellrange(A11:B766) firstrow
qui merge 1:1 observation_date using `temp', nogenerate
save `temp', replace

import excel "RawData/UNRATE.xlsx", clear cellrange(A11:B844) firstrow
qui merge 1:1 observation_date using `temp', nogenerate

rename observation_date Date
rename CPIAUCSL 		CPI
rename FEDFUNDS			FFR
rename UNRATE			Unrate

qui replace Date = mofd(Date)
format Date %tm
tsset  Date 

qui gen infla12 = (CPI-L12.CPI)/(L12.CPI)*100
label var infla12 "Yearly Chcange in the CPI"

// Make a plot 
gen VolckerDisinflation = 20 if Date>=m(1979m8) & Date<=m(1982m8)

twoway (area VolckerDisinflation Date, bcolor(ltblue) yaxis(1) ) ///
(line FFR     Date, yaxis(1) lp(solid) lc(dknavy)) ///
(line infla12 Date, yaxis(1) lp(solid) lc(red*0.5)) ///
(line Unrate  Date, yaxis(2) lp(shortdash) lc(dkgreen) lw(medthick)) ///
if Date>=m(1968m1) & Date<=m(1994m12),  ///
tlabel(1970m1(60)1995m1,format(%tmCY)) tmtick(1968m1(12)1995m1) ///
ylabel(0(5)20, format(%8.0g) axis(1)) ylabel(2(2)10, format(%8.0g) axis(2)) ///
graphregion(color(white)) plotregion(lstyle(foreground)) xtitle("Year") ytitle("", axis(2)) legend(off)

graph export "Output/Figure2.pdf", replace

drop VolckerDisinflation
save "Output/StataData/Figure2.dta", replace

* ============================================ *
* ================ Figure 3 ================== *
* ============================================ *

import excel "RawData/OECD.xlsx", clear sheet("OECD") firstrow
qui replace Date = mofd(Date)
format Date %tm
tsset  Date 
keep if Date < m(1999m1)

// Change units: Nominal exchange rate (NER) as DEU/USD
qui gen NER_DEU = 1/USD_EURO

// Change pre-1999 units from EURO to DM using the "irrevocable conversion rate": 1 Euro = 1.95583 DM 
qui replace NER_DEU = NER_DEU*1.95583 if Date < m(1999m1)

// Construct real exchange rate (RER)
qui gen RER_DEU 	   = (1/NER_DEU)*(CPI_DEU)*(1/CPI_US)
qui gen RER_DEU_growth = (RER_DEU-L.RER_DEU)/(L.RER_DEU)*100

label var NER_DEU 	     "The US-German Nominal Exchange Rate"
label var RER_DEU 	     "The US-German Real Exchange Rate"
label var RER_DEU_growth "Monthly change in the US-German Real Exchange Rate" 


line RER_DEU_growth Date if Date < m(1986m1), lp(solid) lc(navy) ///
tlabel(1960m1(60)1985m1,format(%tmCY)) yscale(range(-15 15)) ylabel(-15(5)15) ///
tline(1973m2, noextend lcolor(ltblue)) ///
graphregion(color(white)) plotregion(lstyle(foreground)) ///
xtitle("Year") ytitle("Percent") 

graph export "Output/Figure3.pdf", replace
save "Output/StataData/Figure3.dta", replace

* ============================================ *
* ================ Figure 4 ================== *
* ============================================ *

import excel "RawData/UNRATE.xlsx", clear cellrange(A11:B844) firstrow
rename observation_date Date
rename UNRATE			Unrate

qui replace Date = mofd(Date)
format Date %tm
tsset  Date 

// Romer-Romer Date
local RomerDate 1955m9 1968m12 1974m4 1978m8 1979m10 1988m1
	
line Unrate Date if Date>=m(1950m1)&Date<=m(2000m12), lc(navy) ///
tline(`RomerDate',noextend lcolor(ltblue)) tlabel(1950m1(120)2000m1,format(%tmCY)) ///
xtitle("Year") ytitle("") ylabel(2(2)11) graphregion(color(white)) plotregion(lstyle(foreground)) ///

graph export "Output/Figure4.pdf",replace
save "Output/StataData/Figure4.dta", replace

* ============================================ *
* ================ Figure 5 ================== *
* ============================================ *

import excel "RawData/DED1.xlsx", clear cellrange(A11:B11951) firstrow
tempfile temp
save `temp'

import excel "RawData/DFEDTAR.xlsx", clear cellrange(A11:B9588) firstrow
qui merge 1:1 observation_date using `temp', nogenerate

rename observation_date Date
rename DED1				ED
rename DFEDTAR			Target

tsset Date
drop if Date<d(01dec2000) | Date>d(01jan2003)

// Keep when the Federal Funds Rate Target is changed

tostring Date, gen(DateLabel) format(%tdd_m) force
replace DateLabel = "" if _n == 1
forvalues i=2/`=_N'{
	qui replace DateLabel="" if (Target[`i'] == Target[`i'-1] & _n == `i')
	}

// Construct the beginning of the day Federal Fundes Rate target

gen mTarget = L.Target 
// Terrorist attack: Target rate changed before the market opened
replace mTarget = mTarget[_n+1] if Date == d(17sep2001)

// Unscheduled Federal Open Market Committee meeting:
replace DateLabel = DateLabel+"*" if DateLabel == "3 Jan"
replace DateLabel = DateLabel+"*" if DateLabel == "18 Apr"
replace DateLabel = DateLabel+"*" if DateLabel == "17 Sep"

// Make a plot

// Position for the date label in the left panel
gen DLabel = DateLabel[_n+1]
gen 	pos=4
replace pos=3 if DLabel=="27 Jun"
replace pos=3 if DLabel=="21 Aug"
replace pos=5 if DLabel=="17 Sep*"
replace pos=3 if DLabel=="11 Dec"

local ntick1 = floor((d(28feb2002)-d(01dec2000))/30)+1

tw (connected mTarget Date,mlabel(DLabel) mlabvposition(pos) mlabgap(*2.5) msize(vtiny) mlabtextstyle(body)) ///
(line ED Date, color(ltblue)) if Date>=d(01dec2000) & Date<=d(28feb2002),  ///
graphregion(color(white)) plotregion(lstyle(foreground)) legend(off) ///
xtitle("") ytitle("Percent") tlabel(#`ntick1',format(%tdMon)) ///
tscale(range(01dec2000 28feb2002)) 

graph save "Output/Figure5a.gph", replace

// Position for the date label in the right panel
gen 	pos2=5
replace pos2=4 if DLabel=="21 Aug"
replace pos2=4 if DLabel=="2 Oct"

local ntick2 = floor((d(01nov2001)-d(01aug2001))/30)+1

// Markets closed due to the terrorist attacks
gen closed = 4 if Date>=d(11sep2001) & Date<=d(17sep2001)

tw (area closed Date, bcolor(ltblue)) (scatter ED Date, mstyle(o) legend(off)) ///
(connected mTarget Date,legend(off) mlabel(DLabel) mlabvposition(pos2) ///
mlabgap(*10) msize(vtiny) mlabtextstyle(heading) color(dknavy)) if Date>=d(01aug2001) & Date<d(01nov2001), ///
graphregion(color(white)) plotregion(lstyle(foreground))  ///
xtitle("") ytitle("Percent") tlabel(#`ntick2',format(%tdMon)) ///
tscale(range(01aug2001 01nov2001)) 

graph save "Output/Figure5b.gph", replace

graph combine "Output/Figure5a.gph" "Output/Figure5b.gph", ///
rows(1) xsize(20) ysize(10) graphregion(color(white))

graph export "Output/Figure5.pdf",replace

erase "Output/Figure5a.gph"
erase "Output/Figure5b.gph"

keep Date ED Target DLabel
save "Output/StataData/Figure5.dta", replace




