###############################################################################%
# This code is to setup the path, packages and aesthetics
###############################################################################%
rm(list = ls())


### ======= Change your path here ======= ###
#setwd('~/Dropbox/Taylor Rule/Replication/Empirical/')
setwd('C:/Dropbox/Taylor Rule/Replication/Empirical/')

### ======= Packages ======= ###
library(tidyverse)
library(ggrepel)
library(knitr)

### ======= Aesthetics ======= ###
my_theme <- theme_minimal() + 
  theme(axis.title.x = element_blank(),
        legend.title = element_blank(),
        legend.position = "bottom",
        text = element_text(size = 9),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(fill = "white", colour = "grey50", linewidth =1),
        legend.text = element_text(size = 8),
        legend.margin = margin(t = -6, b = 0, l = 0, r = 0), 
  )

theme_set(my_theme)

