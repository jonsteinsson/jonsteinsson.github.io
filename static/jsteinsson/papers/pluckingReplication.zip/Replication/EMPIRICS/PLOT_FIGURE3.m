clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

GRAPH_SETTINGS

%% Load wage rigidity meter
wagerigidity    =xlsread('nominal-wage-rigidity-releases.xlsx');
rigidity        =wagerigidity(:,1);%all workers, hourly and non-hourly
rigidity        =rigidity(201:471);
length(rigidity)
daterigidity    =1997+7/12:1/12:2020+1/12;
length(daterigidity)

mean(rigidity)
std(rigidity)

%% Load unemployment
u                       =xlsread('unemployment.xls');
dateu                   =(1948:1/12:2020+1/12)';
dateu(596)
daterigidity(1)
Tu                      =length(dateu); %=866
u                       =u(1:Tu);
urigidity               =u(596:end);

%% Load employment rate
employmentrate  =xlsread('employmentrate.xls');
dateemployment  =1960:1/12:2020+1/12;
Te              =length(dateemployment);
employmentrate  =employmentrate(1:Te);
dateemployment(452)
daterigidity(1)
e               =employmentrate(452:end);

%% Figure

figure
subplot(1,2,1)
[hAx,hLine1,hLine2] =plotyy(daterigidity,rigidity,daterigidity,urigidity);
set(hLine1, 'Color', our_red);
set(hLine2, 'Color', our_blue);
set(hAx(1),'ycolor',our_red)
set(hAx(2),'ycolor',our_blue)
set(hAx(1),'XLim',[daterigidity(1) daterigidity(end)])
set(hAx(2),'XLim',[daterigidity(1) daterigidity(end)])
set(hAx(1),'YLim',[8 19])
set(hAx(2),'YLim',[2 11])
legend({'Share of zero wage-change (%)','Unemployment Rate (%)'},'Location','SouthEast')

subplot(1,2,2)
[hAx,hLine1,hLine2] =plotyy(daterigidity,rigidity,daterigidity,100-e);
set(hLine1, 'Color', our_red);
set(hLine2, 'Color', our_blue);
set(hAx(1),'ycolor',our_red)
set(hAx(2),'ycolor',our_blue)
set(hAx(1),'XLim',[daterigidity(1) daterigidity(end)])
set(hAx(2),'XLim',[daterigidity(1) daterigidity(end)])
set(hAx(1),'YLim',[8 19])
set(hAx(2),'YLim',[33 44])

legend({'Share of zero wage-change (%)','One minus employment rate (%)'},'Location','SouthEast')
set(gcf,'papersize',[20 8.5]); 
set(gcf, 'PaperPosition', [0 0 20 8.5]);  
print(gcf,'-dpdf','figures/Rigidity_both_recent.pdf');