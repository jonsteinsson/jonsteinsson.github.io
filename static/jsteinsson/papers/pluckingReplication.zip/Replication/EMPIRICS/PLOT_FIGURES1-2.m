clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

GRAPH_SETTINGS

%% Load Data
u                       =xlsread('unemployment.xls');
date                    =(1948:1/12:2020+1/12)';
T                       =length(date); %=866
u                       =u(1:T);

m                       =mean(u)
med                     =median(u)
stddev                  =std(u)


%% Define peaks and troughs

cyclesize              =1.5; % values between 0.9 and 1.5 give same thing
empirics               =contractionsexpansions(u,date,cyclesize);

figure
plot(date,empirics.u,'b')
hold on
plot(date,empirics.u,'Color',our_blue)
ylabel('Unemployment (%)')
axis tight
v1=vline(empirics.datetroughs,'-');
set(v1,'Color',our_red)
set(v1,'LineWidth',1)
v2=vline(empirics.datepeaks(2:end),'--');
set(v2,'Color',our_red)
set(v2,'LineWidth',1)
v3=vline(empirics.datepeaks(1),'--');% first peak
set(v3,'Color',our_red)
set(v3,'LineWidth',1)
set(gcf,'papersize',[11 8.5]); 
set(gcf, 'PaperPosition', [0 0 11 8.5]);                                   % [left bottom width height]
print(gcf,'-dpdf','figures/UnemploymentPeaksTroughs.pdf');

max_size=max([empirics.contractions;empirics.expansions]) %6.5(current expansion)
mean_size_expansions = mean(empirics.expansions)
mean_size_contractions = mean(empirics.contractions)

%% Plucking Regressions

datetroughstext   =strtrim(cellstr(num2str(floor(empirics.datetroughs))));
datepeakstext     =strtrim(cellstr(num2str(floor(empirics.datepeaks))));

[regressioncoeffEonC,R2EonC,regressioncoeffConE,R2ConE] = predictiveness(empirics,1)

figure
subplot(1,2,1)
scatter(empirics.contractions,empirics.expansions,'+b')
hold on
myfit   =polyfit(empirics.contractions,empirics.expansions,1);
x       =0:0.1:7;
y       =myfit(1)*x+myfit(2);
plot(x,y,'k');
axis([0,7,0,7])
for i=1:length(empirics.contractions)
    text(empirics.contractions(i),empirics.expansions(i),['  ',datetroughstext{i}])
end
xlabel('Amplitude of a contraction')
ylabel('Amplitude of the subsequent expansion')
axesHandles = findobj(get(gcf,'Children'), 'flat','Type','axes');
axis(axesHandles,'square')

subplot(1,2,2)
scatter(empirics.expansions(1:end-1),empirics.contractions(2:end),'+b')
hold on
myfit   =polyfit(empirics.expansions(1:end-1),empirics.contractions(2:end),1);
x       =0:0.1:7;
y       =myfit(1)*x+myfit(2);
plot(x,y,'k');
axis([0,7,0,7])
for i=1:length(empirics.expansions(1:end-1))
    text(empirics.expansions(i),empirics.contractions(i+1),['  ',datepeakstext{i+1}])
end
xlabel('Amplitude of an expansion')
ylabel('Amplitude of the subsequent contraction')
axesHandles = findobj(get(gcf,'Children'), 'flat','Type','axes');
axis(axesHandles,'square')

set(gcf,'papersize',[11 6]);
set(gcf, 'PaperPosition', [0 0 11 6]);                                   % [left bottom width height]
print(gcf,'-dpdf','figures/PluckingProperty.pdf');

%% Other statistics

empirics               =contractionsexpansions(u,(1:length(u))',cyclesize) 

dummycontraction   =[zeros(length(empirics.speedexpansion),1);ones(length(empirics.speedcontraction),1)];
speed              =[empirics.speedexpansion;empirics.speedcontraction];
fitlm(dummycontraction,speed,'linear')

