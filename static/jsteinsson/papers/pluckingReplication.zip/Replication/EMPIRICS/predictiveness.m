function [regressioncoeffEonC,R2EonC,regressioncoeffConE,R2ConE] = predictiveness(data,plotting)

myfit1   =polyfit(data.contractions,data.expansions,1);
regressioncoeffEonC=myfit1(1);
R2EonC  =corr(data.contractions,data.expansions)^2;
myfit2   =polyfit(data.expansions(1:end-1),data.contractions(2:end),1);
regressioncoeffConE=myfit2(1);
R2ConE  =corr(data.expansions(1:end-1),data.contractions(2:end))^2;

if plotting==1
figure
subplot(1,2,1)
scatter(data.contractions,data.expansions,'+b')
hold on
x1       =0:0.01:max(data.contractions);
y1       =myfit1(1)*x1+myfit1(2);
plot(x1,y1,'k');
axis([1 12 1 12])
xlabel('Amplitude of a contraction')
ylabel('Amplitude of the subsequent expansion')
axesHandles = findobj(get(gcf,'Children'), 'flat','Type','axes');
axis(axesHandles,'square')

subplot(1,2,2)
scatter(data.expansions(1:end-1),data.contractions(2:end),'+b')
hold on
x2       =0:0.01:max(data.expansions(1:end-1));
y2       =myfit2(1)*x2+myfit2(2);
plot(x2,y2,'k');
axis([1 12 1 12])
xlabel('Amplitude of an expansion')
ylabel('Amplitude of the subsequent contraction')
axesHandles = findobj(get(gcf,'Children'), 'flat','Type','axes');
axis(axesHandles,'square')

% Display regression output too
fitlm(data.contractions,data.expansions,'linear')
fitlm(data.expansions(1:end-1),data.contractions(2:end),'linear')%(X,y,linear)
end

end

