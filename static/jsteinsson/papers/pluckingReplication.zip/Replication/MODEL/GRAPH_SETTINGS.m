width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 16;      % Fontsize
lw = 2.5;      % LineWidth
msz = 8;       % MarkerSize

% The properties we've been using in the figures
set(0,'defaultLineLineWidth',lw);   % set the default line width to lw
set(0,'defaultLineMarkerSize',msz); % set the default line marker size to msz
set(0,'defaultLineLineWidth',lw);   % set the default line width to lw
set(0,'defaultLineMarkerSize',msz); % set the default line marker size to msz
set(0,'DefaultAxesFontSize',fsz)
% Set the default Size for display
defpos = get(0,'defaultFigurePosition');
set(0,'defaultFigurePosition', [defpos(1) defpos(2) width*100, height*100]);

% Set the defaults for saving/printing to a file
set(0,'defaultFigureInvertHardcopy','on'); % This is the default anyway
set(0,'defaultFigurePaperUnits','inches'); % This is the default anyway
defsize = get(gcf, 'PaperSize');
left = (defsize(1)- width)/2;
bottom = (defsize(2)- height)/2;
defsize = [left, bottom, width, height];
set(0, 'defaultFigurePaperPosition', defsize);


% COLORS
% This function determines the rgb output corresponding to input values Hue
% and Int. Hue has to be an integer 1 - 12 and Int has to be an integer
% comprised between 1 and 100 .
% Hue is the Hue according to the HSV convention
% (https://en.wikipedia.org/wiki/HSL_and_HSV) and indicates the "type of
% color" in 30 deg increment following the HSV map (i.e. 1 corresponds to
% 0 deg and is "red", 2 corresponds to 30 deg and is "yellow-red", 3
% corresponds to 60 deg and is "yellow".  More "different" colors are
% located at highest angular distances, i.e. the highest contrast to the
% red color (0 deg) is the cyan (180 deg).
% The value Int (integer between 1 and 100) is a measure of darkness 
% of the color when exported to grayscale. The values have been 
% calculated trough minimization for all the different swatches (hue 
% colors), to match the intensity of pure red (HSV=[0 1 1]). 
% Note that pure red is not as black as black (i.e. rgb2gray([1 0 0])=0.2989),
% so values with Int=100 levels will look gray. Perfect for contrast with 
% actual black lines 
load ('HSVBWColormap.mat');
HInt2RGB =@(Hue,Int)hsv2rgb([(Hue-1)/12,Ss(Int,Hue),Vs(Int,Hue)]);
our_blue =HInt2RGB(9,100); % red, darkest 
our_red  =HInt2RGB(1,60); % cyan, less dark 
our_green=HInt2RGB(4,20); % green, less dark 

