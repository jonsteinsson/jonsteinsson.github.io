clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

GRAPH_SETTINGS

%%

f                =0.45;
u                =0.058;
s                =1/((1/u-1)*(1/f-1));

uoff       =@(f)100*s/(s+(1/f-1)^(-1));
fofu       =@(u)1/(1+1/s*(100/u-1)^(-1));

uss        =5.7;
umin       =2.5;
umax       =10.8;
fss        =fofu(uss);
fmax       =fofu(umin);
fmin       =fofu(umax);

figure
[x,y]=fplot(uoff,[0.05,1]);
plot(x,y,'--','Color',our_blue)
hold on
[x,y]=fplot(uoff,[fmin,fmax]);
plot(x,y,'Color',our_red)
axis([0.05 1 -Inf Inf])

xlabel('Job-Finding Rate f')
ylabel('Unemployment u (%)')
%title('Steady-State Worker-Flow Relationship')
set(gcf,'papersize',[11 8.5]); 
set(gcf, 'PaperPosition', [0 0 11 8.5]);                                   % [left bottom width height]
print(gcf,'-dpdf','figures/SteadyStateWorkerFlow.pdf');
