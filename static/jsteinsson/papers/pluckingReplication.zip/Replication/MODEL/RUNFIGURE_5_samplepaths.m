clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

GRAPH_SETTINGS
set(0,'DefaultAxesFontSize',30)

%%

name               ='dnwr_homogeneous_ar1noaggshocks_direct_flows_Nsim10';
load(strcat('RESULTS_simulation/',name))
uss_dnwr=mean(u(:));
fss_dnwr=mean(f(:));
sbarss_dnwr=mean(sbar(:));

name               ='dnwr_homogeneous_ar1_direct_flows_Nsim5000';
load(strcat('RESULTS_simulation/',name))


%% GRAPHS

isample     =2;

u_dnwr      =u(:,isample);
f_dnwr      =f(:,isample);
sbar_dnwr   =sbar(:,isample);

cyclesize       =1.5;
empirics_dnwr   =contractionsexpansions(u_dnwr,(1:T2-T1+1)',cyclesize);

figure
subplot(3,1,1)
plot(u_dnwr,'Color',our_blue)
hold on
plot(uss_dnwr*ones(length(u_dnwr),1),'--k')
axis([1 length(u_dnwr) 0 15])
v1=vline(empirics_dnwr.datetroughs,'-');
set(v1,'Color',our_red)
set(v1,'LineWidth',1)
v2=vline(empirics_dnwr.datepeaks,'--');
set(v2,'Color',our_red)
set(v2,'LineWidth',1)
legend('Sample path','Steady-state level')
ylabel('(%)')
title('Unemployment')

subplot(3,1,2)
plot(f_dnwr,'Color',our_blue)
hold on
plot(fss_dnwr*ones(length(f_dnwr),1),'--k')
ylabel('(%)')
title('Job-Finding Rate')
axis tight
axis([1 length(u_dnwr) 0 60])

subplot(3,1,3)
plot(sbar_dnwr,'Color',our_blue)
hold on
plot(sbarss_dnwr*ones(length(sbar_dnwr),1),'--k')
ylabel('(%)')
xlabel('Time (months)')
title('Employment Exit Rate')
axis tight
axis([1 length(u_dnwr) 0 6])

set(gcf,'papersize',[14 20]); 
set(gcf, 'PaperPosition', [0 0 14 20]);                                   % [left bottom width height]
print(gcf,'-dpdf','./figures/paths_DNWR.pdf');
