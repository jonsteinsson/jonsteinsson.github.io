clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

GRAPH_SETTINGS

name               ='nashonly_homogeneous_ar1_direct_flows_Nsim5000';
%name               ='nashonly_homogeneous_ar1_flows_Nsim5000';

load(strcat('RESULTS_simulation/',name))

% For more readable figures, only take 500 samples
parsim.Nsample =500;
u =  u(:,1:parsim.Nsample);

%% CALCULATE

cyclesize            =1.5;
maxsize              =6.5;
res_truncated        =dopluckingregressions(u,f,sbar,A,parsim,cyclesize,maxsize);
res_untruncated      =dopluckingregressions(u,f,sbar,A,parsim,cyclesize,Inf);

myfit1_truncated     =polyfit(res_truncated.scatterEonC.contractions,res_truncated.scatterEonC.expansions,1);
myfit2_truncated     =polyfit(res_truncated.scatterConE.expansions,res_truncated.scatterConE.contractions,1);
myfit1_untruncated   =polyfit(res_untruncated.scatterEonC.contractions,res_untruncated.scatterEonC.expansions,1);
myfit2_untruncated   =polyfit(res_untruncated.scatterConE.expansions,res_untruncated.scatterConE.contractions,1);

%% Scatter plots

figure
subplot(1,2,1)
scatter(res_untruncated.scatterEonC.contractions,res_untruncated.scatterEonC.expansions,'+b')
hold on
x1       =0:0.01:max(res_untruncated.scatterEonC.contractions);
y1       =myfit1_truncated(1)*x1+myfit1_truncated(2);
plot(x1,y1,'k');
axis([cyclesize 10 cyclesize 10])
xlabel('Amplitude of a contraction')
ylabel('Amplitude of the subsequent expansion')
axesHandles = findobj(get(gcf,'Children'), 'flat','Type','axes');
axis(axesHandles,'square')

subplot(1,2,2)
scatter(res_untruncated.scatterConE.expansions,res_untruncated.scatterConE.contractions,'+b')
hold on
x2       =0:0.01:max(res_untruncated.scatterConE.expansions);
y2       =myfit2_truncated(1)*x2+myfit2_truncated(2);
plot(x2,y2,'k');
axis([cyclesize 10 cyclesize 10])
xlabel('Amplitude of an expansion')
ylabel('Amplitude of the subsequent contraction')
axesHandles = findobj(get(gcf,'Children'), 'flat','Type','axes');
axis(axesHandles,'square')

set(gcf,'papersize',[11 6.5]); 
set(gcf, 'PaperPosition', [0 0 11 6.5]);                                   % [left bottom width height]
print(gcf,'-dpdf',strcat('FIGURES\PluckingRegressions_',name,'.pdf'));
