clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

GRAPH_SETTINGS

load('RESULTS_simulation\costsofcycles_Nsample10')


figure
plot(sigmaalist*100,meanu,'Color',our_blue)
hold on
scatter(sigmaalist(16)*100,meanu(16),'filled','*','LineWidth',2,'MarkerEdgeColor',our_blue);
xlabel('$\sigma(\log(A))(\%)$ ','Interpreter','Latex')
ylabel('E(u) (%)')
axis([0 sigmaalist(end)*100 0 15])
set(gcf,'papersize',[11 8.5]); 
set(gcf, 'PaperPosition', [0 0 11 8.5]);                                 % [left bottom width height]
print(gcf,'-dpdf','figures/Normative_FRmodel.pdf');