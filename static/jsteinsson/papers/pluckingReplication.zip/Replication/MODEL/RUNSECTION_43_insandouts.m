clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

name               ='dnwr_homogeneous_ar1_direct_flows_Nsim5000';
load(strcat('RESULTS_simulation/',name))

sbar=sbar/100;
f=f/100;
u=u/100;

%%
u_sbar      =zeros(parsim.T-parsim.burnin,parsim.Nsample);
u_f         =zeros(parsim.T-parsim.burnin,parsim.Nsample);
u_check     =zeros(parsim.T-parsim.burnin,parsim.Nsample);
u_approx    =zeros(parsim.T-parsim.burnin,parsim.Nsample);

for s= 1:parsim.Nsample
for t=2:parsim.T-parsim.burnin
    sbarmean    =mean(sbar(:,s));
    fmean       =mean(f(:,s));
    u_sbar(1,s)   =u(1,s);
    u_f(1,s)      =u(1,s);
    u_check(1,s)  =u(1,s);
    u_sbar(t,s)   =(1-fmean-sbar(t,s))*u_sbar(t-1,s)+sbar(t,s); 
    u_f(t,s)      =(1-f(t,s)-sbarmean)*u_f(t-1,s)+sbarmean;
    u_check(t,s)  =(1-f(t,s)-sbar(t,s))*u_check(t-1,s)+sbar(t,s);
    u_approx(t,s) =sbar(t,s)/(f(t,s)+sbar(t,s));
end
end

%%

std_u       =zeros(parsim.Nsample,1);
std_uf      =zeros(parsim.Nsample,1);
std_usbar   =zeros(parsim.Nsample,1);
share_f     =zeros(parsim.Nsample,1);
share_sbar  =zeros(parsim.Nsample,1);

for s=1:parsim.Nsample
std_u(s)       =std(u(:,s));
std_uf(s)      =std(u_f(:,s));
std_usbar(s)   =std(u_sbar(:,s));
share_f(s)     =std_uf(s)/std_u(s);
share_sbar(s)  =std_usbar(s)/std_u(s);
end

median.stdu     =quantile(std_u,0.5);
median.stduf    =quantile(std_uf,0.5);
median.stdusbar =quantile(std_usbar,0.5);
median.sharef   =quantile(share_f,0.5);
median.sharesbar=quantile(share_sbar,0.5);

stddev.stdu     =std(std_u);
stddev.stduf    =std(std_uf);
stddev.stdusbar =std(std_usbar);
stddev.sharef   =std(share_f);
stddev.sharesbar=std(share_sbar);

median

