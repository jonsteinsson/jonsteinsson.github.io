clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

GRAPH_SETTINGS

name               ='nashonly_homogeneous_ar2_direct_flows_Nsim1000';

load(strcat('RESULTS_simulation/',name))

cyclesize   =1.5;
maxsize     =Inf;%6.5, use "Inf" for no truncation

%% CALCULATE

res             =dopluckingregressions(u,f,sbar,A,parsim,cyclesize,maxsize);

%%
figure
subplot(3,4,1)
hist(res.m_chopped)
title('Mean(u)')
subplot(3,4,2)
hist(res.stddev_chopped)
title('StdDev(u)')
subplot(3,4,3)
hist(res.skew_chopped)
title('Skewness(u)')

subplot(3,4,5)
hist(res.pluckingEonC_chopped)
axis([-0.3 1.3 -Inf Inf])
title('\beta, exp. on contr.')
subplot(3,4,6)
hist(res.R2EonC_chopped)
title('R2, exp. on contr.')
subplot(3,4,7)
hist(res.meande_chopped)
title('Mean duration of exp.')
subplot(3,4,8)
hist(res.meanse_chopped)
title('Mean speed of exp.')

subplot(3,4,9)
hist(res.pluckingConE_chopped)
title('\beta, contr. on exp.')
subplot(3,4,10)
hist(res.R2ConE_chopped)
title('R2, contr. on exp.')
subplot(3,4,11)
hist(res.meandc_chopped)
title('Mean duration of contr.')
subplot(3,4,12)
hist(res.meansc_chopped)
title('Mean speed of contr.')

median.mean         =quantile(res.m_chopped,0.5);
median.stddev       =quantile(res.stddev_chopped,0.5);
median.skew         =quantile(res.skew_chopped,0.5);
median.pluckingEonC =quantile(res.pluckingEonC_chopped,0.5);
median.R2EonC       =quantile(res.R2EonC_chopped,0.5);
median.pluckingConE =quantile(res.pluckingConE_chopped,0.5);
median.R2ConE       =quantile(res.R2ConE_chopped,0.5);
median.meanse       =quantile(res.meanse_chopped,0.5);
median.meansc       =quantile(res.meansc_chopped,0.5);
median.meande       =quantile(res.meande_chopped,0.5);
median.meandc       =quantile(res.meandc_chopped,0.5);

quant.mean_mean     =mean(res.m_chopped);
quant.mean_median   =quantile(res.m_chopped,0.5);
quant.mean_down     =quantile(res.m_chopped,0.025);
quant.mean_up       =quantile(res.m_chopped,0.975);
quant.stddev_mean   =mean(res.stddev_chopped);
quant.stddev_median =quantile(res.stddev_chopped,0.5);
quant.stddev_down   =quantile(res.stddev_chopped,0.025);
quant.stddev_up     =quantile(res.stddev_chopped,0.975);
quant.skew_mean     =mean(res.skew_chopped);
quant.skew_median   =quantile(res.skew_chopped,0.5);
quant.skew_down     =quantile(res.skew_chopped,0.025);
quant.skew_up       =quantile(res.skew_chopped,0.975);

quant.pluckingEonC_mean     =mean(res.pluckingEonC_chopped);
quant.pluckingEonC_median   =quantile(res.pluckingEonC_chopped,0.5);
quant.pluckingEonC_down     =quantile(res.pluckingEonC_chopped,0.025);
quant.pluckingEonC_up       =quantile(res.pluckingEonC_chopped,0.975);
quant.R2EonC_mean           =mean(res.R2EonC_chopped);
quant.R2EonC_median         =quantile(res.R2EonC_chopped,0.5);
quant.R2EonC_down           =quantile(res.R2EonC_chopped,0.025);
quant.R2EonC_up             =quantile(res.R2EonC_chopped,0.975);

quant.pluckingConE_mean     =mean(res.pluckingConE_chopped);
quant.pluckingConE_median   =quantile(res.pluckingConE_chopped,0.5);
quant.pluckingConE_down     =quantile(res.pluckingConE_chopped,0.025);
quant.pluckingConE_up       =quantile(res.pluckingConE_chopped,0.975);
quant.R2ConE_mean           =mean(res.R2ConE_chopped);
quant.R2ConE_median         =quantile(res.R2ConE_chopped,0.5);
quant.R2ConE_down           =quantile(res.R2ConE_chopped,0.025);
quant.R2ConE_up             =quantile(res.R2ConE_chopped,0.975);

quant.R2diff_median         =quantile(res.R2diff_chopped,0.5);
quant.R2diff_down           =quantile(res.R2diff_chopped,0.025);
quant.R2diff_up             =quantile(res.R2diff_chopped,0.975);
quant.pluckingdiff_median   =quantile(res.pluckingdiff_chopped,0.5);
quant.pluckingdiff_down     =quantile(res.pluckingdiff_chopped,0.025);
quant.pluckingdiff_up       =quantile(res.pluckingdiff_chopped,0.975);

quant.meanse_mean     =mean(res.meanse_chopped);
quant.meanse_median   =quantile(res.meanse_chopped,0.5);
quant.meanse_down     =quantile(res.meanse_chopped,0.025);
quant.meanse_up       =quantile(res.meanse_chopped,0.975);
quant.meansc_mean     =mean(res.meansc_chopped);
quant.meansc_median   =quantile(res.meansc_chopped,0.5);
quant.meansc_down     =quantile(res.meansc_chopped,0.025);
quant.meansc_up       =quantile(res.meansc_chopped,0.975);

quant.meande_mean     =mean(res.meande_chopped);
quant.meande_median   =quantile(res.meande_chopped,0.5);
quant.meande_down     =quantile(res.meande_chopped,0.025);
quant.meande_up       =quantile(res.meande_chopped,0.975);
quant.meandc_mean     =mean(res.meandc_chopped);
quant.meandc_median   =quantile(res.meandc_chopped,0.5);
quant.meandc_down     =quantile(res.meandc_chopped,0.025);
quant.meandc_up       =quantile(res.meandc_chopped,0.975);

stddev.mean           =std(res.m_chopped);
stddev.stddev         =std(res.stddev_chopped);  
stddev.skew           =std(res.skew_chopped);
stddev.pluckingEonC   =nanstd(res.pluckingEonC_chopped);
stddev.R2EonC         =nanstd(res.R2EonC_chopped);
stddev.pluckingConE   =nanstd(res.pluckingConE_chopped);
stddev.R2ConE         =nanstd(res.R2ConE_chopped);
stddev.meanse         =std(res.meanse_chopped);
stddev.meansc         =std(res.meansc_chopped);
stddev.meande         =std(res.meande_chopped);
stddev.meandc         =std(res.meandc_chopped);

%%
tablecolumn={};
tablecolumn.betaEonCmedian=median.pluckingEonC;
tablecolumn.betaEonCstddev=stddev.pluckingEonC;
tablecolumn.betaConEmedian=median.pluckingConE;
tablecolumn.betaConEstddev=stddev.pluckingConE;

tablecolumn.R2EonCmedian=median.R2EonC;
tablecolumn.R2EonCstddev=stddev.R2EonC;
tablecolumn.R2ConEmedian=median.R2ConE;
tablecolumn.R2ConEstddev=stddev.R2ConE;

tablecolumn.speedexpansionmedian=median.meanse;
tablecolumn.speedexpansionstddev=stddev.meanse;
tablecolumn.speedcontractionmedian=median.meansc;
tablecolumn.speedcontractionstddev=stddev.meansc;

tablecolumn.durationexpansionmedian=median.meande;
tablecolumn.durationexpansionstddev=stddev.meande;
tablecolumn.durationcontractionmedian=median.meandc;
tablecolumn.durationcontractionstddev=stddev.meandc;


tablecolumn