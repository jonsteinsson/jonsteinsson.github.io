clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

name               ='nashonly_homogeneous_ar1_direct_flows_Nsim5000';

load(strcat('RESULTS_simulation/',name))

%% CALCULATE
res.u.mean             =zeros(parsim.Nsample,1);
res.u.std              =zeros(parsim.Nsample,1);
res.u.corrA            =zeros(parsim.Nsample,1);
res.u.elasA            =zeros(parsim.Nsample,1);
res.u.autocorr         =zeros(parsim.Nsample,1);

res.f.mean             =zeros(parsim.Nsample,1);
res.f.std              =zeros(parsim.Nsample,1);
res.f.corrA            =zeros(parsim.Nsample,1);
res.f.elasA            =zeros(parsim.Nsample,1);
res.f.autocorr         =zeros(parsim.Nsample,1);

res.sbar.mean          =zeros(parsim.Nsample,1);
res.sbar.std           =zeros(parsim.Nsample,1);
res.sbar.corrA         =zeros(parsim.Nsample,1);
res.sbar.elasA         =zeros(parsim.Nsample,1);
res.sbar.autocorr      =zeros(parsim.Nsample,1);

for s=1:parsim.Nsample
    
u_raw           =quarterly(u(:,s));
f_raw           =quarterly(f(:,s));
sbar_raw        =quarterly(sbar(:,s));
A_raw           =quarterly(A(:,s));

stat_raw.u      =statisticsFR(u_raw,A_raw);
stat_raw.f      =statisticsFR(f_raw,A_raw);
stat_raw.sbar   =statisticsFR(sbar_raw,A_raw);

u_hp            =hpfilter(log(u_raw),1600);
f_hp            =hpfilter(log(f_raw),1600);
sbar_hp         =hpfilter(log(sbar_raw),1600);
A_hp            =hpfilter(log(A_raw),1600);

stat_hp.u      =statisticsFR(u_hp,A_hp);
stat_hp.f      =statisticsFR(f_hp,A_hp);
stat_hp.sbar   =statisticsFR(sbar_hp,A_hp);

res_raw.u.mean(s)             =stat_raw.u.mean;
res_raw.u.std(s)              =stat_raw.u.std;
res_raw.u.corrA(s)            =stat_raw.u.corrA;
res_raw.u.elasA(s)            =stat_raw.u.elasA;
res_raw.u.autocorr(s)         =stat_raw.u.autocorr;

res_raw.f.mean(s)             =stat_raw.f.mean;
res_raw.f.std(s)              =stat_raw.f.std;
res_raw.f.corrA(s)            =stat_raw.f.corrA;
res_raw.f.elasA(s)            =stat_raw.f.elasA;
res_raw.f.autocorr(s)         =stat_raw.f.autocorr;

res_raw.sbar.mean(s)          =stat_raw.sbar.mean;
res_raw.sbar.std(s)           =stat_raw.sbar.std;
res_raw.sbar.corrA(s)         =stat_raw.sbar.corrA;
res_raw.sbar.elasA(s)         =stat_raw.sbar.elasA;
res_raw.sbar.autocorr(s)      =stat_raw.sbar.autocorr;

res_raw.A.std(s)              =std(A_raw);

res_hp.u.mean(s)              =stat_hp.u.mean;
res_hp.u.std(s)               =stat_hp.u.std;
res_hp.u.corrA(s)             =stat_hp.u.corrA;
res_hp.u.elasA(s)             =stat_hp.u.elasA;
res_hp.u.autocorr(s)          =stat_hp.u.autocorr;

res_hp.f.mean(s)              =stat_hp.f.mean;
res_hp.f.std(s)               =stat_hp.f.std;
res_hp.f.corrA(s)             =stat_hp.f.corrA;
res_hp.f.elasA(s)             =stat_hp.f.elasA;
res_hp.f.autocorr(s)          =stat_hp.f.autocorr;

res_hp.sbar.mean(s)           =stat_hp.sbar.mean;
res_hp.sbar.std(s)            =stat_hp.sbar.std;
res_hp.sbar.corrA(s)          =stat_hp.sbar.corrA;
res_hp.sbar.elasA(s)          =stat_hp.sbar.elasA;
res_hp.sbar.autocorr(s)       =stat_hp.sbar.autocorr;

res_hp.A.std(s)               =std(A_hp);

end

median_raw.u.mean         =quantile(res_raw.u.mean,0.5);
median_raw.u.std          =quantile(res_raw.u.std,0.5);
median_raw.u.corrA        =quantile(res_raw.u.corrA,0.5);
median_raw.u.elasA        =quantile(res_raw.u.elasA,0.5);
median_raw.u.autocorr     =quantile(res_raw.u.autocorr,0.5);

median_raw.f.mean         =quantile(res_raw.f.mean,0.5);
median_raw.f.std          =quantile(res_raw.f.std,0.5);
median_raw.f.corrA        =quantile(res_raw.f.corrA,0.5);
median_raw.f.elasA        =quantile(res_raw.f.elasA,0.5);
median_raw.f.autocorr     =quantile(res_raw.f.autocorr,0.5);

median_raw.sbar.mean         =quantile(res_raw.sbar.mean,0.5);
median_raw.sbar.std          =quantile(res_raw.sbar.std,0.5);
median_raw.sbar.corrA        =quantile(res_raw.sbar.corrA,0.5);
median_raw.sbar.elasA        =quantile(res_raw.sbar.elasA,0.5);
median_raw.sbar.autocorr     =quantile(res_raw.sbar.autocorr,0.5);

median_raw.A.std          =quantile(res_raw.A.std,0.5);

median_hp.u.mean         =quantile(res_hp.u.mean,0.5);
median_hp.u.std          =quantile(res_hp.u.std,0.5);
median_hp.u.corrA        =quantile(res_hp.u.corrA,0.5);
median_hp.u.elasA        =quantile(res_hp.u.elasA,0.5);
median_hp.u.autocorr     =quantile(res_hp.u.autocorr,0.5);

median_hp.f.mean         =quantile(res_hp.f.mean,0.5);
median_hp.f.std          =quantile(res_hp.f.std,0.5);
median_hp.f.corrA        =quantile(res_hp.f.corrA,0.5);
median_hp.f.elasA        =quantile(res_hp.f.elasA,0.5);
median_hp.f.autocorr     =quantile(res_hp.f.autocorr,0.5);

median_hp.sbar.mean         =quantile(res_hp.sbar.mean,0.5);
median_hp.sbar.std          =quantile(res_hp.sbar.std,0.5);
median_hp.sbar.corrA        =quantile(res_hp.sbar.corrA,0.5);
median_hp.sbar.elasA        =quantile(res_hp.sbar.elasA,0.5);
median_hp.sbar.autocorr     =quantile(res_hp.sbar.autocorr,0.5);

median_hp.A.std          =quantile(res_hp.A.std,0.5);

%%
disp('u')
median_hp.u
disp('f')
median_hp.f
disp('sbar')
median_hp.sbar

