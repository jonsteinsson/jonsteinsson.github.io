clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

% dbstop if error
% whos

load(strcat('RESULTS_policyfunction/dnwr_homogeneous_ar1_direct')); % to get parameterization of everything except sigmaa

sigmaalist  =[0:0.001:0.022,0.0225,0.023,0.024]';

names=cell(length(sigmaalist),1);
for i=1:length(sigmaalist)
names{i}=strcat('sigmaa',num2str(sigmaalist(i)*10000));
end

%%

parsim.burnin    =200;
parsim.Nsample   =10;
parsim.Tsample   =866;
parsim.T         =(parsim.Tsample+parsim.burnin)*parsim.Nsample+parsim.burnin;%one more burnin given the way simulate.m is written
parsim.NZ        =1;
parsim.Nf        =1;

meanu       =zeros(length(sigmaalist),1);
stdu        =zeros(length(sigmaalist),1);
meansbar    =zeros(length(sigmaalist),1);
means       =zeros(length(sigmaalist),1);

%% Simulations

parfor i=2:length(sigmaalist) % if parallel computing

% Resetting volatility of aggregate shocks    
paramloop=param;
paramloop.sigmaa=sigmaalist(i);
paramloop.sigmaea     =paramloop.sigmaa*sqrt(1-paramloop.rhoa^2);
nA                    =11;
[Aloglist,Ta]         =rouwenhorst(nA,paramloop.rhoa,paramloop.sigmaa);
paramloop.Alist       =exp(Aloglist);
paramloop.Ta          =Ta;
paramloop.etalist     =0;%for convenience code

% Solving for policy function
[solution,solution_nash] = getpolicyfunction(paramloop,ss);

% Simulations
rng(1)
ts      =simulate(solution,ss,paramloop,parsim,'flows');

u_reshaped    =reshape(100*ts.u,parsim.Tsample+parsim.burnin,parsim.Nsample);
u_i           =u_reshaped(parsim.burnin+1:end,:);
meanu(i)      =median(mean(u_i));
stdu(i)       =median(std(u_i));    
sbar_reshaped =reshape(100*ts.sbar,parsim.Tsample+parsim.burnin,parsim.Nsample);
sbar_i        =sbar_reshaped(parsim.burnin+1:end,:);
meansbar(i)   =median(mean(sbar_i));
end

%% Adding sigmaa=0, ie. no aggregate shocks

load(strcat('RESULTS_policyfunction/dnwr_homogeneous_ar1noaggshocks_direct')); % to get parameterization of everything except sigmaa

rng(1,'twister')

ts      =simulate(solution,ss,param,parsim,'flows');

u_reshaped    =reshape(100*ts.u,parsim.Tsample+parsim.burnin,parsim.Nsample);
u_i           =u_reshaped(parsim.burnin+1:end,:);
meanu(1)      =median(mean(u_i));
stdu(1)       =median(std(u_i));    
sbar_reshaped =reshape(100*ts.sbar,parsim.Tsample+parsim.burnin,parsim.Nsample);
sbar_i        =sbar_reshaped(parsim.burnin+1:end,:);
meansbar(1)   =median(mean(sbar_i));    

%% Adding flexible wages
load(strcat('RESULTS_policyfunction/nashonly_homogeneous_ar1_direct'));

rng(1,'twister')
ts      =simulate_nash(solution_nash,ss,param,parsim,'flows');
    
u_reshaped    =reshape(100*ts.u,parsim.Tsample+parsim.burnin,parsim.Nsample);
u_i           =u_reshaped(parsim.burnin+1:end,:);
meanuflex     =median(mean(u_i));
stduflex      =median(std(u_i));    
    
sbar_reshaped =reshape(100*ts.sbar,parsim.Tsample+parsim.burnin,parsim.Nsample);
sbar_i        =sbar_reshaped(parsim.burnin+1:end,:);
meansbarflex  =median(mean(sbar_i));

%% Saving
save(strcat('RESULTS_simulation\costsofcycles_Nsample',num2str(parsim.Nsample)))

