clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

param.wagesetting        ='dnwr';%'nashonly','dnwr'
param.sectors            ='homogeneous';%'homogeneous','heterogeneous'
param.aggshocks          ='ar1';%'ar1','ar1noaggshocks','ar2','ar2noaggshocks'
param.hiring             ='direct';%'direct','ladder'
param.delta              =0.019; %0.019, 0.01
if param.delta==0.019 %baseline
name                     =strcat(param.wagesetting,'_',param.sectors,'_',param.aggshocks,'_',param.hiring);
else
name                     =strcat(param.wagesetting,'_',param.sectors,'_',param.aggshocks,'_',param.hiring,'_delta',num2str(param.delta*100));
end    

%% 1. Calibration
%Steady-state
param.beta        =0.96^(1/12);
param.eta         =0.5;
param.z           =0.95;

switch param.sectors
    case 'homogeneous'
        param.g           =0;
    case 'heterogeneous'
        param.g           =0.023/12; % NOT USED
end

param.discount    =param.beta*exp(param.g)*(1-param.delta);

param.c=0.3;

switch param.aggshocks
    case {'ar1','ar1noaggshocks'}
    switch param.wagesetting
        case 'nashonly'
        param.gamma      =0.57;
            if param.delta==0.01
                param.gamma=0.62;
            end
        case 'srwr'
        param.gamma      =0;% NOT USED
        case 'dnwr'
        param.gamma      =0.43;
            if param.delta==0.01
                param.gamma=0.41;
            end
    end
    case {'ar2','ar2noaggshocks'}
    switch param.hiring
        case 'direct'
        switch param.wagesetting
            case 'nashonly'
            param.gamma      =0.55;       
            case 'srwr'
            param.gamma      =0;% NOT USED
            case 'dnwr'
            param.gamma      =0.37;
        end
        case 'ladder'
        switch param.wagesetting
            case 'nashonly'
            param.gamma      =0.29;
            case 'srwr'
            param.gamma      =0;% NOT USED
            case 'dnwr'
            param.gamma      =0.25;
        end
    end
end

ss                =steadystate(param);

param.tol         =10^(-5);

% Wage-rule
switch param.wagesetting
    case 'srwr'
    param.rho         =0.9;
    param.wagerule    =@(wnash,wlag)(wlag)^param.rho*(wnash)^(1-param.rho);   
    case {'dnwr'}
    switch param.aggshocks
        case {'ar1','ar1noaggshocks'}
        param.pibar       =1.02^(1/12);
        case {'ar2','ar2noaggshocks'}
        param.pibar       =1.005^(1/12);
    end
    param.wagerule    =@(wnash,wlag)max(wnash,wlag/(param.pibar*exp(param.g)));
end

% Match-shocks
param.nx          =201;
param.rhox        =0.98;

switch param.wagesetting
    case 'nashonly'
    param.sigmax      =0.021;
        if param.delta==0.01
        param.sigmax      =0.039;
        end
    case 'srwr'
    param.sigmax      =0;% NOT USED
    case 'dnwr'
    param.sigmax      =0.015;
        if param.delta==0.01
        param.sigmax      =0.027;
        end
end
    
param.sigmaex     =param.sigmax*sqrt(1-param.rhox^2);
nstdx             =3;
dx                =2*nstdx*param.sigmax/(param.nx-1);

switch param.hiring
    case 'direct'
        param.xloglist    =(-nstdx*param.sigmax:dx:nstdx*param.sigmax)';
        param.xlist       =exp(param.xloglist);
        param.Tx          =tauchen(param.xloglist,param.rhox,@(x)normcdf(x,0,param.sigmaex));
        param.xhireindex  =(param.nx+1)/2;
    case 'ladder'
        param.xloglist0   =(-nstdx*param.sigmax:dx:nstdx*param.sigmax)';
        param.xlist0      =exp(param.xloglist0);
        m=(param.nx+1)/2;
        d=0.1;
        s=12;
        Tx22              =tauchen(param.xloglist0,param.rhox,@(x)normcdf(x,0,param.sigmaex));
        Tx11              =diag([0;(1-d)*ones(s-1,1)],1);
        Tx11(:,1)         =[1;d*ones(s,1)];
        Tx12              =zeros(s+1,param.nx);
        Tx12(end,m)       =1-d;
        Tx21              =zeros(param.nx,s+1);
        Tx                =[Tx11,Tx12;Tx21,Tx22];
        param.Tx          =Tx;
        param.xlist       =[0;ones(s,1);param.xlist0];
        param.xhireindex  =2;
end
        
% Aggregate shocks
switch param.aggshocks
    case 'ar1'
    param.rhoa        =0.98;
    switch param.wagesetting
        case 'nashonly'
        param.sigmaa      =0.016;
            if param.delta==0.01
            param.sigmaa      =0.02;
            end
        case 'srwr'
        param.sigmaa      =0;%NOT USED
        case 'dnwr'
        param.sigmaa      =0.015;
        	if param.delta==0.01
            param.sigmaa      =0.016;
            end
    end
    param.sigmaea     =param.sigmaa*sqrt(1-param.rhoa^2);
    nA                =11;
    [Aloglist,Ta]     =rouwenhorst(nA,param.rhoa,param.sigmaa);
    param.Alist       =exp(Aloglist);
    param.Ta          =Ta;
    param.etalist     =0;%for convenience code
   
    case 'ar1noaggshocks'
    param.sigmaa      =0;
    param.rhoa        =0;
    param.sigmaea     =0;
    param.Alist       =1;
    param.Ta          =1;
    param.etalist     =0;%for convenience code
    
    case 'ar2'
    param.root1       =0.985;
    param.root2       =0.88;

    param.rhoa1       =param.root1+param.root2;
    param.rhoa2       =-param.root1*param.root2;
    switch param.hiring
        case 'direct'
        switch param.wagesetting
            case 'nashonly'
            param.sigmaa      =0.016;      
            case 'srwr'
            param.sigmaa      =0;%NOT USED 
            case 'dnwr'
            param.sigmaa      =0.010;
        end
        case 'ladder'
        switch param.wagesetting
            case 'nashonly'
            param.sigmaa      =0.013;       
            case 'srwr'
            param.sigmaa      =0;%NOT USED 
            case 'dnwr'
            param.sigmaa      =0.012;
        end
    end

    param.sigmaea     =param.sigmaa/sqrt((1-param.rhoa2)/((1+param.rhoa2)*((1-param.rhoa2)^2-param.rhoa1^2)));
    param.sigmaeta    =param.sigmaea/sqrt(1-param.root2^2);
    neta              =11;
    [etalist,Teta]    =rouwenhorst(neta,param.root2,param.sigmaeta);
    param.etalist     =etalist;
    param.Teta        =Teta;
    nstd              =3;
    nA                =11;
    stepAlog          =2*nstd*param.sigmaa/(nA-1);
    Aloglist          =(-nstd*param.sigmaa:stepAlog:nstd*param.sigmaa)'; %+/- nstd standard deviations
    param.Alist       =exp(Aloglist);
    
    case 'ar2noaggshocks'
    param.root1       =0;
    param.root2       =0;
    param.rhoa1       =0;
    param.rhoa2       =0;
    param.sigmaa      =0;
    param.sigmaea     =0;
    param.sigmaeta    =0;
    param.Teta        =1;
    param.etalist     =0;
    param.Alist       =0;
end

% Sectoral shocks
switch param.sectors
    case 'heterogeneous'
    param.rhoz       =0;%NOT USED
    param.sigmaz     =0;%NOT USED
    param.sigmaez    =param.sigmaz*sqrt(1-param.rhoz^2);
    nZ               =11;
    [Zloglist,Tz]    =rouwenhorst(nZ,param.rhoz,param.sigmaz);
    param.Zlist      =exp(Zloglist);
    param.Tz         =Tz;
    case 'homogeneous'
    param.Zlist      =1;
    param.Tz         =1;
    param.rhoz       =0;%for convenience code
    param.sigmaz     =0;%needed for setting size wage grid
end

%Lagged wage grid
if ~strcmp(param.wagesetting,'nashonly')
    wlagbottom     =1-4*(param.sigmaa+param.sigmax+param.sigmaz); 
    wlagtop        =1+4*(param.sigmaa+param.sigmax+param.sigmaz);
    nwlag          =401;
    stepwlag       =(wlagtop-wlagbottom)/(nwlag-1);
    param.wlaglist =(wlagbottom:stepwlag:wlagtop)';
end

%% 2. Solving
tic
[solution,solution_nash] = getpolicyfunction(param,ss);
solution.runningtime=toc;

save(strcat('RESULTS_policyfunction/',name),'solution','solution_nash','ss','param')