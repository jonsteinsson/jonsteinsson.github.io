clear all
clc
close all
set(0,'DefaultFigureWindowStyle','docked');

dbstop if error
whos

%%
name               ='nashonly_homogeneous_ar2_direct';

load(strcat('RESULTS_policyfunction\',name))

%%

parsim.burnin   =200;
parsim.NZ       =1; %for multisector only

switch param.aggshocks
    case {'ar1'}
    parsim.Nsample  =5000;
    parsim.T        =866+parsim.burnin;
    case 'ar2'
    parsim.Nsample  =1000;
    parsim.T        =5*866+parsim.burnin;
    case {'ar1noaggshocks','ar2noaggshocks'}
    parsim.Nsample  =10;
    parsim.T        =866+parsim.burnin;
end

u       =zeros(parsim.T-parsim.burnin,parsim.Nsample);
f       =zeros(parsim.T-parsim.burnin,parsim.Nsample);
s       =zeros(parsim.T-parsim.burnin,parsim.Nsample);
sbar    =zeros(parsim.T-parsim.burnin,parsim.Nsample);
j       =zeros(parsim.T-parsim.burnin,parsim.Nsample);
A       =zeros(parsim.T-parsim.burnin,parsim.Nsample);

tic

parfor k=1:parsim.Nsample %(if parallel computing)
%for k=1:parsim.Nsample %(if no parallel computing)

k
rng(k)

    if strcmp(param.wagesetting,'nashonly')
    ts      =simulate_nash(solution_nash,ss,param,parsim,'flows');
    else
    ts      =simulate(solution,ss,param,parsim,'flows');
    end
    u0(:,k)   =100*ts.u0;  
    u(:,k)    =100*ts.u;
    f(:,k)    =100*ts.f;
    s(:,k)    =100*ts.s;
    sbar(:,k) =100*ts.sbar;
    j(:,k)    =100*ts.j;
    A(:,k)    =ts.A;
end

runningtime=toc;

save(strcat('RESULTS_simulation\',name,'_flows_Nsim',num2str(parsim.Nsample)))
