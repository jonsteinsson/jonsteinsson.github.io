function [data] = contractionsexpansions(u,date,size)

data.u                =u;
data.date             =date;
[peaks,troughs]       =findpeaksandtroughs(u,size);
data.peaks            =peaks;
data.troughs          =troughs;
data.datetroughs      =data.date(logical(data.troughs));
data.datepeaks        =data.date(logical(data.peaks));

% We force: starts with a peak (a contraction) and ends with a peak (an expansion)
 
if data.datetroughs(1)<data.datepeaks(1) && data.datetroughs(end)>data.datepeaks(end)%begins and ends with a trough
    data.troughs(data.datetroughs(1))     =0;
    data.troughs(data.datetroughs(end))   =0;
    data.datetroughs                      =data.datetroughs(2:end-1);
else
if data.datetroughs(1)<data.datepeaks(1) && data.datetroughs(end)<data.datepeaks(end)%begins with a trough and ends with a peak
    data.troughs(data.datetroughs(1))     =0;
    data.datetroughs                      =data.datetroughs(2:end);
else
if data.datetroughs(1)>data.datepeaks(1) && data.datetroughs(end)>data.datepeaks(end)%begins with a peak and ends with a trough
    data.troughs(data.datetroughs(end))   =0;
    data.datetroughs                      =data.datetroughs(1:end-1);
end
end
end

data.leveltroughs             =data.u(logical(data.troughs));
data.levelpeaks               =data.u(logical(data.peaks));
% Sizes
data.contractions             =-(data.levelpeaks(1:end-1)-data.leveltroughs);
data.expansions               =data.leveltroughs-data.levelpeaks(2:end);
data.meanc                    =mean(data.contractions);
data.meane                    =mean(data.expansions);
% Durations
data.contractiondurations     =(data.datetroughs-data.datepeaks(1:end-1));
data.expansiondurations       =(data.datepeaks(2:end)-data.datetroughs);
data.meandc                   =mean(data.contractiondurations);
data.meande                   =mean(data.expansiondurations);
% Speeds
data.speedcontraction         =data.contractions./(data.contractiondurations/12);
data.speedexpansion           =data.expansions./(data.expansiondurations/12);
data.meansc                   =mean(data.speedcontraction);
data.meanse                   =mean(data.speedexpansion);

end


