function [res] = dopluckingregressions(u,f,sbar,A,parsim,cyclesize,maxsize)

% Calculates plucking statistics, after truncation of cycles

res.m_chopped               =NaN(parsim.Nsample,1);
res.stddev_chopped          =NaN(parsim.Nsample,1);
res.skew_chopped            =NaN(parsim.Nsample,1);

res.meanc_chopped           =NaN(parsim.Nsample,1);
res.meane_chopped           =NaN(parsim.Nsample,1);
res.meandc_chopped          =NaN(parsim.Nsample,1);
res.meande_chopped          =NaN(parsim.Nsample,1);
res.meanddiff_chopped       =NaN(parsim.Nsample,1);
res.meandreldiff_chopped    =NaN(parsim.Nsample,1);
res.meansc_chopped          =NaN(parsim.Nsample,1);
res.meanse_chopped          =NaN(parsim.Nsample,1);
res.meansdiff_chopped       =NaN(parsim.Nsample,1);
res.meansreldiff_chopped    =NaN(parsim.Nsample,1);
res.pluckingEonC_chopped    =NaN(parsim.Nsample,1);
res.pluckingConE_chopped    =NaN(parsim.Nsample,1);
res.pluckingdiff_chopped    =NaN(parsim.Nsample,1);
res.R2EonC_chopped          =NaN(parsim.Nsample,1);
res.R2ConE_chopped          =NaN(parsim.Nsample,1);
res.R2diff_chopped          =NaN(parsim.Nsample,1);
res.Ncycles1                =NaN(parsim.Nsample,1);
res.Ncycles2                =NaN(parsim.Nsample,1);

% List of all constractions and expansions for plots
res.scatterEonC.contractions        =[];
res.scatterEonC.expansions          =[];
res.scatterConE.contractions        =[];
res.scatterConE.expansions          =[];

for s=1:parsim.Nsample
        
% Take cycles first when truncated, so as to redefine u-series over which to take moments

cycles                          =contractionsexpansions(u(:,s),(1:length(u(:,s)))',cyclesize);
[cycles_truncated,truncator]    =truncation(cycles,maxsize);

% Moments (calculate them now!)
res.m_chopped(s)                    =mean(cycles_truncated.u);
res.stddev_chopped(s)               =std(cycles_truncated.u);
res.skew_chopped(s)                 =skewness(cycles_truncated.u);
% Sizes
res.meanc_chopped(s)                =cycles_truncated.meanc;
res.meane_chopped(s)                =cycles_truncated.meane;
% Durations
res.meandc_chopped(s)               =cycles_truncated.meandc;
res.meande_chopped(s)               =cycles_truncated.meande;
% Speeds
res.meansc_chopped(s)               =cycles_truncated.meansc;
res.meanse_chopped(s)               =cycles_truncated.meanse;

% Regression coefficients & R2 (& Ncycles): take cycles before truncation

% First regression: E on C
reg1censored.condi1=cycles.expansions<maxsize;
reg1censored.condi2=cycles.contractions<maxsize;
reg1censored.condi=(reg1censored.condi1 + reg1censored.condi2==2);
reg1censored.expansions=cycles.expansions(reg1censored.condi);
reg1censored.contractions=cycles.contractions(reg1censored.condi);

if length(reg1censored.contractions)>=5 % otherwise exclude sample from plucking regressions results
    
myfit1_censored                 =polyfit(reg1censored.contractions,reg1censored.expansions,1);%polyfit(x,y)

res.pluckingEonC_chopped(s)         =myfit1_censored(1);
res.R2EonC_chopped(s)               =corr(reg1censored.contractions,reg1censored.expansions)^2;
res.Ncycles1(s)                     =length(reg1censored.contractions);

end

% Second regression: C on E
reg2censored.condi1=cycles.expansions(1:end-1)<maxsize;
reg2censored.condi2=cycles.contractions(2:end)<maxsize;
reg2censored.condi=(reg2censored.condi1 + reg2censored.condi2==2);
reg2censored.expansions=cycles.expansions(1:end-1);
reg2censored.expansions=reg2censored.expansions(reg2censored.condi);
reg2censored.contractions=cycles.contractions(2:end);
reg2censored.contractions=reg2censored.contractions(reg2censored.condi);

if length(reg2censored.contractions)>=5 % otherwise exclude sample from plucking regressions results

myfit2_censored                 =polyfit(reg2censored.expansions,reg2censored.contractions,1);%polyfit(x,y)

res.pluckingConE_chopped(s)         =myfit2_censored(1);
res.R2ConE_chopped(s)               =corr(reg2censored.expansions,reg2censored.contractions)^2;
res.Ncycles2(s)                     =length(reg2censored.expansions);

end

res.pluckingdiff_chopped(s)         =res.R2EonC_chopped(s)-res.R2ConE_chopped(s);
res.R2diff_chopped(s)               =res.pluckingEonC_chopped(s)-res.pluckingConE_chopped(s);

% List of all constractions and expansions for plots
res.scatterEonC.contractions        =[res.scatterEonC.contractions;reg1censored.contractions];
res.scatterEonC.expansions          =[res.scatterEonC.expansions;reg1censored.expansions];
res.scatterConE.contractions        =[res.scatterConE.contractions;reg2censored.contractions];
res.scatterConE.expansions          =[res.scatterConE.expansions;reg2censored.expansions];

% Fujita-Ramey statistics
us_truncated                    =cycles_truncated.u;
fs                              =f(:,s);
fs_truncated                    =fs(truncator);
sbars                           =sbar(:,s);
sbars_truncated                 =sbars(truncator);
As                              =A(:,s);
As_truncated                    =As(truncator);

res.u.mean_chopped(s)           =mean(us_truncated);
res.u.stddev_chopped(s)         =std(us_truncated);
res.u.corrA_chopped(s)          =corr(us_truncated,As_truncated);
res.u.autocorr_chopped(s)       =corr(us_truncated(1:end-1),us_truncated(2:end));

res.f.mean_chopped(s)           =mean(fs_truncated);
res.f.stddev_chopped(s)         =std(fs_truncated);
res.f.corrA_chopped(s)          =corr(fs_truncated,As_truncated);
res.f.autocorr_chopped(s)       =corr(fs_truncated(1:end-1),fs_truncated(2:end));

res.sbar.mean_chopped(s)        =mean(sbars_truncated);
res.sbar.stddev_chopped(s)      =std(sbars_truncated);
res.sbar.corrA_chopped(s)       =corr(sbars_truncated,As_truncated);
res.sbar.autocorr_chopped(s)    =corr(sbars_truncated(1:end-1),sbars_truncated(2:end));

end


end

