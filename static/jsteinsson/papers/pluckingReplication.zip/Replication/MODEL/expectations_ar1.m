function [EXPJ] = expectations_ar1(w,solutionJ,probasA,probasZ,param)

EXPJsamex        =zeros(length(param.xlist),1);
for  k=1:length(param.xlist)
    [windex,windexplus,xw]                 =findnodes(w(k),param.wlaglist);
    Jsol                                   =(1-xw)*solutionJ(:,:,windex,k)+xw*solutionJ(:,:,windexplus,k);
    EXPJsamex(k)                           =probasA'*Jsol*probasZ;
end

EXPJ =param.Tx*EXPJsamex;

end





