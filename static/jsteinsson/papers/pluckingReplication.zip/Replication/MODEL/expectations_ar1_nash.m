function [EXPJ,EXPfJ] = expectations_ar1_nash(Jsolution,fJsolution,probasA,probasZ,param)

EXPJsamex        =zeros(length(param.xlist),1);
for k=1:length(param.xlist)
EXPJsamex(k)    =probasA'*Jsolution(:,:,k)*probasZ;
end

EXPJ            =param.Tx*EXPJsamex;
EXPfJ           =probasA'*fJsolution*probasZ;

end
