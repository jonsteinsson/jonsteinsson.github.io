function [EXPJ] = expectations_ar2(w,solutionJ,probaseta,probasZ,param)

EXPJsamex        =zeros(length(param.xlist),1);
for  k=1:length(param.xlist)
    Jsol                                   =zeros(length(param.etalist),length(param.Zlist));%just so that matlab get size J right in degenerate cases   
    [windex,windexplus,xw]                 =findnodes(w(k),param.wlaglist);
    Jsol(:,:)                              =(1-xw)*solutionJ(1,:,:,windex,k)+xw*solutionJ(1,:,:,windexplus,k);
    EXPJsamex(k)                           =probaseta'*Jsol*probasZ;
end

EXPJ =param.Tx*EXPJsamex;

end





