function [EXPJ,EXPfJ] = expectations_ar2_nash(Jsolution,fJsolution,probaseta,probasZ,param)

EXPJsamex        =zeros(length(param.xlist),1);
for k=1:length(param.xlist)
J               =zeros(length(param.etalist),length(param.Zlist));%just so that matlab get size J right in degenerate cases
J(:,:)          =Jsolution(1,:,:,k);
EXPJsamex(k)    =probaseta'*J*probasZ;
end
EXPJ            =param.Tx*EXPJsamex;

fJ              =zeros(length(param.etalist),length(param.Zlist));%just so that matlab get size J right in degenerate cases
fJ(:,:)         =fJsolution(1,:,:);
EXPfJ           =probaseta'*fJ*probasZ;

end
