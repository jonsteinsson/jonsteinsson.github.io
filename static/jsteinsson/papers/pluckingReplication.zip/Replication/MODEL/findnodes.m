function [X0,X1,x] = findnodes(X,Xlist)

if length(Xlist)==1
    X0      =1;
    X1      =1;
    x       =0;
else
    if X<=Xlist(1)
    X0      =1;
    else
    if X>=Xlist(end)
    X0      =length(Xlist)-1;
    else
    X0      =find(Xlist>X,1)-1;
    end
    end
    X1      =X0+1;
    x       =(X-Xlist(X0))/(Xlist(X1)-Xlist(X0));
end

end

