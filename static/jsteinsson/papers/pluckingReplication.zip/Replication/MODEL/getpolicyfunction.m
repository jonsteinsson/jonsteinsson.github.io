function [solution,solution_nash] = getpolicyfunction(param,ss)

switch param.aggshocks
    case {'ar1','ar1noaggshocks'}
        % Nash
        guess_nash.J  =ss.J*ones(length(param.Alist),length(param.Zlist),length(param.xlist));
        guess_nash.fJ =ss.f*ss.J*ones(length(param.Alist),length(param.Zlist));
        tic
        [solution_nash,solution]=solve_ar1_nash(guess_nash,param,0);
        solution_nash.runningtime=toc;    
            % Wage-Rigidity
            if ~strcmp(param.wagesetting,'nashonly')
            guess.J       =ss.J*ones(length(param.Alist),length(param.Zlist),length(param.wlaglist),length(param.xlist));
            tic
            solution      =solve_ar1(guess,solution,param,0);       
            solution.runningtime=toc;
            else
            solution=solution_nash;
            end
    case {'ar2','ar2noaggshocks'}
        % Nash
        guess_nash.J      =ss.J*ones(length(param.Alist),length(param.etalist),length(param.Zlist),length(param.xlist));
        guess_nash.fJ     =ss.f*ss.J*ones(length(param.Alist),length(param.etalist),length(param.Zlist));
        tic
        [solution_nash,solution]=solve_ar2_nash(guess_nash,param,0);
        solution_nash.runningtime=toc;
            %Wage-Rigidity
            if ~strcmp(param.wagesetting,'nashonly')
            guess.J       =ss.J*ones(length(param.Alist),length(param.etalist),length(param.Zlist),length(param.wlaglist),length(param.xlist));
            tic
            [solution]    =solve_ar2(guess,solution,param,0);
            solution.runningtime=toc;
            else
            solution=solution_nash;
            end
end


end

