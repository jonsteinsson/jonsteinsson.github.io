function [xq] = quarterly(x)
% Turns montly series into quarterly series

n       =floor((length(x))/3)*3;

xq      =1/3*(x(1:3:n-2)+x(2:3:n-1)+x(3:3:n));

end

