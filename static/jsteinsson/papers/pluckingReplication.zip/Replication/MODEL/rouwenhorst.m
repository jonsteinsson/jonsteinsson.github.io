function [alist,Ta] = rouwenhorst(K,rhoa,sigmaa)
% sigmaa is std of a, not of innovations

phi         =sigmaa*sqrt(K-1);%4.47 for K=21, quite large; %3.16 for K=11
stepa       =2*phi/(K-1);
alist       =(-phi:stepa:phi)';
p           =(1+rhoa)/2;
q           =p;
Ta          =[p,1-p;1-q,q];

for k=3:K
s   =length(Ta); 
Ta   =p*[Ta,zeros(s,1);zeros(1,s),0]...
    +(1-p)*[zeros(s,1),Ta;0,zeros(1,s)]...
    +(1-q)*[zeros(1,s),0;Ta,zeros(s,1)]...
    +q*[0,zeros(1,s);zeros(s,1),Ta];
Ta(2:end-1,:)=0.5*Ta(2:end-1,:);
end



end

