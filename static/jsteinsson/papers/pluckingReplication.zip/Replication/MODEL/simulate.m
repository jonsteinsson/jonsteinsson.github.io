function [tsoutput] = simulate(solution,ss,param,parsim,howmuchtosave)

%Simulate Exogeneous Aggregate Shocks
switch param.aggshocks
    case {'ar1'}
    Alog          =simulationexo_ar1(parsim.T,param.rhoa,param.sigmaea,0);
    ts.A          =exp(Alog);
    case {'ar1noaggshocks'}
    ts.A          =ones(parsim.T,1);    
    case {'ar2'}
    [Alog,eta]    =simulationexo_ar2(parsim.T,param.root1,param.root2,param.sigmaea,0,0);
    ts.eta        =eta;
    ts.A          =exp(Alog);
    case {'ar2noaggshocks'}
    ts.eta        =zeros(parsim.T,1);
    ts.A          =ones(parsim.T,1);
end
    
%Simulate Exogeneous Sectoral Shocks
switch param.sectors
    case 'homogeneous'
        parsim.NZ     =1; %overwrites parsim.NZ if single sector
        ts.Z          =ones(parsim.NZ,parsim.T);
    case 'heterogeneous'
        Zlog          =zeros(parsim.NZ,parsim.T);
        for kZ=1:length(param.Zlist)
           Zlog(kZ,:) =simulationexo_ar1(parsim.T,param.rhoz,param.sigmaez,0);
        end
        ts.Z          =exp(Zlog);
end

ts.mZ          =zeros(parsim.NZ,length(param.xlist),length(param.wlaglist),parsim.T);
switch param.wagesetting
    case 'dnwr'
        wm             =ss.w/(param.pibar*exp(param.g));        
    case 'srwr'
        wm             =ss.w;
end
[w0,w1,xw]     =findnodes(wm,param.wlaglist);
ts.mZ(:,param.xhireindex,w1:end,1)=(1-ss.u)*ones(parsim.NZ,length(param.wlaglist)-w1+1);
    
ts.NZ          =zeros(parsim.NZ,parsim.T);
ts.NZ(:,1)     =(1-ss.u)*ones(parsim.NZ,1);
ts.N0Z         =zeros(parsim.NZ,parsim.T);
ts.whireZ      =zeros(parsim.NZ,parsim.T);
ts.whireZ(:,1) =ss.w*ones(parsim.NZ,1);
ts.whirenashZ  =zeros(parsim.NZ,parsim.T);
ts.whirenashZ(:,1) =ss.w*ones(parsim.NZ,1);

ts.EU          =zeros(parsim.T,1);
ts.UE          =zeros(parsim.T,1);
ts.ENDED       =zeros(parsim.T,1);
ts.NEW         =zeros(parsim.T,1);

ts.fZ          =zeros(parsim.NZ,parsim.T);
ts.sZ          =zeros(parsim.NZ,parsim.T);
ts.sbarZ       =zeros(parsim.NZ,parsim.T);
ts.jZ          =zeros(parsim.NZ,parsim.T);

%%
for t=2:parsim.T
    %disp(t)
switch param.aggshocks
    case {'ar1','ar1noaggshocks'}
    [A0,A1,xA]             =findnodes(ts.A(t),param.Alist);%A(t) for AR1
    J                      =(1-xA)*solution.J(A0,:,:,:)+xA*solution.J(A1,:,:,:);
    wnash                  =(1-xA)*solution.wnash(A0,:,1,:)+xA*solution.wnash(A1,:,1,:);
    case {'ar2'}
    [A0,A1,xA]             =findnodes(ts.A(t-1),param.Alist);%A(t-1) for AR2
    J                      =(1-xA)*solution.J(A0,:,:,:,:)+xA*solution.J(A1,:,:,:,:);
    wnash                  =(1-xA)*solution.wnash(A0,:,:,1,:)+xA*solution.wnash(A1,:,:,1,:);
    [eta0,eta1,xeta]       =findnodes(ts.eta(t),param.etalist);%eta(t) for AR2
    J                      =(1-xeta)*J(1,eta0,:,:,:)+xeta*J(1,eta1,:,:,:);
    wnash                  =(1-xeta)*wnash(1,eta0,:,1,:)+xeta*wnash(1,eta1,:,1,:);  
end
EU                     =zeros(parsim.NZ,1);
UE                     =zeros(parsim.NZ,1);
ENDED                  =zeros(parsim.NZ,1);
for kZ=1:parsim.NZ
    [Z0,Z1,xZ]             =findnodes(ts.Z(kZ,t),param.Zlist);
    switch param.aggshocks
    case {'ar1','ar1noaggshocks'}
    JZ                     =squeeze((1-xZ)*J(1,Z0,:,:)+xZ*J(1,Z1,:,:));%dimensions left = (w(-1),x)
    wnashZ                 =squeeze((1-xZ)*wnash(1,Z0,1,:)+xZ*wnash(1,Z1,1,:));%dimensions left = (w(-1),x)
    case {'ar2'}
    JZ                     =squeeze((1-xZ)*J(1,1,Z0,:,:)+xZ*J(1,1,Z1,:,:));%dimensions left = (w(-1),x)
    wnashZ                 =squeeze((1-xZ)*wnash(1,1,Z0,1,:)+xZ*wnash(1,1,Z1,1,:));%dimensions left = (w(-1),x)
    end
    
    %Hiring wage and f
    ts.whirenashZ(kZ,t)    =wnashZ(param.xhireindex);  
    ts.whireZ(kZ,t)        =param.wagerule(wnashZ(param.xhireindex),ts.whireZ(kZ,t-1));
    [wh0,wh1,xwh]          =findnodes(ts.whireZ(kZ,t),param.wlaglist);
    JhireZ                 =(1-xwh)*JZ(wh0,param.xhireindex)+xwh*JZ(wh1,param.xhireindex);
    fZ                     =min(1,(JhireZ/(param.c))^((1-param.eta)/param.eta));% to change if hiring cost proportional to AZ; param.c*ts.A(t)*ts.Z(kZ,t) 
    ts.fZ(kZ,t)            =fZ;
    
    % 1.Productivity and exo separation shocks
    mlagZ                  =squeeze(ts.mZ(kZ,:,:,t-1));
    
    % Below: for constant separation because othewise squeeze turn it into a column vector
    if length(param.xlist)==1
        mlagZ=mlagZ';
    end
    
    m0Z                    =(1-param.delta)*param.Tx'*mlagZ;
        % Below: To guarantee that m0Z(kx,:) is an increasing function, as interpolation can make it slightly decreasing, in which case then snowballs                   
        for kx=1:length(param.xlist)
        for kw=2:length(param.wlaglist)
        if m0Z(kx,kw)<m0Z(kx,kw-1)
            m0Z(kx,kw)=m0Z(kx,kw-1);
        end
        end
        end
    
    % 2A. Wage adjustment
    m1Z                    =m0Z;
    for kx=1:length(param.xlist)
        switch param.wagesetting
            case 'dnwr'
                [wnash0]               =findnodes(wnashZ(kx),param.wlaglist);
                m1Z(kx,1:wnash0)       =zeros(wnash0,1);% wage adjustment DNWR: moving wages below nash wages to nash wage     
            case 'srwr'
            for kw=1:length(param.wlaglist)
                [w0,w1,xw]         =findnodes((param.wlaglist(kw)-(1-param.rho)*wnashZ(kx))/param.rho,param.wlaglist);
                m1Z(kx,kw)         =min(m0Z(kx,w0)+xw*(m0Z(kx,w1)-m0Z(kx,w0)),m0Z(kx,end));               
            end           
        end
    end
    
    % 2B. Endo separation
    m2Z                    =m1Z;
    fired                  =zeros(length(param.xlist),1);
    for kx=1:length(param.xlist)
        wfirethresh            =find(JZ(:,kx)==0,1);
        if ~isempty(wfirethresh)% if there is some firing
            if wfirethresh>1
                fired(kx)              =m1Z(kx,end)-m1Z(kx,wfirethresh);
                m2Z(kx,wfirethresh+1:end)=m1Z(kx,wfirethresh)*ones(length(param.wlaglist)-wfirethresh,1);
            else %wfirethresh==1
            fired(kx)              =m1Z(kx,end);
            m2Z(kx,wfirethresh:end)=zeros(length(param.wlaglist),1);
            end
        end  
        
    end
    %Definition various rates related to separation
    ENDED(kZ)              =sum(fired)+param.delta*ts.NZ(kZ,t-1);
    UE(kZ)                 =fZ*(1-ts.NZ(kZ,t-1));
    EU(kZ)                 =(1-fZ)*ENDED(kZ);
    if ts.NZ(kZ,t-1)~=0
    sZ                     =ENDED(kZ)/(ts.NZ(kZ,t-1));
    else
    sZ                     =0;
    end
    ts.sZ(kZ,t)            =sZ;
    ts.sbarZ(kZ,t)         =sZ*(1-fZ);
    ts.jZ(kZ,t)            =sZ*fZ;
    % 3. Hires
    m3Z                    =m2Z;
    m3Z(param.xhireindex,wh1:end)=m2Z(param.xhireindex,wh1:end)+fZ*(1-(1-sZ)*ts.NZ(kZ,t-1));    
    ts.NZ(kZ,t)            =sum(m3Z(:,end));   
    ts.N0Z(kZ,t)           =sum(m3Z(end-param.nx+1:end,end));
    
    % 4. Inflation Effect on next period's wage in the case of DNWR (by interpolation, with extra node at wnash)
    switch param.wagesetting
        case 'dnwr'
            for kx=1:length(param.xlist)
            wnodestart             =find(param.wlaglist*param.pibar*exp(param.g)>wnashZ(kx),1);
            for kw=wnodestart:length(param.wlaglist)
                [w0,w1,xw]         =findnodes(param.wlaglist(kw)*param.pibar*exp(param.g),param.wlaglist);
                if m3Z(kx,w0)==0 && m3Z(kx,w1)>0 && w1~=length(param.wlaglist)% if mass between w0 and w1, use following nodes w0+1 and w1+1
                    w0=w0+1;
                    w1=w1+1;
                end
                ts.mZ(kZ,kx,kw,t)  =m3Z(kx,w0)+xw*(m3Z(kx,w1)-m3Z(kx,w0));
            end               
            end
        case 'srwr' % for SRWR no change
            ts.mZ(kZ,:,:,t)    =m3Z;
    end
end
ts.EU(t)       =mean(EU);
ts.UE(t)       =mean(UE);
ts.ENDED(t)    =mean(ENDED);

end
ts.N           =mean(ts.NZ,1)';
ts.N0          =mean(ts.N0Z,1)';
ts.u           =1-ts.N;
ts.u0          =1-ts.N0;
ts.f           =[0;ts.UE(2:end)./ts.u(1:end-1)];
ts.sbar        =[0;ts.EU(2:end)./ts.N(1:end-1)];
ts.s           =[0;ts.ENDED(2:end)./ts.N(1:end-1)];
ts.j           =ts.s-ts.sbar;
ts.whire       =mean(ts.whireZ,1)';
ts.whirenash   =mean(ts.whirenashZ,1)';

%Output
switch howmuchtosave
    case 'unemployment' % save unemployment series only
        tsoutput.u =ts.u(parsim.burnin+1:end);
    case 'flows' % save ins and outs of unemployment rates
        tsoutput.u    =ts.u(parsim.burnin+1:end);
        tsoutput.u0   =ts.u0(parsim.burnin+1:end);
        tsoutput.f    =ts.f(parsim.burnin+1:end);
        tsoutput.sbar =ts.sbar(parsim.burnin+1:end);
        tsoutput.s    =ts.s(parsim.burnin+1:end);
        tsoutput.j    =ts.j(parsim.burnin+1:end);
        tsoutput.A    =ts.A(parsim.burnin+1:end);
    case 'all' %save everything
        tsoutput   =ts; %burnin not remove ex post
end

end

