function [tsoutput] = simulate_nash(solution_nash,ss,param,parsim,howmuchtosave)

%Simulate Exogeneous Aggregate Shocks
switch param.aggshocks
    case {'ar1'}
    Alog          =simulationexo_ar1(parsim.T,param.rhoa,param.sigmaea,0);
    ts.A          =exp(Alog);
    case {'ar1noaggshocks'}
    ts.A          =ones(parsim.T,1);    
    case {'ar2'}
    [Alog,eta]    =simulationexo_ar2(parsim.T,param.root1,param.root2,param.sigmaea,0,0);
    ts.eta        =eta;
    ts.A          =exp(Alog);
    case {'ar2noaggshocks'}
    ts.eta        =zeros(parsim.T,1);
    ts.A          =ones(parsim.T,1);
end
    
%Simulate Exogeneous Sectoral Shocks
switch param.sectors
    case 'homogeneous'
        parsim.NZ     =1; %overwrites parsim.NZ if single sector
        ts.Z          =ones(parsim.NZ,parsim.T);
    case 'heterogeneous'
        Zlog          =zeros(parsim.NZ,parsim.T);
        for kZ=1:length(param.Zlist)
           Zlog(kZ,:) =simulationexo_ar1(parsim.T,param.rhoz,param.sigmaez,0);
        end
        ts.Z          =exp(Zlog);
end

ts.nZ          =zeros(parsim.NZ,length(param.xlist),parsim.T);
ts.nZ(:,end,1) =(1-ss.u)*ones(parsim.NZ,1);
ts.NZ          =zeros(parsim.NZ,parsim.T);
ts.NZ(:,1)     =(1-ss.u)*ones(parsim.NZ,1);
ts.N0Z         =zeros(parsim.NZ,parsim.T);
ts.EU          =zeros(parsim.T,1);
ts.UE          =zeros(parsim.T,1);
ts.ENDED       =zeros(parsim.T,1);
ts.NEW         =zeros(parsim.T,1);

ts.fZ          =zeros(parsim.NZ,parsim.T);
ts.sZ          =zeros(parsim.NZ,parsim.T);
ts.sbarZ       =zeros(parsim.NZ,parsim.T);
ts.jZ          =zeros(parsim.NZ,parsim.T);
ts.whireZ      =zeros(parsim.NZ,parsim.T);
ts.whireZ(:,1) =ones(parsim.NZ,1);      

onexhire      =zeros(length(param.xlist),1);
onexhire(param.xhireindex)=1;

%%
for t=2:parsim.T
[A0,A1,xA]             =findnodes(ts.A(t),param.Alist);
J                      =(1-xA)*solution_nash.J(A0,:,:)+xA*solution_nash.J(A1,:,:);
EU                     =zeros(parsim.NZ,1);
UE                     =zeros(parsim.NZ,1);
ENDED                  =zeros(parsim.NZ,1);
for kZ=1:parsim.NZ
    [Z0,Z1,xZ]             =findnodes(ts.Z(kZ,t),param.Zlist);
    JZ                     =squeeze((1-xZ)*J(1,Z0,:)+xZ*J(1,Z1,:));
    fZ                     =(JZ(param.xhireindex)/(param.c*ts.A(t)*ts.Z(kZ,t)))^((1-param.eta)/param.eta);
    ts.fZ(kZ,t)            =fZ;
    nlagZ                  =squeeze(ts.nZ(kZ,:,t-1))';
    n0Z                    =(1-param.delta)*param.Tx'*nlagZ;
    fired                  =sum(n0Z.*(JZ==0));
    ENDED(kZ)              =fired+param.delta*ts.NZ(kZ,t-1);
    UE(kZ)                 =fZ*(1-ts.NZ(kZ,t-1));
    EU(kZ)                 =(1-fZ)*ENDED(kZ);      
    if ts.NZ(kZ,t-1)~=0
    sZ                     =ENDED(kZ)/(ts.NZ(kZ,t-1));
    else
    sZ                     =0;
    end
    ts.sZ(kZ,t)            =sZ;
    ts.sbarZ(kZ,t)         =sZ*(1-fZ);
    ts.jZ(kZ,t)            =sZ*fZ;
    ts.nZ(kZ,:,t)          =n0Z.*(JZ>0)+fZ*(1-(1-sZ)*ts.NZ(kZ,t-1))*onexhire;
    ts.NZ(kZ,t)            =sum(squeeze(ts.nZ(kZ,:,t)));
    ts.N0Z(kZ,t)           =sum(squeeze(ts.nZ(kZ,end-param.nx+1:end,t)));       
    % Adding wages
    whire                  =(1-xA)*solution_nash.w(A0,:,param.xhireindex)+xA*solution_nash.w(A1,:,param.xhireindex);
    ts.whireZ(kZ,t)        =(1-xZ)*whire(1,Z0,1)+xZ*whire(1,Z1,1);
end

ts.EU(t)       =mean(EU);
ts.UE(t)       =mean(UE);
ts.ENDED(t)    =mean(ENDED);
end
ts.N           =mean(ts.NZ,1)';
ts.N0          =mean(ts.N0Z,1)';
ts.u           =1-ts.N;
ts.u0          =1-ts.N0;
ts.f           =[0;ts.UE(2:end)./ts.u(1:end-1)];
ts.sbar        =[0;ts.EU(2:end)./ts.N(1:end-1)];
ts.s           =[0;ts.ENDED(2:end)./ts.N(1:end-1)];
ts.j           =ts.s-ts.sbar;
ts.whire       =mean(ts.whireZ,1)';

%Output
switch howmuchtosave
    case 'unemployment' % save unemployment series only
        tsoutput.u =ts.u(parsim.burnin+1:end);
    case 'flows' % save ins and outs of unemployment rates
        tsoutput.u    =ts.u(parsim.burnin+1:end);
        tsoutput.u0   =ts.u0(parsim.burnin+1:end);
        tsoutput.f    =ts.f(parsim.burnin+1:end);
        tsoutput.sbar =ts.sbar(parsim.burnin+1:end);
        tsoutput.s    =ts.s(parsim.burnin+1:end);
        tsoutput.j    =ts.j(parsim.burnin+1:end);
        tsoutput.A    =ts.A(parsim.burnin+1:end);
    case 'all' %save everything
        tsoutput   =ts; %burnin not remove
end