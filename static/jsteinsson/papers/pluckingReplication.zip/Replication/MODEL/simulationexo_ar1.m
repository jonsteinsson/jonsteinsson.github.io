function [X] = simulationexo_ar1(T,rhox,sigmaex,X0)

X            =zeros(T,1);
X(1)         =rhox*X0+normrnd(0,sigmaex);
        for t=2:T
        X(t)     =rhox*X(t-1)+normrnd(0,sigmaex);
        end


end