function [X,eta] = simulationexo_ar2(T,rhox1,rhox2,sigmaex,X0,eta0)

eta             =zeros(T,1);
eta(1)          =eta0;
X               =zeros(T,1);
X(1)            =X0;

for t=2:T
eta(t)          =rhox2*eta(t-1)+normrnd(0,sigmaex);
X(t)            =rhox1*X(t-1)+eta(t);
end

end