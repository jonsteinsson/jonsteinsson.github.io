function [sol,solfull] = solve_ar1_nash(guess,param,savehistory)

Jsolution       =guess.J;
fJsolution      =guess.fJ;
sizeJ           =size(Jsolution);
sizefJ          =size(fJsolution);

sol.J          =zeros(sizeJ);
sol.fJ         =zeros(sizefJ);
sol.w          =zeros(sizeJ);
sol.f          =zeros(sizefJ);

distanceJ                 ={Inf};
distancefJ                ={Inf};
distance                  ={Inf};
keepgoing                 =1;
lastround                 =0;
iteration                 =0;

while keepgoing
    newJsolution           =zeros(sizeJ);
    newfJsolution          =zeros(sizefJ);
    for i1=1:length(param.Alist)
        probasA                     =param.Ta(i1,:)';
    for i2=1:length(param.Zlist)
        probasZ                     =param.Tz(i2,:)';
        [EXPJ,EXPfJ]                =expectations_ar1_nash(Jsolution,fJsolution,probasA,probasZ,param);
        [J,f]                       =solveloop_nash(param.Alist(i1)*param.Zlist(i2),EXPJ,EXPfJ,param);
        newJsolution(i1,i2,:)       =J;
        newfJsolution(i1,i2)        =f*J(param.xhireindex);
        if lastround
            sol.J(i1,i2,:)         =J;
            sol.f(i1,i2)           =f;
            sol.fJ(i1,i2)          =f*J(param.xhireindex);
            sol.w(i1,i2,:)         =param.gamma*param.Alist(i1)*param.Zlist(i2)*param.xlist+(1-param.gamma)*param.z+param.discount*param.gamma*EXPfJ;
        end
    end
    end
    errorJ                         =newJsolution-Jsolution;
    errorfJ                        =newfJsolution-fJsolution;
    iteration                      =iteration+1;
     %disp(iteration)
    distanceJ{iteration+1}         =max(abs(reshape(errorJ,[],1)));
    distancefJ{iteration+1}        =max(abs(reshape(errorfJ,[],1)));
    distance{iteration+1}          =max(distanceJ{iteration+1},distancefJ{iteration+1});
     %disp(distance{iteration+1})
    Jsolution                      =newJsolution;
    fJsolution                     =newfJsolution;
    if savehistory
    eval(strcat('sol.iteration',num2str(iteration),'.J=Jsolution;'))
    eval(strcat('sol.iteration',num2str(iteration),'.fJ=fJsolution;'))
    eval(strcat('sol.iteration',num2str(iteration),'.errorJ=errorJ;'))
    eval(strcat('sol.iteration',num2str(iteration),'.errorfJ=errorfJ;'))
    end

    if lastround==1
        keepgoing=0;
    end
    if distance{end}<param.tol
        lastround=1;
    end      
    
end

sol.S                 =sol.J/(1-param.gamma);
    
sol.errorJ            =errorJ;
sol.errorfJ           =errorfJ;
sol.distanceJ         =distanceJ;
sol.distancefJ        =distancefJ;

if ~strcmp(param.wagesetting,'nashonly')
    % Wage in model under wage rigidity
    solfull.wnash           =repmat(sol.w,[1 1 1 length(param.wlaglist)]);
    solfull.wnash           =permute(solfull.wnash,[1 2 4 3]);
    solfull.w               =zeros(size(solfull.wnash));
    for i1=1:length(param.Alist)
    for i2=1:length(param.Zlist)
    for i3=1:length(param.wlaglist)
    for i4=1:length(param.xlist)
        solfull.w(i1,i2,i3,i4)   =param.wagerule(sol.w(i1,i2,i4),param.wlaglist(i3));
    end
    end
    end
    end
else
    solfull     =sol;
end


end