function [sol] = solve_ar2(guess,sol,param,savehistory)

Jsolution       =guess.J;
sizeJ           =size(Jsolution);

distance                  ={Inf};
keepgoing                 =1;
lastround                 =0;
iteration                 =0;

while keepgoing
    newJsolution          =zeros(sizeJ);
    for i1=1:length(param.Alist)%=A(t-1)
    for i1b=1:length(param.etalist)
        probaseta         =param.Teta(i1b,:)';
        A                 =param.Alist(i1)^(param.root1)*exp(param.etalist(i1b));%=A(t)
        [A0,A1,xA]        =findnodes(A,param.Alist);
        JsolutionA        =(1-xA)*Jsolution(A0,:,:,:,:)+xA*Jsolution(A1,:,:,:,:);
    for i2=1:length(param.Zlist)
        probasZ           =param.Tz(i2,:)';
    for i3=1:length(param.wlaglist)        
        w                 =squeeze(sol.w(i1,i1b,i2,i3,:));
        EXPJ              =expectations_ar2(w,JsolutionA,probaseta,probasZ,param);
        p                 =A*param.Zlist(i2)*param.xlist;
        J                 =max(p-w+param.discount*EXPJ,0);
        newJsolution(i1,i1b,i2,i3,:)  =J;
    end
    end
    end
    end
    errorJ                         =newJsolution-Jsolution;
    iteration                      =iteration+1;
    disp(iteration)
    distance{iteration+1}          =max(abs(reshape(errorJ,[],1)));
    disp(distance{iteration+1})
    Jsolution                      =newJsolution;
    if savehistory
    eval(strcat('sol.iteration',num2str(iteration),'.J=Jsolution;'))
    eval(strcat('sol.iteration',num2str(iteration),'.errorJ=errorJ;'))
    end
    
    if lastround==1
        keepgoing=0;
    end
    if distance{end}<param.tol || iteration>250
        lastround=1;
    end      

end

sol.J                =Jsolution;
sol.f                =(Jsolution(:,:,:,:,param.xhireindex)/param.c).^((1-param.eta)/param.eta);
sol.errorJ           =errorJ;
sol.distance         =distance;

end