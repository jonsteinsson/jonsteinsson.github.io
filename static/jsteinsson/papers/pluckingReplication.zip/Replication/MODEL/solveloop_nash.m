function [J,f] = solveloop_nash(P,EXPJ,EXPfJ,param)

if strcmp(param.hiring,'ladder')
    J         =NaN(length(param.xlist),1);
    % Nash bargaining for secured jobs
    J(end-param.nx+1:end)       =max(0,(1-param.gamma)*(P*param.xlist(end-param.nx+1:end)-param.z)+param.discount*(EXPJ(end-param.nx+1:end)-param.gamma*EXPfJ));
    wbegin                      =param.gamma*P*param.xlist(param.xhireindex)+(1-param.gamma)*param.z+param.discount*param.gamma*EXPfJ;
    % J for insecure jobs
    J(1:end-param.nx)           =max(0,P*param.xlist(1:end-param.nx)-wbegin+param.discount*EXPJ(1:end-param.nx));
else
if strcmp(param.hiring,'direct')
    J        =max(0,(1-param.gamma)*(P*param.xlist-param.z)+param.discount*(EXPJ-param.gamma*EXPfJ));
end
end

oneoverq  =J(param.xhireindex)/(param.c);
f         =oneoverq^((1-param.eta)/param.eta);

end