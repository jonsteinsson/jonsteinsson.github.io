function [stat] = statisticsFR(x,A)

stat.mean     =mean(x);
stat.std      =std(x);
stat.corrA    =corr(x,A);
aux           =cov(x,A);
stat.elasA    =aux(1,2)/std(A)^2;
stat.autocorr =corr(x(1:end-1),x(2:end));

end

