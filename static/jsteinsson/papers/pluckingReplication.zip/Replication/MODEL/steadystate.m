function [ss] = steadystate(param)

f                   =@(oneoverq)oneoverq^(1/param.eta-1);
J                   =@(oneoverq)(1-param.gamma)*(1-param.z)/(1-param.discount*(1-param.gamma*f(oneoverq)));
ss.oneoverq         =fzero(@(oneoverq)J(oneoverq)-param.c*oneoverq,0.5);
ss.J                =J(ss.oneoverq);
ss.f                =f(ss.oneoverq);
ss.w                =1-ss.J*(1-param.discount);
ss.S                =ss.J/(1-param.gamma);
ss.V                =param.gamma*ss.S;

ss.u                =param.delta/(param.delta+ss.f/(1-ss.f));

end

