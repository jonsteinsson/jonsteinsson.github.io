function [P] =tauchen(y,rho,F)
%% tauchen
% y is the grid for y;
% centered process
% rho is the autoregressive coefficient
% F is the CDF of the innovations
% Returns P, transition matrix

N       =length(y);
P       =zeros(N,N);
ymid    =(y(1:end-1)+y(2:end))/2;
for j=1:N
    P(j,1)  =F(ymid(1)-rho*y(j));
    for k=2:(N-1)
    P(j,k)  =F(ymid(k)-rho*y(j))-F(ymid(k-1)-rho*y(j));
    end
    P(j,N)  =1-F(ymid(N-1)-rho*y(j));
end
