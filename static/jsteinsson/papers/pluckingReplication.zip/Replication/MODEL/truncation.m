function [datatruncated,truncator] = truncation(data,maxsize)

datatruncated.contractions          =data.contractions(data.contractions<maxsize);
datatruncated.expansions            =data.expansions(data.expansions<maxsize);
datatruncated.contractiondurations  =data.contractiondurations(data.contractions<maxsize);
datatruncated.expansiondurations    =data.expansiondurations(data.expansions<maxsize);
datatruncated.speedcontraction      =datatruncated.contractions./(datatruncated.contractiondurations/12);
datatruncated.speedexpansion        =datatruncated.expansions./(datatruncated.expansiondurations/12);

% Sizes
datatruncated.meanc         =mean(datatruncated.contractions);
datatruncated.meane         =mean(datatruncated.expansions);
% Durations
datatruncated.meandc        =mean(datatruncated.contractiondurations);
datatruncated.meande        =mean(datatruncated.expansiondurations);
% Speeds
datatruncated.meansc        =mean(datatruncated.speedcontraction);
datatruncated.meanse        =mean(datatruncated.speedexpansion);

% Lastly, for calculating moments of u (mean, stddev and skewness)
% need a truncated u series
data.which                    =zeros(length(data.u),1);
for n=1:length(data.contractions)
    for t=data.datepeaks(n):data.datetroughs(n)
    data.which(t)   =-data.contractions(n);
    end
end
for n=1:length(data.expansions)
    for t=data.datetroughs(n):data.datepeaks(n+1)
    data.which(t)   =data.expansions(n);
    end
end
datatruncated.u             =data.u(abs(data.which)<maxsize);
truncator                   =abs(data.which)<maxsize;
