#####################################################################
## Support functions for calculating asset price statistics for our 
## disaster model.
##
## Emi Nakamura and Jon Steinsson, June 2008
#####################################################################

getControlVarAPHist <-
    function(allData)
{        
    # Number of points for which asset prices are calculated
    nAPpoints     <- 49
    
    # Indicator as to whether asset prices are calculated for draws from the 
    # priors or posteriors
    priorPostAP   <- 1      # If 0, use draws from prior. If 1, use draws from posterior.

    # Assets of Interest (program always calculates Equity returns)
    getOnePerBond    <- 1
    getPerpetuity    <- 0
    getScaledEq      <- 0  # Approximate leverage, lnD = alpha*lnC
    getOPEquity      <- 0  # One Period Equity
    
    # Simulation length
    nSim          <- 200000
    nSimBurnin    <- 1000
    nIter         <- 100000
    JJ            <- 200
    
    tolIntEq      <- 0.000001  # Tolerance for iterations on Equity integral
    tolIntBond    <- 0.000001  # Tolerance for iterations on Bond integral
    tolIntPerp    <- 0.000001  # Tolerance for iterations on Perpetuity integral
    tolIntScaEq   <- 0.000001  # Tolerance for iterations on "scaled" Equity integral
    tolIntOPEq    <- 0.000001  # Tolerance for iterations on One Period Equity integral

    maxIter       <- 1500    # Maximum number of iterations
    
    # Utility parameters
    gammaU        <- 6.4         # Risk-Aversion
    psiU          <- 2         # Intertemporal Elasticity of Substitution
    rhoU          <- 0.034       # Discount Rate
    thetaU        <- (1-gammaU)/(1-1/psiU)
        
    # Payoff properties of long term bond
    payGrowth     <- 0.90      # Gross growth rate of payoff on the perpetuity
    pDefaultLong  <- 0.40      # Probability that the perpetuity will suffer a partial default in each disaster period
    pDefaultShort <- 0.00      # Probability that the one period bond will suffer a partial default in each disaster period
     
    # Leverage on leveraged equity
    debtEqRatio   <- 0.50
 
    # Initial value for PDivEq
    initPDivEq    <- log(12)
    
    # State Gridsize
    nStateGridEps <- 1
    nStateGridZZ  <- 201
    
    nStateGrid    <- nStateGridEps*nStateGridZZ*2
    
    # Integration Gridsize
    nIntGridEps   <- 1
    nIntGridEta   <- 5
    nIntGridTheta <- 15
    nIntGridPhi   <- 15
    nIntGridNu    <- 1
    
    nIntGrid      <- nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi*nIntGridNu
    
    # Grid limits in units of standard deviations
    nSdEps        <- 2
    nSdEta        <- 3.5
    nSdTheta      <- 3.5
    nSdPhi        <- 3.5
    nSdNu         <- 2
    fracCutoffZZ  <- 0.025
    
    # ZZ Grid parameters
    ZZshrinkFactor <- 0.97 

    # Type of disaster
    onePerDis     <- 0
    onePerPermDis <- 0
    
    # Parameters for simulating a "typical disaster"
    nPrePeriods   <- 5
    nDisPeriods   <- 6
    nPostPeriods  <- 25
    
    countryToUse  <- which(allData$countryNames == "France")
    
    return(list(getOnePerBond = getOnePerBond, getPerpetuity = getPerpetuity,
                getScaledEq = getScaledEq, getOPEquity = getOPEquity, 
                nSim = nSim, nSimBurnin = nSimBurnin, nIter = nIter, JJ = JJ,
                tolIntEq = tolIntEq, tolIntBond = tolIntBond, tolIntPerp = tolIntPerp, 
                tolIntScaEq = tolIntScaEq, tolIntOPEq = tolIntOPEq,
                maxIter = maxIter,                  
                gammaU = gammaU, psiU = psiU, rhoU = rhoU, thetaU = thetaU, 
                nAPpoints = nAPpoints, priorPostAP = priorPostAP,
                payGrowth = payGrowth, pDefaultLong = pDefaultLong, pDefaultShort = pDefaultShort,
                debtEqRatio = debtEqRatio, initPDivEq = initPDivEq,    
                nStateGridEps = nStateGridEps, nStateGridZZ = nStateGridZZ,
                nIntGridEps = nIntGridEps, nIntGridEta = nIntGridEta, nIntGridNu = nIntGridNu,
                nIntGridTheta = nIntGridTheta, nIntGridPhi = nIntGridPhi,
                nStateGrid = nStateGrid, nIntGrid = nIntGrid,
                nSdEps = nSdEps, nSdEta = nSdEta, nSdTheta = nSdTheta,
                nSdPhi = nSdPhi, nSdNu = nSdNu, ZZshrinkFactor = ZZshrinkFactor,
                onePerDis = onePerDis, onePerPermDis = onePerPermDis,
                nPrePeriods = nPrePeriods, nDisPeriods = nDisPeriods, nPostPeriods = nPostPeriods,
                fracCutoffZZ = fracCutoffZZ, countryToUse = countryToUse))
}

## Get Iteration Numbers to Use
######################################################################

getIterNumbers <-
    function(nAPpoints)
{
    if (nAPpoints == 0) {
        vec <- 1:length(bigDataParams[,1])
    } else {
        Mult <- length(bigDataParams[,1]) %/% nAPpoints
        vec  <- seq(Mult, Mult*nAPpoints, by = Mult) 
    }
    return(vec)
}


## Get Parameter Vector
######################################################################

getPosteriorDraw <-
    function(nn, bigDataPosInfo)
{   
    tempParEst <- bigDataParams[nn,]
    
    ## Take averages of country specific shocks
    tempParEst[bigDataPosInfo$muPost]    <- c(rep(mean(tempParEst[bigDataPosInfo$muPost]),length(bigDataPosInfo$muPost)))
    tempParEst[bigDataPosInfo$sigmaEps]  <- c(rep(mean(tempParEst[bigDataPosInfo$sigmaEps]),length(bigDataPosInfo$sigmaEps)))
    tempParEst[bigDataPosInfo$sigmaEta]  <- c(rep(mean(tempParEst[bigDataPosInfo$sigmaEta]),length(bigDataPosInfo$sigmaEta)))    

    ## Set unimportant parameters to small value
    tempParEst[bigDataPosInfo$sigmaEps]  <- c(rep(0.00001^2,length(bigDataPosInfo$sigmaEps)))
    tempParEst[bigDataPosInfo$sigmaNu]   <- c(rep(0.00001^2,length(bigDataPosInfo$sigmaNu)))
          
    return(tempParEst)
}

getPriorDraw <-
    function(nn, modelData, bigDataPosInfo)
{
    tempParEst <- bigDataParams[nn,]
    
    tempParEst[bigDataPosInfo$meanPhi]       <- (modelData$low.meanPhi + (modelData$high.meanPhi - modelData$low.meanPhi)*rbeta(1, modelData$a.meanPhi, modelData$b.meanPhi))
    tempParEst[bigDataPosInfo$meanTheta]     <- rnorm(1, modelData$mu.meanTheta, modelData$tau.meanTheta^(-2))
    tempParEst[bigDataPosInfo$muMid]         <- rnorm(1, modelData$mu.muMid,     modelData$tau.muMid^(-2))
    tempParEst[bigDataPosInfo$muPost]        <- rnorm(1, modelData$mu.muPost,    modelData$tau.muPost^(-2))
    tempParEst[bigDataPosInfo$muPre]         <- rnorm(1, modelData$mu.muPre,     modelData$tau.muPre^(-2))
    tempParEst[bigDataPosInfo$ppC[1]]        <- (modelData$low.ppC1 + (modelData$high.ppC1 - modelData$low.ppC1)*rbeta(1, modelData$a.ppC1, modelData$b.ppC1))
    tempParEst[bigDataPosInfo$ppC[2]]        <- (modelData$low.ppC2 + (modelData$high.ppC2 - modelData$low.ppC2)*rbeta(1, modelData$a.ppC2, modelData$b.ppC2))
    tempParEst[bigDataPosInfo$ppC[3]]        <- (modelData$low.ppC3 + (modelData$high.ppC3 - modelData$low.ppC3)*rbeta(1, modelData$a.ppC3, modelData$b.ppC3))
    tempParEst[bigDataPosInfo$ppW]           <- (modelData$low.ppW  + (modelData$high.ppW  - modelData$low.ppW) *rbeta(1, modelData$a.ppW,  modelData$b.ppW))
    tempParEst[bigDataPosInfo$rho]           <- (modelData$low.rho  + (modelData$high.rho  - modelData$low.rho) *rbeta(1, modelData$a.rho,  modelData$b.rho))
    tempParEst[bigDataPosInfo$sigmaEps]      <- runif(1, modelData$low.sigmaEps,    modelData$high.sigmaEps)
    tempParEst[bigDataPosInfo$sigmaEpsPre]   <- runif(1, modelData$low.sigmaEpsPre, modelData$high.sigmaEpsPre)
    tempParEst[bigDataPosInfo$sigmaEta]      <- runif(1, modelData$low.sigmaEta,    modelData$high.sigmaEta)
    tempParEst[bigDataPosInfo$sigmaEtaPre]   <- runif(1, modelData$low.sigmaEtaPre, modelData$high.sigmaEtaPre)
    tempParEst[bigDataPosInfo$sigmaNu]       <- runif(1, modelData$low.sigmaNu,     modelData$high.sigmaNu)
    tempParEst[bigDataPosInfo$sigmaPhi]      <- (modelData$low.sigmaPhi + (modelData$high.sigmaPhi - modelData$low.sigmaPhi)*rbeta(1, modelData$a.sigmaPhi, modelData$b.sigmaPhi))
    tempParEst[bigDataPosInfo$sigmaTheta]    <- (modelData$low.sigmaTheta + (modelData$high.sigmaTheta - modelData$low.sigmaTheta)*rbeta(1, modelData$a.sigmaTheta, modelData$b.sigmaTheta))
    
    return(tempParEst)    
}

## Create Geweke type plots
#####################################################################

createGewekePlots <-
    function(outputDistAP, controlVar, UnobsPosInfo)
{   
    filename <-  file.path(outDir, 'gewekePlot.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    
    RiskFreeRate <- outputDistAP$logBondReturns
    EquityPremium <- outputDistAP$logEqReturns - outputDistAP$logBondReturns
    
    plot(RiskFreeRate, EquityPremium,
          main = paste('Equity and Bond Returns'))
    
    dev.off()
    
    filename <-  file.path(outDir, 'histEP.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 6)

    hist(EquityPremium,
         main = '', xlab = 'Equity Premium', ylab = 'Frequency',
         freq = TRUE)    
    
    dev.off()
    
    ## Save AP stuff in a text file
    temp.output <- cbind(outputDistAP$logEqReturns - outputDistAP$logBondReturns, 
                         outputDistAP$logEqReturns,outputDistAP$logEqReturnsNoDis,
                         outputDistAP$logBondReturns, outputDistAP$logBondReturnsNoDis)
    
    dimnames(temp.output) <- list(1:dim(temp.output)[1],1:dim(temp.output)[2])
    dimnames(temp.output)[[2]] <- cbind("Equity Premium", "logEqReturns", "logEqReturnsNoDis",
                                        "logBondReturns", "logBondReturnsNoDis")
    filename <-  file.path(outDir, 'APdist.txt')  
    write.table(temp.output, file = filename)
    
    ## Save key parameters in a text file
    countryToUse <- controlVar$countryToUse
    ParVec <- outputDistAP$ParVec
    ParVecKey <- as.matrix(ParVec[,UnobsPosInfo$muPost[countryToUse]])   
    dimnames(ParVecKey) <- list(1:dim(ParVecKey)[1],1:dim(ParVecKey)[2])    
    dimnames(ParVecKey)[[2]] <- "muPost"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$sigmaEps[countryToUse]])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "sigmaEps"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$sigmaEta[countryToUse]])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "sigmaEta"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$meanPhi])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "meanPhi"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$meanTheta])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "meanTheta"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$sigmaPhi])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "sigmaPhi"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$sigmaTheta])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "sigmaTheta"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$ppW[1]])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "pWb"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$ppC[1]])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "pCb_NWD"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$ppC[2]])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "pCe"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$ppC[3]])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "pCb_WD"
    ParVecKey <- cbind(ParVecKey, ParVec[,UnobsPosInfo$rho])
    dimnames(ParVecKey)[[2]][dim(ParVecKey)[2]] <- "rho"    
    
    filename <-  file.path(outDir, 'ParDist.txt')  
    write.table(ParVecKey, file = filename) 
    
}


## Create specialized histogram
#####################################################################

createHistAP <- 
    function(outputDistAP)
{
    eqPrem <- outputDistAP$logEqReturns - outputDistAP$logBondReturns
    
    # Creat bin breaks
    nBins   <- 31
    minHist <- 0
    maxHist <- 0.15
    setBreaks <- seq(from = minHist,to = maxHist, length.out = nBins)
    
    inRange <- (minHist < eqPrem & eqPrem < maxHist)
    belowRange <- sum(eqPrem < minHist)/length(eqPrem)
    aboveRange <- sum(maxHist < eqPrem)/length(eqPrem)
    
    cat('Fraction below range in histogram: ',belowRange,'\n')
    cat('Fraction above range in histogram: ',aboveRange,'\n')

    eqPrem <- eqPrem[which(inRange)]
    
    filename <-  file.path(outDir, 'histEP2.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 6)

    hist(eqPrem,
         main = '', 
         xlab = 'Equity Premium', 
         ylab = 'Density',
         freq = FALSE,
         #probability = TRUE,
         density = 30,
         breaks = setBreaks)    
    
    dev.off()    
    
}