#####################################################################
## Support functions for calculating asset price statistics for our 
## disaster model.
##
## Emi Nakamura and Jon Steinsson, June 2008
#####################################################################

getControlVarAPHistGamma <-
    function(allData)
{        
    # Number of points for which asset prices are calculated
    nAPpoints     <- 5
    
    # Indicator as to whether asset prices are calculated for draws from the 
    # priors or posteriors
    priorPostAP   <- 1      # If 0, use draws from prior. If 1, use draws from posterior.

    # Assets of Interest (program always calculates Equity returns)
    getOnePerBond    <- 1
    getPerpetuity    <- 0
    getScaledEq      <- 0  # Approximate leverage, lnD = alpha*lnC
    getOPEquity      <- 0  # One Period Equity
    
    # Simulation length
    nSim          <- 200000
    nSimBurnin    <- 1000
    nIter         <- 100000
    JJ            <- 200
    
    tolIntEq      <- 0.000001  # Tolerance for iterations on Equity integral
    tolIntBond    <- 0.000001  # Tolerance for iterations on Bond integral
    tolIntPerp    <- 0.000001  # Tolerance for iterations on Perpetuity integral
    tolIntScaEq   <- 0.000001  # Tolerance for iterations on "scaled" Equity integral
    tolIntOPEq    <- 0.000001  # Tolerance for iterations on One Period Equity integral

    maxIter       <- 1500    # Maximum number of iterations
    
    # Utility parameters
    gammaU        <- 6.5         # Risk-Aversion
    psiU          <- 2           # Intertemporal Elasticity of Substitution
    rhoU          <- 0.034       # Discount Rate
    thetaU        <- (1-gammaU)/(1-1/psiU)

    # Grid Search Parameters
    targetEqPrem  <- 0.048
    initialGamma  <- 6.4
    largestInc    <- 2.0    # Largest change in proposed Gamma
    smallestInc   <- 0.1    # Smallest change in proposed Gamma
        
    # Payoff properties of long term bond
    payGrowth     <- 0.90      # Gross growth rate of payoff on the perpetuity
    pDefaultLong  <- 0.40      # Probability that the perpetuity will suffer a partial default in each disaster period
    pDefaultShort <- 0.00      # Probability that the one period bond will suffer a partial default in each disaster period
     
    # Leverage on leveraged equity
    debtEqRatio   <- 0.50

    # Type of disaster
    onePerDis     <- 0
    onePerPermDis <- 0
 
    # Initial value for PDivEq
    initPDivEq    <- log(12)
    
    # State Gridsize
    nStateGridEps <- 1
    nStateGridZZ  <- 51
    
    nStateGrid    <- nStateGridEps*nStateGridZZ*2
    
    # Integration Gridsize
    nIntGridEps   <- 1
    nIntGridEta   <- 3
    nIntGridTheta <- 9
    nIntGridPhi   <- 9
    nIntGridNu    <- 1
    
    nIntGrid      <- nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi*nIntGridNu
    
    # Grid limits in units of standard deviations
    nSdEps        <- 2
    nSdEta        <- 3.5
    nSdTheta      <- 3.5
    nSdPhi        <- 3.5
    nSdNu         <- 2
    fracCutoffZZ  <- 0.025
    
    # ZZ Grid parameters
    ZZshrinkFactor <- 0.97 
    
    # Parameters for simulating a "typical disaster"
    nPrePeriods   <- 5
    nDisPeriods   <- 7
    nPostPeriods  <- 25
    
    countryToUse  <- which(allData$countryNames == "France")
    
    return(list(getOnePerBond = getOnePerBond, getPerpetuity = getPerpetuity,
                getScaledEq = getScaledEq, getOPEquity = getOPEquity, 
                nSim = nSim, nSimBurnin = nSimBurnin, nIter = nIter, JJ = JJ,
                tolIntEq = tolIntEq, tolIntBond = tolIntBond, tolIntPerp = tolIntPerp, 
                tolIntScaEq = tolIntScaEq, tolIntOPEq = tolIntOPEq,
                maxIter = maxIter,                  
                gammaU = gammaU, psiU = psiU, rhoU = rhoU, thetaU = thetaU, 
                targetEqPrem = targetEqPrem, 
                initialGamma = initialGamma, largestInc = largestInc, smallestInc = smallestInc,
                nAPpoints = nAPpoints, priorPostAP = priorPostAP,
                payGrowth = payGrowth, pDefaultLong = pDefaultLong, pDefaultShort = pDefaultShort,
                debtEqRatio = debtEqRatio, initPDivEq = initPDivEq,    
                nStateGridEps = nStateGridEps, nStateGridZZ = nStateGridZZ,
                nIntGridEps = nIntGridEps, nIntGridEta = nIntGridEta, nIntGridNu = nIntGridNu,
                nIntGridTheta = nIntGridTheta, nIntGridPhi = nIntGridPhi,
                nStateGrid = nStateGrid, nIntGrid = nIntGrid,
                nSdEps = nSdEps, nSdEta = nSdEta, nSdTheta = nSdTheta,
                nSdPhi = nSdPhi, nSdNu = nSdNu, ZZshrinkFactor = ZZshrinkFactor,
                nPrePeriods = nPrePeriods, nDisPeriods = nDisPeriods, nPostPeriods = nPostPeriods,
                onePerDis = onePerDis, onePerPermDis = onePerPermDis,
                fracCutoffZZ = fracCutoffZZ, countryToUse = countryToUse))
}

## Get Iteration Numbers to Use
######################################################################

getIterNumbers <-
    function(nAPpoints)
{
    if (nAPpoints == 0) {
        vec <- 1:length(bigDataParams[,1])
    } else {
        Mult <- length(bigDataParams[,1]) %/% nAPpoints
        vec  <- seq(Mult, Mult*nAPpoints, by = Mult) 
    }
    return(vec)
}


## Get Parameter Vector
######################################################################

getPosteriorDraw <-
    function(nn, bigDataPosInfo)
{   
    tempParEst <- bigDataParams[nn,]
    
    ## Take averages of country specific shocks
    tempParEst[bigDataPosInfo$muPost]    <- c(rep(mean(tempParEst[bigDataPosInfo$muPost]),length(bigDataPosInfo$muPost)))
    tempParEst[bigDataPosInfo$sigmaEps]  <- c(rep(mean(tempParEst[bigDataPosInfo$sigmaEps]),length(bigDataPosInfo$sigmaEps)))
    tempParEst[bigDataPosInfo$sigmaEta]  <- c(rep(mean(tempParEst[bigDataPosInfo$sigmaEta]),length(bigDataPosInfo$sigmaEta)))    

    ## Set unimportant parameters to small value
    tempParEst[bigDataPosInfo$sigmaEps]  <- c(rep(0.00001^2,length(bigDataPosInfo$sigmaEps)))
    tempParEst[bigDataPosInfo$sigmaNu]   <- c(rep(0.00001^2,length(bigDataPosInfo$sigmaNu)))
          
    return(tempParEst)
}

getPriorDraw <-
    function(nn, modelData, bigDataPosInfo)
{
    tempParEst <- bigDataParams[nn,]
    
    tempParEst[bigDataPosInfo$meanPhi]       <- (modelData$low.meanPhi + (modelData$high.meanPhi - modelData$low.meanPhi)*rbeta(1, modelData$a.meanPhi, modelData$b.meanPhi))
    tempParEst[bigDataPosInfo$meanTheta]     <- rnorm(1, modelData$mu.meanTheta, modelData$tau.meanTheta^(-2))
    tempParEst[bigDataPosInfo$muMid]         <- rnorm(1, modelData$mu.muMid,     modelData$tau.muMid^(-2))
    tempParEst[bigDataPosInfo$muPost]        <- rnorm(1, modelData$mu.muPost,    modelData$tau.muPost^(-2))
    tempParEst[bigDataPosInfo$muPre]         <- rnorm(1, modelData$mu.muPre,     modelData$tau.muPre^(-2))
    tempParEst[bigDataPosInfo$ppC[1]]        <- (modelData$low.ppC1 + (modelData$high.ppC1 - modelData$low.ppC1)*rbeta(1, modelData$a.ppC1, modelData$b.ppC1))
    tempParEst[bigDataPosInfo$ppC[2]]        <- (modelData$low.ppC2 + (modelData$high.ppC2 - modelData$low.ppC2)*rbeta(1, modelData$a.ppC2, modelData$b.ppC2))
    tempParEst[bigDataPosInfo$ppC[3]]        <- (modelData$low.ppC3 + (modelData$high.ppC3 - modelData$low.ppC3)*rbeta(1, modelData$a.ppC3, modelData$b.ppC3))
    tempParEst[bigDataPosInfo$ppW]           <- (modelData$low.ppW  + (modelData$high.ppW  - modelData$low.ppW) *rbeta(1, modelData$a.ppW,  modelData$b.ppW))
    tempParEst[bigDataPosInfo$rho]           <- (modelData$low.rho  + (modelData$high.rho  - modelData$low.rho) *rbeta(1, modelData$a.rho,  modelData$b.rho))
    tempParEst[bigDataPosInfo$sigmaEps]      <- runif(1, modelData$low.sigmaEps,    modelData$high.sigmaEps)
    tempParEst[bigDataPosInfo$sigmaEpsPre]   <- runif(1, modelData$low.sigmaEpsPre, modelData$high.sigmaEpsPre)
    tempParEst[bigDataPosInfo$sigmaEta]      <- runif(1, modelData$low.sigmaEta,    modelData$high.sigmaEta)
    tempParEst[bigDataPosInfo$sigmaEtaPre]   <- runif(1, modelData$low.sigmaEtaPre, modelData$high.sigmaEtaPre)
    tempParEst[bigDataPosInfo$sigmaNu]       <- runif(1, modelData$low.sigmaNu,     modelData$high.sigmaNu)
    tempParEst[bigDataPosInfo$sigmaPhi]      <- (modelData$low.sigmaPhi + (modelData$high.sigmaPhi - modelData$low.sigmaPhi)*rbeta(1, modelData$a.sigmaPhi, modelData$b.sigmaPhi))
    tempParEst[bigDataPosInfo$sigmaTheta]    <- (modelData$low.sigmaTheta + (modelData$high.sigmaTheta - modelData$low.sigmaTheta)*rbeta(1, modelData$a.sigmaTheta, modelData$b.sigmaTheta))
    
    return(tempParEst)    
}

## Grid Search over Gamma for given parameters
#####################################################################

EstGamma <-
    function(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, simOutput, simOutputOnGrid, printStuff = 1)
{
    targetEqPrem <- controlVarAP$targetEqPrem
    initialGamma <- controlVarAP$initialGamma
    largestInc   <- controlVarAP$largestInc
    smallestInc  <- controlVarAP$smallestInc
    
    psiU         <- controlVarAP$psiU
    
    currentInc   <- largestInc
    currentGamma <- initialGamma
    GammaLow  <- 0
    GammaHigh <- 100
    while (currentInc >= smallestInc) {    
        controlVarAP$gammaU <- currentGamma
        controlVarAP$thetaU <- (1-currentGamma)/(1-1/psiU)
        PDivs               <- getPDivs_EZW(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, printStuff = 0)
        if (length(PDivs) > 1) { # This is to deal with non-convergence in getPDivs_EZW
            returnsAP       <- calcReturns(simOutput, simOutputOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, printTime = 0)
            nPer            <- length(returnsAP$Equity$Return)
            EqPremOut       <- log(mean(returnsAP$Equity$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer]))            
            if (printStuff == 1) cat('*')
        } else {
            EqPremOut       <- 1000
            if (printStuff == 1) cat('$')
        }
        cat(c(EqPremOut,currentGamma, GammaLow, GammaHigh),'\n')
        #printParEstimates(controlVarAP,ParEstimates)
        if (EqPremOut < targetEqPrem) {
            GammaLow  <- currentGamma
            foundNewGamma <- 0
            while (foundNewGamma == 0) {
                if (currentGamma + currentInc < GammaLow + (GammaHigh-GammaLow)/2) {
                    foundNewGamma <- 1
                    currentGamma <- currentGamma + currentInc
                } else {
                    currentInc <- currentInc/2
                }
            }    
        } else if (EqPremOut >= targetEqPrem) {
            GammaHigh  <- currentGamma
            foundNewGamma <- 0
            while(foundNewGamma == 0) {
                if (currentGamma - currentInc > GammaHigh - (GammaHigh-GammaLow)/2) {
                    foundNewGamma <- 1
                    currentGamma <- currentGamma - currentInc
                } else {
                    currentInc <- currentInc/2
                }
            }
        }            
    }
    
    currentGamma <- (GammaHigh+GammaLow)/2
    
    return(currentGamma)
}

## Create specialized histogram
#####################################################################

createHistAP <- 
    function(outputDistAP)
{
    gammaU <- outputDistAP$gammaVec
    
    # Creat bin breaks
    nBins   <- 31
    minHist <- 0
    maxHist <- 12
    setBreaks <- seq(from = minHist,to = maxHist, length.out = nBins)
    
    inRange <- (minHist < gammaU & gammaU < maxHist)
    belowRange <- sum(gammaU < minHist)/length(gammaU)
    aboveRange <- sum(maxHist < gammaU)/length(gammaU)
    
    cat('Fraction below range in histogram: ',belowRange,'\n')
    cat('Fraction above range in histogram: ',aboveRange,'\n')

    gammaU <- gammaU[which(inRange)]
    
    filename <-  file.path(outDir, 'histGamma.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 6)

    hist(gammaU,
         main = '', 
         xlab = 'Gamma', 
         ylab = 'Density',
         freq = FALSE,
         #probability = TRUE,
         density = 30,
         breaks = setBreaks)    
    
    dev.off()    
    
}

## Print ParEstimates
#####################################################################

printParEstimates <-
    function(controlVarAP, ParEstimates)
{
    cat('\n')
    cat('PARAMETERS\n')
    cat('\n')
    cat('rhoU:                     ',controlVarAP$rhoU,'\n')
    cat('gammaU:                   ',controlVarAP$gammaU,'\n')
    cat('psiU:                     ',controlVarAP$psiU,'\n')
    cat('thetaU:                   ',controlVarAP$thetaU,'\n')
    cat('\n')
    cat('Mu:                       ',ParEstimates[bigDataPosInfo$muPost][controlVarAP$countryToUse],'\n')
    cat('sigmaEps:                 ',ParEstimates[bigDataPosInfo$sigmaEps][controlVarAP$countryToUse],'\n')
    cat('sigmaEta:                 ',ParEstimates[bigDataPosInfo$sigmaEta][controlVarAP$countryToUse],'\n')
    cat('\n')
    cat('pWb:                      ',ParEstimates[bigDataPosInfo$ppW],'\n')
    cat('pCb_NWD:                  ',ParEstimates[bigDataPosInfo$ppC][1],'\n')
    cat('pCb_WD:                   ',ParEstimates[bigDataPosInfo$ppC][3],'\n')
    cat('1-pCe:                    ',ParEstimates[bigDataPosInfo$ppC[2]],'\n')
    cat('rho:                      ',ParEstimates[bigDataPosInfo$rho],'\n')
    cat('meanPhi:                  ',ParEstimates[bigDataPosInfo$meanPhi],'\n')
    cat('meanTheta:                ',ParEstimates[bigDataPosInfo$meanTheta],'\n')
    cat('sigmaPhi:                 ',ParEstimates[bigDataPosInfo$sigmaPhi],'\n')
    cat('sigmaTheta:               ',ParEstimates[bigDataPosInfo$sigmaTheta],'\n')
    cat('\n')
    cat('Average Length Disaster:  ',1/(1-ParEstimates[bigDataPosInfo$ppC[2]]),'\n')
    cat('Prob Enter Disaster:      ',ParEstimates[bigDataPosInfo$ppW]*ParEstimates[bigDataPosInfo$ppC][3] 
                                      + (1-ParEstimates[bigDataPosInfo$ppW])*ParEstimates[bigDataPosInfo$ppC][1],'\n')
    cat('\n')

}