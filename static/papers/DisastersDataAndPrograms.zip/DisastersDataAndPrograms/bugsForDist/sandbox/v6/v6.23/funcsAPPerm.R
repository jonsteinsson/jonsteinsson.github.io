#####################################################################
## Support functions for calculating asset prices for our disaster
## model.
##
## Emi Nakamura and Jon Steinsson, June 2008
#####################################################################

getControlVarAP <-
    function(allData)
{
    # Type of disaster
    onePerPermDis   <- 1
    MultiPerPermDis <- 0

    doEZW         <- 1
    doPowerU      <- 0 
    updatePDivs   <- 1
        
    # Assets of Interest (program always calculates Equity returns)
    getOnePerBond    <- 1
    getPerpetuity    <- 0
    getScaledEq      <- 0  # Approximate leverage, lnD = alpha*lnC
    getOPEquity      <- 0  # One Period Equity
    
    # Simulation length
    nSim          <- 150000
    nSimBurnin    <- 1000
    nIter         <- 100000  # Number of iterations in calculation of PDiv
    JJ            <- 200
    
    tolIntEq      <- 0.000001  # Tolerance for iterations on Equity integral
    tolIntBond    <- 0.000001  # Tolerance for iterations on Bond integral
    tolIntPerp    <- 0.000001  # Tolerance for iterations on Perpetuity integral
    tolIntScaEq   <- 0.000001  # Tolerance for iterations on "scaled" Equity integral
    tolIntOPEq    <- 0.000001  # Tolerance for iterations on One Period Equity integral

    maxIter       <- 1500      # Maximum number of iterations
    
    # Utility parameters
    gammaU        <- 6.4         # Risk-Aversion
    psiU          <- 2           # Intertemporal Elasticity of Substitution
    rhoU          <- 0.034       # Discount Rate
    thetaU        <- (1-gammaU)/(1-1/psiU)
    
    # Payoff properties of long term bond
    payGrowth     <- 0.90      # Gross growth rate of payoff on the perpetuity
    pDefaultLong  <- 0.40      # Probability that the perpetuity will suffer a partial default in each disaster period
    pDefaultShort <- 0.00      # Probability that the one period bond will suffer a partial default in each disaster period
    
    # Leverage on leveraged equity
    debtEqRatio   <- 0.50    
    
    # For getDistasterDist
    updateDistDisBasePar <- 0
    updateDistDis <- 1
    nSimDistDis   <- 25000
    maxDistDrop   <- 1.0   # max percentage drop in PeakTrough and LongRun
        
    # Initial value for PDivEq
    initPDivEq    <- log(12)
    
    # State Gridsize
    nStateGridEps <- 1
    nStateGridZZ  <- 1
    
    nStateGrid    <- nStateGridEps*nStateGridZZ*2
    
    # Integration Gridsize
    nIntGridEps   <- 1
    nIntGridEta   <- 5
    nIntGridTheta <- 155
    nIntGridPhi   <- 1
    nIntGridNu    <- 1
    
    nIntGrid      <- nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi*nIntGridNu
    
    # Grid limits in units of standard deviations
    nSdEps        <- 2
    nSdEta        <- 3.5
    nSdTheta      <- 9.5
    nSdPhi        <- 3.5
    nSdNu         <- 2
    fracCutoffZZ  <- 0.025
    
    # ZZ Grid parameters
    ZZshrinkFactor <- 0.97 
    
    # Parameters for simulating a "typical disaster"
    nPrePeriods   <- 5
    nDisPeriods   <- 6
    nPostPeriods  <- 25
    
    if (onePerPermDis) nDisPeriods <- 1
    
    countryToUse  <- which(allData$countryNames == "France")
    
    return(list(doEZW = doEZW, doPowerU = doPowerU, updatePDivs = updatePDivs, 
                getOnePerBond = getOnePerBond, getPerpetuity = getPerpetuity,
                getScaledEq = getScaledEq, getOPEquity = getOPEquity, 
                nSim = nSim, nSimBurnin = nSimBurnin, nIter = nIter, JJ = JJ,
                tolIntEq = tolIntEq, tolIntBond = tolIntBond, tolIntPerp = tolIntPerp, 
                tolIntScaEq = tolIntScaEq, tolIntOPEq = tolIntOPEq,
                maxIter = maxIter,                  
                gammaU = gammaU, psiU = psiU, rhoU = rhoU, thetaU = thetaU, 
                payGrowth = payGrowth, pDefaultLong = pDefaultLong, pDefaultShort = pDefaultShort,
                debtEqRatio = debtEqRatio, initPDivEq = initPDivEq,
                nStateGridEps = nStateGridEps, nStateGridZZ = nStateGridZZ, 
                nIntGridEps = nIntGridEps, nIntGridEta = nIntGridEta, nIntGridNu = nIntGridNu,
                nIntGridTheta = nIntGridTheta, nIntGridPhi = nIntGridPhi,
                nStateGrid = nStateGrid, nIntGrid = nIntGrid,
                nSdEps = nSdEps, nSdEta = nSdEta, nSdTheta = nSdTheta,
                nSdPhi = nSdPhi, nSdNu = nSdNu, ZZshrinkFactor = ZZshrinkFactor,
                nPrePeriods = nPrePeriods, nDisPeriods = nDisPeriods, nPostPeriods = nPostPeriods,
                MultiPerPermDis = MultiPerPermDis, onePerPermDis = onePerPermDis, maxDistDrop = maxDistDrop,
                updateDistDis = updateDistDis, updateDistDisBasePar = updateDistDisBasePar,
                nSimDistDis = nSimDistDis,
                fracCutoffZZ = fracCutoffZZ, countryToUse = countryToUse))
}

## Get Parameter Estimates
######################################################################

getParEstimates <-
    function(UnobsPosInfo, controlVar, DistDisasters)
{
    timer1 <- proc.time()[3]

    filename <-  file.path(outDir, paste(c('bigDataParams','Rda'),collapse = '.'))  
    load(filename)
    
    ParEst <- numeric(dim(bigDataParams)[2])
    for (ii in UnobsPosInfo$deviance) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$meanPhi) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$meanTheta) ParEst[ii]     <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muMid) ParEst[ii]         <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muPost) ParEst[ii]        <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muPre) ParEst[ii]         <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$ppC) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$ppW) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$rho) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$rhobets) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEps) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEpsPre) ParEst[ii]   <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEta) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEtaPre) ParEst[ii]   <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaNu) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaPhi) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaTheta) ParEst[ii]    <- mean(bigDataParams[,ii])
    
    ## Take averages of country specific shocks
    ParEst[UnobsPosInfo$muPost]      <- c(rep(mean(ParEst[UnobsPosInfo$muPost]),length(UnobsPosInfo$muPost)))
    ParEst[UnobsPosInfo$sigmaEps]  <- c(rep(mean(ParEst[UnobsPosInfo$sigmaEps]),length(UnobsPosInfo$sigmaEps)))
    ParEst[UnobsPosInfo$sigmaEta]  <- c(rep(mean(ParEst[UnobsPosInfo$sigmaEta]),length(UnobsPosInfo$sigmaEta)))    

    ## Set unimportant parameters to small value
    ParEst[UnobsPosInfo$sigmaEps]  <- c(rep(0.00001,length(UnobsPosInfo$sigmaEps)))
    ParEst[UnobsPosInfo$sigmaNu]   <- c(rep(0.00001,length(UnobsPosInfo$sigmaNu)))
    
    ## No disasters
    #ParEst[UnobsPosInfo$ppW]         <- 0.0
    #ParEst[UnobsPosInfo$ppC]         <- c(0.0,0.0,0.0)
    
    ## No Temporary component
    ParEst[UnobsPosInfo$meanPhi]   <- 0
    ParEst[UnobsPosInfo$sigmaPhi]  <- 10^(-8)
        
    if(controlVar$onePerPermDis) {
        ParEst[UnobsPosInfo$ppC][2]      <- 0.028                
        ParEst[UnobsPosInfo$meanTheta]   <- mean(DistDisasters$DistDropPeakTrough)
        ParEst[UnobsPosInfo$sigmaTheta]  <- var(DistDisasters$DistDropPeakTrough)^(1/2)        
    }
    
    if(controlVar$MultiPerPermDis) {                        
        ParEst[UnobsPosInfo$meanTheta]   <- mean(DistDisasters$DistDropPeakTrough)*(1-ParEst[UnobsPosInfo$ppC[2]])
        ParEst[UnobsPosInfo$sigmaTheta]  <- (var(DistDisasters$DistDropPeakTrough)*(1-ParEst[UnobsPosInfo$ppC[2]]))^(1/2)       
    }
    
    # Ad hoc
    #ParEst[UnobsPosInfo$sigmaTheta]  <- 10^(-8)
    #ParEst[UnobsPosInfo$sigmaEta]  <- 10^(-8)
    
    timer1 <- proc.time()[3] - timer1
    cat('time getParEstimates = ',timer1,'\n')
        
    return(ParEst)
}

## Calculate the distributions of ZZ, Peak to Trough and Long Run 
## effects of the disaster. Used, e.g., in calcWeights for one period
## and permanent disasters.
#####################################################################

getDistDisasters <-    
    function(controlVar, ParEst, UnobsPosInfo, IRlength = 35, useBaselinePar)
{        
    timer1 <- proc.time()[3]

    nSim           <- controlVar$nSimDistDis
    countryToUse   <- controlVar$countryToUse
    maxDistDrop    <- controlVar$maxDistDrop
    
    # Use baseline parameters as oppose to OnePerDis, etc.
    if (useBaselinePar) {
        filename <-  file.path(outDir, paste(c('bigDataParams','Rda'),collapse = '.'))  
        load(filename)
        for (ii in UnobsPosInfo$muPost[countryToUse])        mu         <- mean(bigDataParams[,ii])
        for (ii in UnobsPosInfo$sigmaEta[countryToUse])      sigmaEta   <- mean(bigDataParams[,ii])
        for (ii in UnobsPosInfo$meanPhi)                     meanPhi    <- mean(bigDataParams[,ii])
        for (ii in UnobsPosInfo$meanTheta)                   meanTheta  <- mean(bigDataParams[,ii])
        for (ii in UnobsPosInfo$sigmaPhi)                    sigmaPhi   <- mean(bigDataParams[,ii])
        for (ii in UnobsPosInfo$sigmaTheta)                  sigmaTheta <- mean(bigDataParams[,ii])
        for (ii in UnobsPosInfo$rho)                         rho        <- mean(bigDataParams[,ii])
        for (ii in UnobsPosInfo$ppC[2])                      ppCc       <- mean(bigDataParams[,ii])
    } else {
        mu             <- ParEst[UnobsPosInfo$muPost][countryToUse]
        sigmaEta       <- ParEst[UnobsPosInfo$sigmaEta][countryToUse]
        meanPhi        <- ParEst[UnobsPosInfo$meanPhi]
        sigmaPhi       <- ParEst[UnobsPosInfo$sigmaPhi]
        meanTheta      <- ParEst[UnobsPosInfo$meanTheta]
        sigmaTheta     <- ParEst[UnobsPosInfo$sigmaTheta]
        rho            <- ParEst[UnobsPosInfo$rho]
        ppCc           <- 0
    }
    
    DistDropBeginEnd   <- matrix(0,nrow = nSim, ncol = 1)
    DistDropPeakTrough <- matrix(0,nrow = nSim, ncol = 1)
    DistDropLongRun    <- matrix(0,nrow = nSim, ncol = 1)
    DistMaxZZ          <- matrix(0,nrow = nSim, ncol = 1)
    DistMinZZ          <- matrix(0,nrow = nSim, ncol = 1)
            
    XX <- matrix(0,nrow = nSim, ncol = IRlength + 1)
    ZZ <- matrix(0,nrow = nSim, ncol = IRlength + 1)
    for (ii in 1:nSim) {
        phi     <- matrix(0, nrow = IRlength, ncol = 1)
        theta   <- matrix(0, nrow = IRlength, ncol = 1)

        disLength            <- rgeom(1,1-ppCc) + 1
        if (disLength > IRlength) disLength <- IRlength
        phi[1:disLength,1]   <- rtnorm(disLength,mean = meanPhi, sd = sigmaPhi, lower = -1000, upper = 0)
        theta[1:disLength,1] <- rnorm(disLength,mean = meanTheta, sd = sigmaTheta)
        XX[ii,2] <- theta[1,1]
        ZZ[ii,2] <- phi[1,1] - theta[1,1]        
        for (jj in 3:(IRlength+1)) { 
            ZZ[ii,jj] <- (rho*ZZ[ii,jj-1] + phi[jj-1,1] - theta[jj-1,1])
            XX[ii,jj] <- XX[ii,jj-1] + theta[jj-1,1]
        }
        DistDropBeginEnd[ii,1]   <- XX[ii,disLength+1] + ZZ[ii,disLength+1]
        DistDropPeakTrough[ii,1] <- min(XX[ii,] + ZZ[ii,])
        DistDropLongRun[ii,1]    <- XX[ii,IRlength+1] + ZZ[ii,IRlength+1]
        DistMaxZZ[ii,1]          <- max(XX[ii,])
        DistMinZZ[ii,1]          <- min(XX[ii,])
    }
    
    DistDropPeakTrough <- DistDropPeakTrough[(exp(DistDropPeakTrough) > 1 - maxDistDrop)]
    DistDropLongRun    <- DistDropLongRun[(exp(DistDropLongRun) > 1 - maxDistDrop)]
    DistDropBeginEnd   <- DistDropBeginEnd[(exp(DistDropBeginEnd) > 1 - maxDistDrop)]
    DistMinZZ          <- DistMinZZ[(exp(DistMinZZ) > 1 - maxDistDrop)]

    timer1 <- proc.time()[3] - timer1
    cat('time getDistDisasters = ',timer1,'\n')
    
    return(list(DistDropBeginEnd = DistDropBeginEnd, 
           DistDropPeakTrough = DistDropPeakTrough,
           DistDropLongRun = DistDropLongRun,
           DistMaxZZ = DistMaxZZ, DistMinZZ = DistMinZZ))
}

getDistQuantiles <-
    function(DistFull, nSd, nPoints)
{    
    DistFull   <- sort(DistFull)   
    fracCutOff <- pnorm(-nSd)
    incProb    <- (1 - 2*fracCutOff)/(nPoints-1)
    nDist       <- length(DistFull)
    DistQuants <- numeric(nPoints)
    for (ii in 1:nPoints) {
        tempProb       <- fracCutOff + (ii-1)*incProb
        nTemp          <- max(1,floor(tempProb*nDist))
        DistQuants[ii] <- DistFull[nTemp]
    }
    
    return(DistQuants)
}

getSimpleSequence <-
    function(DistFull, nSd, nPoints)
{    
    DistFull   <- sort(DistFull)   
    fracCutOff <- pnorm(-nSd)
    nDist      <- length(DistFull)
    qLow       <- DistFull[max(1,floor(fracCutOff*nDist))]
    qHigh      <- DistFull[ceiling((1-fracCutOff)*nDist)]
    DistQuants <- seq(qLow, qHigh, length.out = nPoints)
    
    return(DistQuants)
}

# Create Grids
#####################################################################
# State Vector: Eps, ZZ, II
# Integration Vector: Eps,  Eta, Theta, Phi, Nu        

createStateGrid <-
    function(controlVar, ParEst, UnobsPosInfo, DistDisasters)
{
    countryToUse <- controlVar$countryToUse
    
    nStateGridEps <- controlVar$nStateGridEps
    nStateGridZZ  <- controlVar$nStateGridZZ        
    
    nSdEps        <- controlVar$nSdEps
    sigmaEps      <- ParEst[UnobsPosInfo$sigmaEps][countryToUse]

    ZZshrinkFactor<- controlVar$ZZshrinkFactor    
    fracCutoffZZ  <- controlVar$fracCutoffZZ 
    
    distMinZZ     <- sort(DistDisasters$DistMinZZ)
    distMaxZZ     <- sort(DistDisasters$DistMaxZZ, decreasing = TRUE)

    nDistZZ       <- length(distMinZZ)
    nDistZZCutoff <- floor(fracCutoffZZ*nDistZZ)
    tempMaxGridZZ <- distMaxZZ[nDistZZCutoff]
    tempMinGridZZ <- distMinZZ[nDistZZCutoff]
    
    #Create Gridpoints
    gridII        <- c(0,1)
    if (nStateGridEps == 1) {
        gridEps   <- 0
    } else {
        gridEps   <- seq(-nSdEps*sigmaEps, nSdEps*sigmaEps, length.out = nStateGridEps)
    }
    if (nStateGridZZ == 1) {
        gridZZ    <- 0
    } else {
        maxGridZZ <- max(0.05,tempMaxGridZZ)
        minGridZZ <- min(-0.05,tempMinGridZZ)
        fracPosZZ <- maxGridZZ/(maxGridZZ-minGridZZ)
        nPosZZ    <- max(2,min(nStateGridZZ-2,floor(fracPosZZ*nStateGridZZ)))
        nNegZZ    <- nStateGridZZ - nPosZZ - 1
        gridZZ    <- numeric(nStateGridZZ)
        NegBaseInc<- abs(minGridZZ)*((ZZshrinkFactor -1)/(ZZshrinkFactor^nNegZZ-1))
        PosBaseInc<- abs(maxGridZZ)*((ZZshrinkFactor -1)/(ZZshrinkFactor^nPosZZ-1))
        
        gridZZ[1] <- minGridZZ
        
        if (nNegZZ > 1) {
            for(ii in 2:nNegZZ) {
                gridZZ[ii] <- gridZZ[ii-1] + ZZshrinkFactor^(ii-2)*NegBaseInc
            }
        }
        gridZZ[nStateGridZZ] <- maxGridZZ
        if (nPosZZ > 1) {
            for(ii in 2:nPosZZ) {
                gridZZ[nStateGridZZ-ii+1] <- gridZZ[nStateGridZZ-ii+2] - ZZshrinkFactor^(ii-2)*PosBaseInc
            }
        }
        
        # To turn off ZZshrinkFactor
        #gridZZ   <- seq(minGridZZ, maxGridZZ, length.out = nStateGridZZ)    
    }
    
    #Create state grid
    stateGrid     <- as.matrix(expand.grid(gridEps, gridZZ, gridII))
    dimnames(stateGrid)[[2]] <- c('Eps','ZZ','II')
        
    return(list(stateGrid = stateGrid, gridII = gridII, gridEps = gridEps, gridZZ = gridZZ))
}
    

createIntGrid <-
    function(controlVar, ParEst, UnobsPosInfo, DistDisasters)
{
    countryToUse  <- controlVar$countryToUse
    
    onePerPermDis <- controlVar$onePerPermDis
    
    nIntGridEps   <- controlVar$nIntGridEps
    nIntGridEta   <- controlVar$nIntGridEta
    nIntGridTheta <- controlVar$nIntGridTheta
    nIntGridPhi   <- controlVar$nIntGridPhi
    nIntGridNu    <- controlVar$nIntGridNu

    nSdEps        <- controlVar$nSdEps
    nSdEta        <- controlVar$nSdEta
    nSdTheta      <- controlVar$nSdTheta
    nSdPhi        <- controlVar$nSdPhi
    nSdNu         <- controlVar$nSdNu

    sigmaEps      <- ParEst[UnobsPosInfo$sigmaEps][countryToUse]
    sigmaEta      <- ParEst[UnobsPosInfo$sigmaEta][countryToUse]
    meanPhi       <- ParEst[UnobsPosInfo$meanPhi]
    sigmaPhi      <- ParEst[UnobsPosInfo$sigmaPhi]
    meanTheta     <- ParEst[UnobsPosInfo$meanTheta]
    sigmaTheta    <- ParEst[UnobsPosInfo$sigmaTheta]
    sigmaNu       <- ParEst[UnobsPosInfo$sigmaNu][countryToUse]

    uu <- 0
    ll <- -1000        
    meanPhiStar  <- meanPhi + ((dnorm((ll-meanPhi)/sigmaPhi) - dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))*sigmaPhi
    varTemp      <- sigmaPhi^2*(1+((((ll-meanPhi)/sigmaPhi)*dnorm((ll-meanPhi)/sigmaPhi) - ((uu-meanPhi)/sigmaPhi)*dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))
                                -((dnorm((ll-meanPhi)/sigmaPhi) - dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))^2)
    sigmaPhiStar <- varTemp^(1/2)
        
    #shockvec is : Eps, Eta, Theta, Phi, Nu
    #Create gridpoints
    if (nIntGridEps == 1) {
        tempGridEps   <- 0
    } else {
        tempGridEps   <- seq(-nSdEps*sigmaEps, nSdEps*sigmaEps, length.out = (nIntGridEps+1))            
    }
    if (nIntGridEta == 1) {
        tempGridEta   <- 0 
    } else {
        tempGridEta   <- seq(-nSdEta*sigmaEta, nSdEta*sigmaEta, length.out = (nIntGridEta+1))
    }
    if (nIntGridTheta == 1) {
        tempGridTheta <- meanTheta 
    } else if (!onePerPermDis) {
        tempGridTheta <- seq(meanTheta - nSdTheta*sigmaTheta, meanTheta + nSdEta*sigmaTheta, length.out = (nIntGridTheta+1))        
    } else if (onePerPermDis) {
        #tempGridTheta <- getDistQuantiles(DistDisasters$DistDropPeakTrough, nSdTheta, nIntGridTheta+1)
        tempGridTheta <- getSimpleSequence(DistDisasters$DistDropPeakTrough, nSdTheta, nIntGridTheta+1)
    }
    if (nIntGridPhi == 1) {
        tempGridPhi   <- meanPhi
    } else {
        tempGridPhi   <- seq(meanPhiStar - nSdPhi*sigmaPhiStar, uu, length.out = (nIntGridPhi+1))
    } 
    if (nIntGridNu == 1) {
        tempGridNu    <- 0
    } else { 
        tempGridNu    <- seq(-nSdNu*sigmaNu, nSdNu*sigmaNu, length.out = (nIntGridNu+1))
    }
    
    #Generate grid midpoints
    if (nIntGridEps == 1) {
        gridEps   <- 0
    } else {
        gridEps   <-  (tempGridEps[2:(nIntGridEps+1)] + tempGridEps[1:nIntGridEps]) /2
    }
    if (nIntGridEta == 1) {
        gridEta   <- 0
    } else {
        gridEta   <-  (tempGridEta[2:(nIntGridEta+1)] + tempGridEta[1:nIntGridEta]) /2
    }
    if (nIntGridTheta == 1) {
        gridTheta <- meanTheta
    } else {
        gridTheta <-  (tempGridTheta[2:(nIntGridTheta+1)] + tempGridTheta[1:nIntGridTheta]) /2
    }
    if (nIntGridPhi == 1) {
        gridPhi   <- meanPhi
    } else {
        gridPhi   <-  (tempGridPhi[2:(nIntGridPhi+1)] + tempGridPhi[1:nIntGridPhi]) /2
    }
    if (nIntGridNu == 1) {
        gridNu    <- 0
    } else {
        gridNu    <-  (tempGridNu[2:(nIntGridNu+1)] + tempGridNu[1:nIntGridNu]) /2
    }
    
    #Create state grid
    intGrid <- as.matrix(expand.grid(gridEps, gridEta, gridTheta, gridPhi, gridNu))
    dimnames(intGrid)[[2]] <- c('Eps','Eta','Theta','Phi','Nu')

    return(list(intGrid = intGrid, gridEps = gridEps, gridEta = gridEta,
                gridTheta = gridTheta, gridPhi = gridPhi, gridNu = gridNu,
                tempGridEps = tempGridEps, tempGridTheta = tempGridTheta, 
                tempGridPhi = tempGridPhi, tempGridEta = tempGridEta, tempGridNu = tempGridNu))

}

# Create nextStateFunc
#####################################################################

nextStateFuncGen <-
    function(stateGridList,intGridList, controlVar, ParEst, UnobsPosInfo)
{
    countryToUse <- controlVar$countryToUse

    intGridEps   <- intGridList$gridEps
    intGridEta   <- intGridList$gridEta
    intGridTheta <- intGridList$gridTheta
    intGridPhi   <- intGridList$gridPhi
    intGridNu    <- intGridList$gridNu
    
    nIntGridEps    <- length(intGridEps)
    nIntGridEta    <- length(intGridEta)
    nIntGridTheta  <- length(intGridTheta)
    nIntGridPhi    <- length(intGridPhi)
    nIntGridNu     <- length(intGridNu)
    
    stateGridEps <- stateGridList$gridEps
    stateGridZZ  <- stateGridList$gridZZ
    
    nStateGridEps <- length(stateGridEps)
    nStateGridZZ  <- length(stateGridZZ)
    
    nStates <- dim(stateGridList$stateGrid)[1]
    nInt    <- dim(intGridList$intGrid)[1]

    rhoZZ         <- ParEst[UnobsPosInfo$rho]

    nextStateFunc <-
        function(currentState)
    {
        oldZZ <- currentState[2]

        # No-disaster case
        nextStateNoDis <- numeric(nInt)
        for (iiNu in 1:nIntGridNu) {
            runZZ     <- rhoZZ*oldZZ + intGridNu[iiNu]
            indRunZZ  <- which.min(abs(stateGridZZ-runZZ))
            
            # We can skip Phi, Theta and Eta since ZZ and Eps are constant for these in this case
            nextStateEps    <- numeric(nIntGridEps)
            for(iiEps in 1:nIntGridEps) {
                runEps    <- intGridEps[iiEps]
                indRunEps <- which.min(abs(stateGridEps-runEps))                
                nextStateEps[iiEps] <- (indRunZZ-1)*nStateGridEps + indRunEps
            }
            nextStateEps   <- rep(nextStateEps,nIntGridEta*nIntGridTheta*nIntGridPhi)
            startInd       <- (iiNu-1)*nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi + 1
            endInd         <- iiNu*nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi
            nextStateNoDis[startInd:endInd] <- nextStateEps
        }
        
        # Disaster case
        nextStateDis <- numeric(nInt)
        for (iiNu in 1:nIntGridNu) {
            for (iiPhi in 1:nIntGridPhi) {
                for (iiTheta in 1:nIntGridTheta) {
                    runZZ     <- rhoZZ*oldZZ + intGridPhi[iiPhi] + intGridNu[iiNu]
                    indRunZZ  <- which.min(abs(stateGridZZ-runZZ))
                    
                    # We can skip Eta since ZZ and Eps are constant over Eta
                    nextStateEps    <- numeric(nIntGridEps)
                    for (iiEps in 1:nIntGridEps) {
                        runEps    <- intGridEps[iiEps]
                        indRunEps <- which.min(abs(stateGridEps-runEps))                        
                        nextStateEps[iiEps] <- nStateGridZZ*nStateGridEps + (indRunZZ-1)*nStateGridEps + indRunEps
                    }
                    nextStateEps   <- rep(nextStateEps,nIntGridEta)
                    
                    startInd       <- ((iiNu-1)*nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi 
                                       + (iiPhi-1)*nIntGridEps*nIntGridEta*nIntGridTheta
                                       + (iiTheta-1)*nIntGridEps*nIntGridEta + 1)
                    endInd         <- ((iiNu-1)*nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi 
                                       + (iiPhi-1)*nIntGridEps*nIntGridEta*nIntGridTheta
                                       + (iiTheta-1)*nIntGridEps*nIntGridEta + length(nextStateEps))
                    nextStateDis[startInd:endInd] <- nextStateEps
                    
                    #cat('[iiNu, iiPhi, iiTheta] = ',iiNu,' ',iiPhi,' ',iiTheta,'\n')
                    #print(nextStateEps)
                    #cat('\n')
                    #browser()                    
                }
            }
        }
        
        #if (mean(nextStateNoDis) != 130) browser()
        #if (mean(nextStateDis) != 238) browser()
        
        #browser()
        
        return(list(nextStateNoDis = nextStateNoDis, nextStateDis = nextStateDis))
    }
    
    return(nextStateFunc)
}

nextStateFuncGenAndSave <-
    function(stateGridList,intGridList, controlVar, ParEst, UnobsPosInfo)
{
    nextStateFunc   <- nextStateFuncGen(stateGridList, intGridList, controlVar, ParEst, UnobsPosInfo)
    stateGrid <- stateGridList$stateGrid
    nStateGrid <- dim(stateGrid)[1]
    
    timer2 <- proc.time()[3]
        
    for (ii in 1:nStateGrid) {        
        nextState <- nextStateFunc(stateGrid[ii,])
        filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
        save(nextState,file = filename)
    }
    
    timer2 <- proc.time()[3] - timer2
    # cat('Time Gen and Save nextState: ',timer2,'\n\n')
}


# Create probability distribution over intGrid
#####################################################################

getWeightsSimpleSequence <- 
    function(distFull, tempGrid)
{
    distFull <- sort(distFull)
    nDistPoints <- length(distFull)
    nGridPoints <- length(tempGrid)-1
    shockWeights <- numeric(nGridPoints)
    
    for (ii in 1:nGridPoints) {
        nWithin <- sum(tempGrid[ii] < distFull & distFull <= tempGrid[ii+1])
        shockWeights[ii] <- nWithin/nDistPoints
    }    
    shockWeights[1] <- shockWeights[1] + sum(distFull <= tempGrid[1])/nDistPoints
    shockWeights[nGridPoints] <- shockWeights[nGridPoints] + sum(tempGrid[nGridPoints+1] < distFull)/nDistPoints
    
    return(shockWeights)
}

calcWeights <-
    function(intGridList, controlVar, ParEst, UnobsPosInfo, DistDisasters)
{
    countryToUse   <- controlVar$countryToUse

    onePerPermDis  <- controlVar$onePerPermDis

    nSdTheta       <- controlVar$nSdTheta
    nSdPhi         <- controlVar$nSdPhi
    fracCutOffTheta<- pnorm(-nSdTheta)
    fracCutOffPhi  <- pnorm(-nSdPhi)

    intGridEps     <- intGridList$gridEps
    intGridEta     <- intGridList$gridEta
    intGridTheta   <- intGridList$gridTheta
    intGridPhi     <- intGridList$gridPhi
    intGridNu      <- intGridList$gridNu
    
    nIntGridEps    <- length(intGridEps)
    nIntGridEta    <- length(intGridEta)
    nIntGridTheta  <- length(intGridTheta)
    nIntGridPhi    <- length(intGridPhi)
    nIntGridNu     <- length(intGridNu)
        
    tempGridEps    <- intGridList$tempGridEps
    tempGridEta    <- intGridList$tempGridEta
    tempGridTheta  <- intGridList$tempGridTheta
    tempGridPhi    <- intGridList$tempGridPhi
    tempGridNu     <- intGridList$tempGridNu

    nTempGridEps    <- length(tempGridEps)
    nTempGridEta    <- length(tempGridEta)
    nTempGridTheta  <- length(tempGridTheta)
    nTempGridPhi    <- length(tempGridPhi)
    nTempGridNu     <- length(tempGridNu)
    
    mu             <- ParEst[UnobsPosInfo$muPost][countryToUse]
    sigmaEps       <- ParEst[UnobsPosInfo$sigmaEps][countryToUse]
    sigmaEta       <- ParEst[UnobsPosInfo$sigmaEta][countryToUse]
    meanPhi        <- ParEst[UnobsPosInfo$meanPhi]
    sigmaPhi       <- ParEst[UnobsPosInfo$sigmaPhi]
    meanTheta      <- ParEst[UnobsPosInfo$meanTheta]
    sigmaTheta     <- ParEst[UnobsPosInfo$sigmaTheta]
    rhoZZ          <- ParEst[UnobsPosInfo$rho]
    sigmaNu        <- ParEst[UnobsPosInfo$sigmaNu][countryToUse]
    
    # Weights over Eps
    if (nIntGridEps == 1) {
        wEps <- 1
    } else {
        wEps <- (pnorm(tempGridEps[2:nTempGridEps], numeric(nTempGridEps-1), rep(sigmaEps,nIntGridEps)) 
                 - pnorm(tempGridEps[1:nTempGridEps-1], numeric(nTempGridEps-1), rep(sigmaEps,nIntGridEps)) )
        lowTailEps        <- pnorm(tempGridEps[1], 0, sigmaEps)
        highTailEps       <-  1- pnorm(tempGridEps[nTempGridEps], 0, sigmaEps)
        wEps[1]           <- wEps[1] + lowTailEps
        wEps[nIntGridEps] <- wEps[nIntGridEps] + highTailEps 
    }
    
    # Weights over Eta
    if (nIntGridEta == 1) {
        wEta <- 1
    } else {
        wEta <- (pnorm(tempGridEta[2:nTempGridEta], numeric(nTempGridEta-1), rep(sigmaEta,nIntGridEta)) 
                 - pnorm(tempGridEta[1:nTempGridEta-1], numeric(nTempGridEta-1), rep(sigmaEta,nIntGridEta)) )
        lowTailEta        <- pnorm(tempGridEta[1], 0, sigmaEta)
        highTailEta       <-  1- pnorm(tempGridEta[nTempGridEta], 0, sigmaEta)
        wEta[1]           <- wEta[1] + lowTailEta
        wEta[nIntGridEta] <- wEta[nIntGridEta] + highTailEta
    }
    
    # Weights over Theta
    if (nIntGridTheta == 1) {
        wTheta <- 1
    } else if (!onePerPermDis) {
        wTheta <- (pnorm(tempGridTheta[2:nTempGridTheta], rep(meanTheta,nIntGridTheta), rep(sigmaTheta,nIntGridTheta)) 
                 - pnorm(tempGridTheta[1:nTempGridTheta-1], rep(meanTheta,nIntGridTheta), rep(sigmaTheta,nIntGridTheta)) )
        lowTailTheta        <- pnorm(tempGridTheta[1], meanTheta, sigmaTheta)
        highTailTheta       <-  1- pnorm(tempGridTheta[nTempGridTheta], meanTheta, sigmaTheta)
        wTheta[1]           <- wTheta[1] + lowTailTheta
        wTheta[nIntGridTheta] <- wTheta[nIntGridTheta] + highTailTheta
    } else {
        # Weights if we use getSimpleSequence to get grid
        if (onePerPermDis) {
            wTheta <- getWeightsSimpleSequence(DistDisasters$DistDropPeakTrough, tempGridTheta)
        }
        # Weights if we use getDistQuantiles to get grid
        #wTheta    <- numeric(nIntGridTheta) + (1-2*fracCutOffTheta)/nIntGridTheta
        #wTheta[1] <- wTheta[1] + fracCutOffTheta 
        #wTheta[nIntGridTheta] <- wTheta[nIntGridTheta] + fracCutOffTheta
    } 
    
    # Weights over Phi
    if (nIntGridPhi == 1) {
        wPhi <- 1
    } else {
        wPhi <- (ptnorm(tempGridPhi[2:nTempGridPhi], rep(meanPhi,nIntGridPhi), rep(sigmaPhi,nIntGridPhi),-1000, 0) 
                 - ptnorm(tempGridPhi[1:nTempGridPhi-1], rep(meanPhi,nIntGridPhi), rep(sigmaPhi,nIntGridPhi),-1000,0) )
        lowTailPhi        <- ptnorm(tempGridPhi[1], meanPhi, sigmaPhi,-1000,0)
        highTailPhi       <-  1- ptnorm(tempGridPhi[nTempGridPhi], meanPhi, sigmaPhi,-1000,0)
        wPhi[1]           <- wPhi[1] + lowTailPhi
        wPhi[nIntGridPhi] <- wPhi[nIntGridPhi] + highTailPhi
    } 

    # Weights over Nu
    if (nIntGridNu == 1) {
        wNu <- 1
    } else {
        wNu <- (pnorm(tempGridNu[2:nTempGridNu], numeric(nTempGridNu-1), rep(sigmaNu,nIntGridNu)) 
                 - pnorm(tempGridNu[1:nTempGridNu-1], numeric(nTempGridNu-1), rep(sigmaNu,nIntGridNu)) )
        lowTailNu        <- pnorm(tempGridNu[1], 0, sigmaNu)
        highTailNu       <-  1- pnorm(tempGridNu[nTempGridNu], 0, sigmaNu)
        wNu[1]           <- wNu[1] + lowTailNu
        wNu[nIntGridNu] <- wNu[nIntGridNu] + highTailNu   
    }
        
    #Create weights for all states
    weightsOverIntGrid <- kronecker(wEta, wEps)
    weightsOverIntGrid <- kronecker(wTheta, weightsOverIntGrid)
    weightsOverIntGrid <- kronecker(wPhi, weightsOverIntGrid)
    weightsOverIntGrid <- kronecker(wNu, weightsOverIntGrid)
    
    return(weightsOverIntGrid)
}

## Create PDivEqNextIntFunc
#####################################################################

PDivIntFuncGen <-
    function(stateGridList, intGridList, weightsOverIntGrid, controlVar, ParEst, UnobsPosInfo)
{
    countryToUse <- controlVar$countryToUse
    
    EpsOnIntGrid   <- intGridList$intGrid[,1]
    EtaOnIntGrid   <- intGridList$intGrid[,2]
    ThetaOnIntGrid <- intGridList$intGrid[,3]
    PhiOnIntGrid   <- intGridList$intGrid[,4]
    NuOnIntGrid    <- intGridList$intGrid[,5]
        
    mu             <- ParEst[UnobsPosInfo$muPost][countryToUse]
    pWb            <- ParEst[UnobsPosInfo$ppW][1]
    pCb_NWD        <- ParEst[UnobsPosInfo$ppC][1]
    pCe            <- 1 - ParEst[UnobsPosInfo$ppC][2]
    pCb_WD         <- ParEst[UnobsPosInfo$ppC][3]
    rhoZZ          <- ParEst[UnobsPosInfo$rho]
    
    rhoU           <- controlVar$rhoU
    gammaU         <- controlVar$gammaU
    psiU           <- controlVar$psiU
    thetaU         <- controlVar$thetaU
    
    payGrowth      <- controlVar$payGrowth
    pDefaultLong   <- controlVar$pDefaultLong
    pDefaultShort  <- controlVar$pDefaultShort
    debtEqRatio    <- controlVar$debtEqRatio
        
    PDivEqIntFunc <-
        function(currentState, nextPDivVecDis, nextPDivVecNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) 
                        * (1 + exp(nextPDivVecNoDis))^thetaU)
                
        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + ThetaOnIntGrid + PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDis   <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) 
                        * (1 + exp(nextPDivVecDis))^thetaU)
                
        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis

        #Do the numerical integration
        PDiv        <- (weightsOverIntGrid %*% (intValNoDis * pNoDis + intValDis * pDis))^(1/thetaU)
        PDiv        <- log(PDiv)
                
        return(PDiv)
    }
    
    PDivOnePerBondIntFunc <-
        function(currentState, curPDivEq, nextPDivEqDis, nextPDivEqNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU)  )

        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + ThetaOnIntGrid + PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDisND <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqDis))^(-1+thetaU)  )       
        intValDisD  <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) 
                        * exp(curPDivEq)^(-thetaU) * (1 + exp(nextPDivEqDis))^thetaU)     
        
        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis
        
        #Do the numerical integration
        
        Num         <- weightsOverIntGrid %*% (intValNoDis * pNoDis + (1-pDefaultShort) * intValDisND * pDis)
        Denom       <- 1 - weightsOverIntGrid %*% (pDefaultShort * intValDisD * pDis)
        PDiv        <- Num/Denom
        PDiv        <- log(PDiv)
        
        return(PDiv)
    }

    PDivPerpetuityIntFunc <-
        function(currentState, curPDivEq, nextPDivEqDis, nextPDivEqNoDis, nextPDivPerpDis, 
                 nextPDivPerpNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU)
                         * payGrowth * (1 + exp(nextPDivPerpNoDis)) )

        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + ThetaOnIntGrid + PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDisND <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqDis))^(-1+thetaU) 
                         * payGrowth * (1 + exp(nextPDivPerpDis)) )
        intValDisD  <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) 
                        * exp(curPDivEq)^(-thetaU) * (1 + exp(nextPDivEqDis))^thetaU)


        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis
        
        #Do the numerical integration
        Num         <- weightsOverIntGrid %*% (intValNoDis * pNoDis + (1-pDefaultLong) * intValDisND * pDis)
        Denom       <- 1 - weightsOverIntGrid %*% (pDefaultLong * intValDisD * pDis)
        PDiv        <- Num/Denom
        PDiv        <- log(PDiv)
        
        return(PDiv)
    }
   
    PDivScaledEqIntFunc <-
        function(currentState, curPDivEq, nextPDivEqDis, nextPDivEqNoDis, nextPDivScaEqDis, 
                 nextPDivScaEqNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)+(1+debtEqRatio)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU)
                         * (1 + exp(nextPDivScaEqNoDis)) )

        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + ThetaOnIntGrid + PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDis   <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)+(1+debtEqRatio)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqDis))^(-1+thetaU)
                         * (1 + exp(nextPDivScaEqDis)) )

        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis

        #Do the numerical integration
        PDiv        <- weightsOverIntGrid %*% (intValNoDis * pNoDis + intValDis * pDis)
        PDiv        <- log(PDiv)

        return(PDiv)
    }

    PDivOPEquityIntFunc <-
        function(currentState, curPDivEq, nextPDivEqDis, nextPDivEqNoDis, nextPDivScaEqDis, 
                 nextPDivScaEqNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU+thetaU) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU) )

        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + ThetaOnIntGrid + PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDis   <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU+thetaU) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU) )

        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis

        #Do the numerical integration
        PDiv        <- weightsOverIntGrid %*% (intValNoDis * pNoDis + intValDis * pDis)
        PDiv        <- log(PDiv)

        return(PDiv)
    }
    
    return(list(PDivEqIntFunc = PDivEqIntFunc, PDivOnePerBondIntFunc = PDivOnePerBondIntFunc, 
                PDivPerpetuityIntFunc = PDivPerpetuityIntFunc, PDivScaledEqIntFunc = PDivScaledEqIntFunc, 
                PDivOPEquityIntFunc = PDivOPEquityIntFunc))
}

# Calculate P-Div Ratio for Equity for Each Value on State Grid
################################################################################################

getPDivs_EZW <-
    function(controlVar, ParEst, UnobsPosInfo, DistDisasters, printStuff = 1)
{                
    #Create State Grid
    stateGridList          <- createStateGrid(controlVar, ParEst, UnobsPosInfo, DistDisasters)
    stateGrid              <- stateGridList$stateGrid
    
    #Create Integration grid
    intGridList            <- createIntGrid(controlVar, ParEst, UnobsPosInfo, DistDisasters)
    intGrid                <- intGridList$intGrid
    
    # Generate nextStateFunc
    #nextStateFunc         <- nextStateFuncGen(stateGridList, intGridList, ParEst, UnobsPosInfo)
    nextStateFuncGenAndSave(stateGridList, intGridList, controlVar, ParEst, UnobsPosInfo)

    # Calculate weights over intGrid
    weightsOverIntGrid     <- calcWeights(intGridList, controlVar, ParEst, UnobsPosInfo, DistDisasters)
    
    # Genernate PDivNextIntFuncGens    
    PDivIntFunc            <- PDivIntFuncGen(stateGridList, intGridList, weightsOverIntGrid, 
                                             controlVar, ParEst, UnobsPosInfo)
    PDivEqIntFunc          <- PDivIntFunc$PDivEqIntFunc
    PDivOnePerBondIntFunc  <- PDivIntFunc$PDivOnePerBondIntFunc
    PDivPerpetuityIntFunc  <- PDivIntFunc$PDivPerpetuityIntFunc
    PDivScaledEqIntFunc    <- PDivIntFunc$PDivScaledEqIntFunc
    PDivOPEquityIntFunc    <- PDivIntFunc$PDivOPEquityIntFunc

    #### Equity ####       
    PDivVec    <- numeric(dim(stateGrid)[1]) + controlVar$initPDivEq
    PDivVecOld <- PDivVec
    
    if (printStuff) cat('Calculating P-Div Ratio for Equity\n')
    timer2 <- proc.time()[3]
    
    nIter <- 0
    maxDiff <- 2*controlVar$tolIntEq    
    while (maxDiff > controlVar$tolIntEq & nIter < controlVar$maxIter & maxDiff < 10^5) {
        
        #cat(maxDiff, ' ', controlVar$tolIntEq, ' ', nIter, ' ', controlVar$maxIter,' \n')
        
        timer1 <- proc.time()[3]        
        for (ii in 1:length(PDivVec)) {

            currentState <- stateGrid[ii,]

            filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
            load(filename)

            nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
            nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]
            
            #nextPDivVecDis   <- PDivVec[nextState$nextStateDis]
            #nextPDivVecNoDis <- PDivVec[nextState$nextStateNoDis]
            
            PDivVec[ii] <- PDivEqIntFunc(currentState, nextPDivVecDis, nextPDivVecNoDis)

        }
        
        maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
        PDivVecOld  <- PDivVec
        nIter       <- nIter + 1
        
        timer1 <- proc.time()[3] - timer1
        if (printStuff) {
            cat(timer1,' ')
            if (nIter %% 10 == 0) cat('\n')
        }
        
        
    }
    if (printStuff) {
        cat('\n')
        timer2 <- proc.time()[3] - timer2
        cat('Total Time Int Equity: ', timer2, '\n')
        cat('Number of Iterations:  ', nIter,'\n')
        cat('sup norm:              ', maxDiff,'\n')
    }
    if (nIter == controlVar$maxIter) {
        cat('\n')
        cat('#########################################\n')
        cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
        cat('#########################################\n')
        cat('\n')
    }
    if (maxDiff > 10^5) {
        cat('\n')
        cat('############################\n')
        cat('#### EQUITY DIVERGED #######\n')
        cat('############################\n')
        cat('\n')
    }
        
    output <- list(Equity = PDivVec)

    if (maxDiff < 10^5) {
    
        #### One Period Bond ####
        if (controlVar$getOnePerBond == 1) {        
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for a One Period Bond\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVar$tolIntBond
            while (maxDiff > controlVar$tolIntBond & nIter < controlVar$maxIter) {

                timer1 <- proc.time()[3]        
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEqDis   <- output$Equity[nextState$nextStateDis]
                    nextPDivEqNoDis <- output$Equity[nextState$nextStateNoDis]

                    PDivVec[ii] <- PDivOnePerBondIntFunc(currentState, output$Equity[ii], 
                                                         nextPDivEqDis, nextPDivEqNoDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int OnePerBond: ', timer2, '\n')
                cat('Number of Iterations:      ', nIter,'\n')
                cat('sup norm:                  ', maxDiff,'\n')
            }

            output$OnePerBond <- PDivVec
        }    

        #### Perpetuity ####
        if (controlVar$getPerpetuity == 1) {        
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for a Perpetuity\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVar$tolIntPerp
            while (maxDiff > controlVar$tolIntPerp & nIter < controlVar$maxIter) {

                timer1 <- proc.time()[3]        
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEqDis   <- output$Equity[nextState$nextStateDis]
                    nextPDivEqNoDis <- output$Equity[nextState$nextStateNoDis]

                    nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
                    nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]

                    PDivVec[ii] <- PDivPerpetuityIntFunc(currentState, output$Equity[ii], 
                                                         nextPDivEqDis, nextPDivEqNoDis,
                                                         nextPDivVecDis, nextPDivVecNoDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int Perpetuity: ', timer2, '\n')
                cat('Number of Iterations:      ', nIter,'\n')
                cat('sup norm:                  ', maxDiff,'\n')
            }
            if (nIter == controlVar$maxIter) {
                cat('#########################################\n')
                cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
                cat('#########################################\n')
            }

            output$Perpetuity <- PDivVec
        }    

        #### Scaled Equity ####
        if (controlVar$getScaledEq == 1) {        
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for Scaled Equity\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVar$tolIntScaEq
            while (maxDiff > controlVar$tolIntScaEq & nIter < controlVar$maxIter) {

                timer1 <- proc.time()[3]        
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEqDis   <- output$Equity[nextState$nextStateDis]
                    nextPDivEqNoDis <- output$Equity[nextState$nextStateNoDis]

                    nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
                    nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]

                    PDivVec[ii] <- PDivScaledEqIntFunc(currentState, output$Equity[ii], 
                                                       nextPDivEqDis, nextPDivEqNoDis,
                                                       nextPDivVecDis, nextPDivVecNoDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int Scaled Eq:    ', timer2, '\n')
                cat('Number of Iterations:        ', nIter,'\n')
                cat('sup norm:                    ', maxDiff,'\n')
            }
            if (nIter == controlVar$maxIter) {
                cat('#########################################\n')
                cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
                cat('#########################################\n')
            }

            output$ScaledEq <- PDivVec
        }    

        #### One Period Equity ####
        if (controlVar$getOPEquity == 1) {        
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for One Period Equity\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVar$tolIntOPEq
            while (maxDiff > controlVar$tolIntOPEq & nIter < controlVar$maxIter) {

                timer1 <- proc.time()[3]        
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEqDis   <- output$Equity[nextState$nextStateDis]
                    nextPDivEqNoDis <- output$Equity[nextState$nextStateNoDis]

                    nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
                    nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]

                    PDivVec[ii] <- PDivOPEquityIntFunc(currentState, output$Equity[ii], 
                                                       nextPDivEqDis, nextPDivEqNoDis,
                                                       nextPDivVecDis, nextPDivVecNoDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int One Period Eq:', timer2, '\n')
                cat('Number of Iterations:        ', nIter,'\n')
                cat('sup norm:                    ', maxDiff,'\n')
            }
            if (nIter == controlVar$maxIter) {
                cat('#########################################\n')
                cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
                cat('#########################################\n')
            }

            output$OPEquity <- PDivVec
        }    

    }
     
    return(output)     
}

# Calculate Return on Equity Using Simulated Data From Model
#####################################################################

calcReturns <- 
    function(simOutput, simOutputOnGrid, PDivs, controlVar, ParEst, UnobsPosInfo, DistDisasters, printTime = 1)
{    
    timer1 <- proc.time()[3]
        
    stateGridList <- createStateGrid(controlVar, ParEst, UnobsPosInfo, DistDisasters)
    gridEps       <- stateGridList$gridEps
    gridZZ        <- stateGridList$gridZZ
    gridII        <- stateGridList$gridII
    
    nGridEps      <- length(gridEps)
    nGridZZ       <- length(gridZZ)
    nGridII       <- length(gridII)
    
    payGrowth     <- controlVar$payGrowth
    debtEqRatio   <- controlVar$debtEqRatio
    
    CC   <- simOutput$CC
    Eps  <- simOutputOnGrid$Eps
    ZZ   <- simOutputOnGrid$ZZ
    II   <- simOutputOnGrid$II
    
    nSim <- length(CC)
    
    BB <- debtEqRatio/(1+debtEqRatio)
    
    getCurPos <- 
        function(Eps, ZZ, II)
    {
        curEps <- which(Eps[1] == gridEps)
        curZZ  <- which(ZZ[1] == gridZZ)
        curII  <- which(II[1] == gridII)
        curPos <- (curII - 1)*nGridEps*nGridZZ + (curZZ - 1)*nGridEps + curEps        
        return(curPos)
    }

    REq       <- numeric(nSim)
    PDivEq    <- numeric(nSim)
    PDivEqOld <- exp(PDivs$Equity[getCurPos(Eps[1],ZZ[1],II[1])])
    PDivEq[1] <- PDivEqOld
    CGrowth   <- numeric(nSim)
    if (controlVar$getOnePerBond == 1) {
        RBond       <- numeric(nSim)
        PDivBond    <- numeric(nSim)
        PDivBondOld <- exp(PDivs$OnePerBond[getCurPos(Eps[1],ZZ[1],II[1])])
        PDivBond[1] <- PDivBondOld
    }
    if (controlVar$getPerpetuity == 1) {
        RPerp       <- numeric(nSim)
        PDivPerp    <- numeric(nSim)
        PDivPerpOld <- exp(PDivs$Perpetuity[getCurPos(Eps[1],ZZ[1],II[1])])
        PDivPerp[1] <- PDivPerpOld
    }
    if (controlVar$getScaledEq == 1) {
        RScaEq       <- numeric(nSim)
        PDivScaEq    <- numeric(nSim)
        PDivScaEqOld <- exp(PDivs$ScaledEq[getCurPos(Eps[1],ZZ[1],II[1])])
        PDivScaEq[1] <- PDivScaEqOld
    }
    if (controlVar$getOPEquity == 1) {
        ROPEq        <- numeric(nSim)
        PDivOPEq     <- numeric(nSim)
        PDivOPEqOld  <- exp(PDivs$OPEquity[getCurPos(Eps[1],ZZ[1],II[1])])
        PDivOPEq[1]  <- PDivOPEqOld
    }

    
    for (ii in 2:nSim) {
        PDivEqCur  <- exp(PDivs$Equity[getCurPos(Eps[ii],ZZ[ii],II[ii])])        
        REq[ii]    <- exp(CC[ii] - CC[ii-1])*PDivEqOld^(-1)*(1+PDivEqCur)
        PDivEq[ii] <- PDivEqCur
        PDivEqOld  <- PDivEqCur
        CGrowth[ii]<- exp(CC[ii] - CC[ii-1])
        if (controlVar$getOnePerBond == 1) {
            PDivBondCur  <- exp(PDivs$OnePerBond[getCurPos(Eps[ii],ZZ[ii],II[ii])])
            RBond[ii]    <- PDivBondOld^(-1)
            PDivBond[ii] <- PDivBondCur
            PDivBondOld  <- PDivBondCur
        }
        if (controlVar$getPerpetuity == 1) {
            PDivPerpCur  <- exp(PDivs$Perpetuity[getCurPos(Eps[ii],ZZ[ii],II[ii])])
            RPerp[ii]    <- payGrowth*PDivPerpOld^(-1)*(1+PDivPerpCur)
            PDivPerp[ii] <- PDivPerpCur
            PDivPerpOld  <- PDivPerpCur
        }
        if (controlVar$getScaledEq == 1) {
            PDivScaEqCur  <- exp(PDivs$ScaledEq[getCurPos(Eps[ii],ZZ[ii],II[ii])])
            RScaEq[ii]    <- exp((1+debtEqRatio)*(CC[ii] - CC[ii-1]))*PDivScaEqOld^(-1)*(1+PDivScaEqCur)
            PDivScaEq[ii] <- PDivScaEqCur
            PDivScaEqOld  <- PDivScaEqCur
        }
        if (controlVar$getOPEquity == 1) {
            PDivOPEqCur   <- exp(PDivs$OPEquity[getCurPos(Eps[ii],ZZ[ii],II[ii])])
            #ROPEq[ii]     <- exp((CC[ii] - CC[ii-1]))*PDivOPEqOld^(-1)
            ROPEq[ii]     <- PDivOPEqOld^(-1)
            PDivOPEq[ii]  <- PDivOPEqCur
            PDivOPEqOld   <- PDivOPEqCur
        }
    }
    
    output <- list(Equity = list(Return = c(NA,REq[2:length(REq)]), PDiv = PDivEq), CGrowth = CGrowth)
    if (controlVar$getOnePerBond == 1) {
        output$OnePerBond <- list(Return = c(NA,RBond[2:length(RBond)]), PDiv = PDivBond)
    } 
    if (controlVar$getPerpetuity == 1) {
        output$Perpetuity <- list(Return = c(NA,RPerp[2:length(RPerp)]), PDiv = PDivPerp)
    } 
    if (controlVar$getScaledEq == 1) {
        output$ScaledEq <- list(Return = c(NA,RScaEq[2:length(RScaEq)]), PDiv = PDivScaEq)
    } 
    if (controlVar$getOPEquity == 1) {
        output$OPEquity <- list(Return = c(NA,ROPEq[2:length(ROPEq)]), PDiv = PDivOPEq)
    } 


    timer1 <- proc.time()[3] - timer1
    if (printTime) {
        cat('Time Calc Returns:   ',timer1,'\n')
    }

    return(output)
}

## Simulate the Model
######################################################################

simulateModel_EZW <-
    function(controlVarAP, ParEstimates, UnobsPosInfo, DistDisasters, NoDisasters = 0, printStuff = 1)
{
    timer1 <- proc.time()[3]
    
    nSim         <- controlVarAP$nSim
    nSimBurnin   <- controlVarAP$nSimBurnin
    countryToUse <- controlVarAP$countryToUse
    
    onePerPermDis  <- controlVarAP$onePerPermDis
    
    simOutput  <- list(NULL)
    
    #Get parameters
    paramNames <- c("meanPhi", "meanTheta", "muMid", "muPost", "muPre", "ppC", "ppW", "rho", "rhobeta", 
                    "sigmaEps", "sigmaEpsPre", "sigmaEta", "sigmaEtaPre", "sigmaNu", "sigmaPhi", 
                    "sigmaTheta")                
    for (ii in 1:length(paramNames)) {
        eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
        eval(parse(text = paste('simOutput$',paramNames[ii],'<-',paramNames[ii], sep='')))
    }
    utilityParamNames <- c("gammaU", "rhoU")
    for (ii in 1:length(utilityParamNames)){
        eval(parse(text = paste(utilityParamNames[ii],'<- controlVarAP$',utilityParamNames[ii], sep='')))
        eval(parse(text = paste('simOutput$',utilityParamNames[ii],'<-',utilityParamNames[ii], sep='')))
    }    
    
    if (onePerPermDis) {
        ThetaDist      <- DistDisasters$DistDropPeakTrough
    }
    
    # Initialize variables
    II      <- numeric(nSim+nSimBurnin)
    IIWorld <- numeric(nSim+nSimBurnin)
    XX      <- numeric(nSim+nSimBurnin)
    ZZ      <- numeric(nSim+nSimBurnin)
    Eps     <- numeric(nSim+nSimBurnin)
    CC      <- numeric(nSim+nSimBurnin)
    Eta     <- numeric(nSim+nSimBurnin)
    Phi     <- numeric(nSim+nSimBurnin)
    Theta   <- numeric(nSim+nSimBurnin)
    Nu      <- numeric(nSim+nSimBurnin)
    
    ## Set initial values
    XX[1]      <- 1
    CC[1]  <- XX[1] + ZZ[1] + Eps[1]
     
    ## Simulate model
    numDis <- 1
    for (ii in 2:(nSim+nSimBurnin)) {
        IIWorld[ii] <- rbinom(1,1,ppW)
        if (II[ii-1] == 1) {
            temppp <- ppC[2]
        } else if (IIWorld[ii] == 1) {
            temppp <- ppC[3]
        } else {
            temppp <- ppC[1]
        }
        if (NoDisasters) {
            II[ii]    <- 0
        } else {
            II[ii]    <- rbinom(1,1,temppp)
        }
        if (II[ii]) {
            if (!onePerPermDis) {
                Theta[ii] <- rnorm(1,meanTheta,sigmaTheta)
            } else {
                #jj <- numDis %% length(ThetaDist)
                #Theta[ii] <- ThetaDist[jj] - muPost[countryToUse]
                #numDis <- numDis + 1
                tempXX    <- runif(1)
                tempXX    <- max(1,round(tempXX*length(ThetaDist)))            
                Theta[ii] <- ThetaDist[tempXX]
            }
        }
        Phi[ii]   <- rtnorm(1,meanPhi,sigmaPhi,-1000,0)
        Eps[ii]   <- rnorm(1,0,sigmaEps[countryToUse]) 
        Eta[ii]   <- rnorm(1,0,sigmaEta[countryToUse])
        Nu[ii]    <- rnorm(1,0,sigmaNu[countryToUse]) 
        XX[ii]    <- XX[ii-1] + muPost[countryToUse] + Eta[ii] + Theta[ii]*II[ii]
        ZZ[ii]    <- rho*ZZ[ii-1] + Nu[ii] + Phi[ii]*II[ii]
        CC[ii]    <- XX[ii] + ZZ[ii] + Eps[ii]
    }
    
    simOutput$IIWorld <- IIWorld[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$II      <- II[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Eps     <- Eps[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Eta     <- Eta[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Theta   <- Theta[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Phi     <- Phi[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Nu      <- Nu[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$XX      <- XX[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$ZZ      <- ZZ[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$CC      <- CC[(nSimBurnin+1):(nSim+nSimBurnin)]
    
    timer1 <- proc.time()[3] - timer1
    if (printStuff) {
        cat('nSim:                  ',nSim,'\n')    
        cat('time simulation =      ',timer1,'\n')
    }
    
    return(simOutput)
}

## Put Simulated Output on Grid
#####################################################################

putSimOutputOnStateGrid <-
    function(simOutput, controlVar, ParEst, UnobsPosInfo, DistDisasters, printTime = 1)
{   
    timer1 <- proc.time()[3]

    ZZ  <- simOutput$ZZ
    Eps <- simOutput$Eps
    
    nSim <- length(ZZ)
    
    ZZOnGrid  <- numeric(nSim)
    EpsOnGrid <- numeric(nSim)
        
    stateGridList <- createStateGrid(controlVar, ParEst, UnobsPosInfo, DistDisasters)
    stateGridEps <- stateGridList$gridEps
    stateGridZZ  <- stateGridList$gridZZ
    
    for (ii in 1:nSim) {
        EpsInd <- which.min(abs(stateGridEps-Eps[ii]))
        EpsOnGrid[ii] <- stateGridEps[EpsInd]
        ZZInd  <- which.min(abs(stateGridZZ-ZZ[ii]))
        ZZOnGrid[ii] <- stateGridZZ[ZZInd]
    }

    timer1 <- proc.time()[3] - timer1
    if (printTime) {
        cat('Time Put Sim on Grid:  ',timer1,'\n')
    }
    
    return(list(Eps = EpsOnGrid, ZZ = ZZOnGrid, II = simOutput$II))
}

## Save Consumption and Asset Returns in a Text File
#####################################################################

saveCAndAPReturnsInTextFile <-
    function(simOutput, returnsEZW)
{    
    lengthReturnsEZW <- length(returnsEZW)
    temp.output <- cbind(simOutput$CC, simOutput$II, returnsEZW$Equity$Return, returnsEZW$Equity$PDiv)
    dimnames(temp.output)[[2]] <- c('CC', 'II', 'EquityR', 'EquityPDiv')
    
    if (lengthReturnsEZW > 2) {
        for (ii in 3:lengthReturnsEZW) {
            temp.output <- cbind(temp.output, returnsEZW[[ii]][[1]],returnsEZW[[ii]][[2]])
            dimnames(temp.output)[[2]][4+2*(ii-3)+1] <- paste(names(returnsEZW[ii]),'R', sep='')
            dimnames(temp.output)[[2]][4+2*(ii-3)+2] <- paste(names(returnsEZW[ii]),'PDiv', sep='')
        }
    }
    filename <-  file.path(outDir, 'CAndAPReturns.txt')  
    write.table(temp.output, file = filename)
    
    return(temp.output)
}


## Simulate a "Typical Disaster"
#####################################################################

simulateTypicalDisaster <-
    function(controlVarAP, ParEstimates, UnobsPosInfo, DistDisasters)
{    
    nPrePeriods  <- controlVarAP$nPrePeriods
    nDisPeriods  <- controlVarAP$nDisPeriods
    nPostPeriods <- controlVarAP$nPostPeriods
    
    countryToUse <- controlVarAP$countryToUse
    
    onePerPermDis    <- controlVarAP$onePerPermDis
    
    simOutput  <- list(NULL)
    
    #Get parameters
    paramNames <- c("meanPhi", "meanTheta", "muMid", "muPost", "muPre", "ppC", "ppW", "rho", "rhobeta", 
                    "sigmaEps", "sigmaEpsPre", "sigmaEta", "sigmaEtaPre", "sigmaNu", "sigmaPhi", 
                    "sigmaTheta")                
    for (ii in 1:length(paramNames)) {
        eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
        eval(parse(text = paste('simOutput$',paramNames[ii],'<-',paramNames[ii], sep='')))
    }
    utilityParamNames <- c("gammaU", "rhoU")
    for (ii in 1:length(utilityParamNames)){
        eval(parse(text = paste(utilityParamNames[ii],'<- controlVarAP$',utilityParamNames[ii], sep='')))
        eval(parse(text = paste('simOutput$',utilityParamNames[ii],'<-',utilityParamNames[ii], sep='')))
    }    

    uu <- 0
    ll <- -1000        
    meanPhiStar  <- meanPhi + ((dnorm((ll-meanPhi)/sigmaPhi) - dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))*sigmaPhi
    
    # Initialize variables
    II    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    XX    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    ZZ    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Eps   <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    CC    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Eta   <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Phi   <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Theta <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Nu    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)

    if (onePerPermDis) {
        ThetaDist      <- DistDisasters$DistDropPeakTrough
        PhiDist        <- DistDisasters$DistDropPeakTrough
    }
    
    ## Set initial values
    XX[1]  <- 1
    CC[1]  <- XX[1] + ZZ[1] + Eps[1]
    
    ## Simulate Pre Period
    for (ii in 2:nPrePeriods) {
        XX[ii] <- XX[ii-1] + muPost[countryToUse]
        CC[ii]  <- XX[ii] + ZZ[ii] + Eps[ii]    
    }
    
    ## Simulate Disaster Periods
    for (ii in (nPrePeriods+1):(nPrePeriods+nDisPeriods)) {
        II[ii]    <- 1
        if (!onePerPermDis) {
            Theta[ii] <- meanTheta
        } else {
            Theta[ii] <- mean(ThetaDist)
        }
        Phi[ii]   <- meanPhiStar
        XX[ii]    <- XX[ii-1] + muPost[countryToUse] + Theta[ii]*II[ii]
        ZZ[ii]    <- rho*ZZ[ii-1] + Phi[ii]*II[ii]
        CC[ii]    <- XX[ii] + ZZ[ii]
    }

    ## Simulate Post Periods
    for (ii in (nPrePeriods+nDisPeriods+1):(nPrePeriods+nDisPeriods+nPostPeriods)) {
        XX[ii]    <- XX[ii-1] + muPost[countryToUse]
        ZZ[ii]    <- rho*ZZ[ii-1]
        CC[ii]    <- XX[ii] + ZZ[ii]
    }
    
    simOutput$II    <- II
    simOutput$Eps   <- Eps
    simOutput$Eta   <- Eta
    simOutput$Theta <- Theta
    simOutput$Phi   <- Phi
    simOutput$Nu    <- Nu
    simOutput$XX    <- XX
    simOutput$ZZ    <- ZZ
    simOutput$CC    <- CC
    
    return(simOutput)
}

## Print Results
#####################################################################

printSummaryStats <- 
    function(returnsAP, returnsAPNoDis, controlVar, Pref = 1)
{
    if (Pref == 1) {
        Pref <- 'EZW'
    } else if (Pref == 2) {
        Pref <- 'CRRA'
    } else {
        Pref <- ''
    }

    payGrowth <- controlVar$payGrowth
    
    options(digits = 5)
    nPer <- length(returnsAP$Equity$Return)
    
    # Basic Results
    cat('\n')
    cat('Asset Returns for ',Pref,' Rep Consumer\n')
    cat('Unlevered Equity: Log E[R]:  ',log(mean(returnsAP$Equity$Return[2:nPer])),'\n')
    if (controlVar$getOnePerBond == 1) {
        cat('One Per Bond: Log E[R]:      ',log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
        cat('Unlevered Equity Premium:    ',log(mean(returnsAP$Equity$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getPerpetuity == 1) {
        cat('Perpetuity: Log E[R]:        ',log(mean(returnsAP$Perpetuity$Return[2:nPer])),'\n')
        cat('Term Premium:                ',log(mean(returnsAP$Perpetuity$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getScaledEq == 1) {
        cat('Scaled Eq: Log E[R]:         ',log(mean(returnsAP$ScaledEq$Return[2:nPer])),'\n')
        cat('Scaled Equity Premium:       ',log(mean(returnsAP$ScaledEq$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
    }    
    if (controlVar$getOPEquity == 1) {
        cat('One Per Eq: Log E[R]:        ',log(mean(returnsAP$OPEquity$Return[2:nPer])),'\n')
        cat('One Per Equity Premium:      ',log(mean(returnsAP$OPEquity$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
    }    

    
    # Results Conditional on Disasters and Non-Disasters
    cat('\n')
    cat('Asset Returns for ',Pref,' Rep Consumer (Conditional on No-Disasters)\n')
    cat('Unlevered Equity: Log E[R]:  ',log(mean(returnsAPNoDis$Equity$Return[2:nPer])),'\n')
    if (controlVar$getOnePerBond == 1) {
        cat('One Per Bond: Log E[R]:      ',log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
        cat('Unlevered Equity Premium:    ',log(mean(returnsAPNoDis$Equity$Return[2:nPer])) - log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getPerpetuity == 1) {
        cat('Perpetuity: Log E[R]:        ',log(mean(returnsAPNoDis$Perpetuity$Return[2:nPer])),'\n')
        cat('Term Premium:                ',log(mean(returnsAPNoDis$Perpetuity$Return[2:nPer])) - log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getScaledEq == 1) {
        cat('Scaled Eq: Log E[R]:         ',log(mean(returnsAPNoDis$ScaledEq$Return[2:nPer])),'\n')
        cat('Scaled Equity Premium:       ',log(mean(returnsAPNoDis$ScaledEq$Return[2:nPer])) - log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getOPEquity == 1) {
        cat('One Per Eq: Log E[R]:        ',log(mean(returnsAPNoDis$OPEquity$Return[2:nPer])),'\n')
        cat('One Per Equity Premium:      ',log(mean(returnsAPNoDis$OPEquity$Return[2:nPer])) - log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
    }


    cat('\n')
    cat('Price-Dividend Ratios for       ',Pref,' Rep Consumer\n')
    cat('Unlevered Equity: P/Div:        ',mean(returnsAP$Equity$PDiv),'\n')
    if (controlVar$getOnePerBond == 1) {
        cat('One Per Bond: P/Div:             ',mean(returnsAP$OnePerBond$PDiv),'\n')
    }
    if (controlVar$getPerpetuity == 1) {
        cat('Perpetuity: P/Div:               ',mean(returnsAP$Perpetuity$PDiv),'\n')
        cat('\n')
        cat('Duration of Perpetuity (no Dis): ',payGrowth*(mean(returnsAP$Perpetuity$PDiv)+1),'\n')
    }
    if (controlVar$getScaledEq == 1) {
        cat('Scaled Equity: P/Div:            ',mean(returnsAP$ScaledEq$PDiv),'\n')
    }
    if (controlVar$getOPEquity == 1) {
        cat('One Per Equity: P/Div:           ',mean(returnsAP$OPEquity$PDiv),'\n')
    }


}

## Plot Diagnostic Plots
#####################################################################

plotDiagnostics <-
    function(simOutput, returnsEZW)
{
    nSim <- length(simOutput$CC)
    
    ii <- which.max(abs(simOutput$ZZ)) - 1
    
    ReturnsToPlot <- max(ii-25,1):min(ii+25,nSim-1)
    
    filename <-  file.path(outDir, 'DiagnosticPlots.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(returnsEZW$Equity$Return[ReturnsToPlot]), ylim = c(-1,3), 
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$Return[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()

    filename <-  file.path(outDir, 'DiagnosticPlotsPDiv.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(returnsEZW$Equity$PDiv[ReturnsToPlot]), ylim = c(-1,20), 
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$PDiv[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()
    
    ReturnsToPlot <- 200:300    
    filename <-  file.path(outDir, 'DiagnosticPlots2.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(returnsEZW$Equity$Return[ReturnsToPlot]), ylim = c(-1,3), 
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$Return[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()

    filename <-  file.path(outDir, 'DiagnosticPlots2PDiv.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(returnsEZW$Equity$PDiv[ReturnsToPlot]), ylim = c(-1,20), 
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$PDiv[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()    
}

## Plot Typical Disaster
#####################################################################

plotTypDis <-
    function(simOutput, simOutputOnGrid, returnsEZW, Pref)
{    
    CC <- simTypDis$CC        
    DCC <- CC[2] - CC[1]
    NN  <- length(CC)
    CCNoTrend <- CC
    for (ii in 2:NN) CCNoTrend[ii] = CC[ii] - (ii-1)*DCC

    filename <-  file.path(outDir, paste(c('TypDisPlot',Pref,'pdf'), collapse = '.')) 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(log(returnsEZW$Equity$Return)), ylim = c(-0.5,1), 
          main = paste('Equity and Bond Return'))
    lines(as.ts(log(returnsEZW$OnePerBond$Return)), col = 2, lty = 2)
    lines(as.ts((simOutput$II/2+1)/2), col = 4)
    lines(as.ts(CCNoTrend), col = 3)

    dev.off()

    filename <-  file.path(outDir, paste(c('TypDisPlotPDiv',Pref,'pdf'), collapse = '.')) 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    totRange <- range(returnsEZW$Equity$PDiv, simOutput$II, simOutput$ZZ)
    
    plot(as.ts(returnsEZW$Equity$PDiv), ylim = totRange, 
          main = paste('Equity PDiv'))
    lines(as.ts(simOutput$II), col = 4)
    lines(as.ts(CCNoTrend), col = 3)

    dev.off()    
}

saveTypDis <-
    function(simOutput, returnsEZW)
{       
    CC <- simOutput$CC
    ZZ <- simOutput$ZZ
    XX <- simOutput$XX
    II <- simOutput$II
    
    DCC <- CC[2] - CC[1]
    NN  <- length(CC)
    CCNoTrend <- CC
    for (ii in 2:NN) CCNoTrend[ii] = CC[ii] - (ii-1)*DCC
    
    temp.output <- cbind(CC, CCNoTrend, ZZ, XX, II, returnsEZW$Equity$Return, 
                         returnsEZW$Equity$PDiv, returnsEZW$OnePerBond$Return, returnsEZW$OnePerBond$PDiv)
    dimnames(temp.output)[[2]] <- c('CC', 'CCNoTrend', 'ZZ', 'XX', 'II', 'EqReturn', 
                                    'EqPDiv', 'BillReturn', 'BillPDiv' )
                                    
    filename <-  file.path(outDir, 'outputTypDis.txt')  
    write.table(temp.output, file = filename)
    
    return(temp.output)
}

printSummaryTypDis <- 
    function(simTypDis, returnsTypDis, controlVar)
{    
    options(digits = 5)

    firstperiod <- controlVar$nPrePeriods + 1
    
    CC <- simTypDis$CC        
    DCC <- CC[2] - CC[1]
    NN  <- length(CC)
    CCNoTrend <- CC
    for (ii in 2:NN) CCNoTrend[ii] = CC[ii] - (ii-1)*DCC
    
    # Typical Disaster
    cat('\n')
    cat('Results for a Typical Disaster\n')
    cat('Return on Equity in first period:  ',returnsTypDis$Equity$Return[firstperiod] - 1,'\n')
    cat('Change in C in first period:       ',CCNoTrend[firstperiod] - 1,'\n')

}


## Test convergence of PDiv
#####################################################################


calcTestPDiv <-
    function(controlVar, ParEst, UnobsPosInfo, DistDisasters, PDivVecOld)
{                
    #Create State Grid
    stateGridList          <- createStateGrid(controlVar, ParEst, UnobsPosInfo, DistDisasters)
    stateGrid              <- stateGridList$stateGrid

    #Create Integration grid
    intGridList            <- createIntGrid(controlVar, ParEst, UnobsPosInfo)
    intGrid                <- intGridList$intGrid
    
    # Calculate weights over intGrid
    weightsOverIntGrid     <- calcWeights(intGridList, controlVar, ParEst, UnobsPosInfo)
    
    # Genernate PDivNextIntFuncGens    
    PDivIntFunc            <- PDivIntFuncGen(stateGridList, intGridList, weightsOverIntGrid, 
                                             controlVar, ParEst, UnobsPosInfo)
    PDivEqIntFunc          <- PDivIntFunc$PDivEqIntFunc
    
    PDivVec                <- 0*PDivVecOld
    
    for (ii in 1:length(PDivVec)) {

        currentState <- stateGrid[ii,]

        filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
        load(filename)

        nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
        nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]

        PDivVec[ii] <- PDivEqIntFunc(currentState, nextPDivVecDis, nextPDivVecNoDis)

    }
    
    maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
        
    return(list(maxDiff = maxDiff, PDiv = PDivVec, PDivOld = PDivVecOld))     
}

## Calculate Equity Premium in Barro and Ursua (2008) model with our
## Peak to Trough distribution
#####################################################################

EquityPremiumBarroUrsuaFormula <- 
    function(controlVar, ParEst, bigDataPosInfo, DistDisasters)
{
    gammaU         <- controlVar$gammaU
    psiU           <- controlVar$psiU
    rhoU           <- controlVar$rhoU
    
    countryToUse <- controlVar$countryToUse
    sigmaEta       <- ParEst[bigDataPosInfo$sigmaEta][countryToUse]
    
    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    load(filename)    

    # Overall probability of entering a disaster
    bigDataPEnterOverall <- as.matrix((bigDataParams[,bigDataPosInfo$ppW]*bigDataParams[,bigDataPosInfo$ppC[3]]
                            + (1-bigDataParams[,bigDataPosInfo$ppW])*bigDataParams[,bigDataPosInfo$ppC[1]]))
    pp <- mean(bigDataPEnterOverall)
    
    mu <- ParEst[bigDataPosInfo$muPost][countryToUse]
    
    vv <- DistDisasters$DistDropPeakTrough  ## distibution of log(1-b)
    bb <- 1 - exp(vv)
    
    #bbsmall <- (bb < 0.6)
    #bb <- bb[bbsmall]
    
    #browser()
    
    gStar   <- mu + (1/2)*sigmaEta^2 - pp*mean(bb)
    rhoStar <- rhoU - (gammaU-1/psiU)*(gStar - 0.5*gammaU*sigmaEta^2 
                          - (pp/(gammaU-1))*(mean((1-bb)^(1-gammaU))-1-(gammaU-1)*mean(bb)))
    
    ## Formula in Barro and Ursua (2008)
    ## r^e - r^f = gamma*sigma^2 + pE{b[((1-b)^(-gamma)-1]}
    
    EquityPremium     <- gammaU*sigmaEta^2 + pp*mean(bb*((1-bb)^(-gammaU)-1))
    EquityReturn      <- rhoStar + gammaU*gStar - 0.5*gammaU*(gammaU-1)*sigmaEta^2 - pp*(mean((1-bb)^(1-gammaU))-1-(gammaU-1)*mean(bb))
    RiskFreeRate      <- rhoStar + gammaU*gStar - 0.5*gammaU*(gammaU+1)*sigmaEta^2 - pp*(mean((1-bb)^(-gammaU))-1-gammaU*mean(bb))
    EquityReturnNoDis <- rhoStar + gammaU*gStar - 0.5*gammaU*(gammaU-1)*sigmaEta^2 - pp*(mean((1-bb)^(1-gammaU))-1-gammaU*mean(bb))
    
    EquityPremium2     <- gammaU*sigmaEta^2 + pp*(mean((1-bb)^(-gammaU)) - mean((1-bb)^(1-gammaU)) - mean(bb))
    EquityPremium3     <- gammaU*sigmaEta^2 + log((pp+(1-pp)*(1-mean(bb)))/(pp+(1-pp)*mean((1-bb)^(1-gammaU)))) + log(pp+(1-pp)*(mean((1-bb)^(-gammaU))+mean((1-bb)^(1-gammaU)) + mean(bb)))
    
    cat('\n')
    cat('Asset Returns using Barro and Ursua (2008) formula\n')
    cat('and Peak-Trough Distribution\n')
    cat('Unlevered Equity Return:        ',EquityReturn,'\n')
    cat('Unlevered Risk Free Rate:       ',RiskFreeRate,'\n')
    cat('Unlevered Equity Premium:       ',EquityPremium,'\n')
    cat('\n')
    cat('Unlevered Equity Return NoDis:  ',EquityReturnNoDis,'\n')
    cat('Unlevered Risk Free Rate NoDis: ',RiskFreeRate,'\n')
    cat('Unlevered Equity Premium NoDis: ',EquityReturnNoDis-RiskFreeRate,'\n')    
    cat('\n')
    cat('Unlevered Equity Premium2:      ',EquityPremium2,'\n')
    cat('Unlevered Equity Premium3:      ',EquityPremium3,'\n')
    
    #browser()
    
    return(1)
}