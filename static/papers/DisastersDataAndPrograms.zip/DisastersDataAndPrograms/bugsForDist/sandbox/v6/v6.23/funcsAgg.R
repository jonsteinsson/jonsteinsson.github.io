###############################################################################
## Support functions for aggregating run from disaster model 
##
## Emi Nakamura and Jon Steinsson, July 2008
###############################################################################

getControlAgg <-
    function()
{
    createNewData <- 1
    fullPlot      <- 1    

    # Definition of disaster episode
    hiProb       <- 0.1
    totProb      <- 1

    return(list(createNewData = createNewData, fullPlot = fullPlot,
                hiProb = hiProb, totProb = totProb))
}

## Get Runs to Use in Aggregation
#####################################################################

getRunsToUse <- 
    function()
{
    XX1ToUse <- 3:50 
    XX2ToUse <- NULL 

    ZB1ToUse <- NULL 
    ZB2ToUse <- NULL 

    ZZ1ToUse <- NULL 
    ZZ2ToUse <- NULL
    
    runsToUse <- NULL
    for (ii in XX1ToUse) {
        runsToUse <- c(runsToUse, paste(c('bugsSimSave.XX1',ii,'Rda'), collapse = '.'))
    }
    for (ii in XX2ToUse) {
        runsToUse <- c(runsToUse, paste(c('bugsSimSave.XX2',ii,'Rda'), collapse = '.'))
    }
    
    for (ii in ZB1ToUse) {
        runsToUse <- c(runsToUse, paste(c('bugsSimSave.ZB1',ii,'Rda'), collapse = '.'))
    }
    for (ii in ZB2ToUse) {
        runsToUse <- c(runsToUse, paste(c('bugsSimSave.ZB2',ii,'Rda'), collapse = '.'))
    }
    
    for (ii in ZZ1ToUse) {
        runsToUse <- c(runsToUse, paste(c('bugsSimSave.ZZ1',ii,'Rda'), collapse = '.'))
    }
    for (ii in ZZ2ToUse) {
        runsToUse <- c(runsToUse, paste(c('bugsSimSave.ZZ2',ii,'Rda'), collapse = '.'))
    }

    return(runsToUse)
}

## Create and Manipulate BigData
#####################################################################

getBigDataPosInfo <-
    function(UnobsPosInfo)
{        
        nCountries <- length(UnobsPosInfo$muMid)
        bigDataPosInfo<- list(II = 1:length(UnobsPosInfo$II), IIWorld = 1:length(UnobsPosInfo$IIWorld),
                              xx = 1:length(UnobsPosInfo$xx), 
                              zz = 1:length(UnobsPosInfo$zz), phi = 1:length(UnobsPosInfo$phi), 
                              theta = 1:length(UnobsPosInfo$theta), 
                              deviance = NULL, meanPhi = NULL, meanTheta = NULL,
                              muMid = NULL, muPost = NULL, muPre = NULL,
                              ppC = NULL, ppW = NULL, rho = NULL,  
                              sigmaEps = NULL, sigmaEpsPre = NULL, sigmaEta = NULL, 
                              sigmaEtaPre = NULL, sigmaNu = NULL, sigmaPhi = NULL,
                              sigmaTheta = NULL)
        
        dimParams <- 1
        bigDataPosInfo$deviance <- dimParams
        dimParams <- dimParams + 1
        bigDataPosInfo$meanPhi <- dimParams
        dimParams <- dimParams + 1
        bigDataPosInfo$meanTheta <- dimParams
        dimParams <- dimParams + 1
        bigDataPosInfo$muMid <- dimParams:(dimParams+nCountries-1)
        dimParams <- dimParams + nCountries
        bigDataPosInfo$muPost <- dimParams:(dimParams+nCountries-1)
        dimParams <- dimParams + nCountries
        bigDataPosInfo$muPre <- dimParams:(dimParams+nCountries-1)
        dimParams <- dimParams + nCountries
        bigDataPosInfo$ppC <- dimParams:(dimParams+2)
        dimParams <- dimParams + 3
        bigDataPosInfo$ppW <- dimParams
        dimParams <- dimParams + 1
        bigDataPosInfo$rho <- dimParams
        dimParams <- dimParams + 1
        bigDataPosInfo$sigmaEps <- dimParams:(dimParams+nCountries-1)
        dimParams <- dimParams + nCountries
        bigDataPosInfo$sigmaEpsPre <- dimParams:(dimParams+nCountries-1)
        dimParams <- dimParams + nCountries
        bigDataPosInfo$sigmaEta <- dimParams:(dimParams+nCountries-1)
        dimParams <- dimParams + nCountries
        bigDataPosInfo$sigmaEtaPre <- dimParams:(dimParams+nCountries-1)
        dimParams <- dimParams + nCountries
        bigDataPosInfo$sigmaNu <- dimParams:(dimParams+nCountries-1)
        dimParams <- dimParams + nCountries
        bigDataPosInfo$sigmaPhi <- dimParams
        dimParams <- dimParams + 1
        bigDataPosInfo$sigmaTheta <- dimParams
        bigDataPosInfo$dimParams <- dimParams
        
        return(bigDataPosInfo)
}


combineRuns <- 
    function(UnobsPosInfo, bigDataPosInfo, runsToUse)
{
    nRuns         <- length(runsToUse)   

    filename <-  file.path(outDir, runsToUse[1]) 
    load(filename)
    nThin         <- max(1, (nRuns*nrow(bugsSim[[1]])) %/% 2000)
    rm(bugsSim)
    
    dimParams <- bigDataPosInfo$dimParams
    
    bigDataII      <- NULL
    bigDataIIWorld <- NULL
    bigDataXX      <- NULL
    bigDataZZ      <- NULL
    bigDataPhi     <- NULL
    bigDataTheta   <- NULL
    bigDataParams  <- NULL 
    for (ii in 1:nRuns) {
        filename <-  file.path(outDir, runsToUse[ii]) 
        load(filename)
        
        rowsToKeep <- seq(nThin,nrow(bugsSim[[1]]),by = nThin)
        
        bigDataII      <- rbind(bigDataII, matrix(bugsSim[[1]][ rowsToKeep, UnobsPosInfo$II],
                                             nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$II)))
        bigDataIIWorld <- rbind(bigDataIIWorld, matrix(bugsSim[[1]][ rowsToKeep, UnobsPosInfo$IIWorld],
                                             nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$IIWorld)))
        bigDataXX      <- rbind(bigDataXX, matrix(bugsSim[[1]][ rowsToKeep, UnobsPosInfo$xx],
                                             nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$xx)))
        bigDataZZ      <- rbind(bigDataZZ, matrix(bugsSim[[1]][ rowsToKeep, UnobsPosInfo$zz],
                                             nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$zz)))
        bigDataPhi     <- rbind(bigDataPhi, matrix(bugsSim[[1]][ rowsToKeep, UnobsPosInfo$phi],
                                             nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$phi)))
        bigDataTheta   <- rbind(bigDataTheta, matrix(bugsSim[[1]][ rowsToKeep, UnobsPosInfo$theta],
                                             nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$theta)))
        tempParams     <- matrix(0, nrow = length(rowsToKeep), ncol = dimParams)
        
        tempParams[,bigDataPosInfo$deviance]      <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$deviance]
        tempParams[,bigDataPosInfo$meanPhi]       <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$meanPhi]
        tempParams[,bigDataPosInfo$meanTheta]     <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$meanTheta]
        tempParams[,bigDataPosInfo$muMid]         <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$muMid]
        tempParams[,bigDataPosInfo$muPost]        <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$muPost]
        tempParams[,bigDataPosInfo$muPre]         <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$muPre]
        tempParams[,bigDataPosInfo$ppC]           <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$ppC]
        tempParams[,bigDataPosInfo$ppW]           <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$ppW]
        tempParams[,bigDataPosInfo$rho]           <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$rho]
        tempParams[,bigDataPosInfo$sigmaEps]      <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$sigmaEps]
        tempParams[,bigDataPosInfo$sigmaEpsPre]   <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$sigmaEpsPre]
        tempParams[,bigDataPosInfo$sigmaEta]      <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$sigmaEta]
        tempParams[,bigDataPosInfo$sigmaEtaPre]   <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$sigmaEtaPre]
        tempParams[,bigDataPosInfo$sigmaNu]       <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$sigmaNu]
        tempParams[,bigDataPosInfo$sigmaPhi]      <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$sigmaPhi]
        tempParams[,bigDataPosInfo$sigmaTheta]    <- bugsSim[[1]][ rowsToKeep, UnobsPosInfo$sigmaTheta]
        bigDataParams <- rbind(bigDataParams, tempParams)
        cat('.')
    }
    cat('\n')
       
    colnames <- c(dimnames(bugsSim[[1]][UnobsPosInfo$deviance]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$meanPhi]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$meanTheta]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$muMid]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$muPost]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$muPre]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$ppC]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$ppW]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$rho]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmEps]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmEpsPre]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmEta]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmEtaPre]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmNu]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmaPhi]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmaTheta]))
    rownames <- 1:nrow(bigDataParams)
    
    filename <-  file.path(outDir, 'bigDataII.Rda') 
    save(bigDataII,file = filename)
    filename <-  file.path(outDir, 'bigDataIIWorld.Rda') 
    save(bigDataIIWorld,file = filename)
    filename <-  file.path(outDir, 'bigDataXX.Rda') 
    save(bigDataXX,file = filename)
    filename <-  file.path(outDir, 'bigDataZZ.Rda') 
    save(bigDataZZ,file = filename)
    filename <-  file.path(outDir, 'bigDataPhi.Rda') 
    save(bigDataPhi,file = filename)
    filename <-  file.path(outDir, 'bigDataTheta.Rda') 
    save(bigDataTheta,file = filename)
    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    save(bigDataParams,file = filename)

}

## Print and Plot Multiple Runs
#######################################################################

.calcSummary2 <-
    function(bugsSim,varPosInfo = 1:(dim(bugsSim)[2]),toPower = 1, mult = 1)
{         
    bugsSim <- as.matrix((bugsSim[,varPosInfo]^toPower)*mult)
    
    nParams <- dim(bugsSim)[2]
    
    tempVar <- matrix(apply(bugsSim,2,mean),nParams,1)
    colnames(tempVar) <- "mean"
    output  <- tempVar
    tempVar <- matrix(apply(bugsSim,2,sd),nParams,1)
    colnames(tempVar) <- "sd"
    output  <- cbind(output,tempVar)
    tempVar <- matrix(apply(bugsSim,2,quantile, probs = 0.05),nParams,1)
    colnames(tempVar) <- "q05"
    output  <- cbind(output,tempVar)
    tempVar <- matrix(apply(bugsSim,2,quantile, probs = 0.25),nParams,1)
    colnames(tempVar) <- "q25"
    output  <- cbind(output,tempVar)
    tempVar <- matrix(apply(bugsSim,2,quantile, probs = 0.50),nParams,1)
    colnames(tempVar) <- "q50"
    output  <- cbind(output,tempVar)
    tempVar <- matrix(apply(bugsSim,2,quantile, probs = 0.75),nParams,1)
    colnames(tempVar) <- "q75"
    output  <- cbind(output,tempVar)
    tempVar <- matrix(apply(bugsSim,2,quantile, probs = 0.95),nParams,1)
    colnames(tempVar) <- "q95"
    output  <- cbind(output,tempVar)

    output <- cbind(matrix(toPower,dim(output)[1],1),matrix(mult,dim(output)[1],1),output)
    dimnames(output)[[2]][1] <- 'toPower'
    dimnames(output)[[2]][2] <- 'mult'
    
    return(output)
}

.momTruncNorm <-
    function(meanPhi, sigmaPhi)
{
    NN <- length(meanPhi)
    
    uu <- 0
    ll <- -1000
        
    meanPhiStar  <- meanPhi + ((dnorm((ll-meanPhi)/sigmaPhi) - dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))*sigmaPhi
    varTemp      <- sigmaPhi^2*(1+((((ll-meanPhi)/sigmaPhi)*dnorm((ll-meanPhi)/sigmaPhi) - ((uu-meanPhi)/sigmaPhi)*dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))
                                -((dnorm((ll-meanPhi)/sigmaPhi) - dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))^2)
    sigmaPhiStar <- varTemp^(1/2)
        
    return(list(meanPhiStar, sigmaPhiStar))
}

simSummaryDisasterParMulti <- 
    function(bigDataPosInfo)
{
    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    load(filename)    
    
    cat('DISASTER PARAMETERS\n') 
    bigDataPosInfoDisPar <- c(bigDataPosInfo$ppW, bigDataPosInfo$ppC, bigDataPosInfo$rho,
                            bigDataPosInfo$meanPhi, bigDataPosInfo$meanTheta,  
                            bigDataPosInfo$sigmaPhi, bigDataPosInfo$sigmaTheta)
    bigDataPosInfoDisPar3<- c(bigDataPosInfo$deviance)
    
    momPhi <- .momTruncNorm(bigDataParams[,bigDataPosInfo$meanPhi],bigDataParams[, bigDataPosInfo$sigmaPhi])
    
    # Overall probability of entering a disaster
    bigDataPEnterOverall <- as.matrix((bigDataParams[,bigDataPosInfo$ppW]*bigDataParams[,bigDataPosInfo$ppC[3]]
                            + (1-bigDataParams[,bigDataPosInfo$ppW])*bigDataParams[,bigDataPosInfo$ppC[1]]))
    
    temp.output <- rbind(.calcSummary2(bigDataPEnterOverall),
                         .calcSummary2(bigDataParams,bigDataPosInfoDisPar,1,1),
                         .calcSummary2(as.matrix(momPhi[[1]])),
                         .calcSummary2(as.matrix(momPhi[[2]])),
                         .calcSummary2(bigDataParams,bigDataPosInfoDisPar3,1,-1/2))
    rownames(temp.output) <- c('pCbA','pWb','pCb_NWD','1-pCe','pCb_WD','rho',
                               'meanPhi', 'meanTheta','sigmaPhi', 'sigmaTheta',
                               'meanPhiStar','sigmaPhiStar','LogLike')
    print(temp.output)
    filename <-  file.path(outDir, 'bigDataParamsSummary.txt')  
    write.table(temp.output, file = filename)
    cat('\n')
    
}

simSummaryCountryParMulti <-
    function(allData,bigDataPosInfo)
{
    countryNames <- allData$countryNames
    
    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    load(filename)
    
    #options(digits=8)
    
    cat('   muPre   \n')
    CountrySum <- .calcSummary2(bigDataParams,bigDataPosInfo$muPre)    
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])
    print(CountrySum)
    filename <-  file.path(outDir, 'bigDataParamsSummaryMuPre.txt')  
    write.table(.calcSummary2(bigDataParams,bigDataPosInfo$muPre), file = filename)
    cat('\n')

    cat('   muMid   \n')
    CountrySum <- .calcSummary2(bigDataParams,bigDataPosInfo$muMid)
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])
    print(CountrySum)
    filename <-  file.path(outDir, 'bigDataParamsSummaryMuMid.txt')  
    write.table(.calcSummary2(bigDataParams,bigDataPosInfo$muMid), file = filename)
    cat('\n')

    cat('   muPost   \n')
    CountrySum <- .calcSummary2(bigDataParams,bigDataPosInfo$muPost)
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])
    print(CountrySum)
    filename <-  file.path(outDir, 'bigDataParamsSummaryMuPost.txt')  
    write.table(.calcSummary2(bigDataParams,bigDataPosInfo$muPost), file = filename)
    cat('\n')
    
    cat('   sigmaEps   \n')
    CountrySum <- .calcSummary2(bigDataParams,bigDataPosInfo$sigmaEps,1)
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])
    print(CountrySum)
    filename <-  file.path(outDir, 'bigDataParamsSummarySigmaEps.txt')  
    write.table(.calcSummary2(bigDataParams,bigDataPosInfo$sigmaEps,1), file = filename)
    cat('\n')

    cat('   sigmaEpsPre   \n')
    CountrySum <- .calcSummary2(bigDataParams,bigDataPosInfo$sigmaEpsPre,1)
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])
    print(CountrySum)
    filename <-  file.path(outDir, 'bigDataParamsSummarySigmaEpsPre.txt')  
    write.table(.calcSummary2(bigDataParams,bigDataPosInfo$sigmaEpsPre,1), file = filename)
    cat('\n')
    
    cat('   sigmaEta   \n')
    CountrySum <- .calcSummary2(bigDataParams,bigDataPosInfo$sigmaEta,1)
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])
    print(CountrySum)
    filename <-  file.path(outDir, 'bigDataParamsSummarySigmaEta.txt')  
    write.table(.calcSummary2(bigDataParams,bigDataPosInfo$sigmaEta,1), file = filename)
    cat('\n')

    cat('   sigmaEtaPre   \n')
    CountrySum <- .calcSummary2(bigDataParams,bigDataPosInfo$sigmaEtaPre,1)
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])
    print(CountrySum)
    filename <-  file.path(outDir, 'bigDataParamsSummarySigmaEtaPre.txt')  
    write.table(.calcSummary2(bigDataParams,bigDataPosInfo$sigmaEtaPre,1), file = filename)
    cat('\n')

    cat('   sigmaNu   \n')
    CountrySum <- .calcSummary2(bigDataParams,bigDataPosInfo$sigmaNu,1)
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])
    print(CountrySum)
    filename <-  file.path(outDir, 'bigDataParamsSummarySigmaNu.txt')  
    write.table(.calcSummary2(bigDataParams,bigDataPosInfo$sigmaNu,1), file = filename)
    cat('\n')

}


simPlotMany <-
    function(allData, bigDataPosInfo, fullPlot = 1)
{    
    yy          <- allData$cData    
    nCountries  <- length(allData$countryNames)
    posFirst    <- allData$posFirst
    posLast     <- allData$posLast
    startYears  <- allData$startYears
    endYears    <- allData$endYears
    countryNames<- allData$countryNames

    posIIW      <- allData$posIIW
    nPeriods    <- max(posIIW)
    allYears    <- seq(min(startYears),min(startYears)+nPeriods-1,by =1)
        
    .tracePlotCountry <-
        function(dataMatrix,posInfo,nameInfo,toPower = 1,mult = 1)
    {
        TempInd    <- min(posInfo) - 1 + ii
        TempSample <- (dataMatrix[ , TempInd]^toPower)*mult
        labEx      <- nameInfo
        ylimTemp   <- range(TempSample)               
        plot(1:nrow(dataMatrix), as.ts(TempSample),
             main = labEx,
             xlab = 'iters',
             ylab = labEx,
             type = "l",
             ylim = ylimTemp,
             col = 1)
    }
    
    .histogramCountry <-
        function(dataMatrix,posInfo,nameInfo,toPower = 1,mult = 1)
    {        
        TempInd <- min(posInfo) - 1 + ii
        TempSample <- (dataMatrix[ , TempInd]^toPower)*mult        
        labEx <- nameInfo
        hist(TempSample,
             main        = labEx,
             ylab        = 'prob',
             xlab        = labEx,
             probability = TRUE)

    
    }        
    
    .tracePlotDisaster <-
        function(dataMatrix,posInfo,nameInfo,toPower = 1,mult = 1)
    {
        TempInd <- posInfo
        TempSample <- (dataMatrix[ , TempInd]^toPower)*mult
        labEx <- nameInfo
        ylimTemp   <- range(TempSample)   
        plot(1:nrow(dataMatrix), as.ts(TempSample),
             main = labEx,
             xlab = 'time',
             ylab = labEx,
             type = "l",
             ylim = ylimTemp,
             col = 1)
    }
    
    
    .histogramDisaster <-
        function(dataMatrix,posInfo,nameInfo,toPower = 1,mult = 1)
    {
        TempInd <- posInfo
        TempSample <- (dataMatrix[ , TempInd]^toPower)*mult
        labEx <- nameInfo
        hist(TempSample,
             main        = labEx,
             xlab        = labEx,
             ylab        = 'prob',
             probability = TRUE)
    }
  
    if (fullPlot == 1) {
    
        ## Plot each country's output from bugs
        ########################################
        for (ii in 1:nCountries) {
            filename <-  file.path(outDir, paste(c('bigData', countryNames[ii], 'pdf'),collapse = '.'))
            pdf(filename, paper = 'special', width = 6, height = 7)
            par(mfrow = c(3, 3))
            ## Plot yy
            labEx <- expression(c[t])            
            plot(startYears[ii]:endYears[ii], as.ts(yy[posFirst[ii]:posLast[ii]]),
                 main = paste(labEx,'for',countryNames[ii]),
                 xlab = 'time',
                 ylab = labEx,
                 type = "l")
            
            ## Plot xx and yy
            filename <-  file.path(outDir, 'bigDataXX.Rda') 
            load(filename)
            TempSample  <- bigDataXX[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            mean.Sample <- apply(TempSample,2,mean)
            q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)            
            ylimTemp    <- range(c(mean.Sample,q05.Sample,q95.Sample,yy[posFirst[ii]:posLast[ii]])) 
            labEx       <- expression(x[t])
            plot(startYears[ii]:endYears[ii], as.ts(yy[posFirst[ii]:posLast[ii]]),
                 main = labEx,
                 xlab = 'time',
                 ylab = labEx,
                 type = "l",
                 ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(mean.Sample), col = 2)
            lines(startYears[ii]:endYears[ii], as.ts(q05.Sample), col = 3)
            lines(startYears[ii]:endYears[ii], as.ts(q95.Sample), col = 4)
            rm(bigDataXX)
            
            ## Plot zz
            filename <-  file.path(outDir, 'bigDataZZ.Rda') 
            load(filename)
            TempSample  <- bigDataZZ[ , bigDataPosInfo$zz[posFirst[ii]:posLast[ii]]]
            mean.Sample <- apply(TempSample,2,mean)
            q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
            ylimTemp    <- range(c(mean.Sample,q05.Sample,q95.Sample)) 
            labEx       <- expression(z[t])
            plot(startYears[ii]:endYears[ii], as.ts(mean.Sample),
                 main = labEx,
                 xlab = 'time',
                 ylab = labEx,
                 type = "l",
                 ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(q05.Sample), col = 3)
            lines(startYears[ii]:endYears[ii], as.ts(q95.Sample), col = 4)
            rm(bigDataZZ)
    
            ## Plot II
            filename <-  file.path(outDir, 'bigDataII.Rda') 
            load(filename)
            TempSample  <- bigDataII[ , bigDataPosInfo$II[posFirst[ii]:posLast[ii]]]
            mean.Sample <- apply(TempSample,2,mean)
            q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
            ylimTemp    <- range(c(mean.Sample,q05.Sample,q95.Sample)) 
            ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample)) 
            labEx <- expression(I[t])
            plot(startYears[ii]:endYears[ii], as.ts(mean.Sample),
                 main = labEx,
                 xlab = 'time',
                 ylab = labEx,
                 type = "l",
                 ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(q05.Sample), col = 3)
            lines(startYears[ii]:endYears[ii], as.ts(q95.Sample), col = 4)
            rm(bigDataII)
    
            ## Plot phi
            filename <-  file.path(outDir, 'bigDataPhi.Rda') 
            load(filename)
            TempSample  <- bigDataPhi[ , bigDataPosInfo$phi[posFirst[ii]:posLast[ii]]]
            mean.Sample <- apply(TempSample,2,mean)
            q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
            ylimTemp    <- range(c(mean.Sample,q05.Sample,q95.Sample)) 
            ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample)) 
            labEx <- expression(phi[t])
            plot(startYears[ii]:endYears[ii], as.ts(mean.Sample),
                 main = labEx,
                 xlab = 'time',
                 ylab = labEx,
                 type = "l",
                 ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(q05.Sample), col = 3)
            lines(startYears[ii]:endYears[ii], as.ts(q95.Sample), col = 4)
            rm(bigDataPhi)
    
            ## Plot theta
            filename <-  file.path(outDir, 'bigDataTheta.Rda') 
            load(filename)
            TempSample  <- bigDataTheta[ , bigDataPosInfo$theta[posFirst[ii]:posLast[ii]]]
            mean.Sample <- apply(TempSample,2,mean)
            q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
            ylimTemp    <- range(c(mean.Sample,q05.Sample,q95.Sample)) 
            ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample)) 
            labEx <- expression(theta[t])
            plot(startYears[ii]:endYears[ii], as.ts(mean.Sample),
                 main = labEx,
                 xlab = 'time',
                 ylab = labEx,
                 type = "l",
                 ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(q05.Sample), col = 3)
            lines(startYears[ii]:endYears[ii], as.ts(q95.Sample), col = 4)
            rm(bigDataTheta)
            
            filename <-  file.path(outDir, 'bigDataParams.Rda') 
            load(filename)            
            
            #whichPar <- which("mu" == attr(bigDataPosInfo,"names"))
            .tracePlotCountry(bigDataParams, bigDataPosInfo$muPre,'muPre',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$muPre,'muPre',1)
 
            .tracePlotCountry(bigDataParams, bigDataPosInfo$muMid,'muMid',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$muMid,'muMid',1)
    
            .tracePlotCountry(bigDataParams, bigDataPosInfo$muPost,'muPost',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$muPost,'muPost',1)
    
            .tracePlotCountry(bigDataParams, bigDataPosInfo$sigmaEps,'sigmaEps',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$sigmaEps,'sigmaEps',1)
    
            .tracePlotCountry(bigDataParams, bigDataPosInfo$sigmaEpsPre,'sigmaEpsPre',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$sigmaEpsPre,'sigmaEpsPre',1)
    
            .tracePlotCountry(bigDataParams, bigDataPosInfo$sigmaEta,'sigmaEta',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$sigmaEta,'sigmaEta',1)
    
            .tracePlotCountry(bigDataParams, bigDataPosInfo$sigmaEtaPre,'sigmaEtaPre',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$sigmaEtaPre,'sigmaEtaPre',1)

            .tracePlotCountry(bigDataParams, bigDataPosInfo$sigmaNu,'sigmaNu',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$sigmaNu,'sigmaNu',1)
            
            dev.off()
        }
    }
    
    ## Plot disaster parameters
    ################################
    filename <-  file.path(outDir, paste(c('bigData','disasterPar','pdf'),collapse = '.'))
    pdf(filename, paper = 'special', width = 6, height = 7)
    par(mfrow = c(3, 3))

    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    load(filename)            

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$ppW[1],'pWb',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$ppW[1],'pWb',1)

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$ppC[1],'pCb_NWD',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$ppC[1],'pCb_NWD',1)

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$ppC[2],'1-pCe',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$ppC[2],'1-pCe',1)

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$ppC[3],'pCb_WD',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$ppC[3],'pCb_WD',1)

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$rho,'rho',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$rho,'rho',1)

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$meanPhi,'meanPhi',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$meanPhi,'meanPhi',1)

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$sigmaPhi,'sigmaPhi',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$sigmaPhi,'sigmaPhi',1)

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$meanTheta,'meanTheta',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$meanTheta,'meanTheta',1)
    
    .tracePlotDisaster(bigDataParams, bigDataPosInfo$sigmaTheta,'sigmaTheta',1)
    .histogramDisaster(bigDataParams, bigDataPosInfo$sigmaTheta,'sigmaTheta',1)

    .tracePlotDisaster(bigDataParams, bigDataPosInfo$deviance,'Log Likelihood',1,-1/2)
    .histogramDisaster(bigDataParams, bigDataPosInfo$deviance,'Log Likelihood',1,-1/2)
    
    dev.off()
    
    ## Plot World Disasters
    #####################################
    
    filename <-  file.path(outDir, 'bigDataIIWorld.Rda') 
    load(filename)

    mean.Sample  <- apply(bigDataIIWorld,2,mean)    
        
    filename <-  file.path(outDir, paste(c('bigData','WorldDisaster','txt'), collapse = '.'))  
    write.table(mean.Sample, file = filename)

    filename <-  file.path(outDir, paste(c('bigData','WorldDisaster','pdf'),collapse = '.'))
    pdf(filename, paper = 'special')

    plot(allYears, as.ts(mean.Sample), 
         main = "World Disasters", 
         ylab = "World Disaster Prob.", 
         xlab = "Year" , #pch = 2, 
         type = "h", col = 2)   
    par(new=T)   
    
    dev.off()
    
    ## Plot Country Summary
    #####################################
            
    filename <-  file.path(outDir, paste(c('bigData', 'countrySummary', 'pdf'),collapse = '.')) 
    pdf(filename, paper = 'special', width = 6, height = 7)
    par(mfrow = c(3, 2))

    filename <-  file.path(outDir, 'bigDataII.Rda') 
    load(filename)
    filename <-  file.path(outDir, 'bigDataXX.Rda') 
    load(filename)

    for (ii in 1:nCountries) {

        ## Disaster probability
        TempSample   <- bigDataII[ , bigDataPosInfo$II[posFirst[ii]:posLast[ii]]]
        mean.Sample  <- apply(TempSample,2,mean)    
        plot(startYears[ii]:endYears[ii], as.ts(mean.Sample), 
             main = countryNames[ii], 
             ylab = "Disaster Prob.", 
             xlab = "Year" , #pch = 2, 
             type = "h", col = 2)   
        par(new=T)
            TempSample   <- bigDataXX[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            mean.Sample  <- apply(TempSample,2,mean)    
        ylimTemp <- range(c(mean.Sample, yy[posFirst[ii]:posLast[ii]])) 
        plot(startYears[ii]:endYears[ii], as.ts(yy[posFirst[ii]:posLast[ii]]), 
             axes = F, xlab = "", ylab = "", 
             type = "l", col = 1,
             ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(mean.Sample), col = 3)
        axis(side=4)

        ## Disaster Gap 
        filename <-  file.path(outDir, 'bigDataZZ.Rda') 
        load(filename)            
        TempSample  <- bigDataZZ[ , bigDataPosInfo$zz[posFirst[ii]:posLast[ii]]]
        mean.Sample <- apply(TempSample,2,mean)
        q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
        q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
        ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample)) 
        plot(startYears[ii]:endYears[ii], as.ts(mean.Sample),
             main = countryNames[ii],
             xlab = 'time',
             ylab = "Disaster Gap (z)",
             type = "l",
             ylim = ylimTemp)
        lines(startYears[ii]:endYears[ii], as.ts(q05.Sample), col = 3)
        lines(startYears[ii]:endYears[ii], as.ts(q95.Sample), col = 4)
        rm(bigDataZZ)

        ## Distruction
        filename <-  file.path(outDir, 'bigDataPhi.Rda') 
        load(filename)
        Temp.II      <- bigDataII[ , bigDataPosInfo$II[posFirst[ii]:posLast[ii]]]
        Temp.phi     <- bigDataPhi[ , bigDataPosInfo$phi[posFirst[ii]:posLast[ii]]]
        Temp.phiII   <- Temp.II*Temp.phi
        mean.Sample  <- apply(Temp.phiII,2,mean)    
        plot(startYears[ii]:endYears[ii], as.ts(mean.Sample),  
             ylab = "Distruction (phi x I)", 
             xlab = "Year", 
             type = "s", col = 2)
        par(new=T)
        rm(bigDataPhi)      
            TempSample   <- bigDataXX[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            mean.Sample  <- apply(TempSample,2,mean)    
        ylimTemp <- range(c(mean.Sample, yy[posFirst[ii]:posLast[ii]])) 
        plot(startYears[ii]:endYears[ii], as.ts(yy[posFirst[ii]:posLast[ii]]), 
             axes = F, xlab = "", ylab = "", 
             type = "l", col = 1,
             ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(mean.Sample), col = 3)
        axis(side=4)    

        ## Long Run Impact
        filename <-  file.path(outDir, 'bigDataTheta.Rda') 
        load(filename)
        Temp.II      <- bigDataII[ , bigDataPosInfo$II[posFirst[ii]:posLast[ii]]]
        Temp.theta   <- bigDataTheta[ , bigDataPosInfo$theta[posFirst[ii]:posLast[ii]]]
        Temp.thetaII   <- Temp.II*Temp.theta
        mean.Sample  <- apply(Temp.thetaII,2,mean)  
        plot(startYears[ii]:endYears[ii], as.ts(mean.Sample),  
             ylab = "Long Run (theta x I)", 
             xlab = "Year", 
             type = "s", col = 2)
        par(new=T)
        rm(bigDataTheta)
            TempSample   <- bigDataXX[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            mean.Sample  <- apply(TempSample,2,mean)    
        ylimTemp <- range(c(mean.Sample, yy[posFirst[ii]:posLast[ii]])) 
        plot(startYears[ii]:endYears[ii], as.ts(yy[posFirst[ii]:posLast[ii]]), 
             axes = F, xlab = "", ylab = "", 
             type = "l", col = 1,
             ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(mean.Sample), col = 3)
        axis(side=4)    

        ## Distruction cond. on disaster
        filename <-  file.path(outDir, 'bigDataPhi.Rda') 
        load(filename)
        Temp.II      <- bigDataII[ , bigDataPosInfo$II[posFirst[ii]:posLast[ii]]]
        Temp.phi     <- bigDataPhi[ , bigDataPosInfo$phi[posFirst[ii]:posLast[ii]]]
        Temp.phiII   <- Temp.II*Temp.phi
        mean.phiII   <- apply(Temp.phiII,2,mean)    
        mean.II      <- apply(Temp.II,2,mean)
        mean.phiCond <- mean.phiII/mean.II
        Temp.NaN     <- which(mean.phiCond=="NaN")
        mean.phiCond[Temp.NaN] <- 0
        Temp.smallII <- (mean.II < 0.01)
        mean.phiCond[Temp.smallII] <- 0
        plot(startYears[ii]:endYears[ii], as.ts(mean.phiCond),  
             ylab = "Distruction cond. dis. (phi)", 
             xlab = "Year", 
             type = "s", col = 2)
        par(new=T)
        rm(bigDataPhi)
            TempSample   <- bigDataXX[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            mean.Sample  <- apply(TempSample,2,mean)    
        ylimTemp <- range(c(mean.Sample, yy[posFirst[ii]:posLast[ii]])) 
        plot(startYears[ii]:endYears[ii], as.ts(yy[posFirst[ii]:posLast[ii]]), 
             axes = F, xlab = "", ylab = "", 
             type = "l", col = 1,
             ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(mean.Sample), col = 3)
        axis(side=4)    

        ## Long Run Impact cond. on disaster        
        filename <-  file.path(outDir, 'bigDataTheta.Rda') 
        load(filename)
        Temp.II      <- bigDataII[ , bigDataPosInfo$II[posFirst[ii]:posLast[ii]]]
        Temp.theta   <- bigDataTheta[ , bigDataPosInfo$theta[posFirst[ii]:posLast[ii]]]
        Temp.thetaII <- Temp.II*Temp.theta
        mean.thetaII <- apply(Temp.thetaII,2,mean)  
        mean.II      <- apply(Temp.II,2,mean)
        mean.thetaCond <- mean.thetaII/mean.II
        Temp.NaN     <- which(mean.thetaCond=="NaN")
        mean.thetaCond[Temp.NaN] <- 0
        Temp.smallII <- (mean.II < 0.01)
        mean.thetaCond[Temp.smallII] <- 0
        plot(startYears[ii]:endYears[ii], as.ts(mean.thetaCond),  
             ylab = "Long Run cond. dis. (theta)", 
             xlab = "Year", 
             type = "s", col = 2)
        par(new=T)
        rm(bigDataTheta)
            TempSample   <- bigDataXX[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            mean.Sample  <- apply(TempSample,2,mean)    
        ylimTemp <- range(c(mean.Sample, yy[posFirst[ii]:posLast[ii]])) 
        plot(startYears[ii]:endYears[ii], as.ts(yy[posFirst[ii]:posLast[ii]]), 
             axes = F, xlab = "", ylab = "", 
             type = "l", col = 1,
             ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(mean.Sample), col = 3)
        axis(side=4)    

    }    

    dev.off()

    ## Plot Country Summary for Paper
    #####################################

    filename <-  file.path(outDir, paste(c('bigData', 'countrySummaryForPaper', 'pdf'),collapse = '.')) 
    pdf(filename, paper = 'special', width = 6, height = 7)
    par(mfrow = c(2, 1))

    filename <-  file.path(outDir, 'bigDataII.Rda') 
    load(filename)
    filename <-  file.path(outDir, 'bigDataXX.Rda') 
    load(filename)

    for (ii in 1:nCountries) {

        ## Disaster probability
        #par(mar=c(4,4,4,4))
        TempSample   <- bigDataII[ , bigDataPosInfo$II[posFirst[ii]:posLast[ii]]]
        mean.Sample  <- apply(TempSample,2,mean)    
        plot(startYears[ii]:endYears[ii], as.ts(mean.Sample), 
             main = countryNames[ii], 
             ylab = "", 
             xlab = "Year" , #pch = 2, 
             type = "h", col = 2,
             ylim = c(0,1))   
        par(new=T)
            TempSample   <- bigDataXX[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            mean.Sample  <- apply(TempSample,2,mean)    
        ylimTemp <- range(c(mean.Sample, yy[posFirst[ii]:posLast[ii]])) 
        plot(startYears[ii]:endYears[ii], as.ts(yy[posFirst[ii]:posLast[ii]]), 
             axes = F, xlab = "", ylab = "", 
             type = "l", col = 1,
             ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(mean.Sample), col = 3)
        axis(side=4)


    }    

    dev.off()

}

## Plot and Print Impluse Response Functions
#######################################################################


plotTypicalDisasterImpulseResponseMany <- 
    function(allData, bigDataPosInfo, IRlength = 20, disLength = 1)
{

    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    load(filename)
    
    yy          <- allData$cData
    nCountries  <- length(allData$countryNames)

    rho       <- mean(bigDataParams[ , bigDataPosInfo$rho])
    meanPhi   <- mean(bigDataParams[ , bigDataPosInfo$meanPhi])
    sigmaPhi  <- mean(bigDataParams[ , bigDataPosInfo$sigmaPhi])
    meanTheta <- mean(bigDataParams[ , bigDataPosInfo$meanTheta])
    
    uu <- 0
    ll <- -1000
    meanPhiStar  <- meanPhi + ((dnorm((ll-meanPhi)/sigmaPhi) - dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))*sigmaPhi

    YY <- matrix(0,nrow = IRlength + 1, ncol = 1)
    ZZ <- matrix(0,nrow = IRlength + 1, ncol = 1)

    YY[2,1] <- (disLength >= 1)*meanTheta
    ZZ[2,1] <- (disLength >= 1)*meanPhiStar - (disLength >= 1)*meanTheta        
    for (jj in 3:(IRlength+1)) { 
        ZZ[jj,1] <- rho*ZZ[jj-1,1] + (disLength >= jj-1)*meanPhiStar - (disLength >= jj-1)*meanTheta
        YY[jj,1] <- YY[jj-1,1] + (disLength >= jj-1)*meanTheta
    }       
    YY <- YY + ZZ 
    
    dimnames(YY) <- list(0:IRlength,'YY')
    filename <-  file.path(outDir, paste(c('TypicalDisasterImpulseResponse',
                           disLength,'Per','txt'), collapse = '.'))  
    write.table(YY, file = filename)
    filename <-  file.path(outDir, paste(c('TypicalDisasterImpulseResponse',
                           disLength,'Per','pdf'), collapse = '.')) 
    pdf(filename, paper = 'special')
    
    plot(0:IRlength, as.ts(YY),
         main = paste('Impulse Response for a Typical',disLength,'Period Disaster'),
         xlab = 'Years',
         ylab = 'D log(C)',
         type = "l")

    dev.off()
}

.calcSummaryIR <-
    function(YY)
{
    nPer    <- dim(YY)[2]
    nKeep   <- dim(YY)[1]
    
    tempDimNames <- list(dimnames(YY)[[1]],1,dimnames(YY)[[2]])
    
    tempYY <- array(NA,c(nKeep,1,nPer), dimnames = tempDimNames)
    tempYY[,1,] <- YY
    
    output <- monitor(tempYY)
    
    return(output)
}


plotDistributionDisasterImpulseResponseMany <- 
    function(allData, bigDataPosInfo, IRlength = 25)
{
    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    load(filename)
    
    yy          <- allData$cData
    nCountries  <- length(allData$countryNames)

    nSim        <- 5000
        
    for (ii in bigDataPosInfo$muPost) tempMeanMuPost <- mean(bigDataParams[,ii])
    meanMuPost  <- mean(tempMeanMuPost)
    
    sigmaEta    <- mean(bigDataParams[ , bigDataPosInfo$sigmaEta])
    
    rho         <- mean(bigDataParams[ , bigDataPosInfo$rho])
    meanPhi     <- mean(bigDataParams[ , bigDataPosInfo$meanPhi])
    sigmaPhi    <- mean(bigDataParams[ , bigDataPosInfo$sigmaPhi])
    meanTheta   <- mean(bigDataParams[ , bigDataPosInfo$meanTheta])
    sigmaTheta  <- mean(bigDataParams[ , bigDataPosInfo$sigmaTheta])
    ppCc        <- mean(bigDataParams[ , bigDataPosInfo$ppC[2]])
    
    uu <- 0
    ll <- -1000
    meanPhiStar  <- meanPhi + ((dnorm((ll-meanPhi)/sigmaPhi) - dnorm((uu-meanPhi)/sigmaPhi))/(pnorm((uu-meanPhi)/sigmaPhi) - pnorm((ll-meanPhi)/sigmaPhi)))*sigmaPhi
    
    ## Ad hoc parameters
    #scaleUpShocks  <- 1.0 
    #meanPhi        <- scaleUpShocks*meanPhiStar
    #meanTheta      <- scaleUpShocks*meanTheta
    #sigmaPhi       <- 10^(-8)
    #sigmaTheta     <- 10^(-8)    
    
    YY <- matrix(0,nrow = nSim, ncol = IRlength + 1)
    XX <- matrix(0,nrow = nSim, ncol = IRlength + 1)
    ZZ <- matrix(0,nrow = nSim, ncol = IRlength + 1)
    muCum <- matrix(0,nrow = nSim, ncol = IRlength + 1)
    DisDropBeginEnd <- matrix(0,nrow = nSim, ncol = 1)
    DisDropPeakTrough <- matrix(0,nrow = nSim, ncol = 1)
    DisDropLongRun <- matrix(0,nrow = nSim, ncol = 1)
    for (ii in 1:nSim) {
        phi     <- matrix(0, nrow = IRlength, ncol = 1)
        theta   <- matrix(0, nrow = IRlength, ncol = 1)

        typePlot <- 1
        if (typePlot == 1) {
            disLength            <- rgeom(1,1-ppCc) + 1
            #disLength            <- round(1/mean(1-ppCc[ ,1]))
            if (disLength > IRlength) disLength <- IRlength
            phi[1:disLength,1]   <- rtnorm(disLength,mean = meanPhi, sd = sigmaPhi, lower = -1000, upper = 0)
            theta[1:disLength,1] <- rnorm(disLength,mean = meanTheta, sd = sigmaTheta)
        } 
        XX[ii,2] <- theta[1,1]
        ZZ[ii,2] <- phi[1,1] - theta[1,1]        
        for (jj in 3:(IRlength+1)) { 
            ZZ[ii,jj] <- (rho*ZZ[ii,jj-1] + phi[jj-1,1] - theta[jj-1,1])
            XX[ii,jj] <- XX[ii,jj-1] + theta[jj-1,1]
        }
        DisDropBeginEnd[ii,1]  <- XX[ii,disLength+1] + ZZ[ii,disLength+1]
        DisDropPeakTrough[ii,1] <- min(XX[ii,] + ZZ[ii,])
        DisDropLongRun[ii,1] <- XX[ii,IRlength+1] + ZZ[ii,IRlength+1]
    }
    YY <- XX + ZZ 
    dimnames(YY) <- list(1:nSim, 0:IRlength)
    
    ## Impulse response figure and data
    filename <-  file.path(outDir, paste(c('BigDataDistDisasterIR','txt'),collapse = '.'))  
    write.table(.calcSummary2(YY), file = filename)
    filename <-  file.path(outDir, paste(c('BigDataDistDisasterIR','pdf'), collapse = '.')) 
    pdf(filename, paper = 'special')
    mean.IR <- matrix(apply(YY,2,mean), nrow = IRlength + 1, ncol = 1)
    q05.IR <- matrix(apply(YY,2,quantile, probs = 0.05), nrow = IRlength + 1, ncol = 1) 
    q33.IR <- matrix(apply(YY,2,quantile, probs = 0.33), nrow = IRlength + 1, ncol = 1)
    q50.IR <- matrix(apply(YY,2,quantile, probs = 0.50), nrow = IRlength + 1, ncol = 1)
    q67.IR <- matrix(apply(YY,2,quantile, probs = 0.67), nrow = IRlength + 1, ncol = 1)
    q95.IR <- matrix(apply(YY,2,quantile, probs = 0.95), nrow = IRlength + 1, ncol = 1)

    ylimTemp <- range(c(mean.IR,q05.IR,q95.IR)) 
    plot(0:IRlength, as.ts(mean.IR),
         main = paste('Disaster Distribution'),
         xlab = 'Years',
         ylab = 'D log(C)',
         type = "l",
         ylim = ylimTemp)
    lines(0:IRlength, as.ts(q05.IR), col = 1, lty = 2)
    #lines(0:IRlength, as.ts(q33.IR), col = 1, lty = 2) 
    lines(0:IRlength, as.ts(q50.IR), col = 1, lty = 2) 
    #lines(0:IRlength, as.ts(q67.IR), col = 1, lty = 2) 
    lines(0:IRlength, as.ts(q95.IR), col = 1, lty = 2) 

    dev.off()
    
    # Distribution of Change from Beginning to End

    nBins      <- 31
    minHist    <- min(DisDropBeginEnd)
    maxHist    <- max(DisDropBeginEnd)
    setBreaks  <- seq(from = minHist,to = maxHist, length.out = nBins)    
    midpoints  <- (setBreaks[2:nBins]+setBreaks[1:(nBins-1)])/2
    histData   <- matrix(0, nrow = nBins-1, ncol = 2)
    dimnames(histData) <- list(1:(nBins-1), c("bin midpoint","density"))
    for(ii in 1:(nBins-1)) {
        histData[ii,1] <- midpoints[ii]
        histData[ii,2] <- (sum(setBreaks[ii] < DisDropBeginEnd & DisDropBeginEnd <= setBreaks[ii+1])/nrow(DisDropBeginEnd))/(setBreaks[2]-setBreaks[1])
    }

    filename <-  file.path(outDir, paste(c('histBeginEnd','txt'),collapse = '.'))  
    write.table(histData, file = filename)

    filename <-  file.path(outDir, paste(c('distBeginEnd','txt'),collapse = '.'))  
    write.table(DisDropBeginEnd, file = filename)

    filename <-  file.path(outDir, 'histBeginEnd.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 6)

    hist(DisDropBeginEnd,
         main = '', 
         xlab = 'Begin to End Drop in C', 
         ylab = 'Density',
         freq = FALSE,
         #probability = TRUE,
         density = 15,
         breaks = setBreaks)    

    dev.off()
        
    # Distribution of Peak to Trough

    nBins      <- 31
    minHist    <- min(DisDropPeakTrough)
    maxHist    <- max(DisDropPeakTrough)
    setBreaks  <- seq(from = minHist,to = maxHist, length.out = nBins)    
    midpoints  <- (setBreaks[2:nBins]+setBreaks[1:(nBins-1)])/2
    histData   <- matrix(0, nrow = nBins-1, ncol = 2)
    dimnames(histData) <- list(1:(nBins-1), c("bin midpoint","density"))
    for(ii in 1:(nBins-1)) {
        histData[ii,1] <- midpoints[ii]
        histData[ii,2] <- (sum(setBreaks[ii] < DisDropPeakTrough & DisDropPeakTrough <= setBreaks[ii+1])/nrow(DisDropPeakTrough))/(setBreaks[2]-setBreaks[1])
    }

    filename <-  file.path(outDir, paste(c('histPeakTrough','txt'),collapse = '.'))  
    write.table(histData, file = filename)

    filename <-  file.path(outDir, paste(c('distPeakTrough','txt'),collapse = '.'))  
    write.table(DisDropPeakTrough, file = filename)

    filename <-  file.path(outDir, 'histPeakTrough.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 6)

    hist(DisDropPeakTrough,
         main = '', 
         xlab = 'Peak to Trough Drop in C', 
         ylab = 'Density',
         freq = FALSE,
         #probability = TRUE,
         density = 15,
         breaks = setBreaks)    

    dev.off()    

    # Distribution of Long Run Effect

    nBins      <- 31
    minHist    <- min(DisDropLongRun)
    maxHist    <- max(DisDropLongRun)
    setBreaks  <- seq(from = minHist,to = maxHist, length.out = nBins)    
    midpoints  <- (setBreaks[2:nBins]+setBreaks[1:(nBins-1)])/2
    histData   <- matrix(0, nrow = nBins-1, ncol = 2)
    dimnames(histData) <- list(1:(nBins-1), c("bin midpoint","density"))
    for(ii in 1:(nBins-1)) {
        histData[ii,1] <- midpoints[ii]
        histData[ii,2] <- (sum(setBreaks[ii] < DisDropLongRun & DisDropLongRun <= setBreaks[ii+1])/nrow(DisDropLongRun))/(setBreaks[2]-setBreaks[1])
    }

    filename <-  file.path(outDir, paste(c('histLongRun','txt'),collapse = '.'))  
    write.table(histData, file = filename)

    filename <-  file.path(outDir, paste(c('distLongRun','txt'),collapse = '.'))  
    write.table(DisDropLongRun, file = filename)

    filename <-  file.path(outDir, 'histLongRun.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 6)

    hist(DisDropLongRun,
         main = '', 
         xlab = 'Long Run Drop in C', 
         ylab = 'Density',
         freq = FALSE,
         #probability = TRUE,
         density = 15,
         breaks = setBreaks)    

    dev.off()   
    
}

## Analyze Disaster "Episodes"
###############################################################################

getDisasterEpisodesMany <- 
    function(allData, bigDataPosInfo, controlAgg)
{
    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    load(filename)
    filename <-  file.path(outDir, 'bigDataII.Rda') 
    load(filename)
    filename <-  file.path(outDir, 'bigDataPhi.Rda') 
    load(filename)
    filename <-  file.path(outDir, 'bigDataTheta.Rda') 
    load(filename)

    
    yy          <- allData$cData
    countryNames<- allData$countryNames
    posFirst    <- allData$posFirst
    posLast     <- allData$posLast
    startYears  <- allData$startYears
    endYears    <- allData$endYears
    nCountries  <- length(allData$countryNames)
    nKeep       <- nrow(bigDataParams)
    
    ## Create vector that records with years are disaster years 
    dEpsIndex   <- numeric(length(yy))
    
    ## Create a vector with disaster probabilities
    disasterProb <- apply(bigDataII,2,mean)
    
    ## Define list containing information about disaster episodes
    dEps <- list(dProb = disasterProb)
    dEps$Ind <- numeric(length(yy))
    dEps$episodes <- list(NULL)
    
    hiDisasterProb <- (disasterProb > controlAgg$hiProb)
    
    nDisasters <- 0
    for (ii in 1:nCountries) {
        jj <- posFirst[ii]
        while (jj <= posLast[ii]) {
            if (hiDisasterProb[jj]) {
                # Determine whether current period is in a disaster episode
                tempDisaster <- disasterProb[jj]
                tempLength <- 1
                if (jj+1 <= posLast[ii]) { ## Figure out whether next period is in current tempDisaster
                    tempInd <- hiDisasterProb[jj+1]
                } else {
                    tempInd <- FALSE
                }
                while (tempInd) {
                    tempDisaster <- tempDisaster + disasterProb[jj+tempLength]
                    tempLength <- tempLength + 1
                    if (jj+tempLength <= posLast[ii]) { ## Figure out whether next period is in current tempDisaster
                        tempInd <- hiDisasterProb[jj+tempLength]
                    } else {
                        tempInd <- FALSE
                    }
                }
                if (tempDisaster > controlAgg$totProb) {
                    dEps$Ind[jj:(jj+tempLength-1)] <- 1
                    nDisasters <- nDisasters + 1
                }
                # Analyze disaster episode
                if (dEps$Ind[jj] == 1) {
                    dEps$episodes[[nDisasters]] <- list(country = countryNames[ii])
                    dEps$episodes[[nDisasters]]$startDate    <- startYears[ii] + jj - posFirst[ii]
                    dEps$episodes[[nDisasters]]$endDate      <- startYears[ii] + jj + tempLength - 1 - posFirst[ii]
                    dEps$episodes[[nDisasters]]$nYears       <- tempLength
                    dEps$episodes[[nDisasters]]$meanLength   <- 0
                    dEps$episodes[[nDisasters]]$meanSumTheta <- 0
                    dEps$episodes[[nDisasters]]$meanMaxFall  <- 0
                    dEps$episodes[[nDisasters]]$meanPermFall <- 0
                    
                    meanrho            <- mean(bigDataParams[ ,bigDataPosInfo$rho])
                    tempLengthIRF      <- 1 + tempLength + ceiling(5*(-log(2)/log(meanrho)))
                    tempIRF            <- matrix(0, nKeep,tempLengthIRF)
                    tempZZ             <- matrix(0, nKeep,tempLengthIRF)
                    tempPerm           <- matrix(0, nKeep,tempLengthIRF)
                    tempPosInfoPhi     <- bigDataPosInfo$phi[jj:(jj+tempLength-1)]
                    tempPosInfoTheta   <- bigDataPosInfo$theta[jj:(jj+tempLength-1)]
                    tempPosInfoII      <- bigDataPosInfo$II[jj:(jj+tempLength-1)]                        
                    
                    dEps$episodes[[nDisasters]]$meanLength <- (dEps$episodes[[nDisasters]]$meanLength
                        + sum(bigDataII[ , tempPosInfoII])/nKeep)                                                
                    dEps$episodes[[nDisasters]]$meanSumTheta <- (dEps$episodes[[nDisasters]]$meanSumTheta
                        + sum(bigDataII[ , tempPosInfoII]*bigDataTheta[ , tempPosInfoTheta])/dim(bigDataII)[1])
                    
                    ## Calculate Disaster Impulse response for each iteration
                    tempII             <- bigDataII[ ,tempPosInfoII]
                    tempII             <- cbind(matrix(0,nKeep,1),tempII, matrix(0,nKeep,tempLengthIRF-1-tempLength))
                    tempPhi            <- bigDataPhi[ ,tempPosInfoPhi]
                    tempPhi            <- cbind(matrix(0,nKeep,1),tempPhi, matrix(0,nKeep,tempLengthIRF-1-tempLength))
                    tempTheta          <- bigDataTheta[ ,tempPosInfoTheta]
                    tempTheta          <- cbind(matrix(0,nKeep,1),tempTheta, matrix(0,nKeep,tempLengthIRF-1-tempLength))
                    tempRho            <- bigDataParams[ ,bigDataPosInfo$rho]
                    
                    tempZZ            <- matrix(0, nKeep,tempLengthIRF)
                    tempPerm          <- matrix(0, nKeep,tempLengthIRF)
                    tempZZ[,2]        <- tempII[,2]*tempPhi[,2] - tempII[,2]*tempTheta[,2]
                    tempPerm[,2]      <- tempII[,2]*tempTheta[,2]
                    for (yy in 3:tempLengthIRF) {
                        tempZZ[,yy] <- tempRho[]*tempZZ[,yy-1] + tempII[,yy]*tempPhi[,yy] - tempII[,yy]*tempTheta[,yy] 
                        tempPerm[,yy] <- tempPerm[,yy-1] + tempII[,yy]*tempTheta[,yy]
                    }
                    tempIRF <- tempZZ + tempPerm
                    dEps$episodes[[nDisasters]]$meanMaxFall  <- mean(apply(tempIRF,1,min))
                    dEps$episodes[[nDisasters]]$meanPermFall <- mean(tempPerm[ ,tempLengthIRF])
                    
                    cat('.')
                }
                jj <- jj + tempLength
            } else {
                jj <- jj + 1
            }
        }
    }
    
    filename <-  file.path(outDir, 'dEps.Rda') 
    save(dEps,file = filename)    
    
    cat('\n')
    return(dEps)
}

printDisasterEpisodesMany <-
    function(dEps)
{
    if (length(dEps$episodes[[1]]) != 0) {
        nDEps <- length(dEps$episodes)
        MatToPlot <- matrix(0,nDEps,6)
        attr(MatToPlot,"dimnames") <- list(numeric(nDEps),numeric(6))
        attr(MatToPlot,"dimnames")[[2]] <- c("startDate","EndDate","nYears","meanLength","meanMaxFall","meanPermFall") 
        for (ii in 1:nDEps) {
              attr(MatToPlot,"dimnames")[[1]][ii] <- dEps$episodes[[ii]]$country
              MatToPlot[ii,1] <- dEps$episodes[[ii]]$startDate
              MatToPlot[ii,2] <- dEps$episodes[[ii]]$endDate
              MatToPlot[ii,3] <- dEps$episodes[[ii]]$nYears
              MatToPlot[ii,4] <- dEps$episodes[[ii]]$meanLength
              MatToPlot[ii,5] <- dEps$episodes[[ii]]$meanMaxFall
              MatToPlot[ii,6] <- dEps$episodes[[ii]]$meanPermFall
        }
        
        cat('\n')
        cat('   Summary of Disaster Episodes   \n')
        filename <- file.path(outDir, 'bigDataSummaryDisasterEpisodes.txt')
        cat('\n')
        print(MatToPlot)
        write.table(MatToPlot, file = filename)
        cat('\n')
        return(MatToPlot)
    } else {
        cat('\n')
        cat('   There Are No Disaster Episodes Estimated   \n')
        cat('\n')

    }
}
