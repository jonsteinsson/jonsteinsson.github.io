#####################################################################
## Support functions for runSim.R.
##
## Emi Nakamura and Jon Steinsson, June 2009
#####################################################################


getControlVarSim <-
    function(allData)
{
    doSimSingleCountry     <- 1
    doSimMultiCountry      <- 1
    doSimSingleCountryLong <- 0
    
    nRuns <- 500 # Number of simulations to be aggregated together to create statistics of interest
    
    # SimSingleCountry parameters
    nYearsSingle     <- 2006 - 1935 + 1
    nSimBurninSingle <- 0
    
    # SimMultiCountry parameters
    nSimBurninMulti  <- 0
    
    # SimSingleCountryLong parameters
    nYearsLong       <- 200000
    nSimBurninLong   <- 0
    
    return(list(doSimSingleCountry = doSimSingleCountry, 
                doSimMultiCountry = doSimMultiCountry,
                doSimSingleCountryLong = doSimSingleCountryLong, 
                nRuns = nRuns, nYearsSingle = nYearsSingle, nSimBurninSingle = nSimBurninSingle,
                nSimBurninMulti = nSimBurninMulti, nYearsLong = nYearsLong, 
                nSimBurninLong = nSimBurninLong))
}

## Get Parameter Estimates
######################################################################

getParEstimatesSim <-
    function(UnobsPosInfo)
{
    filename <-  file.path(outDir, paste(c('bigDataParams','Rda'),collapse = '.'))  
    load(filename)
    
    ParEst <- numeric(dim(bigDataParams)[2])
    for (ii in UnobsPosInfo$deviance) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$meanPhi) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$meanTheta) ParEst[ii]     <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muMid) ParEst[ii]         <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muPost) ParEst[ii]        <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muPre) ParEst[ii]         <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$ppC) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$ppW) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$rho) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$rhobets) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEps) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEpsPre) ParEst[ii]   <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEta) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEtaPre) ParEst[ii]   <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaNu) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaPhi) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaTheta) ParEst[ii]    <- mean(bigDataParams[,ii])
    
    ## Take averages of country specific shocks
    ParEst[UnobsPosInfo$muPost]    <- c(rep(mean(ParEst[UnobsPosInfo$muPost]),length(UnobsPosInfo$muPost)))
    ParEst[UnobsPosInfo$sigmaEps]  <- c(rep(mean(ParEst[UnobsPosInfo$sigmaEps]),length(UnobsPosInfo$sigmaEps)))
    ParEst[UnobsPosInfo$sigmaEta]  <- c(rep(mean(ParEst[UnobsPosInfo$sigmaEta]),length(UnobsPosInfo$sigmaEta)))    
    
    ## No disasters
    #ParEst[UnobsPosInfo$ppW]         <- 0.0
    #ParEst[UnobsPosInfo$ppC]         <- c(0.0,0.0,0.0)
            
    return(ParEst)
}

#####################################################################
## Estimate frequency of no disasters for single country over given
## number of years

getStatsForSingleCountry <-
    function(ParEstimates, UnobsPosInfo, controlVarSim)
{
    nRuns    <- controlVarSim$nRuns
    nYears   <- controlVarSim$nYearsSingle
    
    nNoDis  <- 0
    nNoWDis <- 0
    for (ii in 1:nRuns) {
        simOutput <- SimSingleCountry(ParEstimates, UnobsPosInfo, controlVarSim, nYears)
        nNoDis <- nNoDis + 1 - max(simOutput$II)
        nNoWDis <- nNoWDis + 1 - max(simOutput$IIWorld)
    }
    
    fracNoDis  <- nNoDis/nRuns
    fracNoWDis <- nNoWDis/nRuns
    
    return(list(fracNoDis = fracNoDis, fracNoWDis = fracNoWDis))
}

#####################################################################
## Estimate frequency of no disasters for single country over given
## number of years

getStatsForMultiCountry <-
    function(ParEstimates, UnobsPosInfo, controlVarSim)
{
    nRuns    <- controlVarSim$nRuns
    
    nSomeCountryNoDis  <- 0
    nNoWDis         <- 0
    for (ii in 1:nRuns) {
        allData         <- SimMultiCountry(ParEstimates, UnobsPosInfo, controlVarSim)
                
        startYears <- allData$startYears
        when1934   <- 1934 - startYears
        
        SomeCountryNoDis <- 0
        jj <- 1
        while (jj <= length(allData$posFirst) & SomeCountryNoDis < 1) {            
            SomeCountryNoDis <- 1 - max(allData$II[(allData$posFirst[jj]+when1934[jj]):allData$posLast[jj]])
            jj = jj + 1
        }        
        
        nSomeCountryNoDis <- nSomeCountryNoDis + SomeCountryNoDis
        nNoWDis        <- nNoWDis + 1 - max(allData$IIWorld[(1934-1890+1):117])
        
        if (ii %% 100 == 0) cat('.')
        if (ii %% 1000 == 0) cat('\n')

    }
    cat('\n')
    
    fracSomeCountryNoDis  <- nSomeCountryNoDis/nRuns
    fracNoWDis         <- nNoWDis/nRuns
    
    return(list(fracSomeCountryNoDis = fracSomeCountryNoDis,
                fracNoWDis = fracNoWDis))
}

#####################################################################
## Estimate standard deviation of the growth rate of consumption
## during disasters

getStatsForSingleCountryLong <-
    function(ParEstimates, UnobsPosInfo, controlVarSim)
{
    nYears   <- controlVarSim$nYearsLong
    
    simOutput <- SimSingleCountry(ParEstimates, UnobsPosInfo, controlVarSim, nYears)
    
    II  <- simOutput$II
    CC  <- simOutput$CC
    
    IItemp  <- which(II == 1)    
    DCCDis  <- CC[IItemp] - CC[IItemp-1]
    meanDCCDis <- mean(DCCDis)
    stdDCCDis  <- var(DCCDis)^(1/2)
    
    IILastBefore      <- numeric(nYears)
    IILastOf          <- numeric(nYears)
    IILastBefore[1:(nYears-1)] <- !II[1:(nYears-1)] & II[2:nYears]
    IILastOf[1:(nYears-1)]     <- II[1:(nYears-1)] & !II[2:nYears]
    
    DCBeginEnd        <- exp(CC[which(IILastOf == 1)] - CC[which(IILastBefore == 1)])-1
    
    return(list(meanDCCDis = meanDCCDis, stdDCCDis = stdDCCDis, DCBeginEnd = DCBeginEnd))
}

#####################################################################
## Simulate a single country

SimSingleCountry <-
    function(ParEstimates, UnobsPosInfo, controlVar, nSim, nSimBurnin = 0)
{       
    simOutput  <- list(NULL)

    #Get parameters
    paramNames <- c("meanPhi", "meanTheta", "muMid", "muPost", "muPre", "ppC", "ppW", "rho", 
                    "sigmaEps", "sigmaEpsPre", "sigmaEta", "sigmaEtaPre", "sigmaNu", 
                    "sigmaPhi", "sigmaTheta")                
    for (ii in 1:length(paramNames)) {
        eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
        eval(parse(text = paste('simOutput$',paramNames[ii],'<-',paramNames[ii], sep='')))
    }
    
    # Initialize variables
    II      <- numeric(nSim+nSimBurnin)
    IIWorld <- numeric(nSim+nSimBurnin)
    XX      <- numeric(nSim+nSimBurnin)
    ZZ      <- numeric(nSim+nSimBurnin)
    Eps     <- numeric(nSim+nSimBurnin)
    CC      <- numeric(nSim+nSimBurnin)
    Eta     <- numeric(nSim+nSimBurnin)
    Phi     <- numeric(nSim+nSimBurnin)
    Theta   <- numeric(nSim+nSimBurnin)
    Nu      <- numeric(nSim+nSimBurnin)

    ## Set initial values
    XX[1]      <- 1
    CC[1]  <- XX[1] + ZZ[1] + Eps[1]
    
    ## Simulate model
    for (ii in 2:(nSim+nSimBurnin)) {
        IIWorld[ii] <- rbinom(1,1,ppW)
        if (II[ii-1] == 1) {
            temppp <- ppC[2]
        } else if (IIWorld[ii] == 1) {
            temppp <- ppC[3]
        } else {
            temppp <- ppC[1]
        }
        II[ii]    <- rbinom(1,1,temppp)

        Theta[ii] <- rnorm(1,meanTheta,sigmaTheta)
        Phi[ii]   <- rtnorm(1,meanPhi,sigmaPhi,-1000,0)
        Eps[ii]   <- rnorm(1,0,sigmaEps[1]) 
        Eta[ii]   <- rnorm(1,0,sigmaEta[1])
        Nu[ii]    <- rnorm(1,0,sigmaNu[1]) 
        XX[ii]    <- XX[ii-1] + muPost[1] + Eta[ii] + Theta[ii]*II[ii]
        ZZ[ii]    <- rho*ZZ[ii-1] + Nu[ii] - Theta[ii]*II[ii] + Phi[ii]*II[ii]
        CC[ii]    <- XX[ii] + ZZ[ii] + Eps[ii]
    }

    simOutput$IIWorld <- IIWorld[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$II      <- II[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Eps     <- Eps[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Eta     <- Eta[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Theta   <- Theta[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Phi     <- Phi[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Nu      <- Nu[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$XX      <- XX[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$ZZ      <- ZZ[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$CC      <- CC[(nSimBurnin+1):(nSim+nSimBurnin)]

    return(simOutput)
}

#####################################################################
## Simulate same sized data set as we use

SimMultiCountry <- 
    function(ParEstimates, UnobsPosInfo, controlVar)
{
    allData    <- readData(prefixDir)
    
    nSimBurnin <- controlVar$nSimBurninMulti
    
    #Get parameters
    paramNames <- c("meanPhi", "meanTheta", "muMid", "muPost", "muPre", "ppC", "ppW", "rho", 
                    "sigmaEps", "sigmaEpsPre", "sigmaEta", "sigmaEtaPre", "sigmaNu", 
                    "sigmaPhi", "sigmaTheta")                
    for (ii in 1:length(paramNames)) {
        eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
        eval(parse(text = paste('allData$',paramNames[ii],'<-',paramNames[ii], sep='')))
    }
    
    nDataPoints <- length(allData$cData)
    
    allData$IIWorld <- c(0,rbinom(max(allData$posIIW)-1,1,ppW))
    allData$II      <- numeric(nDataPoints)
    allData$XX      <- numeric(nDataPoints)
    allData$ZZ      <- numeric(nDataPoints)
    allData$Eps     <- numeric(nDataPoints)
    allData$CC      <- numeric(nDataPoints)
    allData$Eta     <- numeric(nDataPoints)
    allData$Phi     <- numeric(nDataPoints)
    allData$Theta   <- numeric(nDataPoints)
    allData$Nu      <- numeric(nDataPoints)
    
    for (ii in 1:length(allData$posFirst)) {
        
        nSim   <- allData$posLast[ii]-allData$posFirst[ii]+1 ## Number of periods for country ii

        # Initialize variables
        II      <- numeric(nSim+nSimBurnin)
        XX      <- numeric(nSim+nSimBurnin)
        ZZ      <- numeric(nSim+nSimBurnin)
        Eps     <- numeric(nSim+nSimBurnin)
        CC      <- numeric(nSim+nSimBurnin)
        Eta     <- numeric(nSim+nSimBurnin)
        Phi     <- numeric(nSim+nSimBurnin)
        Theta   <- numeric(nSim+nSimBurnin)
        Nu      <- numeric(nSim+nSimBurnin)

        ## Set initial values
        XX[1]      <- 1
        CC[1]  <- XX[1] + ZZ[1] + Eps[1]

        ## Simulate model
        for (jj in 2:(nSim+nSimBurnin)) {
                        
            if (II[jj-1] == 1) {
                temppp <- ppC[2]
            } else if (allData$IIWorld[allData$posIIW[allData$posFirst[ii]+jj-1]] == 1) {
                temppp <- ppC[3]
            } else {
                temppp <- ppC[1]
            }
            II[jj]    <- rbinom(1,1,temppp)

            Theta[jj] <- rnorm(1,meanTheta,sigmaTheta)
            Phi[jj]   <- rtnorm(1,meanPhi,sigmaPhi,-1000,0)
            Eps[jj]   <- rnorm(1,0,sigmaEps[1]) 
            Eta[jj]   <- rnorm(1,0,sigmaEta[1])
            Nu[jj]    <- rnorm(1,0,sigmaNu[1]) 
            XX[jj]    <- XX[jj-1] + muPost[1] + Eta[jj] + Theta[jj]*II[jj]
            ZZ[jj]    <- rho*ZZ[jj-1] + Nu[jj] - Theta[jj]*II[jj] + Phi[jj]*II[jj]
            CC[jj]    <- XX[jj] + ZZ[jj] + Eps[jj]
        }

        allData$II[allData$posFirst[ii]:allData$posLast[ii]]      <- II[(nSimBurnin+1):(nSim+nSimBurnin)]
        allData$Eps[allData$posFirst[ii]:allData$posLast[ii]]     <- Eps[(nSimBurnin+1):(nSim+nSimBurnin)]
        allData$Eta[allData$posFirst[ii]:allData$posLast[ii]]     <- Eta[(nSimBurnin+1):(nSim+nSimBurnin)]
        allData$Theta[allData$posFirst[ii]:allData$posLast[ii]]   <- Theta[(nSimBurnin+1):(nSim+nSimBurnin)]
        allData$Phi[allData$posFirst[ii]:allData$posLast[ii]]     <- Phi[(nSimBurnin+1):(nSim+nSimBurnin)]
        allData$Nu[allData$posFirst[ii]:allData$posLast[ii]]      <- Nu[(nSimBurnin+1):(nSim+nSimBurnin)]
        allData$XX[allData$posFirst[ii]:allData$posLast[ii]]      <- XX[(nSimBurnin+1):(nSim+nSimBurnin)]
        allData$ZZ[allData$posFirst[ii]:allData$posLast[ii]]      <- ZZ[(nSimBurnin+1):(nSim+nSimBurnin)]
        allData$CC[allData$posFirst[ii]:allData$posLast[ii]]      <- CC[(nSimBurnin+1):(nSim+nSimBurnin)]
    }
    
    return(allData)
}
