#####################################################################
## Support functions for runStats.R
##
## Emi Nakamura and Jon Steinsson, September 2012
#####################################################################

getRWDistDisasters <- 
    function(allData)
{    
    CC <- allData$cData
    
    filename <- file.path(outDir, paste(c('dEps','Rda'),collapse = '.'))
    load(filename)
    DisInd <- dEps$Ind
    
    TT <- length(DisInd)
      
    # Create variable that contains info on number of periods since last disaster started
    DisCount <- numeric(TT)
    for (ii in 1:TT) {
        if (sum(ii == allData$posFirst)) {
            DisCount[ii] = 0
        } else if (DisCount[ii-1] == 0) {
            if (DisInd[ii-1] == 0 & DisInd[ii] == 1) DisCount[ii] = 1
        } else {
            if (DisInd[ii-1] == 0 & DisInd[ii] == 1) {
                DisCount[ii] = 1
            } else {
                DisCount[ii] = DisCount[ii-1] + 1
            }
        }
    }
    
    DisYear0 <- which(DisCount == 1) - 1
    DisYear1 <- which(DisCount == 1)
    DisYear2 <- which(DisCount == 2) 
    DisYear3 <- which(DisCount == 3)
    DisYear4 <- which(DisCount == 4)
    DisYear5 <- which(DisCount == 5)
    DisYear6 <- which(DisCount == 6)
    DisYear7 <- which(DisCount == 7)
    DisYear8 <- which(DisCount == 8)
    DisYear9 <- which(DisCount == 9)
    DisYear10 <- which(DisCount == 10)
    
    NDis <- length(DisYear1)
    
    DisDist <- matrix(NA,nrow = 11, ncol = NDis)
    DisDist[1,] <- 0
    #DisDist[2,1:NDis] <- CC[DisYear1] - CC[DisYear0]
    
    for (ii in 1:10) {
        for (jj in 1:NDis) {
            if (DisCount[DisYear0[jj] + ii] == ii) DisDist[ii+1,jj] <- CC[DisYear0[jj] + ii] - CC[DisYear0[jj]]
        }
    }
    
    medianCC <- numeric(11)
    q25CC    <- numeric(11)
    q75CC    <- numeric(11)
    for (ii in 1:10) {
        temp <- which(1 - is.na(DisDist[ii+1,]) == 1)
        medianCC[ii+1] <- median(DisDist[ii+1,temp])
        q25CC[ii+1]    <- quantile(DisDist[ii+1,temp],prob = 0.25)
        q75CC[ii+1]    <- quantile(DisDist[ii+1,temp],prob = 0.75)
    }
    
    return(list(medianCC = medianCC,
                q25CC    = q25CC,
                q75CC    = q75CC))
}