#####################################################################
## This program calculates asset prices for our disaster model
##
## Emi Nakamura and Jon Steinsson, June 2008
#####################################################################

rm(list = ls())
gc()

options(digits = 5)

library("arm")
library("msm")

source('funcs.R')
source('funcsAgg.R')
source('funcsAP.R')

dirInfo          <- getDirInfo()
outDir           <- dirInfo$outDir
prefixDir        <- dirInfo$prefixDir
outDirNextState  <- file.path(outDir, 'nextState')
allData          <- readData(prefixDir)

controlVarAP     <- getControlVarAP(allData)

NamesNPosInfo    <- getNamesNPosInfo(allData)
parameters       <- NamesNPosInfo$UnobsNames
UnobsPosInfo     <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo   <- getBigDataPosInfo(UnobsPosInfo)

if (controlVarAP$doEZW) {
    if (controlVarAP$updatePDivs) {

        ParEstimates     <- getParEstimates(bigDataPosInfo, controlVarAP)
        
        filename <- file.path(outDir, "APresults.txt")
        sink(filename)
        cat('\n')
        cat('PARAMETERS\n')
        cat('\n')
        cat('rhoU:                     ',controlVarAP$rhoU,'\n')
        cat('gammaU:                   ',controlVarAP$gammaU,'\n')
        cat('psiU:                     ',controlVarAP$psiU,'\n')
        cat('thetaU:                   ',controlVarAP$thetaU,'\n')
        cat('\n')
        cat('Mu:                       ',ParEstimates[bigDataPosInfo$muPost][controlVarAP$countryToUse],'\n')
        cat('sigmaEps:                 ',ParEstimates[bigDataPosInfo$sigmaEps][controlVarAP$countryToUse],'\n')
        cat('sigmaEta:                 ',ParEstimates[bigDataPosInfo$sigmaEta][controlVarAP$countryToUse],'\n')
        cat('\n')
        cat('pWb:                      ',ParEstimates[bigDataPosInfo$ppW],'\n')
        cat('pCb_NWD:                  ',ParEstimates[bigDataPosInfo$ppC][1],'\n')
        cat('pCb_WD:                   ',ParEstimates[bigDataPosInfo$ppC][3],'\n')
        cat('1-pCe:                    ',ParEstimates[bigDataPosInfo$ppC[2]],'\n')
        cat('rho:                      ',ParEstimates[bigDataPosInfo$rho],'\n')
        cat('meanPhi:                  ',ParEstimates[bigDataPosInfo$meanPhi],'\n')
        cat('meanTheta:                ',ParEstimates[bigDataPosInfo$meanTheta],'\n')
        cat('sigmaPhi:                 ',ParEstimates[bigDataPosInfo$sigmaPhi],'\n')
        cat('sigmaTheta:               ',ParEstimates[bigDataPosInfo$sigmaTheta],'\n')
        cat('\n')
        cat('Average Length Disaster:  ',1/(1-ParEstimates[bigDataPosInfo$ppC[2]]),'\n')
        cat('Prob Enter Disaster:      ',ParEstimates[bigDataPosInfo$ppW]*ParEstimates[bigDataPosInfo$ppC][3] 
                                          + (1-ParEstimates[bigDataPosInfo$ppW])*ParEstimates[bigDataPosInfo$ppC][1],'\n')
        cat('\n')
        cat('nStateGrid:                    ',controlVarAP$nStateGrid,'\n')
        cat('nStateEps:                     ',controlVarAP$nStateGridEps,'\n')
        cat('nStateZZ:                      ',controlVarAP$nStateGridZZ,'\n')

        cat('nIntGrid:                      ',controlVarAP$nIntGrid,'\n')
        cat('nIntEps:                       ',controlVarAP$nIntGridEps,'\n')
        cat('nIntEta:                       ',controlVarAP$nIntGridEta,'\n')
        cat('nIntTheta:                     ',controlVarAP$nIntGridTheta,'\n')
        cat('nIntPhi:                       ',controlVarAP$nIntGridPhi,'\n')
        cat('nIntNu:                        ',controlVarAP$nIntGridNu,'\n')
        cat('\n')
        sink()
                
        if (controlVarAP$updateDistDis) {
            DistDisasters     <- getDistDisasters(controlVarAP, ParEstimates, bigDataPosInfo, IRlength = 35)
            filename <- file.path(outDir,'DistDisasters.Rda')
            save(DistDisasters, file = filename)
        } else {
            filename <- file.path(outDir,'DistDisasters.Rda')
            load(filename)
        }
        
        PDivs             <- getPDivs_EZW(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)

        outputEZW <- list(allData = allData, controlVarAP = controlVarAP, ParEstimates = ParEstimates,
                          bigDataPosInfo = bigDataPosInfo, PDivs = PDivs)    
        filename <- file.path(outDir,'outputEZW.Rda')
        save(outputEZW, file = filename)           
    } else {   
        timer1 <- proc.time()[3]

        filename <- file.path(outDir,'outputEZW.Rda')
        load(filename)

        allData        <- outputEZW$allData
        controlVarAP   <- outputEZW$controlVarAP
        ParEstimates   <- outputEZW$ParEstimates
        bigDataPosInfo <- outputEZW$bigDataPosInfo
        PDivs          <- outputEZW$PDivs

        controlVarAP$nSim <- 200000

        if (controlVarAP$updateDistDis) {
            DistDisasters     <- getDistDisasters(controlVarAP, ParEstimates, bigDataPosInfo, IRlength = 35)
            filename <- file.path(outDir,'DistDisasters.Rda')
            save(DistDisasters, file = filename)
        } else {
            filename <- file.path(outDir,'DistDisasters.Rda')
            load(filename)
        }

        timer1 <- proc.time()[3] - timer1
        cat('Time to Load:       ',timer1,'\n')    
    }
} else {
    ParEstimates     <- getParEstimates(bigDataPosInfo, controlVarAP)

    filename <- file.path(outDir, "APresults.txt")
    sink(filename)
    cat('\n')
    cat('PARAMETERS\n')
    cat('\n')
    cat('rhoU:                     ',controlVarAP$rhoU,'\n')
    cat('gammaU:                   ',controlVarAP$gammaU,'\n')
    cat('psiU:                     ',controlVarAP$psiU,'\n')
    cat('thetaU:                   ',controlVarAP$thetaU,'\n')
    cat('\n')
    cat('Mu:                       ',ParEstimates[bigDataPosInfo$muPost][controlVarAP$countryToUse],'\n')
    cat('sigmaEps:                 ',ParEstimates[bigDataPosInfo$sigmaEps][controlVarAP$countryToUse],'\n')
    cat('sigmaEta:                 ',ParEstimates[bigDataPosInfo$sigmaEta][controlVarAP$countryToUse],'\n')
    cat('\n')
    cat('pWb:                      ',ParEstimates[bigDataPosInfo$ppW],'\n')
    cat('pCb_NWD:                  ',ParEstimates[bigDataPosInfo$ppC][1],'\n')
    cat('pCb_WD:                   ',ParEstimates[bigDataPosInfo$ppC][3],'\n')
    cat('1-pCe:                    ',ParEstimates[bigDataPosInfo$ppC[2]],'\n')
    cat('rho:                      ',ParEstimates[bigDataPosInfo$rho],'\n')
    cat('meanPhi:                  ',ParEstimates[bigDataPosInfo$meanPhi],'\n')
    cat('meanTheta:                ',ParEstimates[bigDataPosInfo$meanTheta],'\n')
    cat('sigmaPhi:                 ',ParEstimates[bigDataPosInfo$sigmaPhi],'\n')
    cat('sigmaTheta:               ',ParEstimates[bigDataPosInfo$sigmaTheta],'\n')
    cat('\n')
    cat('Average Length Disaster:  ',1/(1-ParEstimates[bigDataPosInfo$ppC[2]]),'\n')
    cat('Prob Enter Disaster:      ',ParEstimates[bigDataPosInfo$ppW]*ParEstimates[bigDataPosInfo$ppC][3] 
                                      + (1-ParEstimates[bigDataPosInfo$ppW])*ParEstimates[bigDataPosInfo$ppC][1],'\n')
    cat('\n')
    cat('nStateGrid:                    ',controlVarAP$nStateGrid,'\n')
    cat('nStateEps:                     ',controlVarAP$nStateGridEps,'\n')
    cat('nStateZZ:                      ',controlVarAP$nStateGridZZ,'\n')

    cat('nIntGrid:                      ',controlVarAP$nIntGrid,'\n')
    cat('nIntEps:                       ',controlVarAP$nIntGridEps,'\n')
    cat('nIntEta:                       ',controlVarAP$nIntGridEta,'\n')
    cat('nIntTheta:                     ',controlVarAP$nIntGridTheta,'\n')
    cat('nIntPhi:                       ',controlVarAP$nIntGridPhi,'\n')
    cat('nIntNu:                        ',controlVarAP$nIntGridNu,'\n')
    cat('\n')
    sink()
    
    if (controlVarAP$updateDistDis) {
        DistDisasters     <- getDistDisasters(controlVarAP, ParEstimates, bigDataPosInfo, IRlength = 35)
        filename <- file.path(outDir,'DistDisasters.Rda')
        save(DistDisasters, file = filename)
    } else {
        filename <- file.path(outDir,'DistDisasters.Rda')
        load(filename)
    }

}

simOutput        <- simulateModel_EZW(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, NoDisasters = 0)
simOutputOnGrid  <- putSimOutputOnStateGrid(simOutput, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)

filename <- file.path(outDir,'simOutput.Rda')
save(simOutput, file = filename)   
filename <- file.path(outDir,'simOutputOnGrid.Rda')
save(simOutputOnGrid, file = filename)   

simOutputNoDis       <- simulateModel_EZW(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, NoDisasters = 1)
simOutputNoDisOnGrid <- putSimOutputOnStateGrid(simOutputNoDis, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)

filename <- file.path(outDir,'simOutputNoDis.Rda')
save(simOutputNoDis, file = filename)   
filename <- file.path(outDir,'simOutputNoDisOnGrid.Rda')
save(simOutputNoDisOnGrid, file = filename)   

simTypDis        <- simulateTypicalDisaster(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)
simTypDisOnGrid  <- putSimOutputOnStateGrid(simTypDis, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)

if (controlVarAP$doEZW) {
    returnsEZW       <- calcReturns(simOutput, simOutputOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)
    returnsNoDisEZW      <- calcReturns(simOutputNoDis, simOutputNoDisOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)
    filename <- file.path(outDir,'returnsEZW.Rda')
    save(returnsEZW, file = filename)   
    filename <- file.path(outDir,'returnsNoDisEZW.Rda')
    save(returnsNoDisEZW, file = filename)   
    filename <- file.path(outDir, "APresults.txt")
    sink(filename, append = TRUE)
    printSummaryStats(returnsEZW, returnsNoDisEZW, controlVarAP, Pref = 1)
    sink()
    saveCAndAPReturnsInTextFile(simOutput, returnsEZW)
    
    plotDiagnostics(simOutput, returnsEZW)
    returnsTypDis    <- calcReturns(simTypDis, simTypDisOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)
    filename <- file.path(outDir, "APresults.txt")
    sink(filename, append = TRUE)
    printSummaryTypDis(simTypDis, returnsTypDis, controlVarAP)
    sink()
    plotTypDis(simTypDis, simTypDisOnGrid, returnsTypDis, Pref = 'EZW')
    saveTypDis(simTypDis, returnsTypDis)
}

if ((controlVarAP$gammaU == 1/controlVarAP$psiU) & controlVarAP$doPowerU) {
    returnsCRRA <- getAssetPricesCRRA(controlVarAP, ParEstimates, bigDataPosInfo, simOutput)
    returnsNoDisCRRA <- getAssetPricesCRRA(controlVarAP, ParEstimates, bigDataPosInfo, simOutputNoDis)
    filename <- file.path(outDir,'returnsCRRA.Rda')
    save(returnsCRRA, file = filename)   
    filename <- file.path(outDir,'returnsNoDisCRRA.Rda')
    save(returnsNoDisCRRA, file = filename)   
    filename <- file.path(outDir, "APresults.txt")
    sink(filename, append = TRUE)
    printSummaryStats(returnsCRRA, returnsNoDisCRRA, controlVarAP, Pref = 2)
    sink()
    
    returnsTypDis    <- getAssetPricesCRRA(controlVarAP, ParEstimates, bigDataPosInfo, simTypDis)
    plotTypDis(simTypDis, simTypDisOnGrid, returnsTypDis, Pref = 'PowerU')
    saveTypDis(simTypDis, returnsTypDis)
    if (controlVarAP$doEZW) plotDiagnosticsEZW_CRRA(simOutput, returnsEZW, returnsCRRA)
}

#EquityPremiumBarroUrsuaFormula(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters)


