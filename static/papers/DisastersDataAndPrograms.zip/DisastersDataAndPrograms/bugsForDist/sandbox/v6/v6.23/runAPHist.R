#####################################################################
## This program creates asset price statistics for our disaster model
##
## Emi Nakamura and Jon Steinsson, December 2008
#####################################################################

rm(list = ls())
gc()

options(digits = 5)

library("arm")
library("BRugs")
library("R2WinBUGS")

source('funcs.R')
source('funcsAgg.R')
source('funcsAP.R')
source('funcsAPHist.R')

dirInfo          <- getDirInfo()
outDir           <- dirInfo$outDir
prefixDir        <- dirInfo$prefixDir
outDirNextState  <- file.path(outDir, 'nextState')
allData          <- readData(prefixDir)
controlVarAP     <- getControlVarAPHist(allData)
modelData        <- getModelData(allData)

NamesNPosInfo    <- getNamesNPosInfo(allData)
parameters       <- NamesNPosInfo$UnobsNames
UnobsPosInfo     <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo   <- getBigDataPosInfo(UnobsPosInfo)

## Load parameter sample
filename <-  file.path(outDir, paste(c('bigDataParams','Rda'),collapse = '.'))
load(filename)

nAPpoints        <- controlVarAP$nAPpoints
vecAPpoints      <- getIterNumbers(nAPpoints)
priorWeight      <- controlVarAP$priorWeight

logEqReturnsVec          <- numeric(nAPpoints)
logEqReturnsNoDisVec     <- numeric(nAPpoints)
logBondReturnsVec        <- numeric(nAPpoints)
logBondReturnsNoDisVec   <- numeric(nAPpoints)
ParVec                   <- matrix(0, ncol = length(bigDataParams[1,]), nrow = nAPpoints) 

filename <- file.path(outDir,'DistDisasters.Rda')
load(filename)

ii <- 1
while (ii <= nAPpoints) {
    timer2 <- proc.time()[3]

    if (controlVarAP$priorPostAP == 0) {
        ParEstimates     <- getPriorDraw(vecAPpoints[ii], modelData, bigDataPosInfo)    
    } else {
        ParEstimates     <- getPosteriorDraw(vecAPpoints[ii], bigDataPosInfo)    
    }

    ParVec[ii,]          <- ParEstimates
    
    PDivs                <- getPDivs_EZW(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, printStuff = 0)
    
    if (length(PDivs) > 1) {
    
        simOutput            <- simulateModel_EZW(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, NoDisasters = 0, printStuff = 0)
        simOutputOnGrid      <- putSimOutputOnStateGrid(simOutput, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, printTime = 0)

        simOutputNoDis       <- simulateModel_EZW(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, NoDisasters = 1, printStuff = 0)
        simOutputNoDisOnGrid <- putSimOutputOnStateGrid(simOutputNoDis, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, printTime = 0)

        returnsEZW           <- calcReturns(simOutput, simOutputOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, printTime = 0)
        returnsNoDisEZW      <- calcReturns(simOutputNoDis, simOutputNoDisOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, printTime = 0)

        #printSummaryStats(returnsEZW, returnsNoDisEZW, controlVarAP, Pref = 1)
        

        logEqReturnsVec[ii]        <- log(mean(returnsEZW$Equity$Return[2:controlVarAP$nSim]))
        logEqReturnsNoDisVec[ii]   <- log(mean(returnsNoDisEZW$Equity$Return[2:controlVarAP$nSim]))
        logBondReturnsVec[ii]      <- log(mean(returnsEZW$OnePerBond$Return[2:controlVarAP$nSim]))
        logBondReturnsNoDisVec[ii] <- log(mean(returnsNoDisEZW$OnePerBond$Return[2:controlVarAP$nSim]))
        
        ii <- ii + 1

        timer2 <- proc.time()[3] - timer2
        cat(timer2,' ')
        if (ii %% 10 == 0) cat('\n',ii,' ')    
    }    
}
cat('\n')

outputDistAP <- list(allData = allData, controlVarAP = controlVarAP, ParVec = ParVec, 
                     logEqReturns = logEqReturnsVec, logEqReturnsNoDis = logEqReturnsNoDisVec,
                     logBondReturns = logBondReturnsVec, logBondReturnsNoDis = logBondReturnsNoDisVec)    
filename <- file.path(outDir,'outputDistAP.Rda')
save(outputDistAP, file = filename)           

createGewekePlots(outputDistAP, controlVarAP, bigDataPosInfo)
createHistAP(outputDistAP)