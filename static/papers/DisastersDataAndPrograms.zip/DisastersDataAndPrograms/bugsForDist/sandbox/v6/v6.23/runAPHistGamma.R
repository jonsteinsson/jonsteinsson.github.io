#####################################################################
## This program creates asset price statistics for our disaster model
##
## Emi Nakamura and Jon Steinsson, December 2008
#####################################################################

rm(list = ls())
gc()

library("arm")
library("BRugs")
library("R2WinBUGS")
library("msm")

source('funcs.R')
source('funcsAgg.R')
source('funcsAP.R')
source('funcsAPHistGamma.R')

options(digits = 5)

dirInfo          <- getDirInfo()
outDir           <- dirInfo$outDir
prefixDir        <- dirInfo$prefixDir
outDirNextState  <- file.path(outDir, 'nextState')
allData          <- readData(prefixDir)
controlVarAP     <- getControlVarAPHistGamma(allData)
modelData        <- getModelData(allData)

NamesNPosInfo    <- getNamesNPosInfo(allData)
parameters       <- NamesNPosInfo$UnobsNames
UnobsPosInfo     <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo   <- getBigDataPosInfo(UnobsPosInfo)

## Load parameter sample
filename <-  file.path(outDir, paste(c('bigDataParams','Rda'),collapse = '.'))
load(filename)

filename <- file.path(outDir,'DistDisasters.Rda')
load(filename)

nAPpoints        <- controlVarAP$nAPpoints
vecAPpoints      <- getIterNumbers(nAPpoints)
priorWeight      <- controlVarAP$priorWeight

gammaVec         <- numeric(nAPpoints)
ParVec           <- matrix(0, ncol = length(bigDataParams[1,]), nrow = nAPpoints) 

filename <- file.path(outDir,'DistDisasters.Rda')
load(filename)

ii <- 1
while (ii <= nAPpoints) {
    timer2 <- proc.time()[3]
    
    cat(ii,' ')
    
    if (controlVarAP$priorPostAP == 0) {
        ParEstimates <- getPriorDraw(vecAPpoints[ii], modelData, bigDataPosInfo)    
    } else {
        ParEstimates <- getPosteriorDraw(vecAPpoints[ii], bigDataPosInfo)    
    }
    #ParEstimates     <- getParEstimates(bigDataPosInfo, controlVarAP)
    #printParEstimates(controlVarAP,ParEstimates)
    
    ParVec[ii,]      <- ParEstimates

    simOutput        <- simulateModel_EZW(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, NoDisasters = 0, printStuff = 0)
    simOutputOnGrid  <- putSimOutputOnStateGrid(simOutput, controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, printTime = 0)
        
    gammaVec[ii]     <- EstGamma(controlVarAP, ParEstimates, bigDataPosInfo, DistDisasters, simOutput, simOutputOnGrid, printStuff = 1)

    ii <- ii + 1

    timer2 <- proc.time()[3] - timer2
    cat(' ',timer2,'\n')
}
cat('\n')

outputDistAP <- list(allData = allData, controlVarAP = controlVarAP, ParVec = ParVec, gammaVec = gammaVec)    
filename <- file.path(outDir,'outputDistAP.Rda')
save(outputDistAP, file = filename)           

createHistAP(outputDistAP)