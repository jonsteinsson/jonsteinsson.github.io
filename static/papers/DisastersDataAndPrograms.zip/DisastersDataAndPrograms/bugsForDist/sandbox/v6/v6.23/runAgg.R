#####################################################################
# This program aggregates many runs to create accurate estimates of 
# model's parameters
#
# Emi Nakamura and Jon Steinsson, July 2008
#####################################################################

rm(list = ls())
gc()

library("arm")
library("msm")

source('funcs.R')
source('funcsAgg.R')

options(digits = 6)

dirInfo       <- getDirInfo()
outDir        <- dirInfo$outDir
prefixDir     <- dirInfo$prefixDir
allData       <- readData(prefixDir)

controlVar    <- getControlVar()
controlAgg    <- getControlAgg()

NamesNPosInfo <- getNamesNPosInfo(allData)
parameters    <- NamesNPosInfo$UnobsNames
UnobsPosInfo  <- NamesNPosInfo$UnobsPosInfo

runsToUse     <- getRunsToUse()

bigDataPosInfo <- getBigDataPosInfo(UnobsPosInfo)

if (controlAgg$createNewData) combineRuns(UnobsPosInfo, bigDataPosInfo, runsToUse)

simSummaryDisasterParMulti(bigDataPosInfo)
simSummaryCountryParMulti(allData,bigDataPosInfo)
simPlotMany(allData, bigDataPosInfo, controlAgg$fullPlot)
plotTypicalDisasterImpulseResponseMany(allData, bigDataPosInfo, IRlength = 20, disLength = 6)
plotDistributionDisasterImpulseResponseMany(allData, bigDataPosInfo, IRlength = 25)
dEps <- getDisasterEpisodesMany(allData, bigDataPosInfo, controlAgg)
printDisasterEpisodesMany(dEps)
