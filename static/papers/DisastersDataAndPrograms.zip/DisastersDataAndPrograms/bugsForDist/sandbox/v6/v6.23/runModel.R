#######################################################
## This program runs the disaster model on consumption 
## data in Winbugs
##
## Emi Nakamura and Jon Steinsson, March 2008
#######################################################

rm(list = ls())
gc()

library("arm")

source('funcs.R')

#setwd('d:/mydocs/Research/2007/Consumption Disasters/DisastersDataAndPrograms/bugsForDist/sandbox/v6/v6.23')

# Define variables with directory information (second function in funcs.R)
dirInfo       <- getDirInfo()
outDir        <- dirInfo$outDir
prefixDir     <- dirInfo$prefixDir

# Define controlVar (see first function in funcs.R)
controlVar <- getControlVar()

# Import data to be used for estimation
if (controlVar$useRealData) {
    allData       <- readData(prefixDir)
} else {
    allData      <- SimFullDataSetNoDisasters()
}

# Load data to be inputed into bugs (fourth function in funcs.R)
modelData    <- getModelData(allData)
bugs.data(modelData, data.file = "modelData.txt")

# Load variables that contain parameter names and information 
# about their position in the parameter vector
NamesNPosInfo<- getNamesNPosInfo(allData)
parameters   <- NamesNPosInfo$UnobsNames
UnobsPosInfo <- NamesNPosInfo$UnobsPosInfo

timer <- list(bugs = 0, save = 0, plot = 0, temp = 0, total = 0)

timer$total <- proc.time()[3]

if (controlVar$noRun != 1) {
    # The model is estimated in batches. Each batch is one iteration of this for-loop
    for (ii in controlVar$nFirstRun:(controlVar$nFirstRun+controlVar$NRuns-1)) {
        # If the first batch has nFirstRun==1, program allows the the user to specify 
        # whether to draw new initial values or to get initial values from a saved file
        # For all subsequent batches, the initial values will be gotten from a file.
        # This file is created below and contains the last values from the preceeding batch.
        if (ii == 1) {
            ## Get Initial Values
            if (controlVar$newInit == 1) {
                initialValues <- getNewInitialValues(allData, UnobsPosInfo, controlVar)
            } else {
                initialValues <- getSavedInitialValues(outDir)
            }
        } else {
            initialValues <- getSavedInitialValues(outDir)
        }
        
        ## Run bugs
        timer$temp <- proc.time()[3]
        codafile <- bugs("modelData.txt", initialValues, parameters,
                         model.file = "disastermodel.bug", digits = 7,
                         n.chains = length(initialValues), 
                         n.iter = controlVar$Niter, 
                         n.burnin = controlVar$NinitBurnin, 
                         n.thin = controlVar$NinitThin,
                         bugs.directory = "c:/Program Files/WinBUGS14/",
                         codaPkg = TRUE, bugs.seed = controlVar$seedForBugs)
        cat('1 ')
        bugsSim <- read.bugs(codafile, quiet = TRUE)
        cat('2 ')
        #browser()
        gc() #gc(verbose = TRUE)
        timer$bugs <- proc.time()[3] - timer$temp
        timer$temp <- proc.time()[3]
    
        ## Save Output
        tempPrint <- paste(c(controlVar$priorType,controlVar$nOfChain),collapse = '')
        filename <-  file.path(outDir, paste(c('bugsSimSave',tempPrint,ii,'Rda'),collapse = '.'))
        save(bugsSim, file = filename)
        
        ## Save Initial Values
        bugsSimInit <- saveLastValues(UnobsPosInfo,ii, filename)
        
        #rm(bugsSim)
        timer$save <- proc.time()[3] - timer$temp
        cat('timer$bugs = ',timer$bugs,' timer$save = ',timer$save,'\n')
        gc() #gc(verbose = TRUE) #gc(verbose = TRUE, reset = TRUE)
        
        cat('\n')
    
    }
}

timer$total <- proc.time()[3] - timer$total
cat('timer$total = ',timer$total,'\n')