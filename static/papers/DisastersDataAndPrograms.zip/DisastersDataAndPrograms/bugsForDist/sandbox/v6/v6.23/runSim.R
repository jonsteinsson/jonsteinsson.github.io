#####################################################################
## This program simulates data from the estimated disaster model
## and calculates various statistics on the simulate data
##
## Emi Nakamura and Jon Steinsson, June 2009
#####################################################################

rm(list = ls())
gc()

options(digits = 5)

library("arm")
library("msm")

source('funcs.R')
source('funcsAgg.R')
source('funcsAP.R')
source('funcsSim.R')

dirInfo       <- getDirInfo()
outDir        <- dirInfo$outDir
prefixDir     <- dirInfo$prefixDir
allData       <- readData(prefixDir)

controlVarSim <- getControlVarSim(allData)

NamesNPosInfo    <- getNamesNPosInfo(allData)
parameters       <- NamesNPosInfo$UnobsNames
UnobsPosInfo     <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo   <- getBigDataPosInfo(UnobsPosInfo)

ParEstimates     <- getParEstimatesSim(bigDataPosInfo)

cat('\n')
cat('PARAMETERS\n')
cat('\n')
cat('Mu:                       ',ParEstimates[bigDataPosInfo$muPost][1],'\n')
cat('sigmaEps:                 ',ParEstimates[bigDataPosInfo$sigmaEps][1],'\n')
cat('sigmaEta:                 ',ParEstimates[bigDataPosInfo$sigmaEta][1],'\n')
cat('pWb:                      ',ParEstimates[bigDataPosInfo$ppW],'\n')
cat('pCb_NWD:                  ',ParEstimates[bigDataPosInfo$ppC][1],'\n')
cat('pCb_WD:                   ',ParEstimates[bigDataPosInfo$ppC][3],'\n')
cat('1-pCe:                    ',ParEstimates[bigDataPosInfo$ppC][2],'\n')
cat('rho:                      ',ParEstimates[bigDataPosInfo$rho],'\n')
cat('meanPhi:                  ',ParEstimates[bigDataPosInfo$meanPhi],'\n')
cat('meanTheta:                ',ParEstimates[bigDataPosInfo$meanTheta],'\n')
cat('sigmaPhi:                 ',ParEstimates[bigDataPosInfo$sigmaPhi],'\n')
cat('sigmaTheta:               ',ParEstimates[bigDataPosInfo$sigmaTheta],'\n')
cat('\n')
cat('Average Length Disaster:  ',1/(1-ParEstimates[bigDataPosInfo$ppC][2]),'\n')
cat('Prob Enter Disaster:      ',ParEstimates[bigDataPosInfo$ppW]*ParEstimates[bigDataPosInfo$ppC][3] 
                                  + (1-ParEstimates[bigDataPosInfo$ppW])*ParEstimates[bigDataPosInfo$ppC][1],'\n')
cat('\n')

cat('Probability of no world disaster over 1946-2006:   ',dbinom(0,61,ParEstimates[bigDataPosInfo$ppW]),'\n\n')

## Single Country Stuff

if (controlVarSim$doSimSingleCountry) {
        
    statsSingleCountry <- getStatsForSingleCountry(ParEstimates, bigDataPosInfo, controlVarSim) 
    
    cat('Probability of no disaster for a single country over 1935-2006: ',statsSingleCountry$fracNoDis,'\n')
    cat('Probability of no world disaster over 1935-2006:                ',statsSingleCountry$fracNoWDis,'\n\n')
}

## Multi Country Stuff

if (controlVarSim$doSimMultiCountry) {
        
    statsMultiCountry <- getStatsForMultiCountry(ParEstimates, bigDataPosInfo, controlVarSim) 
    
    cat('Probability that at least one country has no disaster over 1935-2006: ',statsMultiCountry$fracSomeCountryNoDis,'\n')
    cat('Probability of no world disaster over 1935-2006      :                ',statsMultiCountry$fracNoWDis,'\n\n')
}

## Single Country Long Stuff

if (controlVarSim$doSimSingleCountryLong) {
        
    statsSingleCountryLong <- getStatsForSingleCountryLong(ParEstimates, bigDataPosInfo, controlVarSim) 

    cat('Mean consumption growth during disasters:                  ',statsSingleCountryLong$meanDCCDis,'\n')
    cat('Standard deviation of consumption growth during disasters: ',statsSingleCountryLong$stdDCCDis,'\n')
    cat('Mean fall in consumption Begining to End (levels)          ',mean(statsSingleCountryLong$DCBeginEnd),'\n')
    cat('St.dev fall in consumption Begining to End (levels)        ',var(statsSingleCountryLong$DCBeginEnd)^(1/2),'\n\n')
}
