#####################################################################
# This program calculates simple statistics for the data and the model
#
# Emi Nakamura and Jon Steinsson, September 2012
#####################################################################

rm(list = ls())
gc()

options(digits = 5)

library("arm")
library("msm")

source('funcs.R')
source('funcsAgg.R')
source('funcsAP.R')
source('funcsStats.R')

dirInfo          <- getDirInfo()
outDir           <- dirInfo$outDir
prefixDir        <- dirInfo$prefixDir
outDirNextState  <- file.path(outDir, 'nextState')
allData          <- readData(prefixDir)

controlVarAP     <- getControlVarAP(allData)

NamesNPosInfo    <- getNamesNPosInfo(allData)
parameters       <- NamesNPosInfo$UnobsNames
UnobsPosInfo     <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo   <- getBigDataPosInfo(UnobsPosInfo)

ParEstimates     <- getParEstimates(bigDataPosInfo, controlVarAP)

DistDisasters    <- getDistDisasters(controlVarAP, ParEstimates, bigDataPosInfo, IRlength = 35)

RWDistDisasters  <- getRWDistDisasters(allData)

plot(as.ts(DistDisasters$medianCC[1:11]),ylim = c(-0.3,0.2))
lines(as.ts(RWDistDisasters$medianCC), col = 2)
lines(as.ts(DistDisasters$q25CC[1:11]), col = 3)
lines(as.ts(DistDisasters$q75CC[1:11]), col = 3)

temp.output <- cbind(RWDistDisasters$medianCC[1:11], RWDistDisasters$q25CC[1:11], RWDistDisasters$q75CC[1:11],
                DistDisasters$medianCC[1:11], DistDisasters$q25CC[1:11], DistDisasters$q75CC[1:11])
colnames(temp.output) <- c('RWmedian','RWq25','RWq75','modelmedian','modelq25','modelq75')
filename <-  file.path(outDir, 'PathDuringDisasters.txt')  
write.table(temp.output, file = filename)

