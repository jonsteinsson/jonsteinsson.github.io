
*Program to analyze relationship between consumption and stock market drops in asset pricing data

clear
set memory 300000


local dir1 "d:\mydocs\disasters_barro\stata\data_assets\"
local dir2 "d:\mydocs\disasters_barro\stata\simulations\"
local dir3 "d:\mydocs\disasters_barro\stata\working\"
local dir4 "d:\mydocs\disasters_barro\stata\stataoutput\"


set logtype text
log using `dir4'disasterpropertiesb, replace


******************************************************************
*REAL DATA

*Analyze the properties of stock vs bond returns during disasters
use `dir3'xallcrashes_med, clear
drop if country_acnym =="VE"

*Compare stock and bond returns for cases where consumption drop is greater than 0.17
*How many episodes?
tab  country_acnym if  DCPCINX_bdc<-0.17  &  DCPCINX_bdc ~=0

*Cases where stock returns are less than bond returns
summ  DRTB_bstock DRB10Y_bstock DRSTOCK_bstock if  DCPCINX_bdc<-0.17 & DRTB_bstock~=. & DRSTOCK_bstock~=. &  DRSTOCK_bstock < DRTB_bstock

*List episodes
list country_acnym time_bstock DRSTOCK_bstock DRTB_bstock DDP_bstock time_bdc DCPCINX_bdc if  DCPCINX_bdc<-0.17 & DRTB_bstock~=. & DRSTOCK_bstock~=. &  DRSTOCK_bstock < DRTB_bstock, noobs clean

*Cases where bond returns are less than stock returns
summ  DRTB_bstock DRB10Y_bstock DRSTOCK_bstock if  DCPCINX_bdc<-0.17 & DRTB_bstock~=. & DRSTOCK_bstock~=. &  DRSTOCK_bstock >= DRTB_bstock

*List episodes
list country_acnym time_bstock DRSTOCK_bstock DRTB_bstock DDP_bstock time_bdc DCPCINX_bdc if DCPCINX_bdc<-0.17 & DRTB_bstock~=. & DRSTOCK_bstock~=. &  DRSTOCK_bstock >= DRTB_bstock, noobs clean


********************************************************************
*SIMULATED DATA
use `dir3'simallcrashes, clear

*Compare stock and bond returns for cases where consumption drop is greater than 0.17

*Cases where stock returns are less than bond returns
summ  DROnePerBond_REquity DRPerpetuity_REquity DREquity_REquity if  DCC_CC<-0.17 & DREquity_REquity~=. & DROnePerBond_REquity~=. &  DREquity_REquity < DROnePerBond_REquity

*Cases where bond returns are less than stock returns
summ  DROnePerBond_REquity DRPerpetuity_REquity DREquity_REquity if  DCC_CC<-0.17 & DREquity_REquity~=. & DROnePerBond_REquity~=. &  DREquity_REquity >= DROnePerBond_REquity


*Mean size of consumption disasters, temporary and permanent effects
summ  DCC_CC if DCC_CC<-0.17 
summ  DXX_CC if DCC_CC<-0.17 
summ  DZZ_CC if DCC_CC<-0.17 



log close
