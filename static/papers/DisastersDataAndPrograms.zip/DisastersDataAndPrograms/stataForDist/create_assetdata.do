
*Program to read disasters asset pricing data

clear
set memory 300000
set more off

local dir1 "d:\mydocs\disasters_barro\stata\data_assets\"
local dir1b "d:\mydocs\disasters_barro\stata\data_consump\"
local dir2 "d:\mydocs\disasters_barro\stata\simulations\"
local dir3 "d:\mydocs\disasters_barro\stata\working\"


*Read in asset pricing data
insheet using `dir1'stockdata.csv, clear case
rename v1 year
sort year
save `dir3'stockdata, replace

insheet using `dir1'bonddata.csv, clear case
sort year
save `dir3'bonddata, replace

*Merge stock and bond data
merge year using `dir3'stockdata
drop _merge
sort year
save `dir3'stockandbond, replace
reshape long RTB RB10Y DP RSTOCK, i(year) j(country_acnym) string

bysort country: egen temp = mean(RSTOCK)
gen hasstocks = 1 if temp~=.
replace hasstocks=0 if temp==.
drop temp

sort country_acnym year
save `dir3'stockandbond2, replace

*Read in timing of stock crashes
insheet using `dir1'data_crashperiods.csv, clear
save `dir3'data_crashperiods, replace

insheet using `dir1'country_acnym.csv, clear names
sort country
save `dir3'country_acnym, replace

*Merge crash periods with acronyms
use `dir3'data_crashperiods, clear
sort country
merge country using `dir3'country_acnym
drop _merge

*Create crash number
sort country_acnym timedepr time_bstock
by country_acnym: gen crashnum = _n
save `dir3'data_crashperiods, replace

*Create start and end dates of crashes
rename timedepr time_depress

foreach var of varlist time_bstock  time_bdc time_bdy time_depress {
	gen `var'1 = real(substr(`var', 1, 4))
	gen `var'2 = real(substr(`var', -4, 4))
	drop `var'
	}

sort country_acnym	crashnum
save `dir3'data_crashperiods2, replace	


*Reshape dataset
reshape long time_bstock  time_bdc time_bdy time_depress, i(country_acnym crashnum) j(crashdate)
sort country_acnym	crashnum crashdate
save `dir3'data_crashperiods3, replace	


foreach var of varlist bstock  bdc bdy depress {
	use `dir3'data_crashperiods3, clear
	keep  country_acnym crashnum crashdate time_`var' `var'
	rename time_`var' year
	
	*Drop missing values
	drop if year==.

	*Separate immediately consecutive crashes
	gen yearhalf =0
	egen countrynum = group(country_acnym)
	sort countrynum year crashnum 
	by countrynum: gen year2 = _n
	tsset countrynum year2
	replace yearhalf = 1 if year==L.year	
	drop countrynum year2
	
	drop if year==.
	sort country_acnym year yearhalf
	save `dir3'tempdata_`var', replace
	}


*Read in consumption data
insheet using `dir1b'consumptiondata.csv, clear case
sort year
save `dir3'consumptiondata, replace

insheet using `dir1b'outputdata.csv, clear case
sort year
save `dir3'outputdata, replace

merge year using `dir3'consumptiondata
sort year
drop _merge
save `dir3'candydata, replace

reshape long CPCINX YPCINX, i(year) j(country_acnym) string
sort country_acnym year
save `dir3'candydata2, replace

*Merge everything together
merge country_acnym year using `dir3'stockandbond2
drop _merge

*Create indexes for stocks, bonds etc.
egen countrynum = group(country_acnym)
sort countrynum year 
tsset countrynum year

foreach var of varlist  RTB RB10Y DP RSTOCK {
	gen tempreturn  = 0
	replace tempreturn  = log(1 + `var') if `var' ~=.
	sort country_acnym year 
	by country_acnym: gen index`var' = sum(tempreturn)
	replace index`var' = exp(index`var')
	tsset countrynum year
	replace index`var' = . if `var'==. & F.`var' ==.
	drop tempreturn
	}


*Create two observations for each year (to accomodate consecutive crashes)
gen yearhalf =0
sort country_acnym year
save `dir3'temp1, replace

replace yearhalf =1
sort country_acnym year
append using `dir3'temp1
sort country_acnym year

foreach name in  bstock bdc bdy depress{
	sort country_acnym year yearhalf
	merge country_acnym year yearhalf  using `dir3'tempdata_`name'
	rename crashdate crashdate_`name'
	rename crashnum crashnum_`name'
	drop _merge
	drop if year==.

	}

sort countrynum year yearhalf
by countrynum: gen year2 = _n
tsset countrynum year2
save `dir3'alldata, replace

*Create dataset including consumption, output and nominal data
keep if yearhalf==1
foreach var of varlist RTB RB10Y RSTOCK {
	gen `var'_nom = (1+`var') * (1+DP) - 1
	gen index`var'_nom = `var'*  indexDP
	}

save `dir3'alldata_nom, replace

keep  year country_acnym YPCINX CPCINX RTB RB10Y DP RSTOCK indexRTB indexRB10Y indexDP indexRSTOCK RTB_nom indexRTB_nom RB10Y_nom indexRB10Y_nom RSTOCK_nom indexRSTOCK_nom

reshape wide R* index* YPCINX CPCINX DP, i(year) j(country_acnym) string

outsheet using `dir3'aggvars_withnom, comma replace



*Calculate declines over crashes
use `dir3'alldata, clear
foreach var of varlist bstock bdc bdy depress {
	use `dir3'alldata, clear
	keep  year year2 country_acnym YPCINX CPCINX countrynum indexRTB indexRB10Y indexDP indexRSTOCK yearhalf crashnum_`var' crashdate_`var' `var'

	keep if crashnum_`var'~=.
	egen unique = group(country_acnym crashnum_`var')
	sort unique year2
	by unique: gen time = _n
	tsset unique time
	
	foreach name in RTB RB10Y DP RSTOCK {
		gen D`name'_`var' = (index`name' / L.index`name') -1
		}
	
	foreach name in YPCINX CPCINX {
		gen D`name'_`var' = (`name' / L.`name') -1
		}

	
	foreach name2 in RSTOCK RTB RB10Y {
		gen D`name2'_nom_`var' = ((1+D`name2'_`var')  * (1+ DDP_`var')) - 1
		}
	
		keep  year country_acnym countrynum indexRTB indexRB10Y indexDP indexRSTOCK yearhalf crashnum_`var' crashdate_`var' `var' D*
		
		*Drop variables for final dataset
		keep if crashdate_`var' ==2
		drop index* yearhalf crashdate*
		
		rename crashnum_`var' crashnum
		sort country_acnym crashnum
		save `dir3'xcrash_`var', replace
		
	}

use `dir3'xcrash_bstock
foreach name in  bdc bdy depress {
	merge country_acnym crashnum using `dir3'xcrash_`name'
	drop _merge
	sort country_acnym crashnum
	}
	
save `dir3'xallcrashes, replace	


*Merge with crashdates file
use `dir3'data_crashperiods, clear
keep country_acnym crashnum time*
sort country_acnym crashnum
save `dir3'crashnames, replace

use `dir3'xallcrashes, clear
sort country_acnym crashnum
merge country_acnym crashnum using `dir3'crashnames
drop if _merge==2
drop _merge

gen eqprem_bstock = DRSTOCK_bstock - DRTB_bstock
gen eqprem_nom_bstock = DRSTOCK_nom_bstock - DRTB_nom_bstock


save `dir3'xallcrashes, replace	

keep year country_acnym countrynum crashnum bstock bdc bdy depress DRTB_bstock DRB10Y_bstock DDP_bstock DRSTOCK_bstock DRSTOCK_nom_bstock  DRTB_nom_bstock DRB10Y_nom_bstock DCPCINX_bdc DYPCINX_bdy eqprem* time*

save `dir3'xallcrashes_med, replace	

outsheet using `dir3'crashrealdata, comma replace

keep year country_acnym countrynum crashnum bstock bdc bdy depress DRTB_bstock DRB10Y_bstock DDP_bstock DRSTOCK_bstock DRSTOCK_nom_bstock DRTB_nom_bstock DRB10Y_nom_bstock DCPCINX_bdc DYPCINX_bdy eqprem* 

save `dir3'xallcrashes_small, replace	
