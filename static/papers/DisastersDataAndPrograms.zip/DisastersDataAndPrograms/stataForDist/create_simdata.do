
*Program to read disasters asset pricing data

clear
set memory 300000
set more off

local dir1 "d:\mydocs\disasters_barro\stata\data_assets\"
local dir2 "d:\mydocs\disasters_barro\stata\simulations\"
local dir3 "d:\mydocs\disasters_barro\stata\working\"


*Read in asset pricing data
insheet using `dir2'CAndAPReturns.txt, clear case delimiter(" ")

rename CC v1
rename II v2
rename EquityR v3
rename EquityPDiv v4
rename OnePerBondR v5
rename OnePerBondPDiv v6
rename PerpetuityR v7
rename PerpetuityPDiv v8
rename XX v9
rename ZZ v10


rename v1 year
rename v2 CC
rename v3 II
rename v4 REquity
rename v5 EquityPDiv
rename v6 ROnePerBond
rename v7 OnePerBondPDiv
rename v8 RPerpetuity
rename v9 PerpetuityPDiv
rename v10 XX
rename v11 ZZ


sort year
save `dir3'simdata, replace

*Make returns into numeric variables
foreach var of varlist REquity ROnePerBond RPerpetuity {
	gen temp  = real(`var')
	drop `var'
	gen `var' = temp - 1
	drop temp
	}

*Create countries
gen year2 = mod(year,200)
gen country = (year- year2)/200 + 1
sort country year2

*Create indexes
foreach var of varlist  REquity ROnePerBond RPerpetuity {
	gen tempreturn  = 0
	replace tempreturn  = log(1 + `var') if `var' ~=.
	sort country year 
	by country: gen index`var' = sum(tempreturn)
	replace index`var' = exp(index`var')
	tsset country year
	replace index`var' = . if `var'==. & F.`var' ==.
	drop tempreturn
	}

*Create a panel
tsset country year2

*Consumption disasters
*Define beginning and end of consumption disasters
gen crashdate_CC=.
replace crashdate_CC =1 if (II==0 & F.II==1)
replace crashdate_CC =2 if (II==1 & F.II==0)

*Stock disasters
gen crashdate_REquity=.
replace crashdate_REquity =1 if (II==0 & F.II==1)

gen tempdiff = .
gen tempdiff2 = .
gen length = .


foreach num of numlist 1(1)8 {
	gen temp = `num'
	
	replace tempdiff = F`num'.indexREquity - indexREquity 
	replace length = temp if tempdiff <tempdiff2
	replace tempdiff2 = tempdiff if tempdiff < tempdiff2	
	

	drop temp
	}

drop temp*
replace length = . if crashdate_REquity ~=1

foreach num of numlist 1(1)8 {
		replace crashdate_REquity = 2 if (L`num'.length == `num' & country ==L.country)
}

*Create crashnum variable

foreach var of varlist CC REquity {
	gen tempind=0
	replace tempind=1 if crashdate_`var' ==1
	sort country year2
	by country: gen crashnum_`var' = sum(tempind)
	drop temp*

}


save `dir3'allsim, replace	
	
*Calculate declines over crashes
foreach var of varlist CC REquity {
	use `dir3'allsim, clear
	
	keep year CC II XX ZZ REquity ROnePerBond RPerpetuity year2 country indexREquity indexROnePerBond indexRPerpetuity crashdate_`var' crashnum_`var'
	
	
	keep if crashdate_`var'~=.
	
	egen unique = group(country crashnum_`var')
	sort unique year2
	by unique: gen time = _n
	tsset unique time	
	
	foreach name in  REquity ROnePerBond RPerpetuity {
		gen D`name'_`var' = (index`name' / L.index`name') -1 
		}
	
	foreach name in CC XX ZZ {
		gen D`name'_`var' = (exp(`name') / exp(L.`name')) -1
		}
		

		*Drop variables for final dataset
		keep if crashdate_`var' ==2
		drop index* crashdate* 
		
		rename crashnum_`var' crashnum
		sort country crashnum
		save `dir3'simcrash_`var', replace		
	}

use `dir3'simcrash_REquity
foreach var of varlist CC REquity {
	merge country crashnum using `dir3'simcrash_`var'
	drop _merge
	sort country crashnum
	}
	
foreach var of varlist D* {	
	drop if 	`var'==.
	}

drop R*

gen eqprem_REquity = DREquity_REquity - DROnePerBond_REquity

save `dir3'simallcrashes, replace	

outsheet using `dir3'crashsimdata, comma replace

