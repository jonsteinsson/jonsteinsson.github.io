
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 	THIS DOFILE: Indentify sample of DESCENDANTS, who are		********
******** 				 theyr parents, and generate dataset			********
********************************************************************************



*cd "C:\Mal6_2015\Empirical\Descendants\Matching"
cd "${data_dir}"

clear


*===============================
*		LOAD IN OUTCOME DATA
*===============================

* Import dataset
insheet using Gagnasett1.csv, delimiter(";")

* Rename
rename id_einstaklingur id_kt
rename tekjur year
rename kyn gender_now
gen female_now = 0
replace female_now = 1 if gender_now == 2
rename aldur age_now
gen age_now2 = age_now*age_now
rename hjskapur_skattur marital_status
gen married_now = 0
replace married_now = 1 if marital_status == 3
gen nr_children = 0
replace nr_children = fjldi_barna_yngri + fjldi_barna_eldri if fjldi_barna ==.
replace nr_children = fjldi_barna if fjldi_barna !=.


sort id_kt year

* Count number of unique ID
by id_kt, sort: gen nvals = _n == 1
count if nvals

* Save data as Stata data
drop nvals
save data_outcomes.dta, replace



*==============================================
*	LOAD IN CPI INDEX AND MERGE TO OUTCOMES
*==============================================
clear
import excel "${data_dir}/cpi.xlsx", sheet("Sheet1") firstrow
save cpi.dta, replace

*** MERGE TO OUTCOMES
clear
use data_outcomes.dta
merge m:1 year using cpi.dta
drop _merge

save data_outcomes.dta, replace





*===========================================
*	SAMPLE: INHABITANTS OF WESTMAN ISLAND
*===========================================
clear
insheet using Gagnasett2.csv, delimiter(";")

*** rename
rename id_einstaklingur id_kt
rename moved family_moved
sort id_kt

*** MERGE information about missing status
merge 1:1 id_kt using missing.dta
drop _merge


*** Generate variables
gen female = 0
replace female = 1 if gender == 2 | gender == 4

gen adult = 0
replace adult = 1 if gender == 1 | gender == 2

gen child = 0
replace child = 1 if gender == 3 | gender == 4

gen adult_age = age if gender == 1 | gender == 2
gen child_age = age if gender == 3 | gender == 4
 
gen married = 0
replace married = 1 if marital == 3
gen widow = 0
replace widow = 1 if marital == 4
gen divorsed = 0
replace divorsed = 1 if marital == 5 | marital == 6

* Dummy for moving to a new house after 1960
destring family_moved, replace
gen change_house = 0
replace change_house = 1 if family_moved >= 600

* Dummy for being born in the Westman Islands
destring place_of_birth, replace
gen born_west = 0
replace born_west = 1 if place_of_birth == 80


*** Drop descendants - do not have a destroyed "status"
keep if destroyed !=.


* Save data as Stata data
save sample_westman.dta, replace
clear




*** Merge Inhabitants to outcomes - determine of they moved or not
clear
use data_outcomes.dta

merge m:1 id_kt using sample_westman.dta
drop if _merge != 3
drop _merge
sort id_kt year

*** Only look during the first year in the data - determine if moved or not
by id_kt, sort: gen nvals = _n == 1
count if nvals


* Moved status
gen moved = 0 if sveitarflag_nr_sk == 8000 & nvals == 1   /* Municipality 8000 is Westman Islands */
replace moved = 1 if sveitarflag_nr_sk != 8000 & nvals == 1 
replace moved = moved[_n-1] if id_kt == id_kt[_n-1]       /* Keep the same moving status throughout the sample */


* GENERATE ID FOR MATCHING WITH DESCENDANTS
gen id_match = id_kt


gen earnings = launatekjur + reikna_endurgjald
gen total_income = launatekjur + reikna_endurgjald + arartekjur + fjrmagnstekjur
gen net_wealth = eignir_alls - skuldir
gen net_housing_wealth = fasteignir - skuldir_barkaupa

* Transfer payments
gen pension = gr_r_lfeyrissji
gen gov_transfers = arartekjur - pension

gen receiving_transfers = 0
replace receiving_transfers = 1 if earnings == 0 & receiving_transfers != 0


* Generate real varialbles - in 2014 prices
gen real_earnings = (earnings/cpi)*cpi2014
gen real_income = (total_income/cpi)*cpi2014
gen real_assets = (eignir_alls/cpi)*cpi2014
gen real_house = (fasteignir/cpi)*cpi2014
gen real_financial = (fjrmagnstekjur/cpi)*cpi2014
gen real_otherincome = (arartekjur/cpi)*cpi2014




*=================================================
*	SAMPLE RESTRICTIONS
*=================================================

*** FOR PEOPLE BELOW AGE 25, SET EARNINGS, INCOME AND ASSETS TO MISSING
*drop if age_now <= 25
replace real_earnings =. if age_now < 25
replace real_income =. if age_now < 25
replace real_assets =. if age_now < 25
replace real_house =. if age_now < 25
replace real_financial =. if age_now < 25
replace real_otherincome =. if age_now < 25


*** FOR PEOPLE AGE 67 AND OLDER, SET EARNINGS TO MISSING
replace real_earnings =. if age_now >= 67

collapse destroyed moved age born_west change_house married divorsed widow real_earnings real_income real_assets edu, by(id_match)

* Save data
save sample_westman.dta, replace
clear





*===========================================
*	SAMPLE: DESCENDANTS
*===========================================

clear
insheet using Gagnasett2.csv, delimiter(";")

*** rename
rename id_einstaklingur id_kt
rename moved family_moved
sort id_kt

*** MERGE information about missing status
merge 1:1 id_kt using missing.dta
drop _merge

*** Descendants are those that do not have a "destroyed status"
keep if destroyed ==.


********************************************************************
* Count number of descendants we do not have outcomes for
count if missing_always == 1
count if missing_natreg == 1
********************************************************************

* Save data as Stata data
save sample_descendants.dta, replace
clear




*=========================================================================
*		MATCH DESCENDANTS WITH THEIR PARENTS - DETERMINE IF TREATED OR NOT
*=========================================================================
clear
use sample_descendants.dta

*** Drop if both father and mother cannot be found
	
	* Count how many
	count if id_father =="" & id_mother ==""
	*Drop			
	drop if id_father =="" & id_mother ==""


keep id_kt id_father id_mother
save match_descendants.dta, replace


*** Generate dataset for mathcing descendants with their MOTHERS ***
gen father = id_father
gen mother = id_mother

rename id_kt id_einstaklingur
gen id_match = id_mother
save match_mother.dta, replace


*** Generate dataset for mathcing descendants with their FATHERS ***
clear
use match_descendants.dta

gen father = id_father
gen mother = id_mother

rename id_kt id_einstaklingur
gen id_match = id_father
save match_father.dta, replace



**** MATCH WITH MOTHER ***
clear
use match_mother.dta

merge m:1 id_match using sample_westman.dta
sort _merge
drop if _merge != 3
drop _merge

* Keep relevant variables from mother
keep id_einstaklingur father mother destroyed moved age born_west ///
change_house married divorsed widow real_earnings real_income real_assets edu

rename id_einstaklingur id_kt
rename father id_father
rename mother id_mother
rename destroyed destroyed_mother
rename moved moved_mother
rename age age_mother
rename born_west born_west_mother
rename change_house change_house_mother
rename married married_mother
rename divorsed divorsed_mother
rename widow widow_mother
rename real_earnings  real_earnings_mother
rename real_income real_income_mother 
rename real_assets real_assets_mother
rename edu edu_mother
save matched_mother.dta, replace



**** MATCH WITH FATHER ***
clear
use match_father.dta

merge m:1 id_match using sample_westman.dta
sort _merge
drop if _merge != 3
drop _merge

* Keep relevant variables from father
keep id_einstaklingur father mother destroyed moved age born_west ///
change_house married divorsed widow real_earnings real_income real_assets edu

rename id_einstaklingur id_kt
rename father id_father
rename mother id_mother
rename destroyed destroyed_father
rename moved moved_father
rename age age_father
rename born_west born_west_father
rename change_house change_house_father
rename married married_father
rename divorsed divorsed_father
rename widow widow_father
rename real_earnings  real_earnings_father
rename real_income real_income_father
rename real_assets real_assets_father
rename edu edu_father
save matched_father.dta, replace




*** MERGE THE TWO DATASETS TOGETHER
clear
use matched_mother.dta
merge 1:1 id_kt using matched_father.dta
sort _merge
drop _merge

* Count individuals
by id_kt, sort: gen nvals = _n == 1
count if nvals

* Generate groups of treatment: Two letters, first is fathers' status and second
* is mother's status. Status can be "D" for destroyed, "N" for not-destroyed, and
* "R" for parent not being from Westman Islands, but e.g. Reykjavik

gen DD = 1 if destroyed_father == 1 & destroyed_mother == 1
gen DN = 1 if destroyed_father == 1 & destroyed_mother == 0
gen ND = 1 if destroyed_father == 0 & destroyed_mother == 1
gen NN = 1 if destroyed_father == 0 & destroyed_mother == 0
gen DR = 1 if destroyed_father == 1 & destroyed_mother == .
gen RD = 1 if destroyed_father == . & destroyed_mother == 1
gen NR = 1 if destroyed_father == 0 & destroyed_mother == .
gen RN = 1 if destroyed_father == . & destroyed_mother == 0



save descendants_matched.dta,replace







*========================================
*	MERGE DESCENDANTS TO OUTCOME DATA
*========================================
clear
use data_outcomes.dta

merge m:1 id_kt using descendants_matched.dta
drop if _merge != 3
drop _merge

sort id_kt year

drop nvals
by id_kt, sort: gen nvals = _n == 1
count if nvals

* Drop if missing earnings 
count if launatekjur ==. & nvals == 1
drop if launatekjur ==.


/* 	Drop descendants that are born before 1973. 
	Those were not living in the Westman Islands 
	and cannot therefore be thought to have been affected by it. */

		* Age in 1973
		gen year_born = year - age_now

		count if year_born >= 1973 & nvals == 1
		count if year_born < 1973 & nvals == 1

		* Drop if born before 1973
		drop if year_born < 1973
		drop if year < 1989



*** 2nd VS. 3rd generation 

gen parent_age_max = max(age_father,age_mother)
gen parent_age_min = min(age_father,age_mother)

gen parent_age = age_mother
replace parent_age = age_father if parent_age ==.

*** Parent education
gen parent_edu_max = max(edu_father,edu_mother)
gen parent_edu_min = min(edu_father,edu_mother)

gen parent_edu = edu_mother
replace parent_edu = edu_father if parent_edu ==.


gen third_generation = 0
replace third_generation = 1 if parent_age < 25


count if nvals == 1 & third_generation ==1
count if nvals == 1 & third_generation ==0



* Count individuals in each group
count if DD == 1 & nvals ==1
count if DN == 1 & nvals ==1
count if ND == 1 & nvals ==1
count if NN == 1 & nvals ==1
count if DR == 1 & nvals ==1
count if RD == 1 & nvals ==1
count if NR == 1 & nvals ==1
count if RN == 1 & nvals ==1


* Treatment groups
gen destroyed = 1 if DD == 1 | DR == 1 | RD == 1
replace destroyed = 0 if NN == 1 | NR == 1 | RN == 1


* Drop DN and ND as it is unclear if they are treated or not
gen excluded = 0
replace excluded = 1 if DN == 1
replace excluded = 1 if ND == 1
count if excluded == 1 & nvals == 1


*========================================
*	Table 1 -- Descendant groups
*========================================

* Table with group count
gen not_destroyed = 0 if destroyed == 1
replace not_destroyed = 1 if destroyed == 0

cd "${output_dir}"
eststo clear
eststo: quietly estpost summarize destroyed if destroyed == 1 & nvals == 1
eststo: quietly estpost summarize not_destroyed if not_destroyed == 1 & nvals == 1
eststo: quietly estpost summarize excluded if excluded == 1 & nvals == 1
eststo: quietly estpost summarize nvals if nvals == 1
esttab using Table1.tex, replace cells("count") nodepvar noobs 
cd "${data_dir}"
drop not_destroyed 

* Drop those neither treated or not
drop if excluded == 1



*** Dummy variable MOVED = 1 if location is not Westman Islands when they enter sample (most often in 1981)
gen moved = 0 if sveitarflag_nr_sk == 8000 & nvals == 1
replace moved = 1 if sveitarflag_nr_sk != 8000 & nvals == 1
replace moved = moved[_n-1] if id_kt == id_kt[_n-1]


*** Save dataset for EDUCATION REGRESSIONS before restricting the sample by age 
save descendants_outcomes_education.dta, replace



*=============================================
*	GENERATE OUTCOME VARIABLES 
*=============================================

gen earnings = launatekjur + reikna_endurgjald
gen pension_earnings = earnings + gr_r_lfeyrissji
gen total_income = launatekjur + reikna_endurgjald + arartekjur + fjrmagnstekjur
gen income_2 = launatekjur + reikna_endurgjald + arartekjur
gen income_3 = launatekjur + reikna_endurgjald + arartekjur - gr_r_lfeyrissji
gen net_wealth = eignir_alls - skuldir
gen net_housing_wealth = fasteignir - skuldir_barkaupa
gen assets_nohousing = eignir_alls - fasteignir

* Transfer payments
gen pension = gr_r_lfeyrissji
gen gov_transfers = arartekjur - pension

gen receiving_transfers = 0
replace receiving_transfers = 1 if earnings == 0 & gov_transfers != 0




***************************************************
* Generate real varialbles - in 2014 prices in USD
***************************************************
* Exchange rate in december 2014 is 124.96
gen usd_2014 = 125 

gen real_earnings = ((earnings/cpi)*cpi2014)/usd_2014
gen real_pension_earnings = ((pension_earnings/cpi)*cpi2014)/usd_2014
gen real_income = ((total_income/cpi)*cpi2014)/usd_2014
gen real_income_no_finance = ((income_2/cpi)*cpi2014)/usd_2014
gen real_income_no_finance_pension = ((income_3/cpi)*cpi2014)/usd_2014
gen real_assets = ((eignir_alls/cpi)*cpi2014)/usd_2014
gen real_assets_nohousing = ((assets_nohousing/cpi)*cpi2014)/usd_2014
gen real_house = ((fasteignir/cpi)*cpi2014)/usd_2014
gen real_financial = ((fjrmagnstekjur/cpi)*cpi2014)/usd_2014
gen real_otherincome = ((arartekjur/cpi)*cpi2014)/usd_2014


* Labor supply - earnings not zero
gen labor_supply = 0 if real_earnings ==0
replace labor_supply = 1 if real_earnings > 0



*=================================================
*	SAMPLE RESTRICTIONS AND TRIMMING/WINSORIZING
*=================================================

*** FOR PEOPLE BELOW AGE 25, SET EARNINGS, INCOME AND ASSETS TO MISSING
replace real_earnings =. if age_now < 25
replace real_pension_earnings =. if age_now < 25
replace real_income =. if age_now < 25
replace real_income_no_finance =. if age_now < 25
replace real_income_no_finance_pension =. if age_now < 25
replace real_assets =. if age_now < 25
replace real_assets_nohousing =. if age_now < 25
replace real_house =. if age_now < 25
replace real_financial =. if age_now < 25
replace real_otherincome =. if age_now < 25
replace labor_supply =. if age_now < 25




*** Generate AGE BUCKETS
* 18 to 24
gen age_18_24 = 0
replace age_18_24 = 1 if age_now >= 18 & age_now <=24

* 25 to 34
gen age_25_34 = 0
replace age_25_34 = 1 if age_now >= 25 & age_now <=34

* 35 to 44
gen age_35_44 = 0
replace age_35_44 = 1 if age_now >= 35 & age_now <=44

* 45 to 54
gen age_45_54 = 0
replace age_45_54 = 1 if age_now >= 45 & age_now <=54

* 55 to 64
gen age_55_64 = 0
replace age_55_64 = 1 if age_now >= 55 & age_now <=64

* 65 and older
gen age_65 = 0
replace age_65 = 1 if age_now >= 65

*** Generate 5 year AGE BUCKETS
gen age_0_4 = 0
replace age_0_4 = 1 if age_now >= 0 & age_now <=4
gen age_5_9 = 0
replace age_5_9 = 1 if age_now >= 5 & age_now <=9
gen age_10_14 = 0
replace age_10_14 = 1 if age_now >= 10 & age_now <=14
gen age_15_19 = 0
replace age_15_19 = 1 if age_now >= 15 & age_now <=19
gen age_20_24 = 0
replace age_20_24 = 1 if age_now >= 20 & age_now <=24
gen age_25_29 = 0
replace age_25_29 = 1 if age_now >= 25 & age_now <=29
gen age_30_34 = 0
replace age_30_34 = 1 if age_now >= 30 & age_now <=34
gen age_35_39 = 0
replace age_35_39 = 1 if age_now >= 35 & age_now <=39
gen age_40_44 = 0
replace age_40_44 = 1 if age_now >= 40 & age_now <=44
gen age_45_49 = 0
replace age_45_49 = 1 if age_now >= 45 & age_now <=49
gen age_50_54 = 0
replace age_50_54 = 1 if age_now >= 50 & age_now <=54
gen age_55_59 = 0
replace age_55_59 = 1 if age_now >= 55 & age_now <=59
gen age_60_64 = 0
replace age_60_64 = 1 if age_now >= 60 & age_now <=64
gen age_65_69 = 0
replace age_65_69 = 1 if age_now >= 65 & age_now <=69
gen age_70 = 0
replace age_70 = 1 if age_now >= 70




*** Save dataset
save descendants_outcomes.dta, replace




