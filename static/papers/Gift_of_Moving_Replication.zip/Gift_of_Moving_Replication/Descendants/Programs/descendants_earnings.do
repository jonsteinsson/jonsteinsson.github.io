	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 		THIS DOFILE: Effect on earnings of DESCENDANTS	 		********
	********************************************************************************
	
	
	*** Set the directory where the results are stored
	cd "${output_dir}"

	
	* Load in mached outcome data
	clear
	use "${data_dir}/descendants_outcomes.dta"
	


	*================================================
	* Table A.3
	*================================================
	
	**** Control mean
	sum real_earnings if destroyed == 0
	local mem = r(mean)
	
	* RF
	xi: reg real_earnings destroyed , vce(cluster id_kt)
	outreg2 using Table_A3_descendants, tex nocons ctitle(Reduced Form) keep(destroyed) dec(0) addstat("Control Mean", `mem') replace
	
	* RF - controls
	xi: reg real_earnings destroyed female_now i.age_now i.year, vce(cluster id_kt)
	outreg2 using Table_A3_descendants, tex nocons ctitle(Reduced Form) keep(destroyed) dec(0) addstat("Control Mean", `mem') append
	
	
	* IV 
	xi: ivreg2 real_earnings (moved = destroyed) , cluster(id_kt)
	outreg2 using Table_A3_descendants, tex nocons ctitle(IV) keep(moved) dec(0) addstat("Control Mean", `mem') append
	
	* IV - controls
	xi: ivreg2 real_earnings female_now i.age_now i.year (moved = destroyed), cluster(id_kt)
	outreg2 using Table_A3_descendants, tex nocons ctitle(IV) keep(moved) dec(0) addstat("Control Mean", `mem') append
	
 
	* OLS
	xi: reg real_earnings moved , vce(cluster id_kt)
	outreg2 using Table_A3_descendants, tex nocons ctitle(OLS) keep(moved) dec(0) append
	
	* OLS - controls
	xi: reg real_earnings moved female_now i.age_now i.year, vce(cluster id_kt)
	outreg2 using Table_A3_descendants, tex nocons ctitle(OLS) keep(moved) dec(0) append
	

	







