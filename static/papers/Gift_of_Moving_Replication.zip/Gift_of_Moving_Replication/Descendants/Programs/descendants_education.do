	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 		THIS DOFILE: Effect on education of DESCENDANTS	 		********
	********************************************************************************
	
	
	*** Set the directory where the results are stored
	cd "${output_dir}"

	
	* Load in mached outcome data
	clear
	use "${data_dir}/descendants_outcomes.dta"
	
	

	* Only have data on education in 2011
	drop if year !=2011


	**** EDUCATION ****
	* edu==9 means missing education
	replace edu =. if edu ==9  

	*** EDU - Variable from 1 to 5
	gen edu_new = 1 if edu == 3 
	replace edu_new = 2 if edu == 4
	replace edu_new = 3 if edu == 5
	replace edu_new = 4 if edu == 6 
	replace edu_new = 5 if edu == 7

	replace edu = edu_new

	*** Code to years of education
	gen edu_years =.
	replace edu_years = 10 if edu == 1
	replace edu_years = 14 if edu == 2
	replace edu_years = 15 if edu == 3 /* Average lenght 0.5 - 2 years. Set to 1 year */
	replace edu_years = 18 if edu == 4  /* Average lenght of university education is 4 years */
	replace edu_years = 22 if edu == 5


	* Indicator for university
	gen university = 1 if edu >= 4 & year == 2011 & edu !=.
	replace university = 0 if edu < 4 & year == 2011 & edu !=.
	
	* Indicator for post-compulsory edu
	gen further = 1 if edu >= 2 & year == 2011 & edu !=.
	replace further = 0 if edu < 2 & year == 2011 & edu !=.


	* Parental controls -- earnings
	gen parent_earnings = max(real_earnings_father, real_earnings_mother)

	*** Parental controls -- Parents years of schooling
	gen parent_edu_years = 10
	replace parent_edu_years = 10 if parent_edu == 1
	replace parent_edu_years = 14 if parent_edu == 2
	replace parent_edu_years = 15 if parent_edu == 3 /* Average lenght 0.5 - 2 years. Set to 1 year */
	replace parent_edu_years = 18 if parent_edu == 4  /* Average lenght of university education is 4 years */
	replace parent_edu_years = 22 if parent_edu == 5


	
	
	
	
	
	*======================================================
	*	Table 9. IV. OLS estimated of years of schooling 
	*======================================================
	
	**** Control mean
	sum edu_years if destroyed == 0
	local mem = r(mean)
	
	* IV
	ivreg2 edu_years (moved = destroyed), cluster(id_kt)

	ivreg2 edu_years female_now i.year_born (moved = destroyed), cluster(id_kt)
	outreg2 using Table_9_descendants, tex nocons ctitle(IV) keep(moved) dec(2) addstat("Control Mean", `mem') replace
	
	
	
	
	* OLS (no controls)
	reg edu_years moved, vce(cluster id_kt)
	
	* OLS
	reg edu_years moved female_now i.year_born, vce(cluster id_kt)
	outreg2 using Table_9_descendants, tex nocons ctitle(OLS) keep(moved) dec(2) append
	



	
	*=================================================
	*	Reduced form estimates for comparison
	*=================================================
	
	/*

	* RF
	reg edu_years destroyed, vce(cluster id_kt)
	outreg2 using edu_years_reducedform_descendants, tex replace ctitle(edu_years) dec(2)

	reg edu_years destroyed female_now i.year_born, vce(cluster id_kt)
	outreg2 using edu_years_reducedform_descendants, tex append ctitle(edu_years) dec(2)

	
	*/



	
	
	
	*====================================================
	*	Effect on completing Post-compulsory education
	*====================================================
	
	/*
	
	**** Control mean
	sum further if destroyed == 0
	local mem = r(mean)
	
	*** RF
	reg further destroyed, vce(cluster id_kt)
	outreg2 using post_compulsory_descendants,tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem') replace
	
	*** RF - controls
	reg further destroyed female_now i.year_born, vce(cluster id_kt)
	outreg2 using post_compulsory_descendants,tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem') append

	*** IV 
	ivreg2 further (moved = destroyed), cluster(id_kt)
	outreg2 using post_compulsory_descendants,tex nocons ctitle(IV) ///
	keep(moved) dec(3) addstat("Control Mean", `mem') append
	
	*** IV - controls
	ivreg2 further female_now i.year_born (moved = destroyed), cluster(id_kt)
	outreg2 using post_compulsory_descendants,tex nocons ctitle(IV) ///
	keep(moved) dec(3) addstat("Control Mean", `mem') append

	*** OLS
	reg further moved, cluster(id_kt)
	outreg2 using post_compulsory_descendants,tex nocons ctitle(OLS) keep(moved) dec(3) append
	
	*** OLS - controls
	reg further moved female_now i.year_born, cluster(id_kt)
	outreg2 using post_compulsory_descendants,tex nocons ctitle(OLS) keep(moved) dec(3) append
	
	*/
	
	
	
	*====================================================
	*	Effect on completing university degree
	*====================================================
	
	/*
	
	**** Control mean
	sum university if destroyed == 0
	local mem = r(mean)
	
	*** RF
	reg university destroyed, vce(cluster id_kt)
	outreg2 using university_descendants,tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem') replace
	
	*** RF - controls
	reg university destroyed female_now i.year_born, vce(cluster id_kt)
	outreg2 using university_descendants,tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem') append

	*** IV 
	ivreg2 university (moved = destroyed), cluster(id_kt)
	outreg2 using university_descendants,tex nocons ctitle(IV) ///
	keep(moved) dec(3) addstat("Control Mean", `mem') append
	
	*** IV - controls
	ivreg2 university female_now i.year_born (moved = destroyed), cluster(id_kt)
	outreg2 using university_descendants,tex nocons ctitle(IV) ///
	keep(moved) dec(3) addstat("Control Mean", `mem') append

	*** OLS
	reg university moved, cluster(id_kt)
	outreg2 using university_descendants,tex nocons ctitle(OLS) keep(moved) dec(3) append
	
	*** OLS - controls
	reg university moved female_now i.year_born, cluster(id_kt)
	outreg2 using university_descendants,tex nocons ctitle(OLS) keep(moved) dec(3) append
	
	
	
	*/
	
	
	
	

	*=================================================
	*
	*	Controlling for parents characteristics
	*	
	*	Education, age and earnings
	*
	*=================================================
	
	/*
	
	
	*** Years of school
	
	**** Control mean
	sum edu_years if destroyed == 0
	local mem = r(mean)
	
	* RF
	reg edu_years destroyed, vce(cluster id_kt)
	outreg2 using edu_years_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(Reduced Form) keep(destroyed) dec(2) addstat("Control Mean", `mem') replace
	
	* RF - controls 
	reg edu_years destroyed female_now i.year_born parent_edu_years parent_age parent_earnings, vce(cluster id_kt)
	outreg2 using edu_years_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(Reduced Form) keep(destroyed) dec(2) addstat("Control Mean", `mem') append
	
	* IV
	ivreg2 edu_years (moved = destroyed), cluster(id_kt)
	outreg2 using edu_years_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(IV) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	* IV - controls
	ivreg2 edu_years female_now i.year_born parent_edu_years parent_age parent_earnings (moved = destroyed), cluster(id_kt)
	outreg2 using edu_years_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(IV) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	
	* OLS
	reg edu_years moved, vce(cluster id_kt)
	outreg2 using edu_years_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(OLS) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	* OLS - controls
	reg edu_years moved female_now i.year_born parent_edu_years parent_age parent_earnings, vce(cluster id_kt)
	outreg2 using edu_years_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(OLS) keep(moved) dec(2) addstat("Control Mean", `mem') append
	


	
	*** Post-compulsory
	
	**** Control mean
	sum further if destroyed == 0
	local mem = r(mean)
	
	* RF
	reg further destroyed, vce(cluster id_kt)
	outreg2 using post_compulsory_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(Reduced Form) keep(destroyed) dec(2) addstat("Control Mean", `mem') replace
	
	* RF - controls 
	reg further destroyed female_now i.year_born parent_edu_years parent_age parent_earnings, vce(cluster id_kt)
	outreg2 using post_compulsory_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(Reduced Form) keep(destroyed) dec(2) addstat("Control Mean", `mem') append
	
	* IV
	ivreg2 further (moved = destroyed), cluster(id_kt)
	outreg2 using post_compulsory_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(IV) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	* IV - controls
	ivreg2 further female_now i.year_born parent_edu_years parent_age parent_earnings (moved = destroyed), cluster(id_kt)
	outreg2 using post_compulsory_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(IV) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	
	* OLS
	reg further moved, vce(cluster id_kt)
	outreg2 using post_compulsory_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(OLS) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	* OLS - controls
	reg further moved female_now i.year_born parent_edu_years parent_age parent_earnings, vce(cluster id_kt)
	outreg2 using post_compulsory_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(OLS) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	
	
	
	*** University
	
	**** Control mean
	sum university if destroyed == 0
	local mem = r(mean)
	
	* RF
	reg university destroyed, vce(cluster id_kt)
	outreg2 using university_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(Reduced Form) keep(destroyed) dec(2) addstat("Control Mean", `mem') replace
	
	* RF - controls 
	reg university destroyed female_now i.year_born parent_edu_years parent_age parent_earnings, vce(cluster id_kt)
	outreg2 using university_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(Reduced Form) keep(destroyed) dec(2) addstat("Control Mean", `mem') append
	
	* IV
	ivreg2 university (moved = destroyed), cluster(id_kt)
	outreg2 using university_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(IV) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	* IV - controls
	ivreg2 university female_now i.year_born parent_edu_years parent_age parent_earnings (moved = destroyed), cluster(id_kt)
	outreg2 using university_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(IV) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	
	* OLS
	reg university moved, vce(cluster id_kt)
	outreg2 using university_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(OLS) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	* OLS - controls
	reg university moved female_now i.year_born parent_edu_years parent_age parent_earnings, vce(cluster id_kt)
	outreg2 using university_descendants_PARENT_CONTROLS, tex nocons ///
	ctitle(OLS) keep(moved) dec(2) addstat("Control Mean", `mem') append
	
	
	
	
	*/
	
	
	
	
	





