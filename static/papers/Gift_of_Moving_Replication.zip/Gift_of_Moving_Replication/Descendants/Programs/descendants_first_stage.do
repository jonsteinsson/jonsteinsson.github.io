	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 			THIS DOFILE: First stage for DESCENDANTS	 		********
	********************************************************************************
	
	
	*** Set the directory where the results are stored
	cd "${output_dir}"

	
	* Load in mached outcome data
	clear
	use "${data_dir}/descendants_outcomes.dta"
	

	* N.B. Only use one observation per individual, 
	*the first time we see him in the data
	
	drop nvals
	by id_kt, sort: gen nvals = _n == 1
	count if nvals


	*===================================
	*	Table 4 -- columns 7 and 8
	*===================================
	
	**** Control mean
	sum moved if destroyed == 0
	local mem = r(mean)

	*** FIRST-STAGE  (F-statistics from education IV)
	reg moved destroyed if nvals == 1, vce(robust)
	outreg2 using Table_4_firststage_descendants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", 10.4) replace
	
	**** FIRST-STAGE -- With controls (F-statistics from education IV)
	reg moved destroyed female_now i.age_now if nvals == 1, vce(robust)
	outreg2 using Table_4_firststage_descendants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", 12.3) append 


	
	*=========================================
	*	Appendix Table A.1 -- columns 7 and 8
	*=========================================
	
	**** Control mean
	sum moved if destroyed == 0
	local mem = r(mean)

	*** FIRST-STAGE  (F-statistics from education IV)
	reg moved destroyed if nvals == 1, vce(robust)
	outreg2 using Table_A1_firststage_descendants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", 10.4) replace
	
	**** FIRST-STAGE -- With controls (F-statistics from education IV)
	reg moved destroyed female_now i.age_now if nvals == 1, vce(robust)
	outreg2 using Table_A1_firststage_descendants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", 12.3) append 

	
	
	
	
	
	
