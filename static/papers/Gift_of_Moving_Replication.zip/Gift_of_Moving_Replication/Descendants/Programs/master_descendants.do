	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 						MASTER DOFILE 3:						********
	******** 			Data preparation and Analysis of DESCENDATNS		********
	********************************************************************************
	
	
	**** Set directories

	* Define home directory
	global main_dir "... put your main directory here"

	* set data, code, and output directories
	global data_dir ${main_dir}/Data
	global do_programs_dir ${main_dir}/Programs
	global output_dir ${main_dir}/Output
	
	* Start taking time
	timer clear 4
	timer on 4
	
	*** log dofile
	cd "${output_dir}"
	log using analysis_descendants_log, replace
	
	*** 0. Data preparation 
	do "${do_programs_dir}/dataprep_descendants.do"
	
	
	*** 1. First stage (Table 4, Table A.1) 
	do "${do_programs_dir}/descendants_first_stage.do"
	
	*** 2. Effect on education (Table 9) 
	do "${do_programs_dir}/descendants_education.do"
	
	*** 3. Effect on earnings (Table A.3) 
	do "${do_programs_dir}/descendants_earnings.do"
	
	
	*** Turn off time and show
	timer off 4
	timer list 4
	
	log close
