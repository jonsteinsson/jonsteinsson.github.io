********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Prepare data for Inhabitants			********
********************************************************************************

cd ${data_dir}


*===========================================
*		Load in and prepare outcome data
*===========================================
clear
insheet using Gagnasett_1_mal6.csv, delimiter(";")


* Naming and preparation of variables
rename id_einstaklingur id_kt
rename tekjur year
rename kyn gender_now
gen female_now = 0
replace female_now = 1 if gender_now == 2
rename aldur age_now
gen age_now2 = age_now*age_now
rename hjskapur_skattur marital_status
gen married_now = 0
replace married_now = 1 if marital_status == 3 | marital_status == 5 | marital_status == 6

rename hjskapur_jskr marital_natreg
replace marital_natreg="0" if marital_natreg==""
replace marital_natreg="8" if marital_natreg=="L" | marital_natreg=="G"
destring marital_natreg, replace

gen widow_now = 0
replace widow_now = 1 if marital_natreg == 4
gen divorsed_now = 0
replace divorsed_now = 1 if marital_natreg == 5

gen nr_children = 0
replace nr_children = fjldi_barna_yngri + fjldi_barna_eldri if fjldi_barna ==.
replace nr_children = fjldi_barna if fjldi_barna !=.

gen mortality = 0
replace mortality = 1 if dnarr !=.

sort id_kt year


* Count individuals
by id_kt, sort: gen nvals = _n == 1
count if nvals

* Count number of individuals that are only in National Registry
count if year == 1978 | year == 1980 & nvals == 1

* Count number of individuals we never find
count if year == 2015 & nvals == 1

drop nvals
save data_outcomes.dta, replace



*=========================================================================
*	Store data on individuals that are missing in outcome data
*=========================================================================

by id_kt, sort: gen nvals = _n == 1
count if nvals

*** Sample if IDs with MISSING outcomes
keep if year == 1978 | year == 1980 | year == 2015
keep if nvals == 1

* individuals we never find
gen missing_always = 0
replace missing = 1 if year == 2015

* individuals that are only in National Registry
gen missing_natreg = 0
replace missing_natreg = 1 if year == 1978 | year == 1980

* Lives abroad
gen abroad = 0
replace abroad = 1 if erlendis_th == 1

keep id_kt missing_always missing_natreg abroad
save missing.dta, replace



***	CPI index for deflating
clear
import excel "C:\Mal6_2015\Empirical\Inhabitants\new moved variable\Matching new\cpi.xlsx", sheet("Sheet1") firstrow
save cpi.dta, replace

*** MERGE TO OUTCOMES
clear
use data_outcomes.dta
merge m:1 year using cpi.dta
sort _merge
drop _merge

save data_outcomes.dta, replace


*=========================================
*		New Variable: Address identifier 
*=========================================
clear
insheet using Gagnasett_2_mal6_2015.csv, delimiter(";")
keep id_einstaklingur address
save address_data.dta, replace



*=======================================================
*	Load in and prepare data on Westman Islanders
*=======================================================
clear
insheet using Gagnasett_2_mal6.csv, delimiter(";")

*** Merge address
merge 1:1 id_einstaklingur using address_data.dta
drop _merge

*** Rename
rename id_einstaklingur id_kt
rename moved family_moved
sort id_kt

*** Merge information about missing status
merge 1:1 id_kt using missing.dta
drop _merge


*** Generate variables
gen female = 0
replace female = 1 if gender == 2 | gender == 4

gen adult = 0
replace adult = 1 if gender == 1 | gender == 2

gen child = 0
replace child = 1 if gender == 3 | gender == 4

gen adult_age = age if gender == 1 | gender == 2
gen child_age = age if gender == 3 | gender == 4

summarize marital 
gen married = 0
replace married = 1 if marital == 3
gen widow = 0
replace widow = 1 if marital == 4
gen divorsed = 0
replace divorsed = 1 if marital == 5 | marital == 6

* Dummy for moving to a new house after 1960
destring family_moved, replace
gen change_house = 0
replace change_house = 1 if family_moved >= 600


* Dummy for being born in the Westman Islands
destring place_of_birth, replace
gen born_west = 0
replace born_west = 1 if place_of_birth == 80


* Count unique ID
by id_kt, sort: gen nvals = _n == 1
count if nvals

* Count DESTROYED groups
count if destroyed ==1
count if destroyed ==0		
		
*** Drop descendants - do not have a destroyed "status"
keep if destroyed !=.

* Size of Orignal Inhabitants
count if nvals ==1


/*  Correct outliers in house value
These are apartment buildings with multiple apartments but summarized 
with one vale -- not true for other multi-apartment houses */ 

* Outliers in size
replace house_size = house_size/3 if house_value == 10718
replace house_size = house_size/8 if house_value == 7344
replace house_size = house_size/8 if house_value == 7314

* Outliers in value
replace house_value = house_value/3 if house_value == 10718
replace house_value = house_value/8 if house_value == 7344
replace house_value = house_value/8 if house_value == 7314

sum house_value, detail

*** House Value in 2014 USD
/* Values in 1,000 of 1970 ISK. N.B. that in 1981, 2 zeros were removed */
replace house_value = ((((house_value*1000)/100)/145.4)*132928.4)/125  
sum house_value, detail



*** Constructing Families: 
* Idependent (Household head & spouse) and dependent children

order id_kt gender age marital address
gsort address gender -age 

* Max age
egen max_age = max(age), by(address gender)
* Max age overall
egen max_age_overall = max(age), by(address)
* "Distance" from max age
gen distance_max_age = max_age_overall - age

* Find male and female household heads
gen hh_male = 0
gen hh_female = 0
	
*** All married couples are automatically household heads
replace hh_male = 1 if gender == 1 & marital == 3
replace hh_female = 1 if gender == 2 & marital == 3
	
*** All widows and widowees are household heads
replace hh_male = 1 if gender == 1 & marital == 4
replace hh_female = 1 if gender == 2 & marital == 4
	
*** All divorced people are household heads
replace hh_male = 1 if gender == 1 & marital == 6
replace hh_female = 1 if gender == 2 & marital == 6
	
*** The oldest man and oldest women are also household heads (if not already classified based on marital status)
replace hh_male = 1 if gender == 1 & age == max_age & age >= 25
replace hh_female = 1 if gender == 2 & age == max_age & age >= 25
	
	
*** Young couples
replace hh_male = 1 if gender == 1 & age >= 18 & age < 25 & age == max_age & distance_max_age <= 15
replace hh_female = 1 if gender == 2 & age >= 18 & age < 25 & age == max_age & distance_max_age <= 15
	
*** Independent (parents)
gen independent = 0
replace independent = 1 if hh_male == 1 | hh_female == 1
	
*** Dependent (children)
gen dependent = 0
replace dependent = 1 if hh_male == 0 & hh_female == 0
* Correct for older cohorts not classified as independent
replace independent = 1 if dependent == 1 & age >= 25
replace dependent = 0 if age >= 25
	
	
order address gender age marital hh_male hh_female independent dependent
drop nvals
save data_westman.dta, replace




	
	

*======================================================================================
*	Load in and prepare data on inhabitants of the  Westman Islands in 1974 and 1975
*======================================================================================

* DATA 1974
clear
insheet using Gagnasett_3_mal6.csv, delimiter(";")

* Keep if year 1974
keep if rtalgagna == 1974

keep einst_id perm_place_nr temp_place_nr marital place_of_birth lives_temp change_house_when
rename einst_id id_kt
rename perm_place_nr perm_place_nr_1974
rename temp_place_nr temp_place_nr_1974
rename marital marital_1974
rename place_of_birth place_of_birth_1974
rename lives_temp lives_temp_1974
rename change_house_when change_house_1974

save inhabitants_1974.dta, replace
clear




* DATA 1975
clear
insheet using Gagnasett_3_mal6.csv, delimiter(";")

* Keep if year 1975
keep if rtalgagna == 1975


keep einst_id perm_place_nr temp_place_nr marital place_of_birth lives_temp change_house_when
rename einst_id id_kt
rename perm_place_nr perm_place_nr_1975
rename temp_place_nr temp_place_nr_1975
rename marital marital_1975
rename place_of_birth place_of_birth_1975
rename lives_temp lives_temp_1975
rename change_house_when change_house_1975


save inhabitants_1975.dta, replace
clear




* Merge Inhabitants of 1974 & 1975 to list of Inhabitants in 1973
use data_westman.dta
* 1974
merge 1:1 id_kt using inhabitants_1974.dta
sort _merge
drop if _merge == 2

* Has moved from WI in 1974?
gen moved_1974 = 0
replace moved_1974 = 1 if _merge == 1
drop _merge


* 1975
merge 1:1 id_kt using inhabitants_1975.dta
sort _merge
drop if _merge == 2

* Has moved from WI in 1975?
gen moved_1975 = 0
replace moved_1975 = 1 if _merge == 1
*** Classify those that had a temporary address outside WI as moved
*replace moved_1975 = 1 if lives_temp_1975 == 1
drop _merge



* Variable for moving as of 1975 
* (alternative definition for comparison: moved as of 1981 --- defined below)
gen new_moved = 0
replace new_moved = 1 if moved_1975 == 1


save data_westman.dta, replace
clear




*** Match number of children before the eruption -- According to tax records
use data_outcomes.dta
keep if year == 1981
sort id_kt
by id_kt, sort: gen nvals = _n == 1
count if nvals
sort nvals
keep if nvals == 1

gen nr_children_before = fjldi_barna_eldri
keep id_kt nr_children_before
save data_children.dta, replace
clear


*** Match education of the old
use data_outcomes.dta
keep if year == 2011
sort id_kt
by id_kt, sort: gen nvals = _n == 1
count if nvals
keep if nvals == 1

keep id_kt edu


* edu==9 means missing education
replace edu =. if edu ==9  

*** edu variable from 1 to 5
gen edu_new = 1 if edu == 3 
replace edu_new = 2 if edu == 4
replace edu_new = 3 if edu == 5
replace edu_new = 4 if edu == 6 
replace edu_new = 5 if edu == 7

replace edu = edu_new

*** Code to years of education
gen edu_years =.
replace edu_years = 10 if edu == 1
replace edu_years = 14 if edu == 2
replace edu_years = 15 if edu == 3 
replace edu_years = 18 if edu == 4
replace edu_years = 22 if edu == 5

keep id_kt edu_years
save edu_westman.dta, replace
clear



*** Matching
use data_westman.dta
merge 1:1 id_kt using data_children.dta
sort _merge
drop if _merge == 2
drop _merge

merge 1:1 id_kt using edu_westman.dta
sort _merge
drop if _merge == 2
drop _merge


save data_westman_summary.dta, replace
clear




*===============================
*		MERGE DATA
*===============================
clear
use data_outcomes.dta

merge m:1 id_kt using data_westman.dta
drop if _merge != 3
drop _merge

sort id_kt year
* Count id
by id_kt, sort: gen nvals = _n == 1
count if nvals

drop nvals
by id_kt, sort: gen nvals = _n == 1
count if nvals



*** Dummy variable MOVED = 1 if location is not Westman Islands when they enter sample (most often in 1981)
drop if sveitarflag_nr_sk ==.
gen moved = 0 if sveitarflag_nr_sk == 8000 & nvals == 1
replace moved = 1 if sveitarflag_nr_sk != 8000 & nvals == 1
replace moved = moved[_n-1] if id_kt == id_kt[_n-1]


* Location dummies
gen capital_area = 0
replace capital_area = 1 if sveitarflag_nr_sk <= 1604
gen other_area = 0
replace other_area = 1 if sveitarflag_nr_sk > 1604 & sveitarflag_nr_sk != 8000	
gen lives_westman = 0
replace lives_westman = 1 if sveitarflag_nr_sk == 8000

* Location variable
gen location = 1 if lives_westman == 1 & nvals == 1
replace location = 2 if capital_area == 1 & nvals == 1	
replace location = 3 if other_area == 1 & nvals == 1			




*=============================================
*	GROUPS
*=============================================

*** Generations
gen generation = 1 if gender == 1 | gender == 2
replace generation = 2 if gender == 3 | gender == 4

* Children between age 0 and 8
gen young_less9 = 0
replace young_less9 = 1 if age <= 8

* Children between age 9 and 17
gen young_above9 = 0 
replace young_above9 = 1 if age >= 9 & age < 18


*** DEFINITION OF "YOUNG"
gen young25 = 0
replace young25 = 1 if age < 25


*** Generate 5 year AGE BUCKETS
gen age_18_24 = 0
replace age_18_24 = 1 if age_now >= 18 & age_now <=24
gen age_25_29 = 0
replace age_25_29 = 1 if age_now >= 25 & age_now <=29
gen age_30_34 = 0
replace age_30_34 = 1 if age_now >= 30 & age_now <=34
gen age_35_39 = 0
replace age_35_39 = 1 if age_now >= 35 & age_now <=39
gen age_40_44 = 0
replace age_40_44 = 1 if age_now >= 40 & age_now <=44
gen age_45_49 = 0
replace age_45_49 = 1 if age_now >= 45 & age_now <=49
gen age_50_54 = 0
replace age_50_54 = 1 if age_now >= 50 & age_now <=54
gen age_55_59 = 0
replace age_55_59 = 1 if age_now >= 55 & age_now <=59
gen age_60_64 = 0
replace age_60_64 = 1 if age_now >= 60 & age_now <=64
gen age_65_69 = 0
replace age_65_69 = 1 if age_now >= 65 & age_now <=69
gen age_70 = 0
replace age_70 = 1 if age_now >= 70



*** Generate 5 year COHORT BUCKETS
gen cohort_0_4 = 0
replace cohort_0_4 = 1 if age >= 0 & age <=4
gen cohort_5_9 = 0
replace cohort_5_9 = 1 if age >= 5 & age <=9
gen cohort_10_14 = 0
replace cohort_10_14 = 1 if age >= 10 & age <=14
gen cohort_15_19 = 0
replace cohort_15_19 = 1 if age >= 15 & age <=19
gen cohort_20_24 = 0
replace cohort_20_24 = 1 if age >= 20 & age <=24
gen cohort_25_29 = 0
replace cohort_25_29 = 1 if age >= 25 & age <=29
gen cohort_30_34 = 0
replace cohort_30_34 = 1 if age >= 30 & age <=34
gen cohort_35_39 = 0
replace cohort_35_39 = 1 if age >= 35 & age <=39
gen cohort_40_44 = 0
replace cohort_40_44 = 1 if age >= 40 & age <=44
gen cohort_45_49 = 0
replace cohort_45_49 = 1 if age >= 45 & age <=49
gen cohort_50_54 = 0
replace cohort_50_54 = 1 if age >= 50 & age <=54
gen cohort_55_59 = 0
replace cohort_55_59 = 1 if age >= 55 & age <=59
gen cohort_60_64 = 0
replace cohort_60_64 = 1 if age >= 60 & age <=64
gen cohort_65plus = 0
replace cohort_65plus = 1 if age >= 65



*** Generate 10 year COHORT BUCKETS
gen cohort_0_9 = 0
replace cohort_0_9 = 1 if age >= 0 & age <=9
gen cohort_10_18 = 0
replace cohort_10_18 = 1 if age >= 10 & age <=18
gen cohort_19_25 = 0
replace cohort_19_25 = 1 if age >= 19 & age <=25
gen cohort_26_34 = 0
replace cohort_26_34 = 1 if age >= 26 & age <=34
gen cohort_35_44 = 0
replace cohort_35_44 = 1 if age >= 35 & age <=44
gen cohort_45_54 = 0
replace cohort_45_54 = 1 if age >= 45 & age <=54
gen cohort_55_64 = 0
replace cohort_55_64 = 1 if age >= 55 & age <=64


*** Save dataset for education analysis beforerestricting the sample by age 
save westman_outcomes_education.dta, replace




*=============================================
*	GENERATE OUTCOME VARIABLES 
*=============================================

gen earnings = launatekjur + reikna_endurgjald
gen pension_earnings = earnings + gr_r_lfeyrissji
gen total_income = launatekjur + reikna_endurgjald + arartekjur + fjrmagnstekjur
gen net_wealth = eignir_alls - skuldir
gen net_housing_wealth = fasteignir - skuldir_barkaupa
gen assets_nohousing = eignir_alls - fasteignir

* Transfer payments
gen pension = gr_r_lfeyrissji
gen gov_transfers = arartekjur - pension

gen receiving_transfers = 0
replace receiving_transfers = 1 if earnings == 0 & gov_transfers != 0




***************************************************
* Generate real varialbles - in 2014 prices in USD
***************************************************
* Exchange rate in december 2014 is 124.96
gen usd_2014 = 125 

gen real_earnings = ((earnings/cpi)*cpi2014)/usd_2014
gen real_pension_earnings = ((pension_earnings/cpi)*cpi2014)/usd_2014
gen real_income = ((total_income/cpi)*cpi2014)/usd_2014
gen real_pension = ((pension/cpi)*cpi2014)/usd_2014
gen real_assets = ((eignir_alls/cpi)*cpi2014)/usd_2014
gen real_assets_nohousing = ((assets_nohousing/cpi)*cpi2014)/usd_2014
gen real_house = ((fasteignir/cpi)*cpi2014)/usd_2014
gen real_financial = ((fjrmagnstekjur/cpi)*cpi2014)/usd_2014
gen real_otherincome = ((arartekjur/cpi)*cpi2014)/usd_2014



* Labor supply - earnings not zero
gen labor_supply = 0 if real_earnings ==0
replace labor_supply = 1 if real_earnings > 0

* Alternative labor supply definition - wages not zero
gen labor_supply_wages = 0
replace labor_supply_wages = 1 if launatekjur > 0





*=================================================
*	Restrictins/Trimming
*=================================================

*** FOR PEOPLE BELOW AGE 25, SET EARNINGS, INCOME AND ASSETS TO MISSING
gen real_earnings_18_64 = real_earnings
replace real_earnings_18_64 =. if age_now < 18
replace real_earnings_18_64 =. if age_now >= 65

replace real_earnings =. if age_now < 25
replace real_pension_earnings =. if age_now < 25
replace non_zero_earnings =. if age_now < 25
replace above_min_earnings =. if age_now < 25
replace real_income =. if age_now < 25
replace real_pension =. if age_now < 25
replace real_assets =. if age_now < 25
replace real_assets_nohousing =. if age_now < 25
replace real_house =. if age_now < 25
replace real_financial =. if age_now < 25
replace real_otherincome =. if age_now < 25
replace labor_supply =. if age_now < 25
replace labor_supply_wages =. if age_now < 25



*** FOR PEOPLE AGE 65 AND OLDER, SET EARNINGS TO MISSING
replace real_earnings =. if age_now >= 65
replace real_pension_earnings =. if age_now >= 65


save westman_outcomes.dta, replace





clear
use westman_outcomes_education.dta

* Only have data on education in 2011
drop if year !=2011

**** EDUCATION ****
* edu==9 means missing education
replace edu =. if edu ==9  

*** EDU - Variable from 1 to 5
gen edu_new = 1 if edu == 3 
replace edu_new = 2 if edu == 4
replace edu_new = 3 if edu == 5
replace edu_new = 4 if edu == 6 
replace edu_new = 5 if edu == 7
replace edu = edu_new

*** Code to years of education
gen edu_years =.
replace edu_years = 10 if edu == 1
replace edu_years = 14 if edu == 2
/* Average lenght 0.5 - 2 years. Set to 1 year */
replace edu_years = 15 if edu == 3 
/* Average lenght of university education is 4 years - 
That is, 50% of those that graduate with Bachelors degree 
have a masters degree or eqv.*/
replace edu_years = 18 if edu == 4 
replace edu_years = 22 if edu == 5

* University dummy
gen university = 1 if edu >= 4 & edu !=.
replace university = 0 if edu < 4 & edu !=.

* Futher education dummy (post-compulsory education)	
gen further = 1 if edu >= 2 & edu !=.
replace further = 0 if edu < 2 & edu !=.
	

save westman_outcomes_education.dta, replace




*** Add the measure of education to main outcome data
clear
use westman_outcomes_education.dta
keep id_kt edu
save data_edu.dta, replace

clear
use westman_outcomes.dta
drop edu
merge m:1 id_kt using data_edu.dta
drop _merge
save westman_outcomes.dta, replace






