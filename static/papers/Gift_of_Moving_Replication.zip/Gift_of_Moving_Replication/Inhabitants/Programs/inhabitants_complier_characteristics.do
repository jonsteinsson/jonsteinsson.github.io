********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Complier Characteristics 		 		********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"

clear


*=========================================================================
*		GENERATE DATASET
*=========================================================================

*	SAMPLE OF PARENTS - GENERATION OLD
use "${data_dir}/westman_outcomes.dta"

* ID for matching
gen id_match = id_kt

collapse edu married born_west, by(id_match)
save parents_match.dta, replace

 
*	SAMPLE OF CHILDREN - GENERATION YOUNG
use "${data_dir}/westman_outcomes.dta"


*** Drop if both father and mother cannot be found
* Count how many
count if id_father ==. & id_mother ==.
*Drop			
drop if id_father ==. & id_mother ==.


* Count id
drop nvals
by id_kt, sort: gen nvals = _n == 1
count if nvals

* Restrict to one observation per child - only want to identify its match to parents
drop if nvals != 1

keep id_kt id_father id_mother
save children_match.dta, replace



*** Generate dataset for matching children with their MOTHERS ***
gen father = id_father
gen mother = id_mother

rename id_kt id_einstaklingur
gen id_match = id_mother
save children_match_mother.dta, replace


*** Generate dataset for mathcing children with their FATHERS ***
clear
use children_match.dta

gen father = id_father
gen mother = id_mother

rename id_kt id_einstaklingur
gen id_match = id_father
save children_match_father.dta, replace




**** MATCH WITH MOTHER ***
clear
use children_match_mother.dta

merge m:1 id_match using parents_match.dta
sort _merge
drop if _merge != 3
drop _merge

* Keep relevant variables from mother
keep id_einstaklingur edu married born_west
rename id_einstaklingur id_kt
rename edu edu_mother
rename married married_mother
rename born_west born_west_mother
save children_aftermatch_mother.dta, replace


**** MATCH WITH FATHER ***
clear
use children_match_father.dta

merge m:1 id_match using parents_match.dta
sort _merge
drop if _merge != 3
drop _merge

* Keep relevant variables from father
keep id_einstaklingur edu married born_west
rename id_einstaklingur id_kt
rename edu edu_father
rename married married_father
rename born_west born_west_father
save children_aftermatch_father.dta, replace



*** MERGE THE TWO DATASETS TOGETHER
clear
use children_aftermatch_mother.dta
merge 1:1 id_kt using children_aftermatch_father.dta
sort _merge
drop _merge

* Count individuals
by id_kt, sort: gen nvals = _n == 1
count if nvals




*** Generate Parent education: It is father's education if not missing, otherwise mother's
gen parent_edu = edu_father
replace parent_edu = edu_mother if edu_father ==.
gen parent_edu_max = max(edu_father,edu_mother)

gen parent_married = married_father
replace parent_married = married_mother if married_father ==.

** Dummy for post-compulsory education
gen parent_further = 0 if parent_edu_max !=.
replace parent_further = 1 if parent_edu_max !=. & parent_edu_max >= 2


* Variables to keep and merge to children for ALL YEARS
keep id_kt edu_mother edu_father parent_edu married_father married_mother parent_married ///
born_west_mother born_west_father parent_edu_max parent_further

save children_matched.dta, replace




*=========================================================================
*		MATCH INFORMATION ABOUT PARENTAL INCOME TO DATASET
*=========================================================================
clear
use "${data_dir}/westman_outcomes.dta"
merge m:1 id_kt using children_matched.dta
sort _merge
drop _merge


save westman_outcomes_familyincome.dta, replace

* Only look at individuals when we first see them in the outcome data
drop if nvals != 1






*=====================================================
*=====================================================

*			Table 13

* 	COMPLIER CHARACTERISTICS RATIOS 

*	Column (1): P[X=1]
*	Column (2): P[X=1|Complier]
*	Column (3): P[X=1|Complier]/P[X=1]

*=====================================================
*=====================================================


*** Dummy variables for non-binary characteristics

* Age - above median or not
summarize age if young25 == 1, detail
gen age_young25_above = 0 if young25 == 1
replace age_young25_above = 1 if age >= 12 & young25 == 1

* house_value --- above median or not
summarize house_value if young25 == 1, detail
gen house_value_young25_above = 0 if young25 == 1
replace house_value_young25_above = 1 if house_value >= 67798.97 & young25 == 1

* house_year --- above median or not
summarize house_year if young25 == 1, detail
gen house_year_young25_above = 0 if young25 == 1
replace house_year_young25_above = 1 if house_year >= 1950 & young25 == 1


	

*** Female

* Column 3
reg new_moved destroyed if young25 == 1
estimates store Model1
reg new_moved destroyed if female_now == 1 & young25 == 1
estimates store Model2

suest Model1 Model2, vce(cluster address)
nlcom (Column_3: [Model2_mean]destroyed / [Model1_mean]destroyed), post

scalar bbeta=_b[Column_3]

* Column 1, 2	
count if female_now == 1 & young25 == 1
local count = r(N)
count if nvals == 1 & young25 == 1
local total = r(N)
scalar C1 = (`count'/`total')
di C1
scalar C2 = C1*bbeta
di C2
	
outreg2 using Table_13_complier_characteristics, /// 
tex ctitle(Female) dec(3) addstat("Column 1", C1, "Column 2", C2, "Column 3", bbeta) replace	
	
scalar drop C1 C2 bbeta
	
	
	
	
*** Age above median

* Column 3
reg new_moved destroyed if young25 == 1
estimates store Model1
reg new_moved destroyed if age_young25_above == 1 & young25 == 1
estimates store Model2

suest Model1 Model2, vce(cluster address)
nlcom (Column_3: [Model2_mean]destroyed / [Model1_mean]destroyed), post

scalar bbeta=_b[Column_3]


* Column 1, 2
count if age_young25_above == 1 & young25 == 1
local count = r(N)
count if nvals == 1 & young25 == 1
local total = r(N)
scalar C1 = (`count'/`total')
di C1
scalar C2 = C1*bbeta
di C2
	
outreg2 using Table_13_complier_characteristics, /// 
tex ctitle(Age above median) dec(3) addstat("Column 1", C1, "Column 2", C2, "Column 3", bbeta) append	

scalar drop C1 C2 bbeta



*** Change house 

* Column 3	
reg new_moved destroyed if young25 == 1
estimates store Model1
reg new_moved destroyed if change_house == 1 & young25 == 1
estimates store Model2

suest Model1 Model2, vce(cluster address)
nlcom (Column_3: [Model2_mean]destroyed / [Model1_mean]destroyed), post

scalar bbeta=_b[Column_3]


* Column 1, 2	
count if change_house == 1 & young25 == 1
local count = r(N)
count if nvals == 1 & young25 == 1
local total = r(N)
scalar C1 = (`count'/`total')
di C1
scalar C2 = C1*bbeta
di C2
	
outreg2 using Table_13_complier_characteristics, /// 
tex ctitle(Change house) dec(3) addstat("Column 1", C1, "Column 2", C2, "Column 3", bbeta) append	

scalar drop C1 C2 bbeta



*** Born in the Westman Islands

* Column 3
reg new_moved destroyed if young25 == 1
estimates store Model1
reg new_moved destroyed if born_west == 1 & young25 == 1
estimates store Model2

suest Model1 Model2, vce(cluster address)
nlcom (Column_3: [Model2_mean]destroyed / [Model1_mean]destroyed), post

scalar bbeta=_b[Column_3]


* Column 1, 2
count if born_west == 1 & young25 == 1
local count = r(N)
count if nvals == 1 & young25 == 1
local total = r(N)
scalar C1 = (`count'/`total')
di C1
scalar C2 = C1*bbeta
di C2
	
outreg2 using Table_13_complier_characteristics, /// 
tex ctitle(Born in WI) dec(3) addstat("Column 1", C1, "Column 2", C2, "Column 3", bbeta) append	

scalar drop C1 C2 bbeta




*** House value above median

* Column 3
reg new_moved destroyed if house_value != . & young25 == 1
estimates store Model1
reg new_moved destroyed if house_value_young25_above == 1 & house_value != . & young25 == 1
estimates store Model2

suest Model1 Model2, vce(cluster address)
nlcom (Column_3: [Model2_mean]destroyed / [Model1_mean]destroyed), post

scalar bbeta=_b[Column_3]


* Column 1, 2	
count if house_value != . & young25 == 1 & house_value_young25_above == 1
local count = r(N)
count if house_value != . & young25 == 1
local total = r(N)
scalar C1 = (`count'/`total')
di C1
scalar C2 = C1*bbeta
di C2
	
outreg2 using Table_13_complier_characteristics, /// 
tex ctitle(House value above median) dec(3) addstat("Column 1", C1, "Column 2", C2, "Column 3", bbeta) append	

scalar drop C1 C2 bbeta




*** House year above median

* Column 3
reg new_moved destroyed if house_year != . & young25 == 1
estimates store Model1
reg new_moved destroyed if house_year != . & young25 == 1 & house_year_young25_above == 1
estimates store Model2

suest Model1 Model2, vce(cluster address)
nlcom (Column_3: [Model2_mean]destroyed / [Model1_mean]destroyed), post

scalar bbeta=_b[Column_3]


* Column 1, 2	
count if house_year != . & young25 == 1 & house_year_young25_above == 1
local count = r(N)
count if house_year != . & young25 == 1
local total = r(N)
scalar C1 = (`count'/`total')
di C1
scalar C2 = C1*bbeta
di C2
	
outreg2 using Table_13_complier_characteristics, /// 
tex ctitle(House year above median) dec(3) addstat("Column 1", C1, "Column 2", C2, "Column 3", bbeta) append	

scalar drop C1 C2 bbeta



*** Parent with post-compulsory education

* Column 3
reg new_moved destroyed if parent_further != . & young25 == 1
estimates store Model1
reg new_moved destroyed if parent_further != . & young25 == 1 & parent_further == 1
estimates store Model2

suest Model1 Model2, vce(cluster address)
nlcom (Column_3: [Model2_mean]destroyed / [Model1_mean]destroyed), post

scalar bbeta=_b[Column_3]


* Column 1, 2
count if parent_further != . & young25 == 1 & parent_further == 1
local count = r(N)
count if parent_further != . & young25 == 1
local total = r(N)
scalar C1 = (`count'/`total')
di C1
scalar C2 = C1*bbeta
di C2
	
outreg2 using Table_13_complier_characteristics, /// 
tex ctitle(Parents with post-compulsory education) dec(3) addstat("Column 1", C1, "Column 2", C2, "Column 3", bbeta) append	

scalar drop C1 C2 bbeta


*** Parent married

* Column 3
reg new_moved destroyed if parent_married != . & young25 == 1 
estimates store Model1
reg new_moved destroyed if parent_married != . & young25 == 1 & parent_married == 1
estimates store Model2

suest Model1 Model2, vce(cluster address)
nlcom (Column_3: [Model2_mean]destroyed / [Model1_mean]destroyed), post

scalar bbeta=_b[Column_3]


* Column 1, 2
count if parent_married != . & young25 == 1 & parent_married == 1
local count = r(N)
count if parent_married != . & young25 == 1 
local total = r(N)
scalar C1 = (`count'/`total')
di C1
scalar C2 = C1*bbeta
di C2
	
outreg2 using Table_13_complier_characteristics, /// 
tex ctitle(Parents married) dec(3) addstat("Column 1", C1, "Column 2", C2, "Column 3", bbeta) append	


scalar drop C1 C2 bbeta














