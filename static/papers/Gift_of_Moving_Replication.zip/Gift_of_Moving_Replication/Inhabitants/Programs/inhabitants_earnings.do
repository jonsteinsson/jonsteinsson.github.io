
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 		THIS DOFILE: Estimated effect on earnings				********
********************************************************************************




	*** Set the directory where the results are stored
	cd "${output_dir}"

	clear

	* Load in mached outcome data
	use "${data_dir}/westman_outcomes.dta"

	* Restrict sample to those 25 and older (if not already done)
	replace real_earnings = . if age_now < 25

	
	
	
	
	*=================================================
	*	Table 5	--- RF, IV and OLS --- Young 25
	*=================================================
	
	**** Control mean
	sum real_earnings if destroyed == 0 & young25 == 1
	local mem = r(mean)
	
	* RF
	xi: reg real_earnings destroyed if young25 == 1, vce(cluster address)
	outreg2 using Table_5_earnings_young, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') replace
	
	* RF Controls and Year FE
	xi: reg real_earnings destroyed female_now change_house born_west i.age_now ///
	i.year if young25 == 1, vce(cluster address)
	outreg2 using Table_5_earnings_young, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') append
	
	
	* Wald estimator (IV with no controls)
	reg real_earnings destroyed if young25 == 1
	estimates store RF
	reg new_moved destroyed if young25 == 1 & nvals == 1
	estimates store FS
	
	* Wald 
	suest RF FS, vce(cluster address)
	nlcom (new_moved: [RF_mean]destroyed / [FS_mean]destroyed ), post
	
	scalar bbeta=_b[new_moved]

	outreg2 using Table_5_earnings_young, tex append ctitle(Wald) dec(0) ///
	addstat("Moved", bbeta, "Control Mean", `mem')
	
	
	*** IV (2SLS): Controls and Year FE
	xi: ivreg2 real_earnings female_now change_house born_west i.age_now ///
	i.year (new_moved = destroyed)  if young25 == 1, cluster(address)
	outreg2 using Table_5_earnings_young, tex nocons ctitle(2SLS) ///
	keep(new_moved) dec(0) addstat("Control Mean", `mem') append
	
	
	
	* OLS: No controls
	xi: reg real_earnings new_moved if young25 == 1, vce(cluster address)
	outreg2 using Table_5_earnings_young, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	* OLS: Controls and Year FE
	xi: reg real_earnings new_moved female_now change_house born_west i.age_now ///
	i.year if young25 == 1, vce(cluster address)
	outreg2 using Table_5_earnings_young, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	
	
	
	
	*=================================================
	*	Table 7	--- RF, IV and OLS --- Old 25
	*=================================================
		
	**** Control mean
	sum real_earnings if destroyed == 0 & young25 == 0
	local mem = r(mean)
	
	* RF
	xi: reg real_earnings destroyed if young25 == 0, vce(cluster address)
	outreg2 using Table_7_earnings_old, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') replace
	
	* RF Controls and Year FE
	xi: reg real_earnings destroyed female_now change_house born_west i.age_now ///
	i.year if young25 == 0, vce(cluster address)
	outreg2 using Table_7_earnings_old, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') append
	
	
	* Wald estimator (IV with no controls)
	reg real_earnings destroyed if young25 == 0
	estimates store RF
	reg new_moved destroyed if young25 == 0 & nvals == 1
	estimates store FS
	
	* Wald 
	suest RF FS, vce(cluster address)
	nlcom (new_moved: [RF_mean]destroyed / [FS_mean]destroyed), post
	
	scalar bbeta=_b[new_moved]

	outreg2 using Table_7_earnings_old, tex append ctitle(Wald) dec(0) ///
	addstat("Moved", bbeta, "Control Mean", `mem')
	
	
	*** IV (2SLS): Controls and Year FE
	xi: ivreg2 real_earnings female_now change_house born_west i.age_now ///
	i.year (new_moved = destroyed)  if young25 == 0, cluster(address)
	outreg2 using Table_7_earnings_old, tex nocons ctitle(2SLS) ///
	keep(new_moved) dec(0) addstat("Control Mean", `mem') append
	
	
	
	* OLS: No controls
	xi: reg real_earnings new_moved if young25 == 0, vce(cluster address)
	outreg2 using Table_7_earnings_old, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	* OLS: Controls and Year FE
	xi: reg real_earnings new_moved female_now change_house born_west i.age_now ///
	i.year if young25 == 0, vce(cluster address)
	outreg2 using Table_7_earnings_old, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
		
		
		
	
	*=================================================
	*	Table 6	--- RF, IV and OLS --- Dependents
	*=================================================
	
	
	**** Control mean
	sum real_earnings if destroyed == 0 & dependent == 1
	local mem = r(mean)
	
	* RF
	xi: reg real_earnings destroyed if dependent == 1, vce(cluster address)
	outreg2 using Table_6_earnings_dependant, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') replace
	
	* RF Controls and Year FE
	xi: reg real_earnings destroyed female_now i.age_now i.year ///
	change_house foreign born_west if dependent == 1, vce(cluster address)
	outreg2 using Table_6_earnings_dependant, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') append
	
	
	* Wald estimator (IV with no controls)
	reg real_earnings destroyed if dependent == 1
	estimates store RF
	reg new_moved destroyed if dependent == 1 & nvals == 1
	estimates store FS
	
	* Wald 
	suest RF FS, vce(cluster address)
	nlcom (new_moved: [RF_mean]destroyed / [FS_mean]destroyed), post
	
	scalar bbeta=_b[new_moved]

	outreg2 using Table_6_earnings_dependant, tex append ctitle(Wald) dec(0) ///
	addstat("Moved", bbeta, "Control Mean", `mem')
	
	
	*** IV (2SLS): Controls and Year FE
	xi: ivreg2 real_earnings female_now i.year i.age_now ///
	change_house foreign born_west (new_moved = destroyed) if dependent == 1, cluster(address)
	outreg2 using Table_6_earnings_dependant, tex nocons ctitle(2SLS) ///
	keep(new_moved) dec(0) addstat("Control Mean", `mem') append
	
	
	
	* OLS: No controls
	xi: reg real_earnings new_moved if dependent == 1, vce(cluster address)
	outreg2 using Table_6_earnings_dependant, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	* OLS: Controls and Year FE
	xi: reg real_earnings new_moved female_now i.age_now i.year ///
	change_house foreign born_west if dependent == 1, vce(cluster address)
	outreg2 using Table_6_earnings_dependant, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	
	
	
	*=======================================================================
	*	Table 8	--- RF, IV and OLS --- Household Heads (Independents)
	*=======================================================================

	**** Control mean
	sum real_earnings if destroyed == 0 & independent == 1
	local mem = r(mean)
	
	* RF
	xi: reg real_earnings destroyed if independent == 1, vce(cluster address)
	outreg2 using Table_8_earnings_household_head, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') replace
	
	* RF Controls and Year FE
	xi: reg real_earnings destroyed female_now i.age_now i.year ///
	change_house foreign born_west if independent == 1, vce(cluster address)
	outreg2 using Table_8_earnings_household_head, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') append
	
	
	* Wald estimator (IV with no controls)
	reg real_earnings destroyed if independent == 1
	estimates store RF
	reg new_moved destroyed if independent == 1 & nvals == 1
	estimates store FS
	
	* Wald 
	suest RF FS, vce(cluster address)
	nlcom (new_moved: [RF_mean]destroyed / [FS_mean]destroyed), post
	
	scalar bbeta=_b[new_moved]

	outreg2 using Table_8_earnings_household_head, tex append ctitle(Wald) dec(0) ///
	addstat("Moved", bbeta, "Control Mean", `mem')
	
	
	*** IV (2SLS): Controls and Year FE
	xi: ivreg2 real_earnings female_now i.age_now i.year ///
	change_house foreign born_west (new_moved = destroyed) if independent == 1, cluster(address)
	outreg2 using Table_8_earnings_household_head, tex nocons ctitle(2SLS) ///
	keep(new_moved) dec(0) addstat("Control Mean", `mem') append
	
	
	
	* OLS: No controls
	xi: reg real_earnings new_moved if independent == 1, vce(cluster address)
	outreg2 using Table_8_earnings_household_head, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	* OLS: Controls and Year FE
	xi: reg real_earnings new_moved female_now i.age_now i.year ///
	change_house foreign born_west if independent == 1, vce(cluster address)
	outreg2 using Table_8_earnings_household_head, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	
	
	

 
 
 
	*=================================================
	*	Table A.5 --- RF, IV and OLS --- Young 25 
	*	restricting on years with no pension income
	*=================================================

	* Test on the effects of pension: Set observations of earnings to missing
	* in those years when pension > 0
	 
	 * outcome
	 gen earnings_missing_pension = real_earnings
	 replace earnings_missing_pension = . if pension > 0 & age_now < 67
	 
	 sum earnings_missing_pension  if young25 == 1 & destroyed == 0, detail 
	 sum real_earnings  if young25 == 1 & destroyed == 0, detail 
	 
	 
	 
	 
	**** Control mean
	sum earnings_missing_pension if destroyed == 0 & young25 == 1
	local mem = r(mean)
	
	* RF
	xi: reg earnings_missing_pension destroyed if young25 == 1, vce(cluster address)
	outreg2 using Table_A5_earnings_no_pension_young, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') replace
	
	* RF Controls and Year FE
	xi: reg earnings_missing_pension destroyed female_now change_house born_west i.age_now ///
	i.year if young25 == 1, vce(cluster address)
	outreg2 using Table_A5_earnings_no_pension_young, tex nocons ctitle(Reduced Form) ///
	keep(destroyed) dec(0) addstat("Control Mean", `mem') append
	
	
	* Wald estimator (IV with no controls)
	reg earnings_missing_pension destroyed if young25 == 1
	estimates store RF
	reg new_moved destroyed if young25 == 1 & nvals == 1
	estimates store FS
	
	* Wald 
	suest RF FS, vce(cluster address)
	nlcom (new_moved: [RF_mean]destroyed / [FS_mean]destroyed), post
	
	scalar bbeta=_b[new_moved]

	outreg2 using Table_A5_earnings_no_pension_young, tex append ctitle(Wald) dec(0) ///
	addstat("Moved", bbeta, "Control Mean", `mem')
	
	
	*** IV (2SLS): Controls and Year FE
	xi: ivreg2 earnings_missing_pension female_now change_house born_west i.age_now ///
	i.year (new_moved = destroyed)  if young25 == 1, cluster(address)
	outreg2 using Table_A5_earnings_no_pension_young, tex nocons ctitle(2SLS) ///
	keep(new_moved) dec(0) addstat("Control Mean", `mem') append
	
	
	
	* OLS: No controls
	xi: reg earnings_missing_pension new_moved if young25 == 1, vce(cluster address)
	outreg2 using Table_A5_earnings_no_pension_young, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	* OLS: Controls and Year FE
	xi: reg earnings_missing_pension new_moved female_now change_house born_west i.age_now ///
	i.year if young25 == 1, vce(cluster address)
	outreg2 using Table_A5_earnings_no_pension_young, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(0) append
	
	
	
	
	
	
	 

	
	*=======================================================
	*	Figure A.4 --- IV estimates by years --- Young 25 
	*=======================================================
	
	
	*** Generate 5 year bins and interactions
	gen year_81_85 = 0
	replace year_81_85 = 1 if year == 1981 | year == 1982 | year == 1983 | year == 1984 | year == 1985    
	gen year_86_90 = 0
	replace year_86_90 = 1 if year == 1986 | year == 1987 | year == 1988 | year == 1989 | year == 1990
	gen year_91_95 = 0
	replace year_91_95 = 1 if year == 1991 | year == 1992 | year == 1993 | year == 1994 | year == 1995
	gen year_96_00 = 0
	replace year_96_00 = 1 if year == 1996 | year == 1997 | year == 1998 | year == 1999 | year == 2000
	gen year_01_05 = 0
	replace year_01_05 = 1 if year == 2001 | year == 2002 | year == 2003 | year == 2004 | year == 2005
	gen year_06_10 = 0
	replace year_06_10 = 1 if year == 2006 | year == 2007 | year == 2008 | year == 2009 | year == 2010
	gen year_11_14 = 0
	replace year_11_14 = 1 if year == 2011 | year == 2012 | year == 2013 | year == 2014

	gen destroyed_year_81_85 = destroyed * year_81_85
	gen destroyed_year_86_90 = destroyed * year_86_90
	gen destroyed_year_91_95 = destroyed * year_91_95
	gen destroyed_year_96_00 = destroyed * year_96_00
	gen destroyed_year_01_05 = destroyed * year_01_05
	gen destroyed_year_06_10 = destroyed * year_06_10
	gen destroyed_year_11_14 = destroyed * year_11_14


	gen moved_year_81_85 = new_moved * year_81_85
	gen moved_year_86_90 = new_moved * year_86_90
	gen moved_year_91_95 = new_moved * year_91_95
	gen moved_year_96_00 = new_moved * year_96_00
	gen moved_year_01_05 = new_moved * year_01_05
	gen moved_year_06_10 = new_moved * year_06_10
	gen moved_year_11_14 = new_moved * year_11_14

	

	ivreg2 real_earnings female_now change_house born_west i.age_now ///
	year_81_85 year_86_90 year_91_95 year_96_00 year_06_10 ///
	(moved_year_81_85 moved_year_86_90 moved_year_91_95 moved_year_96_00 ///
	moved_year_01_05 moved_year_06_10 moved_year_11_14 = ///
	destroyed_year_81_85 destroyed_year_86_90 destroyed_year_91_95 destroyed_year_96_00 ///
	destroyed_year_01_05 destroyed_year_06_10 destroyed_year_11_14) ///
	if young25 == 1, cluster(address)
	*outreg2 using real_earnings_5year_iv_young25, tex replace ctitle(coeff) dec(3)
	
	
	coefplot, keep(moved_year_81_85 moved_year_86_90 moved_year_91_95 ///
	moved_year_96_00 moved_year_01_05 moved_year_06_10 moved_year_11_14) ///
	yline(0, lc(gs4)) vertical rename(moved_year_81_85=81-85 moved_year_86_90=86-90 moved_year_91_95=91-95 ///
	moved_year_96_00=96-00 moved_year_01_05=01-05 moved_year_06_10=06-10 moved_year_11_14=11-14) ///
	recast(connected) msymbol(O) ciopts(recast(rline) lpattern(dash) lcolor(*.4)) format(%15.0fc) ///
	graphregion(color(white) lwidth(vthick)) bgcolor(white) ylabel(,angle(0)) xtitle("Period") ytitle("Treatment Effect ($)")
	graph export Figure_A4_real_earnings_iv_young25.png, replace
	graph export Figure_A4_real_earnings_iv_young25.eps, replace	
	
	
	
	











