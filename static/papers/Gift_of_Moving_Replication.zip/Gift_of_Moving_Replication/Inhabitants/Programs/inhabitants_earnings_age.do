
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Treatment effects by age  				********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"

clear



*===============================================================================
* Figure A.3 (a) and A.3 (b)
*===============================================================================



clear
use "${data_dir}/westman_outcomes.dta"
drop if age_now < 18


*** Generate 2 year age buckets
gen age_now_16_17 = 0
replace age_now_16_17 = 1 if age_now >= 16 & age_now <= 17
gen age_now_18_19 = 0
replace age_now_18_19 = 1 if age_now >= 18 & age_now <= 19
gen age_now_20_21 = 0
replace age_now_20_21 = 1 if age_now >= 20 & age_now <= 21
gen age_now_22_23= 0
replace age_now_22_23 = 1 if age_now >= 22 & age_now <= 23
gen age_now_24_25 = 0
replace age_now_24_25 = 1 if age_now >= 24 & age_now <= 25
gen age_now_26_27 = 0
replace age_now_26_27 = 1 if age_now >= 26 & age_now <= 27
gen age_now_28_29 = 0
replace age_now_28_29 = 1 if age_now >= 28 & age_now <= 29
gen age_now_30_31 = 0
replace age_now_30_31 = 1 if age_now >= 30 & age_now <= 31
gen age_now_32_33 = 0
replace age_now_32_33 = 1 if age_now >= 32 & age_now <= 33
gen age_now_34_35 = 0
replace age_now_34_35 = 1 if age_now >= 34 & age_now <= 35
gen age_now_36_37 = 0
replace age_now_36_37 = 1 if age_now >= 36 & age_now <= 37
gen age_now_38_39 = 0
replace age_now_38_39 = 1 if age_now >= 38 & age_now <= 39
gen age_now_40_41 = 0
replace age_now_40_41 = 1 if age_now >= 40 & age_now <= 41
gen age_now_42_43 = 0
replace age_now_42_43 = 1 if age_now >= 42 & age_now <= 43
gen age_now_44_45 = 0
replace age_now_44_45 = 1 if age_now >= 44 & age_now <= 45
gen age_now_46_47 = 0
replace age_now_46_47 = 1 if age_now >= 46 & age_now <= 47
gen age_now_48_49 = 0
replace age_now_48_49 = 1 if age_now >= 48 & age_now <= 49
gen age_now_50_51 = 0
replace age_now_50_51 = 1 if age_now >= 50 & age_now <= 51
gen age_now_52_53 = 0
replace age_now_52_53 = 1 if age_now >= 52 & age_now <= 53
gen age_now_54_55 = 0
replace age_now_54_55 = 1 if age_now >= 54 & age_now <= 55
gen age_now_56_57 = 0
replace age_now_56_57 = 1 if age_now >= 56 & age_now <= 57
gen age_now_58_59 = 0
replace age_now_58_59 = 1 if age_now >= 58 & age_now <= 59
gen age_now_60_61 = 0
replace age_now_60_61 = 1 if age_now >= 60 & age_now <= 61
gen age_now_62_64 = 0
replace age_now_62_64 = 1 if age_now >= 62 & age_now <= 63



gen destroyed_age_now_16_17  = destroyed * age_now_16_17
gen destroyed_age_now_18_19  = destroyed * age_now_18_19
gen destroyed_age_now_20_21  = destroyed * age_now_20_21
gen destroyed_age_now_22_23  = destroyed * age_now_22_23
gen destroyed_age_now_24_25  = destroyed * age_now_24_25
gen destroyed_age_now_26_27  = destroyed * age_now_26_27
gen destroyed_age_now_28_29  = destroyed * age_now_28_29
gen destroyed_age_now_30_31  = destroyed * age_now_30_31
gen destroyed_age_now_32_33  = destroyed * age_now_32_33
gen destroyed_age_now_34_35  = destroyed * age_now_34_35
gen destroyed_age_now_36_37  = destroyed * age_now_36_37
gen destroyed_age_now_38_39  = destroyed * age_now_38_39
gen destroyed_age_now_40_41  = destroyed * age_now_40_41
gen destroyed_age_now_42_43  = destroyed * age_now_42_43
gen destroyed_age_now_44_45  = destroyed * age_now_44_45
gen destroyed_age_now_46_47  = destroyed * age_now_46_47
gen destroyed_age_now_48_49  = destroyed * age_now_48_49
gen destroyed_age_now_50_51  = destroyed * age_now_50_51
gen destroyed_age_now_52_53  = destroyed * age_now_52_53
gen destroyed_age_now_54_55  = destroyed * age_now_54_55
gen destroyed_age_now_56_57  = destroyed * age_now_56_57
gen destroyed_age_now_58_59  = destroyed * age_now_58_59
gen destroyed_age_now_60_61  = destroyed * age_now_60_61
gen destroyed_age_now_62_64  = destroyed * age_now_62_64



gen moved_age_now_16_17  = new_moved * age_now_16_17
gen moved_age_now_18_19  = new_moved * age_now_18_19
gen moved_age_now_20_21  = new_moved * age_now_20_21
gen moved_age_now_22_23  = new_moved * age_now_22_23
gen moved_age_now_24_25  = new_moved * age_now_24_25
gen moved_age_now_26_27  = new_moved * age_now_26_27
gen moved_age_now_28_29  = new_moved * age_now_28_29
gen moved_age_now_30_31  = new_moved * age_now_30_31
gen moved_age_now_32_33  = new_moved * age_now_32_33
gen moved_age_now_34_35  = new_moved * age_now_34_35
gen moved_age_now_36_37  = new_moved * age_now_36_37
gen moved_age_now_38_39  = new_moved * age_now_38_39
gen moved_age_now_40_41  = new_moved * age_now_40_41
gen moved_age_now_42_43  = new_moved * age_now_42_43
gen moved_age_now_44_45  = new_moved * age_now_44_45
gen moved_age_now_46_47  = new_moved * age_now_46_47
gen moved_age_now_48_49  = new_moved * age_now_48_49
gen moved_age_now_50_51  = new_moved * age_now_50_51
gen moved_age_now_52_53  = new_moved * age_now_52_53
gen moved_age_now_54_55  = new_moved * age_now_54_55
gen moved_age_now_56_57  = new_moved * age_now_56_57
gen moved_age_now_58_59  = new_moved * age_now_58_59
gen moved_age_now_60_61  = new_moved * age_now_60_61
gen moved_age_now_62_64  = new_moved * age_now_62_64






*=========================================================
* 	REDUCED FORM -- Current Age Interactions

*	 Figure A.3. (a)
*=========================================================


tempname myresults
postfile `myresults' age estimate se ci_low ci_upp using myresults.dta, replace

forvalues x = 18(2)62 {

xi: ivreg real_earnings  ///
destroyed_age_now_18_19 destroyed_age_now_20_21 destroyed_age_now_22_23 ///
destroyed_age_now_24_25 destroyed_age_now_26_27 destroyed_age_now_28_29 destroyed_age_now_30_31 ///
destroyed_age_now_32_33 destroyed_age_now_34_35 destroyed_age_now_36_37 destroyed_age_now_38_39 ///
destroyed_age_now_40_41 destroyed_age_now_42_43 destroyed_age_now_44_45 destroyed_age_now_46_47 ///
destroyed_age_now_48_49 destroyed_age_now_50_51 destroyed_age_now_52_53 destroyed_age_now_54_55 ///
destroyed_age_now_56_57 destroyed_age_now_58_59 destroyed_age_now_60_61 ///
destroyed_age_now_62_64 ///
age_now_18_19 age_now_20_21 age_now_22_23 ///
age_now_24_25 age_now_26_27 age_now_28_29 age_now_30_31 ///
age_now_32_33 age_now_34_35 age_now_36_37 age_now_38_39 ///
age_now_40_41 age_now_42_43 age_now_44_45 age_now_46_47 ///
age_now_48_49 age_now_50_51 age_now_52_53 age_now_54_55 ///
age_now_56_57 age_now_58_59 age_now_60_61 ///
age_now_62_64 i.year female_now change_house born_west ///
if young25 == 1, cluster(address)

post `myresults' (`x') (`=_b[destroyed_age_now_`x']') (`=_se[destroyed_age_now_`x']') ///
(`=_b[destroyed_age_now_`x'] - invttail(e(df_r),0.025)*_se[destroyed_age_now_`x']') ///
(`=_b[destroyed_age_now_`x'] + invttail(e(df_r), 0.025)*_se[destroyed_age_now_`x']') 
}
postclose `myresults'


preserve
clear 
use myresults.dta

format estimate %15.0fc
graph twoway scatter estimate ci_low ci_upp age, lpattern(solid dash dash) ///
color(navy gs6 gs6) lwidth(medium thin thin) yline(0,lc(gs4)) ///
legend(label(1 Point Estimate) label(2 95% Confidence Interval) label(3 ) label(4)) ///
legend(order(1 2)) legend(region(lcolor(white))) ylabel(,angle(0)) ///
graphregion(color(white) lwidth(vthick)) bgcolor(white) xlabel(18(6)62) ////
xtitle("Age") ytitle("Reduced From Estimates ($)") connect(1 2 3) msymbol(0 none none) lcolor(*1 *.5 *.5)
graph export Figure_A3a_earnings_reducedform_young25.png, replace
graph export Figure_A3a_earnings_reducedform_young25.eps, replace

restore




*=========================================================
* 	IV -- Current Age Interactions

*	 Figure A.3. (b)
*=========================================================


tempname myresults
postfile `myresults' age estimate se ci_low ci_upp using myresults.dta, replace

forvalues x = 18(2)62 {

xi: ivreg real_earnings ///
(moved_age_now_18_19 moved_age_now_20_21 moved_age_now_22_23 ///
moved_age_now_24_25 moved_age_now_26_27 moved_age_now_28_29 moved_age_now_30_31 ///
moved_age_now_32_33 moved_age_now_34_35 moved_age_now_36_37 moved_age_now_38_39 ///
moved_age_now_40_41 moved_age_now_42_43 moved_age_now_44_45 moved_age_now_46_47 ///
moved_age_now_48_49 moved_age_now_50_51 moved_age_now_52_53 moved_age_now_54_55 ///
moved_age_now_56_57 moved_age_now_58_59 moved_age_now_60_61 ///
moved_age_now_62_64 = ///
destroyed_age_now_18_19 destroyed_age_now_20_21 destroyed_age_now_22_23 ///
destroyed_age_now_24_25 destroyed_age_now_26_27 destroyed_age_now_28_29 destroyed_age_now_30_31 ///
destroyed_age_now_32_33 destroyed_age_now_34_35 destroyed_age_now_36_37 destroyed_age_now_38_39 ///
destroyed_age_now_40_41 destroyed_age_now_42_43 destroyed_age_now_44_45 destroyed_age_now_46_47 ///
destroyed_age_now_48_49 destroyed_age_now_50_51 destroyed_age_now_52_53 destroyed_age_now_54_55 ///
destroyed_age_now_56_57 destroyed_age_now_58_59 destroyed_age_now_60_61 destroyed_age_now_62_64) ///
age_now_18_19 age_now_20_21 age_now_22_23 ///
age_now_24_25 age_now_26_27 age_now_28_29 age_now_30_31 ///
age_now_32_33 age_now_34_35 age_now_36_37 age_now_38_39 ///
age_now_40_41 age_now_42_43 age_now_44_45 age_now_46_47 ///
age_now_48_49 age_now_50_51 age_now_52_53 age_now_54_55 ///
age_now_56_57 age_now_58_59 age_now_60_61 ///
age_now_62_64 i.year female_now change_house born_west  ///
if young25 == 1, cluster(address)

/* *** Estimates for PDV calculation 
outreg2 using iv_estimates_for_PDV_calculation, excel nocons ctitle(coeff) ///
keep(moved_age_now_18_19 moved_age_now_20_21 moved_age_now_22_23 ///
moved_age_now_24_25 moved_age_now_26_27 moved_age_now_28_29 moved_age_now_30_31 ///
moved_age_now_32_33 moved_age_now_34_35 moved_age_now_36_37 moved_age_now_38_39 ///
moved_age_now_40_41 moved_age_now_42_43 moved_age_now_44_45 moved_age_now_46_47 ///
moved_age_now_48_49 moved_age_now_50_51 moved_age_now_52_53 moved_age_now_54_55 ///
moved_age_now_56_57 moved_age_now_58_59 moved_age_now_60_61 ///
moved_age_now_62_64) dec(0) replace
*/

post `myresults' (`x') (`=_b[moved_age_now_`x']') (`=_se[moved_age_now_`x']') ///
(`=_b[moved_age_now_`x'] - invttail(e(df_r),0.025)*_se[moved_age_now_`x']') ///
(`=_b[moved_age_now_`x'] + invttail(e(df_r), 0.025)*_se[moved_age_now_`x']') 
}
postclose `myresults'




preserve
clear 
use myresults.dta

* N.B. no CI at age 55+ for illustration purposes
replace ci_low = . if age >= 56
replace ci_upp = . if age >= 56
format estimate %15.0fc

graph twoway scatter estimate ci_low ci_upp age, lpattern(solid dash dash) ///
color(navy gs6 gs6) lwidth(medium thin thin) yline(0,lc(gs4)) ///
legend(label(1 Point Estimate) label(2 95% Confidence Interval) label(3 ) label(4)) ///
legend(order(1 2)) legend(region(lcolor(white))) ylabel(,angle(0)) ///
graphregion(color(white) lwidth(vthick)) bgcolor(white) xlabel(18(6)62) ////
xtitle("Age") ytitle("Treatment Effect ($)") connect(1 2 3) msymbol(0 none none) ///
lcolor(*1 *.5 *.5) yscale(range(-10000 150000)) ylabel(0(50000)150000)
graph export Figure_A3b_earnings_iv_young25.png, replace
graph export Figure_A3b_earnings_iv_young25.eps, replace

restore





















