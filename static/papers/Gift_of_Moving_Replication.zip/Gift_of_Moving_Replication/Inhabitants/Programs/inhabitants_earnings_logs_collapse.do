
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Effect on log lifetime earnings 		********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"

clear

use "${data_dir}/westman_outcomes.dta"


* Restrict sample to those 25 and older (if not already done)
replace real_earnings = . if age_now < 25

*** Mean life-time earnings
collapse (mean) real_earnings ///
new_moved destroyed female_now change_house born_west young25, by(id_kt address)
gen log_real_earnings = log(real_earnings)



*=================================================
*	Table A.2.	--- RF, IV and OLS --- Young 25
*=================================================
	
*** Reduced form

* Col(1)	
reg log_real_earnings destroyed if young25 == 1, vce(cluster address)
outreg2 using Table_A2_log_real_earnings_young25, tex replace nocons ctitle(Reduced Form) keep(destroyed) dec(3)
* Col(2)
reg log_real_earnings destroyed female_now change_house born_west ///
if young25 == 1, vce(cluster address)
outreg2 using Table_A2_log_real_earnings_young25, tex append nocons ctitle(Reduced Form) keep(destroyed) dec(3)


*** IV (2SLS)

* Col(3)
ivreg2 log_real_earnings (new_moved = destroyed) if young25 == 1, cluster(address)
outreg2 using Table_A2_log_real_earnings_young25, tex append nocons title(IV) keep(new_moved) dec(3)
* Col(4)
ivreg2 log_real_earnings female_now change_house born_west  ///
 (new_moved = destroyed)  if young25 == 1, cluster(address)
outreg2 using Table_A2_log_real_earnings_young25, tex append nocons ctitle(IV) keep(new_moved) dec(3)


*** OLS

* Col(5)
reg log_real_earnings new_moved if young25 == 1, vce(cluster address)
outreg2 using Table_A2_log_real_earnings_young25, tex append nocons ctitle(OLS) keep(new_moved) dec(3)
* Col(6)
reg log_real_earnings new_moved female_now change_house born_west  ///
if young25 == 1, vce(cluster address)
outreg2 using Table_A2_log_real_earnings_young25, tex append nocons ctitle(OLS) keep(new_moved) dec(3)
 
 
















