
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Effects by age at treatment	 		********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"

clear

use "${data_dir}/westman_outcomes.dta"

* Restrict sample to those 25 and older (if not already done)
replace real_earnings = . if age_now < 25

*** FOUR COHORT SPLIT
drop cohort_0_9
gen cohort_0_9 = 0
replace cohort_0_9 = 1 if age >= 0 & age <=9
gen cohort_10_24 = 0
replace cohort_10_24 = 1 if age >= 10 & age <=24
gen cohort_25_50 = 0
replace cohort_25_50 = 1 if age >= 25 & age <=50
gen cohort_50plus = 0
replace cohort_50plus = 1 if age > 50


*** INTERACTIONS
gen destroyed_cohort_0_9 = destroyed * cohort_0_9
gen destroyed_cohort_10_24 = destroyed * cohort_10_24
gen destroyed_cohort_25_50 = destroyed * cohort_25_50
gen destroyed_cohort_50plus = destroyed * cohort_50plus

gen moved_cohort_0_9 = new_moved * cohort_0_9
gen moved_cohort_10_24 = new_moved * cohort_10_24
gen moved_cohort_25_50 = new_moved * cohort_25_50
gen moved_cohort_50plus = new_moved * cohort_50plus



*================================================
* Figure 6
*================================================

ivreg2 real_earnings female_now change_house born_west ///
i.year foreign cohort_0_9 cohort_10_24 cohort_25_50 cohort_50plus ///
(moved_cohort_0_9 moved_cohort_10_24 moved_cohort_25_50 moved_cohort_50plus = ///
destroyed_cohort_0_9 destroyed_cohort_10_24 destroyed_cohort_25_50 destroyed_cohort_50plus ) ///
, cluster(address)
*outreg2 using earnings_iv_4cohorts_tex, tex append ctitle(coeff) dec(3)

*** COEFPLOT
coefplot, keep(moved_cohort_0_9 moved_cohort_10_24 moved_cohort_25_50 moved_cohort_50plus) ///
yline(0, lcolor(gs6)) vertical rename(moved_cohort_0_9=0-9 moved_cohort_10_24=10-24 ///
moved_cohort_25_50=25-50 moved_cohort_50plus=50+) citop msymbol(O) ciopts(recast(rcap)) ///
graphregion(color(white) lwidth(vthick)) bgcolor(white) ylabel(,angle(0)) ///
xtitle("Age at Treatment") title("") subtitle(" ") ytitle("Treatment Effect ($)") format(%15.0fc)
graph export Figure_6_earnings_iv_4cohorts.png, replace
graph export Figure_6_earnings_iv_4cohorts.eps, replace














