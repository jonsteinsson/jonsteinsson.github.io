********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Effects on Education 			 		********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"

clear

* Load in mached outcome data
use "${data_dir}/westman_outcomes_education.dta"



* Only have data on education in 2011
drop if year !=2011

**** EDUCATION ****
* edu==9 means missing education
replace edu =. if edu ==9  

*** EDU - Variable from 1 to 5
gen edu_new = 1 if edu == 3 
replace edu_new = 2 if edu == 4
replace edu_new = 3 if edu == 5
replace edu_new = 4 if edu == 6 
replace edu_new = 5 if edu == 7
replace edu = edu_new

*** Code to years of education
gen edu_years =.
replace edu_years = 10 if edu == 1
replace edu_years = 14 if edu == 2
/* Average lenght 0.5 - 2 years. Set to 1 year */
replace edu_years = 15 if edu == 3 
/* Average lenght of university education is 4 years - 
That is, 50% of those that graduate with Bachelors degree 
have a masters degree or eqv.*/
replace edu_years = 18 if edu == 4 
replace edu_years = 22 if edu == 5

* University dummy
gen university = 1 if edu >= 4 & edu !=.
replace university = 0 if edu < 4 & edu !=.

* Futher education dummy (post-compulsory education)	
gen further = 1 if edu >= 2 & edu !=.
replace further = 0 if edu < 2 & edu !=.




	*=====================================================
	*	Table 9 -- Education in years  -- Young, Old
	*=====================================================
	
	**** Control mean
	sum edu_years if destroyed == 0 & young25 == 1
	local mem = r(mean)
	
	
	* Col(1): IV 
	ivreg2 edu_years female_now change_house born_west i.age ///
	(new_moved = destroyed) if young25==1, cluster(address) 
	outreg2 using Table_9_edu_years_iv_young_old, tex nocons ctitle(IV) ///
	keep(new_moved) dec(2) addstat("Control Mean", `mem') replace
	
	
	* Col(2): OLS
	reg edu_years new_moved female_now change_house born_west ///
	i.age if young25==1, vce(cluster address) 
	outreg2 using Table_9_edu_years_iv_young_old, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(2) append
	
	
		
	**** Control mean
	sum edu_years if destroyed == 0 & young25 == 0
	local mem = r(mean)
	
	* Col(3): IV 
	ivreg2 edu_years female_now change_house born_west i.age ///
	(new_moved = destroyed) if young25==0, cluster(address) 
	outreg2 using Table_9_edu_years_iv_young_old, tex nocons ctitle(IV) ///
	keep(new_moved) dec(2) addstat("Control Mean", `mem') append
	
	* Col(4): OLS
	reg edu_years new_moved female_now change_house born_west ///
	i.age if young25==0, vce(cluster address) 
	outreg2 using Table_9_edu_years_iv_young_old, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(2) append
	
	
		


	
	*=====================================================
	*	Table 10 -- Education levels
	*=====================================================
	
	* Further education dummy
	
	**** Control mean
	sum further if destroyed == 0 & young25 == 1
	local mem = r(mean)
	
	* Col(2)
	ivreg2 further female_now change_house born_west i.age ///
	(new_moved = destroyed) if young25==1, cluster(address)
	outreg2 using Table_10_edu_uni_further_iv_young25, tex nocons ctitle(further) ///
	keep(new_moved) dec(3) addstat("Control Mean", `mem') replace

	
	* University dummy
	
	**** Control mean
	sum university if destroyed == 0 & young25 == 1
	local mem = r(mean)
	
	* Col(1)
	ivreg2 university female_now change_house born_west ///
	i.age (new_moved = destroyed) if young25==1, cluster(address)
	outreg2 using Table_10_edu_uni_further_iv_young25, tex nocons ctitle(university) ///
	keep(new_moved) dec(3) addstat("Control Mean", `mem') append
	
	
	
	
	
	*================================================================
	*	Table 11 -- Education in years  -- Dependents, Household heads
	*================================================================
	
	*** Control mean
	sum edu_years if destroyed == 0 & dependent == 1
	local mem = r(mean)
	
	
	* Col(1): IV 
	ivreg2 edu_years female_now change_house i.age ///
	born_west foreign (new_moved = destroyed) if dependent==1, cluster(address) 
	outreg2 using Table_11_edu_years_iv_dependent_independent, tex nocons ctitle(IV) ///
	keep(new_moved) dec(2) addstat("Control Mean", `mem') replace
	
	* Col(2): OLS
	reg edu_years new_moved female_now change_house i.age ///
	born_west foreign if dependent==1, vce(cluster address)
	outreg2 using Table_11_edu_years_iv_dependent_independent, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(2) append
	
	
	
	*** Control mean
	sum edu_years if destroyed == 0 & independent == 1
	local mem = r(mean)
	

	* Col(3): IV 
	ivreg2 edu_years female_now change_house i.age ///
	born_west foreign (new_moved = destroyed) if independent==1, cluster(address)
	outreg2 using Table_11_edu_years_iv_dependent_independent, tex nocons ctitle(IV) ///
	keep(new_moved) dec(2) addstat("Control Mean", `mem') append
	
	* Col(4): OLS
	reg edu_years new_moved female_now change_house i.age ///
	born_west foreign if independent==1, vce(cluster address) 
	outreg2 using Table_11_edu_years_iv_dependent_independent, tex nocons ctitle(OLS) ///
	keep(new_moved) dec(2) append
	

	

