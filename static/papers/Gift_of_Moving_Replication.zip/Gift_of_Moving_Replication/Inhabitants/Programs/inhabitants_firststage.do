
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: First Stage for Inhabitants			********
********************************************************************************


	*** Set the directory where the results are stored
	cd "${output_dir}"

	clear

	* Load in mached outcome data
	use "${data_dir}/westman_outcomes.dta"
	
	* Restrict sample to those 25 and older (if not already done)
	replace real_earnings = . if age_now < 25
	
		
	*==========================================================================
	*	Table 2. Dependent vs. independent (household heads) -- Young vs. Old
	*==========================================================================
	
	
	*** Row 1
		* Col 1
		count if nvals == 1 & dependent == 1 & young25 == 1
		mat temp1 = r(N)
		* Col 2
		count if nvals == 1 & dependent == 1 & young25 == 0
		mat temp2 = r(N)
		* Col 3
		count if nvals == 1 & dependent == 1
		mat temp3 = r(N)
		
		mat R1 = (temp1, temp2, temp3)
		matrix colnames R1 = Younger_25, Older_25, Total
		matrix rownames R1 = Dependants
		
		
	*** Row 2
		* Col 1
		count if nvals == 1 & independent == 1 & young25 == 1
		mat temp1 = r(N)
		* Col 2
		count if nvals == 1 & independent == 1 & young25 == 0
		mat temp2 = r(N)
		* Col 3
		count if nvals == 1 & independent == 1
		mat temp3 = r(N)
		
		mat R2 = (temp1, temp2, temp3)
		matrix colnames R2 = Younger_25, Older_25, Total
		matrix rownames R2 = Household_Heads	
		
		
	*** Row 3
		* Col 1
		count if nvals == 1 & young25 == 1
		mat temp1 = r(N)
		* Col 2
		count if nvals == 1 & young25 == 0
		mat temp2 = r(N)
		* Col 3
		count if nvals == 1
		mat temp3 = r(N)
		
		mat R3 = (temp1, temp2, temp3)
		matrix colnames R3 = Younger_25, Older_25, Total
		matrix rownames R3 = Total	
		
		
		mat combined_mat = [R1\R2\R3]
		mat2txt, matrix(combined_mat) saving(table_2.tex) replace
		
	
	
	
	
	
	
	*=========================================================
	*	Table 4. First Stage regressions -- All, Young, Old
	*=========================================================

	/* N.B. Only use one observation per individual, 
	the first time we see him in the data (1981 most often) */

	drop nvals
	by id_kt, sort: gen nvals = _n == 1
	count if nvals

	
	**** Control mean
	sum new_moved if nvals == 1 & destroyed == 0
	local mem = r(mean)
	
			*** Relevant F-statistic Column (1)
			xi: ivreg2 real_earnings (new_moved = destroyed), cluster(address)
			* 17.9
			local fstat =  e(widstat)
			
	* All
	reg new_moved destroyed if nvals == 1, vce(cluster address)
	outreg2 using Table_4_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') replace
	

			*** Relevant F-statistic Column (2)
			xi: ivreg2 real_earnings female_now change_house born_west i.age_now ///
			i.year (new_moved = destroyed), cluster(address)
			* 21.1
			local fstat =  e(widstat)
	
	* With controls
	reg new_moved destroyed female_now born_west change_house i.age_now if nvals == 1, vce(cluster address)
	outreg2 using Table_4_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append


	

	**** Control mean
	sum new_moved if nvals == 1 & destroyed == 0 & young25 == 1
	local mem = r(mean)
	
	
			*** Relevant F-statistic Column (3)
			xi: ivreg2 real_earnings (new_moved = destroyed)  if young25 == 1, cluster(address)
			* 10.9
			local fstat =  e(widstat)
			
	* Younger than 25
	reg new_moved destroyed if nvals == 1 & young25 == 1, vce(cluster address)
	outreg2 using Table_4_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append

	
			*** Relevant F-statistic Column (4)
			xi: ivreg2 real_earnings female_now change_house born_west i.age_now ///
			i.year (new_moved = destroyed)  if young25 == 1, cluster(address)
			* 13.6
			local fstat =  e(widstat)

	* With controls
	reg new_moved destroyed female_now born_west change_house i.age_now if nvals == 1 & young25 == 1, vce(cluster address)
	outreg2 using Table_4_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append


		

	

	**** Control mean
	sum new_moved if nvals == 1 & destroyed == 0 & young25 == 0
	local mem = r(mean)	

	
			*** Relevant F-statistic Column (5)
			xi: ivreg2 real_earnings (new_moved = destroyed)  if young25 == 0, cluster(address)
			* 25.8
			local fstat =  e(widstat)
			
	* 25 and Older
	reg new_moved destroyed if nvals == 1 & young25 == 0, vce(cluster address)
	outreg2 using Table_4_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append
		
		
			*** Relevant F-statistic Column (6)
			xi: ivreg2 real_earnings female_now change_house born_west i.age_now ///
			i.year (new_moved = destroyed)  if young25 == 0, cluster(address)
			* 27.7	
			local fstat =  e(widstat)
			
	* With controls
	reg new_moved destroyed female_now born_west change_house i.age_now if nvals == 1 & young25 == 0, vce(cluster address)
	outreg2 using Table_4_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append



		

	
	
		
	
	*===================================================================
	*	Appendix Table A.1. First Stage: Dependent vs. independent
	*===================================================================

	drop nvals
	by id_kt, sort: gen nvals = _n == 1
	count if nvals

	
	
	**** Control mean
	sum new_moved if nvals == 1 & destroyed == 0
	local mem = r(mean)
	
			*** Relevant F-statistic Column (1)
			xi: ivreg2 real_earnings (new_moved = destroyed), cluster(address)
			* 17.9
			local fstat =  e(widstat)
			
	* All
	reg new_moved destroyed if nvals == 1, vce(cluster address)
	outreg2 using Table_A1_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') replace
	

			*** Relevant F-statistic Column (2)
			xi: ivreg2 real_earnings female_now change_house born_west i.age_now ///
			i.year (new_moved = destroyed), cluster(address)
			* 21.1
			local fstat =  e(widstat)
			
	* With controls
	reg new_moved destroyed female_now born_west change_house i.age_now if nvals == 1, vce(cluster address)
	outreg2 using Table_A1_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append
		
	
	
	
	
	**** Control mean
	sum new_moved if nvals == 1 & destroyed == 0 & dependent == 1
	local mem = r(mean)
	
	
			*** Relevant F-statistic Column (3)
			xi: ivreg2 real_earnings (new_moved = destroyed)  if dependent == 1, cluster(address)
			* 8.9
			local fstat =  e(widstat)
			
	*** Dependent
	reg new_moved destroyed if nvals == 1 & dependent == 1, vce(cluster address)
	outreg2 using Table_A1_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append


			*** Relevant F-statistic Column (4)	
			xi: ivreg2 real_earnings female_now foreign change_house born_west i.age_now ///
			i.year (new_moved = destroyed)  if dependent == 1, cluster(address)
			* 11.4
			local fstat =  e(widstat)
	
	**** With controls
	reg new_moved destroyed female_now foreign born_west change_house i.age_now if nvals == 1 & dependent == 1, vce(cluster address)
	outreg2 using Table_A1_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append


	
	

	**** Control mean
	sum new_moved if nvals == 1 & destroyed == 0 & independent == 1
	local mem = r(mean)
	
	
			*** Relevant F-statistic Column (5)
			xi: ivreg2 real_earnings (new_moved = destroyed)  if independent == 1, cluster(address)
			* 27.5
			local fstat =  e(widstat)
			
	*** Independent
	reg new_moved destroyed if nvals == 1 & independent == 1, vce(cluster address)
	outreg2 using Table_A1_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append
		

			*** Relevant F-statistic Column (6)
			xi: ivreg2 real_earnings female_now foreign change_house born_west i.age_now ///
			i.year (new_moved = destroyed)  if independent == 1, cluster(address)
			* 29.4
			local fstat =  e(widstat)	
		
	**** With controls
	reg new_moved destroyed female_now foreign born_west change_house i.age_now if nvals == 1 & independent == 1, vce(cluster address)
	outreg2 using Table_A1_firststage_inhabitants, tex nocons ctitle(coeff) ///
	keep(destroyed) dec(3) addstat("Control Mean", `mem', "F-statistic", `fstat') append



	




