
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Effects on other outcomes		 		********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"


*=========================================
*		Pension recipient
*
*		Table 14, row 1
*		Table A.4 row 1
*=========================================



clear 
* Load in mached outcome data
use "${data_dir}/westman_outcomes.dta"



*** Pension recipient
gen pension_recipient = 0
replace pension_recipient = 1 if pension > 0

*** Table 14. Young - Pension recipient

* Control mean
sum pension_recipient if young25 == 1 & destroyed == 0
local mem = r(mean)

* IV 2SLS
xi: ivreg2 pension_recipient female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed)  if young25 == 1, cluster(address)
outreg2 using Table_14_other_outcomes_young25, tex nocons ctitle(Pension Recipient -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') replace

* OLS
xi: reg pension_recipient new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 1, vce(cluster address)
outreg2 using Table_14_other_outcomes_young25, tex nocons ctitle(Pension Recipient -- OLS) ///
keep(new_moved) append




* Control mean
sum pension_recipient if young25 == 0 & destroyed == 0
local mem = r(mean)

* IV 2SLS
xi: ivreg2 pension_recipient female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed)  if young25 == 0, cluster(address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Pension Recipient -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') replace

* OLS
xi: reg pension_recipient new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 0, vce(cluster address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Pension Recipient -- OLS) ///
keep(new_moved) dec(3)  append


	





*=========================================
*		Death before age 50
*
*		Table 14, row 2
*		Table A.4 row 2
*=========================================


clear
use "${data_dir}/westman_outcomes.dta"

collapse (max) dnarr age_now year, by(id_kt)
gen early_death = 0
replace early_death = 1 if age_now < 50 & dnarr !=.
keep id_kt year early_death

save death_new.dta, replace


clear
use "${data_dir}/westman_outcomes.dta"

merge m:1 id_kt year using death_new.dta
sort _merge
keep if _merge == 3
drop _merge


*** Throw out those that have not reached age of 50 by 2014
keep if byear <= 1964


*** Table 14. Young - Early Death


* Control mean
sum early_death if young25 == 1 & destroyed == 0
local mem = r(mean)


* IV 2SLS
xi: ivreg2 early_death female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed)  if young25 == 1, cluster(address)
outreg2 using Table_14_other_outcomes_young25, tex nocons ctitle(Early Death -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') append

* OLS
xi: reg early_death new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 1, vce(cluster address)
outreg2 using Table_14_other_outcomes_young25, tex nocons ctitle(Early Death -- OLS) ///
keep(new_moved) dec(3) append




*** Table A.4. Old - Early Death

* Control mean
sum early_death if young25 == 0 & destroyed == 0
local mem = r(mean)


* IV 2SLS
xi: ivreg2 early_death female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed)  if young25 == 0, cluster(address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Early Death -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') append

* OLS
xi: reg early_death new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 0, vce(cluster address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Early Death -- OLS) ///
keep(new_moved) dec(3) append







*=========================================
*		Marriage
*
*		Table 14, row 3
*		Table A.4 row 3
*=========================================

clear
use "${data_dir}/westman_outcomes.dta"


*** Table 14. Young - Marriage

* Control mean
sum married_now if young25 == 1 & destroyed == 0
local mem = r(mean)

* IV 
xi: ivreg2 married_now female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed)  if young25 == 1, cluster(address)
outreg2 using Table_14_other_outcomes_young25, tex nocons ctitle(Married -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') append

* OLS
xi: reg married_now new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 1, vce(cluster address)
outreg2 using Table_14_other_outcomes_young25, tex nocons ctitle(Married -- OLS) ///
keep(new_moved) dec(3) append





*** Table A.4. Old - Marriage

* Control mean 
sum married_now if young25 == 0 & destroyed == 0
local mem = r(mean)


* IV
xi: ivreg2 married_now female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed) if young25 == 0, cluster(address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Married -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') append

* OLS
xi: reg married_now new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 0, vce(cluster address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Married -- OLS) ///
keep(new_moved) dec(3) append





*=========================================
*		Number of children
*
*		Table 14, row 4
*		Table A.4 row 4
*=========================================

 
clear
use "${data_dir}/westman_outcomes.dta"

collapse (max) nr_children, by(id_kt)
rename nr_children total_nr_children

tempname `children'
save `children'.dta, replace

use "${data_dir}/westman_outcomes.dta" 

merge m:1 id_kt using `children'.dta
drop _merge


 
*** Table 14. Young - Number of children

* Control mean 
sum total_nr_children if young25 == 1 & destroyed == 0
local mem = r(mean)

* IV 
xi: ivreg2 total_nr_children female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed)  if young25 == 1, cluster(address)
outreg2 using Table_14_other_outcomes_young25, tex nocons ctitle(Number of Children -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') append

* OLS
xi: reg total_nr_children new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 1, vce(cluster address)
outreg2 using Table_14_other_outcomes_young25, tex nocons ctitle(Number of Children -- OLS) ///
keep(new_moved) dec(3) append




*** Table A.4. Old - Number of children

* Control mean 
sum total_nr_children if young25 == 0 & destroyed == 0
local mem = r(mean)


* IV
xi: ivreg2 total_nr_children female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed)  if young25 == 0, cluster(address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Number of Children -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') append

* OLS
xi: reg total_nr_children new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 0, vce(cluster address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Number of Children -- OLS) ///
keep(new_moved) dec(3) append





*=========================================
*		Labor supply
*
*		Table A.4 row 5
*=========================================


*** Table A.4. Old - Labor supply

* Control mean
sum labor_supply if young25 == 0 & destroyed == 0
local mem = r(mean)


* IV 
xi: ivreg2 labor_supply female_now change_house born_west ///
i.age_now i.year (new_moved = destroyed)  if young25 == 0, cluster(address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Labor Supply -- IV) ///
keep(new_moved) dec(3) addstat("Control Mean", `mem') append

* OLS
xi: reg labor_supply new_moved female_now change_house born_west ///
i.age_now i.year if young25 == 0, vce(cluster address)
outreg2 using Table_A4_other_outcomes_old25, tex nocons ctitle(Labor Supply -- OLS) ///
keep(new_moved) dec(3) append









