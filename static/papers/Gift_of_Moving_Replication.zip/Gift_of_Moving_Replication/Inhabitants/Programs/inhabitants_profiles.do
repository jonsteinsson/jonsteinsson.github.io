
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Earnings profiles						********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"


*======================================================
* Figure 3
*======================================================

clear
use "${data_dir}/westman_outcomes.dta"
format real_earnings %15.0fc

* Restrict sample to those 25 and older (if not already done)
replace real_earnings = . if age_now < 25

collapse real_earnings, by (year destroyed young25)

* Earnings - Young25
graph twoway (line real_earnings year if destroyed == 1 & young25 == 1, legend(label(1 "Destroyed" )) ///
lpattern(solid) ylabel(,angle(0)) xtitle("Year") ytitle("Average Earnings ($)") ///
legend(region(color(white))) graphregion(color(white) lwidth(vthick)) bgcolor(white) xlabel(1980(5)2015) ) ///
(line real_earnings year if destroyed == 0 & young25 == 1, legend(label(2 "Not Destroyed" )) lpattern(dash))
graph export Figure_3_earnings_treatment_young25.png, replace
graph export Figure_3_earnings_treatment_young25.eps, replace





*======================================================
* Figure 5
*======================================================


clear
use "${data_dir}/westman_outcomes.dta"


gen real_earnings_18_64 = real_earnings 
replace real_earnings_18_64 = . if age_now < 18 | age_now > 64 

collapse real_earnings_18_64, by (age_now destroyed young25)
format real_earnings_18_64 %15.0fc


* Earnings
graph twoway (line real_earnings_18_64 age_now if destroyed == 1  & young25 ==1, legend(label(1 "Destroyed" )) ///
lpattern(solid) ylabel(,angle(0)) title(" ") xtitle("Age") ytitle("Average Earnings ($)") ///
legend(region(color(white))) graphregion(color(white) lwidth(vthick)) bgcolor(white) xlabel(18(6)66) ) ///
(line real_earnings_18_64 age_now if destroyed == 0 & young25 ==1, ///
legend(label(2 "Not Destroyed" )) lpattern(longdash))
graph export Figure_5_earnings_profile_destroyed_young25.png, replace
graph export Figure_5_earnings_profile_destroyed_young25.eps, replace







