
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 			THIS DOFILE: Quantile treatment effects	 		********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"

clear

use "${data_dir}/westman_outcomes.dta"

* Restrict sample to those 25 and older (if not already done)
replace real_earnings = . if age_now < 25



*===========================================
* Young - Reduced form
*===========================================

/*

tempname myresults
postfile `myresults' group estimate se ci_low cu_upp using myresults.dta, replace

forvalues x = 1(1)23 {

ivqte real_earnings (destroyed) if young25 == 1, ///
dummy(female_now change_house born_west age_now year) ///
variance quantile(0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.4 0.45 0.5 ///
0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 0.96 0.97 0.98 0.99)

post `myresults' (`x') (`=_b[Quantile_`x']') (`=_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] - invttail(e(df_r),0.025)*_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] + invttail(e(df_r), 0.025)*_se[Quantile_`x']') 
}
postclose `myresults'

preserve
clear 
use myresults.dta
gen quantile = 0
replace quantile = 5 if group == 1
replace quantile = 10 if group == 2
replace quantile = 15 if group == 3
replace quantile = 20 if group == 4
replace quantile = 25 if group == 5
replace quantile = 30 if group == 6
replace quantile = 35 if group == 7
replace quantile = 40 if group == 8
replace quantile = 45 if group == 9
replace quantile = 50 if group == 10
replace quantile = 55 if group == 11
replace quantile = 60 if group == 12
replace quantile = 65 if group == 13
replace quantile = 70 if group == 14
replace quantile = 75 if group == 15
replace quantile = 80 if group == 16
replace quantile = 85 if group == 17
replace quantile = 90 if group == 18
replace quantile = 95 if group == 19
replace quantile = 96 if group == 20
replace quantile = 97 if group == 21
replace quantile = 98 if group == 22
replace quantile = 99 if group == 23

format estimate %15.0fc

*** Line with mean effect
gen mean_coeff = 3408 if quantile >= 0

graph twoway scatter estimate mean_coeff quantile, lpattern(solid longdash) ///
color(navy forest_green) lwidth(medium medium ) yline(0, lc(gs4)) ///
legend(label(1 Point Estimate) label(2 Point Estimate Mean) ) legend(order(1 2)) ///
legend(region(lcolor(white))) ylabel(,angle(0)) ///
graphregion(color(white) lwidth(vthick)) bgcolor(white) ///
xtitle("Quantile") ytitle("Treatment Effect ($)") connect(1 2) msymbol(0 none ) lcolor(*1 *1) 
graph export coefplot_earnings_quantile_unconditional_reducedform_young25.png, replace

restore

*/


*===========================================
* Old - Reduced form
*===========================================

/*

tempname myresults
postfile `myresults' group estimate se ci_low cu_upp using myresults.dta, replace

forvalues x = 1(1)23 {

ivqte real_earnings (destroyed) if young25 == 0, ///
dummy(female_now change_house born_west age_now year) ///
variance quantile(0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.4 0.45 0.5 ///
0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 0.96 0.97 0.98 0.99)

post `myresults' (`x') (`=_b[Quantile_`x']') (`=_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] - invttail(e(df_r),0.025)*_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] + invttail(e(df_r), 0.025)*_se[Quantile_`x']') 
}
postclose `myresults'

preserve
clear 
use myresults.dta
gen quantile = 0
replace quantile = 5 if group == 1
replace quantile = 10 if group == 2
replace quantile = 15 if group == 3
replace quantile = 20 if group == 4
replace quantile = 25 if group == 5
replace quantile = 30 if group == 6
replace quantile = 35 if group == 7
replace quantile = 40 if group == 8
replace quantile = 45 if group == 9
replace quantile = 50 if group == 10
replace quantile = 55 if group == 11
replace quantile = 60 if group == 12
replace quantile = 65 if group == 13
replace quantile = 70 if group == 14
replace quantile = 75 if group == 15
replace quantile = 80 if group == 16
replace quantile = 85 if group == 17
replace quantile = 90 if group == 18
replace quantile = 95 if group == 19
replace quantile = 96 if group == 20
replace quantile = 97 if group == 21
replace quantile = 98 if group == 22
replace quantile = 99 if group == 23

format estimate %15.0fc

*** Line with mean effect
gen mean_coeff = -799.5 if quantile >= 0

graph twoway scatter estimate mean_coeff quantile, lpattern(solid longdash) ///
color(navy forest_green) lwidth(medium medium ) yline(0, lc(gs4)) ///
legend(label(1 Point Estimate) label(2 Point Estimate Mean) ) legend(order(1 2)) ///
legend(region(lcolor(white))) ylabel(,angle(0)) ///
graphregion(color(white) lwidth(vthick)) bgcolor(white) ///
xtitle("Quantile") ytitle("Treatment Effect ($)") connect(1 2) msymbol(0 none ) lcolor(*1 *1) 
graph export coefplot_earnings_quantile_unconditional_reducedform_old25.png, replace

restore

*/







*===========================================
* 	Figure 4
* 	Young - IV
*===========================================

tempname myresults
postfile `myresults' group estimate se ci_low cu_upp using myresults.dta, replace

forvalues x = 1(1)23 {

ivqte real_earnings (new_moved=destroyed) if young25 == 1, ///
dummy(female_now change_house born_west age_now year) ///
variance quantile(0.05 0.1 0.15 0.20 0.25 0.30 0.35 0.4 0.45 0.5 ///
0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 0.96 0.97 0.98 0.99)

post `myresults' (`x') (`=_b[Quantile_`x']') (`=_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] - invttail(e(df_r),0.025)*_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] + invttail(e(df_r), 0.025)*_se[Quantile_`x']') 
}
postclose `myresults'


preserve
clear 
use myresults.dta
gen quantile = 0
replace quantile = 5 if group == 1
replace quantile = 10 if group == 2
replace quantile = 15 if group == 3
replace quantile = 20 if group == 4
replace quantile = 25 if group == 5
replace quantile = 30 if group == 6
replace quantile = 35 if group == 7
replace quantile = 40 if group == 8
replace quantile = 45 if group == 9
replace quantile = 50 if group == 10
replace quantile = 55 if group == 11
replace quantile = 60 if group == 12
replace quantile = 65 if group == 13
replace quantile = 70 if group == 14
replace quantile = 75 if group == 15
replace quantile = 80 if group == 16
replace quantile = 85 if group == 17
replace quantile = 90 if group == 18
replace quantile = 95 if group == 19
replace quantile = 96 if group == 20
replace quantile = 97 if group == 21
replace quantile = 98 if group == 22
replace quantile = 99 if group == 23

format estimate %15.0fc


*** Line with mean effect
gen mean_coeff = 27532.4 if quantile >= 0

graph twoway scatter estimate mean_coeff quantile, lpattern(solid longdash) ///
color(navy forest_green) lwidth(medium medium) yline(0, lc(gs4)) ///
legend(label(1 Point Estimate) label(2 Point Estimate Mean)) legend(order(1 2)) ///
legend(region(lcolor(white))) ylabel(,angle(0)) ylabel(0(20000)120000) ///
graphregion(color(white) lwidth(vthick)) bgcolor(white) ///
xtitle("Quantile") ytitle("Treatment Effect ($)") connect(1 2) msymbol(0 none) lcolor(*1 *1)
graph export Figure_4_earnings_quantile_iv_young25.png, replace
graph export Figure_4_earnings_quantile_iv_young25.eps, replace

restore





*===========================================
* 	Figure A.5
* 	Old - IV
*===========================================

tempname myresults
postfile `myresults' group estimate se ci_low cu_upp using myresults.dta, replace

forvalues x = 1(1)23 {

ivqte real_earnings (new_moved=destroyed) if young25 == 0, ///
dummy(female_now change_house born_west age_now year) ///
variance quantile(0.05 0.1 0.15 0.20 0.25 0.30 0.35 0.4 0.45 0.5 ///
0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 0.96 0.97 0.98 0.99)

post `myresults' (`x') (`=_b[Quantile_`x']') (`=_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] - invttail(e(df_r),0.025)*_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] + invttail(e(df_r), 0.025)*_se[Quantile_`x']') 
}
postclose `myresults'


preserve
clear 
use myresults.dta
gen quantile = 0
replace quantile = 5 if group == 1
replace quantile = 10 if group == 2
replace quantile = 15 if group == 3
replace quantile = 20 if group == 4
replace quantile = 25 if group == 5
replace quantile = 30 if group == 6
replace quantile = 35 if group == 7
replace quantile = 40 if group == 8
replace quantile = 45 if group == 9
replace quantile = 50 if group == 10
replace quantile = 55 if group == 11
replace quantile = 60 if group == 12
replace quantile = 65 if group == 13
replace quantile = 70 if group == 14
replace quantile = 75 if group == 15
replace quantile = 80 if group == 16
replace quantile = 85 if group == 17
replace quantile = 90 if group == 18
replace quantile = 95 if group == 19
replace quantile = 96 if group == 20
replace quantile = 97 if group == 21
replace quantile = 98 if group == 22
replace quantile = 99 if group == 23

format estimate %15.0fc


*** Line with mean effect
gen mean_coeff = -3930.7 if quantile >= 0

graph twoway scatter estimate mean_coeff quantile, lpattern(solid longdash) ///
color(navy forest_green) lwidth(medium medium) yline(0, lc(gs4)) ///
legend(label(1 Point Estimate) label(2 Point Estimate Mean)) legend(order(1 2)) ///
legend(region(lcolor(white))) ylabel(,angle(0)) ylabel(-100000(20000)0) ///
graphregion(color(white) lwidth(vthick)) bgcolor(white) ///
xtitle("Quantile") ytitle("Treatment Effect ($)") connect(1 2) msymbol(0 none) lcolor(*1 *1)
graph export Figure_A5_earnings_quantile_iv_old25.png, replace
graph export Figure_A5_earnings_quantile_iv_old25.eps, replace

restore






*========================================
* 			Figure A.2
* 		Quantile Effect -- Logs
*========================================

collapse real_earnings ///
new_moved destroyed female_now change_house born_west young25, by(id_kt)
gen log_real_earnings = log(real_earnings)


tempname myresults
postfile `myresults' group estimate se ci_low cu_upp using myresults.dta, replace

forvalues x = 1(1)23 {

ivqte log_real_earnings (new_moved=destroyed) if young25 == 1, ///
dummy(female_now change_house born_west ) ///
variance quantile(0.05 0.1 0.15 0.20 0.25 0.30 0.35 0.4 0.45 0.5 ///
0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 0.96 0.97 0.98 0.99)

post `myresults' (`x') (`=_b[Quantile_`x']') (`=_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] - invttail(e(df_r),0.025)*_se[Quantile_`x']') ///
(`=_b[Quantile_`x'] + invttail(e(df_r), 0.025)*_se[Quantile_`x']') 
}
postclose `myresults'


preserve
clear 
use myresults.dta
gen quantile = 0
replace quantile = 5 if group == 1
replace quantile = 10 if group == 2
replace quantile = 15 if group == 3
replace quantile = 20 if group == 4
replace quantile = 25 if group == 5
replace quantile = 30 if group == 6
replace quantile = 35 if group == 7
replace quantile = 40 if group == 8
replace quantile = 45 if group == 9
replace quantile = 50 if group == 10
replace quantile = 55 if group == 11
replace quantile = 60 if group == 12
replace quantile = 65 if group == 13
replace quantile = 70 if group == 14
replace quantile = 75 if group == 15
replace quantile = 80 if group == 16
replace quantile = 85 if group == 17
replace quantile = 90 if group == 18
replace quantile = 95 if group == 19
replace quantile = 96 if group == 20
replace quantile = 97 if group == 21
replace quantile = 98 if group == 22
replace quantile = 99 if group == 23



*** Line with mean effect
gen mean_coeff = 0.866 if quantile >= 0

graph twoway scatter estimate mean_coeff quantile, lpattern(solid longdash) ///
color(navy forest_green ) lwidth(medium medium) yline(0, lc(gs4)) ///
legend(label(1 Point Estimate) label(2 Point Estimate Mean)) legend(order(1 2)) ///
legend(region(lcolor(white))) ylabel(,angle(0)) ///
graphregion(color(white) lwidth(vthick)) bgcolor(white) ///
xtitle("Quantile") ytitle("Treatment Effect") connect(1 2) msymbol(0 none) lcolor(*1 *1) ylabel(0(0.5)2.5)
graph export Figure_A2_earnings_quantile_iv_young25_logs.png, replace
graph export Figure_A2_earnings_quantile_iv_young25_logs.eps, replace



restore






