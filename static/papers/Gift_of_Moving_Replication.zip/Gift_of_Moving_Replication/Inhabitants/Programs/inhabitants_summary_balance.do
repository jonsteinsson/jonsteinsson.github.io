
********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 		THIS DOFILE: Summary statistics and balance tests		********
********************************************************************************


*** Set the directory where the results are stored
cd "${output_dir}"


clear

*** Number of children in 1973
use "${data_dir}/parents_children_matched.dta"
rename children_1973 nr_children_1973
save children_1973.dta,replace


clear
* Load in mached outcome data
use "${data_dir}/data_westman_summary.dta"

merge 1:1 id_kt using children_1973.dta
drop _merge



*** Missing groups
replace missing_always =0 if missing_always ==.
replace missing_natreg =0 if missing_natreg ==.

*** Total number of missing
gen missing = 0
replace missing = 1 if missing_always == 1
replace missing = 1 if missing_natreg == 1
count if missing == 1


gen young25 = 0
replace young25 = 1 if age < 25



*======================
*	COUNT GROUPS
*======================

* Total sample
* 5,227

* Total sample - found in DeCODE
by id_kt, sort: gen nvals = _n == 1
count if nvals

* Destroyed
count if nvals ==1 & destroyed == 1

* Not Destroyed
count if nvals ==1 & destroyed == 0

* Never found in any records at Statistics Iceland
count if nvals ==1 & missing_always ==1

* Only in the National Registry in 1978-1980
count if nvals ==1 & missing_natreg ==1

* In the National Registry in 1978-1980 -- LIVES ABROAD
count if nvals ==1 & missing_natreg ==1 & abroad == 1

* In the National Registry in 1978-1980 -- DOES NOT LIVE ABROAD 
count if nvals ==1 & missing_natreg ==1 & abroad == 0


* Not Mathced - Destroyed 
count if nvals ==1 & missing_natreg ==1 | missing_always ==1 & destroyed == 1

* Not Mathced - NOT Destroyed 
count if nvals ==1 & missing_natreg ==1 | missing_always ==1 & destroyed == 0





*=========================================================
*	Table 3. Column (1) Summary statistics - YOUNG25
*=========================================================
estpost tabstat house_value house_year female age foreign married ///
nr_children_1973 widow divorsed change_house born_west missing ///
if destroyed == 0 & young25 ==1, statistics(mean) columns(statistics)
esttab using Table_3_col_1.tex, cells("mean") replace



*=========================================================
*	Table 3. Column (2) Balance test - YOUNG25
*========================================================= 


reg house_value destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex replace dec(0) nocons keep(destroyed)

reg house_year destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(2) nocons keep(destroyed)

reg female destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(3) nocons keep(destroyed)

reg age destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(2) nocons keep(destroyed)

reg nr_children_1973 destroyed if young25 ==1
outreg2 using Table_3_col_2, tex append dec(3) nocons keep(destroyed)

reg married destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(3) nocons keep(destroyed)

reg widow destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(2) nocons keep(destroyed)

reg divorsed destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(2) nocons keep(destroyed)

reg change_house destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(2) nocons keep(destroyed)

reg born_west destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(2) nocons keep(destroyed)

reg missing destroyed if young25 ==1, vce(robust)
outreg2 using Table_3_col_2, tex append dec(2) nocons keep(destroyed)






*=========================================================
*	Table 3. Column (3) Summary statistics - OLD25
*=========================================================
estpost tabstat house_value house_year female age foreign married ///
nr_children_1973 widow divorsed edu_years change_house born_west missing ///
if destroyed == 0 & young25 ==0, statistics(mean) columns(statistics)
esttab using Table_3_col_3.tex, cells("mean count") replace



*=========================================================
*	Table 3. Column (4) Balance test - OLD25
*========================================================= 

reg house_value destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex replace dec(0) nocons keep(destroyed)

reg house_year destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(2) nocons keep(destroyed) 

reg female destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(3) nocons keep(destroyed)

reg age destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(2) nocons keep(destroyed)

reg married destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(3) nocons keep(destroyed)

reg nr_children_1973 destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(3) nocons keep(destroyed)

reg widow destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(2) nocons keep(destroyed)

reg divorsed destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(2) nocons keep(destroyed)

reg edu_years destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(2) nocons keep(destroyed)

reg change_house destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(2) nocons keep(destroyed)

reg born_west destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(2) nocons keep(destroyed)

reg missing destroyed if young25 ==0, vce(robust)
outreg2 using Table_3_col_4, tex append dec(2) nocons keep(destroyed)



