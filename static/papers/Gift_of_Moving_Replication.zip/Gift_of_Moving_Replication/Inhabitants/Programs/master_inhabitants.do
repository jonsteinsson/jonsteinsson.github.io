	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 						MASTER DOFILE:					 		********
	******** 	Runs all results on confidential data for Inhabitants		********
	********************************************************************************
	
	
	*** Set directories

	* Define home directory
	global main_dir "... put your main directory here"

	* set data, code, and output directories
	global data_dir ${main_dir}/Data
	global do_dir ${main_dir}/Programs
	global output_dir ${main_dir}/Output

	* Start taking time
	timer clear 3
	timer on 3
	
	* log dofile
	cd "${output_dir}"
	log using analysis_inhabitants_data_log, replace
	
	
	*** Data Preparation 
	* 0.1 Data preparation -- Inhabitants
	do "${do_dir}/dataprep_inhabitants.do"
	
	* 0.2 Data preparation -- Parent-children match
	do "${do_dir}/parents_children_match.do"
	
	
	
	
	*** Analysis 
	* 1. Summary statistics and balance tests
	do "${do_dir}/inhabitants_summary_balance.do"
	
	* 2. First stage
	do "${do_dir}/inhabitants_firststage.do"
	
	* 3. Effect on earnings
	do "${do_dir}/inhabitants_earnings.do"
	
	* 4. Earnings profiles
	do "${do_dir}/inhabitants_profiles.do"
	
	* 5. Effect on earnings by age
	do "${do_dir}/inhabitants_earnings_age.do"
	
	* 6. Effect on log life-time earnings
	do "${do_dir}/inhabitants_earnings_logs_collapse.do"
	
	* 7. Effect on earnings by age at time of eruption
	do "${do_dir}/inhabitants_earnings_treatment_age.do"
	
	* 8. Quantile effects
	do "${do_dir}/inhabitants_quantiles.do"
	
	* 9. Effect on education
	do "${do_dir}/inhabitants_education.do"
	
	* 10. Effect on other outcomes
	do "${do_dir}/inhabitants_other_outcomes.do"
	
	* 11. Complier characteristics
	do "${do_dir}/inhabitants_complier_characteristics.do"
	
	
	
	*** Turn off time and show
	timer off 3
	timer list 3
	
	
	log close
	
	
	
