	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 			THIS DOFILE: Match between parents and children		********
	********************************************************************************
	
	
	*** Set the directory where the results are stored
	cd "${data_dir}"
	clear
	


	*=========================================================================
	*		SAMPLE OF PARENTS - GENERATION OLD
	*=========================================================================
	* Load in data
	use "${data_dir}/westman_outcomes.dta"

	rename destroyed parent_destroyed
	rename byear parent_byear
	rename age parent_age
	rename female parent_female

	collapse parent_destroyed parent_byear parent_age parent_female, by(id_kt)

	* GENERATE ID FOR MATCHING WITH DESCENDANTS
	rename id_kt id_match

	save parents_match.dta, replace
	clear

	 
 
 
	*=========================================================================
	*		SAMPLE OF CHILDREN - GENERATION YOUNG
	*=========================================================================
	use "${data_dir}/westman_outcomes.dta"


	*** Drop if both father and mother cannot be found
			* Count how many
				count if id_father ==. & id_mother ==.
	*Drop			
	drop if id_father ==. & id_mother ==.


	* Count id
	drop nvals
	by id_kt, sort: gen nvals = _n == 1
	count if nvals

	* Restrict to one observation per child - only want to identify the its match to parents
	drop if nvals != 1

	keep id_kt id_father id_mother byear age female
	save children_match.dta, replace



	*** Generate dataset for matching children with their MOTHERS ***
	rename id_father father
	rename id_mother mother

	rename id_kt id_einstaklingur
	gen id_match = mother
	drop if id_match ==.
	save children_match_mother.dta, replace


	*** Generate dataset for mathcing descendants with their FATHERS ***
	clear
	use children_match.dta

	rename id_father father
	rename id_mother mother

	rename id_kt id_einstaklingur
	gen id_match = father
	drop if id_match ==.
	save children_match_father.dta, replace




	**** MATCH MOTHERS with Children ***
	clear
	use parents_match.dta

	merge 1:m id_match using children_match_mother.dta
	sort id_match

	sort _merge
	drop if _merge != 3
	drop _merge

	* Collapse to compute nr of children
	gen children_1973 = 0
	replace children_1973 = 1 if age <= 18

	collapse (sum) children_1973, by(id_match)

	save mothers_aftermatch_children.dta, replace



	**** MATCH FATHERS with Children ***
	clear
	use parents_match.dta

	merge 1:m id_match using children_match_father.dta
	sort id_match

	sort _merge
	drop if _merge != 3
	drop _merge

	* Collapse to compute nr of children
	gen children_1973 = 1

	collapse (sum) children_1973, by(id_match)

	save fathers_aftermatch_children.dta, replace




	*** MERGE THE TWO DATASETS TOGETHER
	clear
	use mothers_aftermatch_children.dta
	append using fathers_aftermatch_children.dta

	*rename id_match id_kt
	save parents_children_matched.dta, replace



		
	*=========================================================================
	*		MATCH TO DATA ON DESTROYED STATUS
	*=========================================================================
	clear
	use parents_match.dta
	merge 1:1 id_match using parents_children_matched.dta
	sort _merge

	replace children_1973 = 0 if _merge == 1 
	drop _merge


	rename id_match id_kt
	keep id_kt children_1973
	save parents_children_matched.dta, replace


















