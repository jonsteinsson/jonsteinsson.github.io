	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 		THIS DOFILE: Average Earnings across location			********
	********************************************************************************
	
	
	*** Set the directory where the results are stored
	cd "${output_dir}"
	

	clear
	import excel "${data_dir}/earnings_location_averages.xlsx", sheet("Sheet1") firstrow


	*** Generate variables in real USD
	gen real_laun =	(laun*(cpi_2014/cpi))/125
	gen real_total_laun = (total_laun*(cpi_2014/cpi))/125

	format real_laun real_total_laun %15.0fc


	*** Earnings by location 
	graph twoway (line real_total_laun ar if location == 1, legend(label(1 "Westman Islands")) lpattern(solid) ///
	ylabel(, angle(0)) xtitle("") ytitle("Average Earnings (2014 $)")) ///
	(line real_total_laun ar if location == 2, legend(label(2 "Capital region")) lpattern(longdash)) ///
	(line real_total_laun ar if location == 3, legend(label(3 "Other regions")) lpattern(dash_dot) ///
	graphregion(color(white) lwidth(vthick)) bgcolor(white) legend(region(lcolor(white))) ///
	xscale(range(1981[6]2014)) xlabel(1981(6)2014) xmtick(1981(6)2014) )  
	graph export Figure_7.png, replace
	graph export Figure_7.eps, replace


	
	*** Earnings of wage earners only
	/* 
	graph twoway (line real_laun ar if location == 1, legend(label(1 "Westman Islands")) lpattern(solid) ///
	ylabel(, angle(0)) xtitle("") ytitle("Average Wage Earnings (2014 $)")) ///
	(line real_laun ar if location == 2, legend(label(2 "Capital region")) lpattern(longdash)) ///
	(line real_laun ar if location == 3, legend(label(3 "Other regions")) lpattern(dash_dot) ///
	graphregion(fcolor(white)) legend(region(lcolor(white))) bgcolor(white) ylabel(20000(5000)40000) xscale(range(1981[6]2014)) xlabel(1981(6)2014) xmtick(1981(6)2014) )  
	graph export real_laun_averages_25_65.png, replace
	*/








