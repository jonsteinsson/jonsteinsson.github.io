

	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 					THIS DOFILE: Fish catch				 		********
	********************************************************************************
	
	
	*** Set the directory where the results are stored
	cd "${output_dir}"
	
	clear
	import excel "${data_dir}/fish_catch.xlsx", sheet("Sheet1") firstrow
	
	
	replace Sudurland=Sudurland/1000
	replace Samtals=Samtals/1000

	format Sudurland %15.0fc
	format Samtals %15.0fc

	graph twoway (line Sudurland year, yaxis(1) xline(1973, lc(gs4))  yscale(range(0[40]250) axis(1)) ///
	ytick(0[40]250) ylabel(0[40]250,angle(0)) legend(label(1 "South Iceland" )) ///
	ytitle("Total fish catch (1,000 tones)", axis(1)) lpattern(solid) xtitle(" ") title(" ") ///
	xlabel(1967(2)1976) text(230 1973 "Eruption", place(e))  )  ///
	(line Samtals year, yaxis(2) yscale(range(0[400]1600) axis(2)) ytick(0[400]1600, axis(2)) ///
	ylabel(0[400]1600,angle(0) axis(2)) legend(label(2 "Iceland Total" )) ///
	ytitle("Total fish catch (1,000 tones)", axis(2)) lpattern(longdash)), ///
	graphregion(color(white) lwidth(vlarge)) bgcolor(white) legend(region(lcolor(white))   )
	graph export fish_catch.png, replace
	graph export fish_catch.eps, replace


