	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 					MASTER DOFILE 1:					 		********
	******** 	Runs all results on non-confidential (open-access) data		********
	********************************************************************************
	
	clear all
	
	**** Set directories

	* Define home directory
	global main_dir "... put your main directory here"
	
	* set data, code, and output directories
	global data_dir ${main_dir}/Data
	global do_programs_dir ${main_dir}/Programs
	global output_dir ${main_dir}/Output
	
	* Start taking time
	timer clear 2
	timer on 2
	
	*** log dofile
	cd "${output_dir}"
	log using analysis_openaccess_data_log, replace
	
	
	*** Population (Figure 2) 
	do "${do_programs_dir}/population_by_year.do"
	
	*** Population (Figure 7) 
	do "${do_programs_dir}/earnings_by_location.do"
	
	*** Spatial analysis (Figure D.1)
	do "${do_programs_dir}/spatial_correlation.do"
	
	*** Prices (Figures F.2 and F.3)
	do "${do_programs_dir}/prices.do"
	
	*** Sector shares (Table A.6)
	do "${do_programs_dir}/sector_shares.do"
	
	*** Fish catch (Figure A.1)
	do "${do_programs_dir}/fish_catch.do"
	
	*** Grades from standardized tests (Figure A.6)
	do "${do_programs_dir}/standardized_test_scores.do"
	
	
	*** Turn off time and show
	timer off 2
	timer list 2
	
	log close
