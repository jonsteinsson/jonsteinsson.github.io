	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 					THIS DOFILE: Population				 		********
	********************************************************************************
	

	 
	*** Set the directory where the results are stored
	cd "${output_dir}"
	

	clear
	import excel "${data_dir}/population_1889_1990.xlsx", sheet("Sheet1") firstrow
	
	* other regions
	gen other = total - capital - westman
	* WI before and after eruption
	gen westman_before = westman if year < 1973
	gen westman_after = westman if year > 1974
	* drop years before 50s
	drop if year < 1950

	format westman %15.0fc
	format westman_before %15.0fc
	format westman_after %15.0fc
	format capital %15.0fc
	format other %15.0fc


	graph twoway (line westman_before year, yaxis(1) color(navy) xline(1973, lc(gs4)) legend(label(1 "Westman Islands (Left)" )) lpattern(solid) /// 
	 ylabel(,angle(0)) xtitle(" ") title(" ") ytitle("Population") yscale(titlegap(*10)) legend(order(1 3 4)) legend(cols(2)) text(5450 1973 "Eruption", place(e)) ) ///
	 (line westman_after year, yaxis(1) color(navy) lpattern(solid) legend(label(2 ))) ///
	 (line capital year, yaxis(2) legend(label(3 "Capital Region (Right)" )) color(maroon) lpattern(longdash)) ///
	(line other year, yaxis(2) ylabel(,angle(0) axis(2)) legend(label(4 "Other Regions (Right)" )) ytitle("Population", axis(2)) ///
	color(forest_green) lpattern(dash_dot)), graphregion(color(white) lwidth(vthick)) bgcolor(white) legend(region(lcolor(white)) ) 
	graph export Figure2_population_by_year.png, replace
	graph export Figure2_population_by_year.eps, replace


