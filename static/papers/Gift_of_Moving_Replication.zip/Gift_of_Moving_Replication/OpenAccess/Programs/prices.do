	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 		THIS DOFILE: Prices in WI and other regions		 		********
	********************************************************************************


	*** Set the directory where the results are stored
	cd "${output_dir}"

	* Grocery prices
	clear
	import excel "${data_dir}/price_data.xlsx", sheet("Sheet1") firstrow
	
	format sudurnes %9.0fc

	graph twoway (scatter sudurnes year, connect(l) lcolor(midgreen) mcolor(midgreen) msymbol(O) graphregion(fcolor(white)) bgcolor(white) legend(label(1 "Southern Peninsula" )) ) ///
	(scatter sudurland year, connect(l) lcolor(gold) mcolor(gold) msymbol(O) graphregion(fcolor(white)) legend(label(2 "Southern Region" )) ) ///
	(scatter austurland year, connect(l) lcolor(purple) mcolor(purple) msymbol(O) graphregion(fcolor(white)) legend(label(3 "Eastern Region" )) ) ///
	(scatter nordurland_vestra year, connect(l) lcolor(green) mcolor(green) msymbol(O) graphregion(fcolor(white)) legend(label(4 "Northwestern Region" )) ) ///
	(scatter nordurland_eystra year, connect(l) lcolor(cranberry) mcolor(cranberry) msymbol(O) graphregion(fcolor(white)) legend(label(5 "Northeastern Region" )) ) ///
	(scatter vestfirdir year, connect(l) lcolor(ebblue) mcolor(ebblue) msymbol(O) graphregion(fcolor(white)) legend(label(6 "Westfjords" )) ) ///
	(scatter vesturland year, connect(l) lcolor(navy) mcolor(navy) msymbol(O) graphregion(fcolor(white)) legend(label(7 "Western Region" )) ) ///
	(scatter vestmannaeyjar year, connect(l) lcolor(orange_red) mcolor(orange_red) msymbol(O) graphregion(fcolor(white)) legend(label(8 "Westman Islands" )) /// 
	ytitle("Grocery prices relative to Capital Region (%)") title(" ") xtitle(" ") ///
	ylabel(10(2)0, angle(0)) xlabel(1983(1)1991)  graphregion(color(white) lwidth(vlarge)) bgcolor(white) legend(cols(2)) legend(order(8 1 2 3 5 4 6 7)) yline(0, lcolor(gs6))  )
	graph export price_level_regional.png, replace
	graph export price_level_regional.eps, replace




		   
	* Prices by products and categories		   
	clear
	import excel "${data_dir}/food_groups.xlsx", sheet("Sheet1") firstrow
	
	sort price_diff		   
			   
	graph hbar price_diff, over(group, sort(1) descending) ///
	blabel(bar, format(%4.1f)) graphregion(color(white) lwidth(vlarge)) bgcolor(white) ///
	intensity(50)   ytitle("Price relative to Capital Region (%)", size(small))  
	graph export prices_groups.png, replace   
	graph export prices_groups.eps, replace   
			   
		   
		   
		   
