
	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 		THIS DOFILE: Payroll taxes by industry			 		********
	********************************************************************************
	
	
	*** Set the directory where the results are stored
	cd "${output_dir}"

	
	clear
	import excel "${data_dir}/payroll_tax_sectors.xlsx", sheet("Sheet1") firstrow
	
	destring year, replace
	gen share = amount/total 

	collapse share, by(area balk balk_name_short)

	gen aggsector = 1 if balk == "A"
	replace aggsector = 2 if balk == "CC"
	replace aggsector = 3 if balk == "P" | balk == "Q"
	replace aggsector = 4 if balk == "F"
	replace aggsector = 5 if balk == "C"
	replace aggsector = 6 if balk == "G" | balk == "H"
	replace aggsector = 7 if balk == "I" | balk == "R"
	replace aggsector = 8 if balk == "K" | balk == "L"
	replace aggsector = 9 if balk == "J"
	replace aggsector = 10 if balk == "M" | balk == "N"
	replace aggsector = 11 if balk == "O" |balk == "D" | balk == "E"
	replace aggsector = 12 if balk == "B" | balk == "X" | balk == "S" | balk == "U"
	* Residual group
	replace aggsector = 12 if balk == "ZZZ" & area == "Capital Region"
	replace aggsector = 12 if balk == "ZZZ" & area == "Other Regions"
	replace aggsector = 11 if balk == "ZZZ" & area == "Westman Islands"

	collapse(sum) share, by(area aggsector)

	gen sector = "Fishing and Agriculture" if aggsector == 1
	replace sector = "Fish and Food Processing" if aggsector == 2
	replace sector = "Health and Education" if aggsector == 3
	replace sector = "Construction" if aggsector == 4
	replace sector = "Manufacture, Other" if aggsector == 5
	replace sector = "Trade, Transport" if aggsector == 6
	replace sector = "Hospitality and Recreation" if aggsector == 7
	replace sector = "FIRE" if aggsector == 8
	replace sector = "Information Services" if aggsector == 9
	replace sector = "Professional Services" if aggsector == 10
	replace sector = "Government, Other" if aggsector == 11
	replace sector = "Other" if aggsector == 12
	
	rename area region
	rename share sector_share
	keep region sector sector_share
	order region sector sector_share
	
	list 
	export excel using "${output_dir}/sector_shares.xlsx", firstrow(variables) replace
	
	
	
	
	
