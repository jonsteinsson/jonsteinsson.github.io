	
	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 			THIS DOFILE: Spatial correlation 			 		********
	********************************************************************************

	
	clear
	set matsize 5000

	*** Set the directory where the results are stored
	cd "${output_dir}"
	
	clear
	*use "/Users/josefsigurdsson/Dropbox/Research projects using Icelandic data/Westman islands/Replication/Data/house_info_location.dta"
	use "${data_dir}/house_info_location.dta"
	
	*** Generate Matrix for estimating spatial correlation model
	spatwmat, name(streetweights) xcoord(longitude) ycoord(latitude) band(0 1) standardize

	*** Moran's I test and Geary's C test --- Two-tailed tests of spatial autocorrelation
	*** Null-huypothesis: No Spacial Autocorrelation
	spatgsa house_total_value, weights(streetweights) moran geary twotail
	

	*** Generate spatial laggs and perform a randomization test
	splagvar house_total_value, wname(streetweights) wfrom(Stata) reps(1000) seed(123) plot(house_total_value) moran(house_total_value)
	format wy_house_total_value %9.0gc
	
	
	* Moran's I Scatter plot (restrict x-axis to $300,000 for visual purposes)
	twoway (scatter wy_house_total_value house_total_value if house_total_value < 300000, color(navy) graphregion(color(white) lwidth(vlarge)) bgcolor(white)  )  ///
	(scatter wy_house_total_value house_total_value if house_total_value < 300000 & destroyed == 1, color(orange_red)   ///
	graphregion(fcolor(white)) legend(region(lcolor(white))) ylabel(,angle(0)) xtitle("House Values (in 2014 $)") ///
	ytitle("Spatially Lagged House Value (in 2014 $)") legend(order(1 "Not Destroyed" 2 "Destroyed")) ///
	legend(region(lcolor(white))) xlabel(0(50000)310000) ///
	note("Spatial Autocorrelation Tests" "Geary's C: 0.974 (P-value: 0.128)" "Moran's I: 0.020 (P-value: 0.000)" ) )
	graph export Moran_scatter_house_values_destroyed_not.png, replace
	graph export Moran_scatter_house_values_destroyed_not.eps, replace
	
	
	







