
	********************************************************************************
	*******     	  				Gift of Moving							********
	*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
	*******																	********
	******** 		THIS DOFILE: Test scores in standardized tests			********
	********************************************************************************
	
	
	*** Set the directory where the results are stored
	cd "${output_dir}"
	
	clear

	*** MATH
	clear
	import excel "${data_dir}/samreamd_prof_math_DATA.xlsx", sheet("Sheet1") firstrow
	
	destring grade, replace

	collapse grade, by(school area)
	sort grade

	centile grade, centile(16 17 18 19)


	gen capital_area = 0
	replace capital_area = 1 if area=="Reykjavik" | area=="Ngr.Rvk"

	*** Capital Region
	centile grade if capital_area== 1, centile(8.3 8.4 8.5)

	twoway kdensity grade if capital_area == 1, xline(26.58) text(0.19 24.5 "8th pctl", place(e)) ///
	graphregion(color(white)) bgcolor(white) xtitle("Grade") ytitle("Kernel density")
	graph export kdensity_math_capital.png, replace
	graph export kdensity_math_capital.eps, replace


	*** Other Regions
	centile grade if capital_area== 0, centile(26.7 26.8 26.9)

	twoway kdensity grade if capital_area == 0, xline(26.58) text(0.19 24 "27th pctl", place(e)) ///
	graphregion(color(white)) bgcolor(white) xtitle("Grade") ytitle("Kernel density")
	graph export kdensity_math_other.png, replace
	graph export kdensity_math_other.eps, replace
	
	
	
	
	
	*** ENGLISH
	clear
	import excel "${data_dir}/samreamd_prof_english_DATA.xlsx", sheet("Sheet1") firstrow
	
	destring grade, replace

	collapse grade, by(school area)
	sort grade


	centile grade, centile(10 11 12 13 14)


	gen capital_area = 0
	replace capital_area = 1 if area=="Reykjavik" | area=="Ngr.Rvk"

	*** Capital Region
	centile grade if capital_area== 1, centile(4.4 4.5 4.6)

	twoway kdensity grade if capital_area == 1, xline(26.38) text(0.19 24.9 "5th pctl", place(e)) ///
	graphregion(color(white)) bgcolor(white) xtitle("Grade") ytitle("Kernel density")
	graph export kdensity_english_capital.png, replace
	graph export kdensity_english_capital.eps, replace


	*** Other Regions
	centile grade if capital_area== 0, centile(18.8 18.9 19)

	twoway kdensity grade if capital_area == 0, xline(26.38) text(0.19 24.3 "19th pctl", place(e)) ///
	graphregion(color(white)) bgcolor(white) xtitle("Grade") ytitle("Kernel density")
	graph export kdensity_english_other.png, replace
	graph export kdensity_english_other.eps, replace

	
	
	
	
	
	*** ICELANDIC
	clear
	import excel "${data_dir}/samreamd_prof_isl_DATA.xlsx", sheet("Sheet1") firstrow
	
	collapse grade, by(school area)
	sort grade

	centile grade, centile(12 13 14 15 16)


	gen capital_area = 0
	replace capital_area = 1 if area=="Reykjavik" | area=="Ngr.Rvk"


	*** Capital Region
	centile grade if capital_area== 1, centile(6.9 7 7.1)

	twoway kdensity grade if capital_area== 1, xline(26.68) text(0.19 24.2 "7th pctl", place(e)) ///
	graphregion(color(white)) bgcolor(white) xtitle("Grade") ytitle("Kernel density")
	graph export kdensity_icelandic_capital.png, replace
	graph export kdensity_icelandic_capital.eps, replace

	*** Other Regions
	centile grade if capital_area== 0, centile(21.5 22 22.5)

	twoway kdensity grade if capital_area== 0, xline(26.68) text(0.14 24.3 "22nd pctl", place(e)) ///
	graphregion(color(white)) bgcolor(white) xtitle("Grade") ytitle("Kernel density")
	graph export kdensity_icelandic_other.png, replace
	graph export kdensity_icelandic_other.eps, replace






