********************************************************************************
*******     	  				Gift of Moving							********
*******     	Emi Nakamura, Josef Sigurdsson and Jon Steinsson		********
*******																	********
******** 					The BIG MASTER DOFILE						********
******** 																********
******** 				Last updated: June 10th, 2021					********	
********************************************************************************
	
	
* Start taking time
timer clear 1
timer on 1
	
* Define home directory
global home_dir "... put your home directory here"
	
	
*** 1. Analysis using open-access data
do "${home_dir}/OpenAccess/Programs/master_openaccess.do"
	
*** 2. Analysis using confidential data: Inhabitants
do "${home_dir}/Inhabitants/Programs/master_inhabitants.do"

*** 3. Analysis using confidential data: Descendants
do "${home_dir}/Descendants/Programs/master_descendants.do"
	
	
*** Turn off time and show
timer off 1
timer list 1
