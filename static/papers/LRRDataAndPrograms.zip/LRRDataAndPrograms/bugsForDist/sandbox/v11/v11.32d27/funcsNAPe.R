## Support functions for calculating asset prices for the LRR model
##
## Emi Nakamura, Dmitriy Sergeyev, and Jon Steinsson (July 2016)
#####################################################################

libs <-
  c('quantreg', # This library containes a function that creates TeX table from
                # matrix
    'TTR',      # This package allows to use a function that computes running
                # sums runSum() without loops
    'mvtnorm',  # Deals with multivariate normal
    'Hmisc',    # Allows to use approxExtrap() function that performs linear
                # extrapolation
    'MASS')

if (GlobalUseSnow == 1){
  libs <- c(libs,'snow')
}

lapply(libs, require, character.only = T)

## Set control variables
################################################################################
getControlVarNAPi <- function(allData,controlAgg)
{
  nprocs                   <- 32 ## Number of processors to use

  ## choose countries for which to compute P-D and countries to simulate date
  countryToComputePrice    <- which(allData$countryNames == GlobalCountryName)
  countryToSimulateData    <- numeric(length(GlobalCountryToSimulateData))
  for (ii in 1:length(GlobalCountryToSimulateData)){
    countryToSimulateData[ii] <-
      which(allData$countryNames == GlobalCountryToSimulateData[ii])
  }
  baseCountry              <- which(allData$countryNames == GlobalBaseCountry)
  
  ## Lower bounds for global and total SV
  cutOff                   <- 1e-8    #0.00000025 # NSS (cutOff <- 10^(-10) # BKY)
  cutOffW                  <- 1e-8    #0.00000025 # NSS (cutOff <- 10^(-10) # BKY)
  
  ## Chain to use
  Chain                    <- controlAgg$chainToUse
  usePooledChains          <- 1

  ## Reduce computation time by using previously saved results
  updatePDivs              <- GlobalUpdatePDivs
  newInitPDivs             <- GlobalNewInitPDivs

  createFolders            <- 0
  createPredictability     <- GlobalCreatePredictability
  createNextStateFiles     <- GlobalCreateNextStateFiles
  createWeightFiles        <- GlobalCreateWeightFiles
  simulatePrices           <- GlobalSimulatePrices
  computeBHSelasticities   <- GlobalComputeBHSelasticities
  
  ## Utility Function Type
  doEZW                    <- 1
  doPowerU                 <- 0
  
  ## Assets of Interest (program always calculates equity returns)
  getLeveredXXEquity       <- 1
  getOnePerBond            <- 1
  getPerpetuity            <- 0
  getScaledEq              <- 0  # Approximate leverage, lnD = alpha*lnC
  getOPEquity              <- 0  # One Period Equity

  ## Momements of interest
  getRiskyBondDDiv         <- 0  # E_t(D_{T}/D_t) for T > t
  getRiskyBondPDiv         <- 1  # P_t/D_t = E_t(M_{t,T}D_{T}/D_t)
  getSEEeps                <- 1  # E_t(eps_{t+1}    * D_{T}/D_t)/E_t(D_{T}/D_t)
  getSEEepsW               <- 1  # E_t(epsW_{t+1}   * D_{T}/D_t)/E_t(D_{T}/D_t)
  getSEEomega              <- 1  # E_t(omega_{t+1}  * D_{T}/D_t)/E_t(D_{T}/D_t)
  getSEEomegaW             <- 1  # E_t(omegaW_{t+1} * D_{T}/D_t)/E_t(D_{T}/D_t)
  getSCEeps                <- 1  # E_t(eps_{t+1}    * M_{t,T} * D_{T}/D_t)/E_t(M_{t,T} * D_{T}/D_t)
  getSCEepsW               <- 1  # E_t(epsW_{t+1}   * M_{t,T} * D_{T}/D_t)/E_t(M_{t,T} * D_{T}/D_t)
  getSCEomega              <- 1  # E_t(omega_{t+1}  * M_{t,T} * D_{T}/D_t)/E_t(M_{t,T} * D_{T}/D_t)
  getSCEomegaW             <- 1  # E_t(omegaW_{t+1} * M_{t,T} * D_{T}/D_t)/E_t(M_{t,T} * D_{T}/D_t)
  getSPEeps                <- 1
  getSPEepsW               <- 1
  getSPEomega              <- 1
  getSPEomegaW             <- 1

  getDiagnosticStats       <- 0  # V_t(eps_{W,t+1})/SigmaSqW_t
  getCorrEpsWlogDDiv       <- 0

  maxMaturityTPerBonds     <- 5
  
  ## Simulation length
  nSim                     <- 100000
  nSimBurnin               <- 1000
  nnMonteCarlo             <- 1000
  
  ## Iteration parmaters
  tolIntEq                 <- 0.005  # Tolerance for iterations on Equity integral
  tolIntBond               <- 0.005  # Tolerance for iterations on Bond integral
  tolIntOnePerRiskyBond    <- 0.005  # Tolerance for iterations on one-period risky Bond integral
  tolIntLeveredXXEq        <- 0.005
  tolIntPerp               <- 0.005  # Tolerance for iterations on Perpetuity integral
  tolIntScaEq              <- 0.005  # Tolerance for iterations on "scaled" Equity integral
  tolIntOPEq               <- 0.005  # Tolerance for iterations on One Period Equity integral
  maxIter                  <- 50000  # Maximum number of iterations in calculation of PDiv
  
  # Utility parameters
  gammaU                   <- 9      # Risk-Aversion
  psiU                     <- 1.5    # Intertemporal Elasticity of Substitution
  rhoU                     <- 0.01   # Discount Rate (NSS)
  thetaU                   <- (1-gammaU)/(1-1/psiU)
  # Payoff properties of long term bond
  payGrowth                <- 0.90   # Gross growth rate of payoff on the perpetuity

  # Leverage on leveraged equity
  debtEqRatio              <- 0.50

  # Leverage on leveraged XX claim
  phi                      <- 3       # NSS (Note: BKY value of phi is 2.5)
  # Initial value for PDivEq
  initPDivEqUnLev          <- log(12) #4.3 #log(54)
  initPDivEqLev            <- log(12) #2.7 #log(15)
  initPDivOnePerRiskyBond  <- log(12)
  # Coarse State Gridsize
  nCoarseStateGridNu       <- 1
  nCoarseStateGridXX       <- 7
  nCoarseStateGridXXW      <- 7
  nCoarseStateGridSigmaSq  <- 15
  nCoarseStateGridSigmaSqW <- 15
  nCoarseStateGrid         <- (nCoarseStateGridNu*
                nCoarseStateGridXX*
                nCoarseStateGridSigmaSq*
                nCoarseStateGridXXW*
                nCoarseStateGridSigmaSqW)
  # Fine State Gridsize
  nFineStateGridNu         <- 1
  nFineStateGridXX         <- 35
  nFineStateGridXXW        <- 35
  nFineStateGridSigmaSq    <- 31
  nFineStateGridSigmaSqW   <- 51
  nFineStateGrid           <- (nFineStateGridNu*
                nFineStateGridXX*
                nFineStateGridSigmaSq*
                nFineStateGridXXW*
                nFineStateGridSigmaSqW)
  # Integration Gridsize
  nIntGridEta              <- 5
  nIntGridEtaW             <- 5
  # Grid limits in units of standard deviations
  nSdXX                    <- 10
  nSdXXW                   <- 10
  nSdSigmaSq               <- 6
  nSdSigmaSqW              <- 6
  nSdNu                    <- 2

  nSdEps                   <- 10
  nSdEpsW                  <- 10
  nSdEta                   <- 3
  nSdEtaW                  <- 3
  nSdOmega                 <- 4
  nSdOmegaW                <- 4
  
  ## Exchange rate computation
  computeER                <- 1
  saveSimulatedReturnsPDF  <- 1

  return(list(Chain                    = Chain,
        usePooledChains          = usePooledChains,
        updatePDivs              = updatePDivs,
        createFolders            = createFolders,
        createNextStateFiles     = createNextStateFiles,
        createWeightFiles        = createWeightFiles,
        simulatePrices           = simulatePrices,
        newInitPDivs             = newInitPDivs,
        createPredictability     = createPredictability,
        doEZW                    = doEZW,
        doPowerU                 = doPowerU,
        getLeveredXXEquity       = getLeveredXXEquity,
        getOnePerBond            = getOnePerBond,
        getRiskyBondPDiv         = getRiskyBondPDiv,
        getPerpetuity            = getPerpetuity,
        getScaledEq              = getScaledEq,
        getOPEquity              = getOPEquity,
        getRiskyBondDDiv         = getRiskyBondDDiv,
        getSEEeps                = getSEEeps,
        getSEEepsW               = getSEEepsW,
        getSEEomega              = getSEEomega,
        getSEEomegaW             = getSEEomegaW,
        getSCEeps                = getSCEeps,
        getSCEepsW               = getSCEepsW,
        getSCEomega              = getSCEomega,
        getSCEomegaW             = getSCEomegaW,
        getSPEeps                = getSPEeps,
        getSPEepsW               = getSPEepsW,
        getSPEomega              = getSPEomega,
        getSPEomegaW             = getSPEomegaW,
        getDiagnosticStats       = getDiagnosticStats,
        getCorrEpsWlogDDiv       = getCorrEpsWlogDDiv,
        maxMaturityTPerBonds     = maxMaturityTPerBonds,
        nSim                     = nSim,
        nSimBurnin               = nSimBurnin,
        maxIter                  = maxIter,
        nnMonteCarlo             = nnMonteCarlo,
        tolIntEq                 = tolIntEq,
        tolIntBond               = tolIntBond,
        tolIntOnePerRiskyBond    = tolIntOnePerRiskyBond,
        tolIntLeveredXXEq        = tolIntLeveredXXEq,
        tolIntPerp               = tolIntPerp,
        tolIntScaEq              = tolIntScaEq,
        tolIntOPEq               = tolIntOPEq,
        gammaU                   = gammaU,
        psiU                     = psiU,
        rhoU                     = rhoU,
        thetaU                   = thetaU,
        payGrowth                = payGrowth,
        debtEqRatio              = debtEqRatio,
        initPDivEqUnLev          = initPDivEqUnLev,
        initPDivEqLev            = initPDivEqLev,
        initPDivOnePerRiskyBond  = initPDivOnePerRiskyBond,
        phi                      = phi,
        nCoarseStateGridNu       = nCoarseStateGridNu,
        nCoarseStateGridXX       = nCoarseStateGridXX,
        nCoarseStateGridXXW      = nCoarseStateGridXXW,
        nCoarseStateGridSigmaSq  = nCoarseStateGridSigmaSq,
        nCoarseStateGridSigmaSqW = nCoarseStateGridSigmaSqW,
        nFineStateGridNu         = nFineStateGridNu,
        nFineStateGridXX         = nFineStateGridXX,
        nFineStateGridXXW        = nFineStateGridXXW,
        nFineStateGridSigmaSq    = nFineStateGridSigmaSq,
        nFineStateGridSigmaSqW   = nFineStateGridSigmaSqW,
        nIntGridEta              = nIntGridEta,
        nIntGridEtaW             = nIntGridEtaW,
        nCoarseStateGrid         = nCoarseStateGrid,
        nFineStateGrid           = nFineStateGrid,
        nSdNu                    = nSdNu,
        nSdXX                    = nSdXX,
        nSdXXW                   = nSdXXW,
        nSdSigmaSq               = nSdSigmaSq,
        nSdSigmaSqW              = nSdSigmaSqW,
        nSdEps                   = nSdEps,
        nSdEpsW                  = nSdEpsW,
        nSdEta                   = nSdEta,
        nSdEtaW                  = nSdEtaW,
        nSdOmega                 = nSdOmega,
        nSdOmegaW                = nSdOmegaW,
        cutOff                   = cutOff,
        cutOffW                  = cutOffW,
        countryToComputePrice    = countryToComputePrice,
        countryToSimulateData    = countryToSimulateData,
        baseCountry              = baseCountry,
        nprocs                   = nprocs,
        computeER                = computeER,
        computeBHSelasticities   = computeBHSelasticities,
        saveSimulatedReturnsPDF  = saveSimulatedReturnsPDF))
}

## Create folders where files with the grid and distribution on this grid are
## stored
################################################################################
createFolders <- function(allData, controlVarNAPi, outDir)
{
  countryToComputePrice <- controlVarNAPi$countryToComputePrice
  for (nn in c(1:length(countryToComputePrice))){
  outDirNextState <- file.path(outDir,
              'nextState',
              allData$countryNames[countryToComputePrice[nn]])
  outDirWeightsOverIntGrid <- file.path(outDir,
                  'weightsOverIntGrid',
                  allData$countryNames[countryToComputePrice[nn]])
  dir.create(outDirNextState,         recursive = TRUE)
  dir.create(outDirWeightsOverIntGrid,recursive = TRUE)
  }
}


createCoarseStateGrid <- function(countryToUse,controlVarNAPi,ParEst,UnobsPosInfo)
{
  # Create Grids
  ###############################################
  # State Vector: Nu, XX, SigmaSq, XXW, SigmaSqW
  # Integration Vector: Nu,EtaW,Eta,Eps,Omega,EpsW,OmegaW
  cutOff                   <- controlVarNAPi$cutOff
  cutOffW                  <- controlVarNAPi$cutOffW

  sigmaSqConst             <- ParEst[UnobsPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW            <- ParEst[UnobsPosInfo$sigmaSqConstW]

  nCoarseStateGridNu       <- controlVarNAPi$nCoarseStateGridNu
  nCoarseStateGridXX       <- controlVarNAPi$nCoarseStateGridXX
  nCoarseStateGridXXW      <- controlVarNAPi$nCoarseStateGridXXW
  nCoarseStateGridSigmaSq  <- controlVarNAPi$nCoarseStateGridSigmaSq
  nCoarseStateGridSigmaSqW <- controlVarNAPi$nCoarseStateGridSigmaSqW

  nSdNu         <- controlVarNAPi$nSdNu
  nSdXX         <- controlVarNAPi$nSdXX
  nSdXXW        <- controlVarNAPi$nSdXXW
  nSdSigmaSq    <- controlVarNAPi$nSdSigmaSq
  nSdSigmaSqW   <- controlVarNAPi$nSdSigmaSqW

  sigmaNu <- sqrt(ParEst[UnobsPosInfo$sigmaSqNu][countryToUse])

  sigmaXX <- sqrt(ParEst[UnobsPosInfo$sigmaSqConst][countryToUse]/(1-ParEst[UnobsPosInfo$rho]^2) +
        ParEst[UnobsPosInfo$sigmaSqConstW]/(1 - ParEst[UnobsPosInfo$rhoW]^2))

  sigmaXXW      <- sqrt(ParEst[UnobsPosInfo$sigmaSqConstW]/(1 - ParEst[UnobsPosInfo$rhoW]^2))
  sigmaSigmaSq  <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmega]/(1 - ParEst[UnobsPosInfo$gammma]^2))
  sigmaSigmaSqW <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmegaW]/(1 - ParEst[UnobsPosInfo$gammma]^2))

  # Create Gridpoints
  #################################
  #---------------Nu---------------
  if (nCoarseStateGridNu == 1) {
    gridNu       <- 0
  } else {
    gridNu       <- seq(-nSdNu*sigmaNu,
              nSdNu*sigmaNu,
              length.out = nCoarseStateGridNu)
  }
  #-------------SigmaSqW-----------
  if (nCoarseStateGridSigmaSqW == 1) {
    gridSigmaSqW <- sigmaSqConstW
  } else {
    gridSigmaSqW <- seq(max(cutOffW,sigmaSqConstW - nSdSigmaSqW*sigmaSigmaSqW),
              sigmaSqConstW + nSdSigmaSqW*sigmaSigmaSqW,
              length.out = nCoarseStateGridSigmaSqW)
  }
  #--------------XXW---------------
  if (nCoarseStateGridXXW == 1) {
    gridXXW      <- 0
  } else {
    gridXXW      <- seq(-nSdXXW*sigmaXXW,
              nSdXXW*sigmaXXW,
              length.out = nCoarseStateGridXXW)
  }
  #---------------SigmaSq----------
  if (nCoarseStateGridSigmaSq == 1) {
    gridSigmaSq  <- sigmaSqConst
  } else {
    gridSigmaSq  <- seq(max(cutOff - max(gridSigmaSqW),
              sigmaSqConst - nSdSigmaSq*sigmaSigmaSq),
              sigmaSqConst + nSdSigmaSq*sigmaSigmaSq,
              length.out = nCoarseStateGridSigmaSq)
  }
  #---------------XX---------------
  if (nCoarseStateGridXX == 1) {
    gridXX <- 0
  } else {
    gridXX <- seq(-nSdXX*sigmaXX,
            nSdXX*sigmaXX,
            length.out = nCoarseStateGridXX)
  }
  #Create state grid
  coarseStateGrid  <- as.matrix(expand.grid(gridNu,gridXX,gridSigmaSq,gridXXW,gridSigmaSqW))
  dimnames(coarseStateGrid)[[2]] <- c('Nu','XX','SigmaSq','XXW','SigmaSqW')
  return(list(coarseStateGrid = coarseStateGrid,
        gridNu          = gridNu,
        gridXX          = gridXX,
        gridSigmaSq     = gridSigmaSq,
        gridXXW         = gridXXW,
        gridSigmaSqW    = gridSigmaSqW))
}

createFineStateGrid <- function(countryToUse,controlVarNAPi,ParEst,UnobsPosInfo)
{
  cutOff                 <- controlVarNAPi$cutOff
  cutOffW                <- controlVarNAPi$cutOffW

  sigmaSqConst           <- ParEst[UnobsPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW          <- ParEst[UnobsPosInfo$sigmaSqConstW]

  nFineStateGridNu       <- controlVarNAPi$nFineStateGridNu
  nFineStateGridXX       <- controlVarNAPi$nFineStateGridXX
  nFineStateGridXXW      <- controlVarNAPi$nFineStateGridXXW
  nFineStateGridSigmaSq  <- controlVarNAPi$nFineStateGridSigmaSq
  nFineStateGridSigmaSqW <- controlVarNAPi$nFineStateGridSigmaSqW

  nSdNu                  <- controlVarNAPi$nSdNu
  nSdXX                  <- controlVarNAPi$nSdXX
  nSdXXW                 <- controlVarNAPi$nSdXXW
  nSdSigmaSq             <- controlVarNAPi$nSdSigmaSq
  nSdSigmaSqW            <- controlVarNAPi$nSdSigmaSqW

  sigmaNu                <- sqrt(ParEst[UnobsPosInfo$sigmaSqNu][countryToUse])
  sigmaXX                <- sqrt(ParEst[UnobsPosInfo$sigmaSqConst][countryToUse]/(1 - ParEst[UnobsPosInfo$rho]^2) + ParEst[UnobsPosInfo$sigmaSqConstW]/(1 - ParEst[UnobsPosInfo$rhoW]^2))
  sigmaXXW               <- sqrt(ParEst[UnobsPosInfo$sigmaSqConstW]/(1 - ParEst[UnobsPosInfo$rhoW]^2))
  sigmaSigmaSq           <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmega]/(1 - ParEst[UnobsPosInfo$gammma]^2))
  sigmaSigmaSqW          <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmegaW]/(1 - ParEst[UnobsPosInfo$gammma]^2))

  #   Create Gridpoints
  ############################
  #            Nu
  if (nFineStateGridNu == 1) {
    gridNu       <- 0
  } else {
    gridNu       <- seq(-nSdNu*sigmaNu,
               nSdNu*sigmaNu,
               length.out = nFineStateGridNu)
  }
  #            XXW
  if (nFineStateGridXXW == 1) {
    gridXXW      <- 0
  } else {
    gridXXW      <- seq(-nSdXXW*sigmaXXW,
               nSdXXW*sigmaXXW,
               length.out = nFineStateGridXXW)
  }
  #            XX
  if (nFineStateGridXX == 1) {
    gridXX       <- 0
  } else {
    gridXX       <- seq(-nSdXX*sigmaXX,
               nSdXX*sigmaXX,
               length.out = nFineStateGridXX)
  }
  #            SigmaSqW
  if (nFineStateGridSigmaSqW == 1) {
    gridSigmaSqW <- sigmaSqConstW
  } else {
    gridSigmaSqW <- seq(max(cutOffW,sigmaSqConstW - nSdSigmaSqW*sigmaSigmaSqW),
              sigmaSqConstW + nSdSigmaSqW*sigmaSigmaSqW,
              length.out = nFineStateGridSigmaSqW)
  }
  #            SigmaSq
  if (nFineStateGridSigmaSq == 1) {
    gridSigmaSq  <- sigmaSqConst
  } else {
    gridSigmaSq  <- seq(max(cutOff - max(gridSigmaSqW),
              sigmaSqConst - nSdSigmaSq*sigmaSigmaSq),
              sigmaSqConst + nSdSigmaSq*sigmaSigmaSq,
              length.out = nFineStateGridSigmaSq)
  }

  #Create state grid
  fineStateGrid <- as.matrix(expand.grid(gridNu,gridXX,gridSigmaSq,
                      gridXXW,gridSigmaSqW))
  dimnames(fineStateGrid)[[2]] <- c('Nu','XX','SigmaSq','XXW','SigmaSqW')
  return(list(fineStateGrid = fineStateGrid,
        gridNu        = gridNu,
        gridXX        = gridXX,
        gridSigmaSq   = gridSigmaSq,
        gridXXW       = gridXXW,
        gridSigmaSqW  = gridSigmaSqW))
}

createIntGrid <- function(countryToUse,controlVar,ParEst,UnobsPosInfo,fineStateGridList)
{
  nIntGridEta       <- controlVar$nIntGridEta
  nIntGridEtaW      <- controlVar$nIntGridEtaW
  if (length(fineStateGridList$gridNu)>1) {
    incNuGrid     <- (fineStateGridList$gridNu[2] -
              fineStateGridList$gridNu[1])
  } else {
    incNuGrid     <- 0
  }
  if (length(fineStateGridList$gridXX)>1) {
    incEpsGrid    <- (fineStateGridList$gridXX[2] -
              fineStateGridList$gridXX[1])
  } else {
    incEpsGrid    <- 0
  }
  if (length(fineStateGridList$gridXXW)>1) {
    incEpsWGrid   <- (fineStateGridList$gridXXW[2] -
              fineStateGridList$gridXXW[1])
  } else {
    incEpsWGrid   <- 0
  }
  if (length(fineStateGridList$gridSigmaSq)>1) {
    incOmegaGrid  <- (fineStateGridList$gridSigmaSq[2] -
              fineStateGridList$gridSigmaSq[1])
  } else {
    incOmegaGrid  <- 0
  }
  if (length(fineStateGridList$gridSigmaSqW)>1) {
    incOmegaWGrid <- (fineStateGridList$gridSigmaSqW[2] -
              fineStateGridList$gridSigmaSqW[1])
  } else {
    incOmegaWGrid <- 0
  }
  nSdNu          <- controlVar$nSdNu
  nSdEtaW        <- controlVar$nSdEtaW
  nSdEta         <- controlVar$nSdEta
  nSdEps         <- controlVar$nSdEps
  nSdEpsW        <- controlVar$nSdEpsW
  nSdOmega       <- controlVar$nSdOmega
  nSdOmegaW      <- controlVar$nSdOmegaW

  sigmaNu        <- sqrt(ParEst[UnobsPosInfo$sigmaSqNu][countryToUse])
  chi            <- sqrt(ParEst[UnobsPosInfo$chiSq][countryToUse])
  chiW           <- sqrt(ParEst[UnobsPosInfo$chiSqW])
  sigmaEps       <- sqrt(ParEst[UnobsPosInfo$sigmaSqConst][countryToUse]
              +ParEst[UnobsPosInfo$sigmaSqConstW])
  sigmaEpsW      <- sqrt(ParEst[UnobsPosInfo$sigmaSqConstW])
  sigmaOmega     <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmega])
  sigmaOmegaW    <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmegaW])

  #shockvec is : 'Nu','EtaW','Eta','Eps','Omega','EpsW','OmegaW'
  #Create gridpoints

  # Generate Nu Grid
  if (length(fineStateGridList$gridNu) == 1) {
    gridNu         <- 0
  } else {
    gridNuPos      <- seq(0, nSdNu*sigmaNu, by = incNuGrid)
    gridNuNeg      <- sort(-gridNuPos)
    gridNuNeg      <- gridNuNeg[gridNuNeg!=0]
    gridNu         <- c(gridNuNeg,gridNuPos)
  }
  if (length(fineStateGridList$gridNu) == 1) {
    tempGridNu     <- 0
  } else {
    tempGridNu     <-  gridNu - incNuGrid/2
    tempGridNu     <- c(tempGridNu,tempGridNu(length(tempGridNu))+incNuGrid/2)
  }

  # Generate EtaW Grid
  if (nIntGridEtaW == 1) {
     tempGridEtaW    <- 0
  } else {
     tempGridEtaW     <- seq(-nSdEtaW*sigmaEpsW*chiW,
                nSdEtaW*sigmaEpsW*chiW,
                length.out = (nIntGridEtaW+1))
  }
  if (nIntGridEtaW == 1) {
     gridEtaW        <- 0
  } else {
     gridEtaW        <-  (tempGridEtaW[2:(nIntGridEtaW+1)]
              + tempGridEtaW[1:nIntGridEtaW]) /2
  }

  # Generate Eta Grid
  if (nIntGridEta == 1) {
    tempGridEta    <- 0
  } else {
    tempGridEta     <- seq(-nSdEta*sigmaEps*chi,
                nSdEta*sigmaEps*chi,
                length.out = (nIntGridEta+1))
  }
  if (nIntGridEta == 1) {
    gridEta        <- 0
  } else {
    gridEta        <-  (tempGridEta[2:(nIntGridEta+1)]
              + tempGridEta[1:nIntGridEta]) /2
  }

  # Generate Eps Grid
  if (length(fineStateGridList$gridXX) == 1) {
    gridEps        <- 0
  } else {
    gridEpsPos     <- seq(0, nSdEps*sigmaEps, by = incEpsGrid)
    gridEpsNeg     <- sort(-gridEpsPos)
    gridEpsNeg     <- gridEpsNeg[gridEpsNeg!=0]
    gridEps        <- c(gridEpsNeg,gridEpsPos)
  }
  if (length(fineStateGridList$gridXX) == 1) {
    tempGridEps    <- 0
  } else {
    tempGridEps <-  gridEps - incEpsGrid/2
    tempGridEps <- c(tempGridEps,tempGridEps[length(tempGridEps)]+incEpsGrid/2)
  }

  # Generate EpsW Grid
  if (length(fineStateGridList$gridXXW) == 1) {
    gridEpsW       <- 0
  } else {
    gridEpsWPos    <- seq(0, nSdEpsW*sigmaEpsW, by = incEpsWGrid)
    gridEpsWNeg    <- sort(-gridEpsWPos)
    gridEpsWNeg    <- gridEpsWNeg[gridEpsWNeg!=0]
    gridEpsW       <- c(gridEpsWNeg,gridEpsWPos)
  }
  if (length(fineStateGridList$gridXXW) == 1) {
    tempGridEpsW   <- 0
  } else {
    tempGridEpsW   <-  gridEpsW - incEpsWGrid/2
    tempGridEpsW   <- c(tempGridEpsW,
              tempGridEpsW[length(tempGridEpsW)]+incEpsWGrid/2)
  }

  # Generate Omega Grid
  if (length(fineStateGridList$gridSigmaSq) == 1) {
    gridOmega      <- 0
  } else {
    gridOmegaPos   <- seq(0, nSdOmega*sigmaOmega, by = incOmegaGrid)
    gridOmegaNeg   <- sort(-gridOmegaPos)
    gridOmegaNeg   <- gridOmegaNeg[gridOmegaNeg!=0]
    gridOmega      <- c(gridOmegaNeg,gridOmegaPos)
  }
  if (length(fineStateGridList$gridSigmaSq) == 1) {
    tempGridOmega  <- 0
  } else {
    tempGridOmega  <-  gridOmega - incOmegaGrid/2
    tempGridOmega  <- c(tempGridOmega,
              tempGridOmega[length(tempGridOmega)]+incOmegaGrid/2)
  }

  # Generate OmegaW Grid
  if (length(fineStateGridList$gridSigmaSqW) == 1) {
    gridOmegaW     <- 0
  } else {
    gridOmegaWPos  <- seq(0, nSdOmegaW*sigmaOmegaW, by = incOmegaWGrid)
    gridOmegaWNeg  <- sort(-gridOmegaWPos)
    gridOmegaWNeg  <- gridOmegaWNeg[gridOmegaWNeg!=0]
    gridOmegaW     <- c(gridOmegaWNeg,gridOmegaWPos)
  }
  if (length(fineStateGridList$gridSigmaSqW) == 1) {
    tempGridOmegaW <- 0
  } else {
    tempGridOmegaW <-  gridOmegaW - incOmegaWGrid/2
    tempGridOmegaW <- c(tempGridOmegaW,
              tempGridOmegaW[length(tempGridOmegaW)]+incOmegaWGrid/2)
  }
  nIntGridNu     <- length(gridNu)
  nIntGridEtaW   <- length(gridEtaW)
  nIntGridEta    <- length(gridEta)
  nIntGridEps    <- length(gridEps)
  nIntGridEpsW   <- length(gridEpsW)
  nIntGridOmega  <- length(gridOmega)
  nIntGridOmegaW <- length(gridOmegaW)
  nIntGrid       <- (nIntGridEtaW*nIntGridNu*nIntGridEta
            *nIntGridEps*nIntGridEpsW*nIntGridOmega*nIntGridOmegaW)

  sink(file.path(outDir,
      paste("APresults",GlobalCountryName,"txt",sep=".")), append = TRUE)
  cat('nIntGrid:             ',nIntGrid,'\n')
  cat('nIntNu:               ',nIntGridNu,'\n')
  cat('nIntEtaW:             ',nIntGridEtaW,'\n')
  cat('nIntEta:              ',nIntGridEta,'\n')
  cat('nIntEps:              ',nIntGridEps,'\n')
  cat('nIntEpsW:             ',nIntGridEpsW,'\n')
  cat('nIntOmega:            ',nIntGridOmega,'\n')
  cat('nIntOmegaW:           ',nIntGridOmegaW,'\n')
  cat('\n')
  sink()

  # Create integration grid
  # - expand.grid creates data frame from all combinations of the supplied vectors
  intGrid <- expand.grid(gridNu,gridEtaW,gridEta,
              gridEps,gridOmega,gridEpsW,gridOmegaW)

  intGrid <- as.matrix(intGrid)

  dimnames(intGrid)[[2]] <- c('Nu','EtaW','Eta','Eps','Omega','EpsW','OmegaW')

  return(list(intGrid         = intGrid,
        nIntGridNu      = nIntGridNu,
        nIntGridEtaW    = nIntGridEtaW,
        nIntGridEta     = nIntGridEta,
        nIntGridEps     = nIntGridEps,
        nIntGridEpsW    = nIntGridEpsW,
        nIntGridOmega   = nIntGridOmega,
        nIntGridOmegaW  = nIntGridOmegaW,
        nIntGrid        = nIntGrid,
        gridNu          = gridNu,
        gridEtaW        = gridEtaW,
        gridEta         = gridEta,
        gridEps         = gridEps,
        gridOmega       = gridOmega,
        gridEpsW        = gridEpsW,
        gridOmegaW      = gridOmegaW,
        tempGridNu      = tempGridNu,
        tempGridEtaW    = tempGridEtaW,
        tempGridEta     = tempGridEta,
        tempGridEps     = tempGridEps,
        tempGridOmega   = tempGridOmega,
        tempGridEpsW    = tempGridEpsW,
        tempGridOmegaW  = tempGridOmegaW))
}

## Policy function
################################################################################
nextStateFuncGen <- function(countryToUse,
                      coarseStateGridList,
                      fineStateGridList,
                      intGridList,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)
{
  # Create nextStateFunc
  ##################################
  intGridNu                <- intGridList$gridNu
  intGridEtaW              <- intGridList$gridEtaW
  intGridEta               <- intGridList$gridEta
  intGridEps               <- intGridList$gridEps
  intGridEpsW              <- intGridList$gridEpsW
  intGridOmega             <- intGridList$gridOmega
  intGridOmegaW            <- intGridList$gridOmegaW

  nIntGridNu               <- length(intGridNu)
  nIntGridEtaW             <- length(intGridEtaW)
  nIntGridEta              <- length(intGridEta)
  nIntGridEps              <- length(intGridEps)
  nIntGridEpsW             <- length(intGridEpsW)
  nIntGridOmega            <- length(intGridOmega)
  nIntGridOmegaW           <- length(intGridOmegaW)

  fineStateGridNu          <- fineStateGridList$gridNu
  fineStateGridXX          <- fineStateGridList$gridXX
  fineStateGridXXW         <- fineStateGridList$gridXXW
  fineStateGridSigmaSq     <- fineStateGridList$gridSigmaSq
  fineStateGridSigmaSqW    <- fineStateGridList$gridSigmaSqW

  nFineStateGridNu         <- length(fineStateGridNu)
  nFineStateGridXX         <- length(fineStateGridXX)
  nFineStateGridXXW        <- length(fineStateGridXXW)
  nFineStateGridSigmaSq    <- length(fineStateGridSigmaSq)
  nFineStateGridSigmaSqW   <- length(fineStateGridSigmaSqW)

  coarseStateGridSigmaSq   <- coarseStateGridList$gridSigmaSq
  coarseStateGridSigmaSqW  <- coarseStateGridList$gridSigmaSqW

  nCoarseStateGridSigmaSq  <- length(coarseStateGridSigmaSq)
  nCoarseStateGridSigmaSqW <- length(coarseStateGridSigmaSqW)

  nFineStates <- controlVarNAPi$nFineStateGrid
  nInt        <- intGridList$nIntGrid

  rho         <- ParEst[UnobsPosInfo$rho]
  rhoW        <- ParEst[UnobsPosInfo$rhoW]
  gammma      <- ParEst[UnobsPosInfo$gammma]
  xi          <- ParEst[UnobsPosInfo$xi][countryToUse]
  sigmaEps    <- sqrt(ParEst[UnobsPosInfo$sigmaSqConst][countryToUse])
  sigmaEpsW   <- sqrt(ParEst[UnobsPosInfo$sigmaSqConstW])

  cutOff      <- controlVarNAPi$cutOff
  cutOffW     <- controlVarNAPi$cutOffW

  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes <- matrix(FALSE,
                             nFineStateGridSigmaSqW,
                            nFineStateGridSigmaSq)

  for (iiSigmaSq in (1:nFineStateGridSigmaSq)){
  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[,iiSigmaSq] <-
    (fineStateGridSigmaSq[iiSigmaSq] + fineStateGridSigmaSqW >= cutOff)
  }

  nextStateFunc <- function(currentState)
  {
  oldXX               <- currentState[2]
  oldSigmaSq          <- currentState[3]
  oldXXW              <- currentState[4]
  oldSigmaSqW         <- currentState[5]

  nextState           <- numeric(nInt)

  for (iiOmegaW in 1:nIntGridOmegaW){
    runSigmaSqW <- max(sigmaEpsW^2 + gammma * (oldSigmaSqW - sigmaEpsW^2) +
              intGridOmegaW[iiOmegaW],cutOffW)

    indRunSigmaSqW <- which.min(abs(fineStateGridSigmaSqW-runSigmaSqW))

    for (iiEpsW in 1:nIntGridEpsW){
    runXXW    <- rhoW * oldXXW + intGridEpsW[iiEpsW]
    indRunXXW <- which.min(abs(fineStateGridXXW-runXXW))
    for (iiOmega in 1:nIntGridOmega) {
      runSigmaSq <- sigmaEps^2 +
          gammma * (oldSigmaSq - sigmaEps^2) + intGridOmega[iiOmega]

      indRunSigmaSq <- which.min(abs(fineStateGridSigmaSq - runSigmaSq))

      if (!fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[indRunSigmaSqW,indRunSigmaSq]){
      runSigmaSq    <- min(fineStateGridSigmaSqW[fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[indRunSigmaSqW,]])
      indRunSigmaSq <- which.min(abs(fineStateGridSigmaSq - runSigmaSq))
      }
      for (iiEps in 1:nIntGridEps) {
      runXX <- rho * oldXX + intGridEps[iiEps]
      indRunXX  <- which.min(abs(fineStateGridXX-runXX))

      nextStateNu    <- numeric(nIntGridNu)
      for(iiNu in 1:nIntGridNu) {
        runNu             <- intGridNu[iiNu]
        indRunNu          <- which.min(abs(fineStateGridNu-runNu))
        nextStateNu[iiNu] <- ((indRunSigmaSqW-1) * nFineStateGridXXW * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                               (indRunXXW-1) * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                                         (indRunSigmaSq-1) * nFineStateGridXX * nFineStateGridNu +
                                                     (indRunXX-1) * nFineStateGridNu +
                                                                 indRunNu)
      }
      nextStateNuEtaWEta <- rep(nextStateNu,nIntGridEtaW*nIntGridEta)

      startInd<-((iiOmegaW-1)*nIntGridEpsW*nIntGridOmega*nIntGridEps*nIntGridEta*nIntGridEtaW*nIntGridNu+
                    (iiEpsW-1)*nIntGridOmega*nIntGridEps*nIntGridEta*nIntGridEtaW*nIntGridNu+
                           (iiOmega-1)*nIntGridEps*nIntGridEta*nIntGridEtaW*nIntGridNu+
                                 (iiEps-1)*nIntGridEta*nIntGridEtaW*nIntGridNu+
                                                        1)
      endInd<-((iiOmegaW-1)*nIntGridEpsW*nIntGridOmega*nIntGridEps*nIntGridEta*nIntGridEtaW*nIntGridNu+
                  (iiEpsW-1)*nIntGridOmega*nIntGridEps*nIntGridEta*nIntGridEtaW*nIntGridNu+
                         (iiOmega-1)*nIntGridEps*nIntGridEta*nIntGridEtaW*nIntGridNu+
                                   iiEps*nIntGridEta*nIntGridEtaW*nIntGridNu)
      nextState[startInd:endInd] <- nextStateNuEtaWEta
      }
    }
    }
  }
  return(list(nextState = nextState))
  }
  return(nextStateFunc)
}

nextStateFuncGenAndSave <- function(allData,
                      countryToUse,
                      coarseStateGridList,
                      fineStateGridList,
                      intGridList,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)
{
  nextStateFunc    <- nextStateFuncGen(countryToUse,coarseStateGridList,
                    fineStateGridList, intGridList,
                    controlVarNAPi, ParEst, UnobsPosInfo)
  coarseStateGrid  <- coarseStateGridList$coarseStateGrid
  nCoarseStateGrid <- dim(coarseStateGrid)[1]

  for (ii in 1:nCoarseStateGrid) {
    nextState   <- nextStateFunc(coarseStateGrid[ii,])
    filename    <- file.path(outDir,"nextState",
                allData$countryNames[countryToUse],
                paste(c('nextState',ii,'Rda'), collapse = '.'))
    save(nextState,file = filename)
  }
}

nextStateFuncGenAndSaveOnCluster<- function(subsetStates,
                      allData,
                      countryToUse,
                      coarseStateGridList,
                      fineStateGridList,
                      intGridList,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)
{
  nextStateFunc    <- nextStateFuncGen(countryToUse,coarseStateGridList,
                    fineStateGridList, intGridList,
                    controlVarNAPi, ParEst, UnobsPosInfo)
  coarseStateGrid  <- coarseStateGridList$coarseStateGrid
  nCoarseStateGrid <- dim(coarseStateGrid)[1]
  for (ii in 1:length(subsetStates)) {
    nextState <- nextStateFunc(coarseStateGrid[subsetStates[ii],])
    filename <- file.path(outDir,"nextState",allData$countryNames[countryToUse],
                paste(c('nextState',subsetStates[ii],'Rda'), collapse = '.'))
    save(nextState,file = filename)
  }
}

calcWeightsFuncGen <- function(countryToUse,
                      intGridList,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)
{
  # Create probability distribution over intGrid

  intGridNu      <- intGridList$gridNu
  intGridEtaW    <- intGridList$gridEtaW
  intGridEta     <- intGridList$gridEta
  intGridEps     <- intGridList$gridEps
  intGridEpsW    <- intGridList$gridEpsW
  intGridOmega   <- intGridList$gridOmega
  intGridOmegaW  <- intGridList$gridOmegaW

  nIntGridNu     <- length(intGridNu)
  nIntGridEtaW   <- length(intGridEtaW)
  nIntGridEta    <- length(intGridEta)
  nIntGridEps    <- length(intGridEps)
  nIntGridEpsW   <- length(intGridEpsW)
  nIntGridOmega  <- length(intGridOmega)
  nIntGridOmegaW <- length(intGridOmegaW)

  tempGridNu     <- intGridList$tempGridNu
  tempGridEtaW   <- intGridList$tempGridEtaW
  tempGridEta    <- intGridList$tempGridEta
  tempGridEps    <- intGridList$tempGridEps
  tempGridEpsW   <- intGridList$tempGridEpsW
  tempGridOmega  <- intGridList$tempGridOmega
  tempGridOmegaW <- intGridList$tempGridOmegaW

  nTempGridNu     <- length(tempGridNu)
  nTempGridEtaW   <- length(tempGridEtaW)
  nTempGridEta    <- length(tempGridEta)
  nTempGridEps    <- length(tempGridEps)
  nTempGridEpsW   <- length(tempGridEpsW)
  nTempGridOmega  <- length(tempGridOmega)
  nTempGridOmegaW <- length(tempGridOmegaW)

  xi              <- ParEst[UnobsPosInfo$xi][countryToUse]
  lambda          <- ParEst[UnobsPosInfo$lambda]
  lambdaW         <- ParEst[UnobsPosInfo$lambdaW]
  sigmaNu         <- sqrt(ParEst[UnobsPosInfo$sigmaSqNu][countryToUse])
  chiSq           <- ParEst[UnobsPosInfo$chiSq][countryToUse]
  chiSqW          <- ParEst[UnobsPosInfo$chiSqW]
  sigmaOmega      <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmega])
  sigmaOmegaW     <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmegaW])

  # Weights over Nu
  if (nIntGridNu == 1) {
    wNu <- 1
  } else {
    wNu             <- (pnorm(tempGridNu[2:nTempGridNu],
                  numeric(nTempGridNu-1),
                  rep(sigmaNu,nIntGridNu))
              -
              pnorm(tempGridNu[1:nTempGridNu-1],
                  numeric(nTempGridNu-1),
                  rep(sigmaNu,nIntGridNu)))

    lowTailNu       <- pnorm(tempGridNu[1], 0, sigmaNu)

    highTailNu      <-  1 - pnorm(tempGridNu[nTempGridNu], 0, sigmaNu)

    wNu[1]          <- wNu[1] + lowTailNu

    wNu[nIntGridNu] <- wNu[nIntGridNu] + highTailNu
  }

  weightsOverIntGridFunc <- function(curSigmaSq,curSigmaSqW)
  {
    # Weights over EtaW
    if (nIntGridEtaW == 1) {
       wEtaW <- 1
    } else {
       wEtaW <- (pnorm(tempGridEtaW[2:nTempGridEtaW],
              numeric(nTempGridEtaW-1),
              rep(sqrt(chiSqW*curSigmaSqW),
              nIntGridEtaW))
          -
          pnorm(tempGridEtaW[1:nTempGridEtaW-1],
              numeric(nTempGridEtaW-1),
              rep(sqrt(chiSqW*curSigmaSqW),
              nIntGridEtaW)))

       lowTailEtaW         <- pnorm(tempGridEtaW[1], 0, sqrt(chiSqW*curSigmaSqW))

       highTailEtaW        <- 1 - pnorm(tempGridEtaW[nTempGridEtaW], 0, sqrt(chiSqW*curSigmaSqW))

       wEtaW[1]            <- wEtaW[1] + lowTailEtaW

       wEtaW[nIntGridEtaW] <- wEtaW[nIntGridEtaW] + highTailEtaW
    }
    # Weights over Eta
    if (nIntGridEta == 1) {
      wEta <- 1
    } else {
      wEta <- (pnorm(tempGridEta[2:nTempGridEta],
              numeric(nTempGridEta-1),
              rep(sqrt(chiSq*(curSigmaSq+curSigmaSqW)),nIntGridEta))
          -
          pnorm(tempGridEta[1:nTempGridEta-1],
              numeric(nTempGridEta-1),
              rep(sqrt(chiSq*(curSigmaSq+curSigmaSqW)),nIntGridEta)))

      lowTailEta        <- pnorm(tempGridEta[1],
                    0,
                    sqrt(chiSq*(curSigmaSq+curSigmaSqW)))

      highTailEta       <- 1 - pnorm(tempGridEta[nTempGridEta],
                      0,
                      sqrt(chiSq*(curSigmaSq+curSigmaSqW)))

      wEta[1]           <- wEta[1] + lowTailEta

      wEta[nIntGridEta] <- wEta[nIntGridEta] + highTailEta
    }
    # Weights over Eps and Omega
    if (nIntGridEps == 1 & nIntGridOmega == 1){
      wOmegaEps <- 1
    } else if (nIntGridEps > 1 & nIntGridOmega == 1) {
      wOmegaEps              <- (pnorm(tempGridEps[2:nTempGridEps],
                      numeric(nTempGridEps-1),
                      rep(sqrt(curSigmaSq+curSigmaSqW),nIntGridEps))
                  -
                    pnorm(tempGridEps[1:nTempGridEps-1],
                      numeric(nTempGridEps-1),
                      rep(sqrt(curSigmaSq+curSigmaSqW),nIntGridEps)))

      lowTailEps             <- pnorm(tempGridEps[1],
                      0,
                      sqrt(curSigmaSq+curSigmaSqW))

      highTailEps            <- 1 - pnorm(tempGridEps[nTempGridEps],
                        0,
                        sqrt(curSigmaSq+curSigmaSqW))
      wOmegaEps[1]           <- wOmegaEps[1] + lowTailEps
      wOmegaEps[nIntGridEps] <- wOmegaEps[nIntGridEps] + highTailEps
    } else {
      # Variance-Covariance matrix
      varcov        <- matrix(c(sigmaOmega^2,
                  lambda*sigmaOmega*sqrt(curSigmaSq+curSigmaSqW),
                  lambda*sigmaOmega*sqrt(curSigmaSq+curSigmaSqW),
                  (curSigmaSq+curSigmaSqW)),
                  2,2)

      # Initialize
      wOmegaEpsMatrix <- matrix(0,nIntGridOmega,nIntGridEps)

      # Corners
      wOmegaEpsMatrix[1,1]    <- pmvnorm(c(-Inf,-Inf),
                         upper = c(tempGridOmega[2],tempGridEps[2]),
                         mean  = c(0,0),
                         sigma = varcov)

      wOmegaEpsMatrix[nIntGridOmega,1]<- pmvnorm(c(tempGridOmega[length(tempGridOmega)-1],-Inf),
                             upper = c(Inf,tempGridEps[2]),
                             mean  = c(0,0),
                             sigma = varcov)

      wOmegaEpsMatrix[1,nIntGridEps] <- pmvnorm(c(-Inf,tempGridEps[length(tempGridEps)-1]),
                            upper = c(tempGridOmega[2],Inf),
                            mean  = c(0,0),
                            sigma = varcov)

      wOmegaEpsMatrix[nIntGridOmega,nIntGridEps] <- pmvnorm(c(tempGridOmega[length(tempGridOmega)-1],
                                tempGridEps[length(tempGridEps)-1]),
                                upper = c(Inf,Inf),
                                mean  = c(0,0),
                                sigma = varcov)
      # Sides
      # Seems like a mistake. It must be "2:(nIntGridOmega-1)"
      for (iiOmega in 2:(nIntGridOmega-1)){
        wOmegaEpsMatrix[iiOmega,1]           <- pmvnorm(c(tempGridOmega[iiOmega],-Inf),
                                upper = c(tempGridOmega[iiOmega+1],tempGridEps[2]),
                                mean  = c(0,0),
                                sigma = varcov)
        wOmegaEpsMatrix[iiOmega,nIntGridEps] <- pmvnorm(c(tempGridOmega[iiOmega],tempGridEps[length(tempGridEps)-1]),
                                upper = c(tempGridOmega[iiOmega+1],Inf),
                                mean  = c(0,0),
                                sigma = varcov)
      }
      for (iiEps in 2:(nIntGridEps-1)){
        wOmegaEpsMatrix[1,iiEps]             <- pmvnorm(c(-Inf,tempGridEps[iiEps]),
                                upper = c(tempGridOmega[2],tempGridEps[iiEps+1]),
                                mean  = c(0,0),
                                sigma = varcov)
        wOmegaEpsMatrix[nIntGridOmega,iiEps] <- pmvnorm(c(tempGridOmega[length(tempGridOmega)-1],tempGridEps[iiEps]),
                                upper = c(Inf,tempGridEps[iiEps+1]),
                                mean  = c(0,0),
                                sigma = varcov)
      }
      # Interior
      for (iiOmega in 2:(nIntGridOmega-1)){
        for (iiEps in 2:(nIntGridEps-1)){
          wOmegaEpsMatrix[iiOmega,iiEps]   <- pmvnorm(c(tempGridOmega[iiOmega],tempGridEps[iiEps]),
                                upper = c(tempGridOmega[iiOmega+1],tempGridEps[iiEps+1]),
                                mean  = c(0,0),
                                sigma = varcov)
        }
      }
      wOmegaEpsMatrix <- wOmegaEpsMatrix/sum(wOmegaEpsMatrix)
      wOmegaEps       <- as.vector(t(wOmegaEpsMatrix))
    }

    # Weights over EpsW and OmegaW
    ##############################
    if (nIntGridEpsW == 1 & nIntGridOmegaW == 1){
      wOmegaWEpsW <- 1
    } else if (nIntGridEpsW > 1 & nIntGridOmegaW == 1) {
      wOmegaWEpsW               <- (pnorm(tempGridEpsW[2:nTempGridEpsW],
                      numeric(nTempGridEpsW-1),
                      rep(sqrt(curSigmaSqW),nIntGridEpsW))
                    -
                    pnorm(tempGridEpsW[1:nTempGridEpsW-1],
                      numeric(nTempGridEpsW-1),
                      rep(sqrt(curSigmaSqW),nIntGridEpsW)))
      lowTailEpsW               <- pnorm(tempGridEpsW[1],
                        0,
                        sqrt(curSigmaSqW))
      highTailEpsW              <- 1 - pnorm(tempGridEps[nTempGridEpsW],
                          0,
                          sqrt(curSigmaSqW))
      wOmegaWEpsW[1]            <- wOmegaWEpsW[1] + lowTailEpsW
      wOmegaWEpsW[nIntGridEpsW] <- wOmegaWEpsW[nIntGridEpsW] + highTailEpsW
    } else {
      # Variance-Covariance matrix
      varcov        <- matrix(c(sigmaOmegaW^2,
                    lambdaW*sigmaOmegaW*sqrt(curSigmaSqW),
                    lambdaW*sigmaOmegaW*sqrt(curSigmaSqW),
                    curSigmaSqW),
                  2,2)

      # Initialize
      wOmegaWEpsWMatrix <- matrix(0,nIntGridOmegaW,nIntGridEpsW)

      # Corners
      wOmegaWEpsWMatrix[1,1]                   <- pmvnorm(c(-Inf,-Inf),
                                upper = c(tempGridOmegaW[2],tempGridEpsW[2]),
                                mean  = c(0,0),
                                sigma = varcov)

      wOmegaWEpsWMatrix[nIntGridOmegaW,1]      <- pmvnorm(c(tempGridOmegaW[length(tempGridOmegaW)-1],-Inf),
                                upper = c(Inf,tempGridEpsW[2]),
                                mean  = c(0,0),
                                sigma = varcov)

      wOmegaWEpsWMatrix[1,nIntGridEpsW]        <- pmvnorm(c(-Inf,tempGridEpsW[length(tempGridEpsW)-1]),
                                upper = c(tempGridOmegaW[2],Inf),
                                mean  = c(0,0),
                                sigma = varcov)

      wOmegaWEpsWMatrix[nIntGridOmegaW,nIntGridEpsW] <- pmvnorm(c(tempGridOmegaW[length(tempGridOmegaW)-1],
                                    tempGridEpsW[length(tempGridEpsW)-1]),
                                  upper = c(Inf,Inf),
                                  mean  = c(0,0),
                                  sigma = varcov)

      # Sides
      for (iiOmegaW in 2:(nIntGridOmegaW-1)){
        wOmegaWEpsWMatrix[iiOmegaW,1]            <- pmvnorm(c(tempGridOmegaW[iiOmegaW],-Inf), upper=c(tempGridOmegaW[iiOmegaW+1],tempGridEpsW[2]),mean=c(0,0),sigma = varcov)
        wOmegaWEpsWMatrix[iiOmegaW,nIntGridEpsW] <- pmvnorm(c(tempGridOmegaW[iiOmegaW],tempGridEpsW[length(tempGridEpsW)-1]),upper=c(tempGridOmegaW[iiOmegaW+1],Inf),mean=c(0,0),sigma = varcov)
      }

      for (iiEpsW in 2:(nIntGridEpsW-1)){
        wOmegaWEpsWMatrix[1,iiEpsW]              <- pmvnorm(c(-Inf,tempGridEpsW[iiEpsW]), upper=c(tempGridOmegaW[2],tempGridEpsW[iiEpsW+1]),mean=c(0,0),sigma = varcov)
        wOmegaWEpsWMatrix[nIntGridOmegaW,iiEpsW] <- pmvnorm(c(tempGridOmegaW[length(tempGridOmegaW)-1],tempGridEpsW[iiEpsW]),upper=c(Inf,tempGridEpsW[iiEpsW+1]),mean=c(0,0),sigma = varcov)
      }

      # Interior
      for (iiOmegaW in 2:(nIntGridOmegaW-1)){
        for (iiEpsW in 2:(nIntGridEpsW-1)){
          wOmegaWEpsWMatrix[iiOmegaW,iiEpsW]   <- pmvnorm(c(tempGridOmegaW[iiOmegaW],tempGridEpsW[iiEpsW]),
                                  upper = c(tempGridOmegaW[iiOmegaW+1],tempGridEpsW[iiEpsW+1]),
                                  mean  = c(0,0),
                                  sigma = varcov)
        }
      }

      wOmegaWEpsWMatrix <- wOmegaWEpsWMatrix/sum(wOmegaWEpsWMatrix)
      wOmegaWEpsW       <- as.vector(t(wOmegaWEpsWMatrix))
    }

    #Create weights for all points on int grid
    weightsOverIntGrid <- kronecker(wEtaW, wNu)
    weightsOverIntGrid <- kronecker(wEta, weightsOverIntGrid)
    weightsOverIntGrid <- kronecker(wOmegaEps, weightsOverIntGrid)
    weightsOverIntGrid <- kronecker(wOmegaWEpsW, weightsOverIntGrid)

    return(weightsOverIntGrid)
  }

  return(weightsOverIntGridFunc)
}

calcWeightsFuncGenAndSave <- function(countryToUse,
                      coarseStateGridList,
                      intGridList,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)
{
  weightsOverIntGridFunc  <- calcWeightsFuncGen(countryToUse,intGridList, controlVarNAPi, ParEst, UnobsPosInfo)
  cutOff                  <- controlVarNAPi$cutOff
  cutOffW                 <- controlVarNAPi$cutOffW
  xi                      <- ParEst[UnobsPosInfo$xi][countryToUse]
  coarseStateGridSigmaSq  <- coarseStateGridList$gridSigmaSq
  coarseStateGridSigmaSqW <- coarseStateGridList$gridSigmaSqW
  nCoarseGridSigmaSq      <- length(coarseStateGridSigmaSq)
  nCoarseGridSigmaSqW     <- length(coarseStateGridSigmaSqW)

  for (jj in 1:nCoarseGridSigmaSqW){
    for (ii in 1:nCoarseGridSigmaSq) {
      if (coarseStateGridSigmaSq[ii] + coarseStateGridSigmaSqW[jj]
                                >= cutOff){
        weightsOverIntGrid <- weightsOverIntGridFunc(coarseStateGridSigmaSq[ii],
                               coarseStateGridSigmaSqW[jj])
        filename <- file.path(outDir,
                    "weightsOverIntGrid",
                    allData$countryNames[countryToUse],
                    paste(c('weightsOverIntGrid',ii,jj,'Rda'), collapse = '.'))
        save(weightsOverIntGrid,file = filename)
      }
    }
  }
}

## Price function
################################################################################
PDivIntFuncGen <- function(countryToUse,
                      coarseStateGridList,
                      intGridList,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)
{
  ## Creates functions that compute
  ## price-dividend ratios

  NuOnIntGrid             <- intGridList$intGrid[,1]
  EtaWOnIntGrid           <- intGridList$intGrid[,2]
  EtaOnIntGrid            <- intGridList$intGrid[,3]
  EpsOnIntGrid            <- intGridList$intGrid[,4]
  OmegaOnIntGrid          <- intGridList$intGrid[,5]
  EpsWOnIntGrid           <- intGridList$intGrid[,6]
  OmegaWOnIntGrid         <- intGridList$intGrid[,7]

  mu                      <- ParEst[UnobsPosInfo$mu][countryToUse]
  rho                     <- ParEst[UnobsPosInfo$rho]
  rhoW                    <- ParEst[UnobsPosInfo$rhoW]
  lambda                  <- ParEst[UnobsPosInfo$lambda]
  lambdaW                 <- ParEst[UnobsPosInfo$lambdaW]
  xi                      <- ParEst[UnobsPosInfo$xi][countryToUse]
  chi                     <- sqrt(ParEst[UnobsPosInfo$chiSq][countryToUse])


  rhoU                    <- controlVarNAPi$rhoU
  gammaU                  <- controlVarNAPi$gammaU
  psiU                    <- controlVarNAPi$psiU
  thetaU                  <- controlVarNAPi$thetaU
  phi                     <- controlVarNAPi$phi

  debtEqRatio             <- controlVarNAPi$debtEqRatio
  payGrowth               <- controlVarNAPi$payGrowth

  coarseStateGridSigmaSq  <- coarseStateGridList$gridSigmaSq
  coarseStateGridSigmaSqW <- coarseStateGridList$gridSigmaSqW

  PDivEqIntFunc <- function(currentState, nextPDivVec)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]
    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq  - curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW - curSigmaSqW))

    filename  <- file.path(outDir,
            "weightsOverIntGrid",
            allData$countryNames[countryToUse],
            paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
            collapse = '.'))
    load(filename)
    
    deltaLogC <- mu + curXX + xi*curXXW + NuOnIntGrid - curNu + EtaOnIntGrid + xi*EtaWOnIntGrid
    intVal    <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) * (1 + exp(nextPDivVec))^thetaU)
    
    #Do the numerical integration
    PDiv        <- (weightsOverIntGrid %*% intVal)^(1/thetaU)
    PDiv        <- log(PDiv)
    return(PDiv)
  }
  PDivOnePerBondIntFunc <- function(currentState, curPDivEq, nextPDivEq)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename <- file.path(outDir,
            "weightsOverIntGrid",
            allData$countryNames[countryToUse],
            paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
            collapse = '.'))
    load(filename)

    deltaLogC <- (mu + curXX + xi*curXXW +
            NuOnIntGrid - curNu + EtaOnIntGrid + xi*EtaWOnIntGrid)

    intVal <- (exp(-rhoU)^thetaU*exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))*
          exp(curPDivEq)^(1-thetaU)*(1 + exp(nextPDivEq))^(-1+thetaU))

    ## integration
    PDiv <- weightsOverIntGrid %*% intVal
    PDiv <- log(PDiv)

    return(PDiv)
  }
  PDivOnePerRiskyBondIntFunc <- function(currentState, curPDivEq, nextPDivEq)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq  <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename <- file.path(outDir,
          "weightsOverIntGrid",
          allData$countryNames[countryToUse],
          paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
              collapse = '.'))
    load(filename)

    deltaLogC <- (mu + NuOnIntGrid - curNu  +
            curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    deltaLogD <- (mu +
         phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid))

    ## The first two lines of intVal are SDF
    intVal <- (exp(-rhoU)^thetaU*exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         *exp(curPDivEq)^(1-thetaU)*(1 + exp(nextPDivEq))^(-1+thetaU)*
          exp(deltaLogD))
    PDiv   <- weightsOverIntGrid %*% intVal
    PDiv   <- log(PDiv)

    return(PDiv)
  }
  PDivPerpetuityIntFunc <- function(currentState, curPDivEq,
                    nextPDivEq, nextPDivPerp)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename <- file.path(outDir,
            "weightsOverIntGrid",
            allData$countryNames[countryToUse],
            paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
            collapse = '.'))
    load(filename)

    deltaLogC <- (mu + curXX + xi*curXXW + NuOnIntGrid -
          curNu + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
          *exp(curPDivEq)^(1-thetaU)*(1 + exp(nextPDivEq))^(-1+thetaU)*
          payGrowth * (1 + exp(nextPDivPerp)))

    ## Integrate
    PDiv <- weightsOverIntGrid %*% intVal
    PDiv <- log(PDiv)

    return(PDiv)
  }
  PDivLeveredXXEqIntFunc <- function(currentState, curPDivEq,
                    nextPDivEq, nextPDivVec)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,
                "weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                    iiSigmaSq,iiSigmaSqW,'Rda'),
                    collapse = '.')
                )
    load(filename)

    deltaLogC   <- mu + NuOnIntGrid - curNu  + curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid
    deltaLogD   <- mu                 + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU)  * exp(deltaLogD) * (1 + exp(nextPDivVec)))
    PDiv        <- weightsOverIntGrid %*% intVal
    PDiv        <- log(PDiv)

    return(PDiv)
  }
  PDivTPerRiskyBondIntFunc <- function(currentState,
                    curPDivEq,
                    nextPDivEq,
                    nextPDivVecTminusOnePerRiskyBond)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename <- file.path(outDir,
          "weightsOverIntGrid",
          allData$countryNames[countryToUse],
          paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
          collapse = '.'))
    load(filename)

    deltaLogC <- (mu + NuOnIntGrid - curNu  +
          curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    deltaLogD <- (mu                 +
          phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid))

    intVal <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU)
         * exp(deltaLogD) * exp(nextPDivVecTminusOnePerRiskyBond))

    PDiv        <- weightsOverIntGrid %*% intVal
    PDiv        <- log(PDiv)

    return(PDiv)
  }
  return(list(PDivEqIntFunc               = PDivEqIntFunc,
        PDivOnePerBondIntFunc       = PDivOnePerBondIntFunc,
        PDivLeveredXXEqIntFunc      = PDivLeveredXXEqIntFunc,
        PDivPerpetuityIntFunc       = PDivPerpetuityIntFunc,
        PDivOnePerRiskyBondIntFunc  = PDivOnePerRiskyBondIntFunc,
        PDivTPerRiskyBondIntFunc    = PDivTPerRiskyBondIntFunc))
}

## Create functions that compute expectations of dividend growth, covariance 
## between shocks and price-dividend ratios, covariance between shocks and 
## dividend growth for various assets
################################################################################
MomIntFuncGen <- function(countryToUse,
                      coarseStateGridList,
                      intGridList,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)
{

  NuOnIntGrid             <- intGridList$intGrid[,1]
  EtaWOnIntGrid           <- intGridList$intGrid[,2]
  EtaOnIntGrid            <- intGridList$intGrid[,3]
  EpsOnIntGrid            <- intGridList$intGrid[,4]
  OmegaOnIntGrid          <- intGridList$intGrid[,5]
  EpsWOnIntGrid           <- intGridList$intGrid[,6]
  OmegaWOnIntGrid         <- intGridList$intGrid[,7]

  mu                      <- ParEst[UnobsPosInfo$mu][countryToUse]
  rho                     <- ParEst[UnobsPosInfo$rho]
  rhoW                    <- ParEst[UnobsPosInfo$rhoW]
  lambda                  <- ParEst[UnobsPosInfo$lambda]
  lambdaW                 <- ParEst[UnobsPosInfo$lambdaW]
  xi                      <- ParEst[UnobsPosInfo$xi][countryToUse]
  chi                     <- sqrt(ParEst[UnobsPosInfo$chiSq][countryToUse])
  chiW                    <- sqrt(ParEst[UnobsPosInfo$chiSqW])
  sigmaOmegaW             <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmegaW])
  sigmaOmega              <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmega])

  rhoU                    <- controlVarNAPi$rhoU
  gammaU                  <- controlVarNAPi$gammaU
  psiU                    <- controlVarNAPi$psiU
  thetaU                  <- controlVarNAPi$thetaU
  phi                     <- controlVarNAPi$phi

  debtEqRatio             <- controlVarNAPi$debtEqRatio
  payGrowth               <- controlVarNAPi$payGrowth

  coarseStateGridSigmaSq  <- coarseStateGridList$gridSigmaSq
  coarseStateGridSigmaSqW <- coarseStateGridList$gridSigmaSqW

  DDivOnePerRiskyBondIntFunc <- function(currentState)
  {
  # This function computes the expected dividends growth rate E_t[D_{t+1}/D_t]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,
                "weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'), collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- exp(deltaLogD)
    DDiv        <- weightsOverIntGrid %*% intVal
    DDiv        <- log(DDiv)

    return(DDiv)
  }
  DDivTPerRiskyBondIntFunc                <- function(currentState,
                            nextDDivVecTminusOnePerRiskyBond)
  {
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- exp(deltaLogD) * exp(nextDDivVecTminusOnePerRiskyBond)
    DDiv        <- weightsOverIntGrid %*% intVal
    DDiv        <- log(DDiv)

    return(DDiv)
  }

  CovvEpsDDivOnePerRiskyBondIntFunc       <- function(currentState)
  {
  # Computes cov_t(epsilon_{t+1},D_{t+1}/D_t)
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename <- file.path(outDir,"weightsOverIntGrid",
            allData$countryNames[countryToUse],
            paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
            collapse = '.'))

    load(filename)

    deltaLogD <- mu + phi*(curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal    <- EpsOnIntGrid * exp(deltaLogD)
    Covv      <- weightsOverIntGrid %*% intVal/sqrt(curSigmaSqW+curSigmaSq)

    return(Covv)
  }
  CovvEpsWDDivOnePerRiskyBondIntFunc      <- function(currentState)
  {
  # Computes cov_t(epsilon_{W,t+1},D_{t+1}/D_t)
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq  - curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW - curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- EpsWOnIntGrid * exp(deltaLogD)
    Covv        <- weightsOverIntGrid %*% intVal/sqrt(curSigmaSqW)

    return(Covv)
  }
  CorrEpsWlogDDivOnePerRiskyBondIntFunc      <- function(currentState)
  {
  # Computes cov_t(epsilon_{W,t+1},D_{t+1}/D_t)
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq  - curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW - curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intValNum   <- weightsOverIntGrid %*%(EpsWOnIntGrid * deltaLogD)
    # intValDenom <- (sqrt(weightsOverIntGrid %*% (deltaLogD^2)
    #                      - (weightsOverIntGrid %*% deltaLogD)^2)
    #                 *
    #                 sqrt(curSigmaSqW)
    #                 )
    intValDenom <- curSigmaSqW*phi*xi
    Corr        <- intValNum/intValDenom

    return(Corr)
  }
  CovvOmegaDDivOnePerRiskyBondIntFunc     <- function(currentState)
  {
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- OmegaOnIntGrid * exp(deltaLogD)
    Covv        <- weightsOverIntGrid %*% intVal/sigmaOmega

    return(Covv)
  }
  CovvOmegaWDDivOnePerRiskyBondIntFunc    <- function(currentState)
  {
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- OmegaWOnIntGrid * exp(deltaLogD)
    Covv        <- weightsOverIntGrid %*% intVal/sigmaOmegaW

    return(Covv)
  }

  CovvEpsPDivOnePerRiskyBondIntFunc       <- function(currentState,
                            curPDivEq,
                            nextPDivEq)
  {
    # Computes cov_t(epsilon_{t+1},M_{t,t+1} D_{t+1}/D_t)
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogC <- (mu+NuOnIntGrid-curNu+
            curXX+xi*curXXW+EtaOnIntGrid+xi*EtaWOnIntGrid)

    deltaLogD <- mu + phi*(curXX+xi*curXXW+EtaOnIntGrid+xi*EtaWOnIntGrid)

    intVal <- (exp(-rhoU)^thetaU*exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         *exp(curPDivEq)^(1-thetaU)*(1 + exp(nextPDivEq))^(-1+thetaU)*
          exp(deltaLogD) *
            EpsOnIntGrid)
    Covv <- weightsOverIntGrid %*% intVal/sqrt(curSigmaSqW+curSigmaSq)

    return(Covv)
  }
  CovvEpsWPDivOnePerRiskyBondIntFunc      <- function(currentState,
                            curPDivEq,
                            nextPDivEq)
  {
    # Computes cov_t(epsilonW_{t+1},M_{t,t+1} D_{t+1}/D_t)
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogC <- (mu+NuOnIntGrid-curNu+
            curXX+xi*curXXW+EtaOnIntGrid+xi*EtaWOnIntGrid)

    deltaLogD <- mu + phi*(curXX+xi*curXXW+EtaOnIntGrid+xi*EtaWOnIntGrid)

    intVal <- (exp(-rhoU)^thetaU*exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         *exp(curPDivEq)^(1-thetaU)*(1 + exp(nextPDivEq))^(-1+thetaU)*
          exp(deltaLogD) *
            EpsWOnIntGrid)
    Covv <- weightsOverIntGrid %*% intVal/sqrt(curSigmaSqW)

    return(Covv)
  }
  CovvOmegaPDivOnePerRiskyBondIntFunc     <- function(currentState,
                            curPDivEq,
                            nextPDivEq)
  {
    # Computes cov_t(epsilon_{t+1},M_{t,t+1} D_{t+1}/D_t)
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogC <- (mu+NuOnIntGrid-curNu+
            curXX+xi*curXXW+EtaOnIntGrid+xi*EtaWOnIntGrid)

    deltaLogD <- mu + phi*(curXX+xi*curXXW+EtaOnIntGrid+xi*EtaWOnIntGrid)

    intVal <- (exp(-rhoU)^thetaU*exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         *exp(curPDivEq)^(1-thetaU)*(1 + exp(nextPDivEq))^(-1+thetaU)*
          exp(deltaLogD) *
            OmegaOnIntGrid)
    Covv <- weightsOverIntGrid %*% intVal/sigmaOmega

    return(Covv)
  }
  CovvOmegaWPDivOnePerRiskyBondIntFunc    <- function(currentState,
                            curPDivEq,
                            nextPDivEq)
  {
    # Computes cov_t(epsilon_{t+1},M_{t,t+1} D_{t+1}/D_t)
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogC <- (mu+NuOnIntGrid-curNu+
            curXX+xi*curXXW+EtaOnIntGrid+xi*EtaWOnIntGrid)

    deltaLogD <- mu + phi*(curXX+xi*curXXW+EtaOnIntGrid+xi*EtaWOnIntGrid)

    intVal <- (exp(-rhoU)^thetaU*exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         *exp(curPDivEq)^(1-thetaU)*(1 + exp(nextPDivEq))^(-1+thetaU)*
          exp(deltaLogD) *
            OmegaWOnIntGrid)
    Covv <- weightsOverIntGrid %*% intVal/sigmaOmegaW

    return(Covv)
  }


  CovvEpsDDivTPerRiskyBondIntFunc         <- function(currentState,
                            nextDDivVecTminusOnePerRiskyBond)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq  - curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW - curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- EpsOnIntGrid * exp(deltaLogD) * exp(nextDDivVecTminusOnePerRiskyBond)
    Covv        <- (weightsOverIntGrid %*% intVal)/sqrt(curSigmaSqW+curSigmaSq)

    return(Covv)
  }
  CovvEpsWDDivTPerRiskyBondIntFunc        <- function(currentState,
                            nextDDivVecTminusOnePerRiskyBond)
  {
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- EpsWOnIntGrid * exp(deltaLogD) * exp(nextDDivVecTminusOnePerRiskyBond)
    Covv        <- weightsOverIntGrid %*% intVal/sqrt(curSigmaSqW)

    return(Covv)
  }
  CorrEpsWlogDDivTPerRiskyBondIntFunc        <- function(currentState,
                            nextDDivVecTminusOnePerRiskyBond)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogDsum<- (mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
             +
             nextDDivVecTminusOnePerRiskyBond)
    intValNum   <- (weightsOverIntGrid %*% (EpsWOnIntGrid * deltaLogDsum))
    intValDenom <- curSigmaSqW * phi * xi
    Corr        <- intValNum/intValDenom

    return(Corr)
  }
  CovvOmegaDDivTPerRiskyBondIntFunc       <- function(currentState,
                            nextDDivVecTminusOnePerRiskyBond)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- OmegaOnIntGrid * exp(deltaLogD) * exp(nextDDivVecTminusOnePerRiskyBond)
    Covv        <- weightsOverIntGrid %*% intVal/sigmaOmega

    return(Covv)
  }
  CovvOmegaWDDivTPerRiskyBondIntFunc      <- function(currentState,
                            nextDDivVecTminusOnePerRiskyBond)
  {
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogD   <- mu + phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    intVal      <- OmegaWOnIntGrid * exp(deltaLogD) * exp(nextDDivVecTminusOnePerRiskyBond)
    Covv        <- weightsOverIntGrid %*% intVal/sigmaOmegaW

    return(Covv)
  }

  CovvEpsPDivTPerRiskyBondIntFunc         <- function(currentState,
                            curPDivEq,
                            nextPDivEq,
                            nextPDivVecTminusOnePerRiskyBond)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq  - curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW - curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                    iiSigmaSq,
                    iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogC <- (mu + NuOnIntGrid - curNu  +
          curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    deltaLogD <- (mu                 +
          phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid))

    intVal <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU)
         * EpsOnIntGrid * exp(deltaLogD) *
          exp(nextPDivVecTminusOnePerRiskyBond))

    Covv <- (weightsOverIntGrid %*% intVal)/sqrt(curSigmaSqW+curSigmaSq)

    return(Covv)
  }
  CovvEpsWPDivTPerRiskyBondIntFunc         <- function(currentState,
                            curPDivEq,
                            nextPDivEq,
                            nextPDivVecTminusOnePerRiskyBond)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq  - curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW - curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                    iiSigmaSq,
                    iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogC <- (mu + NuOnIntGrid - curNu  +
          curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    deltaLogD <- (mu                 +
          phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid))

    intVal <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU)
         * EpsWOnIntGrid * exp(deltaLogD) *
          exp(nextPDivVecTminusOnePerRiskyBond))

    Covv <- (weightsOverIntGrid %*% intVal)/sqrt(curSigmaSqW)

    return(Covv)
  }
  CovvOmegaPDivTPerRiskyBondIntFunc       <- function(currentState,
                            curPDivEq,
                            nextPDivEq,
                            nextPDivVecTminusOnePerRiskyBond)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq  - curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW - curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                    iiSigmaSq,
                    iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogC <- (mu + NuOnIntGrid - curNu  +
          curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    deltaLogD <- (mu                 +
          phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid))

    intVal <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU)
         * OmegaOnIntGrid * exp(deltaLogD) *
          exp(nextPDivVecTminusOnePerRiskyBond))

    Covv <- (weightsOverIntGrid %*% intVal)/sigmaOmega

    return(Covv)
  }
  CovvOmegaWPDivTPerRiskyBondIntFunc       <- function(currentState,
                            curPDivEq,
                            nextPDivEq,
                            nextPDivVecTminusOnePerRiskyBond)
  {
    curNu       <- currentState[1]
    curXX       <- currentState[2]
    curSigmaSq  <- currentState[3]
    curXXW      <- currentState[4]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq  - curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW - curSigmaSqW))

    filename    <- file.path(outDir,"weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',
                    iiSigmaSq,
                    iiSigmaSqW,'Rda'),
                collapse = '.'))
    load(filename)

    deltaLogC <- (mu + NuOnIntGrid - curNu  +
          curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid)
    deltaLogD <- (mu                 +
          phi * (curXX + xi*curXXW + EtaOnIntGrid + xi*EtaWOnIntGrid))

    intVal <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU))
         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU)
         * OmegaWOnIntGrid * exp(deltaLogD) *
          exp(nextPDivVecTminusOnePerRiskyBond))

    Covv <- (weightsOverIntGrid %*% intVal)/sigmaOmegaW

    return(Covv)
  }

  VepsWoverSigmaSqWIntFunc <- function(currentState)
  {
    # This function computes V_t[eps_{W,t+1}]/SigmaSqW[t]
    curSigmaSq  <- currentState[3]
    curSigmaSqW <- currentState[5]

    iiSigmaSq   <- which.min(abs(coarseStateGridSigmaSq-curSigmaSq))
    iiSigmaSqW  <- which.min(abs(coarseStateGridSigmaSqW-curSigmaSqW))

    filename    <- file.path(outDir,
                "weightsOverIntGrid",
                allData$countryNames[countryToUse],
                paste(c('weightsOverIntGrid',iiSigmaSq,iiSigmaSqW,'Rda'), collapse = '.'))
    load(filename)

    output      <- (weightsOverIntGrid %*% EpsWOnIntGrid^2)/curSigmaSqW
    #output      <- weightsOverIntGrid %*% EpsWOnIntGrid/sqrt(curSigmaSqW)
    #output      <- weightsOverIntGrid %*% EpsOnIntGrid/sqrt(curSigmaSqW+curSigmaSq)
    #output      <- weightsOverIntGrid %*% EtaOnIntGrid/(chi*sqrt(curSigmaSqW+curSigmaSq)) # very small number
    #output      <- weightsOverIntGrid %*% EtaWOnIntGrid/(chiW*sqrt(curSigmaSqW)) # very small number
    #output      <- weightsOverIntGrid %*% rep(1,length(taWOnIntGrid))

    return(output)
  }
  return(list(
    VepsWoverSigmaSqWIntFunc              = VepsWoverSigmaSqWIntFunc,
    DDivOnePerRiskyBondIntFunc            = DDivOnePerRiskyBondIntFunc,
    DDivTPerRiskyBondIntFunc              = DDivTPerRiskyBondIntFunc,
    CovvEpsDDivTPerRiskyBondIntFunc       = CovvEpsDDivTPerRiskyBondIntFunc,
    CovvEpsWDDivTPerRiskyBondIntFunc      = CovvEpsWDDivTPerRiskyBondIntFunc,
    CovvOmegaDDivTPerRiskyBondIntFunc     = CovvOmegaDDivTPerRiskyBondIntFunc,
    CovvOmegaWDDivTPerRiskyBondIntFunc    = CovvOmegaWDDivTPerRiskyBondIntFunc,
    CovvEpsDDivOnePerRiskyBondIntFunc     = CovvEpsDDivOnePerRiskyBondIntFunc,
    CovvEpsWDDivOnePerRiskyBondIntFunc    = CovvEpsWDDivOnePerRiskyBondIntFunc,
    CovvOmegaDDivOnePerRiskyBondIntFunc   = CovvOmegaDDivOnePerRiskyBondIntFunc,
    CovvOmegaWDDivOnePerRiskyBondIntFunc  = CovvOmegaWDDivOnePerRiskyBondIntFunc,
    CorrEpsWlogDDivOnePerRiskyBondIntFunc = CorrEpsWlogDDivOnePerRiskyBondIntFunc,
    CorrEpsWlogDDivTPerRiskyBondIntFunc   = CorrEpsWlogDDivTPerRiskyBondIntFunc,
    CovvEpsPDivOnePerRiskyBondIntFunc     = CovvEpsPDivOnePerRiskyBondIntFunc,
    CovvEpsWPDivOnePerRiskyBondIntFunc    = CovvEpsWPDivOnePerRiskyBondIntFunc,
    CovvOmegaPDivOnePerRiskyBondIntFunc   = CovvOmegaPDivOnePerRiskyBondIntFunc,
    CovvOmegaWPDivOnePerRiskyBondIntFunc  = CovvOmegaWPDivOnePerRiskyBondIntFunc,
    CovvEpsPDivTPerRiskyBondIntFunc       = CovvEpsPDivTPerRiskyBondIntFunc,
    CovvEpsWPDivTPerRiskyBondIntFunc      = CovvEpsWPDivTPerRiskyBondIntFunc,
    CovvOmegaPDivTPerRiskyBondIntFunc     = CovvOmegaPDivTPerRiskyBondIntFunc,
    CovvOmegaWPDivTPerRiskyBondIntFunc    = CovvOmegaWPDivTPerRiskyBondIntFunc
    ))
}

## Multicore version of PDivEqIntFunc()
snowPDivEqIntFunc <- function(subsetStates,
                      coarseStateGrid,
                      finePDivVecOld,
                      countryToUse,
                      PDivEqIntFunc)
{
  coarsePDivVec <- numeric(length(subsetStates))
  xi            <- ParEst[bigDataPosInfo$xi][countryToUse]
  cutOff        <- controlVarNAPi$cutOff
  cutOffW       <- controlVarNAPi$cutOffW

  for (ii in 1:length(subsetStates)) {
    currentState <- coarseStateGrid[subsetStates[ii],]
    curSigmaSq   <- currentState[3]
    curSigmaSqW  <- currentState[5]

    if (curSigmaSq + curSigmaSqW >= cutOff){
      filename <- file.path(outDir, "nextState",
                  allData$countryNames[countryToUse],
                  paste(c('nextState',subsetStates[ii],'Rda'), collapse = '.'))
      load(filename)

      nextFinePDivVec   <- finePDivVecOld[nextState$nextState]
      coarsePDivVec[ii] <- PDivEqIntFunc(currentState, nextFinePDivVec)
    }
  }
  return(coarsePDivVec)
}
## Multicore version of PDivOnePerBondIntFunc()
snowPDivOnePerBondIntFunc       <- function(subsetStates,
                      coarseStateGrid,
                      output,
                      countryToUse,
                      PDivOnePerBondIntFunc)
{
  coarsePDivVec <- numeric(length(subsetStates))
  xi            <- ParEst[bigDataPosInfo$xi][countryToUse]
  cutOff        <- controlVarNAPi$cutOff
  cutOffW       <- controlVarNAPi$cutOffW

  for (ii in 1:length(subsetStates)) {

    currentState <- coarseStateGrid[subsetStates[ii],]
    curSigmaSq   <- currentState[3]
    curSigmaSqW  <- currentState[5]

    if (curSigmaSq + curSigmaSqW >= cutOff){
      filename <- file.path(outDir,
                  "nextState",
                  allData$countryNames[countryToUse],
                  paste(c('nextState',
                      subsetStates[ii],
                      'Rda'),
                      collapse = '.'))
      load(filename)

      nextFinePDivEq    <- output$Equity[nextState$nextState]

      coarsePDivVec[ii] <-
        PDivOnePerBondIntFunc(currentState,
                    output$EquityCoarse[subsetStates[ii]],
                    nextFinePDivEq)
    }
  }
  return(coarsePDivVec)
}

## Multicore version of PDivLeveredXXEqIntFunc()
snowPDivLeveredXXEqIntFunc      <- function(subsetStates,
                      coarseStateGrid,
                      output,
                      finePDivVecOld,
                      countryToUse,
                      PDivLeveredXXEqIntFunc)
{
  coarsePDivVec <- numeric(length(subsetStates))
  xi            <- ParEst[bigDataPosInfo$xi][countryToUse]
  cutOff        <- controlVarNAPi$cutOff
  cutOffW       <- controlVarNAPi$cutOffW

  for (ii in 1:length(subsetStates)) {

  currentState <- coarseStateGrid[subsetStates[ii],]
  curSigmaSq   <- currentState[3]
  curSigmaSqW  <- currentState[5]

  if (curSigmaSq + curSigmaSqW >= cutOff){
    filename <- file.path(outDir,
              "nextState",
                allData$countryNames[countryToUse],
                paste(c('nextState',subsetStates[ii],'Rda'),
                collapse = '.'))
    load(filename)

    nextFinePDivEq    <- output$Equity[nextState$nextState]
    nextFinePDivVec   <- finePDivVecOld[nextState$nextState]
    coarsePDivVec[ii] <- PDivLeveredXXEqIntFunc(currentState,
                output$EquityCoarse[subsetStates[ii]],
                nextFinePDivEq,nextFinePDivVec)
  }
  }
  return(coarsePDivVec)
}

## Multicore version of PDivPerpetuityIntFunc()
snowPDivPerpetuityIntFunc       <- function(subsetStates,
                      coarseStateGrid,
                      output,
                      finePDivVecOld,
                      countryToUse,
                      PDivPerpetuityIntFunc)
{
  coarsePDivVec <- numeric(length(subsetStates))
  xi            <- ParEst[bigDataPosInfo$xi][countryToUse]
  cutOff        <- controlVarNAPi$cutOff
  cutOffW       <- controlVarNAPi$cutOffW

  for (ii in 1:length(subsetStates)) {

    currentState <- coarseStateGrid[subsetStates[ii],]
    curSigmaSq   <- currentState[3]
    curSigmaSqW  <- currentState[5]

    if (curSigmaSq + curSigmaSqW >= cutOff){
      filename <- file.path(outDir,
                  "nextState",
                  allData$countryNames[countryToUse],
                  paste(c('nextState',subsetStates[ii],'Rda'), collapse = '.'))
      load(filename)

      nextFinePDivEq    <- output$Equity[nextState$nextState]
      nextFinePDivVec   <- finePDivVecOld[nextState$nextState]
      coarsePDivVec[ii] <- PDivPerpetuityIntFunc(currentState,
                            output$EquityCoarse[subsetStates[ii]],
                            nextFinePDivEq,nextFinePDivVec)

      rm(nextState)
    }
  }
  return(coarsePDivVec)
}

## Multicore version of PDivOnePerRiskyBondIntFunc()
snowPDivOnePerRiskyBondIntFunc  <- function(subsetStates,
                      coarseStateGrid,
                      Equity,
                      EquityCoarse,
                      countryToUse,
                      PDivOnePerRiskyBondIntFunc)
{
  coarsePDivVec <- numeric(length(subsetStates))
  xi            <- ParEst[bigDataPosInfo$xi][countryToUse]
  cutOff        <- controlVarNAPi$cutOff

  for (ii in 1:length(subsetStates)) {
  currentState <- coarseStateGrid[subsetStates[ii],]
  curSigmaSq   <- currentState[3]
  curSigmaSqW  <- currentState[5]
  if (curSigmaSq + curSigmaSqW >= cutOff){
    filename <-
    file.path(outDir,"nextState",allData$countryNames[countryToUse],
         paste(c('nextState',subsetStates[ii],'Rda'),collapse='.'))
    load(filename)

    nextFinePDivEq    <- Equity[nextState$nextState]

    coarsePDivVec[ii] <- PDivOnePerRiskyBondIntFunc(
                  currentState,
                  EquityCoarse[subsetStates[ii]],
                  nextFinePDivEq)
  }
  }
  return(coarsePDivVec)
}

## Multicore version of PDivTPerRiskyBondIntFunc()
snowPDivTPerRiskyBondIntFunc    <- function(subsetStates,
                      coarseStateGrid,
                      Equity,
                      EquityCoarse,
                      finePDivVecTminusOnePerBond,
                      countryToUse,
                      PDivTPerRiskyBondIntFunc)
{
  coarsePDivVec <- numeric(length(subsetStates))
  xi            <- ParEst[bigDataPosInfo$xi][countryToUse]
  cutOff        <- controlVarNAPi$cutOff

  for (ii in 1:length(subsetStates)) {
  currentState <- coarseStateGrid[subsetStates[ii],]
  curSigmaSq   <- currentState[3]
  curSigmaSqW  <- currentState[5]
  if (curSigmaSq + curSigmaSqW >= cutOff){
    # Read with possible transitions, i.e., it tells the algorithm were
    # state can go next period from current location
    filename <- file.path(outDir,"nextState",
          allData$countryNames[countryToUse],
          paste(c('nextState',subsetStates[ii],'Rda'),collapse='.'))
    load(filename)

    # Read unlevered equity P-D ratio for possible states tomorrow
    nextFinePDivEq <- Equity[nextState$nextState]

    # Read (T-1)-period risky bond P-D ratio for possible states tomorrow
    nextFinePDivVecTminusOnePerBond <-
      finePDivVecTminusOnePerBond[nextState$nextState]

    # Compute T-period risky bond P-D ratio
    coarsePDivVec[ii] <- PDivTPerRiskyBondIntFunc(
                currentState,
                EquityCoarse[subsetStates[ii]],
                nextFinePDivEq,
                nextFinePDivVecTminusOnePerBond)
  }
  }
  return(coarsePDivVec)
}

## Multicore version of DDivOnePerRiskyBondIntFunc()
snowDDivOnePerRiskyBondIntFunc  <- function(subsetStates,
                      coarseStateGrid,
                      countryToUse,
                      DDivOnePerRiskyBondIntFunc)
{
  coarseDDivVec <- numeric(length(subsetStates))
  cutOff        <- controlVarNAPi$cutOff

  for (ii in 1:length(subsetStates)) {
    currentState <- coarseStateGrid[subsetStates[ii],]
    curSigmaSq   <- currentState[3]
    curSigmaSqW  <- currentState[5]
    if (curSigmaSq + curSigmaSqW >= cutOff){
      coarseDDivVec[ii] <- DDivOnePerRiskyBondIntFunc(currentState)
    }
  }
  return(coarseDDivVec)
}

## Multicore version of VepsWoverSigmaSqWIntFunc()
snowVepsWoverSigmaSqWIntFunc    <- function(subsetStates,
                      coarseStateGrid,
                      countryToUse,
                      VepsWoverSigmaSqWIntFunc)
{
  coarseVec <- numeric(length(subsetStates))
  cutOff        <- controlVarNAPi$cutOff

  for (ii in 1:length(subsetStates)) {
    currentState <- coarseStateGrid[subsetStates[ii],]
    curSigmaSq   <- currentState[3]
    curSigmaSqW  <- currentState[5]
    if (curSigmaSq + curSigmaSqW >= cutOff){
      coarseVec[ii] <- VepsWoverSigmaSqWIntFunc(currentState)
    }
  }
  return(coarseVec)
}

## Multicore version of DDivTPerRiskyBondIntFunc()
snowDDivTPerRiskyBondIntFunc    <- function(subsetStates,
                      coarseStateGrid,
                      fineDDivVecTminusOnePerBond,
                      countryToUse,
                      DDivTPerRiskyBondIntFunc)
{
  coarseDDivVec <- numeric(length(subsetStates))
  xi            <- ParEst[bigDataPosInfo$xi][countryToUse]
  cutOff        <- controlVarNAPi$cutOff
  cutOffW       <- controlVarNAPi$cutOffW

  for (ii in 1:length(subsetStates)) {
    currentState <- coarseStateGrid[subsetStates[ii],]
    curSigmaSq   <- currentState[3]
    curSigmaSqW  <- currentState[5]
    if (curSigmaSq + curSigmaSqW >= cutOff){
      filename <- file.path(outDir, "nextState",allData$countryNames[countryToUse],
                  paste(c('nextState',subsetStates[ii],'Rda'), collapse = '.'))
      load(filename)
      nextFineDDivVecTminusOnePerBond <- fineDDivVecTminusOnePerBond[nextState$nextState]
      coarseDDivVec[ii] <- DDivTPerRiskyBondIntFunc(currentState,
                        nextFineDDivVecTminusOnePerBond)
    }
  }
  return(coarseDDivVec)
}

## Multicore version of Covv1IntFunc()
snowCovv1IntFunc <- function(subsetStates,
                      coarseStateGrid,
                      countryToUse,
                      Covv1IntFunc)
{
  coarseVec   <- numeric(length(subsetStates))
  cutOff      <- controlVarNAPi$cutOff

  for (ii in 1:length(subsetStates)) {
    currentState <- coarseStateGrid[subsetStates[ii],]
    curSigmaSq   <- currentState[3]
    curSigmaSqW  <- currentState[5]
    if (curSigmaSq + curSigmaSqW >= cutOff){
      coarseVec[ii] <- Covv1IntFunc(currentState)
    }
  }
  return(coarseVec)
}

## Multicore version of Covv1costIntFunc()
snowCovv1costIntFunc <- function(subsetStates,
                      coarseStateGrid,
                      output,
                      countryToUse,
                      Covv1costIntFunc)
{
  coarseVec   <- numeric(length(subsetStates))
  cutOff      <- controlVarNAPi$cutOff

  for (ii in 1:length(subsetStates)) {
    currentState <- coarseStateGrid[subsetStates[ii],]
    curSigmaSq   <- currentState[3]
    curSigmaSqW  <- currentState[5]

    filename <- file.path(outDir,
                "nextState",
                allData$countryNames[countryToUse],
                paste(c('nextState',subsetStates[ii],'Rda'),
                collapse = '.'))

    load(filename)

    nextFinePDivEq    <- output$Equity[nextState$nextState]
    #nextFinePDivVec   <- finePDivVecOld[nextState$nextState]

    if (curSigmaSq + curSigmaSqW >= cutOff){
      coarseVec[ii] <- Covv1costIntFunc(currentState,
                output$EquityCoarse[subsetStates[ii]],
                nextFinePDivEq)
    }
  }
  return(coarseVec)
}

## Multicore version of CovvTIntFunc()
snowCovvTIntFunc <- function(subsetStates,
                      coarseStateGrid,
                      fineDDivVecTminusOnePerBond,
                      countryToUse,
                      CovvTIntFunc)
{
  # This function is used to cycles through
  # state space in the current period to
  # compute covariance
  coarseVec   <- numeric(length(subsetStates))
  cutOff      <- controlVarNAPi$cutOff

  for (ii in 1:length(subsetStates)) {
  currentState <- coarseStateGrid[subsetStates[ii],]
  curSigmaSq   <- currentState[3]
  curSigmaSqW  <- currentState[5]
  if (curSigmaSq + curSigmaSqW >= cutOff){
    filename <- file.path(outDir,
          "nextState",
          allData$countryNames[countryToUse],
          paste(c('nextState',subsetStates[ii],'Rda'),collapse='.'))
    load(filename)
    nextFineDDivVecTminusOnePerBond <-
            fineDDivVecTminusOnePerBond[nextState$nextState]

    coarseVec[ii] <-
      CovvTIntFunc(currentState,
              nextFineDDivVecTminusOnePerBond)
  }
  }
  return(coarseVec)
}

## Multicore version of CovvTcostIntFunc()
snowCovvTcostIntFunc <- function(subsetStates,
                      coarseStateGrid,
                      Equity,
                      EquityCoarse,
                      fineDDivVecTminusOnePerBond,
                      countryToUse,
                      CovvTcostIntFunc)
{
  # This function is used to cycles through
  # state space in the current period to
  # compute covariance
  coarseVec   <- numeric(length(subsetStates))
  cutOff      <- controlVarNAPi$cutOff

  for (ii in 1:length(subsetStates)) {
  currentState <- coarseStateGrid[subsetStates[ii],]
  curSigmaSq   <- currentState[3]
  curSigmaSqW  <- currentState[5]

  filename <- file.path(outDir,
              "nextState",
              allData$countryNames[countryToUse],
              paste(c('nextState',subsetStates[ii],'Rda'),
              collapse = '.'))

  load(filename)

  nextFinePDivEq    <- Equity[nextState$nextState]

  if (curSigmaSq + curSigmaSqW >= cutOff){
    filename <- file.path(outDir,
          "nextState",
          allData$countryNames[countryToUse],
          paste(c('nextState',subsetStates[ii],'Rda'),collapse='.'))
    load(filename)
    nextFineDDivVecTminusOnePerBond <-
            fineDDivVecTminusOnePerBond[nextState$nextState]

    coarseVec[ii] <-
      CovvTcostIntFunc(currentState,
            EquityCoarse[subsetStates[ii]],
            nextFinePDivEq,
            nextFineDDivVecTminusOnePerBond)
  }
  }
  return(coarseVec)
}


getPDivs_EZW  <- function(allData,
                      countryToUse,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo,
                      printStuff = 1)
{
  # Calculate P-Div Ratio for Equity for Each Value on State Grid
  ###############################################################
  # Create Coarse State Grid
  coarseStateGridList <- createCoarseStateGrid(countryToUse,
                        controlVarNAPi,
                        ParEst,
                        UnobsPosInfo)
  coarseStateGrid <- coarseStateGridList$coarseStateGrid

  # Create Fine State Grid
  fineStateGridList <- createFineStateGrid(countryToUse,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)
  fineStateGrid <- fineStateGridList$fineStateGrid

  # Create Integration grid
  intGridList <- createIntGrid(countryToUse,
                controlVarNAPi,
                ParEst,
                UnobsPosInfo,
                fineStateGridList)
  intGrid <- intGridList$intGrid

  # Genernate PDivNextIntFuncGens
  PDivIntFunc <- PDivIntFuncGen(countryToUse,
                 coarseStateGridList,
                 intGridList,
                 controlVarNAPi,
                 ParEst,
                 UnobsPosInfo)

  PDivEqIntFunc              <- PDivIntFunc$PDivEqIntFunc
  PDivOnePerBondIntFunc      <- PDivIntFunc$PDivOnePerBondIntFunc
  PDivLeveredXXEqIntFunc     <- PDivIntFunc$PDivLeveredXXEqIntFunc

  PDivOnePerRiskyBondIntFunc <- PDivIntFunc$PDivOnePerRiskyBondIntFunc
  PDivTPerRiskyBondIntFunc   <- PDivIntFunc$PDivTPerRiskyBondIntFunc

  if (GlobalUseSnow == 1){
  ## Create cluster
  cl <- makeCluster(controlVarNAPi$nprocs,type="MPI")

  ## Outputs info about cluster
  clusterCall(cl, function() Sys.info()[c("nodename","machine")])

  ## Create a vector of varibale names to send to all cores
  variablesOnAllCores <- c("outDir","prefixDir","allData",
              "controlVar","controlAgg",
              "controlVarNAPi","countryToUse",
              "ParEst","UnobsPosInfo","GlobalUseSnow",
              "bigDataPosInfo","GlobalCountryName")

  ## Export variables into each core in cluster
  clusterExport(cl,variablesOnAllCores)

  ## Evaluate functions on every core of the cluster
  clusterEvalQ(cl,{
    source('funcs.R');
    source('funcsAgg.R');
    source('funcsNAPe.R');

    coarseStateGridList <- createCoarseStateGrid(countryToUse,
                            controlVarNAPi,
                            ParEst,
                            bigDataPosInfo);

    coarseStateGrid <- coarseStateGridList$coarseStateGrid;

    fineStateGridList <- createFineStateGrid(countryToUse,
                          controlVarNAPi,
                          ParEst,
                          bigDataPosInfo);

    fineStateGrid <- fineStateGridList$fineStateGrid;

    intGridList <- createIntGrid(countryToUse,
                    controlVarNAPi,
                    ParEst,
                    bigDataPosInfo,
                    fineStateGridList);

    intGrid <- intGridList$intGrid;

    PDivIntFunc <- PDivIntFuncGen(countryToUse,
                    coarseStateGridList,
                    intGridList,
                    controlVarNAPi,
                    ParEst,
                    bigDataPosInfo);

    PDivEqIntFunc               <- PDivIntFunc$PDivEqIntFunc;
    PDivOnePerBondIntFunc       <- PDivIntFunc$PDivOnePerBondIntFunc;
    PDivLeveredXXEqIntFunc      <- PDivIntFunc$PDivLeveredXXEqIntFunc;
    PDivPerpetuityIntFunc       <- PDivIntFunc$PDivPerpetuityIntFunc;
    PDivOnePerRiskyBondIntFunc  <- PDivIntFunc$PDivOnePerRiskyBondIntFunc;
    PDivTPerRiskyBondIntFunc    <- PDivIntFunc$PDivTPerRiskyBondIntFunc;
  })
  ## Split the set of all coarse states into subsets that will be used on cores
  subsetStates <- clusterSplit(cl, c(1:dim(coarseStateGrid)[1]))
  }
  ## Generate nextStateFunc on a Cluster OR on a single compuater
  if (GlobalUseSnow == 1){
    if (controlVarNAPi$createNextStateFiles == 1){
      timerC            <- proc.time()[3]
      clusterApply(cl,
            subsetStates,
            nextStateFuncGenAndSaveOnCluster,
            allData,
            countryToUse,
            coarseStateGridList,
            fineStateGridList,
            intGridList,
            controlVarNAPi,
            ParEst,
            bigDataPosInfo)
      timerC <- proc.time()[3] - timerC

      if (printStuff) {
        cat('nextState files created in ',timerC,'\n')
      }
    }
  } else {
  if (controlVarNAPi$createNextStateFiles == 1){
    timerC <- proc.time()[3]
    nextStateFuncGenAndSave(allData,countryToUse,coarseStateGridList,
                fineStateGridList, intGridList,
                controlVarNAPi, ParEst, UnobsPosInfo)

    timerC <- proc.time()[3] - timerC

    if (printStuff) {
    cat('nextState files created in ',timerC,'\n')
    }
  }
  }
  # Calculate weights over intGrid
  calcWeightsFuncGenAndSave(countryToUse,
                coarseStateGridList,
                intGridList,
                controlVarNAPi,
                ParEst,
                UnobsPosInfo)

  # Read some useful variables
  nCoarseStateGridNu        <- controlVarNAPi$nCoarseStateGridNu
  nCoarseStateGridXX        <- controlVarNAPi$nCoarseStateGridXX
  nCoarseStateGridSigmaSq   <- controlVarNAPi$nCoarseStateGridSigmaSq
  nCoarseStateGridXXW       <- controlVarNAPi$nCoarseStateGridXXW
  nCoarseStateGridSigmaSqW  <- controlVarNAPi$nCoarseStateGridSigmaSqW

  nFineStateGridNu          <- controlVarNAPi$nFineStateGridNu
  nFineStateGridXX          <- controlVarNAPi$nFineStateGridXX
  nFineStateGridSigmaSq     <- controlVarNAPi$nFineStateGridSigmaSq
  nFineStateGridXXW         <- controlVarNAPi$nFineStateGridXXW
  nFineStateGridSigmaSqW    <- controlVarNAPi$nFineStateGridSigmaSqW

  fineGridNu                <- fineStateGridList$gridNu
  fineGridXX                <- fineStateGridList$gridXX
  fineGridSigmaSq           <- fineStateGridList$gridSigmaSq
  fineGridXXW               <- fineStateGridList$gridXXW
  fineGridSigmaSqW          <- fineStateGridList$gridSigmaSqW

  coarseGridNu              <- coarseStateGridList$gridNu
  coarseGridXX              <- coarseStateGridList$gridXX
  coarseGridSigmaSq         <- coarseStateGridList$gridSigmaSq
  coarseGridXXW             <- coarseStateGridList$gridXXW
  coarseGridSigmaSqW        <- coarseStateGridList$gridSigmaSqW

  ##############################################################################
  ##                            Equity claim                                  ##
  ##############################################################################
  # Note:
  # flag variable can take on three values: 0,1 and 2.
  #   flag$Equity = 0 - equity computation has not
  #                     been started yet at all;
  #   flag$Equity = 1 - equity iterations started
  #                     but they haven't finished yet;
  #   flag$Equity = 2 - computation was finished before.
  #

  if (controlVarNAPi$newInitPDivs == 1){
    flags               <- list(Equity      = 0,
                  OnePerBond  = 0,
                  Perpetuity  = 0,
                  LeveredXXEq = 0)
    coarsePDivVec <- numeric(dim(coarseStateGrid)[1]) +
                controlVarNAPi$initPDivEqUnLev
    finePDivVec   <- numeric(dim(fineStateGrid)[1]) +
                    controlVarNAPi$initPDivEqUnLev
    coarsePDivVecOld <- coarsePDivVec
    finePDivVecOld   <- finePDivVec

    if (printStuff){
      cat('----------------------------------\n')
      cat('Calculating P-Div Ratio for Equity\n')
      cat('----------------------------------\n')
    }

    timer2  <- proc.time()[3]
    nIter   <- 0
    maxDiff <- 2*controlVarNAPi$tolIntEq
  } else {
    filename <-
    file.path(outDir,
      paste(c('tempPDivsOutput',GlobalCountryName,'Rda'), collapse = '.'))
    load(filename)

    if (flags$Equity == 1) {
      coarsePDivVec    <- output$EquityCoarse
      finePDivVec      <- output$Equity
      coarsePDivVecOld <- coarsePDivVec
      finePDivVecOld   <- finePDivVec
    }
  }
  xi      <- ParEst[UnobsPosInfo$xi][countryToUse]
  cutOff  <- controlVarNAPi$cutOff
  cutOffW <- controlVarNAPi$cutOffW

  while ((flags$Equity != 2) &
      (maxDiff > controlVarNAPi$tolIntEq) &
      (nIter < controlVarNAPi$maxIter) &
        (maxDiff < 10^5))
  {
  timer1            <- proc.time()[3]

  if (GlobalUseSnow == 1){
    ## On Cluster
    coarsePDivVecList <- clusterApply(cl,subsetStates, snowPDivEqIntFunc,
                    coarseStateGrid,finePDivVecOld,
                    countryToUse,PDivEqIntFunc)
    coarsePDivVec <- unlist(coarsePDivVecList)
  } else {
    ## On single computer
    coarsePDivVec <- snowPDivEqIntFunc(c(1:dim(coarseStateGrid)[1]),
                       coarseStateGrid,finePDivVecOld,
                       countryToUse,PDivEqIntFunc)
  }

  maxDiff           <- max(abs(exp(coarsePDivVec) - exp(coarsePDivVecOld)))
  coarsePDivVecOld  <- coarsePDivVec
  timer1            <- proc.time()[3] - timer1

  ## INTERPOLATION ONTO FINE GRID
  timer11     <- proc.time()[3]
  finePDivVec <- InterpolOnFineGrid(coarsePDivVec,
                    cutOff,
                    controlVarNAPi,
                    fineStateGridList,
                    coarseStateGridList)
  finePDivVecOld  <- finePDivVec

  nIter            <- nIter + 1
  timer11          <- proc.time()[3] - timer11
  if (printStuff) {
    cat("  ",nIter,") P-D time = ",timer1,
             ", interp time = ",timer11,
             ", maxDiff = ",maxDiff,'\n')
  }
  if (nIter %% 10 == 0) {
    output       <- list(Equity       = finePDivVec,
               EquityCoarse = coarsePDivVec)

    ## Marks that equity iterations have
    ## been started but not yet completed
    flags$Equity <- 1

    ## Save intermediate computation results in a file
    filename <- file.path(outDir,
    paste(c('tempPDivsOutput',GlobalCountryName,'Rda'), collapse = '.'))
    save(output,nIter,maxDiff,flags,timer2, file = filename)
  }
  }
  if (printStuff & (flags$Equity == 1)) {
    cat('\n')
    timer2 <- proc.time()[3] - timer2
    cat('Total Time Int Equity: ', timer2, '\n')
    cat('Number of Iterations:  ', nIter,'\n')
    cat('sup norm:              ', maxDiff,'\n\n')
  }
  if (flags$Equity == 1) {
  ## Marks the end of equity iterations so that it
  ## will not be repeated when the program is restarted
  flags$Equity <- 2

  output <- list(Equity       = finePDivVec,
           EquityCoarse = coarsePDivVec)

  ## Save intermediate computation results in a file
  filename <- file.path(outDir,
    paste(c('tempPDivsOutput',GlobalCountryName,'Rda'), collapse = '.'))
  save(output,nIter,maxDiff,flags, file = filename)
  }
  if (nIter == controlVarNAPi$maxIter) {
    cat('\n')
    cat('#########################################\n')
    cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
    cat('#########################################\n')
    cat('\n')
  }
  if (maxDiff > 10^5) {
    cat('\n')
    cat('############################\n')
    cat('#### EQUITY DIVERGED #######\n')
    cat('############################\n')
    cat('\n')
  }
  if (maxDiff < 10^5 ){
    ##########################################################################
    ##                          One Period Bond                             ##
    ##########################################################################
    if (controlVarNAPi$getOnePerBond == 1) {

      # Check if the asset pricing procedure has been started before
      if (flags$OnePerBond == 0){

      # Initialize
      coarsePDivVec    <- numeric(dim(coarseStateGrid)[1]) + 4
      finePDivVec      <- numeric(dim(fineStateGrid)[1])   + 4
      coarsePDivVecOld <- coarsePDivVec
      finePDivVecOld   <- finePDivVec
      timer2           <- proc.time()[3]
      nIter            <- 0
      maxDiff          <- 2*controlVarNAPi$tolIntBond

      if (printStuff){
        cat('-------------------------------------------\n')
        cat('Calculating P-Div Ratio for One Period Bond\n')
        cat('-------------------------------------------\n')
      }
      }
      if (flags$OnePerBond == 1) {
      load(file.path(outDir,
        paste(c('tempPDivsOutput',GlobalCountryName,'Rda'),
        collapse = '.')))
      coarsePDivVec    <- output$OnePerBondCoarse
      finePDivVec      <- output$OnePerBond
      coarsePDivVecOld <- coarsePDivVec
      finePDivVecOld   <- finePDivVec
      }
      while ((flags$OnePerBond != 2) &
          (maxDiff > controlVarNAPi$tolIntBond) &
            (nIter < controlVarNAPi$maxIter) &
              (maxDiff < 10^5))
      {

      timer1 <- proc.time()[3]
      if (GlobalUseSnow == 1){
        ## On Cluster
        coarsePDivVecList <- clusterApply(cl,subsetStates,
                    snowPDivOnePerBondIntFunc,
                    coarseStateGrid,
                    output,
                    countryToUse,PDivOnePerBondIntFunc)
        coarsePDivVec <- unlist(coarsePDivVecList)
      } else {
        ## On single computer
        coarsePDivVec <- snowPDivOnePerBondIntFunc(
                    c(1:dim(coarseStateGrid)[1]),
                    coarseStateGrid,
                    output,
                    countryToUse,
                    PDivOnePerBondIntFunc)
      }
      maxDiff          <- max(abs(exp(coarsePDivVec) -
                     exp(coarsePDivVecOld)))
      coarsePDivVecOld <- coarsePDivVec
      timer1           <- proc.time()[3] - timer1

      ## INTERPOLATION ONTO FINE GRID                            #
      timer11     <- proc.time()[3]
      finePDivVec <- InterpolOnFineGrid(coarsePDivVec,
                     cutOff,
                     controlVarNAPi,
                     fineStateGridList,
                     coarseStateGridList)
      finePDivVecOld <- finePDivVec

      nIter   <- nIter + 1
      timer11 <- proc.time()[3] - timer11
      if (printStuff) {
        cat(nIter,")",timer1,timer11,":",maxDiff,' ')
        if (nIter %% 2 == 0) {
          cat('\n')
        }
      }
      if (nIter %% 2 == 0) {
        output$OnePerBond       <- finePDivVec
        output$OnePerBondCoarse <- coarsePDivVec

        ## Marks that bond iterations have
        ## been started but not yet completed
        flags$OnePerBond        <- 1

        ## Save intermediate results
        filename <- file.path(outDir,
          paste(c('tempPDivsOutput',GlobalCountryName,'Rda'),
          collapse = '.'))
        save(output,nIter,maxDiff,flags,timer2, file = filename)
      }
      }
      if (printStuff & (flags$OnePerBond == 1)) {
        cat('\n')
        timer2 <- proc.time()[3] - timer2
        cat('Total Time Int OnePerBond: ', timer2, '\n')
        cat('Number of Iterations:      ', nIter,'\n')
        cat('sup norm:                  ', maxDiff,'\n')
      }
      if (flags$OnePerBond == 1) {
        output$OnePerBond       <- finePDivVec
        output$OnePerBondCoarse <- coarsePDivVec

        ## Marks the end of bond iterations so that it
        ## will not be repeated when the program is restarted
        flags$OnePerBond <- 2

        filename <- file.path(outDir,
        paste(c('tempPDivsOutput',GlobalCountryName,'Rda'),
          collapse = '.'))
        save(output,nIter,maxDiff,flags, file = filename)
      }
    }
    ##########################################################################
    ##                              Perpetuity                              ##
    ##########################################################################
    if (controlVarNAPi$getPerpetuity == 1) {
      if (flags$Perpetuity == 0){
      coarsePDivVec    <- numeric(dim(coarseStateGrid)[1]) + 5
      finePDivVec      <- numeric(dim(fineStateGrid)[1]) + 5
      coarsePDivVecOld <- coarsePDivVec
      finePDivVecOld   <- finePDivVec
      if (printStuff){
        cat('Calculating P-Div Ratio for a Perpetuity\n')
      }
      timer2  <- proc.time()[3]
      nIter   <- 0
      maxDiff <- 2*controlVarNAPi$tolIntPerp
      }
      if (flags$Perpetuity == 1) {
      filename <- file.path(outDir,
             paste(c('tempPDivsOutput',
               GlobalCountryName,'Rda'),
               collapse = '.'))
      load(filename)
      coarsePDivVec    <- output$PerpetuityCoarse
      finePDivVec      <- output$Perpetuity
      coarsePDivVecOld <- coarsePDivVec
      finePDivVecOld   <- finePDivVec
      }
      while ((flags$Perpetuity != 2) &
          (maxDiff > controlVarNAPi$tolIntPerp) &
            (nIter < controlVarNAPi$maxIter) &
              (maxDiff < 10^5)) {

        ## Main Price-Dividend computation lines
        timer1 <- proc.time()[3]
        if (GlobalUseSnow == 1){ ## On Cluster
          coarsePDivVecList <- clusterApply(cl,
                                          subsetStates,
                                          snowPDivPerpetuityIntFunc,
                                          coarseStateGrid,output,
                                          finePDivVecOld,
                                          countryToUse,
                                          PDivPerpetuityIntFunc)
          coarsePDivVec     <- unlist(coarsePDivVecList)
        } else {  ## On single computer
          coarsePDivVec <- snowPDivPerpetuityIntFunc(
                                          c(1:dim(coarseStateGrid)[1]),
                                          coarseStateGrid,
                                          output,
                                          finePDivVecOld,
                                          countryToUse,
                                          PDivPerpetuityIntFunc)
        }
        timer1           <- proc.time()[3] - timer1
        maxDiff          <- max(abs(exp(coarsePDivVec) - exp(coarsePDivVecOld)))
        coarsePDivVecOld <- coarsePDivVec

        ## INTERPOLATION ONTO FINE GRID
        timer11         <- proc.time()[3]
        finePDivVec     <- InterpolOnFineGrid(coarsePDivVec,
                                            cutOff,
                                            controlVarNAPi,
                                            fineStateGridList,
                                            coarseStateGridList)
        finePDivVecOld  <- finePDivVec

        nIter   <- nIter + 1
        timer11 <- proc.time()[3] - timer11
        if (printStuff) {
          cat(nIter,")",timer1,timer11,":",maxDiff,' ')
          if (nIter %% 10 == 0) {
            cat('\n')
          }
        }
        if (nIter %% 10 == 0) {
          output$Perpetuity       <- finePDivVec
          output$PerpetuityCoarse <- coarsePDivVec
          flags$Perpetuity        <- 1 # Marks that Perpetuity iterations
                                       # have been started but not yet completed

          filename <- file.path(outDir,
                              paste(c('tempPDivsOutput',
                                    GlobalCountryName,
                                    'Rda'),
                              collapse = '.'))
          save(output,nIter,maxDiff,flags,timer2, file = filename)
        }
      }
      if (printStuff & (flags$Perpetuity == 1)) {
        cat('\n')
        timer2 <- proc.time()[3] - timer2
        cat('Total Time Int Perpetuity: ', timer2, '\n')
        cat('Number of Iterations:      ', nIter,'\n')
        cat('sup norm:                  ', maxDiff,'\n')
      }
      if (flags$Perpetuity == 1) {
        output$Perpetuity       <- finePDivVec
        output$PerpetuityCoarse <- coarsePDivVec
        flags$Perpetuity        <- 2 ## Marks the end of Perpetuity iterations
                                     ## so that it will not be repeated when
                                     ## the program is restarted

        filename <- file.path(outDir,
                              paste(c('tempPDivsOutput',
                                GlobalCountryName,'Rda'),
                              collapse = '.'))
        save(output,nIter,maxDiff,flags, file = filename)
      }
      if (nIter == controlVarNAPi$maxIter) {
        cat('#########################################\n')
        cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
        cat('#########################################\n')
      }
    }
    ##########################################################################
    ##                          Levered XX Equity                           ##
    ##########################################################################
    if (controlVarNAPi$getLeveredXXEquity == 1) {
    if (flags$LeveredXXEq == 0){
      coarsePDivVec       <- numeric(dim(coarseStateGrid)[1]) +
                      controlVarNAPi$initPDivEqLev
      finePDivVec         <- numeric(dim(fineStateGrid)[1]) +
                      controlVarNAPi$initPDivEqLev
      coarsePDivVecOld    <- coarsePDivVec
      finePDivVecOld      <- finePDivVec
      if (printStuff) {
        cat('Calculating P-Div Ratio for a a levered XX equity \n')
      }
      timer2              <- proc.time()[3]
      nIter               <- 0
      maxDiff             <- 2*controlVarNAPi$tolIntLeveredXXEq
    }
    if (flags$LeveredXXEq == 1) {
      filename <- file.path(outDir,
            paste(c('tempPDivsOutput',GlobalCountryName,'Rda'),
              collapse = '.'))
      load(filename)

      coarsePDivVec       <- output$LeveredXXEqCoarse
      finePDivVec         <- output$LeveredXXEq
      coarsePDivVecOld    <- coarsePDivVec
      finePDivVecOld      <- finePDivVec
    }
      while ((flags$LeveredXXEq != 2) &
          (maxDiff > controlVarNAPi$tolIntLeveredXXEq) &
            (nIter < controlVarNAPi$maxIter) &
              (maxDiff < 10^5)) {

      timer1 <- proc.time()[3]
      if (GlobalUseSnow == 1){
        ## On Cluster
        coarsePDivVecList <- clusterApply(cl,
                        subsetStates,
                        snowPDivLeveredXXEqIntFunc,
                        coarseStateGrid,
                        output,
                        finePDivVecOld,
                        countryToUse,
                        PDivLeveredXXEqIntFunc)
        coarsePDivVec     <- unlist(coarsePDivVecList)
      } else {
        ## On single computer
        coarsePDivVec <- snowPDivLeveredXXEqIntFunc(
                  c(1:dim(coarseStateGrid)[1]),
                    coarseStateGrid,
                    output,
                    finePDivVecOld,
                    countryToUse,
                    PDivLeveredXXEqIntFunc)
      }

      maxDiff <- max(abs(exp(coarsePDivVec) -
                 exp(coarsePDivVecOld)))
      coarsePDivVecOld <- coarsePDivVec
      timer1           <- proc.time()[3] - timer1

      ## INTERPOLATION ONTO FINE GRID
      timer11     <- proc.time()[3]
      finePDivVec <- InterpolOnFineGrid(coarsePDivVec,
                       cutOff,
                       controlVarNAPi,
                       fineStateGridList,
                       coarseStateGridList)
      finePDivVecOld <- finePDivVec

      nIter   <- nIter + 1
      timer11 <- proc.time()[3] - timer11
      if (printStuff) {
        cat(nIter,")",timer1,timer11,":",maxDiff,' ')
        if (nIter %% 10 == 0) {
          cat('\n')
        }
      }
      if (nIter %% 10 == 0) {
        output$LeveredXXEq       <- finePDivVec
        output$LeveredXXEqCoarse <- coarsePDivVec

        ## Marks that LeveredXXEq iterations have
        ## been started but not yet completed
        flags$LeveredXXEq        <- 1

        ## Save intermediate results
        filename <- file.path(outDir,
              paste(c('tempPDivsOutput',GlobalCountryName,'Rda'),
                collapse = '.'))
        save(output,nIter,maxDiff,flags,timer2, file = filename)
      }
      }
      if (printStuff & (flags$LeveredXXEq == 1)) {
        cat('\n')
        timer2 <- proc.time()[3] - timer2
        cat('Total Time Int LeveredXXEq:', timer2, '\n')
        cat('Number of Iterations:      ', nIter,'\n')
        cat('sup norm:                  ', maxDiff,'\n')
      }
      if (flags$LeveredXXEq == 1) {
        output$LeveredXXEq       <- finePDivVec
        output$LeveredXXEqCoarse <- coarsePDivVec

        ## Marks the end of LeveredXXEq iterations
        ## so that it will not be repeated when the program is restarted
        flags$LeveredXXEq        <- 2
        filename <- file.path(outDir,
              paste(c('tempPDivsOutput',GlobalCountryName,'Rda'),
                collapse = '.'))
        save(output,nIter,maxDiff,flags, file = filename)
      }
      if (nIter == controlVarNAPi$maxIter) {
        cat('#########################################\n')
        cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
        cat('#########################################\n')
      }
    }
  }
  if (GlobalUseSnow == 1){
  stopCluster(cl)
  }

  return(output)
}

getAndSaveMomements <- function(allData,
                      countryToUse,
                      controlVarNAPi,
                      ParEst,
                      Equity,
                      EquityCoarse,
                      UnobsPosInfo,
                      printStuff = 1)
{
  # This function computes elasticities and other
  # moments at each point of state space

  # Create Coarse State Grid
  coarseStateGridList <- createCoarseStateGrid(countryToUse,
                        controlVarNAPi,
                        ParEst,
                        UnobsPosInfo)

  coarseStateGrid <- coarseStateGridList$coarseStateGrid

  # Create Fine State Grid
  fineStateGridList <- createFineStateGrid(countryToUse,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo)

  fineStateGrid <- fineStateGridList$fineStateGrid

  # Create Integration grid
  intGridList <- createIntGrid(countryToUse,
                controlVarNAPi,
                ParEst,
                UnobsPosInfo,
                fineStateGridList)

  intGrid <- intGridList$intGrid

  # Genernate PDivNextIntFuncGens
  PDivIntFunc  <- PDivIntFuncGen(countryToUse,
                coarseStateGridList,
                intGridList,
                controlVarNAPi,
                ParEst,
                UnobsPosInfo)

  MomIntFunc <- MomIntFuncGen(countryToUse,
                coarseStateGridList,
                intGridList,
                controlVarNAPi,
                ParEst,
                UnobsPosInfo)

  PDivOnePerRiskyBondIntFunc <-
     PDivIntFunc$PDivOnePerRiskyBondIntFunc

  PDivTPerRiskyBondIntFunc <-
     PDivIntFunc$PDivTPerRiskyBondIntFunc

  DDivOnePerRiskyBondIntFunc <-
      MomIntFunc$DDivOnePerRiskyBondIntFunc

  DDivTPerRiskyBondIntFunc <-
      MomIntFunc$DDivTPerRiskyBondIntFunc

  CovvEpsDDivTPerRiskyBondIntFunc <-
      MomIntFunc$CovvEpsDDivTPerRiskyBondIntFunc

  CovvEpsWDDivTPerRiskyBondIntFunc <-
      MomIntFunc$CovvEpsWDDivTPerRiskyBondIntFunc

  CovvOmegaDDivTPerRiskyBondIntFunc <-
      MomIntFunc$CovvOmegaDDivTPerRiskyBondIntFunc

  CovvOmegaWDDivTPerRiskyBondIntFunc <-
      MomIntFunc$CovvOmegaWDDivTPerRiskyBondIntFunc

  CovvEpsDDivOnePerRiskyBondIntFunc <-
      MomIntFunc$CovvEpsDDivOnePerRiskyBondIntFunc

  CovvEpsWDDivOnePerRiskyBondIntFunc <-
      MomIntFunc$CovvEpsWDDivOnePerRiskyBondIntFunc

  CovvOmegaDDivOnePerRiskyBondIntFunc <-
      MomIntFunc$CovvOmegaDDivOnePerRiskyBondIntFunc

  CovvOmegaWDDivOnePerRiskyBondIntFunc <-
      MomIntFunc$CovvOmegaWDDivOnePerRiskyBondIntFunc

  VepsWoverSigmaSqWIntFunc <-
      MomIntFunc$VepsWoverSigmaSqWIntFunc

  CorrEpsWlogDDivOnePerRiskyBondIntFunc <-
      MomIntFunc$CorrEpsWlogDDivOnePerRiskyBondIntFunc

  CorrEpsWlogDDivTPerRiskyBondIntFunc <-
      MomIntFunc$CorrEpsWlogDDivTPerRiskyBondIntFunc

  CovvEpsPDivOnePerRiskyBondIntFunc     <-
      MomIntFunc$CovvEpsPDivOnePerRiskyBondIntFunc

  CovvEpsWPDivOnePerRiskyBondIntFunc    <-
      MomIntFunc$CovvEpsWPDivOnePerRiskyBondIntFunc

  CovvOmegaPDivOnePerRiskyBondIntFunc   <-
      MomIntFunc$CovvOmegaPDivOnePerRiskyBondIntFunc

  CovvOmegaWPDivOnePerRiskyBondIntFunc  <-
      MomIntFunc$CovvOmegaWPDivOnePerRiskyBondIntFunc

  CovvEpsPDivTPerRiskyBondIntFunc       <-
      MomIntFunc$CovvEpsPDivTPerRiskyBondIntFunc

  CovvEpsWPDivTPerRiskyBondIntFunc      <-
      MomIntFunc$CovvEpsWPDivTPerRiskyBondIntFunc

  CovvOmegaPDivTPerRiskyBondIntFunc     <-
      MomIntFunc$CovvOmegaPDivTPerRiskyBondIntFunc

  CovvOmegaWPDivTPerRiskyBondIntFunc    <-
      MomIntFunc$CovvOmegaWPDivTPerRiskyBondIntFunc


  if (GlobalUseSnow == 1){
  ## Create cluster
  cl <- makeCluster(controlVarNAPi$nprocs,
            type="MPI")

  ## Outputs info about cluster
  clusterCall(cl, function() Sys.info()[c("nodename","machine")])

  ## Create a vector of varibale names to send to all cores
  variablesOnAllCores <- c("outDir","prefixDir","allData",
               "controlVar","controlAgg",
               "controlVarNAPi","countryToUse",
               "ParEst","UnobsPosInfo","GlobalUseSnow",
               "bigDataPosInfo","GlobalCountryName",
               "Equity","EquityCoarse")

  ## Export variables into each core
  clusterExport(cl,variablesOnAllCores)

  ## Evaluate functions and variables on different cores
  ## of the cluster
  clusterEvalQ(cl,{
    source('funcs.R');
    source('funcsAgg.R');
    source('funcsNAPe.R');

    coarseStateGridList <- createCoarseStateGrid(countryToUse,
                           controlVarNAPi,
                           ParEst,
                           bigDataPosInfo);

    coarseStateGrid <- coarseStateGridList$coarseStateGrid;

    fineStateGridList <- createFineStateGrid(countryToUse,controlVarNAPi,
                           ParEst,bigDataPosInfo);

    fineStateGrid <- fineStateGridList$fineStateGrid;

    intGridList  <- createIntGrid(countryToUse,controlVarNAPi,
                       ParEst,bigDataPosInfo,
                       fineStateGridList);

    intGrid <- intGridList$intGrid;

    PDivIntFunc  <- PDivIntFuncGen(countryToUse,
                  coarseStateGridList,
                  intGridList,
                  controlVarNAPi,
                  ParEst,
                  UnobsPosInfo)

    MomIntFunc <- MomIntFuncGen(countryToUse,
                  coarseStateGridList,
                  intGridList,
                  controlVarNAPi,
                  ParEst,
                  bigDataPosInfo);

    PDivOnePerRiskyBondIntFunc <-
         PDivIntFunc$PDivOnePerRiskyBondIntFunc

    PDivTPerRiskyBondIntFunc <-
         PDivIntFunc$PDivTPerRiskyBondIntFunc

    DDivOnePerRiskyBondIntFunc <-
        MomIntFunc$DDivOnePerRiskyBondIntFunc;

    DDivTPerRiskyBondIntFunc <-
        MomIntFunc$DDivTPerRiskyBondIntFunc;

    CovvEpsDDivTPerRiskyBondIntFunc <-
        MomIntFunc$CovvEpsDDivTPerRiskyBondIntFunc;

    CovvEpsWDDivTPerRiskyBondIntFunc <-
        MomIntFunc$CovvEpsWDDivTPerRiskyBondIntFunc;

    CovvOmegaDDivTPerRiskyBondIntFunc <-
        MomIntFunc$CovvOmegaDDivTPerRiskyBondIntFunc;

    CovvOmegaWDDivTPerRiskyBondIntFunc <-
        MomIntFunc$CovvOmegaWDDivTPerRiskyBondIntFunc;

    CovvEpsDDivOnePerRiskyBondIntFunc <-
        MomIntFunc$CovvEpsDDivOnePerRiskyBondIntFunc;

    CovvEpsWDDivOnePerRiskyBondIntFunc <-
        MomIntFunc$CovvEpsWDDivOnePerRiskyBondIntFunc;

    CovvOmegaDDivOnePerRiskyBondIntFunc  <-
        MomIntFunc$CovvOmegaDDivOnePerRiskyBondIntFunc;

    CovvOmegaWDDivOnePerRiskyBondIntFunc <-
        MomIntFunc$CovvOmegaWDDivOnePerRiskyBondIntFunc;

    VepsWoverSigmaSqWIntFunc <-
        MomIntFunc$VepsWoverSigmaSqWIntFunc;

    CorrEpsWlogDDivOnePerRiskyBondIntFunc <-
        MomIntFunc$CorrEpsWlogDDivOnePerRiskyBondIntFunc;

    CorrEpsWlogDDivTPerRiskyBondIntFunc <-
        MomIntFunc$CorrEpsWlogDDivTPerRiskyBondIntFunc;

    CovvEpsPDivOnePerRiskyBondIntFunc     <-
        MomIntFunc$CovvEpsPDivOnePerRiskyBondIntFunc;

    CovvEpsWPDivOnePerRiskyBondIntFunc    <-
        MomIntFunc$CovvEpsWPDivOnePerRiskyBondIntFunc;

    CovvOmegaPDivOnePerRiskyBondIntFunc   <-
        MomIntFunc$CovvOmegaPDivOnePerRiskyBondIntFunc;

    CovvOmegaWPDivOnePerRiskyBondIntFunc  <-
        MomIntFunc$CovvOmegaWPDivOnePerRiskyBondIntFunc;

    CovvEpsPDivTPerRiskyBondIntFunc       <-
        MomIntFunc$CovvEpsPDivTPerRiskyBondIntFunc;

    CovvEpsWPDivTPerRiskyBondIntFunc      <-
        MomIntFunc$CovvEpsWPDivTPerRiskyBondIntFunc;

    CovvOmegaPDivTPerRiskyBondIntFunc     <-
        MomIntFunc$CovvOmegaPDivTPerRiskyBondIntFunc;

    CovvOmegaWPDivTPerRiskyBondIntFunc    <-
        MomIntFunc$CovvOmegaWPDivTPerRiskyBondIntFunc;
  })
  ## Split the set of all coarse states into
  ## subsets that will be sent to different cores
  subsetStates <- clusterSplit(cl, c(1:dim(coarseStateGrid)[1]))
  }
  ## Generate nextStateFunc on a Cluster OR on a single compuater
  ##################################################################
  if (GlobalUseSnow == 1){
  if (controlVarNAPi$createNextStateFiles == 1){
    timerC <- proc.time()[3]

    clusterApply(cl,
      subsetStates,
      nextStateFuncGenAndSaveOnCluster,
      allData,
      countryToUse,
      coarseStateGridList,
      fineStateGridList,
      intGridList,
      controlVarNAPi,
      ParEst,
      bigDataPosInfo)

    timerC <- proc.time()[3] - timerC
    if (printStuff) {
    cat('nextState files created in ',timerC,'\n')
    }
  }
  }
  else {
  if (controlVarNAPi$createNextStateFiles == 1){
    timerC <- proc.time()[3]
    nextStateFuncGenAndSave(allData,countryToUse,coarseStateGridList,
            fineStateGridList, intGridList,
            controlVarNAPi, ParEst, UnobsPosInfo)

    timerC <- proc.time()[3] - timerC
    if (printStuff) {
    cat('nextState files created in ',timerC,'\n')
    }
  }
  }

  # Calculate weights over intGrid
  if (controlVarNAPi$createWeightFiles){
  calcWeightsFuncGenAndSave(countryToUse,
                coarseStateGridList,
                intGridList,
                controlVarNAPi,
                ParEst,
                UnobsPosInfo)
  }

  # Load grid
  nCoarseStateGridNu        <- controlVarNAPi$nCoarseStateGridNu
  nCoarseStateGridXX        <- controlVarNAPi$nCoarseStateGridXX
  nCoarseStateGridSigmaSq   <- controlVarNAPi$nCoarseStateGridSigmaSq
  nCoarseStateGridXXW       <- controlVarNAPi$nCoarseStateGridXXW
  nCoarseStateGridSigmaSqW  <- controlVarNAPi$nCoarseStateGridSigmaSqW

  nFineStateGridNu          <- controlVarNAPi$nFineStateGridNu
  nFineStateGridXX          <- controlVarNAPi$nFineStateGridXX
  nFineStateGridSigmaSq     <- controlVarNAPi$nFineStateGridSigmaSq
  nFineStateGridXXW         <- controlVarNAPi$nFineStateGridXXW
  nFineStateGridSigmaSqW    <- controlVarNAPi$nFineStateGridSigmaSqW

  fineGridNu                <- fineStateGridList$gridNu
  fineGridXX                <- fineStateGridList$gridXX
  fineGridSigmaSq           <- fineStateGridList$gridSigmaSq
  fineGridXXW               <- fineStateGridList$gridXXW
  fineGridSigmaSqW          <- fineStateGridList$gridSigmaSqW

  coarseGridNu              <- coarseStateGridList$gridNu
  coarseGridXX              <- coarseStateGridList$gridXX
  coarseGridSigmaSq         <- coarseStateGridList$gridSigmaSq
  coarseGridXXW             <- coarseStateGridList$gridXXW
  coarseGridSigmaSqW        <- coarseStateGridList$gridSigmaSqW

  cutOff                    <- controlVarNAPi$cutOff

  ComputeSEEAtEveryPoint <- function(statName)
  {
  # This function computes elasticities (an integral) for every point of the
  # state space

  if (statName == 'SEEeps'){
    varName           <- 'TPerRiskyBondDDiv'
    shockName         <- 'Eps'
    nameOnePerIntFunc <- 'CovvEpsDDivOnePerRiskyBondIntFunc'
    nameTPerIntFunc   <- 'CovvEpsDDivTPerRiskyBondIntFunc'
  }
  if (statName == 'SEEepsW'){
    varName           <- 'TPerRiskyBondDDiv'
    shockName         <- 'EpsW'
    nameOnePerIntFunc <- 'CovvEpsWDDivOnePerRiskyBondIntFunc'
    nameTPerIntFunc   <- 'CovvEpsWDDivTPerRiskyBondIntFunc'
  }
  if (statName == 'SEEomega'){
    varName           <- 'TPerRiskyBondDDiv'
    shockName         <- 'Omega'
    nameOnePerIntFunc <- 'CovvOmegaDDivOnePerRiskyBondIntFunc'
    nameTPerIntFunc   <- 'CovvOmegaDDivTPerRiskyBondIntFunc'
  }
  if (statName == 'SEEomegaW'){
    varName           <- 'TPerRiskyBondDDiv'
    shockName         <- 'OmegaW'
    nameOnePerIntFunc <- 'CovvOmegaWDDivOnePerRiskyBondIntFunc'
    nameTPerIntFunc   <- 'CovvOmegaWDDivTPerRiskyBondIntFunc'
  }

  # Initialize
  assign(statName,list())
  CovvStatShockCoarse <- list()
  CovvStatShock <- list()

  timer1 <- proc.time()[3]
  timer2 <- proc.time()[3]

  # Load variable that will be correlated with a shock
  load(file.path(outDir,
    paste(c(varName,GlobalCountryName,'Rda'),collapse = '.')))

  ## cov(var1 1-per,shock)
  if (GlobalUseSnow == 1){
    ## On Cluster
    coarseVecList <- clusterApply(cl,
             subsetStates,
             snowCovv1IntFunc,
             coarseStateGrid,
             countryToUse,
             get(nameOnePerIntFunc))
    coarseVec <- unlist(coarseVecList)
  } else {
    ## On a single computer
    coarseVec <-  snowCovv1IntFunc(
            c(1:dim(coarseStateGrid)[1]),
            coarseStateGrid,
            countryToUse,
            get(nameOnePerIntFunc)
            )
  }
  ## Interpolation onto fine grid
  fineVec <- InterpolOnFineGrid(coarseVec,
                cutOff,
                controlVarNAPi,
                fineStateGridList,
                coarseStateGridList)

  timer2 <- proc.time()[3] - timer2
  if (printStuff) {
    if(statName == 'SEEeps'){
    cat('   Time to compute cov(Dividend Growth,Eps) for 1-Period risky bond:',
            timer2, '\n')
    }
    if(statName == 'SEEepsW'){
    cat('   Time to compute cov(Dividend Growth,EpsW) for 1-Period risky bond:',
            timer2, '\n')
    }
    if(statName == 'SEEomega'){
    cat('   Time to compute cov(Dividend Growth,Omega) for 1-Period risky bond:',
            timer2, '\n')
    }
    if(statName == 'SEEomegaW'){
    cat('   Time to compute cov(Dividend Growth,OmegaW) for 1-Period risky bond:',
            timer2, '\n')
    }
  }

  CovvStatShock[[1]] <- fineVec
  CovvStatShockCoarse[[1]] <- coarseVec

  for (ii in c(2:controlVarNAPi$maxMaturityTPerBonds)){
    timer2  <- proc.time()[3]

    ## Covv(stat T-Per,shock)
    if (GlobalUseSnow == 1){
    ## On Cluster
    coarseVecList <- clusterApply(cl,subsetStates,
                    snowCovvTIntFunc,
                    coarseStateGrid,
                    get(varName)[[ii-1]],
                    countryToUse,
                    get(nameTPerIntFunc))
    coarseVec     <- unlist(coarseVecList)
    } else {
    ## On a single computer
    coarseVec <-  snowCovvTIntFunc(c(1:dim(coarseStateGrid)[1]),
                    coarseStateGrid,
                    get(varName)[[ii-1]],
                    countryToUse,
                    get(nameTPerIntFunc))
    }
    ## Interpolation onto fine grid
    fineVec <- InterpolOnFineGrid(coarseVec,
                cutOff,
                controlVarNAPi,
                fineStateGridList,
                coarseStateGridList)

    CovvStatShockCoarse[[ii]] <- coarseVec
    CovvStatShock[[ii]] <- fineVec

    timer2  <- proc.time()[3] - timer2
    if (printStuff) {
    if(statName == 'SEEeps'){
      cat('   Time to compute cov(dividend growth,Eps) for ',
            ii,'-period risky bond:', timer2, '\n')
    }
    if(statName == 'SEEepsW'){
      cat('   Time to compute cov(dividend growth,EpsW) for ',
            ii,'-period risky bond:', timer2, '\n')
    }
    if(statName == 'SEEomega'){
      cat('   Time to compute cov(dividend growth,Omega) for ',
            ii,'-period risky bond:', timer2, '\n')
    }
    if(statName == 'SEEomegaW'){
      cat('   Time to compute cov(dividend growth,OmegaW) for ',
            ii,'-period risky bond:', timer2, '\n')
    }
    }
  }

  # We can potentially save the covariance results but there is no
  # need to really do that.
  #
  # save(TPerRiskyBondCovvEpsDDivCoarse,TPerRiskyBondCovvEpsDDiv,
  #   file = file.path(outDir,
  #     paste(c('TPerRiskyBondCovvDDivEps',
  #             GlobalCountryName,'Rda'), collapse = '.')))

  rm("coarseVec","fineVec")

  ## Compute elasticity
  for (ii in c(1:controlVarNAPi$maxMaturityTPerBonds)){
    eval(
    parse(
      text =
      paste(statName,
        "[[ii]]<-CovvStatShock[[ii]]/exp(get(varName)[[ii]])",
        sep="")))
  }

  if (printStuff) {
    if (statName == 'SEEeps'){
    cat('   Total time to get SEEeps:', proc.time()[3] - timer1, '\n\n')
    }
    if (statName == 'SEEepsW'){
    cat('   Total time to get SEEepsW:', proc.time()[3] - timer1, '\n\n')
    }
    if (statName == 'SEEomega'){
    cat('   Total time to get SEEomega:', proc.time()[3] - timer1, '\n\n')
    }
    if (statName == 'SEEomegaW'){
    cat('   Total time to get SEEomegaW:', proc.time()[3] - timer1, '\n\n')
    }
  }

  save(list = statName,
  file = file.path(outDir,
          paste(c(statName,GlobalCountryName,'Rda'), collapse = '.')))
  }
  ComputeSCEAtEveryPoint <- function(statName)
  {
  # This function computes elasticities (an integral) for every point of the
  # state space
  load(file.path(outDir,paste('outputEZW.',
                GlobalCountryName,
                '.Rda',sep="")))

  if (statName == 'SCEeps'){
    varName           <- 'TPerRiskyBondPDiv'
    shockName         <- 'Eps'
    nameOnePerIntFunc <- 'CovvEpsPDivOnePerRiskyBondIntFunc'
    nameTPerIntFunc   <- 'CovvEpsPDivTPerRiskyBondIntFunc'
  }
  if (statName == 'SCEepsW'){
    varName           <- 'TPerRiskyBondPDiv'
    shockName         <- 'EpsW'
    nameOnePerIntFunc <- 'CovvEpsWPDivOnePerRiskyBondIntFunc'
    nameTPerIntFunc   <- 'CovvEpsWPDivTPerRiskyBondIntFunc'
  }
  if (statName == 'SCEomega'){
    varName           <- 'TPerRiskyBondPDiv'
    shockName         <- 'Omega'
    nameOnePerIntFunc <- 'CovvOmegaPDivOnePerRiskyBondIntFunc'
    nameTPerIntFunc   <- 'CovvOmegaPDivTPerRiskyBondIntFunc'
  }
  if (statName == 'SCEomegaW'){
    varName           <- 'TPerRiskyBondPDiv'
    shockName         <- 'OmegaW'
    nameOnePerIntFunc <- 'CovvOmegaWPDivOnePerRiskyBondIntFunc'
    nameTPerIntFunc   <- 'CovvOmegaWPDivTPerRiskyBondIntFunc'
  }

  # Initialize
  assign(statName,list())
  CovvStatShockCoarse <- list()
  CovvStatShock <- list()

  timer1 <- proc.time()[3]
  timer2 <- proc.time()[3]

  # Load variable that will be correlated with a shock
  load(file.path(outDir,
    paste(c(varName,GlobalCountryName,'Rda'),collapse = '.')))

  ## cov(var1 1-per,var2)
  if (GlobalUseSnow == 1){
    ## On Cluster
    coarseVecList <- clusterApply(cl,
            subsetStates,
            snowCovv1costIntFunc,
            coarseStateGrid,
            outputEZW$PDivs,
            countryToUse,
            get(nameOnePerIntFunc))

    coarseVec <- unlist(coarseVecList)
  } else {
    ## On a single computer
    coarseVec <-  snowCovv1costIntFunc(
            c(1:dim(coarseStateGrid)[1]),
            coarseStateGrid,
            outputEZW$PDivs,
            countryToUse,
            get(nameOnePerIntFunc)
            )
  }
  ## Interpolation onto fine grid
  fineVec <- InterpolOnFineGrid(coarseVec,
                cutOff,
                controlVarNAPi,
                fineStateGridList,
                coarseStateGridList)

  timer2 <- proc.time()[3] - timer2
  if (printStuff) {
    if(statName == 'SCEeps'){
    cat('   Time to compute cov(P-D,Eps) for 1-Period risky bond:',
            timer2, '\n')
    }
    if(statName == 'SCEepsW'){
    cat('   Time to compute cov(P-D,EpsW) for 1-Period risky bond:',
            timer2, '\n')
    }
    if(statName == 'SCEomega'){
    cat('   Time to compute cov(P-D,Omega) for 1-Period risky bond:',
            timer2, '\n')
    }
    if(statName == 'SCEomegaW'){
    cat('   Time to compute cov(P-D,OmegaW) for 1-Period risky bond:',
            timer2, '\n')
    }
  }

  CovvStatShock[[1]] <- fineVec
  CovvStatShockCoarse[[1]] <- coarseVec

  for (ii in c(2:controlVarNAPi$maxMaturityTPerBonds)){
    timer2  <- proc.time()[3]

    ## Covv(stat T-Per,shock)
    if (GlobalUseSnow == 1){
    ## On Cluster
    coarseVecList <- clusterApply(cl,subsetStates,
                    snowCovvTcostIntFunc,
                    coarseStateGrid,
                    outputEZW$PDivs$Equity,
                    outputEZW$PDivs$EquityCoarse,
                    get(varName)[[ii-1]],
                    countryToUse,
                    get(nameTPerIntFunc))
    coarseVec     <- unlist(coarseVecList)
    } else {
    ## On a single computer
    coarseVec <-  snowCovvTcostIntFunc(c(1:dim(coarseStateGrid)[1]),
                    coarseStateGrid,
                    outputEZW$PDivs$Equity,
                    outputEZW$PDivs$EquityCoarse,
                    get(varName)[[ii-1]],
                    countryToUse,
                    get(nameTPerIntFunc))
    }
    ## Interpolation onto fine grid
    fineVec <- InterpolOnFineGrid(coarseVec,
                cutOff,
                controlVarNAPi,
                fineStateGridList,
                coarseStateGridList)
    CovvStatShockCoarse[[ii]] <- coarseVec
    CovvStatShock[[ii]] <- fineVec

    timer2  <- proc.time()[3] - timer2
    if (printStuff) {
    if(statName == 'SCEeps'){
      cat('   Time to compute cov(P-D,Eps) for ',
            ii,'-period risky bond:', timer2, '\n')
    }
    if(statName == 'SCEepsW'){
      cat('   Time to compute cov(P-D,EpsW) for ',
            ii,'-period risky bond:', timer2, '\n')
    }
    if(statName == 'SCEomega'){
      cat('   Time to compute cov(P-D,Omega) for ',
            ii,'-period risky bond:', timer2, '\n')
    }
    if(statName == 'SCEomegaW'){
      cat('   Time to compute cov(P-D,OmegaW) for ',
            ii,'-period risky bond:', timer2, '\n')
    }
    }
  }

  rm("coarseVec","fineVec")

  ## Compute elasticity
  for (ii in c(1:controlVarNAPi$maxMaturityTPerBonds)){
    eval(
    parse(
      text =
      paste(statName,
        "[[ii]]<-CovvStatShock[[ii]]/exp(get(varName)[[ii]])",
        sep="")))
  }

  if (printStuff) {
    if (statName == 'SCEeps'){
    cat('   Total time to get SCEeps:', proc.time()[3] - timer1, '\n')
    }
    if (statName == 'SCEepsW'){
    cat('   Total time to get SCEepsW:', proc.time()[3] - timer1, '\n')
    }
    if (statName == 'SCEomega'){
    cat('   Total time to get SCEomega:', proc.time()[3] - timer1, '\n')
    }
    if (statName == 'SCEomegaW'){
    cat('   Total time to get SCEomegaW:', proc.time()[3] - timer1, '\n')
    }
  }

  save(list = statName,
      file = file.path(outDir,
          paste(c(statName,GlobalCountryName,'Rda'),collapse = '.')))
  }
  ##############################################################################
  ##  Compute Risky Bond Expected Dividend Growth:                            ##
  ##  TPerRiskyBondDDiv[[tt]] = E_{0}(D_{t}/D_0)                              ##
  ##############################################################################
  if (controlVarNAPi$getRiskyBondDDiv == 1){

  ## Initialize
  TPerRiskyBondDDiv         <- list()
  TPerRiskyBondDDivCoarse   <- list()
  timer1 <- proc.time()[3]
  timer2 <- proc.time()[3]

  if (printStuff) {
    cat('Calculating expected dividend growth for a risky bond\n')
    cat('-----------------------------------------------------\n')
  }

  ##  1-Period Risky Bond Dividend Growth
  if (GlobalUseSnow == 1){
    ## On Cluster
    coarseVecList <- clusterApply(cl,subsetStates,
                  snowDDivOnePerRiskyBondIntFunc,
                  coarseStateGrid,
                  countryToUse,
                  DDivOnePerRiskyBondIntFunc)
    coarseVec <- unlist(coarseVecList)
  } else {
    ## On a single computer
    coarseVec <- snowDDivOnePerRiskyBondIntFunc(c(1:dim(coarseStateGrid)[1]),
                          coarseStateGrid,
                          countryToUse,
                          DDivOnePerRiskyBondIntFunc)
  }
  ## Interpolation onto fine grid
  fineVec <- InterpolOnFineGrid(coarseVec,
                cutOff,
                controlVarNAPi,
                fineStateGridList,
                coarseStateGridList)

  TPerRiskyBondDDivCoarse[[1]]<- coarseVec
  TPerRiskyBondDDiv[[1]]      <- fineVec

  rm("fineVec","coarseVec")

  timer2                  <- proc.time()[3] - timer2
  if (printStuff) {
    cat('   Time to compute dividend growth for 1-period risky bond:',
          timer2, '\n')
  }

  for (ii in c(2:controlVarNAPi$maxMaturityTPerBonds)){
    timer2  <- proc.time()[3]

    ##  T-Period Risky Bond Dividend Growth
    if (GlobalUseSnow == 1){
    ## On Cluster
    coarseVecList <- clusterApply(cl,subsetStates,
                    snowDDivTPerRiskyBondIntFunc,
                    coarseStateGrid,
                    TPerRiskyBondDDiv[[ii-1]],
                    countryToUse,
                    DDivTPerRiskyBondIntFunc)
    coarseVec <- unlist(coarseVecList)
    } else {
    ## On a single computer
    coarseVec <- snowDDivTPerRiskyBondIntFunc(c(1:dim(coarseStateGrid)[1]),
                        coarseStateGrid,
                        TPerRiskyBondDDiv[[ii-1]],
                        countryToUse,
                        DDivTPerRiskyBondIntFunc)
    }
    ## Interpolation onto fine grid
    fineVec <- InterpolOnFineGrid(coarseVec,
                  cutOff,
                  controlVarNAPi,
                  fineStateGridList,
                  coarseStateGridList)

    TPerRiskyBondDDivCoarse[[ii]] <- coarseVec
    TPerRiskyBondDDiv[[ii]] <- fineVec

    timer2  <- proc.time()[3] - timer2
    if (printStuff) {
    cat('   Time to compute dividend growth for ',
          ii,'-period risky bond:', timer2, '\n')
    }
  }
  if (printStuff) {
    cat('   Total Time TPerRiskyBondDDiv:', proc.time()[3] - timer1, '\n\n')
  }
  save(TPerRiskyBondDDiv,TPerRiskyBondDDivCoarse,
    file = file.path(outDir,
      paste(c('TPerRiskyBondDDiv',GlobalCountryName,'Rda'),collapse = '.')))
  #rm("TPerRiskyBondDDivCoarse","TPerRiskyBondDDiv","coarseVec","fineVec")
  }

  ##############################################################################
  ##  Compute Risky Bond P-D ratio                                            ##
  ##  TPerRiskyBondPDiv[[tt]] = E_{0}(M_{0,t} D_{t})/D_0                      ##
  ##############################################################################
  if (controlVarNAPi$getRiskyBondPDiv == 1){

  ## Initialize
  TPerRiskyBondPDiv <- list()
  TPerRiskyBondPDivCoarse <- list()
  timer1 <- proc.time()[3]
  timer2 <- proc.time()[3]

  if (printStuff) {
    cat('Calculating P-D ratio for risky bond                 \n')
    cat('-----------------------------------------------------\n')
  }

  ##  1-Period Risky Bond PD ratio
  if (GlobalUseSnow == 1){
    ## On Cluster
    coarseVecList <- clusterApply(cl,
                subsetStates,
                snowPDivOnePerRiskyBondIntFunc,
                coarseStateGrid,
                Equity,
                EquityCoarse,
                countryToUse,
                PDivOnePerRiskyBondIntFunc)
    coarseVec <- unlist(coarseVecList)
  } else {
    ## On a single computer
    coarseVec <- snowPDivOnePerRiskyBondIntFunc(
              c(1:dim(coarseStateGrid)[1]),
              coarseStateGrid,
              Equity,
              EquityCoarse,
              countryToUse,
              PDivOnePerRiskyBondIntFunc)
  }

  ## Interpolation onto fine grid
  fineVec <- InterpolOnFineGrid(coarseVec,
                 cutOff,
                 controlVarNAPi,
                 fineStateGridList,
                 coarseStateGridList)
  TPerRiskyBondPDiv[[1]] <- fineVec
  TPerRiskyBondPDivCoarse[[1]] <- coarseVec

  rm("fineVec","coarseVec")

  timer2 <- proc.time()[3] - timer2
  if (printStuff) {
    cat('   Time to compute P-D ratio for 1-period risky bond:',
          timer2, '\n')
  }

  for (ii in c(2:controlVarNAPi$maxMaturityTPerBonds)){
    timer2           <- proc.time()[3]

    ##  T-Period Risky Bond P-D ratio
    if (GlobalUseSnow == 1){
      ## On Cluster
      coarseVecList <- clusterApply(cl,
                      subsetStates,
                      snowPDivTPerRiskyBondIntFunc,
                      coarseStateGrid,
                      Equity,
                      EquityCoarse,
                      TPerRiskyBondPDiv[[ii-1]],
                      countryToUse,
                      PDivTPerRiskyBondIntFunc)
      coarseVec <- unlist(coarseVecList)
    } else {
      ## On a single computer
      coarseVec <- snowPDivTPerRiskyBondIntFunc(
                  c(1:dim(coarseStateGrid)[1]),
                  coarseStateGrid,
                  Equity,
                  EquityCoarse,
                  TPerRiskyBondPDiv[[ii-1]],
                  countryToUse,
                  PDivTPerRiskyBondIntFunc)
    }
    ## Interpolation onto fine grid
    fineVec <- InterpolOnFineGrid(coarseVec,
                    cutOff,
                    controlVarNAPi,
                    fineStateGridList,
                    coarseStateGridList)

    TPerRiskyBondPDivCoarse[[ii]] <- coarseVec
    TPerRiskyBondPDiv[[ii]] <- fineVec

    timer2  <- proc.time()[3] - timer2
    if (printStuff) {
      cat('   Time to compute P-D ratio for ',
        ii,'-period risky bond:', timer2, '\n')
    }
  }

  if (printStuff) {
    cat('   Total Time TPerRiskyBondPDiv:',
        proc.time()[3] - timer1, '\n\n')
  }

  save(TPerRiskyBondPDiv,TPerRiskyBondPDivCoarse,
    file = file.path(outDir,
      paste(c('TPerRiskyBondPDiv',GlobalCountryName,'Rda'),
      collapse = '.')))

  rm("TPerRiskyBondPDivCoarse","TPerRiskyBondPDiv","coarseVec","fineVec")
  }

  ##############################################################################
  ## Compute:
  ##  - Shock Exposure Elasticity (SEE)
  ##  - Shock Cost Elasticity (SCE)
  ##############################################################################
  if (controlVarNAPi$getSEEeps==1) ComputeSEEAtEveryPoint('SEEeps')

  if (controlVarNAPi$getSEEepsW==1) ComputeSEEAtEveryPoint('SEEepsW')

  if (controlVarNAPi$getSEEomega==1) ComputeSEEAtEveryPoint('SEEomega')

  if (controlVarNAPi$getSEEomegaW==1) ComputeSEEAtEveryPoint('SEEomegaW')

  if (controlVarNAPi$getSCEeps==1) ComputeSCEAtEveryPoint('SCEeps')

  if (controlVarNAPi$getSCEepsW==1) ComputeSCEAtEveryPoint('SCEepsW')

  if (controlVarNAPi$getSCEomega==1) ComputeSCEAtEveryPoint('SCEomega')

  if (controlVarNAPi$getSCEomegaW==1) ComputeSCEAtEveryPoint('SCEomegaW')

  # close cluster
  if (GlobalUseSnow == 1){
  stopCluster(cl)
  }
}

## Interpolate functions from coarseGrid to fineGrid
InterpolOnFineGrid <- function(coarsePDivVec,
                      cutOff,
                      controlVarNAPi,
                      fineStateGridList,
                      coarseStateGridList)
{
  # This function interpolates price-dividend ratio
  # function from coarse grid on fine grid
  nCoarseStateGridNu       <- controlVarNAPi$nCoarseStateGridNu
  nCoarseStateGridXX       <- controlVarNAPi$nCoarseStateGridXX
  nCoarseStateGridSigmaSq  <- controlVarNAPi$nCoarseStateGridSigmaSq
  nCoarseStateGridXXW      <- controlVarNAPi$nCoarseStateGridXXW
  nCoarseStateGridSigmaSqW <- controlVarNAPi$nCoarseStateGridSigmaSqW

  nFineStateGridNu         <- controlVarNAPi$nFineStateGridNu
  nFineStateGridXX         <- controlVarNAPi$nFineStateGridXX
  nFineStateGridSigmaSq    <- controlVarNAPi$nFineStateGridSigmaSq
  nFineStateGridXXW        <- controlVarNAPi$nFineStateGridXXW
  nFineStateGridSigmaSqW   <- controlVarNAPi$nFineStateGridSigmaSqW

  fineGridNu               <- fineStateGridList$gridNu
  fineGridXX               <- fineStateGridList$gridXX
  fineGridSigmaSq          <- fineStateGridList$gridSigmaSq
  fineGridXXW              <- fineStateGridList$gridXXW
  fineGridSigmaSqW         <- fineStateGridList$gridSigmaSqW

  coarseGridNu             <- coarseStateGridList$gridNu
  coarseGridXX             <- coarseStateGridList$gridXX
  coarseGridSigmaSq        <- coarseStateGridList$gridSigmaSq
  coarseGridXXW            <- coarseStateGridList$gridXXW
  coarseGridSigmaSqW       <- coarseStateGridList$gridSigmaSqW

  # Initialize variables
  PDivOnFineNuGrid                     <- array(0,c(nFineStateGridNu,
                                              nCoarseStateGridXX,
                                              nCoarseStateGridSigmaSq,
                                              nCoarseStateGridXXW,
                                              nCoarseStateGridSigmaSqW))
  PDivOnFineNuXXGrid                   <- array(0,c(nFineStateGridNu,
                                              nFineStateGridXX,
                                              nCoarseStateGridSigmaSq,
                                              nCoarseStateGridXXW,
                                              nCoarseStateGridSigmaSqW))
  PDivOnFineNuXXSigmaSqGrid            <- array(0,c(nFineStateGridNu,
                                              nFineStateGridXX,
                                              nFineStateGridSigmaSq,
                                              nCoarseStateGridXXW,
                                              nCoarseStateGridSigmaSqW))
  PDivOnFineNuXXSigmaSqXXWGrid         <- array(0,c(nFineStateGridNu,
                                              nFineStateGridXX,
                                              nFineStateGridSigmaSq,
                                              nFineStateGridXXW,
                                              nCoarseStateGridSigmaSqW))
  PDivOnFineNuXXSigmaSqXXWSigmaSqWGrid <- array(0,c(nFineStateGridNu,
                                              nFineStateGridXX,
                                              nFineStateGridSigmaSq,
                                              nFineStateGridXXW,
                                              nFineStateGridSigmaSqW))

  # Initialize
  fineGridSigmaSqCoarseGridSigmaSqWIndexes <-
    matrix(FALSE,nCoarseStateGridSigmaSqW,nFineStateGridSigmaSq)
  fineGridSigmaSqFineGridSigmaSqWIndexes   <-
    matrix(FALSE,nFineStateGridSigmaSqW,nFineStateGridSigmaSq)

  coarsePDivMatrix <- array(coarsePDivVec,
                c(nCoarseStateGridNu,
                nCoarseStateGridXX,
                nCoarseStateGridSigmaSq,
                nCoarseStateGridXXW,
                nCoarseStateGridSigmaSqW))
  # Interpolate over Nu
  if (nFineStateGridNu == 1){
    PDivOnFineNuGrid[1,,,,] <- coarsePDivMatrix[1,,,,]
  } else{
    for (iiXX in 1:nCoarseStateGridXX){
      for (iiSigmaSq in 1:nCoarseStateGridSigmaSq){
        for (iiXXW in 1:nCoarseStateGridXXW){
          for (iiSigmaSqW in 1:nCoarseStateGridSigmaSqW){
            if (coarseGridSigmaSq[iiSigmaSq] + coarseGridSigmaSqW[iiSigmaSqW] >= cutOff){
              ff <- approxfun(coarseGridNu,
                        coarsePDivMatrix[,iiXX,iiSigmaSq,iiXXW,iiSigmaSqW])
              PDivOnFineNuGrid[,iiXX,iiSigmaSq,iiXXW,iiSigmaSqW] <- ff(fineGridNu)
            }
          }
        }
      }
    }
  }
  # Interpolate over XX
  if (nFineStateGridXX == 1){
    PDivOnFineNuXXGrid[,1,,,] <- PDivOnFineNuGrid[,1,,,]
  } else {
    for (iiNu in 1:nFineStateGridNu){
      for (iiSigmaSq in 1:nCoarseStateGridSigmaSq){
        for (iiXXW in 1:nCoarseStateGridXXW){
          for (iiSigmaSqW in 1:nCoarseStateGridSigmaSqW){
            if (coarseGridSigmaSq[iiSigmaSq] + coarseGridSigmaSqW[iiSigmaSqW] >= cutOff){
              ff <- approxfun(coarseGridXX,
                            PDivOnFineNuGrid[iiNu,,iiSigmaSq,iiXXW,iiSigmaSqW])
              PDivOnFineNuXXGrid[iiNu,,iiSigmaSq,iiXXW,iiSigmaSqW] <-
                ff(fineGridXX)
            }
          }
        }
      }
    }
  }
  # Interpolate over SigmaSq
  if (nFineStateGridSigmaSq == 1){
    PDivOnFineNuXXSigmaSqGrid[,,1,,] <- PDivOnFineNuXXGrid[,,1,,]
    for (iiSigmaSqW in 1:nCoarseStateGridSigmaSqW){
    coarseGridSigmaSqIndexes <-
      (coarseGridSigmaSq + coarseGridSigmaSqW[iiSigmaSqW] >= cutOff)
    fineGridSigmaSqCoarseGridSigmaSqWIndexes[iiSigmaSqW,] <-
      (fineGridSigmaSq >= min(coarseGridSigmaSq[coarseGridSigmaSqIndexes]))
    }
  } else {
    for (iiNu in 1:nFineStateGridNu){
    for (iiXX in 1:nFineStateGridXX){
      for (iiXXW in 1:nCoarseStateGridXXW){
      for (iiSigmaSqW in 1:nCoarseStateGridSigmaSqW){
        coarseGridSigmaSqIndexes <-
        (coarseGridSigmaSq + coarseGridSigmaSqW[iiSigmaSqW] >= cutOff)
        fineGridSigmaSqCoarseGridSigmaSqWIndexes[iiSigmaSqW,] <-
        (fineGridSigmaSq + coarseGridSigmaSqW[iiSigmaSqW] >= cutOff)
        if (sum(coarseGridSigmaSqIndexes) == 1){
        PDivOnFineNuXXSigmaSqGrid[iiNu,iiXX,,iiXXW,iiSigmaSqW] <-
          PDivOnFineNuXXGrid[iiNu,
                   iiXX,
                   coarseGridSigmaSqIndexes,
                   iiXXW,
                   iiSigmaSqW]
        } else {
        AE <- approxExtrap(
            coarseGridSigmaSq[coarseGridSigmaSqIndexes],
            PDivOnFineNuXXGrid[iiNu,
                      iiXX,
                      coarseGridSigmaSqIndexes,
                      iiXXW,
                      iiSigmaSqW],
            fineGridSigmaSq)
        PDivOnFineNuXXSigmaSqGrid[iiNu,iiXX,,iiXXW,iiSigmaSqW] <- AE$y
        }
      }
      }
    }
    }
  }
  # Interpolate over XXW
  if (nFineStateGridXXW == 1){
    PDivOnFineNuXXSigmaSqXXWGrid[,,,1,] <- PDivOnFineNuXXSigmaSqGrid[,,,1,]
  } else {
    for (iiNu in 1:nFineStateGridNu){
    for (iiXX in 1:nFineStateGridXX){
      for (iiSigmaSq in 1:nFineStateGridSigmaSq){
      for (iiSigmaSqW in 1:nCoarseStateGridSigmaSqW){
        ff <- approxfun(coarseGridXXW,
          PDivOnFineNuXXSigmaSqGrid[iiNu,iiXX,iiSigmaSq,,iiSigmaSqW])
        PDivOnFineNuXXSigmaSqXXWGrid[iiNu,iiXX,iiSigmaSq,,iiSigmaSqW] <-
          ff(fineGridXXW)
      }
      }
    }
    }
  }
  # Interpolate over sigmaSqW
  if (nFineStateGridSigmaSqW == 1){
    PDivOnFineNuXXSigmaSqXXWSigmaSqWGrid[,,,,1] <-
    PDivOnFineNuXXSigmaSqXXWGrid[,,,,1]
  } else {
    for (iiNu in 1:nFineStateGridNu){
    for (iiXX in 1:nFineStateGridXX){
      for (iiSigmaSq in 1:nFineStateGridSigmaSq){
      for (iiXXW in 1:nFineStateGridXXW){
        coarseGridSigmaSqWIndexes <-
        fineGridSigmaSqCoarseGridSigmaSqWIndexes[,iiSigmaSq]
        if (sum(coarseGridSigmaSqWIndexes) == 1){
        PDivOnFineNuXXSigmaSqXXWSigmaSqWGrid[iiNu,iiXX,iiSigmaSq,iiXXW,] <-
          PDivOnFineNuXXSigmaSqXXWGrid[iiNu,
                         iiXX,
                         iiSigmaSq,
                         iiXXW,
                         coarseGridSigmaSqWIndexes]
        }
        if (sum(coarseGridSigmaSqWIndexes) == 0){
        PDivOnFineNuXXSigmaSqXXWSigmaSqWGrid[iiNu,iiXX,iiSigmaSq,iiXXW,] <-
          NaN
        }
        if (sum(coarseGridSigmaSqWIndexes) > 1) {
        fineGridSigmaSqWIndexes <-
          (fineGridSigmaSqW >= min(coarseGridSigmaSqW[coarseGridSigmaSqWIndexes]))
        AE <- approxExtrap(
            coarseGridSigmaSqW[coarseGridSigmaSqWIndexes],
            PDivOnFineNuXXSigmaSqXXWGrid[iiNu,
                          iiXX,
                          iiSigmaSq,
                          iiXXW,
                          coarseGridSigmaSqWIndexes],
            fineGridSigmaSqW)
        PDivOnFineNuXXSigmaSqXXWSigmaSqWGrid[iiNu,iiXX,iiSigmaSq,iiXXW,] <-
          AE$y
        }
      }
      }
    }
    }
  }
  return(as.vector(PDivOnFineNuXXSigmaSqXXWSigmaSqWGrid))
}

calcReturns <- function(countryToUse,
                      simOutput,
                      simOutputOnGrid,
                      PDivs,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo,
                      printTime = 1)
{
  # Calculates returns on equity using simulated data from model

  timer1        <- proc.time()[3]

  stateGridList <- createFineStateGrid(countryToUse,
                    controlVarNAPi,
                    ParEst,
                    UnobsPosInfo)

  gridNu        <- stateGridList$gridNu
  gridXX        <- stateGridList$gridXX
  gridSigmaSq   <- stateGridList$gridSigmaSq
  gridXXW       <- stateGridList$gridXXW
  gridSigmaSqW  <- stateGridList$gridSigmaSqW

  nGridNu       <- length(gridNu)
  nGridXX       <- length(gridXX)
  nGridSigmaSq  <- length(gridSigmaSq)
  nGridXXW      <- length(gridXXW)
  nGridSigmaSqW <- length(gridSigmaSqW)

  gammaU        <- controlVarNAPi$gammaU # Risk-Aversion
  psiU          <- controlVarNAPi$psiU # Intertemporal Elasticity of Substitution
  rhoU          <- controlVarNAPi$rhoU # Discount Rate
  thetaU        <- controlVarNAPi$thetaU

  payGrowth     <- controlVarNAPi$payGrowth

  sigmaSqOmega  <- ParEst[bigDataPosInfo$sigmaSqOmega]
  sigmaSqOmegaW <- ParEst[bigDataPosInfo$sigmaSqOmegaW]
  gammma        <- ParEst[bigDataPosInfo$gammma]
  rho           <- ParEst[bigDataPosInfo$rho]
  rhoW          <- ParEst[bigDataPosInfo$rhoW]
  xi            <- ParEst[bigDataPosInfo$xi][countryToUse]
  lambda        <- ParEst[bigDataPosInfo$lambda]
  lambdaW       <- ParEst[bigDataPosInfo$lambdaW]
  mu            <- ParEst[bigDataPosInfo$mu][countryToUse]
  chiSq         <- ParEst[bigDataPosInfo$chiSq][countryToUse]
  chiSqW        <- ParEst[bigDataPosInfo$chiSqW]
  sigmaSqNu     <- ParEst[bigDataPosInfo$sigmaSqNu][countryToUse]
  sigmaSqConst  <- ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW <- ParEst[bigDataPosInfo$sigmaSqConstW]

  CCwithBreak   <- simOutput$CCwithBreak
  CC            <- simOutput$CC
  DD            <- simOutput$DD
  Nu            <- simOutputOnGrid$Nu
  XX            <- simOutputOnGrid$XX
  XXW           <- simOutputOnGrid$XXW
  SigmaSq       <- simOutputOnGrid$SigmaSq
  SigmaSqW      <- simOutputOnGrid$SigmaSqW

  nSim <- length(CC)

  getCurPos <- function(Nu, XX, SigmaSq, XXW, SigmaSqW)
  {
    curNu       <- which(Nu[1]       == gridNu)
    curXX       <- which(XX[1]       == gridXX)
    curSigmaSq  <- which(SigmaSq[1]  == gridSigmaSq)
    curXXW      <- which(XXW[1]      == gridXXW)
    curSigmaSqW <- which(SigmaSqW[1] == gridSigmaSqW)
    curPos      <- ((curSigmaSqW - 1) * nGridXXW * nGridSigmaSq * nGridXX * nGridNu +
                      (curXXW-1) * nGridSigmaSq * nGridXX * nGridNu +
                           (curSigmaSq-1) * nGridXX * nGridNu +
                                  (curXX - 1) * nGridNu +
                                          curNu)
    return(curPos)
  }

  ## Initialize
  REq <- PDivEq <- CGrowth <- DGrowth<- numeric(nSim)

  PDivEqOld <- exp(PDivs$Equity[getCurPos(Nu[1],
                      XX[1],
                      SigmaSq[1],
                      XXW[1],
                      SigmaSqW[1])])
  PDivEq[1] <- PDivEqOld

  CGrowth[1] <- NA
  DGrowth[1] <- NA

  CGrowthWithBreak   <- c(NA,exp(diff(CCwithBreak)))

  if (controlVarNAPi$getOnePerBond == 1) {
    RBond          <- numeric(nSim)
    PDivBond       <- numeric(nSim)
    PDivBondOld    <- exp(PDivs$OnePerBond[getCurPos(Nu[1],
                            XX[1],
                            SigmaSq[1],
                            XXW[1],
                            SigmaSqW[1])])
    PDivBond[1]    <- PDivBondOld
  }
  if (controlVarNAPi$getPerpetuity == 1) {
    RPerp <- PDivPerp <- numeric(nSim)
    PDivPerpOld    <- exp(PDivs$Perpetuity[getCurPos(Nu[1],
                            XX[1],
                            SigmaSq[1],
                            XXW[1],
                            SigmaSqW[1])])
    PDivPerp[1]    <- PDivPerpOld
  }
  if (controlVarNAPi$getLeveredXXEq == 1) {
    RLeveredXXEq <- PDivLeveredXXEq <- numeric(nSim)
    PDivLeveredXXEqOld <- exp(PDivs$LeveredXXEq[getCurPos(Nu[1],
                              XX[1],
                              SigmaSq[1],
                              XXW[1],
                              SigmaSqW[1])])
    PDivLeveredXXEq[1] <- PDivLeveredXXEqOld
  }
  for (ii in 2:nSim) {
    PDivEqCur        <- exp(PDivs$Equity[getCurPos(Nu[ii],
                          XX[ii],
                          SigmaSq[ii],
                          XXW[ii],
                          SigmaSqW[ii])])

    REq[ii]     <- exp(CC[ii] - CC[ii-1])*PDivEqOld^(-1)*(1+PDivEqCur)
    PDivEq[ii]  <- PDivEqCur
    PDivEqOld   <- PDivEqCur
    CGrowth[ii] <- exp(CC[ii] - CC[ii-1])
    DGrowth[ii] <- exp(DD[ii] - DD[ii-1])

    if (controlVarNAPi$getOnePerBond == 1) {
    PDivBondCur  <- exp(PDivs$OnePerBond[getCurPos(Nu[ii],
                            XX[ii],
                            SigmaSq[ii],
                            XXW[ii],
                            SigmaSqW[ii])])
    RBond[ii]    <- PDivBondOld^(-1)
    PDivBond[ii] <- PDivBondCur
    PDivBondOld  <- PDivBondCur
    }
    if (controlVarNAPi$getPerpetuity == 1) {
    PDivPerpCur  <- exp(PDivs$Perpetuity[getCurPos(Nu[ii],
                            XX[ii],
                            SigmaSq[ii],
                            XXW[ii],
                            SigmaSqW[ii])])
    RPerp[ii]    <- payGrowth*PDivPerpOld^(-1)*(1+PDivPerpCur)
    PDivPerp[ii] <- PDivPerpCur
    PDivPerpOld  <- PDivPerpCur
    }
    if (controlVarNAPi$getLeveredXXEquity == 1) {
    PDivLeveredXXEqCur  <- exp(PDivs$LeveredXXEq[getCurPos(Nu[ii],
                                XX[ii],
                                SigmaSq[ii],
                                XXW[ii],
                                SigmaSqW[ii])])
    RLeveredXXEq[ii]  <- exp(DD[ii] - DD[ii-1])*
                PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEqCur)
    PDivLeveredXXEq[ii] <- PDivLeveredXXEqCur
    PDivLeveredXXEqOld  <- PDivLeveredXXEqCur
    }
  }

  output <- list(Equity           = list(Return = c(NA,REq[2:length(REq)]),
                       PDiv   = PDivEq),
           CGrowth          = CGrowth,
           CGrowthWithBreak = CGrowthWithBreak,
           DGrowth          = DGrowth)

  if (controlVarNAPi$getOnePerBond == 1) {
    output$OnePerBond  <- list(Return = c(NA,RBond[2:length(RBond)]),
                   PDiv   = PDivBond)
  }
  if (controlVarNAPi$getPerpetuity == 1) {
    output$Perpetuity  <- list(Return = c(NA,RPerp[2:length(RPerp)]),
                   PDiv   = PDivPerp)
  }
  if (controlVarNAPi$getLeveredXXEq == 1) {
    output$LeveredXXEq <- list(Return = c(NA,RLeveredXXEq[2:length(RLeveredXXEq)]),
                   PDiv   = PDivLeveredXXEq)
  }
  timer1 <- proc.time()[3] - timer1
  if (printTime) {
    cat('Time Calc Returns:   ',timer1,'\n')
  }
  return(output)
}

simulateGlobal_EZW <- function(controlVarNAPi,
                      ParEstimates,
                      UnobsPosInfo,
                      nSim,
                      nSimBurnin,
                      printStuff = 1)
{
  ## Simulate the Model
  ############################
  timer1     <- proc.time()[3]
  simOutput  <- list(NULL)
  #Get parameters
  cutOffW    <- controlVarNAPi$cutOffW
  paramNames <- c("rhoW",
          "gammma",
          "lambdaW",
          "chiSqW",
          "sigmaSqConstW",
          "sigmaSqOmegaW")
  for (ii in 1:length(paramNames)) {
    eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
    eval(parse(text = paste('simOutput$',paramNames[ii],'<-',paramNames[ii], sep='')))
  }
  if (controlVarNAPi$nCoarseStateGridSigmaSqW == 1){
    sigmaSqOmegaW <- 0
  }
  sigmaOmegaW <- sqrt(sigmaSqOmegaW)
  sigmaConstW <- sqrt(sigmaSqConstW)
  chiW        <- sqrt(chiSqW)
  # Initialize variables
  XXW         <- numeric(nSim+nSimBurnin)
  EpsW        <- numeric(nSim+nSimBurnin)
  EtaW        <- numeric(nSim+nSimBurnin)
  OmegaW      <- numeric(nSim+nSimBurnin)
  SigmaSqW    <- numeric(nSim+nSimBurnin)
  ## Set initial values
  SigmaSqW[1] <- max(sigmaSqConstW + OmegaW[1],cutOffW)
  XXW[1]      <- rnorm(1,0,sqrt(sigmaSqConstW/(1-rhoW^2)))

  ## Simulate model
  for (ii in 2:(nSim+nSimBurnin)) {
    omegaWEpsW   <- rmvnorm(1, mean = c(0,0), sigma = matrix(c(sigmaOmegaW^2,lambdaW*sigmaOmegaW*sqrt(SigmaSqW[ii-1]),lambdaW*sigmaOmegaW*sqrt(SigmaSqW[ii-1]),SigmaSqW[ii-1]),2,2))
    OmegaW[ii]   <- omegaWEpsW[1]
    EpsW[ii]     <- omegaWEpsW[2]
    SigmaSqW[ii] <- max(sigmaSqConstW + gammma * (SigmaSqW[ii-1] - sigmaSqConstW) + OmegaW[ii],cutOffW)
    EtaW[ii]     <- rnorm(1,0,sqrt(chiSqW*SigmaSqW[ii-1]))
    XXW[ii]      <- rhoW * XXW[ii-1] + EpsW[ii]
  }

  timer1 <- proc.time()[3] - timer1
  if (printStuff) {
    cat('nSim:                  ',nSim,'\n')
    cat('time simulation =      ',timer1,'\n')
  }

  simOutput$OmegaW   <- OmegaW
  simOutput$EpsW     <- EpsW
  simOutput$XXW      <- XXW
  simOutput$EtaW     <- EtaW
  simOutput$SigmaSqW <- SigmaSqW

  return(simOutput)
}

## Simulate prices and returns
################################################################################
simulateModel_EZW <- function(countryToUse,
                      controlVarNAPi,
                      ParEstimates,
                      UnobsPosInfo,
                      simGlobalOutput,
                      nSim,
                      nSimBurnin,
                      printStuff = 1)
{
  timer1     <- proc.time()[3]
  simOutput  <- list(NULL)

  #Get parameters
  paramNames <- c("mu",
          "rho",
          "rhoW",
          "gammma",
          "lambda",
          "xi",
          "sigmaSqConst",
          "sigmaSqConstW",
          "chiSq",
          "chiSqW",
          "sigmaSqNu",
          "sigmaSqNuPre",
          "sigmaSqOmega")

  for (ii in 1:length(paramNames)) {
    eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
    eval(parse(text = paste('simOutput$',paramNames[ii],'<-',paramNames[ii], sep='')))
  }

  cutOff       <- controlVarNAPi$cutOff
  cutOffW      <- controlVarNAPi$cutOffW
  phi          <- controlVarNAPi$phi
  if (controlVarNAPi$nCoarseStateGridSigmaSq  == 1) sigmaSqOmega  <- 0
  if (controlVarNAPi$nCoarseStateGridSigmaSqW == 1) sigmaSqOmegaW <- 0
  xi           <- xi[countryToUse]
  chiSq        <- chiSq[countryToUse]
  sigmaNu      <- sqrt(sigmaSqNu[countryToUse])
  sigmaNuPre   <- sqrt(sigmaSqNuPre[countryToUse])
  sigmaOmega   <- sqrt(sigmaSqOmega)
  sigmaSqConst <- sigmaSqConst[countryToUse]
  # Initialize variables
  XX           <- numeric(nSim+nSimBurnin)
  Eps          <- numeric(nSim+nSimBurnin)
  CC           <- numeric(nSim+nSimBurnin)
  YY           <- numeric(nSim+nSimBurnin)
  DD           <- numeric(nSim+nSimBurnin)
  Eta          <- numeric(nSim+nSimBurnin)
  EtaW         <- numeric(nSim+nSimBurnin)
  Nu           <- numeric(nSim+nSimBurnin)
  Omega        <- numeric(nSim+nSimBurnin)
  SigmaSq      <- numeric(nSim+nSimBurnin)

  XXW          <- simGlobalOutput$XXW
  EtaW         <- simGlobalOutput$EtaW
  EpsW         <- simGlobalOutput$EpsW
  OmegaW       <- simGlobalOutput$OmegaW
  SigmaSqW     <- simGlobalOutput$SigmaSqW
  ## Set initial values
  SigmaSq[1]   <- max(sigmaSqConst + Omega[1],cutOff - SigmaSqW[1])
  XX[1]        <- rnorm(1,0,sqrt(sigmaSqConst/(1-rho^2) + sigmaSqConstW/(1-rhoW^2)))
  YY[1]        <- 0
  DD[1]        <- 0
  ## Simulate model
  for (ii in 2:(nSim+nSimBurnin)) {
    omegaEps     <- rmvnorm(1, mean = c(0,0), sigma = matrix(c(sigmaOmega^2,lambda*sigmaOmega*sqrt(SigmaSq[ii-1] + SigmaSqW[ii-1]),lambda*sigmaOmega*sqrt(SigmaSq[ii-1] + SigmaSqW[ii-1]),(SigmaSq[ii-1] + SigmaSqW[ii-1])),2,2))
    Omega[ii]    <- omegaEps[1]
    Eps[ii]      <- omegaEps[2]
    SigmaSq[ii]  <- max(sigmaSqConst  + gammma * (SigmaSq[ii-1]  - sigmaSqConst)  + Omega[ii],cutOff - SigmaSqW[ii])
    Eta[ii]      <- rnorm(1,0,sqrt(chiSq*(SigmaSq[ii-1] + SigmaSqW[ii-1])))
    #EtaW[ii]     <- rnorm(1,0,sqrt(chiSqW*SigmaSqW[ii-1]))
    XX[ii]       <- rho  * XX[ii-1]  + Eps[ii]
    YY[ii]       <- YY[ii-1] + mu[countryToUse] + XX[ii-1] + xi*XXW[ii-1] + Eta[ii] + xi*EtaW[ii]
    DD[ii]       <- DD[ii-1] + mu[countryToUse] + phi * (XX[ii-1] + xi*XXW[ii-1] + Eta[ii] + xi*EtaW[ii])
  }
  Nu                    <- rnorm(nSim+nSimBurnin,0,sigmaNu)
  NuWithBreak           <- c(rnorm(round(56/120*(nSim+nSimBurnin)),0,sigmaNuPre),rnorm(nSim+nSimBurnin - round(56/120*(nSim+nSimBurnin)),0,sigmaNu))

  CC                    <- YY + Nu
  CCwithBreak           <- YY + NuWithBreak

  simOutput$Eps         <- Eps[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$EpsW        <- EpsW[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$Eta         <- Eta[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$EtaW        <- EtaW[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$Nu          <- Nu[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$Omega       <- Omega[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$OmegaW      <- OmegaW[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$XX          <- XX[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$XXW         <- XXW[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$SigmaSq     <- SigmaSq[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$SigmaSqW    <- SigmaSqW[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$CC          <- CC[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$CCwithBreak <- CCwithBreak[(nSimBurnin+1):(nSim+nSimBurnin)]
  simOutput$DD          <- DD[(nSimBurnin+1):(nSim+nSimBurnin)]

  timer1 <- proc.time()[3] - timer1
  if (printStuff) {
    cat('nSim:                  ',nSim,'\n')
    cat('time simulation =      ',timer1,'\n')
  }
  return(simOutput)
}

## Put simulation on the grid
################################################################################
putSimOutputOnStateGrid         <- function(countryToUse,
                      simOutput,
                      controlVarNAPi,
                      ParEst,
                      UnobsPosInfo,
                      printTime = 1)
{
  ## Put Simulated Output on Grid
  ##################################
  timer1                   <- proc.time()[3]

  cutOff                   <- controlVarNAPi$cutOff
  cutOffW                  <- controlVarNAPi$cutOffW
  xi                       <- ParEst[bigDataPosInfo$xi][countryToUse]
  XX                       <- simOutput$XX
  XXW                      <- simOutput$XXW
  Nu                       <- simOutput$Nu
  SigmaSq                  <- simOutput$SigmaSq
  SigmaSqW                 <- simOutput$SigmaSqW
  nSim                     <- length(XX)

  NuOnFineGrid             <- numeric(nSim)
  XXOnFineGrid             <- numeric(nSim)
  XXWOnFineGrid            <- numeric(nSim)
  SigmaSqOnFineGrid        <- numeric(nSim)
  SigmaSqWOnFineGrid       <- numeric(nSim)

  fineStateGridList        <- createFineStateGrid(countryToUse,  controlVarNAPi, ParEst, UnobsPosInfo)
  coarseStateGridList      <- createCoarseStateGrid(countryToUse,controlVarNAPi, ParEst, UnobsPosInfo)

  fineStateGridNu          <- fineStateGridList$gridNu
  fineStateGridXX          <- fineStateGridList$gridXX
  fineStateGridXXW         <- fineStateGridList$gridXXW
  fineStateGridSigmaSq     <- fineStateGridList$gridSigmaSq
  fineStateGridSigmaSqW    <- fineStateGridList$gridSigmaSqW

  nFineStateGridNu         <- length(fineStateGridNu)
  nFineStateGridXX         <- length(fineStateGridXX)
  nFineStateGridXXW        <- length(fineStateGridXXW)
  nFineStateGridSigmaSq    <- length(fineStateGridSigmaSq)
  nFineStateGridSigmaSqW   <- length(fineStateGridSigmaSqW)

  coarseStateGridSigmaSq   <- coarseStateGridList$gridSigmaSq
  coarseStateGridSigmaSqW  <- coarseStateGridList$gridSigmaSqW

  nCoarseStateGridSigmaSq  <- length(coarseStateGridSigmaSq)
  nCoarseStateGridSigmaSqW <- length(coarseStateGridSigmaSqW)

  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes     <- matrix(FALSE,nFineStateGridSigmaSqW  ,nFineStateGridSigmaSq)

  for (iiSigmaSq in (1:nFineStateGridSigmaSq)){
    fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[,iiSigmaSq]   <- (fineStateGridSigmaSq[iiSigmaSq] + fineStateGridSigmaSqW >= cutOff)
  }

  for (ii in 1:nSim) {
    NuInd              <- which.min(abs(fineStateGridNu-Nu[ii]))
    NuOnFineGrid[ii]   <- fineStateGridNu[NuInd]

    XXInd              <- which.min(abs(fineStateGridXX-XX[ii]))
    XXOnFineGrid[ii]   <- fineStateGridXX[XXInd]

    XXWInd             <- which.min(abs(fineStateGridXXW-XXW[ii]))
    XXWOnFineGrid[ii]  <- fineStateGridXXW[XXWInd]

    SigmaSqInd         <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
    SigmaSqWInd        <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))

    if (fineStateGridSigmaSq[SigmaSqInd] + fineStateGridSigmaSqW[SigmaSqWInd] >= cutOff){
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- fineStateGridSigmaSq[SigmaSqInd]
    } else {
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- min(fineStateGridSigmaSq[fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[SigmaSqWInd,]])
      SigmaSqInd             <- which.min(abs(SigmaSqOnFineGrid[ii] - SigmaSq[ii]))
    }

  }
  timer1 <- proc.time()[3] - timer1
  if (printTime) {
    cat('Time Put Sim on Grid:  ',timer1,'\n')
  }
  return(list(Nu       = NuOnFineGrid,
        XX       = XXOnFineGrid,
        XXW      = XXWOnFineGrid,
        SigmaSq  = SigmaSqOnFineGrid,
        SigmaSqW = SigmaSqWOnFineGrid))
}

## Calculate exchange rate
################################################################################
calcFX <- function(returnsEZWBase,
                      returnsEZW,
                      controlVarNAPi)
{
  # Calculate Return on Equity Using Simulated Data From Model
  #############################################################
  gammaU       <- controlVarNAPi$gammaU # Risk-Aversion
  psiU         <- controlVarNAPi$psiU # Intertemporal Elasticity of Substitution
  rhoU         <- controlVarNAPi$rhoU # Discount Rate
  thetaU       <- controlVarNAPi$thetaU

  returnEqBase <- returnsEZWBase$Equity$Return
  CGrowthBase  <- returnsEZWBase$CGrowth

  returnEq     <- returnsEZW$Equity$Return
  CGrowth      <- returnsEZW$CGrowth

  returnEqBase <- returnEqBase[2:length(returnEqBase)]
  CGrowthBase  <- CGrowthBase[2:length(CGrowthBase)]
  returnEq     <- returnEq[2:length(returnEq)]
  CGrowth      <- CGrowth[2:length(CGrowth)]

  logSDFBase <- - thetaU*rhoU - thetaU/psiU*CGrowthBase +(thetaU-1)*returnEqBase
  logSDF <- - thetaU*rhoU - thetaU/psiU*CGrowth + (thetaU-1)*returnEq

  logFX        <- logSDFBase - logSDF

  output <- list(logFX      = logFX,
           logSDF     = logSDF,
           logSDFBase = logSDFBase)

  return(output)
}

initializeSummaryStatsBigFile <- function(allData,
                      controlVarNAPi)
{

  rowNames <- c("cGrowthMean","cGrowthStd","cGrowthAC1","cGrowthMeanWithBreak",
    "cGrowthStdWithBreak","cGrowthAR1WithBreak","dGrowthMean","dGrowthStd",
    "dGrowthAC1","equityMean","equityStd","onePerBondMean","onePerBondStd",
    "equityPremiumMean","equityPremiumStd","equitySharpRatio",
    "leveredEquityMean","leveredEquityStd","leveredEquityPremiumMean",
    "leveredEquityPremiumStd","leveredEquitySharpRatio","PDequityMean",
    "PDequityStd","PDequityAC1","PDonePerBondMean","PDonePerBondStd",
    "PDonePerBondAC1","PDleveredEquityMean","PDleveredEquityStd",
    "PDleveredEquityAC1")

  summaryStats <- matrix(NA,length(rowNames),1)
  rownames(summaryStats) <- rowNames

  filename <- file.path(outDir,paste('summaryStatsBigFile','.Rda',sep=""))
  save(summaryStats, file = filename)
}

saveSummaryStatsBigFile <- function(allData,
                      countryToUse,
                      returnsAP,
                      controlVarNAPi)
{
  load(file.path(outDir,paste('summaryStatsBigFile','.Rda',sep="")))
  payGrowth <- controlVarNAPi$payGrowth
  nPer      <- length(returnsAP$Equity$Return)
  nRow      <- dim(summaryStats)[1]
  nCol      <- dim(summaryStats)[2]

  if ((nCol == 1) & (sum(!is.na(summaryStats[,1]))==0)){
    curCol <- 1
  } else {
    curCol <- nCol + 1
    # Add new row to summaryStats
    summaryStats <- cbind(summaryStats,matrix(NaN,nRow,1))
  }

  colnames(summaryStats)[curCol] <- allData$countryNames[countryToUse]

  summaryStats["cGrowthMean",curCol] <- mean(log(returnsAP$CGrowth[2:nPer]))
  summaryStats["cGrowthStd",curCol] <- sd(log(returnsAP$CGrowth[2:nPer]))
  summaryStats["cGrowthAC1",curCol] <- cor(log(returnsAP$CGrowth[2:(nPer-1)]),
                                            log(returnsAP$CGrowth[3:nPer]))
  summaryStats["cGrowthMeanWithBreak",curCol] <- 
                                mean(log(returnsAP$CGrowthWithBreak[2:nPer]))
  summaryStats["cGrowthStdWithBreak",curCol] <- 
                                sd(log(returnsAP$CGrowthWithBreak[2:nPer]))
  summaryStats["cGrowthAR1WithBreak",curCol] <- 
                                cor(log(returnsAP$CGrowthWithBreak[2:(nPer-1)]),
                                    log(returnsAP$CGrowthWithBreak[3:nPer]))
  summaryStats["dGrowthMean",curCol] <- mean(log(returnsAP$DGrowth[2:nPer]))
  summaryStats["dGrowthStd",curCol] <- sd(log(returnsAP$DGrowth[2:nPer]))
  summaryStats["dGrowthAC1",curCol] <- cor(log(returnsAP$DGrowth[2:(nPer-1)]),
                                            log(returnsAP$DGrowth[3:nPer]))

  summaryStats["equityMean",curCol] <- mean(returnsAP$Equity$Return[2:nPer])
  summaryStats["equityStd",curCol] <- sd(returnsAP$Equity$Return[2:nPer])
  summaryStats["onePerBondMean",curCol] <- mean(returnsAP$OnePerBond$Return[2:nPer])
  summaryStats["onePerBondStd",curCol] <- sd(returnsAP$OnePerBond$Return[2:nPer])
  summaryStats["equityPremiumMean",curCol] <- 
                                mean(returnsAP$Equity$Return[2:nPer]) - 
                                mean(returnsAP$OnePerBond$Return[2:nPer])
  summaryStats["equityPremiumStd",curCol] <- 
                                sd(returnsAP$Equity$Return[2:nPer] - 
                                  returnsAP$OnePerBond$Return[2:nPer])
  summaryStats["equitySharpRatio",curCol] <- (mean(returnsAP$Equity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$Equity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer])

  summaryStats["leveredEquityMean",curCol] <- mean(returnsAP$LeveredXXEq$Return[2:nPer])
  summaryStats["leveredEquityStd",curCol] <- sd(returnsAP$LeveredXXEq$Return[2:nPer])
  summaryStats["leveredEquityPremiumMean",curCol] <- mean(returnsAP$LeveredXXEq$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer])
  summaryStats["leveredEquityPremiumStd",curCol] <- sd(returnsAP$LeveredXXEq$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer])
  summaryStats["leveredEquitySharpRatio",curCol] <- (mean(returnsAP$LeveredXXEq$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$LeveredXXEq$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer])

  summaryStats["PDequityMean",curCol]             <- mean(log(returnsAP$Equity$PDiv))
  summaryStats["PDequityStd",curCol]              <- sd(log(returnsAP$Equity$PDiv))
  summaryStats["PDequityAC1",curCol]              <- cor(log(returnsAP$Equity$PDiv[1:(nPer-1)]),log(returnsAP$Equity$PDiv[2:nPer]))

  summaryStats["PDonePerBondMean",curCol]         <- mean(log(returnsAP$OnePerBond$PDiv))
  summaryStats["PDonePerBondStd",curCol]          <- sd(log(returnsAP$OnePerBond$PDiv))
  summaryStats["PDonePerBondAC1",curCol]          <- cor(log(returnsAP$OnePerBond$PDiv[2:nPer]),log(returnsAP$OnePerBond$PDiv[1:(nPer-1)]))

  summaryStats["PDleveredEquityMean",curCol]      <- mean(log(returnsAP$LeveredXXEq$PDiv))
  summaryStats["PDleveredEquityStd",curCol]       <- sd(log(returnsAP$LeveredXXEq$PDiv))
  summaryStats["PDleveredEquityAC1",curCol]       <- cor(log(returnsAP$LeveredXXEq$PDiv[1:(nPer-1)]),log(returnsAP$LeveredXXEq$PDiv[2:nPer]))

  filename       <- file.path(outDir,paste('summaryStatsBigFile','.Rda',sep=""))
  save(summaryStats, file = filename)
}

saveSummaryStatsBigFileCSV <- function()
{
  load(file.path(outDir,paste('summaryStatsBigFile','.Rda',sep="")))
  filename <-  file.path(outDir, paste('summaryStatsBigFile','.csv',sep=""))
  write.table(round(summaryStats,5), filename,row.names = T,col.names=NA, sep = ",")
}

printSummaryStats <- function(returnsAP,
                      controlVarNAPi,
                      Pref = 1)
{
  ## Print Results
  if (Pref == 1) {
    Pref <- 'EZW'
  } else if (Pref == 2) {
    Pref <- 'CRRA'
  } else {
    Pref <- ''
  }

  payGrowth <- controlVarNAPi$payGrowth

  options(digits = 5)
  nPer <- length(returnsAP$Equity$Return)

  cat('\n')
  cat('Consumption and Dividend growth\n')
  cat('---------------------------------------\n')
  cat('Consumption: post WWII\n')
  cat('E[  log[C_{t+1}/C_{t}]] = ',mean(log(returnsAP$CGrowth[2:nPer])),'\n')
  cat('std[log[C_{t+1}/C_{t}]] = ',sd(log(returnsAP$CGrowth[2:nPer])),'\n')
  cat('AC1[log[C_{t+1}/C_{t}]] = ',cor(log(returnsAP$CGrowth[2:(nPer-1)]),log(returnsAP$CGrowth[3:nPer])),'\n')
  cat('Consumption: all sample with break\n')
  cat('E[  log[C_{t+1}/C_{t}]] = ',mean(log(returnsAP$CGrowthWithBreak[2:nPer])),'\n')
  cat('std[log[C_{t+1}/C_{t}]] = ',sd(log(returnsAP$CGrowthWithBreak[2:nPer])),'\n')
  cat('AC1[log[C_{t+1}/C_{t}]] = ',cor(log(returnsAP$CGrowthWithBreak[2:(nPer-1)]),log(returnsAP$CGrowthWithBreak[3:nPer])),'\n')
  cat('Dividends: post WWII\n')
  cat('E[log[D_{t+1}/D_{t}]]   = ',mean(log(returnsAP$DGrowth[2:nPer])),'\n')
  cat('std[log[D_{t+1}/D_{t}]] = ',sd(log(returnsAP$DGrowth[2:nPer])),'\n')
  cat('AC1[log[D_{t+1}/D_{t}]] = ',cor(log(returnsAP$DGrowth[2:(nPer-1)]),log(returnsAP$DGrowth[3:nPer])),'\n')

  cat('\n')
  cat('Asset Returns for ',Pref,' Rep Consumer\n')
  cat('---------------------------------------\n')
  cat('Unlevered Equity (nonlinear): \n')
  cat('   E[R]:               ',mean(returnsAP$Equity$Return[2:nPer]),'\n')
  cat('   std[R]:             ',sd(returnsAP$Equity$Return[2:nPer]),'\n')
  if (controlVarNAPi$getOnePerBond == 1) {
    cat('One Per Bond (nonlinear):\n')
    cat('   E[R]:                 ',mean(returnsAP$OnePerBond$Return[2:nPer]),'\n')
    cat('   std[R]:               ',sd(returnsAP$OnePerBond$Return[2:nPer]),'\n')
    cat('Unlevered Equity Premium (nonlinear):\n')
    cat('   E[R - Rf]:            ',mean(returnsAP$Equity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]),'\n')
    cat('   std(R - Rf):          ',sd(returnsAP$Equity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
    cat('   E[R - Rf]/std(R - Rf):',(mean(returnsAP$Equity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$Equity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
  }
  if (controlVarNAPi$getLeveredXXEq == 1) {
    cat('Levered XX Equity (nonlinear):\n')
    cat('   E[R]:                 ',mean(returnsAP$LeveredXXEq$Return[2:nPer]),'\n')
    cat('   std[R]:               ',sd(returnsAP$LeveredXXEq$Return[2:nPer]),'\n')
    cat('Levered XX Equity Premium (nonlinear): \n')
    cat('   E[R - Rf]:            ',mean(returnsAP$LeveredXXEq$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]),'\n')
    cat('   std(R - Rf):          ',sd(returnsAP$LeveredXXEq$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
    cat('   E[R - Rf]/std(R - Rf):',(mean(returnsAP$LeveredXXEq$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$LeveredXXEq$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
  }
  if (controlVarNAPi$getPerpetuity == 1) {
    cat('Perpetuity (nonlinear):\n')
    cat('   E[R]:                 ',mean(returnsAP$Perpetuity$Return[2:nPer]),'\n')
    cat('   std[R]:               ',sd(returnsAP$Perpetuity$Return[2:nPer]),'\n')
    cat('Perpetuity Term Premium (nonlinear): \n')
    cat('   E[R - Rf]:            ',mean(returnsAP$Perpetuity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]),'\n')
    cat('   std(R - Rf):          ',sd(returnsAP$Perpetuity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
    cat('   E[R - Rf]/std(R - Rf):',(mean(returnsAP$Perpetuity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$Perpetuity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
  }


  cat('\n')
  cat('Price-Dividend Ratios for ',Pref,' Rep Consumer\n')
  cat('-----------------------------------------------------------\n')
  cat('Unlevered Equity (nonlinear):\n')
  cat('   E[Log[P/Div]]:           ',mean(log(returnsAP$Equity$PDiv)),'\n')
  cat('   Std[log[P/Div]]:         ',sd(log(returnsAP$Equity$PDiv)),'\n')
  cat('   AC1[log[P/Div]]:         ',cor(log(returnsAP$Equity$PDiv[1:(nPer-1)]),log(returnsAP$Equity$PDiv[2:nPer])),'\n')

  if (controlVarNAPi$getOnePerBond == 1) {
    cat('One Per Bond (nonlinear):\n')
    cat('   E[log[P/Div]]:          ',mean(log(returnsAP$OnePerBond$PDiv)),'\n')
    cat('   std[log[P/Div]]:        ',sd(log(returnsAP$OnePerBond$PDiv)),'\n')
    cat('   AC1[log[P/Div]]:        ',cor(log(returnsAP$OnePerBond$PDiv[2:nPer]),log(returnsAP$OnePerBond$PDiv[1:(nPer-1)])),'\n')
  }
  if (controlVarNAPi$getLeveredXXEq == 1) {
    cat('Levered XX equity (nonlinear):\n')
    cat('   E[Log[P/Div]]:          ',mean(log(returnsAP$LeveredXXEq$PDiv)),'\n')
    cat('   std[Log[P/Div]]:        ',sd(log(returnsAP$LeveredXXEq$PDiv)),'\n')
    cat('   AC1[Log[P/Div]]:        ',cor(log(returnsAP$LeveredXXEq$PDiv[1:(nPer-1)]),log(returnsAP$LeveredXXEq$PDiv[2:nPer])),'\n')
  }
  if (controlVarNAPi$getPerpetuity == 1) {
    cat('Perpetuity (nonlinear):\n')
    cat('   E[Log[P/Div]]:          ',mean(log(returnsAP$Perpetuity$PDiv)),'\n')
    cat('   std[Log[P/Div]]:        ',sd(log(returnsAP$Perpetuity$PDiv)),'\n')
    cat('   AC1[Log[P/Div]]:        ',cor(log(returnsAP$Perpetuity$PDiv[1:(nPer-1)]),log(returnsAP$Perpetuity$PDiv[2:nPer])),'\n')
  }
}

printSummaryStatsFX <- function(outputFX,
                      countryToUse,
                      controlVarNAPi,
                      allData,
                      Pref = 1)
{
  if (Pref == 1) {
    Pref <- 'EZW'
  } else if (Pref == 2) {
    Pref <- 'CRRA'
  } else {
    Pref <- ''
  }

  options(digits = 5)
  nPer <- length(outputFX$logFX)

  cat('\n')
  cat('FX between ',allData$countryNames[countryToUse],' and ',allData$countryNames[controlVarNAPi$baseCountry],'\n')
  cat('---------------------------------------\n')
  cat('E[  log[FX]] = ',mean(outputFX$logFX),'\n')
  cat('std[log[FX]] = ',sd(outputFX$logFX),'\n')
  cat('AC1[log[FX]] = ',cor(outputFX$logFX[2:(nPer-1)],outputFX$logFX[3:nPer]),'\n')
  cat('---------------------------------------\n')
  cat('FX between',allData$countryNames[countryToUse],' and ',allData$countryNames[controlVarNAPi$baseCountry],'without global components\n')
  cat('std[  log[FX]] = ',sqrt(var(outputFX$logSDF) + var(outputFX$logSDFBase)),'\n')
  cat('---------------------------------------\n')
  cat('SDF \n')
  cat('std[  log[SDF]] = ',sqrt(var(outputFX$logSDF)),'\n')
  cat('std[  log[SDFBase]] = ',sqrt(var(outputFX$logSDFBase)),'\n')
}

plotDiagnostics <- function(simOutput,returnsEZW)
{
  ## Plot Diagnostic Plots
  ############################
  nSim            <- length(simOutput$CC)
  ii              <- which.max(abs(simOutput$ZZ)) - 1
  ReturnsToPlot   <- max(ii-25,1):min(ii+25,nSim-1)
  filename        <-  file.path(outDir, 'DiagnosticPlots.pdf')
  pdf(filename, paper = 'special', width = 6, height = 7)
  #par(mfrow = c(3, 2))

  plot(as.ts(returnsEZW$Equity$Return[ReturnsToPlot]), ylim = c(-1,3),
      main = paste('Equity and Bonds'))
  lines(as.ts(returnsEZW$OnePerBond$Return[ReturnsToPlot]), col = 2)
  lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
  lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
  lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

  dev.off()

  filename <-  file.path(outDir, 'DiagnosticPlotsPDiv.pdf')
  pdf(filename, paper = 'special', width = 6, height = 7)
  #par(mfrow = c(3, 2))

  plot(as.ts(returnsEZW$Equity$PDiv[ReturnsToPlot]), ylim = c(-1,20),
      main = paste('Equity and Bonds'))
  lines(as.ts(returnsEZW$OnePerBond$PDiv[ReturnsToPlot]), col = 2)
  lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
  lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
  lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

  dev.off()

  ReturnsToPlot <- 200:300
  filename <-  file.path(outDir, 'DiagnosticPlots2.pdf')
  pdf(filename, paper = 'special', width = 6, height = 7)
  #par(mfrow = c(3, 2))

  plot(as.ts(returnsEZW$Equity$Return[ReturnsToPlot]), ylim = c(-1,3),
      main = paste('Equity and Bonds'))
  lines(as.ts(returnsEZW$OnePerBond$Return[ReturnsToPlot]), col = 2)
  lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
  lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
  lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

  dev.off()

  filename <-  file.path(outDir, 'DiagnosticPlots2PDiv.pdf')
  pdf(filename, paper = 'special', width = 6, height = 7)
  #par(mfrow = c(3, 2))

  plot(as.ts(returnsEZW$Equity$PDiv[ReturnsToPlot]), ylim = c(-1,20),
      main = paste('Equity and Bonds'))
  lines(as.ts(returnsEZW$OnePerBond$PDiv[ReturnsToPlot]), col = 2)
  lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
  lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
  lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

  dev.off()
}

## Calculates predictability regressions
################################################################################
predictability_LeveredLRR  <- function(countryToUse,
                                       PDivs,
                                       ParEst,
                                       controlVarNAPi,
                                       bigDataPosInfo)
{
  nnMonteCarlo         <- controlVarNAPi$nnMonteCarlo
  nSimMonteCarlo       <- 77  # Number of years in Beeler-Campbell
                # regressions plus one
  nSimBurninMonteCarlo <- 100
  xi                   <- ParEst[bigDataPosInfo$xi][countryToUse]

  # Initialize variables for excess returns statistics
  beta.er1<-beta.er3<-beta.er5<-beta.er10<-
  r.squared.er1<-r.squared.er3 <-r.squared.er5 <-r.squared.er10<-

  beta.cgs1<-beta.cgs3<-beta.cgs5<-beta.cgs10<-
  r.squared.cgs1 <-r.squared.cgs3 <-r.squared.cgs5 <-r.squared.cgs10<-

  beta.cge1<-beta.cge3<-beta.cge5<-beta.cge10<-
  r.squared.cge1 <-r.squared.cge3 <-r.squared.cge5 <-r.squared.cge10<-

  beta.d1<-beta.d3<-beta.d5<-beta.d10<-
  r.squared.d1<-r.squared.d3<-r.squared.d5<-r.squared.d10<-

  beta.vol1<-beta.vol3<-beta.vol5<-beta.vol10<-
  r.squared.vol1<-r.squared.vol3<-r.squared.vol5<-r.squared.vol10<-

  beta.ModelVol1<-beta.ModelVol3<-beta.ModelVol5<-beta.ModelVol10<-
  r.squared.ModelVol1<-r.squared.ModelVol3<-
  r.squared.ModelVol5<-r.squared.ModelVol10<-
    matrix(0,1,nnMonteCarlo)

  for (kk in 1:nnMonteCarlo){
    if (kk %% 100 == 0){
      print(kk)
    }
    ## Simulate global (world) components of the model
    simGlobalOutput <- simulateGlobal_EZW(controlVarNAPi,
                        ParEst,
                        bigDataPosInfo,
                        nSimMonteCarlo,
                        nSimBurninMonteCarlo,
                        printStuff = 0)

    ## Simulate country-specific processes of the model
    simOutput <- simulateModel_EZW(countryToUse,
                    controlVarNAPi,
                    ParEst,
                    bigDataPosInfo,
                    simGlobalOutput,
                    nSimMonteCarlo,
                    nSimBurninMonteCarlo,
                    printStuff = 0)

    ## Put the above simulated processes on the grid
    simOutputOnGrid <- putSimOutputOnStateGrid(countryToUse,
                          simOutput,
                          controlVarNAPi,
                          ParEst,
                          bigDataPosInfo,
                          printTime = 0)

    ## Calculate returns
    returnsEZW      <- calcReturns(countryToUse,
                    simOutput,
                    simOutputOnGrid,
                    PDivs,
                    controlVarNAPi,
                    ParEst,
                    bigDataPosInfo,
                    printTime = 0)

    nPeriods <- length(returnsEZW$Equity$PDiv)
    xx <- simOutputOnGrid$XX
    sigmaSq  <- simOutputOnGrid$SigmaSq + simOutputOnGrid$SigmaSqW
    pd <- log(returnsEZW$LeveredXXEq$PDiv)
    er <- log(returnsEZW$LeveredXXEq$Return/returnsEZW$OnePerBond$Return)
    cg <- log(returnsEZW$CGrowth)

    ## Excess Returns Predictability
    #################################
    ## 1-year horizon
    er1         <- er[2:nPeriods]
    pd1         <- pd[1:(nPeriods-1)]
    output      <- lm(er1 ~ pd1)
    beta1       <- output$coefficient[2]
    result      <- summary(output)
    r.squared1  <- result$r.squared
    ## 3-year horizon
    er3         <- numeric((nPeriods-3))
    for (mm in 1:(nPeriods-3)) er3[mm] <- sum(er[(mm+1):(mm+3)])
    pd3         <- pd[1:(nPeriods-3)]
    output      <- lm(er3 ~ pd3)
    beta3       <- output$coefficient[2]
    result      <- summary(output)
    r.squared3  <- result$r.squared
    ## 5-year horizon
    er5         <- numeric((nPeriods-5))
    for (mm in 1:(nPeriods-5)) er5[mm] <- sum(er[(mm+1):(mm+5)])
    pd5         <- pd[1:(nPeriods-5)]
    output      <- lm(er5 ~ pd5)
    beta5       <- output$coefficient[2]
    result      <- summary(output)
    r.squared5  <- result$r.squared
    ## 10-year horizon
    er10        <- numeric((nPeriods-10))
    for (mm in 1:(nPeriods-10)) er10[mm] <- sum(er[(mm+1):(mm+10)])
    pd10        <- pd[1:(nPeriods-10)]
    output      <- lm(er10 ~ pd10)
    beta10      <- output$coefficient[2]
    result      <- summary(output)
    r.squared10 <- result$r.squared
    ## Save result
    beta.er1[1,kk]       <- beta1
    beta.er3[1,kk]       <- beta3
    beta.er5[1,kk]       <- beta5
    beta.er10[1,kk]      <- beta10
    r.squared.er1[1,kk]  <- r.squared1
    r.squared.er3[1,kk]  <- r.squared3
    r.squared.er5[1,kk]  <- r.squared5
    r.squared.er10[1,kk] <- r.squared10
    ## Beginning of period Consumption predictability
    #################################################
    cgs1        <- cg[2:nPeriods]
    pd1         <- pd[1:(nPeriods-1)]
    output      <- lm(cgs1 ~ pd1)
    beta1       <- output$coefficient[2]
    result      <- summary(output)
    r.squared1  <- result$r.squared
    ## 3-year horizon
    cgs3        <- numeric((nPeriods-3))
    for (mm in 1:(nPeriods-3)) cgs3[mm] <- sum(cg[(mm+1):(mm+3)])
    pd3         <- pd[1:(nPeriods-3)]
    output      <- lm(cgs3 ~ pd3)
    beta3       <- output$coefficient[2]
    result      <- summary(output)
    r.squared3  <- result$r.squared
    ## 5-year horizon
    cgs5        <- numeric((nPeriods-5))
    for (mm in 1:(nPeriods-5)) cgs5[mm] <- sum(cg[(mm+1):(mm+5)])
    pd5         <- pd[1:(nPeriods-5)]
    output      <- lm(cgs5 ~ pd5)
    beta5       <- output$coefficient[2]
    result      <- summary(output)
    r.squared5  <- result$r.squared
    ## 10-year horizon
    cgs10       <- numeric((nPeriods-10))
    for (mm in 1:(nPeriods-10)) cgs10[mm] <- sum(cg[(mm+1):(mm+10)])
    pd10        <- pd[1:(nPeriods-10)]
    output      <- lm(cgs10 ~ pd10)
    beta10      <- output$coefficient[2]
    result      <- summary(output)
    r.squared10 <- result$r.squared
    ## Save result
    beta.cgs1[1,kk]       <- beta1
    beta.cgs3[1,kk]       <- beta3
    beta.cgs5[1,kk]       <- beta5
    beta.cgs10[1,kk]      <- beta10
    r.squared.cgs1[1,kk]  <- r.squared1
    r.squared.cgs3[1,kk]  <- r.squared3
    r.squared.cgs5[1,kk]  <- r.squared5
    r.squared.cgs10[1,kk] <- r.squared10
    ## End of period Consumption predictability
    ###########################################
    cge1        <- cg[2:nPeriods]
    pd1         <- pd[2:nPeriods]
    output      <- lm(cge1 ~ pd1)
    beta1       <- output$coefficient[2]
    result      <- summary(output)
    r.squared1  <- result$r.squared

    # 3-year horizon
    cge3        <- numeric((nPeriods-3))
    for (mm in 1:(nPeriods-3)){
       cge3[mm] <- sum(cg[(mm+1):(mm+3)])
    }
    pd3         <- pd[2:(nPeriods-(3-1))]
    output      <- lm(cge3 ~ pd3)
    beta3       <- output$coefficient[2]
    result      <- summary(output)
    r.squared3  <- result$r.squared

    # 5-year horizon
    cge5        <- numeric((nPeriods-5))
    for (mm in 1:(nPeriods-5)){
       cge5[mm] <- sum(cg[(mm+1):(mm+5)])
    }
    pd5         <- pd[2:(nPeriods-(5-1))]
    output      <- lm(cge5 ~ pd5)
    beta5       <- output$coefficient[2]
    result      <- summary(output)
    r.squared5  <- result$r.squared

    # 10-year horizon
    cge10       <- numeric((nPeriods-10))
    for (mm in 1:(nPeriods-10)){
       cge10[mm] <- sum(cg[(mm+1):(mm+10)])
    }
    pd10        <- pd[2:(nPeriods-(10-1))]
    output      <- lm(cge10 ~ pd10)
    beta10      <- output$coefficient[2]
    result      <- summary(output)
    r.squared10 <- result$r.squared

    # Save result
    beta.cge1[1,kk]  <- beta1
    beta.cge3[1,kk]  <- beta3
    beta.cge5[1,kk]  <- beta5
    beta.cge10[1,kk] <- beta10

    r.squared.cge1[1,kk]  <- r.squared1
    r.squared.cge3[1,kk]  <- r.squared3
    r.squared.cge5[1,kk]  <- r.squared5
    r.squared.cge10[1,kk] <- r.squared10

    ## Simple Volatility predictability
    ###########################################

    ## Estimate AR(1) process and extract residuals
    regression <- ar(cg[-c(1)],aic = FALSE,order.max = 1)
    vol        <- abs(regression$resid)
    vol        <- vol[!is.na(vol)]

    # 1-year horizon
    vol1        <- log(vol)
    pd1         <- pd[2:(nPeriods-1)]
    output      <- lm(vol1 ~ pd1)
    beta1       <- output$coefficient[2]
    result      <- summary(output)
    r.squared1  <- result$r.squared

    # 3-year horizon
    vol3        <- runSum(vol,3)
    vol3        <- log(vol3[!is.na(vol3)])
    pd3         <- pd[2:(nPeriods-3)]
    output      <- lm(vol3 ~ pd3)
    beta3       <- output$coefficient[2]
    result      <- summary(output)
    r.squared3  <- result$r.squared

    # 5-year horizon
    vol5        <- runSum(vol,5)
    vol5        <- log(vol5[!is.na(vol5)])
    pd5         <- pd[2:(nPeriods-5)]
    output      <- lm(vol5 ~ pd5)
    beta5       <- output$coefficient[2]
    result      <- summary(output)
    r.squared5  <- result$r.squared

    # 10-year horizon
    vol10       <- runSum(vol,10)
    vol10       <- log(vol10[!is.na(vol10)])
    pd10        <- pd[2:(nPeriods-10)]
    output      <- lm(vol10 ~ pd10)
    beta10      <- output$coefficient[2]
    result      <- summary(output)
    r.squared10 <- result$r.squared

    # Save result
    beta.vol1[1,kk]       <- beta1
    beta.vol3[1,kk]       <- beta3
    beta.vol5[1,kk]       <- beta5
    beta.vol10[1,kk]      <- beta10

    r.squared.vol1[1,kk]  <- r.squared1
    r.squared.vol3[1,kk]  <- r.squared3
    r.squared.vol5[1,kk]  <- r.squared5
    r.squared.vol10[1,kk] <- r.squared10

    ## Model Volatility predictability
    ###########################################
    # 1-year horizon
    vol1        <- log(sigmaSq[3:nPeriods])
    pd1         <- pd[2:(nPeriods-1)]
    output      <- lm(vol1 ~ pd1)
    beta1       <- output$coefficient[2]
    result      <- summary(output)
    r.squared1  <- result$r.squared
    # 3-year horizon
    vol3        <- runSum(sigmaSq[3:nPeriods],3)
    vol3        <- log(vol3[!is.na(vol3)])
    pd3         <- pd[2:(nPeriods-3)]
    output      <- lm(vol3 ~ pd3)
    beta3       <- output$coefficient[2]
    result      <- summary(output)
    r.squared3  <- result$r.squared
    # 5-year horizon
    vol5        <- runSum(sigmaSq[3:nPeriods],5)
    vol5        <- log(vol5[!is.na(vol5)])
    pd5         <- pd[2:(nPeriods-5)]
    output      <- lm(vol5 ~ pd5)
    beta5       <- output$coefficient[2]
    result      <- summary(output)
    r.squared5  <- result$r.squared
    # 10-year horizon
    vol10       <- runSum(sigmaSq[3:nPeriods],10)
    vol10       <- log(vol10[!is.na(vol10)])
    pd10        <- pd[2:(nPeriods-10)]
    output      <- lm(vol10 ~ pd10)
    beta10      <- output$coefficient[2]
    result      <- summary(output)
    r.squared10 <- result$r.squared
    # Save result
    beta.ModelVol1[1,kk]       <- beta1
    beta.ModelVol3[1,kk]       <- beta3
    beta.ModelVol5[1,kk]       <- beta5
    beta.ModelVol10[1,kk]      <- beta10
    r.squared.ModelVol1[1,kk]  <- r.squared1
    r.squared.ModelVol3[1,kk]  <- r.squared3
    r.squared.ModelVol5[1,kk]  <- r.squared5
    r.squared.ModelVol10[1,kk] <- r.squared10
   }
   ## Create Statistics over Monte Carlo
   ######################################
   ## Excess Stock Predictability
   beta.er1.median        <- apply(beta.er1,       1,median)
   beta.er3.median        <- apply(beta.er3,       1,median)
   beta.er5.median        <- apply(beta.er5,       1,median)
   beta.er10.median       <- apply(beta.er10,      1,median)
   r.squared.er1.median   <- apply(r.squared.er1,  1,median)
   r.squared.er3.median   <- apply(r.squared.er3,  1,median)
   r.squared.er5.median   <- apply(r.squared.er5,  1,median)
   r.squared.er10.median  <- apply(r.squared.er10, 1,median)
   beta.er1.q025          <- apply(beta.er1,       1,quantile, probs = 0.025)
   beta.er3.q025          <- apply(beta.er3,       1,quantile, probs = 0.025)
   beta.er5.q025          <- apply(beta.er5,       1,quantile, probs = 0.025)
   beta.er10.q025         <- apply(beta.er10,      1,quantile, probs = 0.025)
   r.squared.er1.q025     <- apply(r.squared.er1,  1,quantile, probs = 0.025)
   r.squared.er3.q025     <- apply(r.squared.er3,  1,quantile, probs = 0.025)
   r.squared.er5.q025     <- apply(r.squared.er5,  1,quantile, probs = 0.025)
   r.squared.er10.q025    <- apply(r.squared.er10, 1,quantile, probs = 0.025)
   beta.er1.q975          <- apply(beta.er1,       1,quantile, probs = 0.975)
   beta.er3.q975          <- apply(beta.er3,       1,quantile, probs = 0.975)
   beta.er5.q975          <- apply(beta.er5,       1,quantile, probs = 0.975)
   beta.er10.q975         <- apply(beta.er10,      1,quantile, probs = 0.975)
   r.squared.er1.q975     <- apply(r.squared.er1,  1,quantile, probs = 0.975)
   r.squared.er3.q975     <- apply(r.squared.er3,  1,quantile, probs = 0.975)
   r.squared.er5.q975     <- apply(r.squared.er5,  1,quantile, probs = 0.975)
   r.squared.er10.q975    <- apply(r.squared.er10, 1,quantile, probs = 0.975)
   ## Consumption predictability
   beta.cgs1.median       <- apply(beta.cgs1,      1,median)
   beta.cgs3.median       <- apply(beta.cgs3,      1,median)
   beta.cgs5.median       <- apply(beta.cgs5,      1,median)
   beta.cgs10.median      <- apply(beta.cgs10,     1,median)
   r.squared.cgs1.median  <- apply(r.squared.cgs1, 1,median)
   r.squared.cgs3.median  <- apply(r.squared.cgs3, 1,median)
   r.squared.cgs5.median  <- apply(r.squared.cgs5, 1,median)
   r.squared.cgs10.median <- apply(r.squared.cgs10,1,median)
   beta.cgs1.q025         <- apply(beta.cgs1,      1,quantile, probs = 0.025)
   beta.cgs3.q025         <- apply(beta.cgs3,      1,quantile, probs = 0.025)
   beta.cgs5.q025         <- apply(beta.cgs5,      1,quantile, probs = 0.025)
   beta.cgs10.q025        <- apply(beta.cgs10,     1,quantile, probs = 0.025)
   r.squared.cgs1.q025    <- apply(r.squared.cgs1, 1,quantile, probs = 0.025)
   r.squared.cgs3.q025    <- apply(r.squared.cgs3, 1,quantile, probs = 0.025)
   r.squared.cgs5.q025    <- apply(r.squared.cgs5, 1,quantile, probs = 0.025)
   r.squared.cgs10.q025   <- apply(r.squared.cgs10,1,quantile, probs = 0.025)
   beta.cgs1.q975         <- apply(beta.cgs1,      1,quantile, probs = 0.975)
   beta.cgs3.q975         <- apply(beta.cgs3,      1,quantile, probs = 0.975)
   beta.cgs5.q975         <- apply(beta.cgs5,      1,quantile, probs = 0.975)
   beta.cgs10.q975        <- apply(beta.cgs10,     1,quantile, probs = 0.975)
   r.squared.cgs1.q975    <- apply(r.squared.cgs1, 1,quantile, probs = 0.975)
   r.squared.cgs3.q975    <- apply(r.squared.cgs3, 1,quantile, probs = 0.975)
   r.squared.cgs5.q975    <- apply(r.squared.cgs5, 1,quantile, probs = 0.975)
   r.squared.cgs10.q975   <- apply(r.squared.cgs10,1,quantile, probs = 0.975)
   ## Consumption predictability
   beta.cge1.median       <- apply(beta.cge1,      1,median)
   beta.cge3.median       <- apply(beta.cge3,      1,median)
   beta.cge5.median       <- apply(beta.cge5,      1,median)
   beta.cge10.median      <- apply(beta.cge10,     1,median)
   r.squared.cge1.median  <- apply(r.squared.cge1, 1,median)
   r.squared.cge3.median  <- apply(r.squared.cge3, 1,median)
   r.squared.cge5.median  <- apply(r.squared.cge5, 1,median)
   r.squared.cge10.median <- apply(r.squared.cge10,1,median)
   beta.cge1.q025         <- apply(beta.cge1,      1,quantile, probs = 0.025)
   beta.cge3.q025         <- apply(beta.cge3,      1,quantile, probs = 0.025)
   beta.cge5.q025         <- apply(beta.cge5,      1,quantile, probs = 0.025)
   beta.cge10.q025        <- apply(beta.cge10,     1,quantile, probs = 0.025)
   r.squared.cge1.q025    <- apply(r.squared.cge1, 1,quantile, probs = 0.025)
   r.squared.cge3.q025    <- apply(r.squared.cge3, 1,quantile, probs = 0.025)
   r.squared.cge5.q025    <- apply(r.squared.cge5, 1,quantile, probs = 0.025)
   r.squared.cge10.q025   <- apply(r.squared.cge10,1,quantile, probs = 0.025)
   beta.cge1.q975         <- apply(beta.cge1,      1,quantile, probs = 0.975)
   beta.cge3.q975         <- apply(beta.cge3,      1,quantile, probs = 0.975)
   beta.cge5.q975         <- apply(beta.cge5,      1,quantile, probs = 0.975)
   beta.cge10.q975        <- apply(beta.cge10,     1,quantile, probs = 0.975)
   r.squared.cge1.q975    <- apply(r.squared.cge1, 1,quantile, probs = 0.975)
   r.squared.cge3.q975    <- apply(r.squared.cge3, 1,quantile, probs = 0.975)
   r.squared.cge5.q975    <- apply(r.squared.cge5, 1,quantile, probs = 0.975)
   r.squared.cge10.q975   <- apply(r.squared.cge10,1,quantile, probs = 0.975)
   ## Simple Volatility predictability
   beta.vol1.median       <- apply(beta.vol1,      1,median)
   beta.vol3.median       <- apply(beta.vol3,      1,median)
   beta.vol5.median       <- apply(beta.vol5,      1,median)
   beta.vol10.median      <- apply(beta.vol10,     1,median)
   r.squared.vol1.median  <- apply(r.squared.vol1, 1,median)
   r.squared.vol3.median  <- apply(r.squared.vol3, 1,median)
   r.squared.vol5.median  <- apply(r.squared.vol5, 1,median)
   r.squared.vol10.median <- apply(r.squared.vol10,1,median)
   beta.vol1.q025         <- apply(beta.vol1,      1,quantile, probs = 0.025)
   beta.vol3.q025         <- apply(beta.vol3,      1,quantile, probs = 0.025)
   beta.vol5.q025         <- apply(beta.vol5,      1,quantile, probs = 0.025)
   beta.vol10.q025        <- apply(beta.vol10,     1,quantile, probs = 0.025)
   r.squared.vol1.q025    <- apply(r.squared.vol1, 1,quantile, probs = 0.025)
   r.squared.vol3.q025    <- apply(r.squared.vol3, 1,quantile, probs = 0.025)
   r.squared.vol5.q025    <- apply(r.squared.vol5, 1,quantile, probs = 0.025)
   r.squared.vol10.q025   <- apply(r.squared.vol10,1,quantile, probs = 0.025)
   beta.vol1.q975         <- apply(beta.vol1,      1,quantile, probs = 0.975)
   beta.vol3.q975         <- apply(beta.vol3,      1,quantile, probs = 0.975)
   beta.vol5.q975         <- apply(beta.vol5,      1,quantile, probs = 0.975)
   beta.vol10.q975        <- apply(beta.vol10,     1,quantile, probs = 0.975)
   r.squared.vol1.q975    <- apply(r.squared.vol1, 1,quantile, probs = 0.975)
   r.squared.vol3.q975    <- apply(r.squared.vol3, 1,quantile, probs = 0.975)
   r.squared.vol5.q975    <- apply(r.squared.vol5, 1,quantile, probs = 0.975)
   r.squared.vol10.q975   <- apply(r.squared.vol10,1,quantile, probs = 0.975)
   ## Simple Volatility predictability
   beta.ModelVol1.median       <- apply(beta.ModelVol1,      1,median)
   beta.ModelVol3.median       <- apply(beta.ModelVol3,      1,median)
   beta.ModelVol5.median       <- apply(beta.ModelVol5,      1,median)
   beta.ModelVol10.median      <- apply(beta.ModelVol10,     1,median)
   r.squared.ModelVol1.median  <- apply(r.squared.ModelVol1, 1,median)
   r.squared.ModelVol3.median  <- apply(r.squared.ModelVol3, 1,median)
   r.squared.ModelVol5.median  <- apply(r.squared.ModelVol5, 1,median)
   r.squared.ModelVol10.median <- apply(r.squared.ModelVol10,1,median)
   beta.ModelVol1.q025         <- apply(beta.ModelVol1,      1,quantile, probs = 0.025)
   beta.ModelVol3.q025         <- apply(beta.ModelVol3,      1,quantile, probs = 0.025)
   beta.ModelVol5.q025         <- apply(beta.ModelVol5,      1,quantile, probs = 0.025)
   beta.ModelVol10.q025        <- apply(beta.ModelVol10,     1,quantile, probs = 0.025)
   r.squared.ModelVol1.q025    <- apply(r.squared.ModelVol1, 1,quantile, probs = 0.025)
   r.squared.ModelVol3.q025    <- apply(r.squared.ModelVol3, 1,quantile, probs = 0.025)
   r.squared.ModelVol5.q025    <- apply(r.squared.ModelVol5, 1,quantile, probs = 0.025)
   r.squared.ModelVol10.q025   <- apply(r.squared.ModelVol10,1,quantile, probs = 0.025)
   beta.ModelVol1.q975         <- apply(beta.ModelVol1,      1,quantile, probs = 0.975)
   beta.ModelVol3.q975         <- apply(beta.ModelVol3,      1,quantile, probs = 0.975)
   beta.ModelVol5.q975         <- apply(beta.ModelVol5,      1,quantile, probs = 0.975)
   beta.ModelVol10.q975        <- apply(beta.ModelVol10,     1,quantile, probs = 0.975)
   r.squared.ModelVol1.q975    <- apply(r.squared.ModelVol1, 1,quantile, probs = 0.975)
   r.squared.ModelVol3.q975    <- apply(r.squared.ModelVol3, 1,quantile, probs = 0.975)
   r.squared.ModelVol5.q975    <- apply(r.squared.ModelVol5, 1,quantile, probs = 0.975)
   r.squared.ModelVol10.q975   <- apply(r.squared.ModelVol10,1,quantile, probs = 0.975)

  rm(er,er1,er3,er5,cgs1,cgs3,cgs5,cge1,cge3,cge5)

  er1 <- list(beta.median      = beta.er1.median,
        beta.q025        = beta.er1.q025,
        beta.q975        = beta.er1.q975,
        r.squared.median = r.squared.er1.median,
        r.squared.q025   = r.squared.er1.q025,
        r.squared.q975   = r.squared.er1.q975)
  er3 <- list(beta.median      = beta.er3.median,
        beta.q025        = beta.er3.q025,
        beta.q975        = beta.er3.q975,
        r.squared.median = r.squared.er3.median,
        r.squared.q025   = r.squared.er3.q025,
        r.squared.q975   = r.squared.er3.q975)
  er5 <- list(beta.median      = beta.er5.median,
        beta.q025        = beta.er5.q025,
        beta.q975        = beta.er5.q975,
        r.squared.median = r.squared.er5.median,
        r.squared.q025   = r.squared.er5.q025,
        r.squared.q975   = r.squared.er5.q975)
  er10 <- list(beta.median     = beta.er10.median,
        beta.q025        = beta.er10.q025,
        beta.q975        = beta.er10.q975,
        r.squared.median = r.squared.er10.median,
        r.squared.q025   = r.squared.er10.q025,
        r.squared.q975   = r.squared.er10.q975)
  er <- list(er1 = er1,er3 = er3,er5 = er5,er10 = er10)

  cgs1 <- list(beta.median     = beta.cgs1.median,
        beta.q025        = beta.cgs1.q025,
        beta.q975        = beta.cgs1.q975,
        r.squared.median = r.squared.cgs1.median,
        r.squared.q025   = r.squared.cgs1.q025,
        r.squared.q975   = r.squared.cgs1.q975)
  cgs3 <- list(beta.median     = beta.cgs3.median,
        beta.q025        = beta.cgs3.q025,
        beta.q975        = beta.cgs3.q975,
        r.squared.median = r.squared.cgs3.median,
        r.squared.q025   = r.squared.cgs3.q025,
        r.squared.q975   = r.squared.cgs3.q975)
  cgs5 <- list(beta.median     = beta.cgs5.median,
        beta.q025        = beta.cgs5.q025,
        beta.q975        = beta.cgs5.q975,
        r.squared.median = r.squared.cgs5.median,
        r.squared.q025   = r.squared.cgs5.q025,
        r.squared.q975   = r.squared.cgs5.q975)
  cgs10 <- list(beta.median    = beta.cgs10.median,
        beta.q025        = beta.cgs10.q025,
        beta.q975        = beta.cgs10.q975,
        r.squared.median = r.squared.cgs10.median,
        r.squared.q025   = r.squared.cgs10.q025,
        r.squared.q975   = r.squared.cgs10.q975)
  cgs <- list(cgs1 = cgs1,cgs3 = cgs3,cgs5 = cgs5,cgs10 = cgs10)

  cge1 <- list(beta.median     = beta.cge1.median,
        beta.q025        = beta.cge1.q025,
        beta.q975        = beta.cge1.q975,
        r.squared.median = r.squared.cge1.median,
        r.squared.q025   = r.squared.cge1.q025,
        r.squared.q975   = r.squared.cge1.q975)
  cge3 <- list(beta.median     = beta.cge3.median,
        beta.q025        = beta.cge3.q025,
        beta.q975        = beta.cge3.q975,
        r.squared.median = r.squared.cge3.median,
        r.squared.q025   = r.squared.cge3.q025,
        r.squared.q975   = r.squared.cge3.q975)
  cge5 <- list(beta.median     = beta.cge5.median,
        beta.q025        = beta.cge5.q025,
        beta.q975        = beta.cge5.q975,
        r.squared.median = r.squared.cge5.median,
        r.squared.q025   = r.squared.cge5.q025,
        r.squared.q975   = r.squared.cge5.q975)
  cge10 <- list(beta.median    = beta.cge10.median,
        beta.q025        = beta.cge10.q025,
        beta.q975        = beta.cge10.q975,
        r.squared.median = r.squared.cge10.median,
        r.squared.q025   = r.squared.cge10.q025,
        r.squared.q975   = r.squared.cge10.q975)
  cge <- list(cge1 = cge1,cge3 = cge3,cge5 = cge5,cge10 = cge10)

  vol1 <- list(beta.median     = beta.vol1.median,
        beta.q025        = beta.vol1.q025,
        beta.q975        = beta.vol1.q975,
        r.squared.median = r.squared.vol1.median,
        r.squared.q025   = r.squared.vol1.q025,
        r.squared.q975   = r.squared.vol1.q975)
  vol3 <- list(beta.median     = beta.vol3.median,
        beta.q025        = beta.vol3.q025,
        beta.q975        = beta.vol3.q975,
        r.squared.median = r.squared.vol3.median,
        r.squared.q025   = r.squared.vol3.q025,
        r.squared.q975   = r.squared.vol3.q975)
  vol5 <- list(beta.median     = beta.vol5.median,
        beta.q025        = beta.vol5.q025,
        beta.q975        = beta.vol5.q975,
        r.squared.median = r.squared.vol5.median,
        r.squared.q025   = r.squared.vol5.q025,
        r.squared.q975   = r.squared.vol5.q975)
  vol10 <- list(beta.median    = beta.vol10.median,
        beta.q025        = beta.vol10.q025,
        beta.q975        = beta.vol10.q975,
        r.squared.median = r.squared.vol10.median,
        r.squared.q025   = r.squared.vol10.q025,
        r.squared.q975   = r.squared.vol10.q975)
  vol <- list(vol1=vol1,vol3=vol3,vol5=vol5,vol10=vol10)

  modelVol1 <- list(beta.median      = beta.ModelVol1.median,
            beta.q025        = beta.ModelVol1.q025,
            beta.q975        = beta.ModelVol1.q975,
            r.squared.median = r.squared.ModelVol1.median,
            r.squared.q025   = r.squared.ModelVol1.q025,
            r.squared.q975   = r.squared.ModelVol1.q975)
  modelVol3 <- list(beta.median      = beta.ModelVol3.median,
            beta.q025        = beta.ModelVol3.q025,
            beta.q975        = beta.ModelVol3.q975,
            r.squared.median = r.squared.ModelVol3.median,
            r.squared.q025   = r.squared.ModelVol3.q025,
            r.squared.q975   = r.squared.ModelVol3.q975)
  modelVol5 <- list(beta.median      = beta.ModelVol5.median,
            beta.q025        = beta.ModelVol5.q025,
            beta.q975        = beta.ModelVol5.q975,
            r.squared.median = r.squared.ModelVol5.median,
            r.squared.q025   = r.squared.ModelVol5.q025,
            r.squared.q975   = r.squared.ModelVol5.q975)
  modelVol10 <- list(beta.median      = beta.ModelVol10.median,
             beta.q025        = beta.ModelVol10.q025,
             beta.q975        = beta.ModelVol10.q975,
             r.squared.median = r.squared.ModelVol10.median,
             r.squared.q025   = r.squared.ModelVol10.q025,
             r.squared.q975   = r.squared.ModelVol10.q975)
  modelVol <- list(modelVol1=modelVol1,
          modelVol3=modelVol3,
          modelVol5=modelVol5,
          modelVol10=modelVol10)

  return(list(er=er,cgs=cgs,cge=cge,vol=vol,modelVol=modelVol))
}

savePredictability_LeveredLRR   <- function(predic,
                      outDir,
                      countryToUse)
{
  ## Data from Beeler and Campbell
  ##################################

  ## Excess Stock Predictability
  beta.er1.hat       <- -0.059
  beta.er3.hat       <- -0.229
  beta.er5.hat       <- -0.421

  r.squared.er1.hat  <- 0.022
  r.squared.er3.hat  <- 0.143
  r.squared.er5.hat  <- 0.278

  ## Consumption predictability
  beta.cgs1.hat      <- 0.001
  beta.cgs3.hat      <- -0.010
  beta.cgs5.hat      <- -0.016

  r.squared.cgs1.hat <- 0.000
  r.squared.cgs3.hat <- 0.018
  r.squared.cgs5.hat <- 0.040

  ## Consumption predictability
  beta.cge1.hat      <- 0.012
  beta.cge3.hat      <- 0.010
  beta.cge5.hat      <- -0.001

  r.squared.cge1.hat <- 0.068
  r.squared.cge3.hat <- 0.013
  r.squared.cge5.hat <-  0.000

  ## Dividend predictability
  beta.div1.hat      <- 0.064
  beta.div3.hat      <- 0.076
  beta.div5.hat      <- 0.051

  r.squared.div1.hat <- 0.074
  r.squared.div3.hat <- 0.034
  r.squared.div5.hat <- 0.013

  ## Volatility predictability
  beta.vol1.hat      <- -0.481
  beta.vol3.hat      <- -0.491
  beta.vol5.hat      <- -0.564

  r.squared.vol1.hat <- 0.035
  r.squared.vol3.hat <- 0.122
  r.squared.vol5.hat <- 0.235

  ## BY from Beeler and Campbell
  ##################################################################################################################

  ## Excess Stock Predictability
  beta.er1.BY.median       <- -0.049
  beta.er3.BY.median       <- -0.144
  beta.er5.BY.median       <- -0.230

  beta.er1.BY.pop          <- -0.007
  beta.er3.BY.pop          <- -0.026
  beta.er5.BY.pop          <- -0.039

  r.squared.er1.BY.median  <- 0.007
  r.squared.er3.BY.median  <- 0.018
  r.squared.er5.BY.median  <- 0.027

  r.squared.er1.BY.pop     <- 0.000
  r.squared.er3.BY.pop     <- 0.000
  r.squared.er5.BY.pop     <- 0.000

  ## Consumption predictability
  beta.cgs1.BY.median      <- 0.092
  beta.cgs3.BY.median      <- 0.207
  beta.cgs5.BY.median      <- 0.259

  beta.cgs1.BY.pop         <- 0.097
  beta.cgs3.BY.pop         <- 0.230
  beta.cgs5.BY.pop         <- 0.308

  r.squared.cgs1.BY.median <- 0.242
  r.squared.cgs3.BY.median <- 0.228
  r.squared.cgs5.BY.median <- 0.176

  r.squared.cgs1.BY.pop    <- 0.280
  r.squared.cgs3.BY.pop    <- 0.280
  r.squared.cgs5.BY.pop    <- 0.235

  ## Consumption predictability
  beta.cge1.BY.median      <- 0.113
  beta.cge3.BY.median      <- 0.271
  beta.cge5.BY.median      <- 0.350

  beta.cge1.BY.pop         <- 0.114
  beta.cge3.BY.pop         <- 0.286
  beta.cge5.BY.pop         <- 0.388

  r.squared.cge1.BY.median <- 0.361
  r.squared.cge3.BY.median <- 0.394
  r.squared.cge5.BY.median <- 0.322

  r.squared.cge1.BY.pop    <- 0.390
  r.squared.cge3.BY.pop    <- 0.435
  r.squared.cge5.BY.pop    <- 0.373

  ## Dividend predictability
  beta.div1.BY.median      <- 0.339
  beta.div3.BY.median      <- 0.816
  beta.div5.BY.median      <- 1.053

  beta.div1.BY.pop         <- 0.343
  beta.div3.BY.pop         <- 0.860
  beta.div5.BY.pop         <- 1.171

  r.squared.div1.BY.median <- 0.207
  r.squared.div3.BY.median <- 0.257
  r.squared.div5.BY.median <- 0.224

  r.squared.div1.BY.pop    <- 0.228
  r.squared.div3.BY.pop    <- 0.288
  r.squared.div5.BY.pop    <- 0.265

  ## Volatility predictability
  beta.vol1.BY.median      <- -0.140
  beta.vol3.BY.median      <- -0.124
  beta.vol5.BY.median      <- -0.104

  beta.vol1.BY.pop         <- -0.128
  beta.vol3.BY.pop         <- -0.122
  beta.vol5.BY.pop         <- -0.113

  r.squared.vol1.BY.median <- 0.006
  r.squared.vol3.BY.median <- 0.015
  r.squared.vol5.BY.median <- 0.022

  r.squared.vol1.BY.pop    <- 0.000
  r.squared.vol3.BY.pop    <- 0.001
  r.squared.vol5.BY.pop    <- 0.002

  ## BKY from BKY (2009)
  ##################################################################################################################

  ## Excess Stock Predictability (copied from BKY (2009))
  beta.er1.BKY.median      <- -0.121
  beta.er3.BKY.median      <- -0.344
  beta.er5.BKY.median      <- -0.537

  beta.er1.BKY.pop         <- -0.078
  beta.er3.BKY.pop         <- -0.226
  beta.er5.BKY.pop         <- -0.368

  r.squared.er1.BKY.median <- 0.012
  r.squared.er3.BKY.median <- 0.034
  r.squared.er5.BKY.median <- 0.053

  r.squared.er1.BKY.pop    <- 0.009
  r.squared.er3.BKY.pop    <- 0.026
  r.squared.er5.BKY.pop    <- 0.041

  ## Consumption predictability (copied from BKY (2009))
  beta.cgs1.BKY.median      <- NA
  beta.cgs3.BKY.median      <- NA
  beta.cgs5.BKY.median      <- NA

  beta.cgs1.BKY.pop         <- NA
  beta.cgs3.BKY.pop         <- NA
  beta.cgs5.BKY.pop         <- NA

  r.squared.cgs1.BKY.median <- NA
  r.squared.cgs3.BKY.median <- NA
  r.squared.cgs5.BKY.median <- NA

  r.squared.cgs1.BKY.pop    <- NA
  r.squared.cgs3.BKY.pop    <- NA
  r.squared.cgs5.BKY.pop    <- NA

  ## Consumption predictability (copied from BKY (2009))
  beta.cge1.BKY.median      <- 0.05
  beta.cge3.BKY.median      <- 0.10
  beta.cge5.BKY.median      <- 0.12

  beta.cge1.BKY.pop         <- 0.03
  beta.cge3.BKY.pop         <- 0.05
  beta.cge5.BKY.pop         <- 0.06

  r.squared.cge1.BKY.median <- 0.14
  r.squared.cge3.BKY.median <- 0.10
  r.squared.cge5.BKY.median <- 0.08

  r.squared.cge1.BKY.pop    <- 0.07
  r.squared.cge3.BKY.pop    <- 0.05
  r.squared.cge5.BKY.pop    <- 0.04

  ## Dividend predictability (copied from BKY (2009))
  beta.div1.BKY.median      <- 0.35
  beta.div3.BKY.median      <- 0.45
  beta.div5.BKY.median      <- 0.49

  beta.div1.BKY.pop         <- 0.19
  beta.div3.BKY.pop         <- 0.26
  beta.div5.BKY.pop         <- 0.30

  r.squared.div1.BKY.median <- 0.20
  r.squared.div3.BKY.median <- 0.09
  r.squared.div5.BKY.median <- 0.06

  r.squared.div1.BKY.pop    <- 0.11
  r.squared.div3.BKY.pop    <- 0.05
  r.squared.div5.BKY.pop    <- 0.04

  ## Volatility predictability (copied from BKY (2009))
  beta.vol1.BKY.median      <- -0.95
  beta.vol3.BKY.median      <- -0.90
  beta.vol5.BKY.median      <- -0.78

  beta.vol1.BKY.pop         <- -1.00
  beta.vol3.BKY.pop         <- -0.95
  beta.vol5.BKY.pop         <- -0.93

  r.squared.vol1.BKY.median <- 0.03
  r.squared.vol3.BKY.median <- 0.08
  r.squared.vol5.BKY.median <- 0.11

  r.squared.vol1.BKY.pop    <- 0.07
  r.squared.vol3.BKY.pop    <- 0.21
  r.squared.vol5.BKY.pop    <- 0.29

   # Create Tables
   # Excess returns coefficients
  Table <- cbind(c(beta.er1.hat,              beta.er3.hat,              beta.er5.hat,              NA),
          c(beta.er1.BY.median,        beta.er3.BY.median,        beta.er5.BY.median,        NA),
          c(beta.er1.BKY.median,       beta.er3.BKY.median,       beta.er5.BKY.median,       NA),
          c(predic$er$er1$beta.median, predic$er$er3$beta.median, predic$er$er5$beta.median, predic$er$er10$beta.median),
          c(predic$er$er1$beta.q025,    predic$er$er3$beta.q025,    predic$er$er5$beta.q025,    predic$er$er10$beta.q025),
          c(predic$er$er1$beta.q975,    predic$er$er3$beta.q975,    predic$er$er5$beta.q975,    predic$er$er10$beta.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('beta',
                  'beta_{BY}(50%)',
                  'beta_{BKY}(50%)',
                  'beta_{NSS}(50%)',
                  'beta_{NSS}(2.5%)',
                  'beta_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_ExcessReturnsBetaNAP.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
   ## Excess returns R-squared
  Table <- cbind(c(r.squared.er1.hat,r.squared.er3.hat,r.squared.er5.hat,NA),
          c(r.squared.er1.BY.median,r.squared.er3.BY.median,r.squared.er5.BY.median,NA),
          c(r.squared.er1.BKY.median,r.squared.er3.BKY.median,r.squared.er5.BKY.median,NA),
          c(predic$er$er1$r.squared.median,predic$er$er3$r.squared.median,predic$er$er5$r.squared.median,predic$er$er10$r.squared.median),
          c(predic$er$er1$r.squared.q025,predic$er$er3$r.squared.q025,predic$er$er5$r.squared.q025,predic$er$er10$r.squared.q025),
          c(predic$er$er1$r.squared.q975,predic$er$er3$r.squared.q975,predic$er$er5$r.squared.q975,predic$er$er10$r.squared.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('R^2$',
                  'R^2_{BY}(50%)',
                  'R^2_{BKY}(50%)',
                  'R^2_{NSS}(50%)',
                  'R^2_{NSS}(2.5%)',
                  'R^2_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_ExcessReturnsRsquaredNAPi.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
   ## Beginning of the period consumption: coefficients
  Table <- cbind(c(beta.cgs1.hat,beta.cgs3.hat,beta.cgs5.hat,NA),
              c(beta.cgs1.BY.median,beta.cgs3.BY.median,beta.cgs5.BY.median,NA),
              c(beta.cgs1.BKY.median,beta.cgs3.BKY.median,beta.cgs5.BKY.median,NA),
              c(predic$cgs$cgs1$beta.median,predic$cgs$cgs3$beta.median,predic$cgs$cgs5$beta.median,predic$cgs$cgs10$beta.median),
              c(predic$cgs$cgs1$beta.q025,predic$cgs$cgs3$beta.q025,predic$cgs$cgs5$beta.q025,predic$cgs$cgs10$beta.q025),
              c(predic$cgs$cgs1$beta.q975,predic$cgs$cgs3$beta.q975,predic$cgs$cgs5$beta.q975,predic$cgs$cgs10$beta.q975))
   TableXLS <- Table
   dimnames(TableXLS)[[2]] <- c('beta',
                  'beta_{BY}(50%)',
                  'beta_{BKY}(50%)',
                  'beta_{NSS}(50%)',
                  'beta_{NSS}(2.5%)',
                  'beta_{NSS}(97.5%)')
   dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_BeginningConsumptionBetaNAPi.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
  ## Beginning of the period consumption: R-squared
  Table <- cbind(c(r.squared.cgs1.hat,r.squared.cgs3.hat,r.squared.cgs5.hat,NA),
              c(r.squared.cgs1.BY.median,r.squared.cgs3.BY.median,r.squared.cgs5.BY.median,NA),
              c(r.squared.cgs1.BKY.median,r.squared.cgs3.BKY.median,r.squared.cgs5.BKY.median,NA),
              c(predic$cgs$cgs1$r.squared.median,predic$cgs$cgs3$r.squared.median,predic$cgs$cgs5$r.squared.median,predic$cgs$cgs10$r.squared.median),
              c(predic$cgs$cgs1$r.squared.q025,predic$cgs$cgs3$r.squared.q025,predic$cgs$cgs5$r.squared.q025,predic$cgs$cgs10$r.squared.q025),
              c(predic$cgs$cgs1$r.squared.q975,predic$cgs$cgs3$r.squared.q975,predic$cgs$cgs5$r.squared.q975,predic$cgs$cgs10$r.squared.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('R^2$',
                  'R^2_{BY}(50%)',
                  'R^2_{BKY}(50%)',
                  'R^2_{NSS}(50%)',
                  'R^2_{NSS}(2.5%)',
                  'R^2_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_BeginningConsumptionRsquaredNAPi.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
  ## End-of-period consumption: coefficients
  Table <- cbind(c(beta.cge1.hat,beta.cge3.hat,beta.cge5.hat,NA),
          c(beta.cge1.BY.median,beta.cge3.BY.median,beta.cge5.BY.median,NA),
          c(beta.cge1.BKY.median,beta.cge3.BKY.median,beta.cge5.BKY.median,NA),
          c(predic$cge$cge1$beta.median,predic$cge$cge3$beta.median,predic$cge$cge5$beta.median,predic$cge$cge10$beta.median),
          c(predic$cge$cge1$beta.q025,predic$cge$cge3$beta.q025,predic$cge$cge5$beta.q025,predic$cge$cge10$beta.q025),
          c(predic$cge$cge1$beta.q975,predic$cge$cge3$beta.q975,predic$cge$cge5$beta.q975,predic$cge$cge10$beta.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('beta',
                  'beta_{BY}(50%)',
                  'beta_{BKY}(50%)',
                  'beta_{NSS}(50%)',
                  'beta_{NSS}(2.5%)',
                  'beta_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_EndConsumptionBetaNAPi.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
  ## End-of-period consumption: R-squared
  Table <- cbind(c(r.squared.cge1.hat,r.squared.cge3.hat,r.squared.cge5.hat,NA),
          c(r.squared.cge1.BY.median,r.squared.cge3.BY.median,r.squared.cge5.BY.median,NA),
          c(r.squared.cge1.BKY.median,r.squared.cge3.BKY.median,r.squared.cge5.BKY.median,NA),
          c(predic$cge$cge1$r.squared.median,predic$cge$cge3$r.squared.median,predic$cge$cge5$r.squared.median,predic$cge$cge10$r.squared.median),
          c(predic$cge$cge1$r.squared.q025,predic$cge$cge3$r.squared.q025,predic$cge$cge5$r.squared.q025,predic$cge$cge10$r.squared.q025),
          c(predic$cge$cge1$r.squared.q975,predic$cge$cge3$r.squared.q975,predic$cge$cge5$r.squared.q975,predic$cge$cge10$r.squared.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('R^2$',
                  'R^2_{BY}(50%)',
                  'R^2_{BKY}(50%)',
                  'R^2_{NSS}(50%)',
                  'R^2_{NSS}(2.5%)',
                  'R^2_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_EndConsumptionRsquaredNAPi.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
  ## Simple Volatility: coefficients
  Table <- cbind(c(beta.vol1.hat,beta.vol3.hat,beta.vol5.hat,NA),
              c(beta.vol1.BY.median,beta.vol3.BY.median,beta.vol5.BY.median,NA),
              c(beta.vol1.BKY.median,beta.vol3.BKY.median,beta.vol5.BKY.median,NA),
              c(predic$vol$vol1$beta.median,predic$vol$vol3$beta.median,predic$vol$vol5$beta.median,predic$vol$vol10$beta.median),
              c(predic$vol$vol1$beta.q025,predic$vol$vol3$beta.q025,predic$vol$vol5$beta.q025,predic$vol$vol10$beta.q025),
              c(predic$vol$vol1$beta.q975,predic$vol$vol3$beta.q975,predic$vol$vol5$beta.q975,predic$vol$vol10$beta.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('beta',
                  'beta_{BY}(50%)',
                  'beta_{BKY}(50%)',
                  'beta_{NSS}(50%)',
                  'beta_{NSS}(2.5%)',
                  'beta_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_VolatilityBetaNAPi.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
  ## Simple Volatility: R-squared
  Table <- cbind(c(r.squared.vol1.hat,r.squared.vol3.hat,r.squared.vol5.hat,NA),
              c(r.squared.vol1.BY.median,r.squared.vol3.BY.median,r.squared.vol5.BY.median,NA),
              c(r.squared.vol1.BKY.median,r.squared.vol3.BKY.median,r.squared.vol5.BKY.median,NA),
              c(predic$vol$vol1$r.squared.median,predic$vol$vol3$r.squared.median,predic$vol$vol5$r.squared.median,predic$vol$vol10$r.squared.median),
              c(predic$vol$vol1$r.squared.q025,predic$vol$vol3$r.squared.q025,predic$vol$vol5$r.squared.q025,predic$vol$vol10$r.squared.q025),
              c(predic$vol$vol1$r.squared.q975,predic$vol$vol3$r.squared.q975,predic$vol$vol5$r.squared.q975,predic$vol$vol10$r.squared.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('R^2$',
                  'R^2_{BY}(50%)',
                  'R^2_{BKY}(50%)',
                  'R^2_{NSS}(50%)',
                  'R^2_{NSS}(2.5%)',
                  'R^2_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_VolatilityRsquaredNAPi.',allData$countryNames[countryToUse],'.csv',sep="")  )
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
  ## Model Volatility: coefficients
  Table <- cbind(c(NA,NA,NA,NA),
          c(NA,NA,NA,NA),
          c(NA,NA,NA,NA),
          c(predic$modelVol$modelVol1$beta.median,predic$modelVol$modelVol3$beta.median,predic$modelVol$modelVol5$beta.median,predic$modelVol$modelVol10$beta.median),
          c(predic$modelVol$modelVol1$beta.q025,predic$modelVol$modelVol3$beta.q025,predic$modelVol$modelVol5$beta.q025,predic$modelVol$modelVol10$beta.q025),
          c(predic$modelVol$modelVol1$beta.q975,predic$modelVol$modelVol3$beta.q975,predic$modelVol$modelVol5$beta.q975,predic$modelVol$modelVol10$beta.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('beta',
                  'beta_{BY}(50%)',
                  'beta_{BKY}(50%)',
                  'beta_{NSS}(50%)',
                  'beta_{NSS}(2.5%)',
                  'beta_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_ModelVolatilityBetaNAPi.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
  ## Model Volatility: R-squared
  Table <- cbind(c(NA,NA,NA,NA),
          c(NA,NA,NA,NA),
          c(NA,NA,NA,NA),
          c(predic$modelVol$modelVol1$r.squared.median,predic$modelVol$modelVol3$r.squared.median,predic$modelVol$modelVol5$r.squared.median,predic$modelVol$modelVol10$r.squared.median),
          c(predic$modelVol$modelVol1$r.squared.q025,predic$modelVol$modelVol3$r.squared.q025,predic$modelVol$modelVol5$r.squared.q025,predic$modelVol$modelVol10$r.squared.q025),
          c(predic$modelVol$modelVol1$r.squared.q975,predic$modelVol$modelVol3$r.squared.q975,predic$modelVol$modelVol5$r.squared.q975,predic$modelVol$modelVol10$r.squared.q975))
  TableXLS <- Table
  dimnames(TableXLS)[[2]] <- c('R^2$',
                  'R^2_{BY}(50%)',
                  'R^2_{BKY}(50%)',
                  'R^2_{NSS}(50%)',
                  'R^2_{NSS}(2.5%)',
                  'R^2_{NSS}(97.5%)')
  dimnames(TableXLS)[[1]] <- c('1','3','5','10')
  # XLS
  filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_ModelVolatilityRsquaredNAPi.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
}

## Compute and save varios impulse reponse functions
################################################################################
computeAndSaveImpulseResponses  <- function(allData,
                                            countryToUse,
                                            outputEZW,
                                            controlVarNAPi,
                                            bigDataPosInfo)
{
  ## Impulse Responses
  IR_XXW      <- impulseResponseGeneric(outputEZW,controlVarNAPi,bigDataPosInfo,'XXW')

  IR_XX       <- impulseResponseGeneric(outputEZW,controlVarNAPi,bigDataPosInfo,'XX')
  IR_SigmaSqW <- impulseResponseGeneric(outputEZW,controlVarNAPi,bigDataPosInfo,'SigmaSqW')
  IR_SigmaSq  <- impulseResponseGeneric(outputEZW,controlVarNAPi,bigDataPosInfo,'SigmaSq')

  ## Save
  saveImpulseResponseXXW(allData,countryToUse,IR_XXW)
  saveImpulseResponseXX(allData,countryToUse,IR_XX)
  saveImpulseResponseSigmaSqW(allData,countryToUse,IR_SigmaSqW)
  saveImpulseResponseSigmaSq(allData,countryToUse,IR_SigmaSq)
  
  # ## Price Elasticities
  # PriceElasticityXXW      <- elasticitiesHB(outputEZW,controlVarNAPi,bigDataPosInfo,'XXW')
  # PriceElasticityXX       <- elasticitiesHB(outputEZW,controlVarNAPi,bigDataPosInfo,'XX')
  # PriceElasticitySigmaSqW <- elasticitiesHB(outputEZW,controlVarNAPi,bigDataPosInfo,'SigmaSqW')
  # PriceElasticitySigmaSq  <- elasticitiesHB(outputEZW,controlVarNAPi,bigDataPosInfo,'SigmaSq')
  # ## Save
  # savePriceElasticityXXW(allData,countryToUse,PriceElasticityXXW)
  # savePriceElasticityXX(allData,countryToUse,PriceElasticityXX)
  # savePriceElasticitySigmaSqW(allData,countryToUse,PriceElasticitySigmaSqW)
  # savePriceElasticitySigmaSq(allData,countryToUse,PriceElasticitySigmaSq)
}

impulseResponseGeneric <- function(outputEZW,
                      controlVarNAPi,
                      UnobsPosInfo,
                      typeOfShock,
                      nSimImpulseResponse = 30)
{
  ## Checks if correct type of shock
  if (!(typeOfShock %in% c('XX','XXW','Nu','SigmaSq','SigmaSqW'))) {
    stop('No such shock \n\n')
  }

  ## The following supplementary function is only used to compute impulse responses
  getCurPos <- function(Nu, XX, SigmaSq, XXW, SigmaSqW){
    curNu       <- which(Nu[1]       == fineStateGridNu)
    curXX       <- which(XX[1]       == fineStateGridXX)
    curSigmaSq  <- which(SigmaSq[1]  == fineStateGridSigmaSq)
    curXXW      <- which(XXW[1]      == fineStateGridXXW)
    curSigmaSqW <- which(SigmaSqW[1] == fineStateGridSigmaSqW)

    curPos <- ((curSigmaSqW - 1) * nFineStateGridXXW * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                        (curXXW-1) * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                                  (curSigmaSq-1) * nFineStateGridXX * nFineStateGridNu +
                                            (curXX - 1) * nFineStateGridNu +
                                                          curNu)
    return(curPos)
  }

  ## Read grid parameters
  fineStateGridList        <- createFineStateGrid(countryToUse,  controlVarNAPi, ParEst, UnobsPosInfo)

  fineStateGridNu          <- fineStateGridList$gridNu
  fineStateGridXX          <- fineStateGridList$gridXX
  fineStateGridXXW         <- fineStateGridList$gridXXW
  fineStateGridSigmaSq     <- fineStateGridList$gridSigmaSq
  fineStateGridSigmaSqW    <- fineStateGridList$gridSigmaSqW

  nFineStateGridNu         <- length(fineStateGridNu)
  nFineStateGridXX         <- length(fineStateGridXX)
  nFineStateGridXXW        <- length(fineStateGridXXW)
  nFineStateGridSigmaSq    <- length(fineStateGridSigmaSq)
  nFineStateGridSigmaSqW   <- length(fineStateGridSigmaSqW)

  ## Read price-dividend functions
  PDivs                    <- outputEZW$PDivs
  PDivsLeveredXXeq         <- outputEZW$PDivs$LeveredXXeq
  PDivsOnePerBond          <- outputEZW$PDivs$OnePerBond

  ## Read utility parameters and Leveres asset parameter
  gammaU                   <- controlVarNAPi$gammaU     # Risk-Aversion
  psiU                     <- controlVarNAPi$psiU       # Intertemporal Elasticity of Substitution
  rhoU                     <- controlVarNAPi$rhoU       # Discount Rate
  thetaU                   <- controlVarNAPi$thetaU
  phi                      <- controlVarNAPi$phi
  cutOff                   <- controlVarNAPi$cutOff

  ## Read consumption process parameters
  ParEst                   <- outputEZW$ParEst
  sigmaSqOmega             <- ParEst[bigDataPosInfo$sigmaSqOmega]
  sigmaSqOmegaW            <- ParEst[bigDataPosInfo$sigmaSqOmegaW]
  gammma                   <- ParEst[bigDataPosInfo$gammma]
  rho                      <- ParEst[bigDataPosInfo$rho]
  rhoW                     <- ParEst[bigDataPosInfo$rhoW]
  xi                       <- ParEst[bigDataPosInfo$xi][countryToUse]
  lambda                   <- ParEst[bigDataPosInfo$lambda]
  lambdaW                  <- ParEst[bigDataPosInfo$lambdaW]
  mu                       <- ParEst[bigDataPosInfo$mu][countryToUse]
  chiSq                    <- ParEst[bigDataPosInfo$chiSq][countryToUse]
  chiSqW                   <- ParEst[bigDataPosInfo$chiSqW]
  sigmaSqNu                <- ParEst[bigDataPosInfo$sigmaSqNu][countryToUse]
  sigmaSqConst             <- ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW            <- ParEst[bigDataPosInfo$sigmaSqConstW]

  ## Initialize state variables, Eta shocks, consumption and dividend processes
  EtaW                     <- rep(0,            nSimImpulseResponse)
  Eta                      <- rep(0,            nSimImpulseResponse)
  Nu                       <- rep(0,            nSimImpulseResponse)
  XXW                      <- rep(0,            nSimImpulseResponse)
  XX                       <- rep(0,            nSimImpulseResponse)
  SigmaSqW                 <- rep(sigmaSqConstW,nSimImpulseResponse)
  SigmaSq                  <- rep(sigmaSqConst, nSimImpulseResponse)
  EpsW                     <- rep(0,            nSimImpulseResponse)
  Eps                      <- rep(0,            nSimImpulseResponse)
  omegaW                   <- rep(0,            nSimImpulseResponse)
  omega                    <- rep(0,            nSimImpulseResponse)
  YY                       <- rep(0,            nSimImpulseResponse)
  CC                       <- rep(0,            nSimImpulseResponse)
  DD                       <- rep(0,            nSimImpulseResponse)

  ## Simulate model: shocks occurs in the second period
  if (typeOfShock == 'XXW')      EpsW[2]   <- sqrt(sigmaSqConstW)
  if (typeOfShock == 'XX')       Eps[2]    <- sqrt(sigmaSqConst + sigmaSqConstW)
  if (typeOfShock == 'SigmaSqW') omegaW[2] <- sqrt(sigmaSqOmegaW)
  if (typeOfShock == 'SigmaSq')  omega[2]  <- sqrt(sigmaSqOmega)

  for (ii in 2:nSimImpulseResponse) {
    XXW[ii]      <- rhoW * XXW[ii-1] + EpsW[ii]
    XX[ii]       <- rhoW * XX[ii-1] + Eps[ii]
    SigmaSqW[ii] <- sigmaSqConstW + gammma * (SigmaSqW[ii-1] - sigmaSqConstW) + omegaW[ii]
    SigmaSq[ii]  <- sigmaSqConst + gammma * (SigmaSq[ii-1] - sigmaSqConst) + omega[ii]
    YY[ii]       <- YY[ii-1] + mu + XX[ii-1] + xi*XXW[ii-1] + Eta[ii] + xi* EtaW[ii]
    CC[ii]       <- YY[ii] + Nu[ii]
    DD[ii]       <- DD[ii-1] + mu + phi * (XX[ii-1] + xi*XXW[ii-1] + Eta[ii] + xi*EtaW[ii])
  }

  ## Put simulation on the grid
  NuOnFineGrid             <- numeric(nSimImpulseResponse)
  XXOnFineGrid             <- numeric(nSimImpulseResponse)
  XXWOnFineGrid            <- numeric(nSimImpulseResponse)
  SigmaSqOnFineGrid        <- numeric(nSimImpulseResponse)
  SigmaSqWOnFineGrid       <- numeric(nSimImpulseResponse)

  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes     <- matrix(FALSE,nFineStateGridSigmaSqW  ,nFineStateGridSigmaSq)
  for (iiSigmaSq in (1:nFineStateGridSigmaSq)){
    fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[,iiSigmaSq]   <- (fineStateGridSigmaSq[iiSigmaSq] + fineStateGridSigmaSqW >= cutOff)
  }

  for (ii in 1:nSimImpulseResponse) {
    NuInd              <- which.min(abs(fineStateGridNu-Nu[ii]))
    NuOnFineGrid[ii]   <- fineStateGridNu[NuInd]

    XXInd              <- which.min(abs(fineStateGridXX-XX[ii]))
    XXOnFineGrid[ii]   <- fineStateGridXX[XXInd]

    XXWInd             <- which.min(abs(fineStateGridXXW-XXW[ii]))
    XXWOnFineGrid[ii]  <- fineStateGridXXW[XXWInd]

    SigmaSqInd         <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
    SigmaSqWInd        <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))

    if (fineStateGridSigmaSq[SigmaSqInd] + fineStateGridSigmaSqW[SigmaSqWInd] >= cutOff){
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- fineStateGridSigmaSq[SigmaSqInd]
    } else {
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- min(fineStateGridSigmaSq[fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[SigmaSqWInd,]])
      SigmaSqInd             <- which.min(abs(SigmaSqOnFineGrid[ii] - SigmaSq[ii]))
    }
  }

  ## Create upper and lower traces (this is used for the out-of-the-grid interpolation)
  if (typeOfShock == 'XXW') {
    XXWOnFineGrid.high       <- numeric(nSimImpulseResponse)
    XXWOnFineGrid.low        <- numeric(nSimImpulseResponse)
    for (ii in 1:nSimImpulseResponse) {
      if (min(abs(fineStateGridXXW - XXW[ii]))==0) {
        XXWOnFineGrid.high[ii]           <- XXW[ii]
        XXWOnFineGrid.low[ii]            <- XXW[ii]
      } else {
        XXWInd.firstClosest              <- which.min(abs(fineStateGridXXW-XXW[ii]))
        XXWOnFineGrid.firstClosest       <- fineStateGridXXW[XXWInd.firstClosest]
        XXWInd.secondClosest             <- which.min(abs(fineStateGridXXW[-c(XXWInd.firstClosest)]-XXW[ii]))
        XXWOnFineGrid.secondClosest      <- fineStateGridXXW[-c(XXWInd.firstClosest)][XXWInd.secondClosest]
        XXWOnFineGrid.high[ii]           <- max(XXWOnFineGrid.firstClosest,XXWOnFineGrid.secondClosest)
        XXWOnFineGrid.low[ii]            <- min(XXWOnFineGrid.firstClosest,XXWOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'XX') {
    XXOnFineGrid.high       <- numeric(nSimImpulseResponse)
    XXOnFineGrid.low        <- numeric(nSimImpulseResponse)
    for (ii in 1:nSimImpulseResponse) {
      if (min(abs(fineStateGridXX - XX[ii]))==0) {
        XXOnFineGrid.high[ii]            <- XX[ii]
        XXOnFineGrid.low[ii]             <- XX[ii]
      } else {
        XXInd.firstClosest               <- which.min(abs(fineStateGridXX-XX[ii]))
        XXOnFineGrid.firstClosest        <- fineStateGridXX[XXInd.firstClosest]
        XXInd.secondClosest              <- which.min(abs(fineStateGridXX[-c(XXInd.firstClosest)]-XX[ii]))
        XXOnFineGrid.secondClosest       <- fineStateGridXX[-c(XXInd.firstClosest)][XXInd.secondClosest]
        XXOnFineGrid.high[ii]            <- max(XXOnFineGrid.firstClosest,XXOnFineGrid.secondClosest)
        XXOnFineGrid.low[ii]             <- min(XXOnFineGrid.firstClosest,XXOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'SigmaSqW') {
    SigmaSqWOnFineGrid.high       <- numeric(nSimImpulseResponse)
    SigmaSqWOnFineGrid.low        <- numeric(nSimImpulseResponse)
    for (ii in 1:nSimImpulseResponse) {
      if (min(abs(fineStateGridSigmaSqW - SigmaSqW[ii]))==0) {
        SigmaSqWOnFineGrid.high[ii]      <- SigmaSqW[ii]
        SigmaSqWOnFineGrid.low[ii]       <- SigmaSqW[ii]
      } else {
        SigmaSqWInd.firstClosest         <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))
        SigmaSqWOnFineGrid.firstClosest  <- fineStateGridSigmaSqW[SigmaSqWInd.firstClosest]
        SigmaSqWInd.secondClosest        <- which.min(abs(fineStateGridSigmaSqW[-c(SigmaSqWInd.firstClosest)]-SigmaSqW[ii]))
        SigmaSqWOnFineGrid.secondClosest <- fineStateGridSigmaSqW[-c(SigmaSqWInd.firstClosest)][SigmaSqWInd.secondClosest]
        SigmaSqWOnFineGrid.high[ii]      <- max(SigmaSqWOnFineGrid.firstClosest,SigmaSqWOnFineGrid.secondClosest)
        SigmaSqWOnFineGrid.low[ii]       <- min(SigmaSqWOnFineGrid.firstClosest,SigmaSqWOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'SigmaSq') {
    SigmaSqOnFineGrid.high       <- numeric(nSimImpulseResponse)
    SigmaSqOnFineGrid.low        <- numeric(nSimImpulseResponse)
    for (ii in 1:nSimImpulseResponse) {
      if (min(abs(fineStateGridSigmaSq - SigmaSq[ii]))==0) {
        SigmaSqOnFineGrid.high[ii]       <- SigmaSq[ii]
        SigmaSqOnFineGrid.low[ii]        <- SigmaSq[ii]
      } else {
        SigmaSqInd.firstClosest          <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
        SigmaSqOnFineGrid.firstClosest   <- fineStateGridSigmaSq[SigmaSqInd.firstClosest]
        SigmaSqInd.secondClosest         <- which.min(abs(fineStateGridSigmaSq[-c(SigmaSqInd.firstClosest)]-SigmaSq[ii]))
        SigmaSqOnFineGrid.secondClosest  <- fineStateGridSigmaSq[-c(SigmaSqInd.firstClosest)][SigmaSqInd.secondClosest]
        SigmaSqOnFineGrid.high[ii]       <- max(SigmaSqOnFineGrid.firstClosest,SigmaSqOnFineGrid.secondClosest)
        SigmaSqOnFineGrid.low[ii]        <- min(SigmaSqOnFineGrid.firstClosest,SigmaSqOnFineGrid.secondClosest)
      }
    }
  }

  ## Initialize endogenous variables
  DGrowth             <- c(exp(mu),numeric(nSimImpulseResponse-1))
  CGrowth             <- c(exp(mu),numeric(nSimImpulseResponse-1))
  REq                 <- numeric(nSimImpulseResponse)
  PDivEq              <- numeric(nSimImpulseResponse)

  if (controlVarNAPi$getOnePerBond == 1) {
    RBond           <- numeric(nSimImpulseResponse)
    PDivBond        <- numeric(nSimImpulseResponse)
  }

  if (controlVarNAPi$getLeveredXXEq == 1) {
    RLeveredXXEq    <- numeric(nSimImpulseResponse)
    PDivLeveredXXEq <- numeric(nSimImpulseResponse)
  }

  ## Produce various returns
  if (typeOfShock == 'XXW') {
    if (XXWOnFineGrid.high[1] == XXWOnFineGrid.low[1]) {
      PDivEqCur          <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])])
    } else {
      PDivEqCur.high     <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])])
      PDivEqCur.low      <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.low[1],SigmaSqWOnFineGrid[1])])

      ff                 <- approxfun(c(XXWOnFineGrid.low[1],XXWOnFineGrid.high[1]),c(PDivEqCur.low,PDivEqCur.high))
      PDivEqCur          <- ff(XXW[1])
    }

    PDivEqOld          <- PDivEqCur
    PDivEq[1]          <- PDivEqCur
    REq[1]             <- exp(mu)*PDivEqOld^(-1)*(1+PDivEqCur)

    if (controlVarNAPi$getOnePerBond == 1) {
      if (XXWOnFineGrid.high[1] == XXWOnFineGrid.low[1]) {
        PDivBondCur          <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])])
      } else {
        PDivBondCur.high     <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])])
        PDivBondCur.low      <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.low[1],SigmaSqWOnFineGrid[1])])

        ff                   <- approxfun(c(XXWOnFineGrid.low[1],XXWOnFineGrid.high[1]),c(PDivBondCur.low,PDivBondCur.high))
        PDivBondCur          <- ff(XXW[1])
      }

      PDivBondOld          <- PDivBondCur
      PDivBond[1]          <- PDivBondCur
      RBond[1]             <- PDivBondOld^(-1)

    }
    if (controlVarNAPi$getLeveredXXEq == 1) {
      if (XXWOnFineGrid.high[1] == XXWOnFineGrid.low[1]) {
        PDivLeveredXXEqCur        <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])])
      } else {
        PDivLeveredXXEqCur.high <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])])
        PDivLeveredXXEqCur.low  <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.low[1],SigmaSqWOnFineGrid[1])])

        ff                      <- approxfun(c(XXWOnFineGrid.low[1],XXWOnFineGrid.high[1]),c(PDivLeveredXXEqCur.low,PDivLeveredXXEqCur.high))
        PDivLeveredXXEqCur      <- ff(XXW[1])
      }

      PDivLeveredXXEqOld      <- PDivLeveredXXEqCur
      PDivLeveredXXEq[1]      <- PDivLeveredXXEqCur
      RLeveredXXEq[1]         <- exp(mu)*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEq[1])
    }

    for (ii in 2:nSimImpulseResponse) {
      PDivEqCur.high           <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid.high[ii],SigmaSqWOnFineGrid[ii])])
      PDivEqCur.low            <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid.low[ii],SigmaSqWOnFineGrid[ii])])

      ff                       <- approxfun(c(XXWOnFineGrid.low[ii],XXWOnFineGrid.high[ii]),c(PDivEqCur.low,PDivEqCur.high))
      PDivEqCur                <- ff(XXW[ii])

      REq[ii]                  <- exp(CC[ii] - CC[ii-1])*PDivEqOld^(-1)*(1+PDivEqCur)

      PDivEq[ii]               <- PDivEqCur
      PDivEqOld                <- PDivEqCur

      CGrowth[ii]              <- exp(CC[ii] - CC[ii-1])
      DGrowth[ii]              <- exp(DD[ii] - DD[ii-1])

      if (controlVarNAPi$getOnePerBond == 1) {
        PDivBondCur.high     <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid.high[ii],SigmaSqWOnFineGrid[ii])])
        PDivBondCur.low      <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid.low[ii],SigmaSqWOnFineGrid[ii])])

        ff                   <- approxfun(c(XXWOnFineGrid.low[ii],XXWOnFineGrid.high[ii]),c(PDivBondCur.low,PDivBondCur.high))
        PDivBondCur          <- ff(XXW[ii])

        RBond[ii]            <- PDivBondOld^(-1)

        PDivBond[ii]         <- PDivBondCur
        PDivBondOld          <- PDivBondCur
      }
      if (controlVarNAPi$getLeveredXXEquity == 1) {
        PDivLeveredXXEqCur.high  <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid.high[ii],SigmaSqWOnFineGrid[ii])])
        PDivLeveredXXEqCur.low   <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid.low[ii],SigmaSqWOnFineGrid[ii])])

        ff                       <- approxfun(c(XXWOnFineGrid.low[ii],XXWOnFineGrid.high[ii]),c(PDivLeveredXXEqCur.low,PDivLeveredXXEqCur.high))
        PDivLeveredXXEqCur       <- ff(XXW[ii])

        RLeveredXXEq[ii]         <- exp(DD[ii] - DD[ii-1])*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEqCur)

        PDivLeveredXXEq[ii]      <- PDivLeveredXXEqCur
        PDivLeveredXXEqOld       <- PDivLeveredXXEqCur
      }
    }
  }

  if (typeOfShock == 'XX') {
    if (XXOnFineGrid.high[1] == XXOnFineGrid.low[1]) {
      PDivEqCur          <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
    } else {
      PDivEqCur.high     <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
      PDivEqCur.low      <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid.low[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])

      ff                 <- approxfun(c(XXOnFineGrid.low[1],XXOnFineGrid.high[1]),c(PDivEqCur.low,PDivEqCur.high))
      PDivEqCur          <- ff(XX[1])
    }

    PDivEqOld          <- PDivEqCur
    PDivEq[1]          <- PDivEqCur
    REq[1]             <- exp(mu)*PDivEqOld^(-1)*(1+PDivEqCur)

    if (controlVarNAPi$getOnePerBond == 1) {
      if (XXOnFineGrid.high[1] == XXOnFineGrid.low[1]) {
        PDivBondCur          <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
      } else {
        PDivBondCur.high     <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
        PDivBondCur.low      <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid.low[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])

        ff                   <- approxfun(c(XXOnFineGrid.low[1],XXOnFineGrid.high[1]),c(PDivBondCur.low,PDivBondCur.high))
        PDivBondCur          <- ff(XX[1])
      }

      PDivBondOld          <- PDivBondCur
      PDivBond[1]          <- PDivBondCur
      RBond[1]             <- PDivBondOld^(-1)

    }
    if (controlVarNAPi$getLeveredXXEq == 1) {
      if (XXOnFineGrid.high[1] == XXOnFineGrid.low[1]) {
        PDivLeveredXXEqCur      <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
      } else {
        PDivLeveredXXEqCur.high <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
        PDivLeveredXXEqCur.low  <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid.low[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])

        ff                      <- approxfun(c(XXOnFineGrid.low[1],XXOnFineGrid.high[1]),c(PDivLeveredXXEqCur.low,PDivLeveredXXEqCur.high))
        PDivLeveredXXEqCur      <- ff(XX[1])
      }

      PDivLeveredXXEqOld      <- PDivLeveredXXEqCur
      PDivLeveredXXEq[1]      <- PDivLeveredXXEqCur
      RLeveredXXEq[1]         <- exp(mu)*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEq[1])
    }

    for (ii in 2:nSimImpulseResponse) {
      PDivEqCur.high           <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[ii],XXOnFineGrid.high[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])
      PDivEqCur.low            <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[ii],XXOnFineGrid.low[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])

      ff                       <- approxfun(c(XXOnFineGrid.low[ii],XXOnFineGrid.high[ii]),c(PDivEqCur.low,PDivEqCur.high))
      PDivEqCur                <- ff(XX[ii])

      REq[ii]                  <- exp(CC[ii] - CC[ii-1])*PDivEqOld^(-1)*(1+PDivEqCur)

      PDivEq[ii]               <- PDivEqCur
      PDivEqOld                <- PDivEqCur

      CGrowth[ii]              <- exp(CC[ii] - CC[ii-1])
      DGrowth[ii]              <- exp(DD[ii] - DD[ii-1])

      if (controlVarNAPi$getOnePerBond == 1) {
        PDivBondCur.high     <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[ii],XXOnFineGrid.high[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])
        PDivBondCur.low      <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[ii],XXOnFineGrid.low[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])

        ff                   <- approxfun(c(XXOnFineGrid.low[ii],XXOnFineGrid.high[ii]),c(PDivBondCur.low,PDivBondCur.high))
        PDivBondCur          <- ff(XX[ii])

        RBond[ii]            <- PDivBondOld^(-1)

        PDivBond[ii]         <- PDivBondCur
        PDivBondOld          <- PDivBondCur
      }
      if (controlVarNAPi$getLeveredXXEquity == 1) {
        PDivLeveredXXEqCur.high  <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[ii],XXOnFineGrid.high[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])
        PDivLeveredXXEqCur.low   <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[ii],XXOnFineGrid.low[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])

        ff                       <- approxfun(c(XXOnFineGrid.low[ii],XXOnFineGrid.high[ii]),c(PDivLeveredXXEqCur.low,PDivLeveredXXEqCur.high))
        PDivLeveredXXEqCur       <- ff(XX[ii])

        RLeveredXXEq[ii]         <- exp(DD[ii] - DD[ii-1])*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEqCur)

        PDivLeveredXXEq[ii]      <- PDivLeveredXXEqCur
        PDivLeveredXXEqOld       <- PDivLeveredXXEqCur
      }
    }
  }
  if (typeOfShock == 'SigmaSqW') {
    if (SigmaSqWOnFineGrid.high[1] == SigmaSqWOnFineGrid.low[1]) {
      PDivEqCur          <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])])
    } else {
      PDivEqCur.high     <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])])
      PDivEqCur.low      <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.low[1])])

      ff                 <- approxfun(c(SigmaSqWOnFineGrid.low[1],SigmaSqWOnFineGrid.high[1]),c(PDivEqCur.low,PDivEqCur.high))
      PDivEqCur          <- ff(SigmaSqW[1])
    }
    PDivEqOld          <- PDivEqCur
    PDivEq[1]          <- PDivEqCur
    REq[1]             <- exp(mu)*PDivEqOld^(-1)*(1+PDivEqCur)
    if (controlVarNAPi$getOnePerBond == 1) {
      if (SigmaSqWOnFineGrid.high[1] == SigmaSqWOnFineGrid.low[1]) {
        PDivBondCur          <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])])
      } else {
        PDivBondCur.high     <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])])
        PDivBondCur.low      <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.low[1])])

        ff                   <- approxfun(c(SigmaSqWOnFineGrid.low[1],SigmaSqWOnFineGrid.high[1]),c(PDivBondCur.low,PDivBondCur.high))
        PDivBondCur          <- ff(SigmaSqW[1])
      }
      PDivBondOld          <- PDivBondCur
      PDivBond[1]          <- PDivBondCur
      RBond[1]             <- PDivBondOld^(-1)
    }
    if (controlVarNAPi$getLeveredXXEq == 1) {
      if (SigmaSqWOnFineGrid.high[1] == SigmaSqWOnFineGrid.low[1]) {
        PDivLeveredXXEqCur      <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])])
      } else {
        PDivLeveredXXEqCur.high <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])])
        PDivLeveredXXEqCur.low  <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.low[1])])

        ff                      <- approxfun(c(SigmaSqWOnFineGrid.low[1],SigmaSqWOnFineGrid.high[1]),c(PDivLeveredXXEqCur.low,PDivLeveredXXEqCur.high))
        PDivLeveredXXEqCur      <- ff(SigmaSqW[1])
      }
      PDivLeveredXXEqOld      <- PDivLeveredXXEqCur
      PDivLeveredXXEq[1]      <- PDivLeveredXXEqCur
      RLeveredXXEq[1]         <- exp(mu)*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEq[1])
    }

    for (ii in 2:nSimImpulseResponse) {
      PDivEqCur.high           <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid.high[ii])])
      PDivEqCur.low            <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid.low[ii])])

      ff                       <- approxfun(c(SigmaSqWOnFineGrid.low[ii],SigmaSqWOnFineGrid.high[ii]),c(PDivEqCur.low,PDivEqCur.high))
      PDivEqCur                <- ff(SigmaSqW[ii])

      REq[ii]                  <- exp(CC[ii] - CC[ii-1])*PDivEqOld^(-1)*(1+PDivEqCur)

      PDivEq[ii]               <- PDivEqCur
      PDivEqOld                <- PDivEqCur

      CGrowth[ii]              <- exp(CC[ii] - CC[ii-1])
      DGrowth[ii]              <- exp(DD[ii] - DD[ii-1])

      if (controlVarNAPi$getOnePerBond == 1) {
        PDivBondCur.high         <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid.high[ii])])
        PDivBondCur.low          <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid.low[ii])])

        ff                       <- approxfun(c(SigmaSqWOnFineGrid.low[ii],SigmaSqWOnFineGrid.high[ii]),c(PDivBondCur.low,PDivBondCur.high))
        PDivBondCur              <- ff(SigmaSqW[ii])

        RBond[ii]                <- PDivBondOld^(-1)

        PDivBond[ii]             <- PDivBondCur
        PDivBondOld              <- PDivBondCur
      }
      if (controlVarNAPi$getLeveredXXEquity == 1) {
        PDivLeveredXXEqCur.high  <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid.high[ii])])
        PDivLeveredXXEqCur.low   <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid.low[ii])])

        ff                       <- approxfun(c(SigmaSqWOnFineGrid.low[ii],SigmaSqWOnFineGrid.high[ii]),c(PDivLeveredXXEqCur.low,PDivLeveredXXEqCur.high))
        PDivLeveredXXEqCur       <- ff(SigmaSqW[ii])

        RLeveredXXEq[ii]         <- exp(DD[ii] - DD[ii-1])*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEqCur)

        PDivLeveredXXEq[ii]      <- PDivLeveredXXEqCur
        PDivLeveredXXEqOld       <- PDivLeveredXXEqCur
      }
    }
  }

  if (typeOfShock == 'SigmaSq') {
    if (SigmaSqOnFineGrid.high[1] == SigmaSqOnFineGrid.low[1]) {
      PDivEqCur          <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
    } else {
      PDivEqCur.high     <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
      PDivEqCur.low      <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.low[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])

      ff                 <- approxfun(c(SigmaSqOnFineGrid.low[1],SigmaSqOnFineGrid.high[1]),c(PDivEqCur.low,PDivEqCur.high))
      PDivEqCur          <- ff(SigmaSq[1])
    }

    PDivEqOld          <- PDivEqCur
    PDivEq[1]          <- PDivEqCur

    REq[1]            <- exp(mu)*PDivEqOld^(-1)*(1+PDivEqCur)

    if (controlVarNAPi$getOnePerBond == 1) {
      if (SigmaSqOnFineGrid.high[1] == SigmaSqOnFineGrid.low[1]) {
        PDivBondCur          <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
      } else {
        PDivBondCur.high     <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
        PDivBondCur.low      <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.low[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])

        ff                   <- approxfun(c(SigmaSqOnFineGrid.low[1],SigmaSqOnFineGrid.high[1]),c(PDivBondCur.low,PDivBondCur.high))
        PDivBondCur          <- ff(SigmaSq[1])
      }
      PDivBondOld          <- PDivBondCur
      PDivBond[1]          <- PDivBondCur
      RBond[1]             <- PDivBondOld^(-1)

    }
    if (controlVarNAPi$getLeveredXXEq == 1) {
      if (SigmaSqOnFineGrid.high[1] == SigmaSqOnFineGrid.low[1]) {
        PDivLeveredXXEqCur      <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
      } else {
        PDivLeveredXXEqCur.high <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
        PDivLeveredXXEqCur.low  <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.low[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])

        ff                      <- approxfun(c(SigmaSqOnFineGrid.low[1],SigmaSqOnFineGrid.high[1]),c(PDivLeveredXXEqCur.low,PDivLeveredXXEqCur.high))
        PDivLeveredXXEqCur      <- ff(SigmaSq[1])
      }

      PDivLeveredXXEqOld      <- PDivLeveredXXEqCur
      PDivLeveredXXEq[1]      <- PDivLeveredXXEqCur
      RLeveredXXEq[1]         <- exp(mu)*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEq[1])
    }

    for (ii in 2:nSimImpulseResponse) {
      PDivEqCur.high           <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid.high[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])
      PDivEqCur.low            <- exp(PDivs$Equity[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid.low[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])

      ff                       <- approxfun(c(SigmaSqOnFineGrid.low[ii],SigmaSqOnFineGrid.high[ii]),c(PDivEqCur.low,PDivEqCur.high))
      PDivEqCur                <- ff(SigmaSq[ii])

      REq[ii]                  <- exp(CC[ii] - CC[ii-1])*PDivEqOld^(-1)*(1+PDivEqCur)

      PDivEq[ii]               <- PDivEqCur
      PDivEqOld                <- PDivEqCur

      CGrowth[ii]              <- exp(CC[ii] - CC[ii-1])
      DGrowth[ii]              <- exp(DD[ii] - DD[ii-1])

      if (controlVarNAPi$getOnePerBond == 1) {
        PDivBondCur.high     <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid.high[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])
        PDivBondCur.low      <- exp(PDivs$OnePerBond[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid.low[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])

        ff                   <- approxfun(c(SigmaSqOnFineGrid.low[ii],SigmaSqOnFineGrid.high[ii]),c(PDivBondCur.low,PDivBondCur.high))
        PDivBondCur          <- ff(SigmaSq[ii])

        RBond[ii]            <- PDivBondOld^(-1)

        PDivBond[ii]         <- PDivBondCur
        PDivBondOld          <- PDivBondCur
      }
      if (controlVarNAPi$getLeveredXXEquity == 1) {
        PDivLeveredXXEqCur.high  <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid.high[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])
        PDivLeveredXXEqCur.low   <- exp(PDivs$LeveredXXEq[getCurPos(NuOnFineGrid[ii],XXOnFineGrid[ii],SigmaSqOnFineGrid.low[ii],XXWOnFineGrid[ii],SigmaSqWOnFineGrid[ii])])

        ff                       <- approxfun(c(SigmaSqOnFineGrid.low[ii],SigmaSqOnFineGrid.high[ii]),c(PDivLeveredXXEqCur.low,PDivLeveredXXEqCur.high))
        PDivLeveredXXEqCur       <- ff(SigmaSq[ii])

        RLeveredXXEq[ii]         <- exp(DD[ii] - DD[ii-1])*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEqCur)

        PDivLeveredXXEq[ii]      <- PDivLeveredXXEqCur
        PDivLeveredXXEqOld       <- PDivLeveredXXEqCur
      }
    }
  }
  ## Write Output
  output <- list(Equity   = list(Return = REq, PDiv = PDivEq),
           CGrowth  = CGrowth,
           DGrowth  = DGrowth,
           XXW      = XXW,
           XX       = XX,
           SigmaSqW = SigmaSqW,
           SigmaSq  = SigmaSq)

  if (typeOfShock == 'XXW') {
    output$XXWOnFineGrid.high      <- XXWOnFineGrid.high
    output$XXWOnFineGrid.low       <- XXWOnFineGrid.low
  }
  if (typeOfShock == 'XX') {
    output$XXOnFineGrid.high       <- XXOnFineGrid.high
    output$XXOnFineGrid.low        <- XXOnFineGrid.low
  }
  if (typeOfShock == 'SigmaSqW') {
    output$SigmaSqWOnFineGrid.high <- SigmaSqWOnFineGrid.high
    output$SigmaSqWOnFineGrid.low  <- SigmaSqWOnFineGrid.low
  }
  if (typeOfShock == 'SigmaSq') {
    output$SigmaSqOnFineGrid.high  <- SigmaSqOnFineGrid.high
    output$SigmaSqOnFineGrid.low   <- SigmaSqOnFineGrid.low
  }

  if (controlVarNAPi$getOnePerBond == 1) {
    output$OnePerBond        <- list(Return = RBond,
                     PDiv   = PDivBond)
  }
  if (controlVarNAPi$getLeveredXXEq == 1) {
    output$LeveredXXEq       <- list(Return = RLeveredXXEq,
                     PDiv   = PDivLeveredXXEq)
  }
  return(output)
}

elasticitiesHB  <- function(outputEZW,
                      controlVarNAPi,
                      UnobsPosInfo,
                      typeOfShock)
{
  ## Checks if correct type of shock
  if (!(typeOfShock %in% c('XX','XXW','Nu','SigmaSq','SigmaSqW'))) {
    stop('No such shock \n\n')
  }
  ## The following supplementary function is only used to compute impulse responses
  getCurPos <- function(Nu, XX, SigmaSq, XXW, SigmaSqW){
    curNu       <- which(Nu[1]       == fineStateGridNu)
    curXX       <- which(XX[1]       == fineStateGridXX)
    curSigmaSq  <- which(SigmaSq[1]  == fineStateGridSigmaSq)
    curXXW      <- which(XXW[1]      == fineStateGridXXW)
    curSigmaSqW <- which(SigmaSqW[1] == fineStateGridSigmaSqW)

    curPos <- ((curSigmaSqW - 1) * nFineStateGridXXW * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                        (curXXW-1) * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                                  (curSigmaSq-1) * nFineStateGridXX * nFineStateGridNu +
                                            (curXX - 1) * nFineStateGridNu +
                                                          curNu)
    return(curPos)
  }
  ## Read grid parameters
  fineStateGridList        <- createFineStateGrid(countryToUse,  controlVarNAPi, ParEst, UnobsPosInfo)

  fineStateGridNu          <- fineStateGridList$gridNu
  fineStateGridXX          <- fineStateGridList$gridXX
  fineStateGridXXW         <- fineStateGridList$gridXXW
  fineStateGridSigmaSq     <- fineStateGridList$gridSigmaSq
  fineStateGridSigmaSqW    <- fineStateGridList$gridSigmaSqW

  nFineStateGridNu         <- length(fineStateGridNu)
  nFineStateGridXX         <- length(fineStateGridXX)
  nFineStateGridXXW        <- length(fineStateGridXXW)
  nFineStateGridSigmaSq    <- length(fineStateGridSigmaSq)
  nFineStateGridSigmaSqW   <- length(fineStateGridSigmaSqW)

  ## Read price-dividend functions
  PDivs                    <- outputEZW$PDivs
  PDivsTPerRiskyBond      <- outputEZW$PDivs$TPerRiskyBond

  ## Read utility parameters and Leveres asset parameter
  gammaU                   <- controlVarNAPi$gammaU     # Risk-Aversion
  psiU                     <- controlVarNAPi$psiU       # Intertemporal Elasticity of Substitution
  rhoU                     <- controlVarNAPi$rhoU       # Discount Rate
  thetaU                   <- controlVarNAPi$thetaU
  phi                      <- controlVarNAPi$phi
  cutOff                   <- controlVarNAPi$cutOff

  ## Read consumption process parameters
  ParEst                   <- outputEZW$ParEst
  sigmaSqOmega             <- ParEst[bigDataPosInfo$sigmaSqOmega]
  sigmaSqOmegaW            <- ParEst[bigDataPosInfo$sigmaSqOmegaW]
  gammma                   <- ParEst[bigDataPosInfo$gammma]
  rho                      <- ParEst[bigDataPosInfo$rho]
  rhoW                     <- ParEst[bigDataPosInfo$rhoW]
  xi                       <- ParEst[bigDataPosInfo$xi][countryToUse]
  lambda                   <- ParEst[bigDataPosInfo$lambda]
  lambdaW                  <- ParEst[bigDataPosInfo$lambdaW]
  mu                       <- ParEst[bigDataPosInfo$mu][countryToUse]
  chiSq                    <- ParEst[bigDataPosInfo$chiSq][countryToUse]
  chiSqW                   <- ParEst[bigDataPosInfo$chiSqW]
  sigmaSqNu                <- ParEst[bigDataPosInfo$sigmaSqNu][countryToUse]
  sigmaSqConst             <- ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW            <- ParEst[bigDataPosInfo$sigmaSqConstW]

  ## Read some techinical parameters
  maxMaturityTPerBonds <- controlVarNAPi$maxMaturityTPerBonds

  ## Initialize state variables and dividend processes
  Nu                       <- rep(0,            2)
  XXW                      <- rep(0,            2)
  XX                       <- rep(0,            2)
  SigmaSqW                 <- rep(sigmaSqConstW,2)
  SigmaSq                  <- rep(sigmaSqConst, 2)
  DD                       <- rep(0,            2)
  ## Simulate model: shocks occurs in the second period
  if (typeOfShock == 'XXW'){
    dh     <- 1*abs(fineStateGridXXW[2]-fineStateGridXXW[1])
    XXW[2] <- XXW[2] + dh
  }
  if (typeOfShock == 'XX'){
    dh <- 1*abs(fineStateGridXX[2]-fineStateGridXX[1])
    XX[2]        <- XX[2] + dh
  }
  if (typeOfShock == 'SigmaSqW'){
    dh <- 1*abs(fineStateGridSigmaSqW[2]-fineStateGridSigmaSqW[1])
    SigmaSqW[2]  <- SigmaSqW[2] + dh
  }
  if (typeOfShock == 'SigmaSq'){
    dh <- 1*abs(fineStateGridSigmaSq[2]-fineStateGridSigmaSq[1])
    SigmaSq[2]   <- SigmaSq[2] + dh
  }
  ## Put simulation on the grid
  NuOnFineGrid             <- numeric(2)
  XXOnFineGrid             <- numeric(2)
  XXWOnFineGrid            <- numeric(2)
  SigmaSqOnFineGrid        <- numeric(2)
  SigmaSqWOnFineGrid       <- numeric(2)

  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes     <- matrix(FALSE,nFineStateGridSigmaSqW  ,nFineStateGridSigmaSq)
  for (iiSigmaSq in (1:nFineStateGridSigmaSq)){
    fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[,iiSigmaSq]   <- (fineStateGridSigmaSq[iiSigmaSq] + fineStateGridSigmaSqW >= cutOff)
  }

  for (ii in c(1:2)) {
    NuInd              <- which.min(abs(fineStateGridNu-Nu[ii]))
    NuOnFineGrid[ii]   <- fineStateGridNu[NuInd]

    XXInd              <- which.min(abs(fineStateGridXX-XX[ii]))
    XXOnFineGrid[ii]   <- fineStateGridXX[XXInd]

    XXWInd             <- which.min(abs(fineStateGridXXW-XXW[ii]))
    XXWOnFineGrid[ii]  <- fineStateGridXXW[XXWInd]

    SigmaSqInd         <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
    SigmaSqWInd        <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))

    if (fineStateGridSigmaSq[SigmaSqInd] + fineStateGridSigmaSqW[SigmaSqWInd] >= cutOff){
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- fineStateGridSigmaSq[SigmaSqInd]
    } else {
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- min(fineStateGridSigmaSq[fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[SigmaSqWInd,]])
      SigmaSqInd             <- which.min(abs(SigmaSqOnFineGrid[ii] - SigmaSq[ii]))
    }
  }

  ## Create upper and lower traces (this is used for the out-of-the-grid interpolation)
  if (typeOfShock == 'XXW') {
    XXWOnFineGrid.high       <- numeric(2)
    XXWOnFineGrid.low        <- numeric(2)
    for (ii in 1:2) {
      if (min(abs(fineStateGridXXW - XXW[ii]))==0) {
        XXWOnFineGrid.high[ii]           <- XXW[ii]
        XXWOnFineGrid.low[ii]            <- XXW[ii]
      } else {
        XXWInd.firstClosest              <- which.min(abs(fineStateGridXXW-XXW[ii]))
        XXWOnFineGrid.firstClosest       <- fineStateGridXXW[XXWInd.firstClosest]
        XXWInd.secondClosest             <- which.min(abs(fineStateGridXXW[-c(XXWInd.firstClosest)]-XXW[ii]))
        XXWOnFineGrid.secondClosest      <- fineStateGridXXW[-c(XXWInd.firstClosest)][XXWInd.secondClosest]
        XXWOnFineGrid.high[ii]           <- max(XXWOnFineGrid.firstClosest,XXWOnFineGrid.secondClosest)
        XXWOnFineGrid.low[ii]            <- min(XXWOnFineGrid.firstClosest,XXWOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'XX') {
    XXOnFineGrid.high       <- numeric(2)
    XXOnFineGrid.low        <- numeric(2)
    for (ii in 1:2) {
      if (min(abs(fineStateGridXX - XX[ii]))==0) {
        XXOnFineGrid.high[ii]            <- XX[ii]
        XXOnFineGrid.low[ii]             <- XX[ii]
      } else {
        XXInd.firstClosest               <- which.min(abs(fineStateGridXX-XX[ii]))
        XXOnFineGrid.firstClosest        <- fineStateGridXX[XXInd.firstClosest]
        XXInd.secondClosest              <- which.min(abs(fineStateGridXX[-c(XXInd.firstClosest)]-XX[ii]))
        XXOnFineGrid.secondClosest       <- fineStateGridXX[-c(XXInd.firstClosest)][XXInd.secondClosest]
        XXOnFineGrid.high[ii]            <- max(XXOnFineGrid.firstClosest,XXOnFineGrid.secondClosest)
        XXOnFineGrid.low[ii]             <- min(XXOnFineGrid.firstClosest,XXOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'SigmaSqW') {
    SigmaSqWOnFineGrid.high       <- numeric(2)
    SigmaSqWOnFineGrid.low        <- numeric(2)
    for (ii in 1:2) {
      if (min(abs(fineStateGridSigmaSqW - SigmaSqW[ii]))==0) {
        SigmaSqWOnFineGrid.high[ii]      <- SigmaSqW[ii]
        SigmaSqWOnFineGrid.low[ii]       <- SigmaSqW[ii]
      } else {
        SigmaSqWInd.firstClosest         <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))
        SigmaSqWOnFineGrid.firstClosest  <- fineStateGridSigmaSqW[SigmaSqWInd.firstClosest]
        SigmaSqWInd.secondClosest        <- which.min(abs(fineStateGridSigmaSqW[-c(SigmaSqWInd.firstClosest)]-SigmaSqW[ii]))
        SigmaSqWOnFineGrid.secondClosest <- fineStateGridSigmaSqW[-c(SigmaSqWInd.firstClosest)][SigmaSqWInd.secondClosest]
        SigmaSqWOnFineGrid.high[ii]      <- max(SigmaSqWOnFineGrid.firstClosest,SigmaSqWOnFineGrid.secondClosest)
        SigmaSqWOnFineGrid.low[ii]       <- min(SigmaSqWOnFineGrid.firstClosest,SigmaSqWOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'SigmaSq') {
    SigmaSqOnFineGrid.high       <- numeric(2)
    SigmaSqOnFineGrid.low        <- numeric(2)
    for (ii in 1:2) {
      if (min(abs(fineStateGridSigmaSq - SigmaSq[ii]))==0) {
        SigmaSqOnFineGrid.high[ii]       <- SigmaSq[ii]
        SigmaSqOnFineGrid.low[ii]        <- SigmaSq[ii]
      } else {
        SigmaSqInd.firstClosest          <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
        SigmaSqOnFineGrid.firstClosest   <- fineStateGridSigmaSq[SigmaSqInd.firstClosest]
        SigmaSqInd.secondClosest         <- which.min(abs(fineStateGridSigmaSq[-c(SigmaSqInd.firstClosest)]-SigmaSq[ii]))
        SigmaSqOnFineGrid.secondClosest  <- fineStateGridSigmaSq[-c(SigmaSqInd.firstClosest)][SigmaSqInd.secondClosest]
        SigmaSqOnFineGrid.high[ii]       <- max(SigmaSqOnFineGrid.firstClosest,SigmaSqOnFineGrid.secondClosest)
        SigmaSqOnFineGrid.low[ii]        <- min(SigmaSqOnFineGrid.firstClosest,SigmaSqOnFineGrid.secondClosest)
      }
    }
  }
  ## Initialize endogenous variables
  if (controlVarNAPi$getTPerRiskyBond == 1) {
    PDivTPerRiskyBond           <- replicate(maxMaturityTPerBonds, numeric(2), simplify=F)
    PriceElasticityTPerRiskyBond <- numeric(maxMaturityTPerBonds)
  }
  ## Produce PD ratio for risky bonds after XXW shock
  if (typeOfShock == 'XXW') {
    if (controlVarNAPi$getTPerRiskyBond == 1) {
      for (ii in c(1:maxMaturityTPerBonds)){
        if (XXWOnFineGrid.high[1] == XXWOnFineGrid.low[1]) {
          PDivCur      <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])])
        } else {
          PDivCur.high <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])])
          PDivCur.low  <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.low[1],SigmaSqWOnFineGrid[1])])
          ff           <- approxfun(c(XXWOnFineGrid.low[1],XXWOnFineGrid.high[1]),c(PDivCur.low,PDivCur.high))
          PDivCur      <- ff(XXW[1])
        }
        PDivTPerRiskyBond[[ii]][1] <- PDivCur
      }
      for (ii in c(1:maxMaturityTPerBonds)){
        PDivCur.high                 <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[2],XXOnFineGrid[2],SigmaSqOnFineGrid[2],XXWOnFineGrid.high[2],SigmaSqWOnFineGrid[2])])
        PDivCur.low                  <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[2],XXOnFineGrid[2],SigmaSqOnFineGrid[2],XXWOnFineGrid.low[2],SigmaSqWOnFineGrid[2])])
        ff                           <- approxfun(c(XXWOnFineGrid.low[2],XXWOnFineGrid.high[2]),c(PDivCur.low,PDivCur.high))
        PDivCur                      <- ff(XXW[2])
        PDivTPerRiskyBond[[ii]][2]  <- PDivCur
        #PriceElasticityTPerRiskyBond[ii] <- (PDivTPerRiskyBond[[ii]][2]-PDivTPerRiskyBond[[ii]][1])/dh
        PriceElasticityTPerRiskyBond[ii] <- log(PDivTPerRiskyBond[[ii]][2]/PDivTPerRiskyBond[[ii]][1])/dh
      }
    }
  }
  ## Produce PD ratio for risky bonds after XX shock
  if (typeOfShock == 'XX') {
    if (controlVarNAPi$getTPerRiskyBond == 1) {
      for (ii in c(1:maxMaturityTPerBonds)){
        if (XXOnFineGrid.high[1] == XXOnFineGrid.low[1]) {
          PDivCur      <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
        } else {
          PDivCur.high <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
          PDivCur.low  <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid.low[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
          ff           <- approxfun(c(XXOnFineGrid.low[1],XXOnFineGrid.high[1]),c(PDivCur.low,PDivCur.high))
          PDivCur      <- ff(XX[1])
        }
        PDivTPerRiskyBond[[ii]][1] <- PDivCur
      }
      for (ii in c(1:maxMaturityTPerBonds)){
        PDivCur.high                 <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[2],XXOnFineGrid.high[2],SigmaSqOnFineGrid[2],XXWOnFineGrid[2],SigmaSqWOnFineGrid[2])])
        PDivCur.low                  <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[2],XXOnFineGrid.low[2],SigmaSqOnFineGrid[2],XXWOnFineGrid[2],SigmaSqWOnFineGrid[2])])
        ff                           <- approxfun(c(XXOnFineGrid.low[2],XXOnFineGrid.high[2]),c(PDivCur.low,PDivCur.high))
        PDivCur                      <- ff(XX[2])
        PDivTPerRiskyBond[[ii]][2]  <- PDivCur
        #PriceElasticityTPerRiskyBond[ii] <- (PDivTPerRiskyBond[[ii]][2]-PDivTPerRiskyBond[[ii]][1])/dh
        PriceElasticityTPerRiskyBond[ii] <- log(PDivTPerRiskyBond[[ii]][2]/PDivTPerRiskyBond[[ii]][1])/dh
      }
    }
  }
  ## Produce PD ratio for risky bonds after SigmaSqW shock
  if (typeOfShock == 'SigmaSqW') {
    if (controlVarNAPi$getTPerRiskyBond == 1) {
      for (ii in c(1:maxMaturityTPerBonds)){
        if (SigmaSqWOnFineGrid.high[1] == SigmaSqWOnFineGrid.low[1]) {
          PDivCur      <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])])
        } else {
          PDivCur.high <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])])
          PDivCur.low  <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.low[1])])
          ff           <- approxfun(c(SigmaSqWOnFineGrid.low[1],SigmaSqWOnFineGrid.high[1]),c(PDivCur.low,PDivCur.high))
          PDivCur      <- ff(SigmaSqW[1])
        }
        PDivTPerRiskyBond[[ii]][1] <- PDivCur
      }
      for (ii in c(1:maxMaturityTPerBonds)){
        PDivCur.high                 <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[2],XXOnFineGrid[2],SigmaSqOnFineGrid[2],XXWOnFineGrid[2],SigmaSqWOnFineGrid.high[2])])
        PDivCur.low                  <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[2],XXOnFineGrid[2],SigmaSqOnFineGrid[2],XXWOnFineGrid[2],SigmaSqWOnFineGrid.low[2])])
        ff                           <- approxfun(c(SigmaSqWOnFineGrid.low[2],SigmaSqWOnFineGrid.high[2]),c(PDivCur.low,PDivCur.high))
        PDivCur                      <- ff(SigmaSqW[2])
        PDivTPerRiskyBond[[ii]][2]  <- PDivCur
        #PriceElasticityTPerRiskyBond[ii] <- (PDivTPerRiskyBond[[ii]][2]-PDivTPerRiskyBond[[ii]][1])/dh
        PriceElasticityTPerRiskyBond[ii] <- log(PDivTPerRiskyBond[[ii]][2]/PDivTPerRiskyBond[[ii]][1])/dh
      }
    }
  }
  ## Produce PD ratio for risky bonds after SigmaSq shock
  if (typeOfShock == 'SigmaSq') {
    if (controlVarNAPi$getTPerRiskyBond == 1) {
      for (ii in c(1:maxMaturityTPerBonds)){
        if (SigmaSqOnFineGrid.high[1] == SigmaSqOnFineGrid.low[1]) {
          PDivCur      <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
        } else {
          PDivCur.high <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
          PDivCur.low  <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.low[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])])
          ff           <- approxfun(c(SigmaSqOnFineGrid.low[1],SigmaSqOnFineGrid.high[1]),c(PDivCur.low,PDivCur.high))
          PDivCur      <- ff(SigmaSq[1])
        }
        PDivTPerRiskyBond[[ii]][1] <- PDivCur
      }
      for (ii in c(1:maxMaturityTPerBonds)){
        PDivCur.high                 <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[2],XXOnFineGrid[2],SigmaSqOnFineGrid.high[2],XXWOnFineGrid[2],SigmaSqWOnFineGrid[2])])
        PDivCur.low                  <- exp(PDivsTPerRiskyBond[[ii]][getCurPos(NuOnFineGrid[2],XXOnFineGrid[2],SigmaSqOnFineGrid.low[2],XXWOnFineGrid[2],SigmaSqWOnFineGrid[2])])
        ff                           <- approxfun(c(SigmaSqOnFineGrid.low[2],SigmaSqOnFineGrid.high[2]),c(PDivCur.low,PDivCur.high))
        PDivCur                      <- ff(SigmaSq[2])
        PDivTPerRiskyBond[[ii]][2]  <- PDivCur
        #PriceElasticityTPerRiskyBond[ii] <- (PDivTPerRiskyBond[[ii]][2]-PDivTPerRiskyBond[[ii]][1])/dh
        PriceElasticityTPerRiskyBond[ii] <- log(PDivTPerRiskyBond[[ii]][2]/PDivTPerRiskyBond[[ii]][1])/dh
      }
    }
  }
  ## Write Output
  output <- list(XXW      = XXW,
           XX       = XX,
           SigmaSqW = SigmaSqW,
           SigmaSq  = SigmaSq)

  if (typeOfShock == 'XXW') {
    output$XXWOnFineGrid.high      <- XXWOnFineGrid.high
    output$XXWOnFineGrid.low       <- XXWOnFineGrid.low
  }
  if (typeOfShock == 'XX') {
    output$XXOnFineGrid.high       <- XXOnFineGrid.high
    output$XXOnFineGrid.low        <- XXOnFineGrid.low
  }
  if (typeOfShock == 'SigmaSqW') {
    output$SigmaSqWOnFineGrid.high <- SigmaSqWOnFineGrid.high
    output$SigmaSqWOnFineGrid.low  <- SigmaSqWOnFineGrid.low
  }
  if (typeOfShock == 'SigmaSq') {
    output$SigmaSqOnFineGrid.high  <- SigmaSqOnFineGrid.high
    output$SigmaSqOnFineGrid.low   <- SigmaSqOnFineGrid.low
  }
  if (controlVarNAPi$getTPerRiskyBond == 1) {
    output$TPerRiskyBond        <- list(PDiv            = PDivTPerRiskyBond,
                       PriceElasticity = PriceElasticityTPerRiskyBond)
  }
  return(output)
}

savePriceElasticityXXW <- function(allData,
                      countryToUse,
                      PriceElast)
{
  PriceElasticityTPerRiskyBond <-
      PriceElast$TPerRiskyBond$PriceElasticity

  filename <- file.path(outDir,
          paste(c('PriceElasticityXXW',
            allData$countryNames[countryToUse],'pdf'),
            collapse = '.'))

  pdf(filename, paper = 'special', width = 6, height = 7)

  par(mfrow = c(1, 1))

  plotds(1:length(PriceElasticityTPerRiskyBond),
      as.ts(PriceElasticityTPerRiskyBond),
      ylimTemp   = range(PriceElasticityTPerRiskyBond),
      title.x    = 'horizon',
      title.y    = 'elasticity')
  dev.off()
}

savePriceElasticityXX <- function(allData,
                      countryToUse,
                      PriceElast)
{
  PriceElasticityTPerRiskyBond <- PriceElast$TPerRiskyBond$PriceElasticity

  filename <- file.path(outDir,
              paste(c('PriceElasticityXX',
                allData$countryNames[countryToUse],
                'pdf'),
              collapse = '.'))

  pdf(filename, paper = 'special', width = 6, height = 7)

  par(mfrow = c(1, 1))

  plotds(1:length(PriceElasticityTPerRiskyBond),
      as.ts(PriceElasticityTPerRiskyBond),
      ylimTemp   = range(PriceElasticityTPerRiskyBond),
      title.x    = 'horizon',
      title.y    = 'elasticity')
  dev.off()
}

savePriceElasticitySigmaSqW <- function(allData,
                      countryToUse,
                      PriceElast)
{
  PriceElasticityTPerRiskyBond <- PriceElast$TPerRiskyBond$PriceElasticity

  filename <-  file.path(outDir, paste(c('PriceElasticitySigmaSqW', allData$countryNames[countryToUse], 'pdf'),collapse = '.'))
  pdf(filename, paper = 'special', width = 6, height = 7)
  par(mfrow = c(1, 1))

  plotds(1:length(PriceElasticityTPerRiskyBond),
      as.ts(PriceElasticityTPerRiskyBond),
      ylimTemp   = range(PriceElasticityTPerRiskyBond),
      title.x    = 'horizon',
      title.y    = 'elasticity')
  dev.off()
}

savePriceElasticitySigmaSq <- function(allData,
                      countryToUse,
                      PriceElast)
{
  PriceElasticityTPerRiskyBond <- PriceElast$TPerRiskyBond$PriceElasticity

  filename <-  file.path(outDir, paste(c('PriceElasticitySigmaSq', allData$countryNames[countryToUse], 'pdf'),collapse = '.'))
  pdf(filename, paper = 'special', width = 6, height = 7)
  par(mfrow = c(1, 1))

  plotds(1:length(PriceElasticityTPerRiskyBond),
      as.ts(PriceElasticityTPerRiskyBond),
      ylimTemp   = range(PriceElasticityTPerRiskyBond),
      title.x    = 'horizon',
      title.y    = 'elasticity')
  dev.off()
}

saveImpulseResponseXXW <- function(allData,
                      countryToUse,
                      IR)
{
  XXW                <- IR$XXW
  XXWOnFineGrid.high <- IR$XXWOnFineGrid.high
  XXWOnFineGrid.low  <- IR$XXWOnFineGrid.low
  CGrowth            <- IR$CGrowth
  DGrowth            <- IR$DGrowth
  Req                <- IR$Equity$Return
  PDivEq             <- IR$Equity$PDiv
  RBond              <- IR$OnePerBond$Return
  PDivOnePerBond     <- IR$OnePerBond$PDiv
  RLeveredXXEq       <- IR$LeveredXXEq$Return
  PDivLeveredXXEq    <- IR$LeveredXXEq$PDiv

  nnSim              <- length(XXW)



  ## Create CSV Table
  Table <- cbind(XXW,
          XXWOnFineGrid.high,
          XXWOnFineGrid.low,
          CGrowth,
          DGrowth,
          Req,
          RBond,
          RLeveredXXEq,
          PDivEq,
          PDivOnePerBond,
          PDivLeveredXXEq)

  colnames(Table) <- c("XXW",
            "XXWOnFineGrid.high",
            "XXWOnFineGrid.low",
            "CGrowth",
            "DGrowth",
            "Req",
            "RBond",
            "RLeveredXXEq",
            "PDivEq",
            "PDivOnePerBond",
            "PDivLeveredXXEq")

  # Save
  filename <- file.path(outDir,
          paste('impulseResponseXXW.',
            allData$countryNames[countryToUse],
              '.csv',sep=""))
  write.table(round(Table,5), filename,row.names = T,col.names=NA, sep = ",")

  ##############################################################################
  #                               Plot                                         #
  ##############################################################################
  filename <-  file.path(outDir, paste(c('impulseResponseXXW', allData$countryNames[countryToUse], 'pdf'),collapse = '.'))
  pdf(filename, paper = 'special', width = 6, height = 7)
  par(mfrow = c(3, 2))

  ## XXW
  labEx <- 'xxW'
  ylimTemp <- range(c(XXWOnFineGrid.low,XXWOnFineGrid.high))
  plot(1:nnSim, as.ts(XXW),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)
  lines(1:nnSim, as.ts(XXWOnFineGrid.high), type='l', col=2, lwd=0.4)
  lines(1:nnSim, as.ts(XXWOnFineGrid.low), type='l', col=2, lwd=0.4)

  ## CGrowth
  labEx <- 'Consumption Growth'
  ylimTemp <- range(CGrowth)
  plot(1:nnSim, as.ts(CGrowth),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## Req
  labEx <- 'Return on Equity'
  ylimTemp <- range(Req)
  plot(1:nnSim, as.ts(Req),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## RBond
  labEx <- 'Return on Bond'
  ylimTemp <- range(RBond)
  plot(1:nnSim, as.ts(RBond),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## RLeveredXXEq
  labEx <- 'Return on Levered XX Equity'
  ylimTemp <- range(RLeveredXXEq)
  plot(1:nnSim, as.ts(RLeveredXXEq),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## All returns
  labEx <- 'All returns'
  ylimTemp <- range(c(Req/Req[1],RBond/RBond[1],RLeveredXXEq/RLeveredXXEq[1]))
  plot(1:nnSim, as.ts(Req/Req[1]),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)
  lines(1:nnSim, as.ts(RBond/RBond[1]),        type='l', col=2)
  lines(1:nnSim, as.ts(RLeveredXXEq/RLeveredXXEq[1]), type='l', col=3)

  dev.off()
}

saveImpulseResponseXX <- function(allData,
                      countryToUse,
                      IR)
{
  XX                 <- IR$XX
  XXOnFineGrid.high  <- IR$XXOnFineGrid.high
  XXOnFineGrid.low   <- IR$XXOnFineGrid.low
  CGrowth            <- IR$CGrowth
  DGrowth            <- IR$DGrowth
  Req                <- IR$Equity$Return
  PDivEq             <- IR$Equity$PDiv
  RBond              <- IR$OnePerBond$Return
  PDivOnePerBond     <- IR$OnePerBond$PDiv
  RLeveredXXEq       <- IR$LeveredXXEq$Return
  PDivLeveredXXEq    <- IR$LeveredXXEq$PDiv

  nnSim              <- length(XX)

  ## Create CSV Table
  Table           <- cbind(XX,XXOnFineGrid.high,XXOnFineGrid.low,CGrowth,DGrowth,Req,RBond,RLeveredXXEq,PDivEq,PDivOnePerBond,PDivLeveredXXEq)
  colnames(Table) <- c("XX","XXOnFineGrid.high","XXOnFineGrid.low","CGrowth","DGrowth","Req","RBond","RLeveredXXEq","PDivEq","PDivOnePerBond","PDivLeveredXXEq")

  # Save
  filename <-  file.path(outDir, paste('impulseResponseXX.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(Table,5), filename,row.names = T,col.names=NA, sep = ",")

  ##############################################################################
  #                               Plot                                         #
  ##############################################################################
  filename <-  file.path(outDir, paste(c('impulseResponseXX', allData$countryNames[countryToUse], 'pdf'),collapse = '.'))
  pdf(filename, paper = 'special', width = 6, height = 7)
  par(mfrow = c(3, 2))

  ## XX
  labEx <- 'xx'
  ylimTemp <- range(c(XXOnFineGrid.low,XXOnFineGrid.high))
  plot(1:nnSim, as.ts(XX),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)
  lines(1:nnSim, as.ts(XXOnFineGrid.high), type='l', col=2, lwd=0.4)
  lines(1:nnSim, as.ts(XXOnFineGrid.low), type='l', col=2, lwd=0.4)

  ## CGrowth
  labEx <- 'Consumption Growth'
  ylimTemp <- range(CGrowth)
  plot(1:nnSim, as.ts(CGrowth),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## Req
  labEx <- 'Return on Equity'
  ylimTemp <- range(Req)
  plot(1:nnSim, as.ts(Req),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## RBond
  labEx <- 'Return on Bond'
  ylimTemp <- range(RBond)
  plot(1:nnSim, as.ts(RBond),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## RLeveredXXEq
  labEx <- 'Return on Levered XX Equity'
  ylimTemp <- range(RLeveredXXEq)
  plot(1:nnSim, as.ts(RLeveredXXEq),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## All returns
  labEx <- 'All returns'
  ylimTemp <- range(c(Req/Req[1],RBond/RBond[1],RLeveredXXEq/RLeveredXXEq[1]))
  plot(1:nnSim, as.ts(Req/Req[1]),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)
  lines(1:nnSim, as.ts(RBond/RBond[1]),        type='l', col=2)
  lines(1:nnSim, as.ts(RLeveredXXEq/RLeveredXXEq[1]), type='l', col=3)

  dev.off()
}

saveImpulseResponseSigmaSqW <- function(allData,
                      countryToUse,
                      IR)
{
  SigmaSqW                 <- IR$SigmaSqW
  SigmaSqWOnFineGrid.high  <- IR$SigmaSqWOnFineGrid.high
  SigmaSqWOnFineGrid.low   <- IR$SigmaSqWOnFineGrid.low
  CGrowth            <- IR$CGrowth
  DGrowth            <- IR$DGrowth
  Req                <- IR$Equity$Return
  PDivEq             <- IR$Equity$PDiv
  RBond              <- IR$OnePerBond$Return
  PDivOnePerBond     <- IR$OnePerBond$PDiv
  RLeveredXXEq       <- IR$LeveredXXEq$Return
  PDivLeveredXXEq    <- IR$LeveredXXEq$PDiv

  nnSim              <- length(SigmaSqW)

  ## Create CSV Table
  Table           <- cbind(SigmaSqW,SigmaSqWOnFineGrid.high,SigmaSqWOnFineGrid.low,CGrowth,DGrowth,Req,RBond,RLeveredXXEq,PDivEq,PDivOnePerBond,PDivLeveredXXEq)
  colnames(Table) <- c("SigmaSqW","SigmaSqWOnFineGrid.high","SigmaSqWOnFineGrid.low","CGrowth","DGrowth","Req","RBond","RLeveredXXEq","PDivEq","PDivOnePerBond","PDivLeveredXXEq")

  # Save
  filename <-  file.path(outDir, paste('impulseResponseSigmaSqW.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(Table,5), filename,row.names = T,col.names=NA, sep = ",")

  ##############################################################################
  #                               Plot                                         #
  ##############################################################################
  filename <-  file.path(outDir, paste(c('impulseResponseSigmaSqW', allData$countryNames[countryToUse], 'pdf'),collapse = '.'))
  pdf(filename, paper = 'special', width = 6, height = 7)
  par(mfrow = c(3, 2))

  ## SigmaSqW
  labEx <- 'SigmaSqW'
  ylimTemp <- range(c(SigmaSqWOnFineGrid.low,SigmaSqWOnFineGrid.high))
  plot(1:nnSim, as.ts(SigmaSqW),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)
  lines(1:nnSim, as.ts(SigmaSqWOnFineGrid.high), type='l', col=2, lwd=0.4)
  lines(1:nnSim, as.ts(SigmaSqWOnFineGrid.low), type='l', col=2, lwd=0.4)

  ## CGrowth
  labEx <- 'Consumption Growth'
  ylimTemp <- range(CGrowth)
  plot(1:nnSim, as.ts(CGrowth),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## Req
  labEx <- 'Return on Equity'
  ylimTemp <- range(Req)
  plot(1:nnSim, as.ts(Req),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## RBond
  labEx <- 'Return on Bond'
  ylimTemp <- range(RBond)
  plot(1:nnSim, as.ts(RBond),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## RLeveredXXEq
  labEx <- 'Return on Levered XX Equity'
  ylimTemp <- range(RLeveredXXEq)
  plot(1:nnSim, as.ts(RLeveredXXEq),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## All returns
  labEx <- 'All returns'
  ylimTemp <- range(c(Req/Req[1],RBond/RBond[1],RLeveredXXEq/RLeveredXXEq[1]))
  plot(1:nnSim, as.ts(Req/Req[1]),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)
  lines(1:nnSim, as.ts(RBond/RBond[1]),        type='l', col=2)
  lines(1:nnSim, as.ts(RLeveredXXEq/RLeveredXXEq[1]), type='l', col=3)

  dev.off()
}

saveImpulseResponseSigmaSq <- function(allData,
                      countryToUse,
                      IR)
{
  SigmaSq                 <- IR$SigmaSq
  SigmaSqOnFineGrid.high  <- IR$SigmaSqOnFineGrid.high
  SigmaSqOnFineGrid.low   <- IR$SigmaSqOnFineGrid.low
  CGrowth                 <- IR$CGrowth
  DGrowth                 <- IR$DGrowth
  Req                     <- IR$Equity$Return
  PDivEq                  <- IR$Equity$PDiv
  RBond                   <- IR$OnePerBond$Return
  PDivOnePerBond          <- IR$OnePerBond$PDiv
  RLeveredXXEq            <- IR$LeveredXXEq$Return
  PDivLeveredXXEq         <- IR$LeveredXXEq$PDiv

  nnSim                   <- length(SigmaSq)

  ## Create CSV Table
  Table           <- cbind(SigmaSq,SigmaSqOnFineGrid.high,SigmaSqOnFineGrid.low,CGrowth,DGrowth,Req,RBond,RLeveredXXEq,PDivEq,PDivOnePerBond,PDivLeveredXXEq)
  colnames(Table) <- c("SigmaSq","SigmaSqOnFineGrid.high","SigmaSqOnFineGrid.low","CGrowth","DGrowth","Req","RBond","RLeveredXXEq","PDivEq","PDivOnePerBond","PDivLeveredXXEq")

  # Save
  filename <-  file.path(outDir, paste('impulseResponseSigmaSq.',allData$countryNames[countryToUse],'.csv',sep=""))
  write.table(round(Table,5), filename,row.names = T,col.names=NA, sep = ",")

  ##############################################################################
  #                               Plot                                         #
  ##############################################################################
  filename <-  file.path(outDir, paste(c('impulseResponseSigmaSq', allData$countryNames[countryToUse], 'pdf'),collapse = '.'))
  pdf(filename, paper = 'special', width = 6, height = 7)
  par(mfrow = c(3, 2))

  ## SigmaSqW
  labEx <- 'SigmaSq'
  ylimTemp <- range(c(SigmaSqOnFineGrid.low,SigmaSqOnFineGrid.high))
  plot(1:nnSim, as.ts(SigmaSq),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)
  lines(1:nnSim, as.ts(SigmaSqOnFineGrid.high), type='l', col=2, lwd=0.4)
  lines(1:nnSim, as.ts(SigmaSqOnFineGrid.low), type='l', col=2, lwd=0.4)

  ## CGrowth
  labEx <- 'Consumption Growth'
  ylimTemp <- range(CGrowth)
  plot(1:nnSim, as.ts(CGrowth),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## Req
  labEx <- 'Return on Equity'
  ylimTemp <- range(Req)
  plot(1:nnSim, as.ts(Req),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## RBond
  labEx <- 'Return on Bond'
  ylimTemp <- range(RBond)
  plot(1:nnSim, as.ts(RBond),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## RLeveredXXEq
  labEx <- 'Return on Levered XX Equity'
  ylimTemp <- range(RLeveredXXEq)
  plot(1:nnSim, as.ts(RLeveredXXEq),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)

  ## All returns
  labEx <- 'All returns'
  ylimTemp <- range(c(Req/Req[1],RBond/RBond[1],RLeveredXXEq/RLeveredXXEq[1]))
  plot(1:nnSim, as.ts(Req/Req[1]),
     main = paste(labEx),
     xlab = 'time',
     ylab = '',
     type = "l",
     ylim = ylimTemp)
  lines(1:nnSim, as.ts(RBond/RBond[1]),        type='l', col=2)
  lines(1:nnSim, as.ts(RLeveredXXEq/RLeveredXXEq[1]), type='l', col=3)

  dev.off()
}

computeAndSaveBHSelasticities <- function(allData,
                                            countryToUse,
                                            outputEZW,
                                            controlVarNAPi,
                                            bigDataPosInfo)
{
  ## Create horizon variable
  maxMaturityTPerBonds<- controlVarNAPi$maxMaturityTPerBonds
  horizon             <- 1:maxMaturityTPerBonds

  ## Compute elasticities
  if (controlVarNAPi$getSEEepsW){
    resultsSEEepsW <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SEEepsW')
  }
  if (controlVarNAPi$getSEEeps){
    resultsSEEeps <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SEEeps')
  }
  if (controlVarNAPi$getSEEomegaW){
    resultsSEEomegaW <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SEEomegaW')
  }
  if (controlVarNAPi$getSEEomega){
    resultsSEEomega <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SEEomega')
  }
  if (controlVarNAPi$getSCEepsW){
    resultsSCEepsW <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SCEepsW')
  }
  if (controlVarNAPi$getSCEeps){
    resultsSCEeps <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SCEeps')
  }
  if (controlVarNAPi$getSCEomegaW){
    resultsSCEomegaW <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SCEomegaW')
  }
  if (controlVarNAPi$getSCEomega){
    resultsSCEomega <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SCEomega')
  }

  if (controlVarNAPi$getSPEepsW){
    resultsSEEepsW <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SEEepsW')
    resultsSCEepsW <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SCEepsW')
  }
  if (controlVarNAPi$getSPEeps){
    resultsSEEeps <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SEEeps')
    resultsSCEeps <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SCEeps')
  }
  if (controlVarNAPi$getSPEomegaW){
    resultsSEEomegaW <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SEEomegaW')
    resultsSCEomegaW <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SCEomegaW')
  }
  if (controlVarNAPi$getSPEomega){
    resultsSEEomega <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SEEomega')
    resultsSCEomega <- EvaluateStats(outputEZW,
                    controlVarNAPi,
                    bigDataPosInfo,
                    'SCEomega')
  }

  if (controlVarNAPi$getDiagnosticStats){
    resultsStat1 <- GetStats2(outputEZW,controlVarNAPi,bigDataPosInfo)

    dataToSave <- data.frame(
            Stat1              = resultsStat1$Stat1,
            SigmaSqW           = resultsStat1$SigmaSqW,
            SigmaSqWOnFineGrid = resultsStat1$SigmaSqWOnFineGrid,
            SigmaSq            = resultsStat1$SigmaSq,
            SigmaSqOnFineGrid  = resultsStat1$SigmaSqOnFineGrid)

    filename        <-  file.path(outDir,
                paste(c('Stat1',
                    allData$countryNames[countryToUse],
                    'csv'),
                  collapse = '.'))

    write.csv(dataToSave,file = filename)
  }

  ## Saves shock-exposure elasticity
  if (controlVarNAPi$getSEEepsW   + controlVarNAPi$getSEEeps +
    controlVarNAPi$getSEEomegaW + controlVarNAPi$getSEEomega +
    controlVarNAPi$getCorrEpsWlogDDiv > 0){
    filename <-  file.path(outDir,
                 paste(c('BHS_ShockExposureElasticity',
                     allData$countryNames[countryToUse],
                     'pdf'),collapse = '.'))
    pdf(filename,
      paper  = 'special',
      width  = 6,
      height = 7)
    par(mfrow  = c(controlVarNAPi$getSEEepsW          +
             controlVarNAPi$getSEEeps           +
             controlVarNAPi$getSEEomegaW        +
             controlVarNAPi$getSEEomega         +
             controlVarNAPi$getCorrEpsWlogDDiv, 1))
    if (controlVarNAPi$getCorrEpsWlogDDiv){
      print(resultsTPerRiskyBondCorrEpsWlogDDiv$statsMean)
      plotds(horizon,
        as.ts(resultsTPerRiskyBondCorrEpsWlogDDiv$statsMean),
        ylimTemp   = range(resultsTPerRiskyBondCorrEpsWlogDDiv$statsMean),
        title.x    = 'horizon',
        title.y    = 'EpsW')
    }
    if (controlVarNAPi$getSEEepsW){
      plotds(horizon,
        as.ts(resultsSEEepsW$statsMean),
        ylimTemp   = range(resultsSEEepsW$statsMean),
        title.x    = 'horizon',
        title.y    = 'EpsW')
    }
    if (controlVarNAPi$getSEEeps){
      plotds(horizon,
        as.ts(resultsSEEeps$statsMean),
        ylimTemp   = range(resultsSEEeps$statsMean),
        title.x    = 'horizon',
        title.y    = 'Eps')
    }
    if (controlVarNAPi$getSEEomegaW){
      plotds(horizon,
        as.ts(resultsSEEomegaW$statsMean),
        ylimTemp   = range(resultsSEEomegaW$statsMean),
        title.x    = 'horizon',
        title.y    = 'OmegaW')
    }
    if (controlVarNAPi$getSEEomega){
      plotds(horizon,
        as.ts(resultsSEEomega$statsMean),
        ylimTemp   = range(resultsSEEomega$statsMean),
        title.x    = 'horizon',
        title.y    = 'Omega')
    }
    dev.off()
  }

  ## Saves shock-cost elasticity
  if (controlVarNAPi$getSCEepsW   + controlVarNAPi$getSCEeps +
    controlVarNAPi$getSCEomegaW + controlVarNAPi$getSCEomega > 0){
    filename <-  file.path(outDir,
                 paste(c('BHS_ShockCostElasticity',
                     allData$countryNames[countryToUse],
                     'pdf'),collapse = '.'))
    pdf(filename,
      paper  = 'special',
      width  = 6,
      height = 7)
    par(mfrow  = c(controlVarNAPi$getSCEepsW  +
            controlVarNAPi$getSCEeps    +
            controlVarNAPi$getSCEomegaW +
            controlVarNAPi$getSCEomega, 1))
    if (controlVarNAPi$getSCEepsW){
      plotds(horizon,
        as.ts(resultsSCEepsW$statsMean),
        ylimTemp   = range(resultsSCEepsW$statsMean),
        title.x    = 'horizon',
        title.y    = 'EpsW')
    }
    if (controlVarNAPi$getSCEeps){
      plotds(horizon,
        as.ts(resultsSCEeps$statsMean),
        ylimTemp   = range(resultsSCEeps$statsMean),
        title.x    = 'horizon',
        title.y    = 'Eps')
    }
    if (controlVarNAPi$getSCEomegaW){
      plotds(horizon,
        as.ts(resultsSCEomegaW$statsMean),
        ylimTemp   = range(resultsSCEomegaW$statsMean),
        title.x    = 'horizon',
        title.y    = 'OmegaW')
    }
    if (controlVarNAPi$getSCEomega){
      plotds(horizon,
        as.ts(resultsSCEomega$statsMean),
        ylimTemp   = range(resultsSCEomega$statsMean),
        title.x    = 'horizon',
        title.y    = 'Omega')
    }
    dev.off()
  }
  ## Saves shock-price elasticity
  if (controlVarNAPi$getSPEepsW   + controlVarNAPi$getSPEeps +
    controlVarNAPi$getSPEomegaW + controlVarNAPi$getSPEomega > 0){
    filename <-  file.path(outDir,
                 paste(c('BHS_ShockPriceElasticity',
                     allData$countryNames[countryToUse],
                     'pdf'),collapse = '.'))
    pdf(filename,
      paper  = 'special',
      width  = 6,
      height = 7)

    par(mfrow  = c(controlVarNAPi$getSPEepsW  +
            controlVarNAPi$getSPEeps    +
            controlVarNAPi$getSPEomegaW +
            controlVarNAPi$getSPEomega, 1))

    if (controlVarNAPi$getSPEepsW){
      plotds(horizon,
        as.ts(resultsSEEepsW$statsMean-resultsSCEepsW$statsMean),
        ylimTemp   = range(resultsSEEepsW$statsMean-
                  resultsSCEepsW$statsMean),
        title.x    = 'horizon',
        title.y    = 'EpsW')
    }
    if (controlVarNAPi$getSPEeps){
      plotds(horizon,
        as.ts(resultsSEEeps$statsMean - resultsSCEeps$statsMean),
        ylimTemp   = range(resultsSEEeps$statsMean -
                  resultsSCEeps$statsMean),
        title.x    = 'horizon',
        title.y    = 'Eps')
    }
    if (controlVarNAPi$getSPEomegaW){
      plotds(horizon,
        as.ts(resultsSEEomegaW$statsMean - resultsSCEomegaW$statsMean),
        ylimTemp   = range(resultsSEEomegaW$statsMean -
                  resultsSCEomegaW$statsMean),
        title.x    = 'horizon',
        title.y    = 'OmegaW')
    }
    if (controlVarNAPi$getSPEomega){
      plotds(horizon,
        as.ts(resultsSEEomega$statsMean - resultsSCEomega$statsMean),
        ylimTemp   = range(resultsSEEomega$statsMean -
                  resultsSCEomega$statsMean),
        title.x    = 'horizon',
        title.y    = 'Omega')
    }
    dev.off()
  }
}

BHSelasticitiesGeneric <- function(outputEZW,
                      controlVarNAPi,
                      UnobsPosInfo,
                      typeOfShock)
{
  ## Checks if correct type of shock
  if (!(typeOfShock %in% c('Eps','EpsW','Omega','OmegaW'))) {
    stop('No such shock \n\n')
  }
  ## The following supplementary function is only used to compute impulse responses
  getCurPos <- function(Nu, XX, SigmaSq, XXW, SigmaSqW){
    curNu       <- which(Nu[1]       == fineStateGridNu)
    curXX       <- which(XX[1]       == fineStateGridXX)
    curSigmaSq  <- which(SigmaSq[1]  == fineStateGridSigmaSq)
    curXXW      <- which(XXW[1]      == fineStateGridXXW)
    curSigmaSqW <- which(SigmaSqW[1] == fineStateGridSigmaSqW)

    curPos <- ((curSigmaSqW - 1) * nFineStateGridXXW * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                        (curXXW-1) * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                                  (curSigmaSq-1) * nFineStateGridXX * nFineStateGridNu +
                                            (curXX - 1) * nFineStateGridNu +
                                                          curNu)
    return(curPos)
  }
  ## Read grid parameters
  fineStateGridList        <- createFineStateGrid(countryToUse,  controlVarNAPi, ParEst, UnobsPosInfo)

  fineStateGridNu          <- fineStateGridList$gridNu
  fineStateGridXX          <- fineStateGridList$gridXX
  fineStateGridXXW         <- fineStateGridList$gridXXW
  fineStateGridSigmaSq     <- fineStateGridList$gridSigmaSq
  fineStateGridSigmaSqW    <- fineStateGridList$gridSigmaSqW

  nFineStateGridNu         <- length(fineStateGridNu)
  nFineStateGridXX         <- length(fineStateGridXX)
  nFineStateGridXXW        <- length(fineStateGridXXW)
  nFineStateGridSigmaSq    <- length(fineStateGridSigmaSq)
  nFineStateGridSigmaSqW   <- length(fineStateGridSigmaSqW)

  ## Read consumption process parameters
  sigmaSqConst             <- ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW            <- ParEst[bigDataPosInfo$sigmaSqConstW]

  ## Read some techinical parameters
  maxMaturityTPerBonds     <- controlVarNAPi$maxMaturityTPerBonds
  cutOff                   <- controlVarNAPi$cutOff

  ## Read price-dividend functions
  #PDivs                       <- outputEZW$PDivs
  #PDivsTPerRiskyBond          <- outputEZW$PDivs$TPerRiskyBond

  ## Initialize endogenous elasticities
  SEEepsVal                   <- vector("list", maxMaturityTPerBonds)
  SEEepsWVal                  <- vector("list", maxMaturityTPerBonds)
  SEEomegaVal                 <- vector("list", maxMaturityTPerBonds)
  SEEomegaWVal                <- vector("list", maxMaturityTPerBonds)

  ## Set states for which to compute elasticities
  Nu                       <- rep(0,            1)
  XXW                      <- rep(0,            1)
  XX                       <- rep(0,            1)
  SigmaSqW                 <- rep(sigmaSqConstW,1)
  SigmaSq                  <- rep(sigmaSqConst, 1)
  DD                       <- rep(1,            1)
  ## Put on the grid
  NuOnFineGrid             <- numeric(1)
  XXOnFineGrid             <- numeric(1)
  XXWOnFineGrid            <- numeric(1)
  SigmaSqOnFineGrid        <- numeric(1)
  SigmaSqWOnFineGrid       <- numeric(1)
  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes     <- matrix(FALSE,nFineStateGridSigmaSqW  ,nFineStateGridSigmaSq)
  for (iiSigmaSq in (1:nFineStateGridSigmaSq)){
    fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[,iiSigmaSq]   <- (fineStateGridSigmaSq[iiSigmaSq] + fineStateGridSigmaSqW >= cutOff)
  }

  for (ii in c(1)) {
    NuInd              <- which.min(abs(fineStateGridNu-Nu[ii]))
    NuOnFineGrid[ii]   <- fineStateGridNu[NuInd]

    XXInd              <- which.min(abs(fineStateGridXX-XX[ii]))
    XXOnFineGrid[ii]   <- fineStateGridXX[XXInd]

    XXWInd             <- which.min(abs(fineStateGridXXW-XXW[ii]))
    XXWOnFineGrid[ii]  <- fineStateGridXXW[XXWInd]

    SigmaSqInd         <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
    SigmaSqWInd        <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))

    if (fineStateGridSigmaSq[SigmaSqInd] + fineStateGridSigmaSqW[SigmaSqWInd] >= cutOff){
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- fineStateGridSigmaSq[SigmaSqInd]
    } else {
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- min(fineStateGridSigmaSq[fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[SigmaSqWInd,]])
      SigmaSqInd             <- which.min(abs(SigmaSqOnFineGrid[ii] - SigmaSq[ii]))
    }
  }
  ## Create upper and lower traces (this is used for the out-of-the-grid interpolation)
  if (typeOfShock == 'EpsW') {
    XXWOnFineGrid.high       <- numeric(1)
    XXWOnFineGrid.low        <- numeric(1)
    for (ii in 1:1) {
      if (min(abs(fineStateGridXXW - XXW[ii]))==0) {
        XXWOnFineGrid.high[ii]           <- XXW[ii]
        XXWOnFineGrid.low[ii]            <- XXW[ii]
      } else {
        XXWInd.firstClosest              <- which.min(abs(fineStateGridXXW-XXW[ii]))
        XXWOnFineGrid.firstClosest       <- fineStateGridXXW[XXWInd.firstClosest]
        XXWInd.secondClosest             <- which.min(abs(fineStateGridXXW[-c(XXWInd.firstClosest)]-XXW[ii]))
        XXWOnFineGrid.secondClosest      <- fineStateGridXXW[-c(XXWInd.firstClosest)][XXWInd.secondClosest]
        XXWOnFineGrid.high[ii]           <- max(XXWOnFineGrid.firstClosest,XXWOnFineGrid.secondClosest)
        XXWOnFineGrid.low[ii]            <- min(XXWOnFineGrid.firstClosest,XXWOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'Eps') {
    XXOnFineGrid.high       <- numeric(1)
    XXOnFineGrid.low        <- numeric(1)
    for (ii in 1:1) {
      if (min(abs(fineStateGridXX - XX[ii]))==0) {
        XXOnFineGrid.high[ii]            <- XX[ii]
        XXOnFineGrid.low[ii]             <- XX[ii]
      } else {
        XXInd.firstClosest               <- which.min(abs(fineStateGridXX-XX[ii]))
        XXOnFineGrid.firstClosest        <- fineStateGridXX[XXInd.firstClosest]
        XXInd.secondClosest              <- which.min(abs(fineStateGridXX[-c(XXInd.firstClosest)]-XX[ii]))
        XXOnFineGrid.secondClosest       <- fineStateGridXX[-c(XXInd.firstClosest)][XXInd.secondClosest]
        XXOnFineGrid.high[ii]            <- max(XXOnFineGrid.firstClosest,XXOnFineGrid.secondClosest)
        XXOnFineGrid.low[ii]             <- min(XXOnFineGrid.firstClosest,XXOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'OmegaW') {
    SigmaSqWOnFineGrid.high       <- numeric(1)
    SigmaSqWOnFineGrid.low        <- numeric(1)
    for (ii in 1:1) {
      if (min(abs(fineStateGridSigmaSqW - SigmaSqW[ii]))==0) {
        SigmaSqWOnFineGrid.high[ii]      <- SigmaSqW[ii]
        SigmaSqWOnFineGrid.low[ii]       <- SigmaSqW[ii]
      } else {
        SigmaSqWInd.firstClosest         <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))
        SigmaSqWOnFineGrid.firstClosest  <- fineStateGridSigmaSqW[SigmaSqWInd.firstClosest]
        SigmaSqWInd.secondClosest        <- which.min(abs(fineStateGridSigmaSqW[-c(SigmaSqWInd.firstClosest)]-SigmaSqW[ii]))
        SigmaSqWOnFineGrid.secondClosest <- fineStateGridSigmaSqW[-c(SigmaSqWInd.firstClosest)][SigmaSqWInd.secondClosest]
        SigmaSqWOnFineGrid.high[ii]      <- max(SigmaSqWOnFineGrid.firstClosest,SigmaSqWOnFineGrid.secondClosest)
        SigmaSqWOnFineGrid.low[ii]       <- min(SigmaSqWOnFineGrid.firstClosest,SigmaSqWOnFineGrid.secondClosest)
      }
    }
  }
  if (typeOfShock == 'Omega') {
    SigmaSqOnFineGrid.high       <- numeric(1)
    SigmaSqOnFineGrid.low        <- numeric(1)
    for (ii in 1:1) {
      if (min(abs(fineStateGridSigmaSq - SigmaSq[ii]))==0) {
        SigmaSqOnFineGrid.high[ii]       <- SigmaSq[ii]
        SigmaSqOnFineGrid.low[ii]        <- SigmaSq[ii]
      } else {
        SigmaSqInd.firstClosest          <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
        SigmaSqOnFineGrid.firstClosest   <- fineStateGridSigmaSq[SigmaSqInd.firstClosest]
        SigmaSqInd.secondClosest         <- which.min(abs(fineStateGridSigmaSq[-c(SigmaSqInd.firstClosest)]-SigmaSq[ii]))
        SigmaSqOnFineGrid.secondClosest  <- fineStateGridSigmaSq[-c(SigmaSqInd.firstClosest)][SigmaSqInd.secondClosest]
        SigmaSqOnFineGrid.high[ii]       <- max(SigmaSqOnFineGrid.firstClosest,SigmaSqOnFineGrid.secondClosest)
        SigmaSqOnFineGrid.low[ii]        <- min(SigmaSqOnFineGrid.firstClosest,SigmaSqOnFineGrid.secondClosest)
      }
    }
  }

  ## Compute Elasticity wrt EpsW shock
  if (typeOfShock == 'EpsW') {
    load(file.path(outDir, paste(c('SEEepsW',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      if (XXWOnFineGrid.high[1] == XXWOnFineGrid.low[1]) {
        SEEepsWCur      <- SEEepsW[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])]
      } else {
        SEEepsWCur.high <- SEEepsW[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.high[1],SigmaSqWOnFineGrid[1])]
        SEEepsWCur.low  <- SEEepsW[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid.low[1],SigmaSqWOnFineGrid[1])]
        ff              <- approxfun(c(XXWOnFineGrid.low[1],XXWOnFineGrid.high[1]),c(SEEepsWCur.low,SEEepsWCur.high))
        SEEepsWCur      <- ff(XXW[1])
      }
      SEEepsWVal[[ii]] <- SEEepsWCur
    }
    rm("SEEepsW")
  }
  ## Compute Elasticity wrt Eps shock
  if (typeOfShock == 'Eps') {
    load(file.path(outDir, paste(c('SEEeps',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      if (XXOnFineGrid.high[1] == XXOnFineGrid.low[1]) {
        SEEepsCur      <- SEEeps[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])]
      } else {
        SEEepsCur.high <- SEEeps[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid.high[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])]
        SEEepsCur.low  <- SEEeps[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid.low[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])]
        ff          <- approxfun(c(XXOnFineGrid.low[1],XXOnFineGrid.high[1]),c(SEEepsCur.low,SEEepsCur.high))
        SEEepsCur      <- ff(XX[1])
      }
      SEEepsVal[[ii]][1] <- SEEepsCur
    }
    rm("SEEeps")
  }
  ## Compute Elasticity wrt OmegaW shock
  if (typeOfShock == 'OmegaW') {
    load(file.path(outDir, paste(c('SEEomegaW',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      if (SigmaSqWOnFineGrid.high[1] == SigmaSqWOnFineGrid.low[1]) {
        SEEomegaWCur      <- SEEomegaW[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])]
      } else {
        SEEomegaWCur.high <- SEEomegaW[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.high[1])]
        SEEomegaWCur.low  <- SEEomegaW[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid.low[1])]
        ff                <- approxfun(c(SigmaSqWOnFineGrid.low[1],SigmaSqWOnFineGrid.high[1]),c(SEEomegaWCur.low,SEEomegaWCur.high))
        SEEomegaWCur      <- ff(SigmaSqW[1])
      }
      SEEomegaWVal[[ii]][1] <- SEEomegaWCur
    }
    rm("SEEomegaW")
  }
  ## Compute Elasticity wrt Omega shock
  if (typeOfShock == 'Omega') {
    load(file.path(outDir, paste(c('SEEomega',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      if (SigmaSqOnFineGrid.high[1] == SigmaSqOnFineGrid.low[1]) {
        SEEomegaCur      <- SEEomega[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])]
      } else {
        SEEomegaCur.high <- SEEomega[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.high[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])]
        SEEomegaCur.low  <- SEEomega[[ii]][getCurPos(NuOnFineGrid[1],XXOnFineGrid[1],SigmaSqOnFineGrid.low[1],XXWOnFineGrid[1],SigmaSqWOnFineGrid[1])]
        ff           <- approxfun(c(SigmaSqOnFineGrid.low[1],SigmaSqOnFineGrid.high[1]),c(SEEomegaCur.low,SEEomegaCur.high))
        SEEomegaCur      <- ff(SigmaSq[1])
      }
      SEEomegaVal[[ii]][1] <- SEEomegaCur
    }
    rm("SEEomega")
  }
  output <- list(XXW      = XXW,
           XX       = XX,
           SigmaSqW = SigmaSqW,
           SigmaSq  = SigmaSq)
  if (typeOfShock == 'EpsW') {
    SEEepsWMean              <- lapply(SEEepsWVal,mean,simplify = TRUE)
    SEEepsWMean              <- unlist(SEEepsWMean)
    output$SEEmean           <- SEEepsWMean
    output$XXWOnFineGrid.high<- XXWOnFineGrid.high
    output$XXWOnFineGrid.low <- XXWOnFineGrid.low
  }
  if (typeOfShock == 'Eps') {
    SEEepsMean               <- lapply(SEEepsVal,mean,simplify = TRUE)
    SEEepsMean               <- unlist(SEEepsMean)
    output$SEEmean           <- SEEepsMean
    output$XXOnFineGrid.high <- XXOnFineGrid.high
    output$XXOnFineGrid.low  <- XXOnFineGrid.low
  }
  if (typeOfShock == 'OmegaW') {
    SEEomegaWMean                  <- lapply(SEEomegaWVal,mean,simplify = TRUE)
    SEEomegaWMean                  <- unlist(SEEomegaWMean)
    output$SEEmean                 <- SEEomegaWMean
    output$SigmaSqWOnFineGrid.high <- SigmaSqWOnFineGrid.high
    output$SigmaSqWOnFineGrid.low  <- SigmaSqWOnFineGrid.low
  }
  if (typeOfShock == 'Omega') {
    SEEomegaMean                   <- lapply(SEEomegaVal,mean,simplify = TRUE)
    SEEomegaMean                   <- unlist(SEEomegaMean)
    output$SEEmean                 <- SEEomegaMean
    output$SigmaSqOnFineGrid.high  <- SigmaSqOnFineGrid.high
    output$SigmaSqOnFineGrid.low   <- SigmaSqOnFineGrid.low
  }
  return(output)
}

BHSelasticitiesGeneric2 <- function(outputEZW,
                      controlVarNAPi,
                      UnobsPosInfo,
                      typeOfShock)
{
  ## Checks if correct type of shock
  if (!(typeOfShock %in% c('Eps','EpsW','Omega','OmegaW','Dd'))) {
    stop('No such shock \n\n')
  }
  ## The following supplementary function is only used to compute impulse responses
  getCurPos <- function(Nu, XX, SigmaSq, XXW, SigmaSqW){
    curNu       <- which(Nu[1]       == fineStateGridNu)
    curXX       <- which(XX[1]       == fineStateGridXX)
    curSigmaSq  <- which(SigmaSq[1]  == fineStateGridSigmaSq)
    curXXW      <- which(XXW[1]      == fineStateGridXXW)
    curSigmaSqW <- which(SigmaSqW[1] == fineStateGridSigmaSqW)

    curPos <- ((curSigmaSqW - 1) * nFineStateGridXXW * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                        (curXXW-1) * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                                  (curSigmaSq-1) * nFineStateGridXX * nFineStateGridNu +
                                            (curXX - 1) * nFineStateGridNu +
                                                          curNu)
    return(curPos)
  }
  ## Read grid parameters
  fineStateGridList        <- createFineStateGrid(countryToUse,  controlVarNAPi, ParEst, UnobsPosInfo)

  fineStateGridNu          <- fineStateGridList$gridNu
  fineStateGridXX          <- fineStateGridList$gridXX
  fineStateGridXXW         <- fineStateGridList$gridXXW
  fineStateGridSigmaSq     <- fineStateGridList$gridSigmaSq
  fineStateGridSigmaSqW    <- fineStateGridList$gridSigmaSqW

  nFineStateGridNu         <- length(fineStateGridNu)
  nFineStateGridXX         <- length(fineStateGridXX)
  nFineStateGridXXW        <- length(fineStateGridXXW)
  nFineStateGridSigmaSq    <- length(fineStateGridSigmaSq)
  nFineStateGridSigmaSqW   <- length(fineStateGridSigmaSqW)

  ## Read consumption process parameters
  sigmaSqConst             <- ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW            <- ParEst[bigDataPosInfo$sigmaSqConstW]

  ## Read some techinical parameters
  maxMaturityTPerBonds     <- controlVarNAPi$maxMaturityTPerBonds
  cutOff                   <- controlVarNAPi$cutOff

  ## Read price-dividend functions
  #PDivs                       <- outputEZW$PDivs
  #PDivsTPerRiskyBond          <- outputEZW$PDivs$TPerRiskyBond

  ## Initialize endogenous elasticities
  SEEepsVal                   <- vector("list", maxMaturityTPerBonds)
  SEEepsWVal                  <- vector("list", maxMaturityTPerBonds)
  SEEomegaVal                 <- vector("list", maxMaturityTPerBonds)
  SEEomegaWVal                <- vector("list", maxMaturityTPerBonds)
  DdVal                       <- vector("list", maxMaturityTPerBonds)

  ## Set states for which to compute elasticities
  Nu                       <- rep(0,            1)
  XXW                      <- rep(0,            1)
  XX                       <- rep(0,            1)
  SigmaSqW                 <- rep(sigmaSqConstW,1)
  SigmaSq                  <- rep(sigmaSqConst, 1)
  DD                       <- rep(1,            1)
  ## Put on the grid
  NuOnFineGrid             <- numeric(1)
  XXOnFineGrid             <- numeric(1)
  XXWOnFineGrid            <- numeric(1)
  SigmaSqOnFineGrid        <- numeric(1)
  SigmaSqWOnFineGrid       <- numeric(1)
  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes     <- matrix(FALSE,nFineStateGridSigmaSqW  ,nFineStateGridSigmaSq)
  for (iiSigmaSq in (1:nFineStateGridSigmaSq)){
    fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[,iiSigmaSq]   <- (fineStateGridSigmaSq[iiSigmaSq] + fineStateGridSigmaSqW >= cutOff)
  }

  for (ii in c(1)) {
    NuInd              <- which.min(abs(fineStateGridNu-Nu[ii]))
    NuOnFineGrid[ii]   <- fineStateGridNu[NuInd]

    XXInd              <- which.min(abs(fineStateGridXX-XX[ii]))
    XXOnFineGrid[ii]   <- fineStateGridXX[XXInd]

    XXWInd             <- which.min(abs(fineStateGridXXW-XXW[ii]))
    XXWOnFineGrid[ii]  <- fineStateGridXXW[XXWInd]

    SigmaSqInd         <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
    SigmaSqWInd        <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))

    if (fineStateGridSigmaSq[SigmaSqInd] + fineStateGridSigmaSqW[SigmaSqWInd] >= cutOff){
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- fineStateGridSigmaSq[SigmaSqInd]
    } else {
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- min(fineStateGridSigmaSq[fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[SigmaSqWInd,]])
      SigmaSqInd             <- which.min(abs(SigmaSqOnFineGrid[ii] - SigmaSq[ii]))
    }
  }

  ## Compute Elasticity wrt EpsW shock
  if (typeOfShock == 'EpsW') {
    load(file.path(outDir, paste(c('SEEepsW',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      SEEepsWVal[[ii]] <- SEEepsW[[ii]][getCurPos(NuOnFineGrid[1],
                              XXOnFineGrid[1],
                              SigmaSqOnFineGrid[1],
                              XXWOnFineGrid[1],
                              SigmaSqWOnFineGrid[1])]
    }
    rm("SEEepsW")
  }
  ## Compute Elasticity wrt Eps shock
  if (typeOfShock == 'Eps') {
    load(file.path(outDir, paste(c('SEEeps',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      SEEepsVal[[ii]][1] <- SEEeps[[ii]][getCurPos(NuOnFineGrid[1],
                            XXOnFineGrid[1],
                            SigmaSqOnFineGrid[1],
                            XXWOnFineGrid[1],
                            SigmaSqWOnFineGrid[1])]
    }
    rm("SEEeps")
  }
  ## Compute Elasticity wrt OmegaW shock
  if (typeOfShock == 'OmegaW') {
    load(file.path(outDir, paste(c('SEEomegaW',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      SEEomegaWVal[[ii]][1] <- SEEomegaW[[ii]][getCurPos(NuOnFineGrid[1],
                                XXOnFineGrid[1],
                                SigmaSqOnFineGrid[1],
                                XXWOnFineGrid[1],
                                SigmaSqWOnFineGrid[1])]
    }
    rm("SEEomegaW")
  }
  ## Compute Elasticity wrt Omega shock
  if (typeOfShock == 'Omega') {
    load(file.path(outDir, paste(c('SEEomega',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      SEEomegaVal[[ii]][1] <- SEEomega[[ii]][getCurPos(NuOnFineGrid[1],
                              XXOnFineGrid[1],
                              SigmaSqOnFineGrid[1],
                              XXWOnFineGrid[1],
                              SigmaSqWOnFineGrid[1])]
    }
    rm("SEEomega")
  }
  ## Compute Dividend growth expectation
  if (typeOfShock == 'Dd') {
    load(file.path(outDir, paste(c('TPerRiskyBondDDiv',GlobalCountryName,'Rda'), collapse = '.')))
    for (ii in c(1:maxMaturityTPerBonds)){
      DdVal[[ii]][1] <- TPerRiskyBondDDiv[[ii]][getCurPos(NuOnFineGrid[1],
                              XXOnFineGrid[1],
                              SigmaSqOnFineGrid[1],
                              XXWOnFineGrid[1],
                              SigmaSqWOnFineGrid[1])]
    }
    rm("TPerRiskyBondDDiv")
  }
  output  <- list(XXW                 = XXW,
          XX                  = XX,
          SigmaSqW            = SigmaSqW,
          SigmaSq             = SigmaSq,
          XXWOnFineGrid       = XXWOnFineGrid,
          XXOnFineGrid        = XXOnFineGrid,
          SigmaSqWOnFineGrid  = SigmaSqWOnFineGrid,
          SigmaSqOnFineGrid   = SigmaSqOnFineGrid)

  if (typeOfShock == 'EpsW') {
    SEEepsWMean              <- lapply(SEEepsWVal,mean,simplify = TRUE)
    SEEepsWMean              <- unlist(SEEepsWMean)
    output$SEEmean           <- SEEepsWMean
  }
  if (typeOfShock == 'Eps') {
    SEEepsMean               <- lapply(SEEepsVal,mean,simplify = TRUE)
    SEEepsMean               <- unlist(SEEepsMean)
    output$SEEmean           <- SEEepsMean
  }
  if (typeOfShock == 'OmegaW') {
    SEEomegaWMean            <- lapply(SEEomegaWVal,mean,simplify = TRUE)
    SEEomegaWMean            <- unlist(SEEomegaWMean)
    output$SEEmean           <- SEEomegaWMean
  }
  if (typeOfShock == 'Omega') {
    SEEomegaMean             <- lapply(SEEomegaVal,mean,simplify = TRUE)
    SEEomegaMean             <- unlist(SEEomegaMean)
    output$SEEmean           <- SEEomegaMean
  }
  if (typeOfShock == 'Dd') {
    DdMean             <- lapply(DdVal,mean,simplify = TRUE)
    DdMean             <- unlist(DdMean)
    output$Ddmean           <- DdMean
  }
  return(output)
}

EvaluateStats <- function(outputEZW,
                      controlVarNAPi,
                      UnobsPosInfo,
                      statsName)
{
  # evaluates functions listed in variable 'allowedStatsNames' below
  # in particular point (Nu,XXW,XX,SigmaSqW,SigmaSq) of state space.
  #
  # Currently this point is stationary values of the corresponding
  # coordinates

  ## Checks if the program works with these stats
  allowedStatsNames <- c('SEEeps',
            'SEEepsW',
            'SEEomega',
            'SEEomegaW',
            'SCEeps',
            'SCEepsW',
            'SCEomega',
            'SCEomegaW',
            'TPerRiskyBondDDiv',
            'TPerRiskyBondCorrEpsWlogDDiv')

  if (!(statsName %in% allowedStatsNames)) {
    stop('No such shock \n\n')
  }

  ## Transforms state position on the grid into grid location
  getCurPos <- function(Nu, XX, SigmaSq, XXW, SigmaSqW){
    curNu       <- which(Nu[1]       == fineStateGridNu)
    curXX       <- which(XX[1]       == fineStateGridXX)
    curSigmaSq  <- which(SigmaSq[1]  == fineStateGridSigmaSq)
    curXXW      <- which(XXW[1]      == fineStateGridXXW)
    curSigmaSqW <- which(SigmaSqW[1] == fineStateGridSigmaSqW)

    curPos <- ((curSigmaSqW - 1) * nFineStateGridXXW * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                      (curXXW-1) * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                                (curSigmaSq-1) * nFineStateGridXX * nFineStateGridNu +
                                            (curXX - 1) * nFineStateGridNu +
                                                        curNu)
    return(curPos)
  }

  ## Read grid parameters
  fineStateGridList        <- createFineStateGrid(countryToUse,controlVarNAPi,
                          ParEst,UnobsPosInfo)

  fineStateGridNu          <- fineStateGridList$gridNu
  fineStateGridXX          <- fineStateGridList$gridXX
  fineStateGridXXW         <- fineStateGridList$gridXXW
  fineStateGridSigmaSq     <- fineStateGridList$gridSigmaSq
  fineStateGridSigmaSqW    <- fineStateGridList$gridSigmaSqW

  nFineStateGridNu         <- length(fineStateGridNu)
  nFineStateGridXX         <- length(fineStateGridXX)
  nFineStateGridXXW        <- length(fineStateGridXXW)
  nFineStateGridSigmaSq    <- length(fineStateGridSigmaSq)
  nFineStateGridSigmaSqW   <- length(fineStateGridSigmaSqW)

  ## Read consumption process parameters
  sigmaSqConst             <- ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW            <- ParEst[bigDataPosInfo$sigmaSqConstW]

  ## Read some techinical parameters
  maxMaturityTPerBonds     <- controlVarNAPi$maxMaturityTPerBonds
  cutOff                   <- controlVarNAPi$cutOff

  ## Initialize endogenous elasticities
  statsVal                 <- vector("list", maxMaturityTPerBonds)

  ## Set states for which to compute elasticities
  Nu                       <- rep(0,            1)
  XXW                      <- rep(0,            1)
  XX                       <- rep(0,            1)
  SigmaSqW                 <- rep(sigmaSqConstW,1)
  SigmaSq                  <- rep(sigmaSqConst, 1)
  DD                       <- rep(1,            1)

  ## Put on the grid
  NuOnFineGrid             <- numeric(1)
  XXOnFineGrid             <- numeric(1)
  XXWOnFineGrid            <- numeric(1)
  SigmaSqOnFineGrid        <- numeric(1)
  SigmaSqWOnFineGrid       <- numeric(1)
  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes <- matrix(FALSE,
                nFineStateGridSigmaSqW  ,nFineStateGridSigmaSq)
  for (iiSigmaSq in (1:nFineStateGridSigmaSq)){
    fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[,iiSigmaSq] <-
      (fineStateGridSigmaSq[iiSigmaSq] + fineStateGridSigmaSqW >= cutOff)
  }

  for (ii in c(1)) {
    NuInd              <- which.min(abs(fineStateGridNu-Nu[ii]))
    NuOnFineGrid[ii]   <- fineStateGridNu[NuInd]

    XXInd              <- which.min(abs(fineStateGridXX-XX[ii]))
    XXOnFineGrid[ii]   <- fineStateGridXX[XXInd]

    XXWInd             <- which.min(abs(fineStateGridXXW-XXW[ii]))
    XXWOnFineGrid[ii]  <- fineStateGridXXW[XXWInd]

    SigmaSqInd         <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
    SigmaSqWInd        <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))

    if (fineStateGridSigmaSq[SigmaSqInd] +
        fineStateGridSigmaSqW[SigmaSqWInd] >= cutOff){
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- fineStateGridSigmaSq[SigmaSqInd]
    } else {
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <-
       min(fineStateGridSigmaSq[fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[SigmaSqWInd,]])
      SigmaSqInd             <- which.min(abs(SigmaSqOnFineGrid[ii] - SigmaSq[ii]))
    }
  }
  filename <- file.path(outDir,
    paste(c(statsName,GlobalCountryName,'Rda'), collapse = '.'))
  load(filename)

  for (ii in c(1:maxMaturityTPerBonds)){
    statsVal[[ii]] <- get(statsName)[[ii]][getCurPos(NuOnFineGrid[1],
                            XXOnFineGrid[1],
                            SigmaSqOnFineGrid[1],
                            XXWOnFineGrid[1],
                            SigmaSqWOnFineGrid[1])]
  }

  statsMean <- lapply(statsVal,mean,simplify = TRUE)
  statsMean <- unlist(statsMean)

  output  <- list(statsMean           = statsMean,
          XXW                 = XXW,
          XX                  = XX,
          SigmaSqW            = SigmaSqW,
          SigmaSq             = SigmaSq,
          XXWOnFineGrid       = XXWOnFineGrid,
          XXOnFineGrid        = XXOnFineGrid,
          SigmaSqWOnFineGrid  = SigmaSqWOnFineGrid,
          SigmaSqOnFineGrid   = SigmaSqOnFineGrid)

  return(output)
}

GetStats2 <- function(outputEZW,
                      controlVarNAPi,
                      UnobsPosInfo)
{
  # Evaluates several statistics that envolve integration at different
  # points of state space
  #
  # The difference from GetStats is that the current function
  # evaluates the statistics in more than just one point of state
  # space.
  #

  getCurPos <- function(Nu, XX, SigmaSq, XXW, SigmaSqW){
    curNu       <- which(Nu[1]       == fineStateGridNu)
    curXX       <- which(XX[1]       == fineStateGridXX)
    curSigmaSq  <- which(SigmaSq[1]  == fineStateGridSigmaSq)
    curXXW      <- which(XXW[1]      == fineStateGridXXW)
    curSigmaSqW <- which(SigmaSqW[1] == fineStateGridSigmaSqW)

    curPos <- ((curSigmaSqW - 1) * nFineStateGridXXW * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                        (curXXW-1) * nFineStateGridSigmaSq * nFineStateGridXX * nFineStateGridNu +
                                  (curSigmaSq-1) * nFineStateGridXX * nFineStateGridNu +
                                            (curXX - 1) * nFineStateGridNu +
                                                          curNu)
    return(curPos)
  }
  ## Read grid parameters
  fineStateGridList        <- createFineStateGrid(countryToUse,
                          controlVarNAPi,
                          ParEst,
                          UnobsPosInfo)

  fineStateGridNu          <- fineStateGridList$gridNu
  fineStateGridXX          <- fineStateGridList$gridXX
  fineStateGridXXW         <- fineStateGridList$gridXXW
  fineStateGridSigmaSq     <- fineStateGridList$gridSigmaSq
  fineStateGridSigmaSqW    <- fineStateGridList$gridSigmaSqW

  nFineStateGridNu         <- length(fineStateGridNu)
  nFineStateGridXX         <- length(fineStateGridXX)
  nFineStateGridXXW        <- length(fineStateGridXXW)
  nFineStateGridSigmaSq    <- length(fineStateGridSigmaSq)
  nFineStateGridSigmaSqW   <- length(fineStateGridSigmaSqW)

  ## Read consumption process parameters
  ParEst                   <- outputEZW$ParEst
  sigmaSqOmega             <- ParEst[bigDataPosInfo$sigmaSqOmega]
  sigmaSqOmegaW            <- ParEst[bigDataPosInfo$sigmaSqOmegaW]
  gammma                   <- ParEst[bigDataPosInfo$gammma]
  rho                      <- ParEst[bigDataPosInfo$rho]
  rhoW                     <- ParEst[bigDataPosInfo$rhoW]
  xi                       <- ParEst[bigDataPosInfo$xi][countryToUse]
  lambda                   <- ParEst[bigDataPosInfo$lambda]
  lambdaW                  <- ParEst[bigDataPosInfo$lambdaW]
  mu                       <- ParEst[bigDataPosInfo$mu][countryToUse]
  chiSq                    <- ParEst[bigDataPosInfo$chiSq][countryToUse]
  chiSqW                   <- ParEst[bigDataPosInfo$chiSqW]
  sigmaSqNu                <- ParEst[bigDataPosInfo$sigmaSqNu][countryToUse]
  sigmaSqConst             <- ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]
  sigmaSqConstW            <- ParEst[bigDataPosInfo$sigmaSqConstW]

  ## Read some techinical parameters
  cutOff                   <- controlVarNAPi$cutOff
  nSim                     <- 1000

  ## Initialize state variables, Eta shocks, consumption and dividend processes
  XX                       <- rep(0,nSim)
  XXW                      <- rep(0,nSim)
  Nu                       <- rep(0,nSim)
  SigmaSqW                 <- rep(sigmaSqConstW,nSim)
  SigmaSq                  <- rep(sigmaSqConst, nSim)
  EpsW                     <- rep(0,            nSim)
  Eps                      <- rep(0,            nSim)

  ## Simulate model: shocks occur in the second period
  set.seed(5)
  OmegaW  <- rnorm(nSim,0,sqrt(sigmaSqOmegaW))
  Omega   <- rnorm(nSim,0,sqrt(sigmaSqOmega))
  EpsW[2] <- rnorm(1,0,sqrt(SigmaSqW[1]))
  Eps[2]  <- rnorm(1,0,sqrt(SigmaSqW[1] + SigmaSq[1]))
  for (tt in 2:(nSim-1)) {
    SigmaSqW[tt]  <- max(sigmaSqConstW
               + gammma * (SigmaSqW[tt-1] - sigmaSqConstW)
               + OmegaW[tt],cutOff)
    SigmaSq[tt]   <- (sigmaSqConst
               + gammma * (SigmaSq[tt-1] - sigmaSqConst)
               + Omega[tt])
    EpsW[tt+1]    <- rnorm(1,0,sqrt(SigmaSqW[tt]))
    Eps[tt+1]     <- rnorm(1,0,sqrt(max(SigmaSqW[tt] + SigmaSq[tt],cutOff)))
  }

  ## Put on the grid
  NuOnFineGrid             <- numeric(nSim)
  XXOnFineGrid             <- numeric(nSim)
  XXWOnFineGrid            <- numeric(nSim)
  SigmaSqOnFineGrid        <- numeric(nSim)
  SigmaSqWOnFineGrid       <- numeric(nSim)
  fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes <-
      matrix(FALSE,nFineStateGridSigmaSqW  ,nFineStateGridSigmaSq)
  for (iiSigmaSq in (1:nFineStateGridSigmaSq)){
    fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[,iiSigmaSq] <-
      (fineStateGridSigmaSq[iiSigmaSq] + fineStateGridSigmaSqW >= cutOff)
  }

  for (ii in c(1:nSim)) {
    NuInd              <- which.min(abs(fineStateGridNu-Nu[ii]))
    NuOnFineGrid[ii]   <- fineStateGridNu[NuInd]

    XXInd              <- which.min(abs(fineStateGridXX-XX[ii]))
    XXOnFineGrid[ii]   <- fineStateGridXX[XXInd]

    XXWInd             <- which.min(abs(fineStateGridXXW-XXW[ii]))
    XXWOnFineGrid[ii]  <- fineStateGridXXW[XXWInd]

    SigmaSqInd         <- which.min(abs(fineStateGridSigmaSq-SigmaSq[ii]))
    SigmaSqWInd        <- which.min(abs(fineStateGridSigmaSqW-SigmaSqW[ii]))

    if (fineStateGridSigmaSq[SigmaSqInd] + fineStateGridSigmaSqW[SigmaSqWInd] >= cutOff){
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- fineStateGridSigmaSq[SigmaSqInd]
    } else {
      SigmaSqWOnFineGrid[ii] <- fineStateGridSigmaSqW[SigmaSqWInd]
      SigmaSqOnFineGrid[ii]  <- min(fineStateGridSigmaSq[fineStateGridSigmaSq_fineStateGridSigmaSqWIndexes[SigmaSqWInd,]])
      SigmaSqInd             <- which.min(abs(SigmaSqOnFineGrid[ii] - SigmaSq[ii]))
    }
  }

  ## Compute stat1
  load(file.path(outDir, paste(c('VepsWoverSigmaSqW',GlobalCountryName,'Rda'), collapse = '.')))
  Stat1 <- numeric(nSim)
  for (ii in c(1:nSim)){
    Stat1[ii]   <- VepsWoverSigmaSqW[getCurPos(NuOnFineGrid[ii],
                          XXOnFineGrid[ii],
                          SigmaSqOnFineGrid[ii],
                          XXWOnFineGrid[ii],
                          SigmaSqWOnFineGrid[ii])]
  }
  rm("VepsWoverSigmaSqW")

  output  <- list(Nu                  = Nu,
          XXW                 = XXW,
          XX                  = XX,
          SigmaSqW            = SigmaSqW,
          SigmaSq             = SigmaSq,
          NuOnFineGrid        = NuOnFineGrid,
          XXWOnFineGrid       = XXWOnFineGrid,
          XXOnFineGrid        = XXOnFineGrid,
          SigmaSqWOnFineGrid  = SigmaSqWOnFineGrid,
          SigmaSqOnFineGrid   = SigmaSqOnFineGrid,
          OmegaW              = OmegaW,
          Omega               = Omega,
          EpsW                = EpsW,
          Eps                 = Eps)

  output$Stat1 <- Stat1

  return(output)
}

## A plotting function
plotds  <- function(xx,
                      yy,
                      title.main       = NA,
                      title.x          = NA,
                      title.y          = NA,
                      ylimTemp         = range(yy),
                      xlimTemp         = range(xx),
                      width.line       = 2,
                      type.line        = "l",
                      color.line       = 'coral',
                      color.axis       = "grey75",
                      color.axis.title = "grey30",
                      width.axis       = 0.75,
                      tick.length      = 0.015)
{
  # Control margins, label distance from the axes and label alignment
  par(mar=c(3.1,   # bottom
      4.1,   # left
      3.1,   # top
      2.1),  # right
    mgp=c(axis.title.position = 3,
      axis.label.position = 0.5,
      axis.line.position  = 0),
    las=1)
  plot(xx, as.ts(yy),
     main = title.main,
     xlab = NA,
     ylab = NA,
     type = type.line,
     lwd  = width.line,
     ylim = ylimTemp,
     xlim = xlimTemp,
     col  = color.line,
     axes = FALSE)
  axis(1,
    col      = color.axis,
    lwd      = width.axis,
    col.axis = color.axis.title,
    tck      = tick.length)
  axis(2,
    col      = color.axis,
    lwd      = width.axis,
    col.axis = color.axis.title,
    tck      = tick.length)
  box(bty      = "l",
    col      = color.axis,
    lwd      = width.axis)
  loc <- par("usr")
  text(loc[1],
    loc[4],
    title.y,
    xpd = T,
    pos = 3, # comment this if need allignment
    adj = c(1,0),
    cex = 1.2)
  text(loc[2],
    loc[3],
    title.x,
    xpd = T,
    adj = c(1,4),
    cex = 1.2)
}