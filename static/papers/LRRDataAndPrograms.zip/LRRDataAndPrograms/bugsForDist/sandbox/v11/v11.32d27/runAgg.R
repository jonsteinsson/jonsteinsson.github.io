## The program puts together posterior draws saved in different batches 
## created by runModel.R. Then it calculates some stats, and 
## creates plots and tables.
##
## Emi Nakamura, Dmitriy Sergeyev, Jon Steinsson (July 2016)
################################################################################
rm(list = ls())
gc()
source('funcs.R')
source('funcsAgg.R')

## Define variables with directory information (second function in funcs.R)
dirInfo        <- getDirInfo()
outDir         <- dirInfo$outDir
prefixDir      <- dirInfo$prefixDir

## Import real world data (function in funcs.R)
allData        <- readData(prefixDir) 

## Import control variables (see first function in funcs.R)
controlVar     <- getControlVar()   	

## Import more control variables (see first function in funcsAgg.R)
controlAgg     <- getControlAgg()   	

## Load variables that contain parameter names and information about 
## their position in the parameter vector

## Names/Positions used for each batch (function in funcs.R)
NamesNPosInfo  <- getNamesNPosInfo(allData) 
UnobsPosInfo   <- NamesNPosInfo$UnobsPosInfo

## Names/Positions used for aggregated sample (function in funcsAgg.R)
bigDataPosInfo <- getBigDataPosInfo(UnobsPosInfo) 

## Gets information on which runs are to be aggregated (function in funcsAgg.R)
runsToUse      <- getRunsToUse() 

## Combines runs without combining chains (function in funcsAgg.R)
if (controlAgg$combineRuns) combineRuns(UnobsPosInfo, bigDataPosInfo, runsToUse) 

## If a run of runModel.R created more than one chain at once, this following 
## function will aggregate the chains. Otherwise this function just
## creates files with extension _pooled (e.g., bigDataDS_pooled.Rda) that are
## the same as the files without the extenssion (e.g., bigDataDS.Rda)
if (controlAgg$combineChains) combineChains(UnobsPosInfo, bigDataPosInfo) 

## Get parameter estimates
ParEst <- getParEstimates(bigDataPosInfo,controlAgg$usePooledChains,
                            controlAgg$chainToUse)

## Create summary of prior and posterior for parameters that are COMMON across 
## countries
summaryCommonParameters(controlAgg,bigDataPosInfo)  

## Create summary of prior and posterior for parameters that are DIFFERENT 
## across countries
summaryCountryParameters(controlAgg,bigDataPosInfo) 

## Create main figures
simPlotMany(bigDataPosInfo)   		   				

## Save estaimted xxW and sigmaSqW states in excel file 
saveWorldComponents(controlAgg,bigDataPosInfo)

################################################################################
##                Results based on LONG simulation of the data
################################################################################

## Computes states statistics by simulating long data. In particulat, this
## function computes the frequency of hitting the lower bound for volatility
## The length of the simulated sample is controlAgg$simLengthLong 
modelStatesStats(controlAgg, allData, bigDataPosInfo, ParEst, prefixDir, outDir)                    					  
																										      
################################################################################
##                Results based on MONTE CARLO simulation of the data
################################################################################

## Computes consumption standard deviations and correlations using MONTE CARLO 
## simulations of length(IIW) periods
modelConsumptionSDandCorr(controlAgg, allData, bigDataPosInfo, ParEst, prefixDir, 
                            outDir, MCarlo=1000, useEstInitials=0)          

## Computes consumption and other states statistics by simulating artificial 
## data for length(IIW) periods
modelConsumptionStats(controlAgg, allData, bigDataPosInfo, ParEst, prefixDir, 
                        outDir, MCarlo=1000,useEstInitials=1,plotSimData=0) 
																																 																																 
## Creates VR for consumption growth for all countries AT horizon KK using 
## many simulated data samples (Monte Carlo)
VRsimMonteCarloConsumption(controlAgg, allData, bigDataPosInfo, ParEst, 
                            prefixDir, outDir, KK=15,MCarlo=1000)                    

################################################################################
##                    Results based on actual data
################################################################################

## Compute actual data consumption growth std and corr
realConsumptionStats(controlAgg, allData, bigDataPosInfo) 						    											 

## Plot consumption series for selected countries
realConsumptionLevel(controlAgg,allData,bigDataPosInfo,
                        whichCountries = c(6,7,8,16))											 																 

## Create VR for actual consumption growth for ALL horizons upto KK years
VRrealCmany(controlAgg,allData, bigDataPosInfo, KK = 30)  																		 

################################################################################
##              Stochastic Volatility Stats based on estimated data
################################################################################

## Creates series of MEAN of estimated stochastic volatility for ALL countries
summarySV(controlAgg,bigDataPosInfo) 										                               

## Creates series of MEAN and QUANTILES for estimated stochastic volatility 
## for SOME countries
summarySVsomeCountries(controlAgg,bigDataPosInfo,whichCountries = c(15,16))                

## Computes and saves quantiles of the world SV                
summarySVWorld(controlAgg,bigDataPosInfo)								                                   

## Compare amount of LRR across our results, BY,  and BKY using AR(5) regression
compareLRRinNSSvsBY(controlAgg,ParEst,bigDataPosInfo,allData,
                        countryToUse = "United.States")               

## Compare amount of SV across our results, BY,  and BKY using quantile method
compareSVinNSSvsBY(controlAgg, ParEst,bigDataPosInfo,allData,
                        countryToUse = "United.States")               

## Creates VR for SV using actual data at horizon KK 
VRofSVreal(controlAgg,    allData, bigDataPosInfo, KK = 15)  								               

## Creates VR for SV using real data for horizons upto KK 
VRofSVrealMany(controlAgg,allData, bigDataPosInfo, KK = 30) 			    				               

## Creates distribution of VR of SV using simulated data at horizon KK 
VRofSVsimDataMonteCarlo(controlAgg, allData, bigDataPosInfo, ParEst, 
                          prefixDir, outDir, KK=15,MCarlo=1000) 