#!/bin/sh
#runAgg.sh
#Torque script to run R program

 
#Torque directives
#PBS -N runAgg
#PBS -W group_list=yetisscc
#PBS -l nodes=1,walltime=1:00:00:00,mem=1900mb
#PBS -M ds2635@columbia.edu
#PBS -m abe
#PBS -V

#set output and error directories (SSCC example here)
#PBS -o localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.32d8
#PBS -e localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.32d8

#Command to execute Matlab code
R CMD BATCH --no-save runAgg.R $PBS_JOBNAME.routput