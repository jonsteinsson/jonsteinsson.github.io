#!/bin/sh
#runNAPe.Australia.sh

#Torque directives
#PSB -N runNAPe.Australia
#PBS -W group_list=yetisscc
#PBS -l nodes=2:ppn=16,walltime=11:59:59,mem=23900mb
#PBS -M ds2635@columbia.edu
#PBS -m abe
#PBS -V

#set output and error directories
#PBS -o localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.32d27
#PBS -e localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.32d27

#Command to execute R code
R CMD BATCH --no-save --vanilla runNAPe.Australia.R $PBS_JOBNAME.routput

#End of script
