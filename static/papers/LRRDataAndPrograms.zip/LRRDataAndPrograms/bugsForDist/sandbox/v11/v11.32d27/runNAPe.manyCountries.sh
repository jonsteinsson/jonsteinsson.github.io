#!/bin/sh
#runNAPe.manyCountries.sh

#Torque directives
#PSB -N runNAPe.manyCountries
#PBS -W group_list=yetisscc
#PBS -l nodes=1:ppn=1,walltime=11:59:59,mem=23900mb
#PBS -M ds2635@columbia.edu
#PBS -m abe
#PBS -V

#set output and error directories
#PBS -o localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.32d22
#PBS -e localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.32d22

#Command to execute R code
R CMD BATCH --no-save --vanilla runNAPe.manyCountries.R $PBS_JOBNAME.routput

#End of script
