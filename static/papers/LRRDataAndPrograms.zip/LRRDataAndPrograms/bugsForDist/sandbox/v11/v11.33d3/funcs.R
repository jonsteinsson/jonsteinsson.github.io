## The file contains support functions for runModel.R       
##                                                          
## Emi Nakamura, Dmitriy Sergeyev, Jon Steinsson (July 2016)                                         
################################################################################

## Load external R libraries
if (.Platform$OS.type == "unix"){
   ## On Hotfoot
   # source("/hmt/hpcstorage1/hpc/sscc/work/projects/lrr/lrrRprofile")
   # .libPaths('/hmt/hpcstorage1/hpc/sscc/work/projects/lrr/lrrRlib')
   ## On Yeti
   source("/vega/sscc/work/projects/lrr/lrrRprofile")
   .libPaths('/vega/sscc/work/projects/lrr/lrrRlib')
}
libs <- c('RColorBrewer',
          'zoo',
          'rjags',
          'arm',
          'mvtnorm')
lapply(libs, require, character.only = T)
options(digits = 10)


getControlVar <- function()
{
    newInit      <- 1     # 1 if new initial values; 0 if using old initial values
    Niter        <- 50000 # Number of iterations in each batch
    NinitThin    <- max(1, floor(Niter/650)) # Amount by which coda thins samples before saving results
    Nadapt       <- 1000  # Number of iterations that jags uses to adapt the MCMC algorithm
                          # (e.g., variance of random-walk Metropolis-Hastings steps)
                          # Jags will give warning message if Nadapt is too small.

    NRuns        <- 110   # Number of batches to run in runModel.R
    nFirstRun    <- 1     # Number to be put on first batch. This should be 1 if newInit = 1, but >1 if newInit = 0 since in these cases user will be adding to exiting sample.
    noRun        <- 0     # Doesn't run bugs when noRun = 1

    nOfChains    <- 1     # Number of chains for bugs to create.

    priorType    <- 'YY'  # 'XX' or 'YY' (see getNewInitialValues and related functions below)
    nOfRun       <- 1

    useRealData  <- 1     # Estimates using real world data if useRealData = 1. Otherwise uses simulated data.

    seedForBugs  <- sample(seq.int(-100000, -10000), 1) # Set a random seed

    return(list(newInit      = newInit,
                Niter        = Niter,
                NinitThin    = NinitThin,
                Nadapt       = Nadapt,
                NRuns        = NRuns,
                nFirstRun    = nFirstRun,
                noRun        = noRun,
                nOfChains    = nOfChains,
                nOfRun       = nOfRun,
                priorType    = priorType,
                useRealData  = useRealData,
                seedForBugs  = seedForBugs))
}

## Get outDir
getDirInfo <- function()
{
    ## On Hotfoot
    #prefixDir        <- '/hmt/hpcstorage1/hpc/sscc/work/projects/lrr/'

    ## On Yeti
    #prefixDir        <- '/vega/sscc/work/projects/lrr'

    ## On PCs
    #prefixDir        <- 'C:/Users/Diman/Dropbox/LongRunRisk/bugs/'

    ## On office computer
    prefixDir        <- 'C:/Users/Sergeyev/Dropbox/LongRunRisk/bugs/'

    outDir           <- file.path(prefixDir, 'data/v11/v11.33d3')

    return(list(outDir    = outDir,
                prefixDir = prefixDir))
}

## Read Data
###############################################################################
# readData reads the Barro-Ursua consumption data from a file and returns data for the
# 16 countries we use in our analysis.
readData <- function(prefixDir)
{
    filename                 <- file.path(prefixDir, 'sandbox/v11/cdata20111116.txt')
    dataAll                  <- read.table(filename, header = T, sep = "\t")
    dataAll                  <- as.list(dataAll)
    nCountries               <- length(dataAll)
    attr(dataAll,"names")[1] <- "year"
    dataYears                <- as.matrix(dataAll[[1]])

    ## Create matrix with all consumption data
    cData                    <- dataAll[[2]]
    for (ii in 3:nCountries)
        cData                <- cbind(cData,dataAll[[ii]])
    attr(cData,"dimnames")   <- NULL
    cData                    <- log(cData)

    ## Cut off years at the beginning for which no data is observed
    ii <- 0
    while (ii == 0) {
        tempInd             <- is.na(cData[1,])
        if (sum(tempInd)    < length(tempInd)) {
            ii              <- 1
        } else {
            cData           <- cData[-1,]
            dataYears       <- as.matrix(dataYears[-1,])
        }
    }
    firstYear               <- dataYears[1,1]
    ## Save country names
    countryNames            <- attr(dataAll,"names")
    countryNames            <- countryNames[2:nCountries]
    ## Exclude data from countries not to be used in analysis
    countriesToExclude      <- c("Austria","Colombia","Egypt","Greece","Iceland","New.Zealand","India",
                               "Indonesia","Malaysia","Philippines","Singapore","S..Africa",
                               "Sri.Lanka","Turkey","Uruguay","Venezuela","Argentina","Brazil","Chile",
                               "Mexico","Peru","Japan","Korea","Taiwan")
    excludedCountries       <- numeric(length(countryNames))
    for (ii in 1:length(countriesToExclude)) {
        excludedCountries   <- excludedCountries + (countryNames == countriesToExclude[ii])
    }
    excludedCountries       <- which(as.logical(excludedCountries))
    cData                   <- cData[,-excludedCountries]
    countryNames            <- countryNames[-excludedCountries]

    ## Create data on starting year and ending year for each country
    startYears              <- matrix(NA,length(countryNames),1)
    for (ii in 1:length(countryNames)) {
        tempInd             <- is.na(cData[,ii])
        tempInd             <- sum(tempInd)
        startYears[ii,1]    <- firstYear + tempInd
    }
    endYears                <- matrix(2009,length(countryNames),1)

    ## Make 1890 the starting data
    whichYears              <- 1:(1889-firstYear+1)
    cData[whichYears,]      <- NA
    tempInd                 <- which(startYears < 1890)
    startYears[tempInd]     <- 1890

    ## Make 1950 the Start Date
    tempReduce2 <- 1
    if (tempReduce2) {
        whichYears          <- 1:(1949-firstYear+1)
        cData[whichYears,]  <- NA
        tempInd             <- which(startYears < 1950)
        startYears[tempInd] <- 1950
    }
    ## Make data into long vector (and all other variables also vectors)
    nYears                  <- dim(cData)[1]
    nCountries              <- dim(cData)[2]
    TempInd                 <- !is.na(cData)
    whichTempInd            <- which(TempInd)
    sumTempInd              <- sum(TempInd)
    statePosInfo            <- matrix(NA,nYears,nCountries)
    statePosInfo[whichTempInd] <- 1:sumTempInd
    posFirst                <- numeric(nCountries)
    posLast                 <- statePosInfo[nYears,]
    for (ii in 1:nCountries) posFirst[ii] <- min(statePosInfo[!is.na(statePosInfo[ ,ii]),ii])
    cData                   <- cData[whichTempInd]
    dataYears               <- as.numeric(dataYears)
    startYears              <- as.numeric(startYears)
    endYears                <- as.numeric(endYears)

    ## Create data on position of each point relative to starting point for that country's data
    posIIW                  <- numeric(length(cData))
    for (ii in 1:nCountries) {
        posIIW[posFirst[ii]:posLast[ii]] <- seq(startYears[ii] - min(startYears) + 1,
                                                endYears[ii] - min(startYears) + 1, by = 1)
    }
    nPeriods <- max(posIIW)

    return(list(dataAll      = dataAll,
                cData        = cData,
                countryNames = countryNames,
                dataYears    = dataYears,
                startYears   = startYears,
                endYears     = endYears,
                posFirst     = posFirst,
                posLast      = posLast,
                posIIW       = posIIW,
                nPeriods     = nPeriods))
}

## Model Data
###################################################################
## This function creates a list that contains the data as well as
## information on hyperparameters and other information that
## needs to be passed to bugs to estimate the model

getModelData <- function(allData)
{
    cData               <- allData$cData
    posFirst            <- allData$posFirst
    posLast             <- allData$posLast
    posIIW              <- allData$posIIW

    nCountries          <- length(allData$countryNames)
    nPeriods            <- max(posIIW)

    ## Set Hyperparameters

    # lambda
    low.lambda          <- -0.995
    high.lambda         <- 0.995
    a.lambda            <- 1
    b.lambda            <- 1
    prior.lambda        <- "Unif"

    # lambdaW
    low.lambdaW         <- -0.995
    high.lambdaW        <- 0.995
    a.lambdaW           <- 1
    b.lambdaW           <- 1
    prior.lambdaW       <- "Unif"

    # rho
    low.rho             <- 0.005
    high.rho            <- 0.995
    a.rho               <- 1
    b.rho               <- 1
    prior.rho           <- "Unif"

    # rhoW
    low.rhoW            <- 0.005
    high.rhoW           <- 0.995
    a.rhoW              <- 1
    b.rhoW              <- 1
    prior.rhoW          <- "Unif"

    # chi
    low.chiSq           <- 0.01^2
    high.chiSq          <- 5^2
    a.chiSq             <- 1
    b.chiSq             <- 1
    prior.chiSq         <- "Unif"

    # chiW
    low.chiSqW          <- 0.01^2
    high.chiSqW         <- 5^2
    a.chiSqW            <- 1
    b.chiSqW            <- 1
    prior.chiSqW        <- "Unif"

    # xi
    low.xi              <- rep(0.0001,16)
    high.xi             <- rep(1,16)
    a.xi                <- 1
    b.xi                <- 1
    prior.xi            <- "Unif"

    # Mu
    mu.mu               <- 0.015
    tau.mu              <- 0.03^(-2)
    prior.mu            <- "Norm"

    # sigmaSqConst
    low.sigmaSqConst    <- 0.0001^2
    high.sigmaSqConst   <- 0.02^2
    a.sigmaSqConst      <- 1
    b.sigmaSqConst      <- 1
    prior.sigmaSqConst  <- "Unif"

    # sigmaSqNu
    low.sigmaSqNu       <- 0.0001^2
    high.sigmaSqNu      <- 0.01^2
    a.sigmaSqNu         <- 1
    b.sigmaSqNu         <- 1
    priot.sigmaSqNu     <- "Unif"

    # gammma
    low.gammma          <- 0.005
    high.gammma         <- 0.98
    a.gammma            <- 1
    b.gammma            <- 1
    prior.gammma        <- "Unif"

    # tauOmega
    low.sigmaSqOmega    <- 0.000001^2
    high.sigmaSqOmega   <- 0.000050^2
    a.sigmaSqOmega      <- 1
    b.sigmaSqOmega      <- 1
    prior.sigmaSqOmega  <- "Unif"

    # sigmaSqConstW
    low.sigmaSqConstW   <- 0.005000^2
    high.sigmaSqConstW  <- 0.005001^2
    a.sigmaSqConstW     <- 1
    b.sigmaSqConstW     <- 1
    prior.sigmaSqConstW <- "Unif"

    # tauOmegaW
    low.sigmaSqOmegaW   <- 0.000001^2
    high.sigmaSqOmegaW  <- 0.000020^2
    a.sigmaSqOmegaW     <- 1
    b.sigmaSqOmegaW     <- 1
    prior.sigmaSqOmegaW <- "Unif"

    # initial values for yy
    low.yy1             <- cData[posFirst] - 0.04
    high.yy1            <- cData[posFirst] + 0.04

    mean.yy1            <- cData[posFirst]
    tau.yy1             <- 0.0001
    prior.yy1           <- "Norm"

    # initial values for sigmaSqW
    mean.sigmaSqW1      <- (low.sigmaSqConstW + high.sigmaSqConstW)/2
    tau.sigmaSqW1       <- 1/0.0001^2

    # initial values for sigmaSq
    tau.sigmaSq1        <- 1/0.0001^2

    # initial values for xx
    mean.xx1            <- 0
    tau.xx1             <- 1/(10^2*mean.sigmaSqW1)
    prior.xx1           <- "Norm"

    # initial values for xxW
    mean.xxW1           <- 0
    tau.xxW1            <- 1/(10^2*mean.sigmaSqW1)
    prior.xxW1          <- "Norm"

    cutOff              <- 1e-8

    return(list(cc                 = cData,
                nCountries         = nCountries,
                nPeriods           = nPeriods,
                posFirst           = posFirst,
                posLast            = posLast,
                posIIW             = posIIW,

                mean.yy1           = mean.yy1,
                tau.yy1            = tau.yy1,

                mean.xx1           = mean.xx1,
                tau.xx1            = tau.xx1,

                mean.xxW1          = mean.xxW1,
                tau.xxW1           = tau.xxW1,

                tau.sigmaSq1       = tau.sigmaSq1,

                mean.sigmaSqW1     = mean.sigmaSqW1,
                tau.sigmaSqW1      = tau.sigmaSqW1,

                low.chiSq          = low.chiSq,
                high.chiSq         = high.chiSq,
                a.chiSq            = a.chiSq,
                b.chiSq            = b.chiSq,

                low.chiSqW         = low.chiSqW,
                high.chiSqW        = high.chiSqW,
                a.chiSqW           = a.chiSqW,
                b.chiSqW           = b.chiSqW,

                low.xi             = low.xi,
                high.xi            = high.xi,
                a.xi               = a.xi,
                b.xi               = b.xi,

                mu.mu              = mu.mu,
                tau.mu             = tau.mu,

                low.gammma         = low.gammma,
                high.gammma        = high.gammma,
                a.gammma           = a.gammma,
                b.gammma           = b.gammma,

                low.lambda         = low.lambda,
                high.lambda        = high.lambda,
                a.lambda           = a.lambda,
                b.lambda           = b.lambda,

                low.lambdaW        = low.lambdaW,
                high.lambdaW       = high.lambdaW,
                a.lambdaW          = a.lambdaW,
                b.lambdaW          = b.lambdaW,

                low.rho            = low.rho,
                high.rho           = high.rho,
                a.rho              = a.rho,
                b.rho              = b.rho,

                low.rhoW           = low.rhoW,
                high.rhoW          = high.rhoW,
                a.rhoW             = a.rhoW,
                b.rhoW             = b.rhoW,

                low.sigmaSqConst   = low.sigmaSqConst,
                high.sigmaSqConst  = high.sigmaSqConst,
                a.sigmaSqConst     = a.sigmaSqConst,
                b.sigmaSqConst     = b.sigmaSqConst,

                low.sigmaSqNu      = low.sigmaSqNu,
                high.sigmaSqNu     = high.sigmaSqNu,
                a.sigmaSqNu        = a.sigmaSqNu,
                b.sigmaSqNu        = b.sigmaSqNu,

                low.sigmaSqOmega   = low.sigmaSqOmega,
                high.sigmaSqOmega  = high.sigmaSqOmega,
                a.sigmaSqOmega     = a.sigmaSqOmega,
                b.sigmaSqOmega     = b.sigmaSqOmega,

                low.sigmaSqConstW  = low.sigmaSqConstW,
                high.sigmaSqConstW = high.sigmaSqConstW,
                a.sigmaSqConstW    = a.sigmaSqConstW,
                b.sigmaSqConstW    = b.sigmaSqConstW,

                low.sigmaSqOmegaW  = low.sigmaSqOmegaW,
                high.sigmaSqOmegaW = high.sigmaSqOmegaW,
                a.sigmaSqOmegaW    = a.sigmaSqOmegaW,
                b.sigmaSqOmegaW    = b.sigmaSqOmegaW,

                cutOff             = cutOff))
}

## Initial Values
#######################################################################

## getSavedInitialValues read in initial values from bugsSimInit.Rda
## This is an option for the first batch of a run. For all subsequent
## batches, these are the initial values that are used. bugsSimInit.Rda
## will then contain the last values from the previous batch

getSavedInitialValues <- function(outDir)
{
    load('bugsSimInit.Rda')
    bugsSimInitStart <- bugsSimInit
    filename <-  file.path(outDir, 'bugsSimInitStart.Rda')
    save(bugsSimInit, file = filename)

    return(bugsSimInit)
}

## getNewInitialValues calls one of several different functions
## defined below that create initial values with different characteristics
## The variable priorType in controlVar controls which initial values
## are chosen in the case when one chain is used

getNewInitialValues <- function(allData,UnobsPosInfo, controlVar)
{
    if (controlVar$nOfChains == 1) {
        if (controlVar$priorType == 'XX') {
            Out <- list(getInitialValuesAllXX(allData))
        } else {
            Out <- list(getInitialValuesAllYY(allData))
        }
    }
    if (controlVar$nOfChains == 2) {Out <- list(getInitialValuesAllXX(allData),getInitialValuesAllYY(allData))}

    return(Out)
}

## getInitialValuesAllXX produces initial values all the variation in the
## data attributed to XX and XXW

getInitialValuesAllXX <- function(allData)
{
    cData         <- allData$cData
    nPeriods      <- allData$nPeriods

    lengthWData   <- max(allData$posIIW)
    lengthData    <- length(cData)
    nCountries    <- length(allData$countryNames)

    posFirst      <- allData$posFirst
    posLast       <- allData$posLast
    posIIW        <- allData$posIIW

    ## State Variables
    cDataTemp <- cData
    mu <- numeric(nCountries)
    for (ii in 1:nCountries) {
        mu[ii] <- (cDataTemp[posLast[ii]]- cDataTemp[posFirst[ii]])/(posLast[ii]-posFirst[ii])
        cDataTemp[(posFirst[ii]+1):posLast[ii]] <- cDataTemp[(posFirst[ii]+1):posLast[ii]] - mu[ii]*1:(posLast[ii]-posFirst[ii])
    }
    DcDataTemp <- cDataTemp
    for (ii in 1:nCountries) {
        DcDataTemp[posFirst[ii]] <- NA
        DcDataTemp[(posFirst[ii]+1):posLast[ii]] <- cDataTemp[(posFirst[ii]+1):posLast[ii]] - cDataTemp[posFirst[ii]:(posLast[ii]-1)]
    }
    xxW           <- numeric(nPeriods)
    for (ii in 1:(nPeriods-1)) {
        intTemp <- (posIIW == ii+1 & !is.na(DcDataTemp))
        if (sum(intTemp) == 0) {
            xxW[ii] = 0;
        } else {
            xxW[ii] <- sum(DcDataTemp[intTemp])/sum(intTemp)
        }
    }
    xx            <- numeric(lengthData)
    for (ii in 1:nCountries) {
        for (jj in (posFirst[ii]+1):posLast[ii]) {
            if (!is.na(DcDataTemp[jj])) {
                xx[jj-1] <- DcDataTemp[jj] - xxW[posIIW[jj-1]]
            }
        }
    }
    yy            <- cData                             ## Pre stationary shock consumption
    etaW          <- numeric(nPeriods)
    sigmaSqTempW  <- rnorm(nPeriods, 0.02^2, 0.01^2)
    for (ii in 1:(nPeriods-1)) {
        sigmaSqTempW[ii] <- xxW[ii+1]-xxW[ii]
    }

    sigmaSqTemp   <- rnorm(lengthData, 0.02^2, 0.01^2)
    for (ii in 1:nCountries) {
        for (jj in (posFirst[ii]+1):posLast[ii]) {
            sigmaSqTemp[jj] <- xx[jj+1]-xx[jj]
        }
    }

    ## Country parameters
    sigmaSqNubeta     <- rep(0.2,nCountries)
    chiSqbeta         <- rep(0.2,nCountries)
    sigmaSqConstbeta  <- rep(0.8,nCountries)
    xibeta            <- rep(0.5,nCountries)

    ## Parameters
    rhobeta          <- 0.8
    rhoWbeta         <- 0.8
    gammmabeta       <- 0.8
    sigmaSqOmegabeta <- 0.8
    sigmaSqOmegabetaW<- 0.8
    sigmaSqConstbetaW<- 0.8
    lambdabeta       <- 0.5
    lambdabetaW      <- 0.5
    chiSqbetaW       <- 0.2

    inits <- list(yy                = yy,
                  xx                = xx,
                  xxW               = xxW,
                  etaW              = etaW,
                  xibeta            = xibeta,
                  sigmaSqTemp       = sigmaSqTemp,
                  sigmaSqTempW      = sigmaSqTempW,
                  mu                = mu,
                  sigmaSqOmegabeta  = sigmaSqOmegabeta,
                  sigmaSqOmegabetaW = sigmaSqOmegabetaW,
                  sigmaSqNubeta     = sigmaSqNubeta,
                  sigmaSqConstbeta  = sigmaSqConstbeta,
                  sigmaSqConstbetaW = sigmaSqConstbetaW,
                  chiSqbeta         = chiSqbeta,
                  chiSqbetaW        = chiSqbetaW,
                  rhobeta           = rhobeta,
                  rhoWbeta          = rhoWbeta,
                  gammmabeta        = gammmabeta,
                  lambdabeta        = lambdabeta,
                  lambdabetaW       = lambdabetaW)
    return(inits)
}

## getInitialValuesAllYY produces initial values in which XX = 0 and XXW = 0

getInitialValuesAllYY <- function(allData)
{
    cData         <- allData$cData
    nPeriods      <- allData$nPeriods
    lengthWData   <- max(allData$posIIW)
    lengthData    <- length(cData)
    nCountries    <- length(allData$countryNames)

    ## State variables
    xx            <- numeric(lengthData)               ## Long-run component of cons. growth
    xxW           <- numeric(nPeriods)                 ## Worlds LRR component of cons. growth
    yy            <- cData                             ## Pre stationary shock consumption
    etaW          <- numeric(nPeriods)
    sigmaSqTemp   <- rnorm(lengthData, 0.02^2, 0.01^2) #
    sigmaSqTempW  <- rnorm(nPeriods, 0.02^2, 0.01^2)

    ## Country parameters
    mu                <- rep(0.01,nCountries)
    sigmaSqNubeta     <- rep(0.8,nCountries)
    chiSqbeta         <- rep(0.8,nCountries)
    sigmaSqConstbeta  <- rep(0.2,nCountries)
    xibeta            <- rep(0.5,nCountries)

    ## Parameters
    rhobeta          <- 0.2
    rhoWbeta         <- 0.2
    gammmabeta       <- 0.2
    sigmaSqOmegabeta <- 0.2
    sigmaSqOmegabetaW<- 0.2
    sigmaSqConstbetaW<- 0.2
    lambdabeta       <- 0.5
    lambdabetaW      <- 0.5
    chiSqbetaW       <- 0.8

    inits <- list(yy                = yy,
                  xx                = xx,
                  xxW               = xxW,
                  etaW              = etaW,
                  xibeta            = xibeta,
                  sigmaSqTemp       = sigmaSqTemp,
                  sigmaSqTempW      = sigmaSqTempW,
                  mu                = mu,
                  sigmaSqOmegabeta  = sigmaSqOmegabeta,
                  sigmaSqOmegabetaW = sigmaSqOmegabetaW,
                  sigmaSqNubeta     = sigmaSqNubeta,
                  sigmaSqConstbeta  = sigmaSqConstbeta,
                  sigmaSqConstbetaW = sigmaSqConstbetaW,
                  chiSqbeta         = chiSqbeta,
                  chiSqbetaW        = chiSqbetaW,
                  rhobeta           = rhobeta,
                  rhoWbeta          = rhoWbeta,
                  gammmabeta        = gammmabeta,
                  lambdabeta        = lambdabeta,
                  lambdabetaW       = lambdabetaW)
    return(inits)
}


## Create List with Names and PosInfo for Output from bugs
#####################################################################

getNamesNPosInfo <- function(allData)
{
    cData       <- allData$cData
    lengthWData <- max(allData$posIIW)
    nCountries  <- length(allData$countryNames)

    UnobsNames    <- NULL
    UnobsPosInfo  <- NULL
    UnobsDim      <- NULL

    namesNPos <- list(UnobsNames = UnobsNames, UnobsPosInfo = UnobsPosInfo,
                      UnobsDim = UnobsDim)

    .getNamesNPosInfoState <-
        function(namesNPos,varName)
    {
        namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
        if (length(namesNPos$UnobsPosInfo) == 0) {
            TempStart <- 1
            TempEnd   <- length(cData)
        } else {
            TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
            TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+length(cData)
        }
        namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
        names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
        namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(length(cData)))
        return(namesNPos)
    }

    .getNamesNPosInfoWorldState <-
        function(namesNPos,varName)
    {
        namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
        if (length(namesNPos$UnobsPosInfo) == 0) {
            TempStart <- 1
            TempEnd   <- lengthWData
        } else {
            TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
            TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+lengthWData
        }
        namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
        names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
        namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(lengthWData))
        return(namesNPos)
    }

    .getNamesNPosInfoPar <-
        function(namesNPos,varName,varDim)
    {
        namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
        if (length(namesNPos$UnobsPosInfo) == 0) {
            TempStart <- 1
            TempEnd   <- varDim
        } else {
            TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
            TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+varDim
        }
        namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
        names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
        namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(varDim))
        return(namesNPos)
    }

    .getNamesNPosInfoCountryPar <-
        function(namesNPos,varName)
    {
        namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
        if (length(namesNPos$UnobsPosInfo) == 0) {
            TempStart <- 1
            TempEnd   <- nCountries
        } else {
            TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
            TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+nCountries
        }
        namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
        names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
        namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(nCountries))
        return(namesNPos)
    }

    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'chiSq')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'chiSqW',1)
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'chiSqbeta')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'chiSqbetaW',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'deviance',1)
    namesNPos <- .getNamesNPosInfoWorldState(namesNPos, 'etaW')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'gammma',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'gammmabeta',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'lambda',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'lambdaW',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'lambdabeta',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'lambdabetaW',1)
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'mu')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'rho',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'rhoW',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'rhoWbeta',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'rhobeta',1)
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'sigmaSq')
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqConst')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqConstW',1)
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqConstbeta')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqConstbetaW',1)
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqNu')
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqNubeta')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqOmega',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqOmegaW',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqOmegabeta',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqOmegabetaW',1)
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'sigmaSqTemp')
    namesNPos <- .getNamesNPosInfoWorldState(namesNPos, 'sigmaSqTempW')
    namesNPos <- .getNamesNPosInfoWorldState(namesNPos, 'sigmaSqW')
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'xi')
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'xibeta')
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'xx')
    namesNPos <- .getNamesNPosInfoWorldState(namesNPos, 'xxW')
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'yy')

    return(list(UnobsNames = namesNPos$UnobsNames, UnobsPosInfo = namesNPos$UnobsPosInfo, UnobsDim = namesNPos$UnobsDim))
}

## Save last values as bugsSimInit.Rda
#######################################################################
## This is done to be able to use these values as starting values in the
## next batch

saveLastValues <- function(UnobsPosInfo,runToSave, filename)
{
    load(filename)

    nChains  <- length(bugsSim)
    nKeep    <- dim(bugsSim[[1]])[1]

    tempUnobsPosInfo <- UnobsPosInfo[-c(which(names(UnobsPosInfo) == 'deviance'),
                                        which(names(UnobsPosInfo) == 'sigmaSq'),
                                        which(names(UnobsPosInfo) == 'sigmaSqW'),
                                        which(names(UnobsPosInfo) == 'rho'),
                                        which(names(UnobsPosInfo) == 'rhoW'),
                                        which(names(UnobsPosInfo) == 'lambda'),
                                        which(names(UnobsPosInfo) == 'lambdaW'),
                                        which(names(UnobsPosInfo) == 'sigmaSqConst'),
                                        which(names(UnobsPosInfo) == 'sigmaSqConstW'),
                                        which(names(UnobsPosInfo) == 'chiSq'),
                                        which(names(UnobsPosInfo) == 'chiSqW'),
                                        which(names(UnobsPosInfo) == 'xi'),
                                        which(names(UnobsPosInfo) == 'sigmaSqNu'),
                                        which(names(UnobsPosInfo) == 'sigmaSqOmega'),
                                        which(names(UnobsPosInfo) == 'sigmaSqOmegaW'),
                                        which(names(UnobsPosInfo) == 'gammma'))]

    bugsSimInit <- list(tempUnobsPosInfo)
    kk <- 1
    for (ii in (1:length(tempUnobsPosInfo))) {
        temp <- as.vector(bugsSim[[1]][nKeep,tempUnobsPosInfo[[ii]]])
        #temp <- t(matrix(temp,UnobsDim[[ii]][2],UnobsDim[[ii]][1]))
        bugsSimInit[[1]][[kk]] <- temp
        kk <- kk + 1
    }
    if (nChains > 1) {
        for (jj in 2:nChains) {
            kk <- 1
            bugsSimInit[[jj]] <- tempUnobsPosInfo
            for (ii in (1:length(tempUnobsPosInfo))) {
                temp <- as.vector(bugsSim[[jj]][nKeep,tempUnobsPosInfo[[ii]]])
                #temp <- t(matrix(temp,UnobsDim[[ii]][2],UnobsDim[[ii]][1]))
                bugsSimInit[[jj]][[kk]] <- temp
                kk <- kk + 1
            }
        }
    }

    filename <-  file.path(outDir, 'bugsSimInit.Rda')
    save(bugsSimInit, file = filename)
    save(bugsSimInit, file = 'bugsSimInit.Rda')

    return(bugsSimInit)
}

## Call SimDataSetFromEstimatedParameters from runModel.R
#####################################################################
## This is a wrapper function that calls SimDataSetFromEstimatedParameters
## from runModel.R. The reason for this function is that
## SimDataSetFromEstimatedParameters uses inputs from funcsAgg.R.
## It is useful to source funcsAgg.R within this function so as not
## to have all the functions therein defined in the root environment
## This function outputs a simulated dataset of the same size as
## the real data based on the estimated parameters for use
## in Monte Carlo estimation.

getSimDataSetFromEstimatedParameters <- function(prefixDir, outDir, 
                                            plotSimData = 1, printOLSgamma = 0)
{
    source('funcsAgg.R')
    controlAgg     <- getControlAgg()

    allData   <- readData(prefixDir)
    modelData <- getModelData(allData)

    NamesNPosInfo  <- getNamesNPosInfo(allData)
    UnobsPosInfo   <- NamesNPosInfo$UnobsPosInfo
    bigDataPosInfo <- getBigDataPosInfo(UnobsPosInfo)

    ParEst <- getParEstimates(bigDataPosInfo,controlAgg$usePooledChains,controlAgg$chainToUse)

    cDataEstParams  <- simDataSetFromEstimatedParameters(allData, modelData, controlAgg, ParEst, bigDataPosInfo, prefixDir, outDir)

    allData$cData   <- cDataEstParams$cDis
    filename <-  file.path(outDir, 'cDataEstParams.Rda')
    save(cDataEstParams, file = filename)

    return(allData)
}

## Simulate data from the model
#####################################################################
## Simulates a dataset of the same size as the real data set
## using the estimated parameters

simDataSetFromEstimatedParameters <- function(allData, modelData, controlAgg, 
                                                ParEst, bigDataPosInfo, prefixDir, 
                                                outDir, plotSimData = 1, 
                                                useEstInitials = 0)
{
    library(mvtnorm)

    cData          <- allData$cData
    posFirst       <- allData$posFirst
    posLast        <- allData$posLast
    posIIW         <- allData$posIIW
    startYears     <- allData$startYears
    endYears       <- allData$endYears
    nTotalLength   <- length(cData)
    nCountries     <- length(posFirst)
    nPeriods       <- max(posIIW)

    #####################
    ## Read Parameters ##
    #####################
    # Global Parameters
    rhoW           <- ParEst[bigDataPosInfo$rhoW]
    sigmaSqOmegaW  <- ParEst[bigDataPosInfo$sigmaSqOmegaW]
    sigmaSqConstW  <- ParEst[bigDataPosInfo$sigmaSqConstW]
    lambdaW        <- ParEst[bigDataPosInfo$lambdaW]
    chiSqW         <- ParEst[bigDataPosInfo$chiSqW]
    # Long-run risk parameters
    rho            <- ParEst[bigDataPosInfo$rho]
    gammma         <- ParEst[bigDataPosInfo$gammma]
    sigmaSqOmega   <- ParEst[bigDataPosInfo$sigmaSqOmega]
    lambda         <- ParEst[bigDataPosInfo$lambda]
    # Country specific parameters
    xi             <- ParEst[bigDataPosInfo$xi]
    mu             <- ParEst[bigDataPosInfo$mu]
    chiSq          <- ParEst[bigDataPosInfo$chiSq]
    sigmaSqNu      <- ParEst[bigDataPosInfo$sigmaSqNu]
    sigmaSqConst   <- ParEst[bigDataPosInfo$sigmaSqConst]

    sigmaConstW    <- sqrt(sigmaSqConstW)
    sigmaOmegaW    <- sqrt(sigmaSqOmegaW)
    sigmaConst     <- sqrt(sigmaSqConst)
    sigmaOmega     <- sqrt(sigmaSqOmega)
    sigmaNu        <- sqrt(sigmaSqNu)

    ############################
    ##  Initialize variables   #
    ############################
    XXW            <- numeric(nPeriods)
    EpsW           <- numeric(nPeriods)
    EtaW           <- numeric(nPeriods)
    OmegaW         <- numeric(nPeriods)
    SigmaSqW       <- numeric(nPeriods)

    cc             <- numeric(nTotalLength)
    XX             <- numeric(nTotalLength)
    YY             <- numeric(nTotalLength)
    SigmaSq        <- numeric(nTotalLength)
    Eps            <- numeric(nTotalLength)
    Eta            <- numeric(nTotalLength)
    Nu             <- numeric(nTotalLength)
    Omega          <- numeric(nTotalLength)

    #############################
    ## Global xxW and sigmaSqW ##
    #############################

    ## Set initial values
    if (useEstInitials == 0){
        varOmegaWEpsW <- matrix(c(sigmaOmegaW^2/(1-gammma^2),lambdaW*sqrt(sigmaOmegaW^2/(1-gammma^2))*sqrt(sigmaSqConstW/(1-rhoW^2)),lambdaW*sqrt(sigmaOmegaW^2/(1-gammma^2))*sqrt(sigmaSqConstW/(1-rhoW^2)),sigmaSqConstW/(1-rhoW^2)),2,2)
        omegaWEpsW    <- rmvnorm(1, mean = c(0,0), sigma = varOmegaWEpsW)
        OmegaW[1]     <- omegaWEpsW[1]
        EpsW[1]       <- omegaWEpsW[2]
        SigmaSqW[1]   <- max(sigmaSqConstW + OmegaW[1],modelData$cutOff)
        XXW[1]        <- EpsW[1]
        EtaW[1]       <- rnorm(1,0,sqrt(chiSqW*sigmaConstW^2/(1-gammma^2)))
    }
    if (useEstInitials == 1){
        initsEst      <- getInitsEstimates(allData,bigDataPosInfo,controlAgg$usePooledChains,controlAgg$chainToUse) ## this function extracts initial states from the estimation output
        SigmaSqW[1]   <- initsEst$SigmaSqW0
        XXW[1]        <- initsEst$XXW0
    }

    ## Simulate model
    for (tt in 2:(nPeriods)) {
        varOmegaWEpsW <- matrix(c(sigmaOmegaW^2,lambdaW*sigmaOmegaW*sqrt(SigmaSqW[tt-1]),lambdaW*sigmaOmegaW*sqrt(SigmaSqW[tt-1]),SigmaSqW[tt-1]),2,2)
        omegaWEpsW    <- rmvnorm(1, mean = c(0,0), sigma = varOmegaWEpsW)
        OmegaW[tt]    <- omegaWEpsW[1]
        EpsW[tt]      <- omegaWEpsW[2]
        SigmaSqW[tt]  <- max(sigmaSqConstW + gammma * (SigmaSqW[tt-1] - sigmaSqConstW) + OmegaW[tt],modelData$cutOff)
        XXW[tt]       <- rhoW * XXW[tt-1] + EpsW[tt]
        EtaW[tt]      <- rnorm(1,0,sqrt(chiSqW*SigmaSqW[tt-1]))
    }

    for (ii in 1:nCountries) {
        if (useEstInitials == 0){
            varOmegaEps             <- matrix(c(sigmaOmega^2/(1-gammma^2),lambda*sqrt(sigmaOmega^2/(1-gammma^2))*sqrt(sigmaSqConst[ii]/(1-rho^2) + sigmaSqConstW/(1-rhoW^2)),lambda*sqrt(sigmaOmega^2/(1-gammma^2))*sqrt(sigmaSqConst[ii]/(1-rho^2) + sigmaSqConstW/(1-rhoW^2)),(sigmaSqConst[ii]/(1-rho^2) + sigmaSqConstW/(1-rhoW^2))),2,2)
            omegaEps                <- rmvnorm(1, mean = c(0,0), sigma = varOmegaEps)
            Omega[1]                <- omegaEps[1]
            Eps[1]                  <- omegaEps[2]
            SigmaSq[posFirst[ii]]   <- max(sigmaSqConst + Omega[1],modelData$cutOff - SigmaSqW[posIIW[posFirst[ii]]])
            XX[posFirst[ii]]        <- Eps[1]
            YY[posFirst[ii]]        <- 0
        }
        if (useEstInitials == 1){
            SigmaSq[posFirst[ii]]   <- initsEst$SigmaSq0[ii]
            XX[posFirst[ii]]        <- initsEst$XX0[ii]
            YY[posFirst[ii]]        <- 0
        }
        for (tt in (posFirst[ii]+1):posLast[ii]) {
            varOmegaEps  <- matrix(c(sigmaOmega^2,lambda*sigmaOmega*sqrt(SigmaSq[tt-1] + SigmaSqW[posIIW[tt-1]]),lambda*sigmaOmega*sqrt(SigmaSq[tt-1] + SigmaSqW[posIIW[tt-1]]),(SigmaSq[tt-1] + SigmaSqW[posIIW[tt-1]])),2,2)
            omegaEps     <- rmvnorm(1, mean = c(0,0), sigma = varOmegaEps)
            Omega[tt]    <- omegaEps[1]
            Eps[tt]      <- omegaEps[2]
            SigmaSq[tt]  <- max(sigmaSqConst[ii]  + gammma * (SigmaSq[tt-1]  - sigmaSqConst[ii])  + Omega[tt],modelData$cutOff - SigmaSqW[posIIW[tt]])
            Eta[tt]      <- rnorm(1,0,sqrt(chiSq[ii]*(SigmaSq[tt-1] + SigmaSqW[posIIW[tt-1]])))

            XX[tt]       <- rho  * XX[tt-1]  + Eps[tt]
            YY[tt]       <- YY[tt-1] + mu[ii] + XX[tt-1] + xi[ii]*XXW[posIIW[tt-1]] + Eta[tt] + xi[ii]*EtaW[posIIW[tt]]
        }

        # Consumption process
        Nu[posFirst[ii]:posLast[ii]]     <- rnorm(posLast[ii]-posFirst[ii] + 1,0,sigmaNu[ii])
        cc[posFirst[ii]:posLast[ii]] <- YY[posFirst[ii]:posLast[ii]] + Nu[posFirst[ii]:posLast[ii]]
    }

    ## Create plots
    if (plotSimData == 1){
        filename <-  file.path(outDir,'simConsumption.pdf')
        pdf(filename, paper = 'special', width = 6, height = 7)
        par(mfrow = c(3, 2))

        for (ii in 1:nCountries)
        {
            ylimTemp    <- range(cc[posFirst[ii]:posLast[ii]])
            plot(startYears[ii]:endYears[ii], cc[posFirst[ii]:posLast[ii]],
                 main = allData$countryNames[ii],
                 xlab = 'time',
                 ylab = 'log(C)',
                 type = "l",
                 ylim = ylimTemp)

            ylimTemp    <- range(c(XX[posFirst[ii]:posLast[ii]]))
            plot(startYears[ii]:endYears[ii], XX[posFirst[ii]:posLast[ii]],
                 main = allData$countryNames[ii],
                 xlab = 'time',
                 ylab = 'XX',
                 type = "l",
                 ylim = ylimTemp)

             ylimTemp    <- range(c(XXW[posIIW[posFirst[ii]]:posIIW[posLast[ii]]]))
             plot(startYears[ii]:endYears[ii], XXW[posIIW[posFirst[ii]]:posIIW[posLast[ii]]],
                  main = allData$countryNames[ii],
                  xlab = 'time',
                  ylab = 'XXW',
                  type = "l",
                  ylim = ylimTemp)

            ylimTemp    <- range(SigmaSq)
            plot(startYears[ii]:endYears[ii], SigmaSq[posFirst[ii]:posLast[ii]],
                 main = allData$countryNames[ii],
                 xlab = 'time',
                 ylab = 'SigmaSq',
                 type = "l",
                 ylim = ylimTemp)

             ylimTemp    <- range(c(sqrt(SigmaSqW[posIIW[posFirst[ii]]:posIIW[posLast[ii]]])))
             plot(startYears[ii]:endYears[ii], sqrt(SigmaSqW[posIIW[posFirst[ii]]:posIIW[posLast[ii]]]),
                  main = allData$countryNames[ii],
                  xlab = 'time',
                  ylab = 'SigmaW',
                  type = "l",
                  ylim = ylimTemp)
        }
        dev.off()
    }

    return(list(cc        = cc,
                YY        = YY,
                Nu        = Nu,
                XX        = XX,
                XXW       = XXW,
                SigmaSq   = SigmaSq,
                SigmaSqW  = SigmaSqW,
                Eta       = Eta,
                EtaW      = EtaW))
}
# Simulate data using parameters provided in params of arbitrary length simLength
#################################################################################
simData <- function(params, simLength, cutOff)
{
    # Parameters
    rho        <- params$rho
    rhoW       <- params$rhoW
    chi        <- params$chi
    chiW       <- params$chiW
    xi         <- params$xi
    sigmaConst <- params$sigmaConst
    sigmaConstW<- params$sigmaConstW
    sigmaOmega <- params$sigmaOmega
    sigmaOmegaW<- params$sigmaOmegaW
    sigmaNu    <- params$sigmaNu
    gammma     <- params$gammma
    mu         <- params$mu
    lambda     <- params$lambda
    lambdaW    <- params$lambdaW

    ############################
    ##  Initialize variables   #
    ############################
    XXW        <- numeric(simLength)
    EpsW       <- numeric(simLength)
    EtaW       <- numeric(simLength)
    OmegaW     <- numeric(simLength)
    SigmaSqW   <- numeric(simLength)

    cc         <- numeric(simLength)
    ccNoXX     <- numeric(simLength)
    XX         <- numeric(simLength)
    YY         <- numeric(simLength)
    YYnoXX     <- numeric(simLength)
    SigmaSq    <- numeric(simLength)
    Eps        <- numeric(simLength)
    Eta        <- numeric(simLength)
    Nu         <- numeric(simLength)
    Omega      <- numeric(simLength)

    #############################
    ## Global xxW and sigmaSqW ##
    #############################
    ## Set initial values
    varOmegaWEpsW <- matrix(c(sigmaOmegaW^2/(1-gammma^2),lambdaW*sqrt(sigmaOmegaW^2/(1-gammma^2))*sqrt(sigmaConstW^2/(1-rhoW^2)),lambdaW*sqrt(sigmaOmegaW^2/(1-gammma^2))*sqrt(sigmaConstW^2/(1-rhoW^2)),sigmaConstW^2/(1-rhoW^2)),2,2)
    omegaWEpsW   <- rmvnorm(1, mean = c(0,0), sigma = varOmegaWEpsW)
    OmegaW[1]    <- omegaWEpsW[1]
    EpsW[1]      <- omegaWEpsW[2]
    SigmaSqW[1]  <- max(sigmaConstW^2 + OmegaW[1],cutOff)
    XXW[1]       <- EpsW[1]
    EtaW[1]      <- rnorm(1,0,sqrt(chi^2*SigmaSqW[1]))
    ## Simulate model
    for (tt in 2:simLength) {
        omegaWEpsW   <- rmvnorm(1, mean = c(0,0), sigma = matrix(c(sigmaOmegaW^2,lambdaW*sigmaOmegaW*sqrt(SigmaSqW[tt-1]),lambdaW*sigmaOmegaW*sqrt(SigmaSqW[tt-1]),SigmaSqW[tt-1]),2,2))
        OmegaW[tt]   <- omegaWEpsW[1]
        EpsW[tt]     <- omegaWEpsW[2]
        SigmaSqW[tt] <- max(sigmaConstW^2 + gammma * (SigmaSqW[tt-1] - sigmaConstW^2) + OmegaW[tt],cutOff)
        XXW[tt]      <- rhoW * XXW[tt-1] + EpsW[tt]
        EtaW[tt]     <- rnorm(1,0,sqrt(chiW^2*SigmaSqW[tt-1]))
    }
    varOmegaEps             <- matrix(c(sigmaOmega^2/(1-gammma^2),lambda*sqrt(sigmaOmega^2/(1-gammma^2))*sqrt(sigmaConst^2/(1-rho^2) + sigmaConstW^2/(1-rhoW^2)),lambda*sqrt(sigmaOmega^2/(1-gammma^2))*sqrt(sigmaConst^2/(1-rho^2) + sigmaConstW^2/(1-rhoW^2)),(sigmaConst^2/(1-rho^2) + sigmaConstW^2/(1-rhoW^2))),2,2)
    omegaEps                <- rmvnorm(1, mean = c(0,0), sigma = varOmegaEps)
    Omega[1]                <- omegaEps[1]
    Eps[1]                  <- omegaEps[2]
    SigmaSq[1]              <- max(sigmaConst^2 + Omega[1],cutOff - SigmaSqW[1])
    XX[1]                   <- Eps[1]
    for (tt in 2:simLength) {
        omegaEps     <- rmvnorm(1, mean = c(0,0), sigma = matrix(c(sigmaOmega^2,lambda*sigmaOmega*sqrt(SigmaSq[tt-1] + SigmaSqW[tt-1]),lambda*sigmaOmega*sqrt(SigmaSq[tt-1] + SigmaSqW[tt-1]),(SigmaSq[tt-1] + SigmaSqW[tt-1])),2,2))
        Omega[tt]    <- omegaEps[1]
        Eps[tt]      <- omegaEps[2]
        SigmaSq[tt]  <- max(sigmaConst^2  + gammma * (SigmaSq[tt-1]  - sigmaConst^2)  + Omega[tt],cutOff - SigmaSqW[tt])
        Eta[tt]      <- rnorm(1,0,sqrt(chi^2*(SigmaSq[tt-1] + SigmaSqW[tt-1])))

        XX[tt]       <- rho  * XX[tt-1]  + Eps[tt]
        YY[tt]       <- YY[tt-1]     + mu + XX[tt-1] + xi*XXW[tt-1] + Eta[tt]     + xi*EtaW[tt]
    }

    #EtaWnoSV     <- rnorm(simLength,0,sqrt(chiW^2*sigmaConstW^2))
    #EtaNoSV      <- rnorm(simLength,0,sqrt(chi^2*(sigmaConst^2 + sigmaConstW^2)))
    EtaWnoSV     <- rnorm(simLength,0,sqrt(chiW^2*quantile(SigmaSqW,          probs = 0.5)))
    EtaNoSV      <- rnorm(simLength,0,sqrt(chi^2*quantile(SigmaSqW + SigmaSq, probs = 0.5)))
    for (tt in 2:simLength) {
        YYnoXX[tt]   <- YYnoXX[tt-1] + mu + EtaNoSV[tt] + xi*EtaWnoSV[tt]
    }
    Nu     <- rnorm(simLength,0,sigmaNu)
    cc     <- YY     + Nu
    ccNoXX <- YYnoXX + Nu

    return(list(cc       = cc,
                ccNoXX   = ccNoXX,
                XX       = XX,
                XXW      = XXW,
                Eps      = Eps,
                EpsW     = EpsW,
                Eta      = Eta,
                EtaW     = EtaW,
                Nu       = Nu,
                SigmaSqW = SigmaSqW,
                SigmaSq  = SigmaSq))
}


simDataFixedSV <- function(params, simLength, cutOff)
{
    # Parameters
    rho        <- params$rho
    rhoW       <- params$rhoW
    chi        <- params$chi
    chiW       <- params$chiW
    xi         <- params$xi
    sigmaConst <- params$sigmaConst
    sigmaConstW<- params$sigmaConstW
    sigmaOmega <- params$sigmaOmega
    sigmaOmegaW<- params$sigmaOmegaW
    sigmaNu    <- params$sigmaNu
    gammma     <- params$gammma
    mu         <- params$mu
    lambda     <- params$lambda
    lambdaW    <- params$lambdaW

    ############################
    ##  Initialize variables   #
    ############################
    XXW        <- numeric(simLength)
    XX         <- numeric(simLength)
    YY         <- numeric(simLength)
    SigmaSq    <- numeric(simLength)
    SigmaSqW   <- numeric(simLength)
    #############################
    ##      Simulate SV        ##
    #############################
    OmegaW      <- rnorm(simLength, mean = 0, sd = sigmaOmegaW)
    Omega       <- rnorm(simLength, mean = 0, sd = sigmaOmega)
    SigmaSqW[1] <- max(sigmaConstW^2 + OmegaW[1],cutOff)
    SigmaSq[1]  <- max(sigmaConst^2  + Omega[1], cutOff)
    for (tt in 2:simLength) SigmaSqW[tt] <- max(sigmaConstW^2 + gammma * (SigmaSqW[tt-1] - sigmaConstW^2) + OmegaW[tt],cutOff)
    for (tt in 2:simLength) SigmaSq[tt]  <- max(sigmaConst^2  + gammma * (SigmaSq[tt-1]  - sigmaConst^2)  + Omega[tt], cutOff - SigmaSqW[tt])
    SigmaSqT   <- SigmaSqW + SigmaSq
    SigmaSqW05 <- quantile(SigmaSqW, probs = 0.05)
    SigmaSqW50 <- quantile(SigmaSqW, probs = 0.5)
    SigmaSqW95 <- quantile(SigmaSqW, probs = 0.95)
    SigmaSqT05 <- quantile(SigmaSqT, probs = 0.05)
    SigmaSqT50 <- quantile(SigmaSqT, probs = 0.5)
    SigmaSqT95 <- quantile(SigmaSqT, probs = 0.95)
    ############################################
    ## Simulate for SigmaSqW05 and SigmaSqT05 ##
    ############################################
    EpsW         <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSqW05))
    EtaW         <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSqW05))
    Eps          <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSqT05))
    Eta          <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSqT05))
    Nu           <- rnorm(simLength, mean = 0, sd = sigmaNu)
    XXW[1]       <- EpsW[1]
    XX[1]        <- Eps[1]
    YY[1]        <- 0
    for (tt in 2:simLength) {
        XXW[tt]  <- rhoW * XXW[tt-1] + EpsW[tt]
        XX[tt]   <- rho  * XX[tt-1]  + Eps[tt]
        YY[tt]   <- YY[tt-1] + mu + XX[tt-1] + xi*XXW[tt-1] + Eta[tt] + xi*EtaW[tt]
    }
    cc05         <- YY + Nu
    ############################################
    ## Simulate for SigmaSqW50 and SigmaSqT50 ##
    ############################################
    EpsW         <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSqW50))
    EtaW         <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSqW50))
    Eps          <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSqT50))
    Eta          <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSqT50))
    Nu           <- rnorm(simLength, mean = 0, sd = sigmaNu)
    XXW[1]       <- EpsW[1]
    XX[1]        <- Eps[1]
    YY[1]        <- 0
    for (tt in 2:simLength) {
        XXW[tt]  <- rhoW * XXW[tt-1] + EpsW[tt]
        XX[tt]   <- rho  * XX[tt-1]  + Eps[tt]
        YY[tt]   <- YY[tt-1]     + mu + XX[tt-1] + xi*XXW[tt-1] + Eta[tt] + xi*EtaW[tt]
    }
    cc50         <- YY     + Nu
    ############################################
    ## Simulate for SigmaSqW95 and SigmaSqT95 ##
    ############################################
    EpsW         <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSqW95))
    EtaW         <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSqW95))
    Eps          <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSqT95))
    Eta          <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSqT95))
    Nu           <- rnorm(simLength, mean = 0, sd = sigmaNu)
    XXW[1]       <- EpsW[1]
    XX[1]        <- Eps[1]
    YY[1]        <- 0
    for (tt in 2:simLength) {
        XXW[tt]  <- rhoW * XXW[tt-1] + EpsW[tt]
        XX[tt]   <- rho  * XX[tt-1]  + Eps[tt]
        YY[tt]   <- YY[tt-1]     + mu + XX[tt-1] + xi*XXW[tt-1] + Eta[tt] + xi*EtaW[tt]
    }
    cc95         <- YY     + Nu
    return(list(cc05 = cc05,
                cc50 = cc50,
                cc95 = cc95))
}

simDataBY <- function(params, simLength, cutOff)
{
    # Parameters
    rho        <- params$rho
    chi        <- params$chi
    sigmaConst <- params$sigmaConst
    sigmaOmega <- params$sigmaOmega
    gammma     <- params$gammma
    mu         <- params$mu

    ############################
    ##  Initialize variables   #
    ############################
    cc         <- numeric(simLength)
    ccNoXX     <- numeric(simLength)
    XX         <- numeric(simLength)
    SigmaSq    <- numeric(simLength)
    Eps        <- numeric(simLength)
    Eta        <- numeric(simLength)
    Omega      <- numeric(simLength)

    ############################
    ##          Simulate      ##
    ############################
    Omega[1]                <- rnorm(1, mean = 0, sd = sqrt(sigmaOmega^2/(1-gammma^2)))
    Eps[1]                  <- rnorm(1, mean = 0, sd = sqrt(sigmaConst^2/(1-rho^2)))
    SigmaSq[1]              <- max(sigmaConst^2 + Omega[1],cutOff)
    XX[1]                   <- Eps[1]
    for (tt in 2:simLength) {
        Omega[tt]    <- rnorm(1, mean = 0, sd = sigmaOmega)
        Eps[tt]      <- rnorm(1, mean = 0, sd = sqrt(SigmaSq[tt-1]))
        SigmaSq[tt]  <- max(sigmaConst^2  + gammma * (SigmaSq[tt-1]  - sigmaConst^2)  + Omega[tt],cutOff)
        Eta[tt]      <- rnorm(1,0,sqrt(chi^2*SigmaSq[tt-1]))

        XX[tt]       <- rho  * XX[tt-1]  + Eps[tt]
        cc[tt]       <- cc[tt-1]     + mu + XX[tt-1] + Eta[tt]

    }
    #EtaNoSV          <- rnorm(simLength,0,sqrt(chi^2*sigmaConst^2))
    EtaNoSV          <- rnorm(simLength,0,sqrt(chi^2*quantile(SigmaSq,probs = 0.5)))
    for (tt in 2:simLength) {
        ccNoXX[tt]   <- ccNoXX[tt-1] + mu + EtaNoSV[tt]
    }
    return(list(cc      = cc,
                ccNoXX  = ccNoXX,
                XX      = XX,
                SigmaSq = SigmaSq))
}

simDataBYFixedSV <- function(params, simLength, cutOff)
{
    # Parameters
    rho        <- params$rho
    chi        <- params$chi
    sigmaConst <- params$sigmaConst
    sigmaOmega <- params$sigmaOmega
    gammma     <- params$gammma
    mu         <- params$mu
    ############################
    ##  Initialize variables   #
    ############################
    cc         <- numeric(simLength)
    XX         <- numeric(simLength)
    SigmaSq    <- numeric(simLength)
    ############################
    ##   Simulate SV          ##
    ############################
    Omega                   <- rnorm(simLength,mean=0,sd=sigmaOmega)
    SigmaSq[1]              <- max(sigmaConst^2 + Omega[1],cutOff)
    for (tt in 2:simLength) {
        SigmaSq[tt]  <- max(sigmaConst^2  + gammma * (SigmaSq[tt-1]  - sigmaConst^2)  + Omega[tt],cutOff)
    }
    SigmaSq05 <- quantile(SigmaSq, probs = 0.05)
    SigmaSq50 <- quantile(SigmaSq, probs = 0.5)
    SigmaSq95 <- quantile(SigmaSq, probs = 0.95)
    ############################
    ## Simulate for SigmaSq05 ##
    ############################
    Eps        <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq05))
    Eta        <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq05))
    XX[1]      <- Eps[1]
    for (tt in 2:simLength) {
        XX[tt] <- rho  * XX[tt-1]  + Eps[tt]
        cc[tt] <- cc[tt-1] + mu + XX[tt-1] + Eta[tt]
    }
    cc05 <- cc
    ############################
    ## Simulate for SigmaSq50 ##
    ############################
    Eps        <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq50))
    Eta        <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq50))
    XX[1]      <- Eps[1]
    for (tt in 2:simLength) {
        XX[tt] <- rho  * XX[tt-1]  + Eps[tt]
        cc[tt] <- cc[tt-1] + mu + XX[tt-1] + Eta[tt]
    }
    cc50 <- cc
    ############################
    ## Simulate for SigmaSq95 ##
    ############################
    Eps        <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq95))
    Eta        <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq95))
    XX[1]      <- Eps[1]
    for (tt in 2:simLength) {
        XX[tt] <- rho  * XX[tt-1]  + Eps[tt]
        cc[tt] <- cc[tt-1] + mu + XX[tt-1] + Eta[tt]
    }
    cc95 <- cc
    return(list(cc05 = cc05,
                cc50 = cc50,
                cc95 = cc95))
}