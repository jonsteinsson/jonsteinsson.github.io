## Support functions for runAgg.R
##
## Emi Nakamura, Dmitriy Sergeyev, Jon Steinsson, July 2016            
###############################################################################

getControlAgg <- function()
{
    fullPlot                  <- 1 # Used in simPlotMany
    plotPooledChains          <- 0 # Used in simPlotMany and several other function
    chainToUse                <- 1 
    combineRuns               <- 1 
    combineChains             <- 1 
    compareLRR                <- 0      # if 1 produces output that compares the amount of LRR across BY, BKY and our model          
    simLengthCompareLRR       <- 100#20000  # number of years to simulate to produce LRR comparison
    simLengthLong             <- 100#100000  # number of years to simulate: a constant that will be used for various purposes in the code
    nSubsampleDraws           <- 200    # number of draws to pick from bigDataFile's
    outputFileNamePostfix     <- paste(c("Chain",chainToUse),collapse = '.')
    usePooledChains           <- 1 
    if (usePooledChains){
        outputFileNamePostfix <- "PooledChains"    
        usePooledChains       <- 1
    }
    TableFormat               <- list(TeX = 0, MicrosoftExcel = 1)
    return(list(combineRuns           = combineRuns, 
                plotPooledChains      = plotPooledChains,
                combineChains         = combineChains,
                fullPlot              = fullPlot,
                chainToUse            = chainToUse,
                outputFileNamePostfix = outputFileNamePostfix,
                TableFormat           = TableFormat,
                usePooledChains       = usePooledChains,
                compareLRR            = compareLRR,
                simLengthCompareLRR   = simLengthCompareLRR,
                simLengthLong         = simLengthLong,
                nSubsampleDraws       = nSubsampleDraws))
}

## Get runs to use in the aggregation
################################################################################
getRunsToUse <- function()
{
    YY1ToUse <- 1:2#21:100
    YY1Dir   <- file.path(prefixDir, 'data/v11/v11.33d3')

    runsToUse <- NULL
    for (ii in YY1ToUse) {
        runsToUse <- c(runsToUse, 
            file.path(YY1Dir,paste(c('bugsSimSave.YY1',ii,'Rda'), collapse = '.')))
    }
    return(runsToUse)
}

## Get Parameter Estimates                                            
################################################################################
getParEstimates <- function(UnobsPosInfo,usePooledChains,chainToUse)
{
    if (usePooledChains == 0){
        load(file.path(outDir, paste(c('bigDataParams','Rda'),collapse = '.')))
           
        ParEst <- numeric(dim(bigDataParams[[chainToUse]])[2])   
    
        for (ii in UnobsPosInfo$deviance)      ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$sigmaSqConst)  ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$sigmaSqConstW) ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$mu)            ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$sigmaSqOmega)  ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$sigmaSqOmegaW) ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$sigmaSqNu)     ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$chiSq)         ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii]) 
        for (ii in UnobsPosInfo$chiSqW)        ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii]) 
        for (ii in UnobsPosInfo$xi)            ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])        
        for (ii in UnobsPosInfo$gammma)        ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$lambda)        ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])
        for (ii in UnobsPosInfo$lambdaW)       ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])                
        for (ii in UnobsPosInfo$rho)           ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])     
        for (ii in UnobsPosInfo$rhoW)          ParEst[ii]    <- mean(bigDataParams[[chainToUse]][,ii])          
    }
    if (usePooledChains == 1){
        load(file.path(outDir, 'bigDataParams_pooled.Rda'))
           
        ParEst <- numeric(dim(bigDataParams_pooled)[2])   
    
        for (ii in UnobsPosInfo$deviance)      ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$sigmaSqConst)  ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$sigmaSqConstW) ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$mu)            ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$sigmaSqOmega)  ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$sigmaSqOmegaW) ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$sigmaSqNu)     ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$chiSq)         ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$chiSqW)        ParEst[ii]    <- mean(bigDataParams_pooled[,ii]) 
        for (ii in UnobsPosInfo$xi)            ParEst[ii]    <- mean(bigDataParams_pooled[,ii])                
        for (ii in UnobsPosInfo$gammma)        ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$lambda)        ParEst[ii]    <- mean(bigDataParams_pooled[,ii])
        for (ii in UnobsPosInfo$lambdaW)       ParEst[ii]    <- mean(bigDataParams_pooled[,ii])        
        for (ii in UnobsPosInfo$rho)           ParEst[ii]    <- mean(bigDataParams_pooled[,ii])     
        for (ii in UnobsPosInfo$rhoW)          ParEst[ii]    <- mean(bigDataParams_pooled[,ii])            
    }
    return(ParEst)
}

## Get a draw of parameters
################################################################################
getPars <- function(UnobsPosInfo,usePooledChains,chainToUse,iiMCarlo)
{
    if (usePooledChains == 0){
        filename <-  file.path(outDir, paste(c('bigDataParams','Rda'),collapse = '.'))  
        load(filename)
           
        ParEst <- numeric(dim(bigDataParams[[chainToUse]])[2])   
    
        for (ii in UnobsPosInfo$deviance)      ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqConst)  ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqConstW) ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$mu)            ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqOmega)  ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqOmegaW) ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqNu)     ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$chiSq)         ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii] 
        for (ii in UnobsPosInfo$chiSqW)        ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii] 
        for (ii in UnobsPosInfo$xi)            ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]        
        for (ii in UnobsPosInfo$gammma)        ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$lambda)        ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]
        for (ii in UnobsPosInfo$lambdaW)       ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]                
        for (ii in UnobsPosInfo$rho)           ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]     
        for (ii in UnobsPosInfo$rhoW)          ParEst[ii] <- bigDataParams[[chainToUse]][iiMCarlo,ii]          
    }
    if (usePooledChains == 1){
        filename <-  file.path(outDir, 'bigDataParams_pooled.Rda')  
        load(filename)
           
        ParEst <- numeric(dim(bigDataParams_pooled)[2])   
    
        for (ii in UnobsPosInfo$deviance)      ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqConst)  ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqConstW) ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$mu)            ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqOmega)  ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqOmegaW) ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$sigmaSqNu)     ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$chiSq)         ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$chiSqW)        ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii] 
        for (ii in UnobsPosInfo$xi)            ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]                
        for (ii in UnobsPosInfo$gammma)        ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$lambda)        ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]
        for (ii in UnobsPosInfo$lambdaW)       ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]        
        for (ii in UnobsPosInfo$rho)           ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]     
        for (ii in UnobsPosInfo$rhoW)          ParEst[ii]    <- bigDataParams_pooled[iiMCarlo,ii]            
    }
    return(ParEst)
}
  
## Get average of the estimates of all the states                                        
################################################################################
getStatesEstimates <- function(allData,UnobsPosInfo,usePooledChains,chainToUse)
{
    posFirst   <- allData$posFirst
    posLast    <- allData$posLast
    posIIW     <- allData$posIIW
    nCountries <- length(allData$countryNames)
    nPeriods   <- max(posIIW)
    dataLength <- length(allData$cData)    

    if (usePooledChains == 0){

        ## Read initial YY's
        load(file.path(outDir, paste(c('bigDataYY','Rda'),collapse = '.')))           
        YYest  <- numeric(dataLength)       
        for (ii in c(1:nCountries)) YYest[posFirst[ii]:posLast[ii]] <- apply(bigDataYY[[chainToUse]][,UnobsPosInfo$yy[posFirst[ii]:posLast[ii]]],2,mean)
        rm(bigDataYY)

        ## Read initial XX's
        load(file.path(outDir, paste(c('bigDataXX','Rda'),collapse = '.')))           
        XXest  <- numeric(dataLength)       
        for (ii in c(1:nCountries)) XXest[posFirst[ii]:posLast[ii]] <- apply(bigDataXX[[chainToUse]][,UnobsPosInfo$xx[posFirst[ii]:posLast[ii]]],2,mean)
        rm(bigDataXX)

        ## Read initial XXW's
        load(file.path(outDir, paste(c('bigDataXXW','Rda'),collapse = '.')))     
        XXWest <- apply(bigDataXXW[[chainToUse]][,UnobsPosInfo$xxW],2,mean)
        rm(bigDataXXW)

        ## Read initial SigmaSq's
        load(file.path(outDir, paste(c('bigDataSigmaSq','Rda'),collapse = '.')))           
        SigmaSqest <- numeric(dataLength)       
        for (ii in c(1:nCountries)) SigmaSqest[posFirst[ii]:posLast[ii]] <- apply(bigDataSigmaSq[[chainToUse]][,UnobsPosInfo$sigmaSq[posFirst[ii]:posLast[ii]]],2,mean)
        rm(bigDataSigmaSq)

        ## Read initial SigmaSqW's
        load(file.path(outDir, paste(c('bigDataSigmaSqW','Rda'),collapse = '.')))               
        SigmaSqWest <- apply(bigDataSigmaSqW[[chainToUse]][,UnobsPosInfo$sigmaSqW],2,mean)        
        rm(bigDataSigmaSqW)      

    }
    if (usePooledChains == 1){
        ## Read initial YY's
        load(file.path(outDir, paste(c('bigDataYY_pooled','Rda'),collapse = '.')))           
        YYest  <- numeric(dataLength)       
        for (ii in c(1:nCountries)) YYest[posFirst[ii]:posLast[ii]] <- apply(bigDataYY_pooled[,UnobsPosInfo$yy[posFirst[ii]:posLast[ii]]],2,mean)
        rm(bigDataYY_pooled)

        ## Read initial XX's
        load(file.path(outDir, paste(c('bigDataXX_pooled','Rda'),collapse = '.')))           
        XXest  <- numeric(dataLength)       
        for (ii in c(1:nCountries)) XXest[posFirst[ii]:posLast[ii]] <- apply(bigDataXX_pooled[,UnobsPosInfo$xx[posFirst[ii]:posLast[ii]]],2,mean)
        rm(bigDataXX_pooled)

        ## Read initial XXW's
        load(file.path(outDir, paste(c('bigDataXXW_pooled','Rda'),collapse = '.')))             
        XXWest <- apply(bigDataXXW_pooled[,UnobsPosInfo$xxW],2,mean)       
        rm(bigDataXXW_pooled)

        ## Read initial SigmaSq's
        load(file.path(outDir, paste(c('bigDataSigmaSq_pooled','Rda'),collapse = '.')))           
        SigmaSqest <- numeric(dataLength)       
        for (ii in c(1:nCountries)) SigmaSqest[posFirst[ii]:posLast[ii]] <- apply(bigDataSigmaSq_pooled[,UnobsPosInfo$sigmaSq[posFirst[ii]:posLast[ii]]],2,mean)
        rm(bigDataSigmaSq_pooled)

        ## Read initial SigmaSqW's
        load(file.path(outDir, paste(c('bigDataSigmaSqW_pooled','Rda'),collapse = '.')))           
        SigmaSqWest <- apply(bigDataSigmaSqW_pooled[,UnobsPosInfo$sigmaSqW],2,mean)     
        rm(bigDataSigmaSqW_pooled)      
    }
    
    return(list(XXest       = XXest,
                XXWest      = XXWest,
                YYest       = YYest,
                SigmaSqest  = SigmaSqest,
                SigmaSqWest = SigmaSqWest))
}

## Get draws of the states
################################################################################
getStates <- function(allData,UnobsPosInfo,usePooledChains,chainToUse,nDraws)
{

    posFirst   <- allData$posFirst
    posLast    <- allData$posLast
    posIIW     <- allData$posIIW
    nCountries <- length(allData$countryNames)
    nPeriods   <- max(posIIW)
    dataLength <- length(allData$cData)    

    if (usePooledChains == 0){
        ## Read YY's
        load(file.path(outDir, paste(c('bigDataYY','Rda'),collapse = '.')))           
        Draws <- sample(1:dim(bigDataYY[[chainToUse]])[1], nDraws) ## Set draws to use
        YY <- bigDataYY[[chainToUse]][Draws,]
        rm(bigDataYY)

        ## Read XX's
        load(file.path(outDir, paste(c('bigDataXX','Rda'),collapse = '.')))           
        XX <- bigDataXX[[chainToUse]][Draws,]
        rm(bigDataXX)

        ## Read XXW's
        load(file.path(outDir, paste(c('bigDataXXW','Rda'),collapse = '.')))     
        XXW <- bigDataXXW[[chainToUse]][Draws,]
        rm(bigDataXXW)

        ## Read SigmaSq's
        load(file.path(outDir, paste(c('bigDataSigmaSq','Rda'),collapse = '.')))           
        SigmaSq <- bigDataSigmaSq[[chainToUse]][Draws,]
        rm(bigDataSigmaSq)

        ## Read SigmaSqW's
        load(file.path(outDir, paste(c('bigDataSigmaSqW','Rda'),collapse = '.')))               
        SigmaSqW <- bigDataSigmaSqW[[chainToUse]][Draws,]        
        rm(bigDataSigmaSqW)      

    }
    if (usePooledChains == 1){
        ## Read initial YY's
        load(file.path(outDir, paste(c('bigDataYY_pooled','Rda'),collapse = '.')))           
        Draws <- sample(1:dim(bigDataYY_pooled[[chainToUse]])[1], nDraws) ## Set draws to use
        YY <- bigDataYY_pooled[Draws,]
        rm(bigDataYY_pooled)

        ## Read initial XX's
        load(file.path(outDir, paste(c('bigDataXX_pooled','Rda'),collapse = '.')))           
        XX <- bigDataXX_pooled[Draws,]
        rm(bigDataXX_pooled)

        ## Read initial XXW's
        load(file.path(outDir, paste(c('bigDataXXW_pooled','Rda'),collapse = '.')))             
        XXW <- bigDataXXW_pooled[Draws,]       
        rm(bigDataXXW_pooled)

        ## Read initial SigmaSq's
        load(file.path(outDir, paste(c('bigDataSigmaSq_pooled','Rda'),collapse = '.')))                
        SigmaSq <- bigDataSigmaSq_pooled[Draws,]
        rm(bigDataSigmaSq_pooled)

        ## Read initial SigmaSqW's
        load(file.path(outDir, paste(c('bigDataSigmaSqW_pooled','Rda'),collapse = '.')))           
        SigmaSqW <- bigDataSigmaSqW_pooled[Draws,]     
        rm(bigDataSigmaSqW_pooled)      
    }
    return(list(XX       = XX,
                XXW      = XXW,
                YY       = YY,
                SigmaSq  = SigmaSq,
                SigmaSqW = SigmaSqW))
}

## Get Estimates of Initial States
################################################################################
getInitsEstimates <- function(allData,UnobsPosInfo,usePooledChains,chainToUse)
{

    nCountries <- length(allData$countryNames)
    posFirst   <- allData$posFirst
    posLast    <- allData$posLast
    posIIW     <- allData$posIIW

    if (usePooledChains == 0){
        ## Read XX's
        load(file.path(outDir, paste(c('bigDataXX','Rda'),collapse = '.')))           
        XX0 <- numeric(nCountries)       
        for (ii in c(1:nCountries)) XX0[ii] <- median(bigDataXX[[chainToUse]][,UnobsPosInfo$xx[posFirst[ii]]])
        rm(bigDataXX)
        ## Read XXW's
        load(file.path(outDir, paste(c('bigDataXXW','Rda'),collapse = '.')))           
        XXW0 <- median(bigDataXXW[[chainToUse]][,UnobsPosInfo$xxW[posIIW[posFirst[ii]]]])        
        rm(bigDataXXW)
        ## Read SigmaSq's
        load(file.path(outDir, paste(c('bigDataSigmaSq','Rda'),collapse = '.')))           
        SigmaSq0 <- numeric(nCountries)       
        for (ii in c(1:nCountries)) SigmaSq0[ii] <- median(bigDataSigmaSq[[chainToUse]][,UnobsPosInfo$sigmaSq[posFirst[ii]]])
        rm(bigDataSigmaSq)
        ## Read SigmaSqW's
        load(file.path(outDir, paste(c('bigDataSigmaSqW','Rda'),collapse = '.')))           
        SigmaSqW0 <- median(bigDataSigmaSqW[[chainToUse]][,UnobsPosInfo$sigmaSqW[posIIW[posFirst[ii]]]])        
        rm(bigDataSigmaSqW)      
    }
    if (usePooledChains == 1){
        ## Read XX's
        load(file.path(outDir, paste(c('bigDataXX_pooled','Rda'),collapse = '.')))           
        XX0 <- numeric(nCountries)              
        for (ii in c(1:nCountries)) XX0[ii] <- median(bigDataXX_pooled[,UnobsPosInfo$xx[posFirst[ii]]])
        rm(bigDataXX_pooled)

        ## Read XXW's
        load(file.path(outDir, paste(c('bigDataXXW_pooled','Rda'),collapse = '.')))           
        XXW0 <- median(bigDataXXW_pooled[,UnobsPosInfo$xxW[posIIW[posFirst[ii]]]])        
        rm(bigDataXXW_pooled)

        ## Read SigmaSq's
        load(file.path(outDir, paste(c('bigDataSigmaSq_pooled','Rda'),collapse = '.')))           
        SigmaSq0 <- numeric(nCountries)       
        for (ii in c(1:nCountries)) SigmaSq0[ii] <- median(bigDataSigmaSq_pooled[,UnobsPosInfo$sigmaSq[posFirst[ii]]])
        rm(bigDataSigmaSq_pooled)

        ## Read SigmaSqW's
        load(file.path(outDir, paste(c('bigDataSigmaSqW_pooled','Rda'),collapse = '.')))           
        SigmaSqW0 <- median(bigDataSigmaSqW_pooled[,UnobsPosInfo$sigmaSqW[posIIW[posFirst[ii]]]])        
        rm(bigDataSigmaSqW_pooled)      
    }
    
    return(list(XX0       = XX0,
                XXW0      = XXW0,
                SigmaSq0  = SigmaSq0,
                SigmaSqW0 = SigmaSqW0))
}

## Get BigData position information
################################################################################
getBigDataPosInfo <- function(UnobsPosInfo)
{
    nCountries <- length(UnobsPosInfo$mu)
    bigDataPosInfo<- list(xx      = 1:length(UnobsPosInfo$xx), 
                          xxW     = 1:length(UnobsPosInfo$xxW), 
                          yy      = 1:length(UnobsPosInfo$yy), 
                          sigmaSq = 1:length(UnobsPosInfo$sigmaSq),
                          sigmaSqW= 1:length(UnobsPosInfo$sigmaSqW),
                          etaW    = 1:length(UnobsPosInfo$etaW),
                          
                          deviance     = NULL, 
                          sigmaSqConst = NULL,
                          sigmaSqConstW= NULL,
                          rho          = NULL,
                          rhoW         = NULL,                              
                          gammma       = NULL,                              
                          lambda       = NULL,  
                          lambdaW      = NULL,                                                              
                          mu           = NULL,
                          chiSq        = NULL,
                          chiSqW       = NULL,
                          xi           = NULL,                              
                          sigmaSqOmega = NULL,
                          sigmaSqOmegaW= NULL,
                          sigmaSqNu    = NULL)
    
    dimParams <- 1
    
    bigDataPosInfo$deviance <- dimParams
    dimParams <- dimParams + 1
           
    bigDataPosInfo$rho        <- dimParams
    dimParams <- dimParams + 1   
    
    bigDataPosInfo$rhoW       <- dimParams
    dimParams <- dimParams + 1           
    
    bigDataPosInfo$gammma <- dimParams
    dimParams <- dimParams + 1                            
    
    bigDataPosInfo$lambda <- dimParams
    dimParams <- dimParams + 1          

    bigDataPosInfo$lambdaW <- dimParams
    dimParams <- dimParams + 1          

    bigDataPosInfo$chiSqW <- dimParams
    dimParams <- dimParams + 1          

    bigDataPosInfo$sigmaSqConstW <- dimParams
    dimParams <- dimParams + 1                            
                    
    bigDataPosInfo$mu <- dimParams:(dimParams+nCountries-1)
    dimParams <- dimParams + nCountries
   
    bigDataPosInfo$sigmaSqConst <- dimParams:(dimParams+nCountries-1)
    dimParams <- dimParams + nCountries       
            
    bigDataPosInfo$sigmaSqOmega <- dimParams
    dimParams <- dimParams + 1

    bigDataPosInfo$sigmaSqOmegaW <- dimParams
    dimParams <- dimParams + 1
    
    bigDataPosInfo$sigmaSqNu <- dimParams:(dimParams+nCountries-1)
    dimParams <- dimParams + nCountries
    
    bigDataPosInfo$chiSq <- dimParams:(dimParams+nCountries-1)
    dimParams <- dimParams + nCountries
    
    bigDataPosInfo$xi   <- dimParams:(dimParams+nCountries-1)
    dimParams <- dimParams + nCountries        
                   
    bigDataPosInfo$dimParams <- dimParams
    
    return(bigDataPosInfo)
}

# Combine Runs without combining chains
################################################################################
combineRuns <- function(UnobsPosInfo, bigDataPosInfo, runsToUse)
{
    nRuns         <- length(runsToUse)   

    filename <-  file.path(runsToUse[1]) 
    load(filename)

    nChains <- length(bugsSim)
    
    nThin         <- max(1, (nRuns*nrow(bugsSim[[1]])) %/% 2000)
    
    cat(nThin,"\n")
    
    rm(bugsSim)
    
    dimParams <- bigDataPosInfo$dimParams
    
    bigDataXX      <- replicate(nChains,NULL)
    bigDataXXW     <- replicate(nChains,NULL)    
    bigDataYY      <- replicate(nChains,NULL)
    bigDataSigmaSq <- replicate(nChains,NULL)
    bigDataSigmaSqW<- replicate(nChains,NULL)
    bigDataSigmaSqTempW<- replicate(nChains,NULL)
    bigDataEtaW    <- replicate(nChains,NULL) 
    bigDataParams  <- replicate(nChains,NULL)
     
    for (ii in 1:nRuns) {
        filename <-  file.path(runsToUse[ii]) 
     
        load(filename)
        
        rowsToKeep <- seq(nThin,nrow(bugsSim[[1]]),by = nThin)
        
        ## Combine xx
        for (jj in 1:nChains) {    
            bigDataXX[[jj]] <- rbind(bigDataXX[[jj]], matrix(bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$xx],
                                    nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$xx)))
        }
        
        ## Combine xxW
        for (jj in 1:nChains) {    
            bigDataXXW[[jj]] <- rbind(bigDataXXW[[jj]], matrix(bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$xxW],
                                    nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$xxW)))
        }        

        ## Combine yy
        for (jj in 1:nChains) {    
            bigDataYY[[jj]] <- rbind(bigDataYY[[jj]], matrix(bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$yy],
                                    nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$yy)))
        }

        ## Combine sigmaSq
        for (jj in 1:nChains) {    
            bigDataSigmaSq[[jj]] <- rbind(bigDataSigmaSq[[jj]], matrix(bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$sigmaSq],
                                       nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$sigmaSq)))
        }

        ## Combine sigmaSqW
        for (jj in 1:nChains) {    
            bigDataSigmaSqW[[jj]] <- rbind(bigDataSigmaSqW[[jj]], matrix(bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$sigmaSqW],
                                           nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$sigmaSqW)))
        }

        ## Combine sigmaSqTempW
        for (jj in 1:nChains) {    
            bigDataSigmaSqTempW[[jj]] <- rbind(bigDataSigmaSqTempW[[jj]], matrix(bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$sigmaSqTempW],
                                           nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$sigmaSqTempW)))
        }        
        
        ## Combine etaW
        for (jj in 1:nChains) {    
            bigDataEtaW[[jj]] <- rbind(bigDataEtaW[[jj]], matrix(bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$etaW],
                                    nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$etaW)))
        }

        for (jj in 1:nChains){
            tempParams <- matrix(0, nrow = length(rowsToKeep), ncol = dimParams)
            
            tempParams[,bigDataPosInfo$deviance]      <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$deviance]
            tempParams[,bigDataPosInfo$sigmaSqConst]  <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$sigmaSqConst]
            tempParams[,bigDataPosInfo$sigmaSqConstW] <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$sigmaSqConstW]
            tempParams[,bigDataPosInfo$rho]           <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$rho]                                                
            tempParams[,bigDataPosInfo$rhoW]          <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$rhoW]                                                            
            tempParams[,bigDataPosInfo$gammma]        <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$gammma]            
            tempParams[,bigDataPosInfo$lambda]        <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$lambda]            
            tempParams[,bigDataPosInfo$lambdaW]       <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$lambdaW]                                    
            tempParams[,bigDataPosInfo$mu]            <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$mu]
            tempParams[,bigDataPosInfo$sigmaSqOmega]  <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$sigmaSqOmega]
            tempParams[,bigDataPosInfo$sigmaSqOmegaW] <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$sigmaSqOmegaW]
            tempParams[,bigDataPosInfo$chiSq]         <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$chiSq]
            tempParams[,bigDataPosInfo$chiSqW]        <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$chiSqW]
            tempParams[,bigDataPosInfo$xi]            <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$xi]              
            tempParams[,bigDataPosInfo$sigmaSqNu]     <- bugsSim[[jj]][ rowsToKeep, UnobsPosInfo$sigmaSqNu]
    
            bigDataParams[[jj]] <- rbind(bigDataParams[[jj]], tempParams)
        }
        
        cat('.')
    }
    cat('\n')
       
    colnames <- c(dimnames(bugsSim[[1]][UnobsPosInfo$deviance]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmaSqConst]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmaSqConstW]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$rho]),                                                        
                  dimnames(bugsSim[[1]][UnobsPosInfo$rhoW]),                  
                  dimnames(bugsSim[[1]][UnobsPosInfo$gammma]),                   
                  dimnames(bugsSim[[1]][UnobsPosInfo$lambda]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$lambdaW]),                                    
                  dimnames(bugsSim[[1]][UnobsPosInfo$chiSq]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$chiSqW]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$xi]),                   
                  dimnames(bugsSim[[1]][UnobsPosInfo$mu]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmSqOmega]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmSqOmegaW]),
                  dimnames(bugsSim[[1]][UnobsPosInfo$sigmSqNu]))
                  
    rownames <- 1:nrow(bigDataParams[[1]])
    
    filename <-  file.path(outDir, 'bigDataXX.Rda') 
    save(bigDataXX,file = filename)
    filename <-  file.path(outDir, 'bigDataXXW.Rda') 
    save(bigDataXXW,file = filename)    
    filename <-  file.path(outDir, 'bigDataYY.Rda') 
    save(bigDataYY,file = filename)
    filename <-  file.path(outDir, 'bigDataSigmaSq.Rda') 
    save(bigDataSigmaSq,file = filename)
    filename <-  file.path(outDir, 'bigDataSigmaSqW.Rda') 
    save(bigDataSigmaSqW,file = filename)
    filename <-  file.path(outDir, 'bigDataSigmaSqTempW.Rda') 
    save(bigDataSigmaSqTempW,file = filename)    
    filename <-  file.path(outDir, 'bigDataEtaW.Rda') 
    save(bigDataEtaW,file = filename)    
    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    save(bigDataParams,file = filename)
}

# Combine Chains Once Runs Have Already Been Combined
################################################################################
combineChains <- function(UnobsPosInfo, bigDataPosInfo)
{
    filename <-  file.path(outDir, "bigDataXX.Rda") 
    load(filename)
    filename <-  file.path(outDir, "bigDataXXW.Rda") 
    load(filename)    
    filename <-  file.path(outDir, "bigDataYY.Rda") 
    load(filename)
    filename <-  file.path(outDir, "bigDataSigmaSq.Rda") 
    load(filename)        
    filename <-  file.path(outDir, "bigDataSigmaSqW.Rda") 
    load(filename)  
    filename <-  file.path(outDir, "bigDataSigmaSqTempW.Rda") 
    load(filename)           
    filename <-  file.path(outDir, "bigDataEtaW.Rda") 
    load(filename)    
    filename <-  file.path(outDir, "bigDataParams.Rda") 
    load(filename)    
    
    nChains       <- length(bigDataXX)  
    nThin         <- nChains #max(1, (nRuns*nrow(bugsSim[[1]])) %/% 2000)
    rowsToKeep    <- seq(nThin,nrow(bigDataXX[[1]]),by = nThin)       
    dimParams     <- bigDataPosInfo$dimParams
    
    #cat(nThin,"\n")    
    
    bigDataXX_pooled      <- NULL
    bigDataXXW_pooled     <- NULL    
    bigDataYY_pooled      <- NULL
    bigDataSigmaSq_pooled <- NULL
    bigDataSigmaSqW_pooled<- NULL
    bigDataSigmaSqTempW_pooled<- NULL
    bigDataEtaW_pooled    <- NULL
    bigDataParams_pooled  <- NULL
                     
    for (jj in 1:nChains) {    
        bigDataXX_pooled      <- rbind(bigDataXX_pooled, matrix(bigDataXX[[jj]][rowsToKeep,],nrow = length(rowsToKeep),ncol = length(UnobsPosInfo$xx)))                 ## Combine xx
        bigDataXXW_pooled     <- rbind(bigDataXXW_pooled, matrix(bigDataXXW[[jj]][rowsToKeep,],nrow = length(rowsToKeep),ncol = length(UnobsPosInfo$xxW)))                 ## Combine xx        
        bigDataYY_pooled      <- rbind(bigDataYY_pooled, matrix(bigDataYY[[jj]][rowsToKeep,],nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$yy)))                ## Combine yy
        bigDataSigmaSq_pooled <- rbind(bigDataSigmaSq_pooled, matrix(bigDataSigmaSq[[jj]][rowsToKeep,],nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$sigmaSq))) ## Combine sigmaSq
        bigDataSigmaSqW_pooled<- rbind(bigDataSigmaSqW_pooled, matrix(bigDataSigmaSqW[[jj]][rowsToKeep,],nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$sigmaSqW))) ## Combine sigmaSqW
        bigDataSigmaSqTempW_pooled<- rbind(bigDataSigmaSqTempW_pooled, matrix(bigDataSigmaSqTempW[[jj]][rowsToKeep,],nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$sigmaSqTempW))) ## Combine sigmaSqW
        bigDataEtaW_pooled    <- rbind(bigDataEtaW_pooled, matrix(bigDataEtaW[[jj]][ rowsToKeep,],nrow = length(rowsToKeep), ncol = length(UnobsPosInfo$etaW)))               ## Combine EtaW
        bigDataParams_pooled  <- rbind(bigDataParams_pooled, matrix(bigDataParams[[jj]][rowsToKeep,],nrow = length(rowsToKeep), ncol = dimParams))                      ## Combine Params
    }

    rm(bigDataXX) 
    rm(bigDataXXW)     
    rm(bigDataYY) 
    rm(bigDataSigmaSq) 
    rm(bigDataSigmaSqW) 
    rm(bigDataSigmaSqTempW) 
    rm(bigDataEtaW)
    rm(bigDataParams)
        
    filename <-  file.path(outDir, 'bigDataXX_pooled.Rda') 
    save(bigDataXX_pooled,file = filename)
    filename <-  file.path(outDir, 'bigDataXXW_pooled.Rda') 
    save(bigDataXXW_pooled,file = filename)    
    filename <-  file.path(outDir, 'bigDataYY_pooled.Rda') 
    save(bigDataYY_pooled,file = filename)
    filename <-  file.path(outDir, 'bigDataSigmaSq_pooled.Rda') 
    save(bigDataSigmaSq_pooled,file = filename)
    filename <-  file.path(outDir, 'bigDataSigmaSqW_pooled.Rda') 
    save(bigDataSigmaSqW_pooled,file = filename)
    filename <-  file.path(outDir, 'bigDataSigmaSqTempW_pooled.Rda') 
    save(bigDataSigmaSqTempW_pooled,file = filename)
    filename <-  file.path(outDir, 'bigDataEtaW_pooled.Rda') 
    save(bigDataEtaW_pooled,file = filename)    
    filename <-  file.path(outDir, 'bigDataParams_pooled.Rda') 
    save(bigDataParams_pooled,file = filename)
}

## Creates tables with summary stats for the common parameters
################################################################################
summaryCommonParameters <- function(controlAgg,bigDataPosInfo)
{
    allData       <- readData(prefixDir)
    modelData     <- getModelData(allData)
    
    .calcSummary2 <-
        function(bugsSim,varPosInfo = 1:(dim(bugsSim)[2]),toPower = 1)
    {     
            
        bugsSim <- as.matrix(bugsSim[,varPosInfo]^toPower)
        
        nParams <- dim(bugsSim)[2]
        
        tempVar <- matrix(apply(bugsSim,2,mean),nParams,1)
        colnames(tempVar) <- "mean"
        output  <- tempVar
    
        #tempVar <- matrix(apply(bugsSim,2,median),nParams,1)
        #colnames(tempVar) <- "median"
        #output  <- cbind(output,tempVar)
    
        tempVar <- matrix(apply(bugsSim,2,sd),nParams,1)
        colnames(tempVar) <- "sd"
        output  <- cbind(output,tempVar)
        
        return(output)
    }
    
    .priorPar <-
        function(meanPrior,sdPrior) 
    {
        #tempVar <- matrix(priorType,1,1)
        #colnames(tempVar) <- 'prior'
        #output <- tempVar
        
        tempVar <- matrix(meanPrior,1,1)
        #colnames(tempVar) <- c('E(',varName,')^{prior}')
        colnames(tempVar) <- 'prior mean'
        output <- cbind(tempVar)
        
        tempVar <- matrix(sdPrior,1,1)
        #colnames(tempVar) <- c('std(',varName,')^{prior}')
        colnames(tempVar) <- 'prior sd'
        output <- cbind(output,tempVar)
        
        return(output)
    }
    
    if (controlAgg$usePooledChains == 0){
        filename <-  file.path(outDir, 'bigDataParams.Rda') 
        load(filename)    
                
        Posterior <- rbind(.calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$rho,1),
                           .calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$rhoW,1),                           
                           .calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$sigmaSqConstW,1/2),
                           .calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$sigmaSqOmega,1/2),
                           .calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$sigmaSqOmegaW,1/2),
                           .calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$gammma,1),
                           .calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$lambda,1),
                           .calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$lambdaW,1),
                           .calcSummary2(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$chiSqW,1/2))
    }
    if (controlAgg$usePooledChains == 1){
        filename <-  file.path(outDir, 'bigDataParams_pooled.Rda') 
        load(filename)    
        
        Posterior <- rbind(.calcSummary2(bigDataParams_pooled,bigDataPosInfo$rho,1),
                           .calcSummary2(bigDataParams_pooled,bigDataPosInfo$rhoW,1),                           
                           .calcSummary2(bigDataParams_pooled,bigDataPosInfo$sigmaSqConstW,1/2),
                           .calcSummary2(bigDataParams_pooled,bigDataPosInfo$sigmaSqOmega,1/2),
                           .calcSummary2(bigDataParams_pooled,bigDataPosInfo$sigmaSqOmegaW,1/2),
                           .calcSummary2(bigDataParams_pooled,bigDataPosInfo$gammma,1),
                           .calcSummary2(bigDataParams_pooled,bigDataPosInfo$lambda,1),
                           .calcSummary2(bigDataParams_pooled,bigDataPosInfo$lambdaW,1),
                           .calcSummary2(bigDataParams_pooled,bigDataPosInfo$chiSqW,1/2))
    }   
    # rho Prior
    meanPrior.rho        <- (modelData$low.rho+modelData$high.rho)/2
    sdPrior.rho          <- sqrt(1/12*(modelData$low.rho-modelData$high.rho)^2)     

    # rhoW Prior
    meanPrior.rhoW       <- (modelData$low.rhoW+modelData$high.rhoW)/2
    sdPrior.rhoW         <- sqrt(1/12*(modelData$low.rhoW-modelData$high.rhoW)^2)  

    ## SigmaSqConstW Prior
    sigmaSqConstW         <- runif(100000,modelData$low.sigmaSqConstW,modelData$high.sigmaSqConstW)
    meanPrior.sigmaConstW <- mean(sigmaSqConstW^0.5)
    sdPrior.sigmaConstW   <- sd(sigmaSqConstW^0.5) 
    
    ## SigmaSqOmega Prior
    sigmaSqOmega         <- runif(100000,modelData$low.sigmaSqOmega,modelData$high.sigmaSqOmega)
    meanPrior.sigmaOmega <- mean(sigmaSqOmega^0.5)
    sdPrior.sigmaOmega   <- sd(sigmaSqOmega^0.5)     

    ## SigmaSqOmegaW Prior
    sigmaSqOmegaW         <- runif(100000,modelData$low.sigmaSqOmegaW,modelData$high.sigmaSqOmegaW)
    meanPrior.sigmaOmegaW <- mean(sigmaSqOmegaW^0.5)
    sdPrior.sigmaOmegaW   <- sd(sigmaSqOmegaW^0.5)   

    # gammma Prior
    meanPrior.gammma     <- (modelData$low.gammma+modelData$high.gammma)/2
    sdPrior.gammma       <- sqrt(1/12*(modelData$low.gammma-modelData$high.gammma)^2)   
    
    # lambda Prior
    meanPrior.lambda     <- (modelData$low.lambda+modelData$high.lambda)/2
    sdPrior.lambda       <- sqrt(1/12*(modelData$low.lambda-modelData$high.lambda)^2)      
    
    # lambdaW Prior
    meanPrior.lambdaW    <- (modelData$low.lambdaW + modelData$high.lambdaW)/2
    sdPrior.lambdaW      <- sqrt(1/12*(modelData$low.lambdaW-modelData$high.lambdaW)^2)        

    ## chiSqW Prior
    chiSqW               <- runif(100000,modelData$low.chiSqW,modelData$high.chiSqW)
    meanPrior.chiW       <- mean(chiSqW^0.5)
    sdPrior.chiW         <- sd(chiSqW^0.5) 

    Prior <- rbind(.priorPar(meanPrior.rho,sdPrior.rho),
                   .priorPar(meanPrior.rhoW,sdPrior.rhoW),                   
                   .priorPar(meanPrior.sigmaConstW,sdPrior.sigmaConstW),
                   .priorPar(meanPrior.sigmaOmega,sdPrior.sigmaOmega),
                   .priorPar(meanPrior.sigmaOmegaW,sdPrior.sigmaOmegaW),
                   .priorPar(meanPrior.gammma,sdPrior.gammma),
                   .priorPar(meanPrior.lambda,sdPrior.lambda),
                   .priorPar(meanPrior.lambdaW,sdPrior.lambdaW),
                   .priorPar(meanPrior.chiW,sdPrior.chiW))
        
    Table <- cbind(Prior,Posterior)
                   
    # Save tables   
    if (controlAgg$TableFormat$TeX == 1){
        TableTeX           <- Table
        rownames(TableTeX) <- c('$\\rho$','$\\rhoW$','$\\sigma^{W}$','$\\sigma_{\\omega}$','$\\sigma_{\\omega}^{W}$','$\\gamma_{\\epsilon}$','$\\lambda$',,'$\\lambda_W$')   
         
        filename <- file.path(outDir,paste(c('Parmaters.Common',controlAgg$outputFileNamePostfix),collapse = "."))
        latex.table(TableTeX,
                    file        = filename, 
                    rowlabel    = "", 
                    caption     = "Common parameter.",
                    dec         = 3, 
                    label       = '')
    }
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        TableXLS           <- Table
        rownames(TableXLS) <- c('rho','rhoW','sigmaConstW','sigmaOmega','sigmaOmegaW','gammma','lambda','lambdaW','chiW')
        
        filename   <- file.path(outDir,paste(c('Parameters.Common',controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
        write.table(round(TableXLS,7), filename,row.names = T,col.names=NA, sep = ",")      
    }                  
}

## Creates tables with summary stats for the country-specific parameters
################################################################################
summaryCountryParameters <- function(controlAgg,bigDataPosInfo)
{
    allData       <- readData(prefixDir)
    modelData     <- getModelData(allData)

    countryNames <- allData$countryNames
    nCountries   <- length(countryNames)
    
    .calcSummary3 <-
        function(bugsSim,varPosInfo = 1:(dim(bugsSim)[2]),toPower = 1,name)
    {     
        bugsSim <- as.matrix(bugsSim[,varPosInfo]^toPower)
        
        nParams <- dim(bugsSim)[2]
        
        tempVar <- matrix(apply(bugsSim,2,mean),nParams,1)
        colnames(tempVar) <- paste(name,"mean")
        output  <- tempVar
    
        tempVar <- matrix(apply(bugsSim,2,sd),nParams,1)
        colnames(tempVar) <- paste(name,"sd")
        output  <- cbind(output,tempVar)
        
        return(output)
    }
    
    if (controlAgg$usePooledChains == 0){
        filename <-  file.path(outDir, 'bigDataParams.Rda') 
        load(filename)    

        ## sigmaConst, sigmaEta, sigmaNu, mu
        CountrySumSigmaConst <- .calcSummary3(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$sigmaSqConst,1/2,"sigmaConst")
        CountrySumChi        <- .calcSummary3(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$chiSq,1/2,"chi")    
        CountrySumSigmaNu    <- .calcSummary3(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$sigmaSqNu,1/2,"sigmaNu") 
        CountrySumMu         <- .calcSummary3(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$mu,1,"mu")
        CountrySumXi         <- .calcSummary3(bigDataParams[[controlAgg$chainToUse]],bigDataPosInfo$xi,1,"xi")        
    }
    if (controlAgg$usePooledChains == 1){
        filename <-  file.path(outDir, 'bigDataParams_pooled.Rda') 
        load(filename)    

        ## sigmaConst, sigmaEta, sigmaNu, mu
        CountrySumSigmaConst <- .calcSummary3(bigDataParams_pooled,bigDataPosInfo$sigmaSqConst,1/2,"sigmaConst")     
        CountrySumChi        <- .calcSummary3(bigDataParams_pooled,bigDataPosInfo$chiSq,1/2,"chi")    
        CountrySumSigmaNu    <- .calcSummary3(bigDataParams_pooled,bigDataPosInfo$sigmaSqNu,1/2,"sigmaNu") 
        CountrySumMu         <- .calcSummary3(bigDataParams_pooled,bigDataPosInfo$mu,1,"mu")
        CountrySumXi         <- .calcSummary3(bigDataParams_pooled,bigDataPosInfo$xi,1,"xi")        
    }   
    CountrySum           <- cbind(CountrySumSigmaConst,CountrySumChi,CountrySumSigmaNu,CountrySumMu,CountrySumXi)         
    dimnames(CountrySum) <- list(countryNames,dimnames(CountrySum)[[2]])

    if (controlAgg$TableFormat$TeX == 1){      
        CountrySumTeX <- CountrySum  
        colnames(CountrySumTeX) <- c("mean $\\sigma_{\\epsilon}$","sd $\\sigma_{\\epsilon}$",
                                     "mean $\\chi$"          ,    "sd $\\chi$",
                                     "mean $\\sigma_{\\nu}$",     "sd $\\sigma_{\\nu}$",
                                     "mean $\\mu$",               "sd $\\mu$",
                                     "mean $\\xi$",               "sd $\\xi$")        
        filename <-  file.path(outDir, paste(c('Parameters.Country',controlAgg$outputNameFilePostfix),collapse = "."))  
        latex.table(CountrySumTeX,file = filename, rowlabel="", caption="$\\sigma_{\\epsilon}$; $\\chi$; $\\sigma_{\\nu}$; $\\mu$; $\\xi$",dec = 5, label = '')       
    }    
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        CountrySumXLS <- CountrySum
        filename   <- file.path(outDir,paste(c('Parameters.Country',controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
        write.table(round(CountrySumXLS,5), filename,row.names = T,col.names=NA, sep = ",")    
    }      
}

## Creates basic country and parameter plots
################################################################################
simPlotMany <- function(bigDataPosInfo)
{

    allData       <- readData(prefixDir)
    modelData     <- getModelData(allData)    

    cc          <- allData$cData    
    nCountries  <- length(allData$countryNames)
    posFirst    <- allData$posFirst
    posLast     <- allData$posLast
    startYears  <- allData$startYears
    endYears    <- allData$endYears
    countryNames<- allData$countryNames
    posIIW      <- allData$posIIW

    posIIW      <- allData$posIIW
    nPeriods    <- max(posIIW)
    allYears    <- seq(min(startYears),min(startYears)+nPeriods-1,by =1)
    
        
    .tracePlotCountry <-
        function(dataList,posInfo,nameInfo,toPower)
    {
        TempInd    <- min(posInfo) - 1 + ii
        TempSample <- matrix(dataList[[1]][ , TempInd])^toPower
        labEx      <- nameInfo
        temp.range <- NULL
        for (jj in 1:nChains){
            temp.range <- c(temp.range,matrix(dataList[[jj]][ , TempInd])^toPower)
        }    
        ylimTemp   <- range(temp.range)               
        plot(1:nrow(dataList[[1]]), as.ts(TempSample),
             main = labEx,
             xlab = 'iters',
             ylab = labEx,
             type = "l",
             ylim = ylimTemp,
             col = 1)
        if (nChains > 1) {
            for (jj in 2:nChains) {    
                TempSample <- matrix(dataList[[jj]][ , TempInd])^toPower
                lines(1:nrow(dataList[[1]]), TempSample, type = "l", col = jj)
            }
        }
    }
    
    .tracePlotCountryPooledChains <-
        function(dataList,posInfo,nameInfo,toPower)
    {
        TempInd    <- min(posInfo) - 1 + ii
        TempSample <- matrix(dataList[ , TempInd])^toPower
        labEx      <- nameInfo

        temp.range <- c(matrix(dataList[ , TempInd])^toPower)

        ylimTemp   <- range(temp.range)               
        plot(1:nrow(dataList), as.ts(TempSample),
             main = labEx,
             xlab = 'iters',
             ylab = labEx,
             type = "l",
             ylim = ylimTemp,
             col = 1)
    }    
    
    .histogramCountry <-
        function(dataList,posInfo,nameInfo,toPower)
    {    
        for (jj in 1:nChains) {    
            TempInd <- min(posInfo) - 1 + ii
            TempSample <- matrix(dataList[[jj]][ , TempInd])^toPower        
            labEx <- nameInfo
            hist(TempSample,
                 main        = paste(labEx,'for','chain',jj),
                 ylab        = 'prob',
                 xlab        = labEx,
                 col         = jj,
                 probability = TRUE)
        }     

    }    
    
    .histogramCountryPooledChains <-
        function(dataList,posInfo,nameInfo,toPower)
    {    
 
            TempInd <- min(posInfo) - 1 + ii
            TempSample <- matrix(dataList[ , TempInd])^toPower        
            labEx <- nameInfo
            hist(TempSample,
                 main        = labEx,
                 ylab        = 'prob',
                 xlab        = labEx,
                 col         = 1,
                 probability = TRUE)    
    }        
    
    .tracePlot <-
        function(dataList,posInfo,nameInfo,toPower)
    {
        TempInd <- posInfo
        TempSample <- matrix(dataList[[1]][ , TempInd])^toPower
        labEx <- nameInfo
        temp.range <- NULL
        for (jj in 1:nChains){
            temp.range <- c(temp.range,matrix(dataList[[jj]][ , TempInd])^toPower)
        }    
        ylimTemp   <- range(temp.range)    
        plot(1:nrow(dataList[[1]]), as.ts(TempSample),
             main = labEx,
             xlab = 'time',
             ylab = labEx,
             type = "l",
             ylim = ylimTemp,
             col = 1)
        if (nChains > 1) {
            for (jj in 2:nChains) {    
                TempSample <- matrix(dataList[[jj]][ , TempInd])^toPower
                lines(1:nrow(dataList[[1]]), TempSample, type = "l", col = jj)
            }
        }             
    }
    
    .tracePlotPooledChains <-
        function(dataList,posInfo,nameInfo,toPower)
    {
        TempInd    <- posInfo
        TempSample <- matrix(dataList[ , TempInd])^toPower
        labEx      <- nameInfo
        temp.range <- matrix(dataList[ , TempInd])^toPower
        ylimTemp   <- range(temp.range)    
        plot(1:nrow(dataList), as.ts(TempSample),
             main = labEx,
             xlab = 'time',
             ylab = labEx,
             type = "l",
             ylim = ylimTemp,
             col = 1)
    }    
    
    .histogram <-
        function(dataList,posInfo,nameInfo,toPower)
    {
        for (jj in 1:nChains) {
            TempInd <- posInfo
            TempSample <- dataList[[jj]][ , TempInd]^toPower
            labEx <- nameInfo
            hist(TempSample,
                 main        = labEx,
                 xlab        = labEx,
                 ylab        = 'prob',
                 col         = jj,
                 probability = TRUE)
         }        
    }


    .histogramPooledChains <-
        function(dataList,posInfo,nameInfo,toPower)
    {
            TempInd <- posInfo
            TempSample <- dataList[ , TempInd]^toPower
            labEx <- nameInfo
            hist(TempSample,
                 main        = labEx,
                 xlab        = labEx,
                 ylab        = 'prob',
                 col         = 1,
                 probability = TRUE)
    }
    
    .tracePlotLikelihood <-
        function(dataList,posInfo)
    {
        TempInd <- posInfo
        TempSample <- -1/2*dataList[[1]][ , TempInd]
        labEx <- 'Log Likelihood'
        temp.range <- NULL
        for (jj in 1:nChains){
            temp.range <- c(temp.range,matrix(dataList[[jj]][ , TempInd]))
        }    
        ylimTemp   <- range(temp.range)  
        plot(1:nrow(dataList[[1]]), as.ts(TempSample),
             main = labEx,
             xlab = 'time',
             ylab = labEx,
             type = "l",
             ylim = ylimTemp,
             col = 1)
        if (nChains > 1) {
            for (jj in 2:nChains) {    
                TempSample <- matrix(dataList[[jj]][ , TempInd])
                lines(1:nrow(dataList[[1]]), TempSample, type = "l", col = jj)
            }
        }              
    }

    .histogramLikelihood <-
        function(dataList,posInfo)
    {
        for (jj in 1:nChains) {
            TempInd <- posInfo
            TempSample <- -1/2*dataList[[jj]][ , TempInd]
            labEx <- 'Log Likelihood'
            hist(TempSample,
                 main        = labEx,
                 xlab        = labEx,
                 ylab        = 'prob',
                 col         = jj,
                 probability = TRUE)
         }        
    }

    filename <-  file.path(outDir, 'bigDataParams.Rda') 
    load(filename)         
    
    if (controlAgg$plotPooledChains == 1){
        filename <-  file.path(outDir, 'bigDataParams_pooled.Rda') 
        load(filename)         
    }
       
    nChains <- length(bigDataParams)
    
    ## Common Parameter plots                      
    ###############################################
    filename <-  file.path(outDir, 'bigData.CommonParameters.pdf')
    pdf(filename, paper = 'special', width = 6, height = 7)
    if (nChains == 1) par(mfrow = c(3, 2))
    if (nChains == 2) par(mfrow = c(3, 2)) 

    .tracePlot(bigDataParams, bigDataPosInfo$rho,'rho',1)            
    .histogram(bigDataParams, bigDataPosInfo$rho,'rho',1)     
    
    .tracePlot(bigDataParams, bigDataPosInfo$rhoW,'rhoW',1)           
    .histogram(bigDataParams, bigDataPosInfo$rhoW,'rhoW',1)            

    .tracePlot(bigDataParams, bigDataPosInfo$gammma,'gammma',1)            
    .histogram(bigDataParams, bigDataPosInfo$gammma,'gammma',1)      

    .tracePlot(bigDataParams, bigDataPosInfo$chiSqW,'chiW',1/2)           
    .histogram(bigDataParams, bigDataPosInfo$chiSqW,'chiW',1/2)              
    
    .tracePlot(bigDataParams, bigDataPosInfo$lambda,'lambda',1)            
    .histogram(bigDataParams, bigDataPosInfo$lambda,'lambda',1)              

    .tracePlot(bigDataParams, bigDataPosInfo$lambdaW,'lambdaW',1)           
    .histogram(bigDataParams, bigDataPosInfo$lambdaW,'lambdaW',1)              

    .tracePlot(bigDataParams, bigDataPosInfo$sigmaSqConstW,'sigmaConstW',1/2)           
    .histogram(bigDataParams, bigDataPosInfo$sigmaSqConstW,'sigmaConstW',1/2)              
    
    .tracePlot(bigDataParams, bigDataPosInfo$sigmaSqOmega,'sigmaOmega',1/2)           
    .histogram(bigDataParams, bigDataPosInfo$sigmaSqOmega,'sigmaOmega',1/2)              

    .tracePlot(bigDataParams, bigDataPosInfo$sigmaSqOmegaW,'sigmaOmegaW',1/2)         
    .histogram(bigDataParams, bigDataPosInfo$sigmaSqOmegaW,'sigmaOmegaW',1/2)

    dev.off()
    
    
    if (controlAgg$plotPooledChains == 1){
        filename <-  file.path(outDir, 'bigData.CommonParameters.PooledChains.pdf')
        pdf(filename, paper = 'special', width = 6, height = 7)
        par(mfrow = c(3, 2))

        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$rho,'rho',1)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$rho,'rho',1)     
        
        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$rhoW,'rhoW',1)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$rhoW,'rhoW',1)                  
    
        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$gammma,'gammma',1)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$gammma,'gammma',1)    

        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$chiSqW,'chiW',1)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$chiSqW,'chiW',1)    
        
        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$lambda,'lambda',1)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$lambda,'lambda',1) 
        
        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$lambdaW,'lambdaW',1)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$lambdaW,'lambdaW',1)                         
        
        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqConstW,'sigmaConstW',1/2)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqConstW,'sigmaConstW',1/2)              

        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqOmega,'sigmaOmega',1/2)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqOmega,'sigmaOmega',1/2)              

        .tracePlotPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqOmegaW,'sigmaOmegaW',1/2)
        .histogramPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqOmegaW,'sigmaOmegaW',1/2)              
    
        dev.off()    
    }
    
    if (controlAgg$fullPlot == 1) {
             
        nChains <- length(bigDataParams)
    
        ## Plot each country's output from bugs
        ########################################
        for (ii in 1:nCountries) {
            filename <-  file.path(outDir, paste(c('bigData', countryNames[ii], 'pdf'),collapse = '.'))
            pdf(filename, paper = 'special', width = 6, height = 7)
            if (nChains == 1) par(mfrow = c(3, 2))
            if (nChains == 2) par(mfrow = c(3, 2))           
  
            ## Plot consumption
            labEx <- expression(c[t])       
            ylimTemp <- range(c(cc[posFirst[ii]:posLast[ii]],cc[posFirst[ii]:posLast[ii]]))               
            plot(startYears[ii]:endYears[ii], as.ts(cc[posFirst[ii]:posLast[ii]]),
                 main = paste(labEx,'for',countryNames[ii]),
                 xlab = 'time',
                 ylab = labEx,
                 type = "l",
                 ylim = ylimTemp)
            # Blank Plot
            frame() 
            ## Plot Stochastic volatility: sigma + sigmaW
            filename <-  file.path(outDir, 'bigDataParams.Rda') 
            load(filename)            
            filename <-  file.path(outDir, 'bigDataSigmaSq.Rda') 
            load(filename)            
            filename <-  file.path(outDir, 'bigDataSigmaSqW.Rda') 
            load(filename)
            
            TempSample     <- (bigDataSigmaSq[[1]][, bigDataPosInfo$sigmaSq[(posFirst[ii]+1):posLast[ii]]] 
                              + bigDataSigmaSqW[[1]][, bigDataPosInfo$sigmaSqW[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]])^0.5                        
            mean.Sample    <- apply(TempSample,2,mean)            
            
            q05.Sample     <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample     <- apply(TempSample,2,quantile, probs = 0.95)
            
            ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample))
            plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample),
                 main = countryNames[ii],
                 xlab = 'time',
                 ylab = "sigma_{i,t} + sigma_{W,t}",
                 type = "l",
                 ylim = ylimTemp)
            lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 3)
            lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 4)

            if (nChains == 2){
                mean.Sample.Xi <- mean(TempSampleXi)            
                TempSample     <- (bigDataSigmaSq[[2]][, bigDataPosInfo$sigmaSq[(posFirst[ii]+1):posLast[ii]]] 
                                  + bigDataSigmaSqW[[2]][, bigDataPosInfo$sigmaSqW[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]])^0.5                
                mean.Sample    <- apply(TempSample,2,mean)
                q05.Sample     <- apply(TempSample,2,quantile, probs = 0.05) 
                q95.Sample     <- apply(TempSample,2,quantile, probs = 0.95)
                ylimTemp       <- range(c(mean.Sample,q05.Sample,q95.Sample))
                plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample),
                     main = countryNames[ii],
                     xlab = 'time',
                     ylab = "sigma_{i,t} + sigma_{W,t}",
                     type = "l",
                     ylim = ylimTemp)
                lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 3)
                lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 4)
            }  
            
            ## Plot Stochastic volatility: sigma^2
            TempSample <- (bigDataSigmaSq[[1]][, bigDataPosInfo$sigmaSq[(posFirst[ii]+1):posLast[ii]]])            
            mean.Sample<- apply(TempSample,2,mean)            
            q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
            ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample))
            plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample),
                 main = countryNames[ii],
                 xlab = 'time',
                 ylab = "sigma^2_{i,t}",
                 type = "l",
                 ylim = ylimTemp)
            lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 3)
            lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 4)

            if (nChains == 2){
                TempSample <- (bigDataSigmaSq[[2]][, bigDataPosInfo$sigmaSq[(posFirst[ii]+1):posLast[ii]]])
                mean.Sample<- apply(TempSample,2,mean)
                q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
                q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
                ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample))
                plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample),
                     main = countryNames[ii],
                     xlab = 'time',
                     ylab = "sigma^2_{i,t}",
                     type = "l",
                     ylim = ylimTemp)
                lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 3)
                lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 4)
            }              
            
            ## Plot Stochastic volatility: sigmaW
            TempSample <- (bigDataSigmaSqW[[1]][, bigDataPosInfo$sigmaSqW[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]])^0.5            
            mean.Sample<- apply(TempSample,2,mean)            
            q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
            ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample))
            plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample),
                 main = 'sigma_W',
                 xlab = 'time',
                 ylab = "sigma_{W,t}",
                 type = "l",
                 ylim = ylimTemp)
            lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 3)
            lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 4)

            if (nChains == 2){
                TempSample <- (bigDataSigmaSqW[[2]][, bigDataPosInfo$sigmaSqW[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]])^0.5                
                mean.Sample<- apply(TempSample,2,mean)
                q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
                q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
                ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample))
                plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample),
                     main = 'sigma_W',
                     xlab = 'time',
                     ylab = "sigma_{W,t}",
                     type = "l",
                     ylim = ylimTemp)
                lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 3)
                lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 4)
            }              
            
            rm(bigDataSigmaSq)
            rm(bigDataSigmaSqW)
            
            ## Plot xx and consumption growth
            filename <-  file.path(outDir, 'bigDataXX.Rda') 
            load(filename)
            filename <-  file.path(outDir, 'bigDataXXW.Rda') 
            load(filename)            
            
            TempSampleXi  <- bigDataParams[[1]][,bigDataPosInfo$xi[ii]]
            TempSampleXX  <- bigDataXX[[1]][ , bigDataPosInfo$xx[(posFirst[ii]+1):posLast[ii]]]
            TempSampleXXW <- bigDataXXW[[1]][ ,bigDataPosInfo$xxW[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]]            
            
            mean.Sample.Xi  <- mean(TempSampleXi)
            mean.Sample.XX  <- apply(TempSampleXX,2,mean)
            mean.Sample.XXW <- apply(TempSampleXXW,2,mean)

            q05.Sample.XX  <- apply(TempSampleXX,2,quantile, probs = 0.05) 
            q95.Sample.XX  <- apply(TempSampleXX,2,quantile, probs = 0.95)            
            ylimTemp    <- range(c(mean.Sample.XX,q05.Sample.XX,q95.Sample.XX,diff(cc[posFirst[ii]:posLast[ii]]))) 
            labEx       <- "xx vs. cons gr. Chain 1"
            plot((startYears[ii]+1):endYears[ii], diff(as.ts(cc[posFirst[ii]:posLast[ii]])),
                 main = labEx,
                 xlab = 'time',
                 ylab = expression(x[t]),
                 type = "l",
                 ylim = ylimTemp)
            lines((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XX),                 col = 2)
            lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample.XX),                  col = 3,lty = 3,lwd=1.1)
            lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample.XX),                  col = 3,lty = 3,lwd=1.1)
            lines((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XXW*mean.Sample.Xi), col = 4,lwd=1.1)            
            
            if (nChains == 2){
                TempSampleXi  <- bigDataParams[[2]][,bigDataPosInfo$xi[ii]]            
                TempSampleXX  <- bigDataXX[[2]][ , bigDataPosInfo$xx[(posFirst[ii]+1):posLast[ii]]]
                TempSampleXXW <- bigDataXXW[[2]][ ,bigDataPosInfo$xxW[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]]  
                
                mean.Sample.Xi  <- mean(TempSampleXi)
                mean.Sample.XX  <- apply(TempSampleXX,2,mean)
                mean.Sample.XXW <- apply(TempSampleXXW,2,mean)
                
                q05.Sample.XX  <- apply(TempSampleXX,2,quantile, probs = 0.05) 
                q95.Sample.XX  <- apply(TempSampleXX,2,quantile, probs = 0.95)            
                ylimTemp    <- range(c(mean.Sample.XX,q05.Sample.XX,q95.Sample.XX,diff(cc[posFirst[ii]:posLast[ii]]))) 
                labEx       <- "xx vs. cons gr. Chain 2"
                plot((startYears[ii]+1):endYears[ii], diff(as.ts(cc[posFirst[ii]:posLast[ii]])),
                     main = labEx,
                     xlab = 'time',
                     ylab = expression(x[t]),
                     type = "l",
                     ylim = ylimTemp)
                lines((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XX),                 col = 2)
                lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample.XX),                  col = 3,lty = 3,lwd=1.1)
                lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample.XX),                  col = 3,lty = 3,lwd=1.1)
                lines((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XXW*mean.Sample.Xi), col = 4,lwd=1.1)                
            }
            
            ## Plot xx and xxW
            filename <-  file.path(outDir, 'bigDataXXW.Rda') 
            load(filename)            
            
            TempSampleXi  <- bigDataParams[[1]][,bigDataPosInfo$xi[ii]]            
            TempSampleXX  <- bigDataXX[[1]][ , bigDataPosInfo$xx[(posFirst[ii]+1):posLast[ii]]]
            TempSampleXXW <- bigDataXXW[[1]][ , bigDataPosInfo$xxW[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]]  
            
            mean.Sample.Xi  <- mean(TempSampleXi)
            mean.Sample.XX  <- apply(TempSampleXX,2,mean)
            mean.Sample.XXW <- apply(TempSampleXXW,2,mean)

            ylimTemp    <- range(c(mean.Sample.XX,mean.Sample.Xi*mean.Sample.XXW)) 
            labEx       <- "xx vs. xxW Chain 2"
            plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XX),
                 main = labEx,
                 xlab = 'time',
                 ylab = expression(x[t]),
                 type = "l",
                 ylim = ylimTemp)
            lines((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XXW*mean.Sample.Xi), col = 4,lwd=1.1)                
            
            if (nChains == 2){
                TempSampleXi  <- bigDataParams[[2]][,bigDataPosInfo$xi[ii]]            
                TempSampleXX  <- bigDataXX[[2]][ , bigDataPosInfo$xx[(posFirst[ii]+1):posLast[ii]]]
                TempSampleXXW <- bigDataXXW[[2]][ , bigDataPosInfo$xxW[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]]  
                
                mean.Sample.Xi  <- mean(TempSampleXi)
                mean.Sample.XX  <- apply(TempSampleXX,2,mean)
                mean.Sample.XXW <- apply(TempSampleXXW,2,mean)

                ylimTemp    <- range(c(mean.Sample.XX,mean.Sample.Xi*mean.Sample.XXW)) 
                labEx       <- "xx vs. xxW Chain 2"
                plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XX),
                     main = labEx,
                     xlab = 'time',
                     ylab = expression(x[t]),
                     type = "l",
                     ylim = ylimTemp)
                lines((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XXW*mean.Sample.Xi), col = 4,lwd=1.1)                

            }

            ## Plot Shocks
            ###############################################
            
            TempSampleXX  <- bigDataXX[[1]][ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            TempSampleRho <- bigDataParams[[1]][,bigDataPosInfo$rho]
            
            mean.Sample.XX  <- apply(TempSampleXX,2,mean)
            mean.Sample.rho <- mean(TempSampleRho)
            
            Epsilon <- mean.Sample.XX[2:length(mean.Sample.XX)] - mean.Sample.XX[1:(length(mean.Sample.XX)-1)] * mean.Sample.rho
            ylim_Epsilon = c(-max(abs(Epsilon)),max(abs(Epsilon)))
            xlim_Epsilon = c((startYears[ii]+1),endYears[ii]+0.5)          
                  
            plot((startYears[ii]+1):endYears[ii]+0.5, Epsilon, 
                  type="h", 
                  col="red", 
                  xlab="", 
                  ylab="epsilon", 
                  lwd=0.2, 
                  ylim = ylim_Epsilon,
                  xlim = xlim_Epsilon)
            par(new=TRUE)
            axis(4)
                   
            if (nChains == 2){
                TempSampleXX  <- bigDataXX[[2]][ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
                TempSampleRho <- bigDataParams[[2]][,bigDataPosInfo$rho]
                
                mean.Sample.XX  <- apply(TempSampleXX,2,mean)
                mean.Sample.rho <- mean(TempSampleRho)
                
                Epsilon <- mean.Sample.XX[2:length(mean.Sample.XX)] - mean.Sample.XX[1:(length(mean.Sample.XX)-1)] * mean.Sample.rho
                ylim_Epsilon = c(-max(abs(Epsilon)),max(abs(Epsilon)))
                       
                plot((startYears[ii]+1):endYears[ii]+0.5, Epsilon, 
                     type="h", 
                     col="red", 
                     xlab="", 
                     ylab="epsilon", 
                     lwd=0.3, 
                     ylim = ylim_Epsilon,
                     xlim = xlim_Epsilon)
                par(new=TRUE)
                axis(4)
            }
            ## Parameter plots                             
            ###############################################
            .tracePlotCountry(bigDataParams, bigDataPosInfo$mu,'mu',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$mu,'mu',1)
            
            .tracePlotCountry(bigDataParams, bigDataPosInfo$xi,'xi',1)
            .histogramCountry(bigDataParams, bigDataPosInfo$xi,'xi',1)            

            .tracePlotCountry(bigDataParams, bigDataPosInfo$chiSq,'chi',1/2)
            .histogramCountry(bigDataParams, bigDataPosInfo$chiSq,'chi',1/2)

            .tracePlotCountry(bigDataParams, bigDataPosInfo$sigmaSqConst,'sigmaConst',1/2)            
            .histogramCountry(bigDataParams, bigDataPosInfo$sigmaSqConst,'sigmaConst',1/2)

            .tracePlotCountry(bigDataParams, bigDataPosInfo$sigmaSqNu,'sigmaNu',1/2)           
            .histogramCountry(bigDataParams, bigDataPosInfo$sigmaSqNu,'sigmaNu',1/2)

            dev.off()
        }
    }
    
    if ((controlAgg$fullPlot == 1) & (controlAgg$plotPooledChains == 1)) {
    
        load(file.path(outDir, 'bigDataParams_pooled.Rda'))            
        ## Plot each country's output from bugs
        ########################################
        for (ii in 1:nCountries) {
            filename <-  file.path(outDir, paste(c('bigData', countryNames[ii],"pooledChains", 'pdf'),collapse = '.'))
            pdf(filename, paper = 'special', width = 6, height = 7)
            par(mfrow = c(3, 2))
            ## Plot consumption
            labEx <- expression(c[t])       
            ylimTemp <- range(c(cc[posFirst[ii]:posLast[ii]],cc[posFirst[ii]:posLast[ii]]))               
            plot(startYears[ii]:endYears[ii], as.ts(cc[posFirst[ii]:posLast[ii]]),
                 main = paste(labEx,'for',countryNames[ii]),
                 xlab = 'time',
                 ylab = labEx,
                 type = "l",
                 ylim = ylimTemp)
            ## Plot Stochastic volatility
            filename <-  file.path(outDir, 'bigDataSigmaSq_pooled.Rda') 
            load(filename)            
            filename <-  file.path(outDir, 'bigDataSigmaSqW_pooled.Rda') 
            load(filename)
            TempSample <- (bigDataSigmaSq_pooled[, bigDataPosInfo$sigmaSq[(posFirst[ii]+1):posLast[ii]]] 
                              + bigDataSigmaSqW_pooled[, bigDataPosInfo$sigmaSq[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]])^0.5
            mean.Sample<- apply(TempSample,2,mean)
            q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
            q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
            ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample))
            plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample),
                 main = countryNames[ii],
                 xlab = 'time',
                 ylab = "Stoch. vol. sigma_{i,t}",
                 type = "l",
                 ylim = ylimTemp)
            lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 3)
            lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 4)
            
            rm(bigDataSigmaSq_pooled)
            rm(bigDataSigmaSqW_pooled)
            
            ## Plot xx and consumption growth
            filename <-  file.path(outDir, 'bigDataXX_pooled.Rda') 
            load(filename)
            TempSampleXX  <- bigDataXX_pooled[ , bigDataPosInfo$xx[(posFirst[ii]+1):posLast[ii]]]
            mean.Sample.XX <- apply(TempSampleXX,2,mean)
            q05.Sample.XX  <- apply(TempSampleXX,2,quantile, probs = 0.05) 
            q95.Sample.XX  <- apply(TempSampleXX,2,quantile, probs = 0.95)            
            ylimTemp    <- range(c(mean.Sample.XX,q05.Sample.XX,q95.Sample.XX,diff(cc[posFirst[ii]:posLast[ii]]))) 
            labEx       <- "xx vs. consumption growth"
            plot((startYears[ii]+1):endYears[ii], diff(as.ts(cc[posFirst[ii]:posLast[ii]])),
                 main = labEx,
                 xlab = 'time',
                 ylab = expression(x[t]),
                 type = "l",
                 ylim = ylimTemp)
            lines((startYears[ii]+1):endYears[ii], as.ts(mean.Sample.XX), col = 2)
            lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample.XX), col = 3,lty = 3,lwd=1.1)
            lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample.XX), col = 3,lty = 3,lwd=1.1)

            rm(bigDataXX_pooled)

            ## Plot Shocks
            ###############################################
            filename <-  file.path(outDir, 'bigDataXX_pooled.Rda') 
            load(filename)
            
            TempSampleXX  <- bigDataXX_pooled[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            TempSampleRho <- bigDataParams_pooled[,bigDataPosInfo$rho]
            
            mean.Sample.XX  <- apply(TempSampleXX,2,mean)
            mean.Sample.rho <- mean(TempSampleRho)
            
            Epsilon <- mean.Sample.XX[2:length(mean.Sample.XX)] - mean.Sample.XX[1:(length(mean.Sample.XX)-1)] * mean.Sample.rho
            ylim_Epsilon = c(-max(abs(Epsilon)),max(abs(Epsilon)))
            xlim_Epsilon = c((startYears[ii]+1),endYears[ii]+0.5)          
                  
            plot((startYears[ii]+1):endYears[ii]+0.5, Epsilon, 
                  type="h", 
                  col="red", 
                  xlab="", 
                  ylab="epsilon", 
                  lwd=0.2, 
                  ylim = ylim_Epsilon,
                  xlim = xlim_Epsilon)
            par(new=TRUE)
            axis(4)
            
            ## Parameter plots                             
            ###############################################
            .tracePlotCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$mu,'mu',1)
            .histogramCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$mu,'mu',1)

            .tracePlotCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$xi,'xi',1)
            .histogramCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$xi,'xi',1)

            .tracePlotCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$chiSq,'chi',1/2)
            .histogramCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$chiSq,'chi',1/2)

            .tracePlotCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqConst,'sigmaConst',1/2)
            .histogramCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqConst,'sigmaConst',1/2)

            .tracePlotCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqNu,'sigmaNu',1/2)
            .histogramCountryPooledChains(bigDataParams_pooled, bigDataPosInfo$sigmaSqNu,'sigmaNu',1/2)

            dev.off()
        }
    }
    
    ## Plot sigmaSqW
    ###############################################
    filename <-  file.path(outDir, paste(c('sigmaSqW','pdf'),collapse = '.'))
    pdf(filename, paper = 'special', width = 6, height = 7) 
    
    filename <-  file.path(outDir, 'bigDataSigmaSqW.Rda') 
    load(filename)
           
    TempSample <- (bigDataSigmaSqW[[1]][, bigDataPosInfo$sigmaSq[posIIW[posFirst[nCountries]]:posIIW[posLast[nCountries]]]])^0.5
    mean.Sample<- apply(TempSample,2,mean)
    q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
    q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
        
    ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample))
    plot(startYears[nCountries]:endYears[nCountries], as.ts(mean.Sample),
         xlab = 'time',
         ylab = "Stoc Vol",
         type = "l",
         ylim = ylimTemp)
    lines(startYears[nCountries]:endYears[nCountries], as.ts(q05.Sample), col = 2,lty = 1,lwd=0.4)
    lines(startYears[nCountries]:endYears[nCountries], as.ts(q95.Sample), col = 2,lty = 1,lwd=0.4)   

    dev.off() 
    
    ## Plot Shocks in Separate File
    ###############################################
    filename <-  file.path(outDir, paste(c('ShocksToLRR','pdf'),collapse = '.'))
    pdf(filename, paper = 'special', width = 6, height = 7) 
    par(mfrow = c(3, 2))    

    load(file.path(outDir, 'bigDataXX.Rda'))
    
    for (ii in 1:nCountries) {           
    
        TempSampleXX  <- bigDataXX[[1]][ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
        TempSampleRho <- bigDataParams[[1]][,bigDataPosInfo$rho]
        
        mean.Sample.XX  <- apply(TempSampleXX,2,mean)
        mean.Sample.rho <- mean(TempSampleRho)
        
        Epsilon <- mean.Sample.XX[2:length(mean.Sample.XX)] - mean.Sample.XX[1:(length(mean.Sample.XX)-1)] * mean.Sample.rho
        ylim_Epsilon = c(-max(abs(Epsilon)),max(abs(Epsilon)))
        xlim_Epsilon = c((startYears[ii]+1),endYears[ii]+0.5)          
              
        plot((startYears[ii]+1):endYears[ii]+0.5, Epsilon, 
              type="h", 
              col="red", 
              xlab="", 
              ylab="epsilon",
              main = countryNames[ii], 
              lwd=0.2, 
              ylim = ylim_Epsilon,
              xlim = xlim_Epsilon)
        par(new=TRUE)
        axis(4)
    }
    dev.off()    
    
    if (controlAgg$plotPooledChains == 1){
        filename <-  file.path(outDir, paste(c('ShocksToLRR.pooledChains','pdf'),collapse = '.'))
        pdf(filename, paper = 'special', width = 6, height = 7) 
        par(mfrow = c(3, 2))    
        load(file.path(outDir, 'bigDataXX_pooled.Rda'))
        for (ii in 1:nCountries) {           
            TempSampleXX  <- bigDataXX_pooled[ , bigDataPosInfo$xx[posFirst[ii]:posLast[ii]]]
            TempSampleRho <- bigDataParams_pooled[,bigDataPosInfo$rho]
            
            mean.Sample.XX  <- apply(TempSampleXX,2,mean)
            mean.Sample.rho <- mean(TempSampleRho)
            
            Epsilon <- mean.Sample.XX[2:length(mean.Sample.XX)] - mean.Sample.XX[1:(length(mean.Sample.XX)-1)] * mean.Sample.rho
            ylim_Epsilon = c(-max(abs(Epsilon)),max(abs(Epsilon)))
            xlim_Epsilon = c((startYears[ii]+1),endYears[ii]+0.5)          
                  
            plot((startYears[ii]+1):endYears[ii]+0.5, Epsilon, 
                  type="h", 
                  col="red", 
                  xlab="", 
                  ylab="epsilon",
                  main = countryNames[ii], 
                  lwd=0.2, 
                  ylim = ylim_Epsilon,
                  xlim = xlim_Epsilon)
            par(new=TRUE)
            axis(4)
        }
        dev.off()         
    }
        
    ## Plot consumption growth and LLR component for all countries
    ##############################################################

    ## Load data
    filename <-  file.path(outDir, 'bigDataXX.Rda') 
    load(filename)
    filename <-  file.path(outDir, 'bigDataSigmaSq.Rda') 
    load(filename)
    filename <-  file.path(outDir, 'bigDataSigmaSqW.Rda') 
    load(filename)
    
    ## Initilize output file
    filename <-  file.path(outDir, paste(c('dC_XX_sigmaSq', 'pdf'),collapse = '.'))
    pdf(filename, paper = 'letter')
    par(mfrow = c(3, 2))

    ## Plot
    for (ii in 1:nCountries){
        TempSample  <- bigDataXX[[1]][ , bigDataPosInfo$xx[(posFirst[ii]+1):posLast[ii]]]
        mean.Sample <- apply(TempSample,2,mean)
        q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
        q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)            
        ylimTemp    <- range(c(mean.Sample,q05.Sample,q95.Sample,diff(cc[posFirst[ii]:posLast[ii]]))) 
        plot((startYears[ii]+1):endYears[ii], diff(as.ts(cc[posFirst[ii]:posLast[ii]])),
             main = countryNames[ii],
             xlab = 'time',
             ylab = expression(x[t]),
             type = "l",
             ylim = ylimTemp)
        lines((startYears[ii]+1):endYears[ii], as.ts(mean.Sample), col = 2)
        lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 2,lty = 1,lwd=0.4)
        lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 2,lty = 1,lwd=0.4)

        TempSample <- (bigDataSigmaSq[[1]][, bigDataPosInfo$sigmaSq[(posFirst[ii]+1):posLast[ii]]] 
                          + bigDataSigmaSqW[[1]][, bigDataPosInfo$sigmaSq[posIIW[(posFirst[ii]+1)]:posIIW[posLast[ii]]]])^0.5
        mean.Sample<- apply(TempSample,2,mean)
        q05.Sample  <- apply(TempSample,2,quantile, probs = 0.05) 
        q95.Sample  <- apply(TempSample,2,quantile, probs = 0.95)
        ylimTemp <- range(c(mean.Sample,q05.Sample,q95.Sample))
        plot((startYears[ii]+1):endYears[ii], as.ts(mean.Sample),
             xlab = 'time',
             ylab = "Stoc Vol",
             type = "l",
             ylim = ylimTemp)
        lines((startYears[ii]+1):endYears[ii], as.ts(q05.Sample), col = 2,lty = 1,lwd=0.4)
        lines((startYears[ii]+1):endYears[ii], as.ts(q95.Sample), col = 2,lty = 1,lwd=0.4)   
    }
    dev.off() 
}

## Save XXW and SigmaSqW in Excel file
################################################################################
saveWorldComponents <- function(controlAgg,bigDataPosInfo)
{
    chainToUse    <- controlAgg$chainToUse
    allData       <- readData(prefixDir)
    startYears    <- allData$startYears
    endYears      <- allData$endYears
    posIIW        <- allData$posIIW
    nPeriods      <- max(posIIW)
    allYears      <- seq(min(startYears),min(startYears)+nPeriods-1,by =1)    
  
    ## Load data
    filename <-  file.path(outDir, 'bigDataXXW.Rda') 
    load(filename)
    filename <-  file.path(outDir, 'bigDataSigmaSqW.Rda') 
    load(filename)                     

    TempSampleXXW        <- bigDataXXW[[chainToUse]][,bigDataPosInfo$xxW[1:nPeriods]]              
    mean.Sample.XXW      <- apply(TempSampleXXW,2,mean)
    q05.Sample.XXW       <- apply(TempSampleXXW,2,quantile, probs = 0.05) 
    q95.Sample.XXW       <- apply(TempSampleXXW,2,quantile, probs = 0.95)    

    TempSampleSigmaSqW   <- bigDataSigmaSqW[[chainToUse]][,bigDataPosInfo$sigmaSqW[1:nPeriods]]              
    mean.Sample.sigmaSqW <- apply(TempSampleSigmaSqW,2,mean)
    q05.Sample.sigmaSqW  <- apply(TempSampleSigmaSqW,2,quantile, probs = 0.05) 
    q95.Sample.sigmaSqW  <- apply(TempSampleSigmaSqW,2,quantile, probs = 0.95)  

    ## Save Numbers to Excel file
    xxWtable      <- cbind(allYears,mean.Sample.XXW,q05.Sample.XXW,q95.Sample.XXW)
    sigmaSqWtable <- cbind(allYears,mean.Sample.sigmaSqW,q05.Sample.sigmaSqW,q95.Sample.sigmaSqW)
    
    colnames(xxWtable)      <- c('year','xxW','xxW 0.05','xxW 0.95')
    colnames(sigmaSqWtable) <- c('year','sigmaSqW','sigmaSqW 0.05','sigmaSqW 0.95')

    # Create tables
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c('sigmaSqW',controlAgg$outputFileNamePostfix, 'csv'),collapse = '.'))         
        write.table(sigmaSqWtable, filename,row.names = T,col.names=NA, sep = ",")       

        filename   <- file.path(outDir,paste(c('xxW',controlAgg$outputFileNamePostfix, 'csv'),collapse = '.'))         
        write.table(xxWtable, filename,row.names = T,col.names=NA, sep = ",")               
    }      
}

## Save consumption Level for Select Countries
################################################################################
realConsumptionLevel <- function(controlAgg,allData,bigDataPosInfo,whichCountries)
{
    nCountries      <- length(allData$countryNames)
    Table           <- matrix(NA,120,length(whichCountries)) ## Intialize output Table
    rownames(Table) <- seq(2009,1890,-1)
    kk              <- 1   ## Set counter
    Cnames          <- c() ## Set variable for colnames
    for (ii in whichCountries)
    {
        cc                        <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        Table[1:length(cc),kk]    <- cc[length(cc):1]
        Cnames                    <- c(Cnames,allData$countryNames[ii])
        kk                        <- kk + 1
    }   
    colnames(Table) <- Cnames
    Table           <-Table
    # Create Table
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename <- file.path(outDir,
                        paste(c("C.levelPath.realData",
                                controlAgg$outputFileNamePostfix,"csv"),
                                collapse="."))         
        write.table(round(Table,4), filename,row.names = T,col.names=NA,sep = ",")       
    }
}

## Calculates SD, AC, and cross-corr of consumption growth in the data
################################################################################
realConsumptionStats <- function(controlAgg,allData,bigDataPosInfo)
{
    nCountries <- length(allData$countryNames)
    
    ## Calculate Standard Deviations and Autocorrelations for each country
    SD   <- numeric(nCountries)
    AC1  <- numeric(nCountries)
    AC2  <- numeric(nCountries)
    AC3  <- numeric(nCountries)
    AC4  <- numeric(nCountries)
    AC5  <- numeric(nCountries)
    AC10 <- numeric(nCountries)

    for (ii in 1:nCountries){
        ccCurrent   <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        SD[ii]      <- sd(diff(ccCurrent))
        AC1[ii]     <- cor(diff(ccCurrent[1:(length(ccCurrent)-1)]),
                            diff(ccCurrent[2:length(ccCurrent)]))
        AC2[ii]     <- cor(diff(ccCurrent[1:(length(ccCurrent)-2)]),
                            diff(ccCurrent[3:length(ccCurrent)]))
        AC3[ii]     <- cor(diff(ccCurrent[1:(length(ccCurrent)-3)]),
                            diff(ccCurrent[4:length(ccCurrent)]))
        AC4[ii]     <- cor(diff(ccCurrent[1:(length(ccCurrent)-4)]),
                            diff(ccCurrent[5:length(ccCurrent)]))
        AC5[ii]     <- cor(diff(ccCurrent[1:(length(ccCurrent)-5)]),
                            diff(ccCurrent[6:length(ccCurrent)]))
        AC10[ii]    <- cor(diff(ccCurrent[1:(length(ccCurrent)-10)]),
                            diff(ccCurrent[11:length(ccCurrent)]))
    } 

    # Create Table
    Table           <- cbind(SD,matrix(0,nCountries,1),AC1,AC2,AC3,AC4,AC5,AC10)
    rownames(Table) <- c(allData$countryNames)
    colnames(Table) <- c("sd","","AC1","AC2","AC3","AC4","AC5","AC10")
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename <- file.path(outDir,
                        paste(c("C.stats.realData",
                        controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
        write.table(round(Table,4), filename,row.names = T,col.names=NA, sep = ",")       
    }

    ## Calculate cross correlations between countries
    XCor1     <- matrix(0,nCountries,nCountries)
    XCor5     <- matrix(0,nCountries,nCountries)
    XCor10    <- matrix(0,nCountries,nCountries)
    for (ii in 1:nCountries)
    {
        ccCurrent <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        for (jj in ii:nCountries){
            ccOther <- allData$cData[allData$posFirst[jj]:allData$posLast[jj]]
            minLength <- min(length(ccCurrent),length(ccOther))
            startCurrent <- length(ccCurrent) - minLength + 1
            startOther <- length(ccOther) - minLength + 1
            
            XCor1[ii,jj] <- cor(diff(ccCurrent[startCurrent:length(ccCurrent)]),
                                diff(ccOther[startOther:length(ccOther)]))
            
            XCor1[jj,ii] <- XCor1[ii,jj]
            
            XCor5[ii,jj] <- cor(ccCurrent[(startCurrent+5):length(ccCurrent)] 
                                - ccCurrent[startCurrent:(length(ccCurrent)-5)],
                                ccOther[(startOther+5):length(ccOther)] 
                                - ccOther[startOther:(length(ccOther)-5)])
            
            XCor5[jj,ii]  <- XCor5[ii,jj]
            
            XCor10[ii,jj] <- cor(ccCurrent[(startCurrent+10):length(ccCurrent)] 
                                - ccCurrent[startCurrent:(length(ccCurrent)-10)],
                                ccOther[(startOther+10):length(ccOther)] 
                                - ccOther[startOther:(length(ccOther)-10)])

            XCor10[jj,ii] <- XCor10[ii,jj]
        }
    }    
    
    rownames(XCor1)  <- c(allData$countryNames)
    colnames(XCor1)  <- c(allData$countryNames)
    rownames(XCor5)  <- c(allData$countryNames)
    colnames(XCor5)  <- c(allData$countryNames)
    rownames(XCor10) <- c(allData$countryNames)
    colnames(XCor10) <- c(allData$countryNames)

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.realData.XCor1","csv"),collapse = "."))         
        write.table(round(XCor1,3), filename,row.names = T,col.names=NA, sep = ",")       
    }
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.realData.XCor5","csv"),collapse = "."))         
        write.table(round(XCor5,3), filename,row.names = T,col.names=NA, sep = ",")       
    }
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.realData.XCor10","csv"),collapse = "."))         
        write.table(round(XCor10,3), filename,row.names = T,col.names=NA, sep = ",")       
    }
    ## Create median value across all countries
    medXCor1  <- NULL
    medXCor5  <- NULL
    medXCor10 <- NULL
    for (ii in 1:(nCountries-1)) {
        for (jj in (ii+1):nCountries) {
            medXCor1  <- c(medXCor1, XCor1[ii,jj])
            medXCor5  <- c(medXCor5, XCor5[ii,jj])
            medXCor10 <- c(medXCor10, XCor10[ii,jj])
        }
    }
    medXCor1  <- median(medXCor1)
    medXCor5  <- median(medXCor5)
    medXCor10 <- median(medXCor10)
    ## Output cross correlations for median country 
    Table     <- rbind(c(medXCor1),
                       c(medXCor5),
                       c(medXCor10))    
    rownames(Table) <- c("1 year","5 year","10 year")
    colnames(Table) <- c("Q50")

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.readData.CrossCorrMed","csv"),collapse = "."))         
        write.table(round(Table,4), filename,row.names = T,col.names=NA, sep = ",")       
    }   
    # Create median value versus U.S.    
    medUSXCor1    <- median(XCor1[-which(allData$countryNames == "United.States"),which(allData$countryNames == "United.States")])
    medUSXCor5    <- median(XCor5[-which(allData$countryNames == "United.States"),which(allData$countryNames == "United.States")])
    medUSXCor10   <- median(XCor10[-which(allData$countryNames == "United.States"),which(allData$countryNames == "United.States")])

    ## Output cross correlations for median versus U.S.
    Table   <- rbind(c(medUSXCor1),
                     c(medUSXCor5),
                     c(medUSXCor10))    
    rownames(Table) <- c("1 year","5 year","10 year")
    colnames(Table) <- c("Q50")

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.realData.CrossCorrUS","csv"),collapse = "."))         
        write.table(round(Table,4), filename,row.names = T,col.names=NA, sep = ",")       
    }   
}

## Calculate standard deviation and mean of various variables in the model using  
## long simulation of the model. Also compute the freaquency of hitting the lower
## bound on volatility
################################################################################
modelStatesStats <- function(controlAgg, allData, bigDataPosInfo, 
                                ParEst, prefixDir, outDir)
{
    modelData        <- getModelData(allData)
    nCountries       <- length(allData$countryNames)      
    
    ## Define variables for standard deviations and autocorrelations
    sdDeltaCC       <- numeric(nCountries)
    sdXX            <- numeric(nCountries)
    sdEps           <- numeric(nCountries)
    sdXXW           <- numeric(nCountries)
    sdEpsW          <- numeric(nCountries)
    sdXiXXW         <- numeric(nCountries)
    sdEta           <- numeric(nCountries)
    sdEtaW          <- numeric(nCountries)
    sdXiEtaW        <- numeric(nCountries)
    sdNu            <- numeric(nCountries)
    sdSigmaSqW      <- numeric(nCountries)
    sdSigmaSqT      <- numeric(nCountries)
    meanSigmaSqW    <- numeric(nCountries)
    meanSigmaSqT    <- numeric(nCountries)    
    freqZLBSigmaSqW <- numeric(nCountries)
    freqZLBSigmaSqT <- numeric(nCountries)

    cat('Computing consumption std:',sep="\n")

    for (kk in c(1:nCountries)){
        paramsNSS         <- getNSSparameters(ParEst,bigDataPosInfo,allData,allData$countryNames[kk])
        dataNSS           <- simData(paramsNSS, controlAgg$simLengthLong, paramsNSS$cutOff)
        ## compute artificial data sd's
        sdDeltaCC[kk]       <- sd(diff(dataNSS$cc))
        sdXX[kk]            <- sd(dataNSS$XX)
        sdEps[kk]           <- sd(dataNSS$Eps)
        sdXXW[kk]           <- sd(dataNSS$XXW)
        sdEpsW[kk]          <- sd(dataNSS$EpsW)
        sdXiXXW[kk]         <- sd(paramsNSS$xi * dataNSS$XXW)
        sdEta[kk]           <- sd(dataNSS$Eta)
        sdEtaW[kk]          <- sd(dataNSS$EtaW)
        sdXiEtaW[kk]        <- sd(paramsNSS$xi * dataNSS$EtaW)
        sdNu[kk]            <- sd(diff(dataNSS$Nu))
        sdSigmaSqW[kk]      <- sd(dataNSS$SigmaSqW)
        sdSigmaSqT[kk]      <- sd(dataNSS$SigmaSqW + dataNSS$SigmaSq)
        meanSigmaSqW[kk]    <- mean(dataNSS$SigmaSqW)
        meanSigmaSqT[kk]    <- mean(dataNSS$SigmaSqW + dataNSS$SigmaSq)
        freqZLBSigmaSqW[kk] <- mean(dataNSS$SigmaSqW <= modelData$cutOff)
        freqZLBSigmaSqT[kk] <- mean(dataNSS$SigmaSqW + dataNSS$SigmaSq <= modelData$cutOff)
        cat(allData$countryNames[kk],sep="\n")
    }
    ## Create a table
    TableLong           <- cbind(sdDeltaCC,sdXX,sdEps,sdXXW,sdEpsW,sdXiXXW,sdEta,sdEtaW,sdXiEtaW,sdNu,sdSigmaSqW,sdSigmaSqT,meanSigmaSqW,meanSigmaSqT,freqZLBSigmaSqW,freqZLBSigmaSqT)
    rownames(TableLong) <- allData$countryNames
    colnames(TableLong) <- c('sdDeltaCC','sdXX','sdEps','sdXXW','sdEpsW','sdXiXXW','sdEta','sdEtaW','sdXiEtaW','sdNu','sdSigmaSqW','sdSigmaSqT','meanSigmaSqW','meanSigmaSqT','freqZLBSigmaSqW','freqZLBSigmaSqT')
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.simData","csv"),collapse = "."))         
        write.table(round(TableLong,6), filename,row.names = T,col.names=NA, sep = ",")       
    }      
}  

## Calculate SD, AC, and cross corr of consumption growth in the model 
################################################################################
modelConsumptionSDandCorr <- function(controlAgg, allData, bigDataPosInfo, 
                                        ParEst, prefixDir, outDir, MCarlo, 
                                        useEstInitials = 0)
{
    ## Calculates standard deviations, autocorrelations, and cross country correlations
    ## for simulated data using the estimated model. It draws repeated samples 
    ## of the same size as the actual data based on the posterior mean of the
    ## parameters.

    modelData    <- getModelData(allData)
    nCountries   <- length(allData$countryNames)

    ## Define variables for standard deviations and autocorrelations
    SDnoDis      <- matrix(0,nCountries,MCarlo)
    AC1NoDis     <- matrix(0,nCountries,MCarlo)
    AC2NoDis     <- matrix(0,nCountries,MCarlo)
    AC3NoDis     <- matrix(0,nCountries,MCarlo)
    AC4NoDis     <- matrix(0,nCountries,MCarlo)
    AC5NoDis     <- matrix(0,nCountries,MCarlo)
    AC10NoDis    <- matrix(0,nCountries,MCarlo)

    ## Define variables for cross country correlations
    XCor1NoDis   <- array(0,c(nCountries,nCountries,MCarlo))
    XCor5NoDis   <- array(0,c(nCountries,nCountries,MCarlo))
    XCor10NoDis  <- array(0,c(nCountries,nCountries,MCarlo))

    for (kk in 1:MCarlo){
        ## Simulates data from the model
        dataNew <- simDataSetFromEstimatedParameters(allData, modelData, controlAgg, 
                            ParEst, bigDataPosInfo, prefixDir, 
                            outDir, plotSimData = 0,useEstInitials)

        # Note that there are no disasters not by assumption but becauses there
        # are no disasters in our sample that starts in 1950                         
        cDataNoDis   <- dataNew$cc

        for (ii in 1:nCountries){
            ccNoDisastersCurrent <- cDataNoDis[allData$posFirst[ii]:allData$posLast[ii]]

            SDnoDis[ii,kk]   <- sd(diff(ccNoDisastersCurrent))
            AC1NoDis[ii,kk]  <- cor(diff(ccNoDisastersCurrent[1:(length(ccNoDisastersCurrent)-1)]),diff(ccNoDisastersCurrent[2:length(ccNoDisastersCurrent)]))
            AC2NoDis[ii,kk]  <- cor(diff(ccNoDisastersCurrent[1:(length(ccNoDisastersCurrent)-2)]),diff(ccNoDisastersCurrent[3:length(ccNoDisastersCurrent)]))
            AC3NoDis[ii,kk]  <- cor(diff(ccNoDisastersCurrent[1:(length(ccNoDisastersCurrent)-3)]),diff(ccNoDisastersCurrent[4:length(ccNoDisastersCurrent)]))
            AC4NoDis[ii,kk]  <- cor(diff(ccNoDisastersCurrent[1:(length(ccNoDisastersCurrent)-4)]),diff(ccNoDisastersCurrent[5:length(ccNoDisastersCurrent)]))
            AC5NoDis[ii,kk]  <- cor(diff(ccNoDisastersCurrent[1:(length(ccNoDisastersCurrent)-5)]),diff(ccNoDisastersCurrent[6:length(ccNoDisastersCurrent)]))
            AC10NoDis[ii,kk] <- cor(diff(ccNoDisastersCurrent[1:(length(ccNoDisastersCurrent)-10)]),diff(ccNoDisastersCurrent[11:length(ccNoDisastersCurrent)]))

            for (jj in ii:nCountries)
            {
                ccNoDisastersOther    <- cDataNoDis[allData$posFirst[jj]:allData$posLast[jj]]

                minLength             <- min(length(ccNoDisastersCurrent),length(ccNoDisastersOther))
                startCurrent          <- length(ccNoDisastersCurrent) - minLength + 1
                startOther            <- length(ccNoDisastersOther) - minLength + 1

                XCor1NoDis[ii,jj,kk]  <- cor(diff(ccNoDisastersCurrent[startCurrent:length(ccNoDisastersCurrent)]),diff(ccNoDisastersOther[startOther:length(ccNoDisastersOther)]))
                XCor1NoDis[jj,ii,kk]  <- XCor1NoDis[ii,jj,kk]

                XCor5NoDis[ii,jj,kk]  <- cor(ccNoDisastersCurrent[(startCurrent+5):length(ccNoDisastersCurrent)] - ccNoDisastersCurrent[startCurrent:(length(ccNoDisastersCurrent)-5)],
                                        ccNoDisastersOther[(startOther+5):length(ccNoDisastersOther)] - ccNoDisastersOther[startOther:(length(ccNoDisastersOther)-5)])
                XCor5NoDis[jj,ii,kk]  <- XCor5NoDis[ii,jj,kk]

                XCor10NoDis[ii,jj,kk] <- cor(ccNoDisastersCurrent[(startCurrent+10):length(ccNoDisastersCurrent)] - ccNoDisastersCurrent[startCurrent:(length(ccNoDisastersCurrent)-10)],
                                        ccNoDisastersOther[(startOther+10):length(ccNoDisastersOther)] - ccNoDisastersOther[startOther:(length(ccNoDisastersOther)-10)])
                XCor10NoDis[jj,ii,kk] <- XCor10NoDis[ii,jj,kk]
            }
        }
    }

    ## Output standard deviation and autocorrelation results without disasters by country
    Table   <- cbind(apply(SDnoDis,   1,mean),apply(SDnoDis,   1,quantile,prob = 0.50),apply(SDnoDis,   1,sd),apply(SDnoDis,   1,quantile,prob = 0.025),apply(SDnoDis,   1,quantile,prob = 0.975),matrix(0,nCountries,1),
                     apply(AC1NoDis,  1,mean),apply(AC1NoDis,  1,quantile,prob = 0.50),apply(AC1NoDis,  1,sd),apply(AC1NoDis,  1,quantile,prob = 0.025),apply(AC1NoDis,  1,quantile,prob = 0.975),matrix(0,nCountries,1),
                     apply(AC2NoDis,  1,mean),apply(AC2NoDis,  1,quantile,prob = 0.50),apply(AC2NoDis,  1,sd),apply(AC2NoDis,  1,quantile,prob = 0.025),apply(AC2NoDis,  1,quantile,prob = 0.975),matrix(0,nCountries,1),
                     apply(AC3NoDis,  1,mean),apply(AC3NoDis,  1,quantile,prob = 0.50),apply(AC3NoDis,  1,sd),apply(AC3NoDis,  1,quantile,prob = 0.025),apply(AC3NoDis,  1,quantile,prob = 0.975),matrix(0,nCountries,1),
                     apply(AC4NoDis,  1,mean),apply(AC4NoDis,  1,quantile,prob = 0.50),apply(AC4NoDis,  1,sd),apply(AC4NoDis,  1,quantile,prob = 0.025),apply(AC4NoDis,  1,quantile,prob = 0.975),matrix(0,nCountries,1),
                     apply(AC5NoDis,  1,mean),apply(AC5NoDis,  1,quantile,prob = 0.50),apply(AC5NoDis,  1,sd),apply(AC5NoDis,  1,quantile,prob = 0.025),apply(AC5NoDis,  1,quantile,prob = 0.975),matrix(0,nCountries,1),
                     apply(AC10NoDis, 1,mean),apply(AC10NoDis, 1,quantile,prob = 0.50),apply(AC10NoDis, 1,sd),apply(AC10NoDis, 1,quantile,prob = 0.025),apply(AC10NoDis, 1,quantile,prob = 0.975),matrix(0,nCountries,1))
    rownames(Table) <- c(allData$countryNames)
    colnames(Table) <- c("sd mean","sd med","sd sd","sd q025","sd q975","",
                         "AR1 mean","AR1 med","AR1 sd","AR1 q025","AR1 q975","",
                         "AR2 mean","AR2 med","AR2 sd","AR2 q025","AR2 q975","",
                         "AR3 mean","AR3 med","AR3 sd","AR3 q025","AR3 q975","",
                         "AR4 mean","AR4 med","AR4 sd","AR4 q025","AR4 q975","",
                         "AR5 mean","AR5 med","AR5 sd","AR5 q025","AR5 q975","",
                         "AR10 mean","AR10 med","AR10 sd","AR10 q025","AR10 q975","")

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.simData.Autocorr.ByCountry","csv"),collapse = "."))
        write.table(round(Table,4), filename,row.names = T,col.names=NA, sep = ",")
    }

    ## Output standard deviation and autocorrelation results without disasters median country
    TableTemp  <- cbind(apply(SDnoDis,  2,quantile,prob = 0.50),
                        apply(AC1NoDis,  2,quantile,prob = 0.50),
                        apply(AC2NoDis,  2,quantile,prob = 0.50),
                        apply(AC3NoDis,  2,quantile,prob = 0.50),
                        apply(AC4NoDis,  2,quantile,prob = 0.50),
                        apply(AC5NoDis,  2,quantile,prob = 0.50),
                        apply(AC10NoDis,  2,quantile,prob = 0.50))
    Table      <- rbind(apply(TableTemp, 2, mean),
                        apply(TableTemp, 2, sd),
                        apply(TableTemp, 2, quantile,prob = 0.50),
                        apply(TableTemp, 2, quantile,prob = 0.025),
                        apply(TableTemp, 2, quantile,prob = 0.975))
    rownames(Table) <- c("mean", "sd", "Med", "q025", "q975")
    colnames(Table) <- c("sd medCountry",
                         "AR1 medCountry",
                         "AR2 medCountry",
                         "AR3 medCountry",
                         "AR4 medCountry",
                         "AR5 medCountry",
                         "AR10 medCountry")

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.simData.Autocorr.noDis.MedCountry","csv"),collapse = "."))
        write.table(round(Table,4), filename,row.names = T,col.names=NA, sep = ",")
    }

    ## Cross correlations for median country
    XCor1NoDisMedCountry  <- apply(XCor1NoDis,  3,median)
    XCor5NoDisMedCountry  <- apply(XCor5NoDis,  3,median)
    XCor10NoDisMedCountry <- apply(XCor10NoDis, 3,median)

    ## Output cross correlations for median country
    Table <- rbind(c(median(XCor1NoDisMedCountry),  quantile(XCor1NoDisMedCountry,  prob = 0.025),quantile(XCor1NoDisMedCountry, prob = 0.975)),
                   c(median(XCor5NoDisMedCountry),  quantile(XCor5NoDisMedCountry,  prob = 0.025),quantile(XCor5NoDisMedCountry, prob = 0.975)),
                   c(median(XCor10NoDisMedCountry), quantile(XCor10NoDisMedCountry, prob = 0.025),quantile(XCor10NoDisMedCountry,prob = 0.975)))
                     
    rownames(Table) <- c("1 year","5 year","10 year")
    colnames(Table) <- c("Q50","Q025","Q975")

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.simData.CrossCorrMed","csv"),collapse = "."))
        write.table(round(Table,4), filename,row.names = T,col.names=NA, sep = ",")
    }

    ## Cross correlations versus U.S.
    XCor1NoDisMedUS  <- apply(XCor1NoDis[-which(allData$countryNames  == "United.States"),which(allData$countryNames == "United.States"),], 2,median)
    XCor5NoDisMedUS  <- apply(XCor5NoDis[-which(allData$countryNames  == "United.States"),which(allData$countryNames == "United.States"),], 2,median)
    XCor10NoDisMedUS <- apply(XCor10NoDis[-which(allData$countryNames == "United.States"),which(allData$countryNames == "United.States"),], 2,median)

    ## Output cross correlations versus U.S.
    Table <- rbind(c(median(XCor1NoDisMedUS), quantile(XCor1NoDisMedUS,prob = 0.025),quantile(XCor1NoDisMedUS,prob = 0.975)),
                   c(median(XCor5NoDisMedUS), quantile(XCor5NoDisMedUS,prob = 0.025),quantile(XCor5NoDisMedUS,prob = 0.975)),
                   c(median(XCor10NoDisMedUS), quantile(XCor10NoDisMedUS,prob = 0.025),quantile(XCor10NoDisMedUS,prob = 0.975)))
    rownames(Table) <- c("1 year","5 year","10 year")
    colnames(Table) <- c("Q50","Q025","Q975")

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.simData.CrossCorrUS","csv"),collapse = "."))
        write.table(round(Table,4), filename,row.names = T,col.names=NA, sep = ",")
    }
}

## Calculate standard deviations for consumption AND other variables using
## simulated data from our estimated model. It draws repeated samples
## of the same size as the actual data based on the posterior mean of the
## parameters.
################################################################################
modelConsumptionStats <- function(controlAgg, allData, bigDataPosInfo, ParEst, 
                                    prefixDir, outDir, MCarlo, 
                                    useEstInitials = 0,plotSimData=0)
{
    ## Calculates standard deviations, autocorrelations, and cross country correlations
    ## for simulated data from our estimated model. It draws repeated samples from our
    ## model of the same size as the actual data based on the posterior mean of the 
    ## parameters.
    modelData           <- getModelData(allData)
    nCountries          <- length(allData$countryNames)      
    ## Define variables for standard deviations and autocorrelations
    SDdeltaC            <- matrix(0,nCountries,MCarlo)
    SDnu                <- matrix(0,nCountries,MCarlo)
    SDdeltaYY           <- matrix(0,nCountries,MCarlo)
    SDeta               <- matrix(0,nCountries,MCarlo)
    SDetaW              <- matrix(0,nCountries,MCarlo)
    SDXXW               <- matrix(0,nCountries,MCarlo)
    SDXX                <- matrix(0,nCountries,MCarlo)
    meanSigmaSqW        <- matrix(0,nCountries,MCarlo)
    meanSigmaSqT        <- matrix(0,nCountries,MCarlo)
    sdSigmaSqW          <- matrix(0,nCountries,MCarlo)
    sdSigmaSqT          <- matrix(0,nCountries,MCarlo)
    freqZLBSigmaSqW     <- matrix(0,nCountries,MCarlo)
    freqZLBSigmaSqT     <- matrix(0,nCountries,MCarlo)
    for (kk in 1:MCarlo){   
        dataNew      <- simDataSetFromEstimatedParameters(allData, modelData, controlAgg, ParEst, bigDataPosInfo, prefixDir, outDir, plotSimData,useEstInitials)  ## Simulates data from the model  
        for (ii in 1:nCountries){                       
            ## delta cc
            SDdeltaC[ii,kk]          <- sd(diff(dataNew$cc[allData$posFirst[ii]:allData$posLast[ii]]))
            SDnu[ii,kk]              <- sd(dataNew$Nu[allData$posFirst[ii]:allData$posLast[ii]]) ## Nu               
            SDdeltaYY[ii,kk]         <- sd(diff(dataNew$YY[allData$posFirst[ii]:allData$posLast[ii]]))## delta YY
            SDeta[ii,kk]             <- sd(dataNew$Eta[allData$posFirst[ii]:allData$posLast[ii]])   ## Eta          
            SDetaW[ii,kk]            <- sd(dataNew$EtaW) ## EtaW           
            SDXXW[ii,kk]             <- sd(dataNew$XXW)  ## XXW        
            SDXX[ii,kk]              <- sd(dataNew$XX[allData$posFirst[ii]:allData$posLast[ii]]) ## XX         
            meanSigmaSqT[ii,kk]      <- mean(dataNew$SigmaSqW[allData$posIIW[allData$posFirst[ii]:allData$posLast[ii]]] + dataNew$SigmaSq[allData$posFirst[ii]:allData$posLast[ii]])  ## SigmaSqT        
            sdSigmaSqT[ii,kk]        <- sd(dataNew$SigmaSqW[allData$posIIW[allData$posFirst[ii]:allData$posLast[ii]]] + dataNew$SigmaSq[allData$posFirst[ii]:allData$posLast[ii]])          
            freqZLBSigmaSqT[ii,kk]   <- sum((dataNew$SigmaSqW[allData$posIIW[allData$posFirst[ii]:allData$posLast[ii]]] + dataNew$SigmaSq[allData$posFirst[ii]:allData$posLast[ii]] <= modelData$cutOff))/(allData$posLast[ii] - allData$posFirst[ii] + 1)          
            meanSigmaSqW[ii,kk]      <- mean(dataNew$SigmaSqW)  ## SigmaSqW        
            sdSigmaSqW[ii,kk]        <- sd(dataNew$SigmaSqW)          
            freqZLBSigmaSqW[ii,kk]   <- sum((dataNew$SigmaSqW[allData$posIIW[allData$posFirst[ii]:allData$posLast[ii]]] <= modelData$cutOff))/(allData$posLast[ii] - allData$posFirst[ii] + 1)          
        }      
    }
    ## Output standard deviation results without disasters by country
    Table   <- cbind(apply(SDdeltaC,  1,mean),
                     apply(SDdeltaC,  1,quantile,prob = 0.50),
                     apply(SDdeltaC,  1,sd),
                     matrix(0,nCountries,1),
                     apply(SDdeltaYY,  1,mean),
                     apply(SDdeltaYY,  1,quantile,prob = 0.50),
                     apply(SDdeltaYY,  1,sd),
                     matrix(0,nCountries,1),
                     apply(SDXX,  1,mean),
                     apply(SDXX,  1,quantile,prob = 0.50),
                     apply(SDXX,  1,sd),
                     matrix(0,nCountries,1),
                     apply(SDXXW,  1,mean),
                     apply(SDXXW,  1,quantile,prob = 0.50),
                     apply(SDXXW,  1,sd),
                     matrix(0,nCountries,1),
                     apply(SDeta,  1,mean),
                     apply(SDeta,  1,quantile,prob = 0.50),
                     apply(SDeta,  1,sd),
                     matrix(0,nCountries,1),
                     apply(SDetaW,  1,mean),
                     apply(SDetaW,  1,quantile,prob = 0.50),
                     apply(SDetaW,  1,sd),
                     matrix(0,nCountries,1),
                     apply(SDnu,  1,mean),
                     apply(SDnu,  1,quantile,prob = 0.50),
                     apply(SDnu,  1,sd),
                     matrix(0,nCountries,1),
                     sqrt(apply(meanSigmaSqT,1,mean)),
                     apply(meanSigmaSqT,1,sd)/(2*sqrt(apply(meanSigmaSqT,1,mean))),
                     apply(sdSigmaSqT,1,mean),
                     apply(freqZLBSigmaSqT,1,mean),
                     matrix(0,nCountries,1),
                     sqrt(apply(meanSigmaSqW,1,mean)),
                     apply(meanSigmaSqW,1,mean)/(2*sqrt(apply(meanSigmaSqW,1,mean))),
                     apply(sdSigmaSqW,1,mean),
                     apply(freqZLBSigmaSqW,1,mean))
    rownames(Table) <- c(allData$countryNames)
    colnames(Table) <- c("mean sd delta C","med sd delta C","sd sd delta C","",
                         "mean sd delta YY","med sd delta YY","sd sd delta YY","",
                         "mean sd XX","med sd XX","sd sd XX","",
                         "mean sd XXW","med sd XXW","sd sd XXW","",
                         "mean sd Eta","med sd Eta","sd sd Eta","",
                         "mean sd EtaW","med sd EtaW","sd sd EtaW","",
                         "mean sd Nu","med sd Nu","sd sd Nu","",
                         "sqrt mean mean SimgaSqT","sd mean SimgaSqT/(2 *sqrt mean mean SimgaSqT)","mean sd SimgaSqT","freqZLBSigmaSqT","",
                         "sqrt mean mean SimgaSqW","sd mean SimgaSqW/(2 *sqrt mean mean SimgaSqW)","mean sd SimgaSqW","freqZLBSigmaSqW")

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("C.stats.simData.noDis.ByCountry","csv"),collapse = "."))         
        write.table(round(Table,6), filename,row.names = T,col.names=NA, sep = ",")       
    } 
}

## Variance ratios for consumption growth

# Computes VR for consumption growth (does not adjust for bias)
################################################################################
.VRfunc <- function(cc,horizons)
{

    VRnum  <- numeric(length(horizons))
    VR     <- numeric(length(horizons))
    
    nPeriods  <- length(cc)

    for (kk in 1:length(horizons)){
        VRnum[kk] = 1/(horizons[kk]) * var(diff(cc,horizons[kk]))
    }
    VRden = var(diff(cc,1)) 
    VR <- VRnum/VRden
    
    return(VR = VR)
}

## Computes VR for consumption growth (adjusts for bias)
################################################################################
.VRfunc2 <- function(cc,horizons)
{

    VR     <- numeric(length(horizons))   
    nPeriods  <- length(cc)

    for (kk in 1:length(horizons)){
        VR[kk]    <- var(diff(cc,horizons[kk]))/var(diff(cc,1)) * nPeriods/(nPeriods - horizons[kk] + 1)
    }
    
    return(list(VR = VR))
}

## Read data on real per capita output 
################################################################################
.readOutputData <- function(prefixDir) 
{
    filename   <- file.path(prefixDir, 'sandbox/v11/ydata20100225.txt')
    dataAll    <- read.table(filename, header = T, sep = "\t")
    dataAll    <- as.list(dataAll)
    nCountries <- length(dataAll)
    attr(dataAll,"names")[1] <- "year"
    dataYears  <- as.matrix(dataAll[[1]])
    
    ## Create matrix with all consumption data
    yData <- dataAll[[2]]
    for (ii in 3:nCountries)
        yData <- cbind(yData,dataAll[[ii]])
    attr(yData,"dimnames") <- NULL
    ## Create an index. Output equals 100 for al countries in 2006
    for (ii in 1:dim(yData)[[2]]){
        yData[,ii] <- yData[,ii]/yData[dim(yData)[[1]],ii] * 100
    }
    yData <- log(yData)
    
    ## Cut off years at the beginning for which no data is observed
    ii <- 0
    while (ii == 0) {
        tempInd <- is.na(yData[1,])
        if (sum(tempInd) < length(tempInd)) {
            ii <- 1
        } else {
            yData     <- yData[-1,]
            dataYears <- as.matrix(dataYears[-1,])
        }
    }
    firstYear <- dataYears[1,1]
    
    ## Save country names
    countryNames   <- attr(dataAll,"names")
    countryNames   <- countryNames[2:nCountries]

    ## Blank out data not to be used due to later gap in data
    whichAustria <- which(countryNames == "Austria")
    whichYears <- 1:(1946-firstYear+1)
    yData[whichYears,whichAustria] <- NA  # Austria before WWII
    whichEgypt   <- which(countryNames == "Egypt")
    whichYears <- 1:(1936-firstYear+1)
    yData[whichYears,whichEgypt] <- NA  # Egypt before 1937
    whichMalaysia <- which(countryNames == "Malaysia")
    whichYears <- 1:(1946-firstYear+1)
    yData[whichYears,whichMalaysia] <- NA  # Malaysia before WWII
    whichNetherlands <- which(countryNames == "Netherlands")
    whichYears <- 1:(1813-firstYear+1)
    yData[whichYears,whichNetherlands] <- NA  # Netherlands before Napoleonic Wars
    whichNewZealand <- which(countryNames == "New.Zealand")
    whichYears <- 1:(1946-firstYear+1)
    yData[whichYears,whichNewZealand] <- NA  # New Zealand before WWII
    whichSingapore <- which(countryNames == "Singapore")
    whichYears <- 1:(1947-firstYear+1)
    yData[whichYears,whichSingapore] <- NA  # Singapore before WWII
    whichUnitedStates <- which(countryNames == "United.States")
    whichYears <- 1:(1868-firstYear+1)
    yData[whichYears,whichUnitedStates] <- NA  # United States before Civil War

    ## Cut countries not included in Barro and Ursua (BPEA 2008)
    countriesToExclude <- c("Austria","Colombia","Egypt","Greece","Iceland","New.Zealand","India",
                            "Indonesia","Malaysia","Philippines","Singapore","S..Africa",
                            "Sri.Lanka","Turkey","Uruguay","Venezuela")

    #########################################################################################################
    #########################################################################################################
    countriesToExclude <- c(countriesToExclude,"Argentina","Brazil","Chile","Mexico","Peru","Japan","Korea","Taiwan")
    #########################################################################################################
    #########################################################################################################
    excludedCountries  <- numeric(length(countryNames))
    for (ii in 1:length(countriesToExclude)) {
        excludedCountries <- excludedCountries + (countryNames == countriesToExclude[ii])
    }
    excludedCountries <- which(as.logical(excludedCountries))
    yData <- yData[,-excludedCountries]
    countryNames <- countryNames[-excludedCountries]
            
    ## Create data on starting year and ending year for each country
    startYears <- matrix(NA,length(countryNames),1)
    for (ii in 1:length(countryNames)) {
        tempInd <- is.na(yData[,ii])
        tempInd <- sum(tempInd)
        startYears[ii,1] <- firstYear + tempInd
    }
    endYears <- matrix(2006,length(countryNames),1)    
    
    ## Temporarily reduce data (old data set)
    tempReduce <- 0
    if (tempReduce) {
                countriesToInclude <- c("Argentina", "Australia", "Brazil", "Canada", "Chile", 
                                "Finland", "France", "Italy", "Japan", "Norway", "Peru", 
                                "Spain", "Sweden", "Taiwan", "United.Kingdom", "United.States")
        includedCountries  <- numeric(length(countryNames))
        for (ii in 1:length(countriesToInclude)) {
            includedCountries <- includedCountries + (countryNames == countriesToInclude[ii])
        }
        includedCountries <- which(as.logical(includedCountries))
        yData             <- yData[,includedCountries]
        yearsSubset       <- (1901 - firstYear + 1):(length(dataYears))
        yData             <- yData[yearsSubset,]
        countryNames      <- countryNames[includedCountries]
        dataYears         <- as.matrix(dataYears[yearsSubset,])
        #startYears        <- as.matrix(startYears[includedCountries,])
        startYears        <- c(rep(1901,length(includedCountries)))
        endYears          <- endYears[includedCountries,]
    }
    
    ## Temporarily reduce data set (1890 start date)
    tempReduce2 <- 1
    if (tempReduce2) {
        whichYears <- 1:(1889-firstYear+1)
        yData[whichYears,] <- NA
        tempInd <- which(startYears < 1890)
        startYears[tempInd] <- 1890
    }
    
    ## Make data into long vector (and all other variables also vectors)
    nYears        <- dim(yData)[1]
    nCountries    <- dim(yData)[2]
    TempInd       <- !is.na(yData)
    whichTempInd  <- which(TempInd)
    sumTempInd    <- sum(TempInd)    
    statePosInfo  <- matrix(NA,nYears,nCountries)
    statePosInfo[whichTempInd] <- 1:sumTempInd
    posFirst      <- numeric(nCountries)
    posLast       <- statePosInfo[nYears,]
    for (ii in 1:nCountries) posFirst[ii] <- min(statePosInfo[!is.na(statePosInfo[ ,ii]),ii])
    yData         <- yData[whichTempInd]
    dataYears     <- as.numeric(dataYears)
    startYears    <- as.numeric(startYears)
    endYears      <- as.numeric(endYears)
    
    ## Create data on important intermediate years for each country
    pos1946    <- c(rep(NA,nCountries))
    pos1973    <- c(rep(NA,nCountries))
    for (ii in 1:nCountries) {
        pos1946[ii] <- posFirst[ii] + 1946 - startYears[ii]
        pos1973[ii] <- posFirst[ii] + 1973 - startYears[ii]
    }

    ## Create data on IIW position for each element of II
    posIIW     <- numeric(length(yData))
    for (ii in 1:nCountries) {
        posIIW[posFirst[ii]:posLast[ii]] <- seq(startYears[ii] - min(startYears) + 1, 
                                                endYears[ii] - min(startYears) + 1, by = 1)
    }
    
    ## Create dummy for WWI and WWII
    IIWar     <- numeric(length(yData))
    
    pos1914    <- c(rep(NA,nCountries))
    pos1921    <- c(rep(NA,nCountries))
    pos1940    <- c(rep(NA,nCountries))
    pos1949    <- c(rep(NA,nCountries))    

    for (ii in 1:nCountries) {
        pos1914[ii] <- posFirst[ii] + 1914 - startYears[ii]
        pos1921[ii] <- posFirst[ii] + 1921 - startYears[ii]
        pos1940[ii] <- posFirst[ii] + 1940 - startYears[ii]
        pos1949[ii] <- posFirst[ii] + 1949 - startYears[ii]        
    }      
    
    for (ii in 1:nCountries) {
        IIWar[c(pos1914[ii]:pos1921[ii],pos1940[ii]:pos1949[ii])] <- 1
    }
        
    return(list(dataAll = dataAll, yData = yData, countryNames = countryNames,
                dataYears = dataYears, startYears = startYears, endYears = endYears,
                posFirst = posFirst, posLast = posLast,
                pos1946 = pos1946, pos1973 = pos1973, posIIW = posIIW,
                IIWar = IIWar))
}

## Compute variance ratios for all horizons up to KK-year horizon for
## consumption data
################################################################################
VRrealCmany <- function(controlAgg,allData, bigDataPosInfo,KK)
{

    ## Compute empirical variance ratios for all countries     
    ###########################################################
    nCountries <- length(allData$countryNames)

    VR         <- matrix(0,KK,nCountries)
    VRnoDis    <- matrix(0,KK,nCountries)
    
    for (ii in 1:nCountries)
    {
        # Consumption data
        ccDis            <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]

        # Consumption data without disasters
        if (controlAgg$usePooledChains == 0){
            ccNoDisasters   <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        }                        
        if (controlAgg$usePooledChains == 1){        
                ccNoDisasters   <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        }        
        VR[,ii]      <- .VRfunc(ccDis,1:KK)
        VRnoDis[,ii] <- .VRfunc(ccNoDisasters,1:KK)
    }
    ## Variance Ratios with disasters
    filename <-  file.path(outDir, paste(c('VR.C.realData',controlAgg$outputFileNamePostfix, 'eps'),collapse = '.'))
    postscript(filename, paper = "letter")
    ylim <- range(c(0,VR))     
    matplot(VR,
             xlab = "",
             ylab = expression(VR[k]),
             axes = F,
             type = "o",
             col  = 1:24,
             ylim = ylim,
             pch = 1:nCountries,
             cex.lab=1.5)
    title(main = 'Variance Ratios', cex.main = 2)
    axis(1, cex.axis=2)
    axis(2, cex.axis=2)       
    
    legend(1, ylim[2], 
           allData$countryNames, 
           cex=0.8, 
           col=1:nCountries, 
           pch=1:nCountries,
           ncol = 2) 
    dev.off()
    
    ## Variance Ratios without Disaster
    filename <-  file.path(outDir,paste(c('VR.C.realDataNoDis',controlAgg$outputFileNamePostfix, 'eps'),collapse = '.'))
    postscript(filename, paper = "letter")
    ylim <- range(c(0,VRnoDis))     
    matplot(VRnoDis,
             xlab = "",
             ylab = expression(VR[k]),
             axes = F,
             type = "o",
             col  = 1:24,
             ylim = ylim,
             pch = 1:nCountries,
             cex.lab=1.5)
    title(main = 'Variance Ratios (no disasters)', cex.main = 2)
    axis(1, cex.axis=2)
    axis(2, cex.axis=2)       
    
    legend(1, ylim[2], 
           allData$countryNames, 
           cex=0.8, 
           col=1:nCountries, 
           pch=1:nCountries,
           ncol = 2) 
    dev.off()
    
    ## Save Numbers to Excel file
    colnames(VR)      <- allData$countryNames
    colnames(VRnoDis) <- allData$countryNames
    VR      <- VR
    VRnoDis <- VRnoDis

    # Create tables
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c('VR.C.realData',controlAgg$outputFileNamePostfix, 'csv'),collapse = '.'))         
        write.table(round(VR,3), filename,row.names = T,col.names=NA, sep = ",")       

        filename   <- file.path(outDir,paste(c('VR.C.realDataNoDis',controlAgg$outputFileNamePostfix, 'csv'),collapse = '.'))         
        write.table(round(VRnoDis,3), filename,row.names = T,col.names=NA, sep = ",")               
    }                    
}

## Create VR for consumption growth for all countries at KK-year horizon
## using many simulated data samples (Monte Carlo)
################################################################################
VRsimMonteCarloConsumption <- function(controlAgg, allData, bigDataPosInfo, 
                                        ParEst, prefixDir, outDir, KK, MCarlo)
{
    modelData <- getModelData(allData)

    nCountries <- length(allData$countryNames)    
    VRnoDis    <- matrix(0,nCountries,MCarlo)    

    for (kk in 1:MCarlo){   
        dataNew <- simDataSetFromEstimatedParameters(allData, modelData, 
                        controlAgg, ParEst, bigDataPosInfo, prefixDir, 
                        outDir, plotSimData = 0)    

        cData   <- dataNew$cc       
        for (ii in 1:nCountries){                       
            # Consumption data
            cc <- cData[allData$posFirst[ii]:allData$posLast[ii]]  

            ## Variance Ratios          
            VRnoDis[ii,kk] <- .VRfunc(cc,KK)                                   
        }
    }
    
    # Results for Median Country
    TableNoDisTemp <- apply(VRnoDis,2,median)    
    
    TableNoDis <- cbind(mean(TableNoDisTemp),
                        median(TableNoDisTemp),
                        quantile(TableNoDisTemp,prob=0.025),
                        quantile(TableNoDisTemp,prob=0.975))
    
    
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        TableXLS           <- TableNoDis
        rownames(TableXLS) <- 'Median Country'
        colnames(TableXLS) <- c(paste(c('VR(',KK,')(mean)'),collapse = ""),
                                paste(c('VR(',KK,')(q50)'),collapse = ""),
                                paste(c('VR(',KK,')(q025)'),collapse = ""),
                                paste(c('VR(',KK,')(q975)'),collapse = ""))

        filename <- file.path(outDir,
                        paste(c('VR.C.simData.MonteCarlo',KK,'MedCountry',"csv"),
                                collapse = "."))         

        write.table(round(TableXLS,3), filename,row.names = T,col.names=NA, sep = ",")                
    }                    
    
    # Results By Country
    TableNoDis <- cbind(apply(VRnoDis,1,mean),
                    apply(VRnoDis,1,quantile,prob = 0.50),
                    apply(VRnoDis,1,quantile,prob = 0.025),
                    apply(VRnoDis,1,quantile,prob = 0.975))    
    
    # Saves variance ratios table without disasters #
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        TableXLS           <- TableNoDis
        rownames(TableXLS) <- allData$countryNames
        colnames(TableXLS) <- c(paste(c('VR(',KK,')(mean)'),collapse = ""),
                                paste(c('VR(',KK,')(q50)'),collapse = ""),
                                paste(c('VR(',KK,')(q025)'),collapse = ""),
                                paste(c('VR(',KK,')(q975)'),collapse = ""))

        filename <- file.path(outDir,
                     paste(c('VR.C.simData.noDis.MonteCarlo',KK,
                        'ByCountry',"csv"),collapse = "."))         
        write.table(round(TableXLS,3), filename,row.names = T,col.names=NA, sep = ",")                
    }                                   
}

## Create series of MEAN of estimated stochastic volatility
## for ALL countries
################################################################################
summarySV <- function(controlAgg,bigDataPosInfo)
{
    allData       <- readData(prefixDir)
    modelData     <- getModelData(allData)

    countryNames <- allData$countryNames
    nCountries   <- length(countryNames)    
    posFirst     <- allData$posFirst
    posLast      <- allData$posLast
    startYears   <- allData$startYears
    endYears     <- allData$endYears
    posIIW       <- allData$posIIW
    maxPeriod    <- max(endYears - startYears) + 1
    
    Table           <- matrix(NA,maxPeriod,nCountries)  # Initialize Tables
    rownames(Table) <- c(min(startYears):max(endYears))
    colnames(Table) <- countryNames

    if (controlAgg$usePooledChains == 0){
        filename <-  file.path(outDir, 'bigDataSigmaSq.Rda') 
        load(filename)            
        filename <-  file.path(outDir, 'bigDataSigmaSqW.Rda') 
        load(filename)            
        filename <-  file.path(outDir, 'bigDataParams.Rda') 
        load(filename)            

        for (ii in 1:nCountries){
            TempSample  <- bigDataSigmaSq[[controlAgg$chainToUse]][,bigDataPosInfo$sigmaSq[posFirst[ii]:posLast[ii]]]
            TempSampleW <- bigDataSigmaSqW[[controlAgg$chainToUse]][,bigDataPosInfo$sigmaSqW[posIIW[posFirst[ii]]:posIIW[posLast[ii]]]]
            if (sum(TempSample + TempSampleW<0)){
                print(allData$countryNames[ii])
                for (tt in 1:120){
                    if (sum(TempSample[,tt] + TempSampleW[,tt]<0)){                    
                        print(tt)
                        browser()
                    }
                }
            }  else {        
                TempSampleG  <- sqrt(TempSample + TempSampleW)
                mean.Sample <- apply(TempSampleG,2,mean)                    
                Table[(startYears[ii] - min(startYears) + 1):(endYears[ii] - min(startYears) + 1),ii] <- mean.Sample
            }
        }

    }

    if (controlAgg$usePooledChains == 1){
        filename <-  file.path(outDir, 'bigDataSigmaSq_pooled.Rda') 
        load(filename)            
        filename <-  file.path(outDir, 'bigDataSigmaSqW_pooled.Rda') 
        load(filename)            
        filename <-  file.path(outDir, 'bigDataParams_pooled.Rda') 
        load(filename)            
        
        for (ii in 1:nCountries){
            TempSample  <- bigDataSigmaSq_pooled[, bigDataPosInfo$sigmaSq[posFirst[ii]:posLast[ii]]]
            TempSampleW <- bigDataSigmaSqW_pooled[, bigDataPosInfo$sigmaSqW[posIIW[posFirst[ii]]:posIIW[posLast[ii]]]]            
            TempSample  <- sqrt(TempSample + TempSampleW)
            mean.Sample <- apply(TempSample,2,mean)        
            Table[(startYears[ii] - min(startYears) + 1):(endYears[ii] - min(startYears) + 1),ii] <- mean.Sample
        }
    }
        
    if (controlAgg$TableFormat$TeX == 1){
        filename <- file.path(outDir,paste(c('SV.realData',controlAgg$outputFileNamePostFix),collapse = "."))
        latex.table(Table,
                    file        = filename, 
                    rowlabel    = "", 
                    caption     = "Square root of the mean of the estimated stochastic volatility.",
                    dec         = 3, 
                    label       = '')                    
    }
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c('SV.realData',controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
        write.table(round(Table,5), filename,row.names = T,col.names=NA, sep = ",")      
    }     
}

## Create series of MEAN and QUANTILES of estimated stochastic volatility for
## SOME countries
################################################################################
summarySVsomeCountries <- function(controlAgg,bigDataPosInfo,whichCountries)
{
    allData       <- readData(prefixDir)
    modelData     <- getModelData(allData)    

    countryNames <- allData$countryNames
    nCountries   <- length(countryNames)    
    posFirst     <- allData$posFirst
    posLast      <- allData$posLast
    startYears   <- allData$startYears
    endYears     <- allData$endYears
    posIIW       <- allData$posIIW
    maxPeriod    <- max(endYears - startYears) + 1
    
    # Initialize Tables
    Table <- vector("list", length(whichCountries))

    if (controlAgg$usePooledChains == 0){
        filename <-  file.path(outDir, 'bigDataSigmaSq.Rda') 
        load(filename)            
        filename <-  file.path(outDir, 'bigDataSigmaSqW.Rda') 
        load(filename)            
        filename <-  file.path(outDir, 'bigDataParams.Rda') 
        load(filename)            

        for (ii in 1:length(whichCountries)){
            Table[[ii]] <- matrix(NA,nrow = maxPeriod,ncol = 8)

            TempSample  <- bigDataSigmaSq[[controlAgg$chainToUse]][, bigDataPosInfo$sigmaSq[posFirst[whichCountries[ii]]:posLast[whichCountries[ii]]]]
            TempSampleW <- bigDataSigmaSqW[[controlAgg$chainToUse]][, bigDataPosInfo$sigmaSqW[posIIW[posFirst[whichCountries[ii]]]:posIIW[posLast[whichCountries[ii]]]]]
            TempSample <- sqrt(TempSample + TempSampleW)
    
            mean.Sample <- apply(TempSample,2,mean)
            q025.Sample <- apply(TempSample,2,quantile,probs = 0.025)
            q05.Sample  <- apply(TempSample,2,quantile,probs = 0.05)
            q165.Sample <- apply(TempSample,2,quantile,probs = 0.165)
            q50.Sample  <- apply(TempSample,2,quantile,probs = 0.5)
            q765.Sample <- apply(TempSample,2,quantile,probs = 0.765)
            q95.Sample  <- apply(TempSample,2,quantile,probs = 0.95)
            q975.Sample <- apply(TempSample,2,quantile,probs = 0.975)
            
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),1] <- mean.Sample
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),2] <- q025.Sample        
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),3] <- q05.Sample                
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),4] <- q165.Sample                        
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),5] <- q50.Sample
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),6] <- q765.Sample
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),7] <- q95.Sample                
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),8] <- q975.Sample
            
            colnames(Table[[ii]]) <- c('mean','q025', 'q05', 'q165', 'q50', 'q765', 'q95', 'q975')     
            rownames(Table[[ii]]) <- c(min(startYears):max(endYears))           
        }

    }
    if (controlAgg$usePooledChains == 1){
        filename <-  file.path(outDir, 'bigDataSigmaSq_pooled.Rda') 
        load(filename)            
        filename <-  file.path(outDir, 'bigDataSigmaSqW_pooled.Rda') 
        load(filename)            
        filename <-  file.path(outDir, 'bigDataParams_pooled.Rda') 
        load(filename)            
        
        for (ii in 1:length(whichCountries)){
            Table[[ii]] <- matrix(NA,nrow = maxPeriod,ncol = 8)
 

            TempSample  <- bigDataSigmaSq_pooled[, bigDataPosInfo$sigmaSq[posFirst[whichCountries[ii]]:posLast[whichCountries[ii]]]]
            TempSampleW <- bigDataSigmaSqW_pooled[, bigDataPosInfo$sigmaSqW[posIIW[posFirst[whichCountries[ii]]]:posIIW[posLast[whichCountries[ii]]]]]            
            TempSample  <- sqrt(TempSample + TempSampleW)
                        
            mean.Sample <- apply(TempSample,2,mean)
            q025.Sample <- apply(TempSample,2,quantile,probs = 0.025)
            q05.Sample  <- apply(TempSample,2,quantile,probs = 0.05)
            q165.Sample <- apply(TempSample,2,quantile,probs = 0.165)
            q50.Sample  <- apply(TempSample,2,quantile,probs = 0.5)
            q765.Sample <- apply(TempSample,2,quantile,probs = 0.765)
            q95.Sample  <- apply(TempSample,2,quantile,probs = 0.95)
            q975.Sample <- apply(TempSample,2,quantile,probs = 0.975)
            
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),1] <- mean.Sample
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),2] <- q025.Sample        
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),3] <- q05.Sample                
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),4] <- q165.Sample                        
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),5] <- q50.Sample
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),6] <- q765.Sample
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),7] <- q95.Sample                
            Table[[ii]][(startYears[whichCountries[ii]] - min(startYears) + 1):(endYears[whichCountries[ii]] - min(startYears) + 1),8] <- q975.Sample
            
            colnames(Table[[ii]]) <- c('mean','q025', 'q05', 'q165', 'q50', 'q765', 'q95', 'q975')     
            rownames(Table[[ii]]) <- c(min(startYears):max(endYears))           
        }
    }
  
    # Create Tables of Variance Ratios for Variance Ratios
    if (controlAgg$TableFormat$TeX == 1){
        for (ii in 1:length(whichCountries)){
            filename <- file.path(outDir,paste(c('SV.realData',countryNames[whichCountries[ii]],controlAgg$outputFileNamePostfix),collapse = "."))
            latex.table(Table[[ii]],
                        file        = filename, 
                        rowlabel    = "", 
                        caption     = "Square root of the mean of the estimated stochastic volatility",
                        dec         = 5, 
                        label       = '')                                     
        }
    }
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        for (ii in 1:length(whichCountries)){    
            filename   <- file.path(outDir,paste(c('SV.realData',countryNames[whichCountries[ii]],controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
            write.table(round(Table[[ii]],5), filename,row.names = T,col.names=NA, sep = ",")                         
        }
    }     
}

## Compute and saves quantiles of the world SV
################################################################################
summarySVWorld <- function(controlAgg,bigDataPosInfo)
{
    allData       <- readData(prefixDir)
    modelData     <- getModelData(allData)    
    startYears   <- allData$startYears
    endYears     <- allData$endYears

    nPeriod    <- max(allData$posIIW)
    
    # Initialize Tables
    Table <- vector("list", 1)

    if (controlAgg$usePooledChains == 0){
        filename <-  file.path(outDir, 'bigDataSigmaSqW.Rda') 
        load(filename)            

        Table[[1]] <- matrix(NA,nrow = nPeriod,ncol = 8)

        TempSample  <- bigDataSigmaSqW[[controlAgg$chainToUse]][,bigDataPosInfo$sigmaSqW]^0.5

        mean.Sample <- apply(TempSample,2,mean)
        q025.Sample <- apply(TempSample,2,quantile,probs = 0.025)
        q05.Sample  <- apply(TempSample,2,quantile,probs = 0.05)
        q165.Sample <- apply(TempSample,2,quantile,probs = 0.165)
        q50.Sample  <- apply(TempSample,2,quantile,probs = 0.5)
        q765.Sample <- apply(TempSample,2,quantile,probs = 0.765)
        q95.Sample  <- apply(TempSample,2,quantile,probs = 0.95)
        q975.Sample <- apply(TempSample,2,quantile,probs = 0.975)

        Table[[1]][1:nPeriod,1] <- mean.Sample
        Table[[1]][1:nPeriod,2] <- q025.Sample        
        Table[[1]][1:nPeriod,3] <- q05.Sample                
        Table[[1]][1:nPeriod,4] <- q165.Sample                        
        Table[[1]][1:nPeriod,5] <- q50.Sample
        Table[[1]][1:nPeriod,6] <- q765.Sample
        Table[[1]][1:nPeriod,7] <- q95.Sample                
        Table[[1]][1:nPeriod,8] <- q975.Sample

        colnames(Table[[1]]) <- c('mean','q025', 'q05', 'q165', 'q50', 'q765', 'q95', 'q975')     
        rownames(Table[[1]]) <- c(min(startYears):max(endYears))           

    }
    if (controlAgg$usePooledChains == 1){
        filename <-  file.path(outDir, 'bigDataSigmaSqW_pooled.Rda') 
        load(filename)            
        
        Table[[1]] <- matrix(NA,nrow = nPeriod,ncol = 8)

        TempSample  <- bigDataSigmaSqW_pooled[, bigDataPosInfo$sigmaSqW]^0.5

        mean.Sample <- apply(TempSample,2,mean)
        q025.Sample <- apply(TempSample,2,quantile,probs = 0.025)
        q05.Sample  <- apply(TempSample,2,quantile,probs = 0.05)
        q165.Sample <- apply(TempSample,2,quantile,probs = 0.165)
        q50.Sample  <- apply(TempSample,2,quantile,probs = 0.5)
        q765.Sample <- apply(TempSample,2,quantile,probs = 0.765)
        q95.Sample  <- apply(TempSample,2,quantile,probs = 0.95)
        q975.Sample <- apply(TempSample,2,quantile,probs = 0.975)

        Table[[1]][1:nPeriod,1] <- mean.Sample
        Table[[1]][1:nPeriod,2] <- q025.Sample        
        Table[[1]][1:nPeriod,3] <- q05.Sample                
        Table[[1]][1:nPeriod,4] <- q165.Sample                        
        Table[[1]][1:nPeriod,5] <- q50.Sample
        Table[[1]][1:nPeriod,6] <- q765.Sample
        Table[[1]][1:nPeriod,7] <- q95.Sample                
        Table[[1]][1:nPeriod,8] <- q975.Sample

        colnames(Table[[1]]) <- c('mean','q025', 'q05', 'q165', 'q50', 'q765', 'q95', 'q975')     
        rownames(Table[[1]]) <- c(min(startYears):max(endYears))           
    }
  
    # Create Tables of Variance Ratios for Variance Ratios
    if (controlAgg$TableFormat$TeX == 1){
        filename <- file.path(outDir,paste(c('SV.realData','World',controlAgg$outputFileNamePostfix),collapse = "."))
        latex.table(Table[[1]],
                    file        = filename, 
                    rowlabel    = "", 
                    caption     = "Square root of the mean of the estimated stochastic volatility",
                    dec         = 5, 
                    label       = '')                                     
    }
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c('SV.realData','World',controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
        write.table(round(Table[[1]],5), filename,row.names = T,col.names=NA, sep = ",")                         
    }     
}

## Computes variance ratios of stochastic volatility (without adjusting for bias)
################################################################################
.VRfunc4 <-     function(uu,horizons)
{

    VR     <- numeric(length(horizons))
    VRstd  <- numeric(length(horizons))
    
    nPeriods  <- length(uu)

    for (kk in 1:length(horizons)){
        VR[kk]    <- 1/(horizons[kk]) * var(apply(embed(uu,horizons[kk]), 1, sum))/var(uu)
    }
    
    return(VR = VR)
}

## Compute variance ratios of stochastic volatility using real data at 
## horizon KK
################################################################################
VRofSVreal <- function(controlAgg,allData, bigDataPosInfo, KK)
{

    nCountries <- length(allData$countryNames)
    ## Initialize
    VR         <- matrix(0,nCountries,1)
    VRnoDis    <- matrix(0,nCountries,1)    

    for (ii in 1:nCountries){       
        ## Data with Disasters
        #######################################################################
        ccDis     <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]       
        ar.est    <- ar(diff(ccDis),aic = FALSE,order.max = 5)## Estimate AR(p) process and extract residuals
        reg.resid <- abs(ar.est$resid)
        reg.resid <- reg.resid[!is.na(reg.resid)]
        VR[ii,]   <- .VRfunc4(reg.resid,KK)


        ## Data without Disasters
        #######################################################################
        
        # Consumption data
        if (controlAgg$usePooledChains == 0){
            ccNoDisasters   <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        }    
        if (controlAgg$usePooledChains == 1){
            ccNoDisasters   <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        }        
        
        ar.est       <- ar(diff(ccNoDisasters),aic = FALSE,order.max = 5) ## Estimate AR(p) process and extract residuals
        reg.resid    <- abs(ar.est$resid)
        reg.resid    <- reg.resid[!is.na(reg.resid)]
        VRnoDis[ii,] <- .VRfunc4(reg.resid,KK)                             ## Variance Ratios
    }
    
    Table <- cbind(VR,VRnoDis)
     
    if (controlAgg$TableFormat$TeX == 1){
        TableTeX        <- Table    
        rownames(TableTeX) <- allData$countryNames
        colnames(TableTeX) <- c('$VR_{dis}^{15}$','$VR_{no dis}^{15}$')

        filename <- file.path(outDir,paste(c("VR.SV.realData",controlAgg$outputFileNamePostfix),collapse = "."))
        print(filename)
        latex.table(TableTeX,
                    file        = filename, 
                    rowlabel    = "", 
                    caption     = "The Variance ratios times horizon length (i.e. $VR_k \\times k$) for (1) stochastic volatility with disasters, (2) for stochastic volatility without disasters.",
                    dec         = 3, 
                    label       = '')
    }
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        TableXLS           <- Table
        rownames(TableXLS) <- allData$countryNames
        colnames(TableXLS) <- c('VR(dis,15)','VR(no dis,15)')

        filename   <- file.path(outDir,paste(c("VR.SV.realData",KK,controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
        write.table(round(TableXLS,3), filename,row.names = T,col.names=NA, sep = ",")                
    }                    
}

## Compute variance ratios of stochastic volatility using real data for
## horizons upto KK
################################################################################
VRofSVrealMany <- function(controlAgg,allData, bigDataPosInfo, KK)
{
    nCountries <- length(allData$countryNames)
    ## Initialize
    VR         <- matrix(0,KK,nCountries)
    VRnoDis    <- matrix(0,KK,nCountries)    

    for (ii in 1:nCountries){       
        ## Data with Disasters
        #######################################################################
        ccDis     <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]       
        ar.est    <- ar(diff(ccDis),aic = FALSE,order.max = 5)## Estimate AR(p) process and extract residuals
        reg.resid <- abs(ar.est$resid)
        reg.resid <- reg.resid[!is.na(reg.resid)]
        for (kk in 1:KK){
            VR[kk,ii]   <- .VRfunc4(reg.resid,kk)
        }

        ## Data without Disasters
        #######################################################################
        
        # Consumption data
        if (controlAgg$usePooledChains == 0){
            ccNoDisasters   <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        }    
        if (controlAgg$usePooledChains == 1){
            ccNoDisasters   <- allData$cData[allData$posFirst[ii]:allData$posLast[ii]]
        }        
        
        ar.est       <- ar(diff(ccNoDisasters),aic = FALSE,order.max = 5) ## Estimate AR(p) process and extract residuals
        reg.resid    <- abs(ar.est$resid)
        reg.resid    <- reg.resid[!is.na(reg.resid)]
        for (kk in 1:KK){
            VRnoDis[kk,ii] <- .VRfunc4(reg.resid,kk)                       ## Variance Ratios
        }
    }
     
    colnames(VR)      <- allData$countryNames
    rownames(VR)      <- c(1:KK)
    
    colnames(VRnoDis) <- allData$countryNames
    rownames(VRnoDis) <- c(1:KK)
         
    if (controlAgg$TableFormat$TeX == 1){
        filename <- file.path(outDir,paste(c("VR.SV.realData",controlAgg$outputFileNamePostfix),collapse = "."))
        print(filename)
        latex.table(VR,
                    file        = filename, 
                    rowlabel    = "", 
                    caption     = "The Variance ratios for stochastic volatility with disasters, (2) for stochastic volatility without disasters.",
                    dec         = 3, 
                    label       = '')

        filename <- file.path(outDir,paste(c("VR.SV.realData.noDis",controlAgg$outputFileNamePostfix),collapse = "."))
        print(filename)
        latex.table(VRnoDis,
                    file        = filename, 
                    rowlabel    = "", 
                    caption     = "The Variance ratios for stochastic volatility with disasters, (2) for stochastic volatility without disasters.",
                    dec         = 3, 
                    label       = '')
    }
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c("VR.SV.realData.Dis",controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
        write.table(round(VR,4), filename,row.names = T,col.names=NA, sep = ",")                

        filename   <- file.path(outDir,paste(c("VR.SV.realData.noDis",controlAgg$outputFileNamePostfix,"csv"),collapse = "."))         
        write.table(round(VRnoDis,4), filename,row.names = T,col.names=NA, sep = ",")                
    }                    
}

## Create distribution of VR of SV using simulated data at horizon KK
################################################################################
VRofSVsimDataMonteCarlo <- function(controlAgg, allData, bigDataPosInfo, ParEst, 
                                    prefixDir, outDir, KK, MCarlo)
{
    modelData    <- getModelData(allData)
    
    nCountries <- length(allData$countryNames)    
    VRdis      <- matrix(0,nCountries,MCarlo)
    VRnoDis    <- matrix(0,nCountries,MCarlo)    

    for (kk in 1:MCarlo){   
        dataNew <- simDataSetFromEstimatedParameters(allData, modelData, 
                            controlAgg, ParEst, bigDataPosInfo, prefixDir, 
                            outDir, plotSimData = 0)    
        cData   <- dataNew$cc
        for (ii in 1:nCountries){                       
            # Consumption data
            cc        <- cData[allData$posFirst[ii]:allData$posLast[ii]] 

            ## Estimate AR(p) process and extract residuals
            ar.est    <- ar(diff(cc),aic = FALSE,order.max = 5)          
            reg.resid <- abs(ar.est$resid)
            reg.resid <- reg.resid[!is.na(reg.resid)]

            ## Variance Ratios
            VRdis[ii,kk] <- .VRfunc4(reg.resid,KK)                           
        }
    }
 
     # Results for Median Country
     TableDisTemp <- apply(VRdis,  2,median)  
     TableDis <- cbind(mean(TableDisTemp),
                        median(TableDisTemp),
                        quantile(TableDisTemp,prob=0.025),
                        quantile(TableDisTemp,prob=0.975))
      
     if (controlAgg$TableFormat$MicrosoftExcel == 1){
         TableXLS           <- TableDis
         rownames(TableXLS) <- 'Median Country'
         colnames(TableXLS) <- c(paste(c('VR(',KK,')(mean)'),collapse = ""),
                                 paste(c('VR(',KK,')(q50)'),collapse = ""),
                                 paste(c('VR(',KK,')(q025)'),collapse = ""),
                                 paste(c('VR(',KK,')(q975)'),collapse = ""))
 
         filename   <- file.path(outDir,paste(c('VR.SV.simData.MonteCarlo',KK,'MedCountry',"csv"),collapse = "."))         
         write.table(round(TableXLS,3), filename,row.names = T,col.names=NA, sep = ",")                
     }                    
     
    # Results By Country
    TableDis   <- cbind(apply(VRdis,1,mean),
                        apply(VRdis,1,quantile,prob = 0.50),
                        apply(VRdis,1,quantile,prob = 0.025),
                        apply(VRdis,1,quantile,prob = 0.975))
    
    # Saves variance ratios table with disasters
    #################################################
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        TableXLS           <- TableDis
        rownames(TableXLS) <- allData$countryNames
        colnames(TableXLS) <- c(paste(c('VR(',KK,')(mean)'),collapse = ""),
                                paste(c('VR(',KK,')(q50)'),collapse = ""),
                                paste(c('VR(',KK,')(q025)'),collapse = ""),
                                paste(c('VR(',KK,')(q975)'),collapse = ""))

        filename <- file.path(outDir,paste(c('VR.SV.simData.MonteCarlo',
                                KK,'ByCountry',"csv"),collapse = "."))         
        write.table(round(TableXLS,3), filename,row.names = T,col.names=NA, sep = ",")                
    }                    
}

################################################################################
#           Functions ... are required to compare SV across BY/BKY/NSS models  #
################################################################################

## Parameters are taken from Bansal, Yaron, 
## "Risks for the Long Run: A Potential Resolution of 
## Asset Pricing Puzzles", The Journal of Finance, Vol. 59, 
## No. 4 (Aug., 2004), pp. 1481-1509
################################################################################
getBYparameters <- function()
{
    rho         <- 0.979
    chi         <- 1/0.044
    sigmaConst  <- 0.0078*0.044
    sigmaOmega  <- 0.23*10^(-5)*0.044^2
    gammma      <- 0.987
    mu          <- 0.0015
    cutOff      <- 10^(-10) # Chosen arbitrary because they don't report this number in the paper.

    return(list(rho        = rho,
                chi        = chi,
                sigmaConst = sigmaConst,
                sigmaOmega = sigmaOmega,
                gammma     = gammma,
                mu         = mu,
                cutOff     = cutOff))
}

## Parameters are taken from Bansal, Kiku, Yaron, 
## "An Empirical Evaluation of the Long-Run Risks Model 
## for Asset Price", Critical Finance Review, 2012, 1: 183–221
################################################################################
getBKYparameters <- function()
{
    rho         <- 0.975
    chi         <- 1/0.038
    sigmaConst  <- 0.0072*0.038
    sigmaOmega  <- 0.28*10^(-5)*0.038^2
    gammma      <- 0.999
    mu          <- 0.0015
    cutOff      <- 10^(-10) # Chosen arbitrary because they don't report this number in the paper.

    return(list(rho        = rho,
                chi        = chi,
                sigmaConst = sigmaConst,
                sigmaOmega = sigmaOmega,
                gammma     = gammma,
                mu         = mu,
                cutOff     = cutOff))
}

## Take ParEst variables and saves it in different format
################################################################################
getNSSparameters <- function(ParEst,bigDataPosInfo,allData,countryToUse)
{
    iiCountry          <- which(allData$countryNames == countryToUse) 
    modelData          <- getModelData(allData) # Reads model data. In particular, cutOff parameter values

    # Global Parameters    
    chiW        <- sqrt(ParEst[bigDataPosInfo$chiSqW])
    sigmaConstW <- sqrt(ParEst[bigDataPosInfo$sigmaSqConstW])
    sigmaOmegaW <- sqrt(ParEst[bigDataPosInfo$sigmaSqOmegaW])
    rhoW        <- ParEst[bigDataPosInfo$rhoW]
    lambdaW     <- ParEst[bigDataPosInfo$lambdaW]    

    # Local processes parameters
    sigmaOmega  <- sqrt(ParEst[bigDataPosInfo$sigmaSqOmega])    
    rho         <- ParEst[bigDataPosInfo$rho]
    gammma      <- ParEst[bigDataPosInfo$gammma]
    lambda      <- ParEst[bigDataPosInfo$lambda]        
    
    # Country specific parameters
    chi         <- sqrt(ParEst[bigDataPosInfo$chiSq][iiCountry])
    sigmaConst  <- sqrt(ParEst[bigDataPosInfo$sigmaSqConst][iiCountry])    
    xi          <- ParEst[bigDataPosInfo$xi][iiCountry]
    mu          <- ParEst[bigDataPosInfo$mu][iiCountry]
    sigmaNu     <- sqrt(ParEst[bigDataPosInfo$sigmaSqNu][iiCountry])

    cutOff      <- modelData$cutOff 

    return(list(chiW        = chiW,
                sigmaConstW = sigmaConstW,
                sigmaOmegaW = sigmaOmegaW,
                rhoW        = rhoW,
                lambdaW     = lambdaW,
                sigmaOmega  = sigmaOmega,
                rho         = rho,
                gammma      = gammma,
                lambda      = lambda,
                chi         = chi, 
                sigmaConst  = sigmaConst, 
                xi          = xi, 
                mu          = mu, 
                sigmaNu     = sigmaNu,
                cutOff      = cutOff))
}

## Take initsEst variables and saves it in different format
################################################################################
getNSSinitials <- function(initsEst,bigDataPosInfo,allData,countryToUse)
{
    iiCountry          <- which(allData$countryNames == countryToUse) 

    return(list(XX0       = initsEst$XX0[iiCountry],
                XXW0      = initsEst$XXW0,
                SigmaSq0  = initsEst$SigmaSq0[iiCountry],
                SigmaSqW0 = initsEst$SigmaSqW0))
}

## Computes "stochastic volatility" as absolute value of residuals from AR(5) 
## regression of consmption growth
################################################################################
proxySV <- function(cc)
{
    ar.est    <- ar(diff(cc),aic = FALSE,order.max = 5)        
    reg.resid <- abs(ar.est$resid)
    SV        <- abs(reg.resid[!is.na(reg.resid)])

    cat('R-squared = ',ar.est$var.pred,'\n')
    return(SV)
}

saveSVstats <- function(svBY,svBKY,svNSS,controlAgg)
{
    ## compute mean
    meanSVBY  <- mean(svBY) 
    meanSVBKY <- mean(svBKY)
    meanSVNSS <- mean(svNSS)

    ## compute variance
    sdSVBY    <- sd(svBY)     
    sdSVBKY   <- sd(svBKY)
    sdSVNSS   <- sd(svNSS)

    ## compute q05
    q05svBY   <- quantile(svBY,  prob = 0.05)
    q05svBKY  <- quantile(svBKY, prob = 0.05)
    q05svNSS  <- quantile(svNSS, prob = 0.05)

    ## compute q50    
    q50svBY   <- quantile(svBY,  prob = 0.5)
    q50svBKY  <- quantile(svBKY, prob = 0.5)
    q50svNSS  <- quantile(svNSS, prob = 0.5)

    ## compute q95
    q95svBY   <- quantile(svBY,  prob = 0.95)
    q95svBKY  <- quantile(svBKY, prob = 0.95)
    q95svNSS  <- quantile(svNSS, prob = 0.95)

    ## Create csv table    
    Table     <- rbind(c(meanSVBY,meanSVBKY,meanSVNSS),
                       c(sdSVBY,sdSVBKY,sdSVNSS),
                       c(q05svBY,q05svBKY,q05svNSS),
                       c(q50svBY,q50svBKY,q50svNSS),
                       c(q95svBY,q95svBKY,q95svNSS))

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        TableXLS           <- Table
        rownames(TableXLS) <- c('mean','sd','q05','q50','q95')
        colnames(TableXLS) <- c('BY','BKY','NSS')

        filename   <- file.path(outDir,paste(c('StatsSVmeasure1',"csv"),collapse = "."))         
        write.table(round(TableXLS,3), filename,row.names = T,col.names=NA, sep = ",")                
    }     
} 

saveConsumptionStats <- function(ccBY,ccBKY,ccNSS,controlAgg)
{
    ## compute mean
    meanccBY  <- mean(diff(ccBY))
    meanccBKY <- mean(diff(ccBKY))
    meanccNSS <- mean(diff(ccNSS))

    ## compute variance
    sdccBY    <- sd(diff(ccBY))     
    sdccBKY   <- sd(diff(ccBKY))
    sdccNSS   <- sd(diff(ccNSS))

    ## Create csv table    
    Table     <- rbind(c(meanccBY,meanccBKY,meanccNSS),
                       c(sdccBY,sdccBKY,sdccNSS))

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        TableXLS           <- Table
        rownames(TableXLS) <- c('mean','sd')
        colnames(TableXLS) <- c('BY','BKY','NSS')

        filename   <- file.path(outDir,paste(c('consumptionStats',"csv"),collapse = "."))         
        write.table(round(TableXLS,3), filename,row.names = T,col.names=NA, sep = ",")                
    }     
}    

saveSVdensities <- function(svBY,svBKY,svNSS,controlAgg)   
{
    densitySVBY  <- density(svBY)
    densitySVBKY <- density(svBKY)
    densitySVNSS <- density(svNSS)

    filename <-  file.path(outDir, paste(c('SVdistributions', 'pdf'),collapse = '.'))
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(1, 1))

    ylim <- range(c(0,densitySVBY$y,densitySVNSS$y,densitySVBKY$y))     
    xlim <- range(c(0,densitySVBY$x,densitySVNSS$x,densitySVBKY$x))     
    plot(densitySVBY,
             xlab    = "",
             ylab    = "",
             #axes    = F,
             col     = 1,
             type    = "l",
             ylim    = ylim,
             xlim    = xlim,
             pch     = 1,
             cex.lab = 1.5,
             main    = "density")
    lines(densitySVBKY, col = 2)             
    lines(densitySVNSS, col = 3)             
    #title(main = 'density', cex.main = 2)
    
    
    legend(xlim[2]*0.8, ylim[2], 
           c('BY','BKY','NSS'), 
           cex  = 0.8, 
           col  = 1:3, 
           lty  = 1,
           #pch  = c(2,3,3),
           ncol = 1) 
    dev.off()    
}

saveXXfractions <- function(dataBY,dataBKY,dataNSS)
{
    BYvarFrac      <- var(diff(dataBY$ccNoXXAnnual))/var(diff(dataBY$ccAnnual))
    BKYvarFrac     <- var(diff(dataBKY$ccNoXXAnnual))/var(diff(dataBKY$ccAnnual))
    NSSvarFrac     <- var(diff(dataNSS$ccNoXX))/var(diff(dataNSS$cc))
    TableVarFrac   <- matrix(c(BYvarFrac,BKYvarFrac,NSSvarFrac))

    BYsdFrac       <- sd(diff(dataBY$ccNoXXAnnual))/sd(diff(dataBY$ccAnnual))
    BKYsdFrac      <- sd(diff(dataBKY$ccNoXXAnnual))/sd(diff(dataBKY$ccAnnual))
    NSSsdFrac      <- sd(diff(dataNSS$ccNoXX))/sd(diff(dataNSS$cc))    
    TableSdFrac    <- matrix(c(BYsdFrac,BKYsdFrac,NSSsdFrac))
    
    TableLRR       <- matrix(c(sd(diff(dataBY$ccAnnual)),sd(diff(dataBKY$ccAnnual)),sd(diff(dataNSS$cc))))
    TableNoLRR     <- matrix(c(sd(diff(dataBY$ccNoXXAnnual)),sd(diff(dataBKY$ccNoXXAnnual)),sd(diff(dataNSS$ccNoXX))))

    Table          <- cbind(TableVarFrac,TableSdFrac,TableLRR,TableNoLRR)

    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        TableXLS           <- Table
        rownames(TableXLS) <- c('BY','BKY','NSS')
        colnames(TableXLS) <- c('var(deltaCnoXX)/var(deltaC)','sd(deltaCnoXX)/sd(deltaC)','sd delta c (LRR)','sd delta c (no LRR)')

        filename   <- file.path(outDir,paste(c('fractionXX',"csv"),collapse = "."))         
        write.table(round(TableXLS,3), filename,row.names = T,col.names=NA, sep = ",")                
    }    
}

## Compare amount of LRR across our results, BY,  and BKY
################################################################################
compareLRRinNSSvsBY <- function(controlAgg,ParEst,bigDataPosInfo,allData,
                                countryToUse = "United.States")
{
    ## read parameter values  
    paramsBY             <- getBYparameters()
    paramsBKY            <- getBKYparameters()
    paramsNSS            <- getNSSparameters(ParEst,bigDataPosInfo,allData,countryToUse)
    ## generate data  
    dataBY               <- simDataBY(paramsBY,   controlAgg$simLengthCompareLRR*12, paramsBY$cutOff)
    dataBKY              <- simDataBY(paramsBKY,  controlAgg$simLengthCompareLRR*12, paramsBKY$cutOff)
    dataNSS              <- simData(paramsNSS,    controlAgg$simLengthCompareLRR, paramsNSS$cutOff)
    ## transform monthly to annual data
    dataBY$ccAnnual      <- monthlyToAnnualData(dataBY$cc)
    dataBY$ccNoXXAnnual  <- monthlyToAnnualData(dataBY$ccNoXX)
    dataBKY$ccAnnual     <- monthlyToAnnualData(dataBKY$cc)
    dataBKY$ccNoXXAnnual <- monthlyToAnnualData(dataBKY$ccNoXX)
    ## compute various consumption statistics
    saveConsumptionStats(dataBY$ccAnnual,dataBKY$ccAnnual,dataNSS$cc,controlAgg)
    ## calculate SV proxy by estimating ar(5) regression of the consumption growth rate
    svBY                 <- proxySV(dataBY$ccAnnual)
    svBKY                <- proxySV(dataBKY$ccAnnual)
    svNSS                <- proxySV(dataNSS$cc)
    ## create output
    saveSVstats(svBY,svBKY,svNSS,controlAgg)     # function saves simple stats of SV processes
    saveSVdensities(svBY,svBKY,svNSS,controlAgg) # function saves SV for different models
    saveXXfractions(dataBY,dataBKY,dataNSS)      # function saves the fraction of consumption growth variance due to XX LRR
}

## Compare SV using quantile approach
################################################################################
compareSVinNSSvsBY <- function(controlAgg,ParEst,bigDataPosInfo,allData,
                                countryToUse = "United.States")
{
    ## read parameter values  
    paramsBY             <- getBYparameters()
    paramsBKY            <- getBKYparameters()
    paramsNSS            <- getNSSparameters(ParEst,bigDataPosInfo,allData,countryToUse)
    ## Generate consumption data with fixed stoachastic volatility
    dataBY               <- simDataBYFixedSV(paramsBY,   controlAgg$simLengthCompareLRR*12, paramsBY$cutOff)
    dataBKY              <- simDataBYFixedSV(paramsBKY,  controlAgg$simLengthCompareLRR*12, paramsBKY$cutOff)
    dataNSS              <- simDataFixedSV(paramsNSS,    controlAgg$simLengthCompareLRR,    paramsNSS$cutOff)
    ## Transform monthly BY and BKY data to annual data
    dataBY$cc05Annual    <- monthlyToAnnualData(dataBY$cc05)
    dataBY$cc50Annual    <- monthlyToAnnualData(dataBY$cc50)    
    dataBY$cc95Annual    <- monthlyToAnnualData(dataBY$cc95)    
    dataBKY$cc05Annual   <- monthlyToAnnualData(dataBKY$cc05)
    dataBKY$cc50Annual   <- monthlyToAnnualData(dataBKY$cc50)    
    dataBKY$cc95Annual   <- monthlyToAnnualData(dataBKY$cc95)        
    ## Compute std and save results as a CSV table
    TableBY              <- matrix(c(sd(diff(dataBY$cc05Annual)),sd(diff(dataBY$cc50Annual)),sd(diff(dataBY$cc95Annual))),1,3)
    TableBKY             <- matrix(c(sd(diff(dataBKY$cc05Annual)),sd(diff(dataBKY$cc50Annual)),sd(diff(dataBKY$cc95Annual))),1,3)
    TableNSS             <- matrix(c(sd(diff(dataNSS$cc05)),sd(diff(dataNSS$cc50)),sd(diff(dataNSS$cc95))),1,3)
    Table                <- rbind(TableBY,TableBKY,TableNSS)
    colnames(Table)      <- c('sd delta c (SV05)','sd delta c (SV50)','sd delta c (SV95)')
    rownames(Table)      <- c('BY','BKY','NSS')
    if (controlAgg$TableFormat$MicrosoftExcel == 1){
        filename   <- file.path(outDir,paste(c('StatsSVmeasure2',"csv"),collapse = "."))         
        write.table(round(Table,5), filename,row.names = T,col.names=NA, sep = ",")                
    } 
}

################################################################################
## This part of the file collects useful functions that are used throught     ##
################################################################################
rep.row<-function(x,n)
{
   matrix(rep(x,each=n),nrow=n)
}

rep.col<-function(x,n)
{
   matrix(rep(x,each=n), ncol=n, byrow=TRUE)
}

jarque.bera.test2 <- function(x,na.rm) 
{
    if (NCOL(x) > 1) 
        stop("x is not a vector or univariate time series")
    if (na.rm){
        x <- x[!is.na(x)]
    } 
        
    DNAME <- deparse(substitute(x))
    n <- length(x)
    m1 <- sum(x)/n
    m2 <- sum((x - m1)^2)/n
    m3 <- sum((x - m1)^3)/n
    m4 <- sum((x - m1)^4)/n
    b1 <- (m3/m2^(3/2))^2
    b2 <- (m4/m2^2)
    STATISTIC <- n * b1/6 + n * (b2 - 3)^2/24
    names(STATISTIC) <- "X-squared"
    PARAMETER <- 2
    names(PARAMETER) <- "df"
    PVAL <- 1 - pchisq(STATISTIC, df = 2)
    METHOD <- "Jarque Bera Test"
    structure(list(statistic = STATISTIC, parameter = PARAMETER, 
        p.value = PVAL, method = METHOD, data.name = DNAME), 
        class = "htest")
}

monthlyToAnnualData <- function(cc)
{
    if (length(cc) %% 12){
        cat('Number of months is not multiplicative of 12!\n')
    } else {
        ccAnnual <- log(colSums(matrix(exp(cc), 12)))
    }
}