################################################################
## This program estimates the Long-Run Risk model on consumption 
## data in RJags                                            
##                                                          
## Emi Nakamura, Dmitriy Sergeyev, Jon Steinsson (July 2016)                                         
################################################################

rm(list = ls())
gc()
source('funcs.R')

# Define variables with directory information (second function in funcs.R)
dirInfo     <- getDirInfo()
outDir      <- dirInfo$outDir
prefixDir   <- dirInfo$prefixDir

# Define controlVar (see first function in funcs.R)

controlVar  <- getControlVar()

# Import data to be used for estimation
if (controlVar$useRealData) {
    allData <- readData(prefixDir) # function in funcs.R
} else {
    allData <- getSimDataSetFromEstimatedParameters(prefixDir, outDir)  # function in funcs.R     
}
save(allData, file = file.path(outDir, paste(c('allData','Rda'),collapse = '.')))

# Load data to be inputed into bugs
modelData    <- getModelData(allData)

# Load variables that contain parameter names and information 
# about their position in the parameter vector
NamesNPosInfo<- getNamesNPosInfo(allData)
parameters   <- NamesNPosInfo$UnobsNames
UnobsPosInfo <- NamesNPosInfo$UnobsPosInfo

timer        <- list(bugs = 0, save = 0, plot = 0, temp = 0, total = 0)
timer$total  <- proc.time()[3]

if (controlVar$noRun != 1) {
    # The model is estimated in batches. Each batch is one iteration of this for-loop
    for (ii in controlVar$nFirstRun:(controlVar$nFirstRun+controlVar$NRuns-1)) {
        # If the first batch has nFirstRun==1, program allows the the user to specify 
        # whether to draw new initial values or to get initial values from a saved file
        # For all subsequent batches, the initial values will be gotten from a file.
        # This file is created below and contains the last values from the preceeding batch.
        if (ii == 1) {
            ## Get Initial Values
            if (controlVar$newInit == 1) {
                initialValues <- getNewInitialValues(allData, UnobsPosInfo, controlVar) # function defined in funcs.R
            } else {
                initialValues <- getSavedInitialValues(outDir) # function defined in funcs.R
                
                # To avoid crashing because gammmabeta = 1 in initialValues
                if (initialValues[[1]]$gammmabeta == 1) initialValues[[1]]$gammmabeta <- 0.999
                if (length(initialValues) > 1) {
                    if (initialValues[[2]]$gammmabeta == 1) initialValues[[2]]$gammmabeta <- 0.999
                }
            }
        } else {
            initialValues <- getSavedInitialValues(outDir) # function defined in funcs.R

            # To avoid crashing because gammmabeta = 1 in initialValues
            if (initialValues[[1]]$gammmabeta == 1) initialValues[[1]]$gammmabeta <- 0.999
            if (length(initialValues) > 1) {
                if (initialValues[[2]]$gammmabeta == 1) initialValues[[2]]$gammmabeta <- 0.999
            }
        }
        
        ## Run JAGS
        timer$temp <- proc.time()[3]
        jags <- jags.model(file     = 'lrrmodel.bug',
                           data     =  modelData,
                           inits    = initialValues,
                           n.chains = length(initialValues), 
                           n.adapt  = controlVar$Nadapt) 
        load.module("dic")
        bugsSim <- coda.samples(model          = jags,
                                variable.names = parameters,
                                n.iter         = controlVar$Niter, 
                                thin           = controlVar$NinitThin)


        gc() #gc(verbose = TRUE)
        timer$bugs <- proc.time()[3] - timer$temp
        timer$temp <- proc.time()[3]
    
        ## Save Output
        tempPrint <- paste(c(controlVar$priorType,controlVar$nOfRun),collapse = '')
        filename  <-  file.path(outDir, paste(c('bugsSimSave',tempPrint,ii,'Rda'),collapse = '.'))
        save(bugsSim, file = filename)
        
        ## Save Initial Values
        bugsSimInit <- saveLastValues(UnobsPosInfo,ii, filename)
        
        #rm(bugsSim)
        timer$save <- proc.time()[3] - timer$temp
        cat('timer$bugs = ',timer$bugs,' timer$save = ',timer$save,'\n')
        gc() #gc(verbose = TRUE) #gc(verbose = TRUE, reset = TRUE)
        
        cat('\n')
    }
}