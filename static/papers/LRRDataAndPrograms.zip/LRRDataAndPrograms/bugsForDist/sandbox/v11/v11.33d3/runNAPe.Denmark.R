## This program calculates asset prices for our LRR model
##
## Emi Nakamura, Dmitriy Sergeyev Jon Steinsson, (March 2015)
#####################################################################
rm(list = ls())
print(gc(reset=TRUE))

# Set global variables
GlobalCountryName           <- "Denmark"
GlobalCountryToSimulateData <- "Denmark"
GlobalBaseCountry           <- "Denmark"
GlobalCreateNextStateFiles  <- 1
GlobalCreateWeightFiles     <- 1
GlobalUpdatePDivs           <- 1
GlobalUseSnow               <- 1
GlobalNewInitPDivs          <- 1
GlobalSimulatePrices        <- 1
GlobalComputeBHSelasticities<- 0
GlobalCreatePredictability  <- 0

APresultsFileName <- paste("APresults",GlobalCountryName,"txt",sep=".")
funcsNAPeFileName <- paste("funcsNAPe",GlobalCountryName,"R",sep=".")

source('funcs.R')
source('funcsAgg.R')
source('funcsNAPe.R')

dirInfo        <- getDirInfo()
outDir         <- dirInfo$outDir
prefixDir      <- dirInfo$prefixDir
allData        <- readData(prefixDir)
controlVar     <- getControlVar()
controlAgg     <- getControlAgg()
controlVarNAPi <- getControlVarNAPi(allData, controlAgg)
NamesNPosInfo  <- getNamesNPosInfo(allData)
parameters     <- NamesNPosInfo$UnobsNames
UnobsPosInfo   <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo <- getBigDataPosInfo(UnobsPosInfo)

## Creates folders for nextState and weights
if (controlVarNAPi$createFolders == 1){
  createFolders(allData,controlVarNAPi,outDir)
}

################################################################################
##                            Compute AP                                      ##
################################################################################
if (controlVarNAPi$updatePDivs){
  ParEst <- getParEstimates(bigDataPosInfo,
                            controlAgg$usePooledChains,
                            controlAgg$chainToUse)

  sink(file.path(outDir, APresultsFileName))
  sink()

  for (nn in c(1:length(controlVarNAPi$countryToComputePrice))){
    countryToUse <- controlVarNAPi$countryToComputePrice[nn]

    ## Starts sinking (saving screen output) to file
    sink(file.path(outDir, APresultsFileName),append = TRUE)
    cat('runNAPe.R\n')
    cat('---------------------------------------------------------\n')
    cat(allData$countryNames[controlVarNAPi$countryToComputePrice[nn]],'\n')
    cat('---------------------------------------------------------\n')
    cat('\n')
    cat('PARAMETERS\n')
    cat('\n')
    cat('rhoU:        ',controlVarNAPi$rhoU,'\n')
    cat('gammaU:      ',controlVarNAPi$gammaU,'\n')
    cat('psiU:        ',controlVarNAPi$psiU,'\n')
    cat('thetaU:      ',controlVarNAPi$thetaU,'\n')
    cat('\n')
    cat('Mu:          ',ParEst[bigDataPosInfo$mu][countryToUse],'\n')
    cat('sigmaEpsW:   ',sqrt(ParEst[bigDataPosInfo$sigmaSqConstW]),'\n')
    cat('sigmaEps:    ',sqrt(ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]),'\n')
    cat('chi:         ',sqrt(ParEst[bigDataPosInfo$chiSq][countryToUse]),'\n')
    cat('sigmaOmega:  ',sqrt(ParEst[bigDataPosInfo$sigmaSqOmega]),'\n')
    cat('sigmaOmegaW: ',sqrt(ParEst[bigDataPosInfo$sigmaSqOmegaW]),'\n')
    cat('\n')
    cat('gammma:      ',ParEst[bigDataPosInfo$gammma],'\n')
    cat('rho:         ',ParEst[bigDataPosInfo$rho],'\n')
    cat('rhoW:        ',ParEst[bigDataPosInfo$rhoW],'\n')
    cat('lambda:      ',ParEst[bigDataPosInfo$lambda],'\n')
    cat('lambdaW:     ',ParEst[bigDataPosInfo$lambdaW],'\n')
    cat('\n')
    cat('Country:     ',allData$countryNames[countryToUse],'\n')
    cat('\n')
    cat('\n')
    cat('nCoarseStateGrid:     ',controlVarNAPi$nCoarseStateGrid,'\n')
    cat('nCoarseStateNu:       ',controlVarNAPi$nCoarseStateGridNu,'\n')
    cat('nCoarseStateXX:       ',controlVarNAPi$nCoarseStateGridXX,'\n')
    cat('nCoarseStateXXW:      ',controlVarNAPi$nCoarseStateGridXXW,'\n')
    cat('nCoarseStateSigmaSq:  ',controlVarNAPi$nCoarseStateGridSigmaSq,'\n')
    cat('nCoarseStateSigmaSqW: ',controlVarNAPi$nCoarseStateGridSigmaSqW,'\n')
    cat('\n')
    cat('nFineStateGrid:       ',controlVarNAPi$nFineStateGrid,'\n')
    cat('nFineStateNu:         ',controlVarNAPi$nFineStateGridNu,'\n')
    cat('nFineStateXX:         ',controlVarNAPi$nFineStateGridXX,'\n')
    cat('nFineStateXXW:        ',controlVarNAPi$nFineStateGridXXW,'\n')
    cat('nFineStateSigmaSq:    ',controlVarNAPi$nFineStateGridSigmaSq,'\n')
    cat('nFineStateSigmaSqW:   ',controlVarNAPi$nFineStateGridSigmaSqW,'\n')
    cat('\n')

    ## Finish sinking
    sink()

    ## Compute asset prices
    PDivs <- getPDivs_EZW(allData,
                          countryToUse,
                          controlVarNAPi,
                          ParEst,
                          bigDataPosInfo,
                          printStuff = 1)

    outputEZW  <- list(allData        = allData,
                       controlVarNAPi = controlVarNAPi,
                       ParEst         = ParEst,
                       bigDataPosInfo = bigDataPosInfo,
                       PDivs          = PDivs,
                       countryToUse   = countryToUse)
    save(outputEZW,
          file=file.path(outDir,
                paste('outputEZW.',
                    allData$countryNames[countryToUse],'.Rda',sep="")))
  }
}
################################################################################
## Compute stats based on APs: returns stats, predictability, etc.            ##
################################################################################
if (controlVarNAPi$simulatePrices == 1){
  set.seed(-100000)

  ## Simulate Global Components
  countryToUse <- controlVarNAPi$countryToSimulateData[1]

  filename <- file.path(outDir,
                paste('outputEZW.',
                  allData$countryNames[countryToUse],'.Rda',sep=""))
  load(filename)

  ParEst          <- outputEZW$ParEst
  bigDataPosInfo  <- outputEZW$bigDataPosInfo
  simGlobalOutput <- simulateGlobal_EZW(controlVarNAPi,
                                      ParEst,
                                      bigDataPosInfo,
                                      controlVarNAPi$nSim,
                                      controlVarNAPi$nSimBurnin,
                                      printStuff = 1)

  save(simGlobalOutput, file = file.path(outDir,'simGlobalOutput.Rda'))

  ## Simulate Country Data + Calculate Returns + Calculate Predictability

  ## Initialize summaryStatsBigFile file
  initializeSummaryStatsBigFile(allData,controlVarNAPi)
  for (nn in 1:length(controlVarNAPi$countryToSimulateData)){
      ## `Load prices
      countryToUse    <- controlVarNAPi$countryToSimulateData[nn]

      filename <- file.path(outDir,
                    paste('outputEZW.',
                      allData$countryNames[countryToUse],'.Rda',sep=""))
      load(filename)

      PDivs           <- outputEZW$PDivs
      ParEst          <- outputEZW$ParEst
      bigDataPosInfo  <- outputEZW$bigDataPosInfo

      ## Simulate consumption and AP data
      simOutput       <- simulateModel_EZW(countryToUse,
                                          controlVarNAPi,
                                          ParEst,
                                          bigDataPosInfo,
                                          simGlobalOutput,
                                          controlVarNAPi$nSim,
                                          controlVarNAPi$nSimBurnin,
                                          printStuff = 1)
      simOutputOnGrid <- putSimOutputOnStateGrid(countryToUse,
                                                  simOutput,
                                                  controlVarNAPi,
                                                  ParEst,
                                                  bigDataPosInfo)
      ## Save
      filename <- file.path(outDir,
                    paste('simOutput.',
                          allData$countryNames[countryToUse],
                          '.Rda',
                          sep=""))
      save(simOutput, file = filename)

      filename <- file.path(outDir,
                    paste('simOutputOnGrid.',
                          allData$countryNames[countryToUse],
                          '.Rda',
                          sep=""))
      save(simOutputOnGrid, file = filename)

      ## Compute returns and other stats for a particular country
      returnsEZW      <- calcReturns(countryToUse,
                                      simOutput,
                                      simOutputOnGrid,
                                      PDivs,
                                      controlVarNAPi,
                                      ParEst,
                                      bigDataPosInfo)

      filename <- file.path(outDir,
                    paste('returnsEZW.',
                      allData$countryNames[countryToUse],
                      '.Rda',
                      sep=""))
      save(returnsEZW, file = filename)

      ## Starts sinking (saving screen output) to file
      sink(file.path(outDir, APresultsFileName), append = TRUE)

      cat('---------------------------------------------------------\n')
      cat(allData$countryNames[countryToUse],'\n')
      cat('---------------------------------------------------------\n')

      printSummaryStats(returnsEZW, controlVarNAPi, Pref = 1)

      saveSummaryStatsBigFile(allData,countryToUse,returnsEZW,controlVarNAPi)

      ## Finish sinking
      sink()

      ## Predictability
      if (controlVarNAPi$createPredictability == 1){
          predic <- predictability_LeveredLRR(countryToUse,
                                              PDivs,
                                              ParEst,
                                              controlVarNAPi,
                                              bigDataPosInfo)

          savePredictability_LeveredLRR(predic,outDir,countryToUse)
      }
      # Compute impulse response functions
      computeAndSaveImpulseResponses(allData,
                                      countryToUse,
                                      outputEZW,
                                      controlVarNAPi,
                                      bigDataPosInfo)
  }
} else {
  ## Simulate Country Data + Calculate Returns + Calculate Predictability

  ## Initialize summaryStatsBigFile file
  initializeSummaryStatsBigFile(allData,controlVarNAPi)

  for (nn in 1:length(controlVarNAPi$countryToSimulateData)){
    # Load prices
    countryToUse    <- controlVarNAPi$countryToSimulateData[nn]

    filename <- file.path(outDir,
                      paste('outputEZW.',
                            allData$countryNames[countryToUse],
                            '.Rda',sep=""))
    load(filename)

    PDivs           <- outputEZW$PDivs
    ParEst          <- outputEZW$ParEst
    bigDataPosInfo  <- outputEZW$bigDataPosInfo

    # Load returns
    filename <- file.path(outDir,
                  paste('returnsEZW.',
                    allData$countryNames[countryToUse],
                    '.Rda',
                    sep=""))
    load(filename)

    ## Starts sinking (saving screen output) to file
    sink(file.path(outDir, APresultsFileName), append = TRUE)

    cat('---------------------------------------------------------\n')
    cat(allData$countryNames[countryToUse],'\n')
    cat('---------------------------------------------------------\n')

    printSummaryStats(returnsEZW, controlVarNAPi, Pref = 1)

    saveSummaryStatsBigFile(allData,countryToUse,returnsEZW,controlVarNAPi)

    ## Finish sinking
    sink()

    ## Predictability
    if (controlVarNAPi$createPredictability == 1){
      predic <- predictability_LeveredLRR(countryToUse,
                                          PDivs,
                                          ParEst,
                                          controlVarNAPi,
                                          bigDataPosInfo)
      savePredictability_LeveredLRR(predic,outDir,countryToUse)
    }

    ## Compute impulse response functions
    computeAndSaveImpulseResponses(allData,
                                  countryToUse,
                                  outputEZW,
                                  controlVarNAPi,
                                  bigDataPosInfo)
  }
}
#saveSummaryStatsBigFileCSV()

################################################################################
##            Compute Borovicka, Hansen, Scheinkman elasticities              ##
################################################################################
if (controlVarNAPi$computeBHSelasticities == 1){
  load(file.path(outDir,paste('outputEZW.',
                              allData$countryNames[countryToUse],
                              '.Rda',sep="")))

  ParEst       <- outputEZW$ParEst
  Equity       <- outputEZW$PDivs$Equity
  EquityCoarse <- outputEZW$PDivs$EquityCoarse
  # ParEst[bigDataPosInfo$lambda]        <- 0
  # ParEst[bigDataPosInfo$lambdaW]       <- 0

  bigDataPosInfo <- outputEZW$bigDataPosInfo

  getAndSaveMomements(allData,
                      countryToUse,
                      controlVarNAPi,
                      ParEst,
                      Equity,
                      EquityCoarse,
                      bigDataPosInfo,
                      printStuff = 1)

  computeAndSaveBHSelasticities(allData,
                                  countryToUse,
                                  outputEZW,
                                  controlVarNAPi,
                                  bigDataPosInfo)
}

################################################################################
##                   Exchange Rate Computation                                ##
################################################################################
if (controlVarNAPi$computeER == 1){
  ## Starts sinking (saving screen output) to file
  sink(file.path(outDir, APresultsFileName), append = TRUE)

  cat('The base country is ',
    allData$countryNames[controlVarNAPi$baseCountry],'\n')

  ## Load returns
  filename <- file.path(outDir,
                paste('returnsEZW.',
                      allData$countryNames[controlVarNAPi$baseCountry],
                      '.Rda',sep=""))
  load(filename)

  returnsEZWBase <- returnsEZW

  ## Initialize summaryStatsBigFile file
  initializeSummaryStatsBigFile(allData,controlVarNAPi)
  for (nn in c(1:length(controlVarNAPi$countryToSimulateData))){
    countryToUse    <- controlVarNAPi$countryToSimulateData[nn]
    if (countryToUse != controlVarNAPi$baseCountry){
      cat('Open data for',allData$countryNames[countryToUse],'\n')

      filename <- file.path(outDir,
                    paste('returnsEZW.',
                      allData$countryNames[countryToUse],'.Rda',sep=""))
      load(filename)

      outputFX <- calcFX(returnsEZWBase, returnsEZW, controlVarNAPi)

      printSummaryStatsFX(outputFX,countryToUse, controlVarNAPi,allData)
    }
  }
  sink()
}