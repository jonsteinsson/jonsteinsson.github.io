#!/bin/sh
#runNAPe.Netherlands.sh

#Torque directives
#PSB -N runNAPe.Netherlands
#PBS -W group_list=yetisscc
#PBS -l nodes=2:ppn=16,walltime=11:59:59,mem=39900mb
#PBS -M ds2635@columbia.edu
#PBS -m abe
#PBS -V

#set output and error directories
#PBS -o localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.33d3
#PBS -e localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.33d3

#Command to execute R code
R CMD BATCH --no-save --vanilla runNAPe.Netherlands.R $PBS_JOBNAME.routput

#End of script
