## The file contains support functions for runModel.R       
##                                                          
## Emi Nakamura, Dmitriy Sergeyev, Jon Steinsson (July 2016)                                         
################################################################################

if (.Platform$OS.type == "unix"){
   ## On Hotfoot
   # source("/hmt/hpcstorage1/hpc/sscc/work/projects/lrr/lrrRprofile")
   # .libPaths('/hmt/hpcstorage1/hpc/sscc/work/projects/lrr/lrrRlib')

   ## On Yeti
   source("/vega/sscc/work/projects/lrr/lrrRprofile")
   .libPaths('/vega/sscc/work/projects/lrr/lrrRlib')
}
libs <- c('RColorBrewer',
          'zoo',     
          'rjags',  
          'arm',
          'mvtnorm',
          'RColorBrewer') 
lapply(libs, require, character.only = T)

options(digits = 10)

## Read various control variables
getControlVar <- function()
{
    newInit       <- 1     # 1 if new initial values; 0 if using old initial values
    Niter         <- 50000 # Number of iterations in each batch
    NinitThin     <- max(1, floor(Niter/650)) # Amount by which coda thins samples before saving results
    Nadapt        <- 1000  # Number of iterations that jags uses to adapt the MCMC algorithm 
                           # (e.g., variance of random-walk Metropolis-Hastings steps)
                           # Jags will give warning message if Nadapt is too small.
     
    NRuns         <- 100   # Number of batches to run in runModel.R
    nFirstRun     <- 1     # Number to be put on first batch. This should be 1 if newInit = 1, but >1 if newInit = 0 since in these cases user will be adding to exiting sample. 
    noRun         <- 0     # Doesn't run bugs when noRun = 1
 
    nOfChains     <- 1     # Number of chains for bugs to create.
    
    priorType     <- 'XX'  # 'XX' or 'YY' (see getNewInitialValues and related functions below)
    nOfRun        <- 2
    
    useRealData   <- 1     # Estimates using real world data if useRealData = 1. Otherwise uses simulated data. 
        
    seedForBugs   <- sample(seq.int(-100000, -10000), 1) # Set a random seed
    colorsDSlight <- brewer.pal(8, "Set2")
    
    return(list(newInit      = newInit, 
                Niter        = Niter, 
                NinitThin    = NinitThin,
                Nadapt       = Nadapt,
                NRuns        = NRuns, 
                nFirstRun    = nFirstRun, 
                noRun        = noRun, 
                nOfChains    = nOfChains,
                nOfRun       = nOfRun,
                priorType    = priorType,
                useRealData  = useRealData, 
                seedForBugs  = seedForBugs,
                colorsDSlight=colorsDSlight))
}

## Get outDir
################################################################################
getDirInfo <- function()
{
    ## On Hotfoot
    #prefixDir        <- '/hmt/hpcstorage1/hpc/sscc/work/projects/lrr/'

    ## On Yeti
    #prefixDir        <- '/vega/sscc/work/projects/lrr'       
    
    ## On PC
    #prefixDir        <- 'C:/Users/Diman/Dropbox/LongRunRisk'
    
    ## On office computer 
    prefixDir        <- 'C:/Users/Sergeyev/Dropbox/LongRunRisk/bugs/'
    
    outDir           <- file.path(prefixDir, 'data/v11/v11.35d3')
    
    return(list(outDir    = outDir, 
                prefixDir = prefixDir))
}

## Read Data
################################################################################
# readData reads the Barro-Ursua consumption data from a file and returns data  
# for the 16 countries we use in our analysis.
#
# readData calls readData24Countries (which is written below) in order to get 
# information on the timing of disasters. It is easiest to do this by first 
# constructing a dataset of the same size as the dataset used in Nakamura, 
# Steinsson, Barro, Ursua (2012). This explains the two (very similar) functions.

readData <- function(prefixDir) 
{
    filename   <- file.path(prefixDir, 'sandbox/v11/cdata20111116.txt')
    dataAll    <- read.table(filename, header = T, sep = "\t")
    dataAll    <- as.list(dataAll)
    nCountries <- length(dataAll)
    attr(dataAll,"names")[1] <- "year"
    dataYears  <- as.matrix(dataAll[[1]])
    
    ## Create matrix with all consumption data
    cData <- dataAll[[2]]
    for (ii in 3:nCountries)
        cData <- cbind(cData,dataAll[[ii]])
    attr(cData,"dimnames") <- NULL
    cData <- log(cData)
    
    ## Cut off years at the beginning for which no data is observed
    ii <- 0
    while (ii == 0) {
        tempInd <- is.na(cData[1,])
        if (sum(tempInd) < length(tempInd)) {
            ii <- 1
        } else {
            cData     <- cData[-1,]
            dataYears <- as.matrix(dataYears[-1,])
        }
    }
    firstYear <- dataYears[1,1]
    
    ## Save country names
    countryNames   <- attr(dataAll,"names")
    countryNames   <- countryNames[2:nCountries]

    ## Exclude data from countries not to be used in analysis
    countriesToExclude <- c("Austria","Colombia","Egypt","Greece","Iceland","New.Zealand","India",
                            "Indonesia","Malaysia","Philippines","Singapore","S..Africa",
                            "Sri.Lanka","Turkey","Uruguay","Venezuela","Argentina","Brazil","Chile",
                            "Mexico","Peru","Japan","Korea","Taiwan")
    excludedCountries  <- numeric(length(countryNames))
    for (ii in 1:length(countriesToExclude)) {
        excludedCountries <- excludedCountries + (countryNames == countriesToExclude[ii])
    }
    excludedCountries <- which(as.logical(excludedCountries))
    cData <- cData[,-excludedCountries]
    countryNames <- countryNames[-excludedCountries]
            
    ## Create data on starting year and ending year for each country
    startYears           <- matrix(NA,length(countryNames),1)
    for (ii in 1:length(countryNames)) {
        tempInd          <- is.na(cData[,ii])
        tempInd          <- sum(tempInd)
        startYears[ii,1] <- firstYear + tempInd
    }
    endYears <- matrix(2009,length(countryNames),1)    
        
    ## Make 1890 the starting data 
    whichYears          <- 1:(1889-firstYear+1)
    cData[whichYears,]  <- NA
    tempInd             <- which(startYears < 1890)
    startYears[tempInd] <- 1890
    
    ## Make data into long vector (and all other variables also vectors)
    nYears        <- dim(cData)[1]
    nCountries    <- dim(cData)[2]
    TempInd       <- !is.na(cData)
    whichTempInd  <- which(TempInd)
    sumTempInd    <- sum(TempInd)    
    statePosInfo  <- matrix(NA,nYears,nCountries)
    statePosInfo[whichTempInd] <- 1:sumTempInd
    posFirst      <- numeric(nCountries)
    posLast       <- statePosInfo[nYears,]
    for (ii in 1:nCountries) posFirst[ii] <- min(statePosInfo[!is.na(statePosInfo[ ,ii]),ii])
    cData         <- cData[whichTempInd]
    dataYears     <- as.numeric(dataYears)
    startYears    <- as.numeric(startYears)
    endYears      <- as.numeric(endYears)
    
    ## Create variable indicating position of start of post-WWII sample
    pos1946    <- c(rep(NA,nCountries))
    for (ii in 1:nCountries) {
        pos1946[ii] <- posFirst[ii] + 1946 - startYears[ii]
    }

    ## Create data on position of each point relative to starting point for that country's data
    posIIW     <- numeric(length(cData))
    for (ii in 1:nCountries) {
        posIIW[posFirst[ii]:posLast[ii]] <- seq(startYears[ii] - min(startYears) + 1, 
                                                endYears[ii] - min(startYears) + 1, by = 1)
    }
   
    ## Get disaster indicator variable
    AllData24Countries           <- readData24Countries(prefixDir) 
    AdditionalCountriesToExclude <- c(which(AllData24Countries$countryNames == "Argentina"),
                                      which(AllData24Countries$countryNames == "Brazil"),
                                      which(AllData24Countries$countryNames == "Chile"),
                                      which(AllData24Countries$countryNames == "Mexico"),
                                      which(AllData24Countries$countryNames == "Peru"),
                                      which(AllData24Countries$countryNames == "Japan"),
                                      which(AllData24Countries$countryNames == "Korea"),
                                      which(AllData24Countries$countryNames == "Taiwan"))                               
    indeciesToExclude <- c()
    for (ii in AdditionalCountriesToExclude){
        indeciesToExclude <- c(indeciesToExclude,c(AllData24Countries$posFirst[ii]:AllData24Countries$posLast[ii]))
    }
    disasterInd  <- AllData24Countries$disasterInd[-c(indeciesToExclude)]

    nPeriods <- max(posIIW)
       
    return(list(dataAll      = dataAll, 
                cData        = cData, 
                countryNames = countryNames,
                dataYears    = dataYears, 
                startYears   = startYears, 
                endYears     = endYears,
                posFirst     = posFirst, 
                posLast      = posLast,
                pos1946      = pos1946, 
                posIIW       = posIIW,
                nPeriods     = nPeriods,                
                disasterInd  = disasterInd))
}

readData24Countries <- function(prefixDir) 
{
    filename   <- file.path(prefixDir, 'sandbox/v11/cdata20111116.txt')
    dataAll    <- read.table(filename, header = T, sep = "\t")
    dataAll    <- as.list(dataAll)
    nCountries <- length(dataAll)
    attr(dataAll,"names")[1] <- "year"
    dataYears  <- as.matrix(dataAll[[1]])
    
    ## Create matrix with all consumption data
    cData <- dataAll[[2]]
    for (ii in 3:nCountries)
        cData <- cbind(cData,dataAll[[ii]])
    attr(cData,"dimnames") <- NULL
    cData <- log(cData)
    
    ## Cut off years at the beginning for which no data is observed
    ii <- 0
    while (ii == 0) {
        tempInd <- is.na(cData[1,])
        if (sum(tempInd) < length(tempInd)) {
            ii <- 1
        } else {
            cData     <- cData[-1,]
            dataYears <- as.matrix(dataYears[-1,])
        }
    }
    firstYear <- dataYears[1,1]
    
    ## Save country names
    countryNames   <- attr(dataAll,"names")
    countryNames   <- countryNames[2:nCountries]

    ## Cut countries not included in Barro and Ursua (BPEA 2008)
    countriesToExclude <- c("Austria","Colombia","Egypt","Greece","Iceland","New.Zealand","India",
                            "Indonesia","Malaysia","Philippines","Singapore","S..Africa",
                            "Sri.Lanka","Turkey","Uruguay","Venezuela")                            
    excludedCountries  <- numeric(length(countryNames))
    for (ii in 1:length(countriesToExclude)) {
        excludedCountries <- excludedCountries + (countryNames == countriesToExclude[ii])
    }
    excludedCountries <- which(as.logical(excludedCountries))
    cData <- cData[,-excludedCountries]
    countryNames <- countryNames[-excludedCountries]
            
    ## Create data on starting year and ending year for each country
    startYears <- matrix(NA,length(countryNames),1)
    for (ii in 1:length(countryNames)) {
        tempInd <- is.na(cData[,ii])
        tempInd <- sum(tempInd)
        startYears[ii,1] <- firstYear + tempInd
    }
    endYears <- matrix(2009,length(countryNames),1)    
        
    ## Make 1890 the starting data 
    whichYears <- 1:(1889-firstYear+1)
    cData[whichYears,] <- NA
    tempInd <- which(startYears < 1890)
    startYears[tempInd] <- 1890
    
    ## Make data into long vector (and all other variables also vectors)
    nYears        <- dim(cData)[1]
    nCountries    <- dim(cData)[2]
    TempInd       <- !is.na(cData)
    whichTempInd  <- which(TempInd)
    sumTempInd    <- sum(TempInd)    
    statePosInfo  <- matrix(NA,nYears,nCountries)
    statePosInfo[whichTempInd] <- 1:sumTempInd
    posFirst      <- numeric(nCountries)
    posLast       <- statePosInfo[nYears,]
    for (ii in 1:nCountries) posFirst[ii] <- min(statePosInfo[!is.na(statePosInfo[ ,ii]),ii])
    cData         <- cData[whichTempInd]
    dataYears     <- as.numeric(dataYears)
    startYears    <- as.numeric(startYears)
    endYears      <- as.numeric(endYears)
    
    ## Create variable indicating position of start of post-WWII sample
    pos1946    <- c(rep(NA,nCountries))
    for (ii in 1:nCountries) {
        pos1946[ii] <- posFirst[ii] + 1946 - startYears[ii]
    }

    ## Create data on position of each point relative to starting point for that country's data
    posIIW     <- numeric(length(cData))
    for (ii in 1:nCountries) {
        posIIW[posFirst[ii]:posLast[ii]] <- seq(startYears[ii] - min(startYears) + 1, 
                                                endYears[ii] - min(startYears) + 1, by = 1)
    }
    
    ## Load disaster dummy from file
    load("disInd.Rda")
    disasterInd <- disInd$Ind
    disasterIndTemp <- numeric(length(disasterInd))

    ## Add two years to each disaster
    for (ii in 1:nCountries) {
            for (jj in posFirst[ii]:posLast[ii]) {
                if (disasterInd[jj] == 1){
                    disasterIndTemp[jj] <- 1
                    if (jj+1<=posLast[ii]) disasterIndTemp[jj+1] <- 1
                    if (jj+2<=posLast[ii]) disasterIndTemp[jj+2] <- 1                    
                }
            }
    }    
    disasterInd <- disasterIndTemp
    nPeriods    <- max(posIIW)
           
    return(list(dataAll      = dataAll, 
                cData        = cData, 
                countryNames = countryNames,
                dataYears    = dataYears, 
                startYears   = startYears, 
                endYears     = endYears,
                posFirst     = posFirst, 
                posLast      = posLast,
                pos1946      = pos1946, 
                nPeriods     = nPeriods,
                disasterInd  = disasterInd))
}

## Model Data
################################################################################
## This function creates a list that contains the data as well as
## information on hyperparameters and other information that 
## needs to be passed to bugs to estimate the model

getModelData <- function(allData)
{
    cData               <- allData$cData
    posFirst            <- allData$posFirst
    posLast             <- allData$posLast
    pos1946             <- allData$pos1946
    disasterInd         <- allData$disasterInd
    
    nCountries          <- length(allData$countryNames)    
    
    ## Set Hyperparameters
    
    # rho
    low.rho             <- 0.005
    high.rho            <- 0.995
    a.rho               <- 1
    b.rho               <- 1
    prior.rho           <- "Unif"
      
    # chi  
    low.chiSq           <- 0.01^2    
    high.chiSq          <- 5^2
    a.chiSq             <- 1
    b.chiSq             <- 1
    prior.chiSq         <- "Unif"
      
    # xi
    low.xi              <- rep(0.0001,16)
    high.xi             <- rep(1,16)
    a.xi                <- 1
    b.xi                <- 1
    prior.xi            <- "Unif"
    
    # Mu
    mu.mu               <- 0.015
    tau.mu              <- 0.03^(-2)
    prior.mu            <- "Norm"    
      
    # muDS  
    mu.muDS             <- 0
    tau.muDS            <- 1
    prior.muDS          <- "Norm"    
      
    # sigmaSqDS  
    low.sigmaSqDS       <- 1
    high.sigmaSqDS      <- 1.00001
    a.sigmaSqDS         <- 1
    b.sigmaSqDS         <- 1
    prior.sigmaSqDS     <- "Unif"    
        
    # sigmaSqConst
    low.sigmaSqConst    <- 0.0001^2
    high.sigmaSqConst   <- 0.02^2
    a.sigmaSqConst      <- 1
    b.sigmaSqConst      <- 1  
    prior.sigmaSqConst  <- "Unif"    
      
    # sigmaSqNu  
    low.sigmaSqNu       <- 0.0001^2
    high.sigmaSqNu      <- 0.01^2
    a.sigmaSqNu         <- 1
    b.sigmaSqNu         <- 1
    priot.sigmaSqNu     <- "Unif"    
      
    # sigmaSqNuPre  
    low.sigmaSqNuPre    <- 0.0001^2
    high.sigmaSqNuPre   <- 0.1^2    
    a.sigmaSqNuPre      <- 1
    b.sigmaSqNuPre      <- 1
    prior.sigmaSqNuPre  <- "Unif"
          
    # gammma  
    low.gammma          <- 0.005
    high.gammma         <- 0.98
    a.gammma            <- 1
    b.gammma            <- 1    
    prior.gammma        <- "Unif"  
    
    # tauOmega
    low.sigmaSqOmega    <- 0.000001^2
    high.sigmaSqOmega   <- 0.000050^2      
    a.sigmaSqOmega      <- 1
    b.sigmaSqOmega      <- 1   
    prior.sigmaSqOmega  <- "Unif"

    # initial values for yy
    low.yy1             <- cData[posFirst] - 0.04
    high.yy1            <- cData[posFirst] + 0.04
     
    mean.yy1            <- cData[posFirst]
    tau.yy1             <- 0.0001
    prior.yy1           <- "Norm"

    # initial values for sigmaSq
    tau.sigmaSq1        <- 1/0.0001^2     
    
    # initial values for xx
    mean.xx1            <- 0
    tau.xx1             <- 1/(10^2*0.005^2)
    prior.xx1           <- "Norm"
    
    cutOff              <- 1e-8
    
    return(list(cc                 = cData, 
                nCountries         = nCountries,
                posFirst           = posFirst, 
                posLast            = posLast,
                pos1946            = pos1946,
                disasterInd        = disasterInd, 
                       
                mu.muDS            = mu.muDS, 
                tau.muDS           = tau.muDS,
                       
                mean.yy1           = mean.yy1,
                tau.yy1            = tau.yy1,
                
                mean.xx1           = mean.xx1,
                tau.xx1            = tau.xx1,
       
                tau.sigmaSq1       = tau.sigmaSq1,

                low.chiSq          = low.chiSq, 
                high.chiSq         = high.chiSq,
                a.chiSq            = a.chiSq,
                b.chiSq            = b.chiSq,
       
                low.xi             = low.xi, 
                high.xi            = high.xi,
                a.xi               = a.xi,
                b.xi               = b.xi,               
                       
                mu.mu              = mu.mu,     
                tau.mu             = tau.mu,

                low.gammma         = low.gammma, 
                high.gammma        = high.gammma, 
                a.gammma           = a.gammma,   
                b.gammma           = b.gammma,

                low.rho            = low.rho,
                high.rho           = high.rho, 
                a.rho              = a.rho, 
                b.rho              = b.rho, 

                low.sigmaSqDS      = low.sigmaSqDS, 
                high.sigmaSqDS     = high.sigmaSqDS,
                a.sigmaSqDS        = a.sigmaSqDS,
                b.sigmaSqDS        = b.sigmaSqDS,
                
                low.sigmaSqConst   = low.sigmaSqConst,  
                high.sigmaSqConst  = high.sigmaSqConst,  
                a.sigmaSqConst     = a.sigmaSqConst, 
                b.sigmaSqConst     = b.sigmaSqConst,
                            
                low.sigmaSqNuPre   = low.sigmaSqNuPre, 
                high.sigmaSqNuPre  = high.sigmaSqNuPre,
                a.sigmaSqNuPre     = a.sigmaSqNuPre, 
                b.sigmaSqNuPre     = b.sigmaSqNuPre,
                
                low.sigmaSqNu      = low.sigmaSqNu,    
                high.sigmaSqNu     = high.sigmaSqNu,
                a.sigmaSqNu        = a.sigmaSqNu,    
                b.sigmaSqNu        = b.sigmaSqNu,

                low.sigmaSqOmega   = low.sigmaSqOmega,   
                high.sigmaSqOmega  = high.sigmaSqOmega,
                a.sigmaSqOmega     = a.sigmaSqOmega,   
                b.sigmaSqOmega     = b.sigmaSqOmega,

                cutOff             = cutOff))
}

## Initial Values
################################################################################

## getSavedInitialValues read in initial values from bugsSimInit.Rda
## This is an option for the first batch of a run. For all subsequent
## batches, these are the initial values that are used. bugsSimInit.Rda
## will then contain the last values from the previous batch

getSavedInitialValues <- function(outDir)
{
    load('bugsSimInit.Rda')
    bugsSimInitStart <- bugsSimInit
    filename <-  file.path(outDir, 'bugsSimInitStart.Rda')    
    save(bugsSimInit, file = filename)
    
    return(bugsSimInit)
}

## getNewInitialValues calls one of several different functions
## defined below that create initial values with different characteristics
## The variable priorType in controlVar controls which initial values
## are chosen in the case when one chain is used
################################################################################
getNewInitialValues <- function(allData,UnobsPosInfo, controlVar)
{
    if (controlVar$nOfChains == 1) {
        if (controlVar$priorType == 'XX') {
            Out <- list(getInitialValuesAllXX(allData))
        } else {
            Out <- list(getInitialValuesAllYY(allData))
        }
    }
    if (controlVar$nOfChains == 2) {Out <- list(getInitialValuesAllXX(allData),getInitialValuesAllYY(allData))}

    return(Out)
}

## getInitialValuesAllXX produces initial values all the variation in the 
## data attributed to XX and XXW
################################################################################
getInitialValuesAllXX <- function(allData)
{
    cData         <- allData$cData
 
    lengthData    <- length(cData)
    nCountries    <- length(allData$countryNames)

    posFirst      <- allData$posFirst
    posLast       <- allData$posLast
    pos1946       <- allData$pos1946
    pos1973       <- allData$pos1973    
    disasterInd   <- allData$disasterInd
    
    ## State Variables
    cDataTemp <- cData
    mu <- numeric(nCountries)
    for (ii in 1:nCountries) {
        mu[ii] <- (cDataTemp[posLast[ii]]- cDataTemp[posFirst[ii]])/(posLast[ii]-posFirst[ii])
        cDataTemp[(posFirst[ii]+1):posLast[ii]] <- cDataTemp[(posFirst[ii]+1):posLast[ii]] - mu[ii]*1:(posLast[ii]-posFirst[ii])
    }
    
    DcDataTemp <- cDataTemp
    for (ii in 1:nCountries) {
        DcDataTemp[posFirst[ii]] <- NA
        DcDataTemp[(posFirst[ii]+1):posLast[ii]] <- cDataTemp[(posFirst[ii]+1):posLast[ii]] - cDataTemp[posFirst[ii]:(posLast[ii]-1)]
    }
           
    xx            <- numeric(lengthData)
    for (ii in 1:nCountries) {
        for (jj in (posFirst[ii]+1):posLast[ii]) {
            if (!is.na(DcDataTemp[jj]) & !disasterInd[jj]) {
                xx[jj-1] <- DcDataTemp[jj]
            }
        }
    }
    yy            <- cData                             ## Pre stationary shock consumption
    
    sigmaSqTemp   <- rnorm(lengthData, 0.02^2, 0.01^2)
    for (ii in 1:nCountries) {
        for (jj in (posFirst[ii]+1):posLast[ii]) {
            sigmaSqTemp[jj] <- xx[jj+1]-xx[jj]
        }
    }
        
    DS            <- numeric(lengthData) - 0.1

    ## Country parameters
    sigmaSqNubeta     <- rep(0.2,nCountries)   
    sigmaSqNuPrebeta  <- rep(0.2,nCountries)    
    chiSqbeta         <- rep(0.2,nCountries)   
    sigmaSqConstbeta  <- rep(0.8,nCountries) 
    xibeta            <- rep(0.5,nCountries)     
        
    ## Parameters
    sigmaSqDSbeta    <- 0.8
    muDS             <- -0.2
    rhobeta          <- 0.8
    gammmabeta       <- 0.8
    sigmaSqOmegabeta <- 0.8  
        
    inits <- list(yy                = yy,
                  xx                = xx,
                  xibeta            = xibeta,                  
                  sigmaSqTemp       = sigmaSqTemp,
                  DS                = DS,
                  muDS              = muDS,                   
                  mu                = mu,
                  sigmaSqDSbeta     = sigmaSqDSbeta,                  
                  sigmaSqOmegabeta  = sigmaSqOmegabeta,
                  sigmaSqNubeta     = sigmaSqNubeta,
                  sigmaSqNuPrebeta  = sigmaSqNuPrebeta,
                  sigmaSqConstbeta  = sigmaSqConstbeta,
                  chiSqbeta         = chiSqbeta,
                  rhobeta           = rhobeta,                  
                  gammmabeta        = gammmabeta)                   
    return(inits)
}

## getInitialValuesAllYY produces initial values in which XX = 0
################################################################################
getInitialValuesAllYY <- function(allData)
{
    cData         <- allData$cData
    lengthData    <- length(cData)
    nCountries    <- length(allData$countryNames)
    
    ## State variables
    xx            <- numeric(lengthData)               ## Long-run component of cons. growth
    yy            <- cData                             ## Pre stationary shock consumption
    sigmaSqTemp   <- rnorm(lengthData, 0.02^2, 0.01^2) #
    DS            <- numeric(lengthData)-0.15
    
    ## Country parameters
    mu                <- rep(0.01,nCountries)
    sigmaSqNubeta     <- rep(0.8,nCountries)   
    sigmaSqNuPrebeta  <- rep(0.8,nCountries)    
    chiSqbeta         <- rep(0.8,nCountries)   
    sigmaSqConstbeta  <- rep(0.2,nCountries)    
    xibeta            <- rep(0.5,nCountries)          

    ## Parameters
    sigmaSqDSbeta    <- 0.2
    muDS             <- -0.15
    rhobeta          <- 0.2
    gammmabeta       <- 0.2
    sigmaSqOmegabeta <- 0.2
    
    inits <- list(yy                = yy,
                  xx                = xx,
                  xibeta            = xibeta,                   
                  sigmaSqTemp       = sigmaSqTemp,
                  DS                = DS,
                  muDS              = muDS,                   
                  mu                = mu,
                  sigmaSqDSbeta     = sigmaSqDSbeta,                  
                  sigmaSqOmegabeta  = sigmaSqOmegabeta,
                  sigmaSqNubeta     = sigmaSqNubeta,
                  sigmaSqNuPrebeta  = sigmaSqNuPrebeta,
                  sigmaSqConstbeta  = sigmaSqConstbeta,
                  chiSqbeta         = chiSqbeta,
                  rhobeta           = rhobeta,
                  gammmabeta        = gammmabeta)
    return(inits)
}


## Create List with Names and PosInfo for Output from bugs
#####################################################################
getNamesNPosInfo <- function(allData)
{
    cData       <- allData$cData
    nCountries  <- length(allData$countryNames)
        
    UnobsNames    <- NULL
    UnobsPosInfo  <- NULL
    UnobsDim      <- NULL
    
    namesNPos <- list(UnobsNames = UnobsNames, UnobsPosInfo = UnobsPosInfo,
                      UnobsDim = UnobsDim)
                      
    .getNamesNPosInfoState <- function(namesNPos,varName)
    {        
        namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
        if (length(namesNPos$UnobsPosInfo) == 0) {
            TempStart <- 1
            TempEnd   <- length(cData)
        } else {
            TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
            TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+length(cData)
        }
        namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
        names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
        namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(length(cData)))
        return(namesNPos)
    }                      
    
    .getNamesNPosInfoPar <- function(namesNPos,varName,varDim)
    {
        namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
        if (length(namesNPos$UnobsPosInfo) == 0) {
            TempStart <- 1
            TempEnd   <- varDim
        } else {
            TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
            TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+varDim
        }        
        namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
        names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
        namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(varDim))
        return(namesNPos)
    }
    
    .getNamesNPosInfoCountryPar <- function(namesNPos,varName)
    {
        namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
        if (length(namesNPos$UnobsPosInfo) == 0) {
            TempStart <- 1
            TempEnd   <- nCountries
        } else {
            TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
            TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+nCountries
        }        
        namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
        names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
        namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(nCountries))
        return(namesNPos)
    }    
    
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'DS')
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'chiSq')    
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'chiSqbeta')    
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'deviance',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'gammma',1)     
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'gammmabeta',1) 
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'mu')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'muDS',1) 
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'rho',1)     
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'rhobeta',1)       
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'sigmaSq')   
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqConst')
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqConstbeta')
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqDS',1)    
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqDSbeta',1)    
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqNu')           
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqNuPre') 
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqNuPrebeta')    
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaSqNubeta')    
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqOmega',1)
    namesNPos <- .getNamesNPosInfoPar(namesNPos,        'sigmaSqOmegabeta',1)
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'sigmaSqTemp') 
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'xi')    
    namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'xibeta')    
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'xx')
    namesNPos <- .getNamesNPosInfoState(namesNPos,      'yy')

    return(list(UnobsNames = namesNPos$UnobsNames, UnobsPosInfo = namesNPos$UnobsPosInfo, UnobsDim = namesNPos$UnobsDim))
}

## Save last values as bugsSimInit.Rda
#######################################################################
## This is done to be able to use these values as starting values in the 
## next batch

saveLastValues <- function(UnobsPosInfo,runToSave, filename)
{
    load(filename)
    
    nChains  <- length(bugsSim)
    nKeep    <- dim(bugsSim[[1]])[1]
    
    tempUnobsPosInfo <- UnobsPosInfo[-c(which(names(UnobsPosInfo) == 'deviance'),
                                        which(names(UnobsPosInfo) == 'sigmaSq'),
                                        which(names(UnobsPosInfo) == 'rho'),
                                        which(names(UnobsPosInfo) == 'sigmaSqConst'),
                                        which(names(UnobsPosInfo) == 'chiSq'),
                                        which(names(UnobsPosInfo) == 'xi'),                                         
                                        which(names(UnobsPosInfo) == 'sigmaSqNu'),                                                                                
                                        which(names(UnobsPosInfo) == 'sigmaSqNuPre'),
                                        which(names(UnobsPosInfo) == 'sigmaSqDS'),
                                        which(names(UnobsPosInfo) == 'sigmaSqOmega'),
                                        which(names(UnobsPosInfo) == 'gammma'))]
    
    bugsSimInit <- list(tempUnobsPosInfo)
    kk <- 1
    for (ii in (1:length(tempUnobsPosInfo))) {
        temp <- as.vector(bugsSim[[1]][nKeep,tempUnobsPosInfo[[ii]]])
        #temp <- t(matrix(temp,UnobsDim[[ii]][2],UnobsDim[[ii]][1]))
        bugsSimInit[[1]][[kk]] <- temp
        kk <- kk + 1
    }
    if (nChains > 1) {
        for (jj in 2:nChains) {
            kk <- 1
            bugsSimInit[[jj]] <- tempUnobsPosInfo
            for (ii in (1:length(tempUnobsPosInfo))) {
                temp <- as.vector(bugsSim[[jj]][nKeep,tempUnobsPosInfo[[ii]]])
                #temp <- t(matrix(temp,UnobsDim[[ii]][2],UnobsDim[[ii]][1]))
                bugsSimInit[[jj]][[kk]] <- temp
                kk <- kk + 1
            }
        }
    }
    filename <-  file.path(outDir, 'bugsSimInit.Rda')
    save(bugsSimInit, file = filename)
    save(bugsSimInit, file = 'bugsSimInit.Rda')
    
    return(bugsSimInit)
}

## Call SimDataSetFromEstimatedParameters from runModel.R
#####################################################################
## This is a wrapper function that calls SimDataSetFromEstimatedParameters
## from runModel.R. The reason for this function is that 
## SimDataSetFromEstimatedParameters uses inputs from funcsAgg.R.
## It is useful to source funcsAgg.R within this function so as not
## to have all the functions therein defined in the root environment
## This function outputs a simulated dataset of the same size as 
## the real data based on the estimated parameters for use 
## in Monte Carlo estimation.

getSimDataSetFromEstimatedParameters <- function(prefixDir, outDir, 
                                            plotSimData = 1, printOLSgamma = 0)
{
    source('funcsAgg.R')
    controlAgg     <- getControlAgg()
    allData        <- readData(prefixDir)
    modelData      <- getModelData(allData)
    NamesNPosInfo  <- getNamesNPosInfo(allData)
    UnobsPosInfo   <- NamesNPosInfo$UnobsPosInfo    
    bigDataPosInfo <- getBigDataPosInfo(UnobsPosInfo)
    ParEst         <- getParEstimates(bigDataPosInfo,controlAgg$usePooledChains,controlAgg$chainToUse)    
    cDataEstParams <- simDataSetFromEstimatedParameters(allData, modelData, controlAgg, ParEst, bigDataPosInfo, prefixDir, outDir)
    allData$cData  <- cDataEstParams$cDis    
    filename       <-  file.path(outDir, 'cDataEstParams.Rda')
    save(cDataEstParams, file = filename)
    
    return(allData)
}

## Simulate data from the model 
#####################################################################
## Simulates a dataset of the same size as the real data set
## using the estimated parameters 

simDataSetFromEstimatedParameters <- function(allData, modelData, controlAgg, 
                                                ParEst, bigDataPosInfo, 
                                                prefixDir, outDir, 
                                                plotSimData = 1, 
                                                useEstInitials = 0)
{
    library(mvtnorm)

    cData       <- allData$cData
    posFirst    <- allData$posFirst
    posLast     <- allData$posLast
    pos1946     <- allData$pos1946
    pos1973     <- allData$pos1973
    disasterInd <- allData$disasterInd
    startYears  <- allData$startYears
    endYears    <- allData$endYears
    
    nTotalLength<- length(cData)
    nCountries  <- length(posFirst)    

    #####################
    ## Read Parameters ##
    #####################
    
    # Long-run risk parameters
    rho           <- ParEst[bigDataPosInfo$rho]
    gammma        <- ParEst[bigDataPosInfo$gammma]
    sigmaSqOmega  <- ParEst[bigDataPosInfo$sigmaSqOmega]
    
    # Country specific parameters
    xi            <- ParEst[bigDataPosInfo$xi]
    mu            <- ParEst[bigDataPosInfo$mu]
    chiSq         <- ParEst[bigDataPosInfo$chiSq]
    sigmaSqNuPre  <- ParEst[bigDataPosInfo$sigmaSqNuPre]
    sigmaSqNu     <- ParEst[bigDataPosInfo$sigmaSqNu]
    sigmaSqConst  <- ParEst[bigDataPosInfo$sigmaSqConst]

    sigmaConst    <- sqrt(sigmaSqConst)    
    sigmaOmega    <- sqrt(sigmaSqOmega)    
    sigmaNuPre    <- sqrt(sigmaSqNuPre)
    sigmaNu       <- sqrt(sigmaSqNu)
    
    #######################
    ## Read Disaster Data #
    #######################
    if (controlAgg$usePooledChains == 0){ 
        filename <-  file.path(outDir, 'bigDataDS.Rda') 
        load(filename)                 
        DS <- disasterInd*apply(bigDataDS[[1]],2,mean) 
    } 
    if (controlAgg$usePooledChains == 1){
        filename <-  file.path(outDir, 'bigDataDS_pooled.Rda') 
        load(filename) 
        DS <- disasterInd*apply(bigDataDS_pooled,2,mean) 
    }   

    ############################
    ##  Initialize variables   #
    ############################
    cDis       <- numeric(nTotalLength)    
    cNoDis     <- numeric(nTotalLength)
    XX         <- numeric(nTotalLength)
    YY         <- numeric(nTotalLength)
    SigmaSq    <- numeric(nTotalLength)
    Eps        <- numeric(nTotalLength)
    Eta        <- numeric(nTotalLength)
    Nu         <- numeric(nTotalLength)
    Omega      <- numeric(nTotalLength)
    
    if (useEstInitials == 1){
        initsEst     <- getInitsEstimates(allData,bigDataPosInfo,controlAgg$usePooledChains,controlAgg$chainToUse) ## this function extracts initial states from the estimation output
    }
    
    for (ii in 1:nCountries) {                
        if (useEstInitials == 0){
            varOmegaEps             <- matrix(c(sigmaOmega^2/(1-gammma^2),
                                              0,
                                              0,
                                              (sigmaSqConst[ii]/(1-rho^2))),2,2)
            omegaEps                <- rmvnorm(1, mean = c(0,0), sigma = varOmegaEps)
            Omega[1]                <- omegaEps[1]
            Eps[1]                  <- omegaEps[2]
            SigmaSq[posFirst[ii]]   <- max(sigmaSqConst + Omega[1],modelData$cutOff)
            XX[posFirst[ii]]        <- Eps[1]    
            YY[posFirst[ii]]        <- 0
        }
        if (useEstInitials == 1){            
            SigmaSq[posFirst[ii]]   <- initsEst$SigmaSq0[ii]    
            XX[posFirst[ii]]        <- initsEst$XX0[ii]    
            YY[posFirst[ii]]        <- 0    
        }        
        for (tt in (posFirst[ii]+1):posLast[ii]) {                        
            varOmegaEps  <- matrix(c(sigmaOmega^2,
                                    0,
                                    0,
                                    SigmaSq[tt-1]),2,2)
            omegaEps     <- rmvnorm(1, mean = c(0,0), sigma = varOmegaEps)
            Omega[tt]    <- omegaEps[1]
            Eps[tt]      <- omegaEps[2]
            SigmaSq[tt]  <- max(sigmaSqConst[ii] + gammma * (SigmaSq[tt-1]  - sigmaSqConst[ii])  + Omega[tt],modelData$cutOff)
            Eta[tt]      <- rnorm(1,0,sqrt(chiSq[ii]*(SigmaSq[tt-1])))
    
            XX[tt]       <- rho  * XX[tt-1]  + Eps[tt]
            YY[tt]       <- YY[tt-1] + mu[ii] + XX[tt-1] + Eta[tt]
        }          
        # Consumption process
        Nu[posFirst[ii]:posLast[ii]]     <- c(rnorm(pos1946[ii]-posFirst[ii],0,sigmaNuPre[ii]),rnorm(posLast[ii]-pos1946[ii] + 1,0,sigmaNu[ii])) 
        cNoDis[posFirst[ii]:posLast[ii]] <- YY[posFirst[ii]:posLast[ii]] + Nu[posFirst[ii]:posLast[ii]] 
    }
    
    # Add disasters
    cDis <- cNoDis + DS
    ## Create plots
    if (plotSimData == 1){
        filename <-  file.path(outDir,'simConsumption.pdf')
        pdf(filename, paper = 'special', width = 6, height = 7)
        par(mfrow = c(3, 2))    
    
        for (ii in 1:nCountries)
        {                  
            ylimTemp    <- range(c(cDis[posFirst[ii]:posLast[ii]],cNoDis[posFirst[ii]:posLast[ii]])) 
            plot(startYears[ii]:endYears[ii], cDis[posFirst[ii]:posLast[ii]],
                 main = allData$countryNames[ii],
                 xlab = 'time',
                 ylab = 'log(C)',
                 type = "l",
                 ylim = ylimTemp)
            lines(startYears[ii]:endYears[ii], as.ts(cNoDis[posFirst[ii]:posLast[ii]]), col=5)
            
            ylimTemp    <- range(c(diff(cDis[posFirst[ii]:posLast[ii]]),diff(DS[posFirst[ii]:posLast[ii]]))) 
            plot((startYears[ii]+1):endYears[ii], as.ts(diff(cDis[posFirst[ii]:posLast[ii]])),
                 main = allData$countryNames[ii],
                 xlab = 'time',
                 ylab = 'delta(C)',
                 type = "l",
                 ylim = ylimTemp)
            points((startYears[ii]+1):endYears[ii], as.ts(diff(DS[posFirst[ii]:posLast[ii]])), type='h', col=5, lwd=0.4)      
            points((startYears[ii]+1):endYears[ii], as.ts(XX[posFirst[ii]:(posLast[ii]-1)]), type='l', col=2, lwd=0.7)        

            ylimTemp    <- range(c(XX[posFirst[ii]:posLast[ii]])) 
            plot(startYears[ii]:endYears[ii], XX[posFirst[ii]:posLast[ii]],
                 main = allData$countryNames[ii],
                 xlab = 'time',
                 ylab = 'XX',
                 type = "l",
                 ylim = ylimTemp)
 
            ylimTemp    <- range(SigmaSq) 
            plot(startYears[ii]:endYears[ii], SigmaSq[posFirst[ii]:posLast[ii]],
                 main = allData$countryNames[ii],
                 xlab = 'time',
                 ylab = 'SigmaSq',
                 type = "l",
                 ylim = ylimTemp)     
        }  
        dev.off()    
    }
    return(list(cDis      = cDis, 
                cNoDis    = cNoDis,
                YY        = YY,
                Nu        = Nu,
                XX        = XX,
                SigmaSq   = SigmaSq, 
                Eta       = Eta))
}
# Simulate data using parameters provided in params of arbitrary length simLength
#################################################################################
simData <- function(params, simLength, cutOff)
{
    # Parameters
    rho        <- params$rho
    chi        <- params$chi
    xi         <- params$xi    
    sigmaConst <- params$sigmaConst   
    sigmaOmega <- params$sigmaOmega
    sigmaNu    <- params$sigmaNu
    gammma     <- params$gammma    
    mu         <- params$mu
    ############################
    ##  Initialize variables   #
    ############################
    cc         <- numeric(simLength)    
    ccNoXX     <- numeric(simLength)
    XX         <- numeric(simLength)
    YY         <- numeric(simLength)
    YYnoXX     <- numeric(simLength)
    SigmaSq    <- numeric(simLength)
    Eps        <- numeric(simLength)
    Eta        <- numeric(simLength)
    Nu         <- numeric(simLength)
    Omega      <- numeric(simLength)
    
    ## Set initial values
    varOmegaEps             <- matrix(c(sigmaOmega^2/(1-gammma^2),
                                        0,
                                        0,
                                        (sigmaConst^2/(1-rho^2))),2,2)
    omegaEps                <- rmvnorm(1, mean = c(0,0), sigma = varOmegaEps)
    Omega[1]                <- omegaEps[1]
    Eps[1]                  <- omegaEps[2]
    SigmaSq[1]              <- max(sigmaConst^2 + Omega[1],cutOff)
    XX[1]                   <- Eps[1]    
    for (tt in 2:simLength) {                        
        omegaEps     <- rmvnorm(1, mean = c(0,0), sigma = matrix(c(sigmaOmega^2,0,0,SigmaSq[tt-1]),2,2))
        Omega[tt]    <- omegaEps[1]
        Eps[tt]      <- omegaEps[2]
        SigmaSq[tt]  <- max(sigmaConst^2  + gammma * (SigmaSq[tt-1]  - sigmaConst^2)  + Omega[tt],cutOff)
        Eta[tt]      <- rnorm(1,0,sqrt(chi^2*SigmaSq[tt-1]))

        XX[tt]       <- rho  * XX[tt-1]  + Eps[tt]
        YY[tt]       <- YY[tt-1]     + mu + XX[tt-1] + Eta[tt]  
    }
    EtaNoSV      <- rnorm(simLength,0,sqrt(chi^2*quantile(SigmaSq, probs = 0.5))) 
    for (tt in 2:simLength) {                        
        YYnoXX[tt]   <- YYnoXX[tt-1] + mu + EtaNoSV[tt]
    }             
    Nu     <- rnorm(simLength,0,sigmaNu)                         
    cc     <- YY     + Nu
    ccNoXX <- YYnoXX + Nu
    
    return(list(cc       = cc,
                ccNoXX   = ccNoXX,
                XX       = XX,
                Eps      = Eps,
                Eta      = Eta,
                Nu       = Nu,
                SigmaSq  = SigmaSq))
}

simDataFixedSV <- function(params, simLength, cutOff)
{
    # Parameters
    rho        <- params$rho
    chi        <- params$chi
    xi         <- params$xi    
    sigmaConst <- params$sigmaConst   
    sigmaOmega <- params$sigmaOmega
    sigmaNu    <- params$sigmaNu
    gammma     <- params$gammma    
    mu         <- params$mu
    ############################
    ##  Initialize variables   #
    ############################
    XX         <- numeric(simLength)
    YY         <- numeric(simLength)
    SigmaSq    <- numeric(simLength)
    #############################
    ##      Simulate SV        ##
    #############################
    Omega       <- rnorm(simLength, mean = 0, sd = sigmaOmega)
    SigmaSq[1]  <- max(sigmaConst^2  + Omega[1], cutOff)
    for (tt in 2:simLength) SigmaSq[tt]  <- max(sigmaConst^2  + gammma * (SigmaSq[tt-1]  - sigmaConst^2)  + Omega[tt],cutOff)
    SigmaSq05 <- quantile(SigmaSq, probs = 0.05)     
    SigmaSq50 <- quantile(SigmaSq, probs = 0.5)
    SigmaSq95 <- quantile(SigmaSq, probs = 0.95)
    ############################################
    ##          Simulate for SigmaSq05        ##
    ############################################
    Eps          <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq05))
    Eta          <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq05))
    Nu           <- rnorm(simLength, mean = 0, sd = sigmaNu)                         
    XX[1]        <- Eps[1]    
    YY[1]        <- 0
    for (tt in 2:simLength) {
        XX[tt]   <- rho  * XX[tt-1]  + Eps[tt]
        YY[tt]   <- YY[tt-1] + mu + XX[tt-1] + Eta[tt]
    }
    cc05         <- YY + Nu
    ############################################
    ##          Simulate for SigmaSq50        ##
    ############################################
    Eps          <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq50))
    Eta          <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq50))
    Nu           <- rnorm(simLength, mean = 0, sd = sigmaNu)                         
    XX[1]        <- Eps[1]    
    YY[1]        <- 0
    for (tt in 2:simLength) {
        XX[tt]   <- rho  * XX[tt-1]  + Eps[tt]
        YY[tt]   <- YY[tt-1]     + mu + XX[tt-1] + Eta[tt]
    }
    cc50         <- YY     + Nu    
    ############################################
    ##         Simulate for SigmaSq95         ##
    ############################################
    Eps          <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq95))
    Eta          <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq95))
    Nu           <- rnorm(simLength, mean = 0, sd = sigmaNu)                         
    XX[1]        <- Eps[1]    
    YY[1]        <- 0
    for (tt in 2:simLength) {
        XX[tt]   <- rho  * XX[tt-1]  + Eps[tt]
        YY[tt]   <- YY[tt-1]     + mu + XX[tt-1] + Eta[tt]
    }
    cc95         <- YY     + Nu    
    return(list(cc05 = cc05,
                cc50 = cc50,
                cc95 = cc95))
}

simDataBY <- function(params, simLength, cutOff)
{
    # Parameters
    rho        <- params$rho
    chi        <- params$chi
    sigmaConst <- params$sigmaConst   
    sigmaOmega <- params$sigmaOmega
    gammma     <- params$gammma    
    mu         <- params$mu
    
    ############################
    ##  Initialize variables   #
    ############################
    cc         <- numeric(simLength)    
    ccNoXX     <- numeric(simLength) 
    XX         <- numeric(simLength)
    SigmaSq    <- numeric(simLength)
    Eps        <- numeric(simLength)
    Eta        <- numeric(simLength)
    Omega      <- numeric(simLength)
    
    ############################
    ##          Simulate      ##
    ############################
    Omega[1]                <- rnorm(1, mean = 0, sd = sqrt(sigmaOmega^2/(1-gammma^2)))
    Eps[1]                  <- rnorm(1, mean = 0, sd = sqrt(sigmaConst^2/(1-rho^2)))
    SigmaSq[1]              <- max(sigmaConst^2 + Omega[1],cutOff)
    XX[1]                   <- Eps[1]    
    for (tt in 2:simLength) {                        
        Omega[tt]    <- rnorm(1, mean = 0, sd = sigmaOmega)
        Eps[tt]      <- rnorm(1, mean = 0, sd = sqrt(SigmaSq[tt-1]))
        SigmaSq[tt]  <- max(sigmaConst^2  + gammma * (SigmaSq[tt-1]  - sigmaConst^2)  + Omega[tt],cutOff)
        Eta[tt]      <- rnorm(1,0,sqrt(chi^2*SigmaSq[tt-1]))
                
        XX[tt]       <- rho  * XX[tt-1]  + Eps[tt]
        cc[tt]       <- cc[tt-1]     + mu + XX[tt-1] + Eta[tt]

    }          
    #EtaNoSV          <- rnorm(simLength,0,sqrt(chi^2*sigmaConst^2))    
    EtaNoSV          <- rnorm(simLength,0,sqrt(chi^2*quantile(SigmaSq,probs = 0.5)))    
    for (tt in 2:simLength) {                        
        ccNoXX[tt]   <- ccNoXX[tt-1] + mu + EtaNoSV[tt]
    }
    return(list(cc      = cc,
                ccNoXX  = ccNoXX,
                XX      = XX,
                SigmaSq = SigmaSq))
}

simDataBYFixedSV <- function(params, simLength, cutOff)
{
    # Parameters
    rho        <- params$rho
    chi        <- params$chi
    sigmaConst <- params$sigmaConst   
    sigmaOmega <- params$sigmaOmega
    gammma     <- params$gammma    
    mu         <- params$mu
    ############################
    ##  Initialize variables   #
    ############################
    cc         <- numeric(simLength)    
    XX         <- numeric(simLength)
    SigmaSq    <- numeric(simLength)
    ############################
    ##   Simulate SV          ##
    ############################
    Omega                   <- rnorm(simLength,mean=0,sd=sigmaOmega)
    SigmaSq[1]              <- max(sigmaConst^2 + Omega[1],cutOff)
    for (tt in 2:simLength) {                        
        SigmaSq[tt]  <- max(sigmaConst^2  + gammma * (SigmaSq[tt-1]  - sigmaConst^2)  + Omega[tt],cutOff)
    }
    SigmaSq05 <- quantile(SigmaSq, probs = 0.05)     
    SigmaSq50 <- quantile(SigmaSq, probs = 0.5)
    SigmaSq95 <- quantile(SigmaSq, probs = 0.95)
    ############################
    ## Simulate for SigmaSq05 ##
    ############################
    Eps        <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq05))
    Eta        <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq05))
    XX[1]      <- Eps[1]    
    for (tt in 2:simLength) {                        
        XX[tt] <- rho  * XX[tt-1]  + Eps[tt]
        cc[tt] <- cc[tt-1] + mu + XX[tt-1] + Eta[tt]
    }
    cc05 <- cc
    ############################
    ## Simulate for SigmaSq50 ##
    ############################
    Eps        <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq50))
    Eta        <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq50))
    XX[1]      <- Eps[1]    
    for (tt in 2:simLength) {                        
        XX[tt] <- rho  * XX[tt-1]  + Eps[tt]
        cc[tt] <- cc[tt-1] + mu + XX[tt-1] + Eta[tt]
    }
    cc50 <- cc              
    ############################
    ## Simulate for SigmaSq95 ##
    ############################
    Eps        <- rnorm(simLength, mean = 0, sd = sqrt(SigmaSq95))
    Eta        <- rnorm(simLength, mean = 0, sd = sqrt(chi^2*SigmaSq95))
    XX[1]      <- Eps[1]    
    for (tt in 2:simLength) {                        
        XX[tt] <- rho  * XX[tt-1]  + Eps[tt]
        cc[tt] <- cc[tt-1] + mu + XX[tt-1] + Eta[tt]
    }
    cc95 <- cc                  
    return(list(cc05 = cc05,
                cc50 = cc50,
                cc95 = cc95))
}