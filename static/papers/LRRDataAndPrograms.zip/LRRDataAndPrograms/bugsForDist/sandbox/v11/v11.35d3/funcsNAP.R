#####################################################################
## Support functions for calculating asset prices
##
## Emi Nakamura, Dmitriy Sergeyev and Jon Steinsson, June 2014
#####################################################################
libs <- c('quantreg', # This library containes a function that creates TeX table from matrix
          'TTR',      # This package allows to use a function that computes running sums runSum() without loops
          'mvtnorm',  # Deals with multivariate normal
          'Hmisc',    # Allows to use approxExtrap() function that performs linear extrapolation
          'MASS')

lapply(libs, require, character.only = T)

getControlVarNAP <- function(allData, controlAgg)
{
    countryToUse          <- which(allData$countryNames == GlobalCountryName)
    countryToComputePrice <- which(allData$countryNames == GlobalCountryName)
    countryToSimulateData <- numeric(length(GlobalCountryToSimulateData))

    for (ii in 1:length(GlobalCountryToSimulateData)){
        countryToSimulateData[ii] <- which(allData$countryNames == GlobalCountryToSimulateData[ii])
    }

    createFolders        <- 1
    createPredictability <- 1

    ## if = 1 the program creates nextState files
    createNextStateFiles <- GlobalCreateNextStateFiles 
    
    simulatePrices       <- GlobalSimulatePrices

    ## Sets chain to use
    Chain                <- controlAgg$chainToUse      ## Chain to use
    usePooledChains      <- 1                          ## if = 1 uses pooled chains and discards Chain parameter
    ##
    cutOff               <- 1e-8                       ## value that cuts off stochastic volatility from below
                                                       ## (should be the same as in the estimation)
    ## Utility Function Type
    doEZW                <- 1
    doPowerU             <- 0

    ## Reduce computation time by using previously saved results
    updatePDivs          <- GlobalUpdatePDivs
    simulatePrices       <- GlobalSimulatePrices
    
    ## Assets of Interest (program always calculates Equity returns)
    getLeveredXXEquity   <- 1       ## if = 1 computes AP for our main asset of interest
    getOnePerBond        <- 1
    getPerpetuity        <- 0
    getScaledEq          <- 0       ## if = 1 computes AP for asset with log(D) = alpha*log(C)
    getOPEquity          <- 0       ## One Period Equity
    
    ## Simulation length
    nSim                 <- 100000
    nSimBurnin           <- 1000
    nnMonteCarlo         <- 1000
    
    ## Iteration parmaters
    tolIntEq             <- 0.005  ## Tolerance for iterations on Equity integral
    tolIntBond           <- 0.005  ## Tolerance for iterations on Bond integral
    tolIntLeveredXXEq    <- 0.005
    tolIntPerp           <- 0.005  ## Tolerance for iterations on Perpetuity integral
    tolIntScaEq          <- 0.005  ## Tolerance for iterations on "scaled" Equity integral
    tolIntOPEq           <- 0.005  ## Tolerance for iterations on One Period Equity integral
    maxIter              <- 50000   ## Maximum number of iterations
    
    # Utility parameters
    gammaU               <- 9     ## Risk-Aversion
    psiU                 <- 1.5     ## Intertemporal Elasticity of Substitution
    rhoU                 <- 0.009   ## Discount Rate (NSS)
    thetaU               <- (1-gammaU)/(1-1/psiU)
    
    # Payoff properties of long term bond
    payGrowth            <- 0.90      # Gross growth rate of payoff on the perpetuity
    
    # Leverage on leveraged XX claim
    phi                  <- 3   # NSS
    
    # Initial value for PDivEq
    initPDivEq           <- log(12)
    
    # State Gridsize
    nStateGridNu         <- 1
    nStateGridXX         <- 51
    nStateGridSigmaSq    <- 71
    nStateGrid           <- nStateGridNu*nStateGridXX*nStateGridSigmaSq
    
    # Integration Gridsize
    nIntGridEta          <- 5#7
    
    # Grid limits in units of standard deviations
    nSdNu                <- 1
    nSdXX                <- 10
    nSdSigmaSq           <- 6
    nSdEps               <- 10
    nSdEta               <- 4
    nSdOmega             <- 4

    return(list(countryToComputePrice= countryToComputePrice,
                countryToSimulateData= countryToSimulateData,
                Chain                = Chain,
                usePooledChains      = usePooledChains,
                createNextStateFiles = createNextStateFiles,
                simulatePrices       = simulatePrices,
                doEZW                = doEZW,
                doPowerU             = doPowerU,
                updatePDivs          = updatePDivs,
                getLeveredXXEquity   = getLeveredXXEquity,
                getOnePerBond        = getOnePerBond,
                getPerpetuity        = getPerpetuity,
                getScaledEq          = getScaledEq,
                getOPEquity          = getOPEquity,
                nSim                 = nSim,
                nSimBurnin           = nSimBurnin,
                nnMonteCarlo         = nnMonteCarlo,
                maxIter              = maxIter,
                tolIntEq             = tolIntEq,
                tolIntBond           = tolIntBond,
                tolIntLeveredXXEq    = tolIntLeveredXXEq,
                tolIntPerp           = tolIntPerp,
                tolIntScaEq          = tolIntScaEq,
                tolIntOPEq           = tolIntOPEq,
                gammaU               = gammaU,
                psiU                 = psiU,
                rhoU                 = rhoU,
                thetaU               = thetaU,
                payGrowth            = payGrowth,
                initPDivEq           = initPDivEq,
                phi                  = phi,
                nStateGridNu         = nStateGridNu,
                nStateGridXX         = nStateGridXX,
                nStateGridSigmaSq    = nStateGridSigmaSq,
                nIntGridEta          = nIntGridEta,
                nStateGrid           = nStateGrid,
                nSdNu                = nSdNu,
                nSdXX                = nSdXX,
                nSdSigmaSq           = nSdSigmaSq,
                nSdEps               = nSdEps,
                nSdEta               = nSdEta,
                nSdOmega             = nSdOmega,
                cutOff               = cutOff,
                createFolders        = createFolders))
}

## the following function creates folders that contain
## nextState and weightsOverIntGrid files
createFolders <- function(allData,controlVarNAPi,outDir){
    countryToComputePrice <- controlVarNAPi$countryToComputePrice
    for (nn in c(1:length(countryToComputePrice))){
        outDirNextState          <- file.path(outDir, 
            'nextState',allData$countryNames[countryToComputePrice[nn]])
        outDirWeightsOverIntGrid <- file.path(outDir, 
            'weightsOverIntGrid',allData$countryNames[countryToComputePrice[nn]])
        dir.create(outDirNextState,         recursive = TRUE)
        dir.create(outDirWeightsOverIntGrid,recursive = TRUE)
    }
}

# Create Grids
#####################################################################
# State Vector: Nu, XX, SigmaSq
# Integration Vector: Nu,Eta,Eps,Omega
createStateGrid <- function(countryToUse,controlVarNAP,ParEst,UnobsPosInfo)
{
    cutOff       <- controlVarNAP$cutOff
    sigmaSqConst <- ParEst[UnobsPosInfo$sigmaSqConst][countryToUse]

    nStateGridNu      <- controlVarNAP$nStateGridNu
    nStateGridXX      <- controlVarNAP$nStateGridXX
    nStateGridSigmaSq <- controlVarNAP$nStateGridSigmaSq

    nSdNu        <- controlVarNAP$nSdNu
    nSdXX        <- controlVarNAP$nSdXX
    nSdSigmaSq   <- controlVarNAP$nSdSigmaSq

    sigmaNu      <- sqrt(ParEst[UnobsPosInfo$sigmaSqNu][countryToUse])
    sigmaXX      <- sqrt(ParEst[UnobsPosInfo$sigmaSqConst][countryToUse]/(1 - ParEst[UnobsPosInfo$rho]^2))
    sigmaSigmaSq <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmega]/(1 - ParEst[UnobsPosInfo$gammma]^2))

    #Create Gridpoints

    #            Nu
    if (nStateGridNu == 1) {
        gridNu   <- 0
    } else {
        gridNu   <- seq(-nSdNu*sigmaNu, nSdNu*sigmaNu, length.out = nStateGridNu)
    }

    #            XX
    if (nStateGridXX == 1) {
        gridXX   <- 0
    } else {
        gridXX   <- seq(-nSdXX*sigmaXX, nSdXX*sigmaXX, length.out = nStateGridXX)
    }

    #            SigmaSq
    if (nStateGridSigmaSq == 1) {
        gridSigmaSq   <- sigmaSqConst
    } else {
        gridSigmaSq   <- seq(max(cutOff,sigmaSqConst - nSdSigmaSq*sigmaSigmaSq), sigmaSqConst + nSdSigmaSq*sigmaSigmaSq, length.out = nStateGridSigmaSq)
    }

    #Create state grid
    stateGrid     <- as.matrix(expand.grid(gridNu, gridXX, gridSigmaSq))
    dimnames(stateGrid)[[2]] <- c('Nu','XX','SigmaSq')


    return(list(stateGrid   = stateGrid,
                gridNu      = gridNu,
                gridXX      = gridXX,
                gridSigmaSq = gridSigmaSq))
}

createIntGrid <- function(countryToUse,controlVarNAP,ParEst,UnobsPosInfo,stateGridList)
{
    nIntGridEta   <- controlVarNAP$nIntGridEta

    if (length(stateGridList$gridNu)>1) {
        incNuGrid   <- stateGridList$gridNu[2] - stateGridList$gridNu[1]
    } else {
        incNuGrid   <- 0
    }
    if (length(stateGridList$gridXX)>1) {
        incEpsGrid   <- stateGridList$gridXX[2] - stateGridList$gridXX[1]
    } else {
        incEpsGrid   <- 0
    }
    if (length(stateGridList$gridSigmaSq)>1) {
        incOmegaGrid   <- stateGridList$gridSigmaSq[2] - stateGridList$gridSigmaSq[1]
    } else {
        incOmegaGrid   <- 0
    }

    nSdNu          <- controlVarNAP$nSdNu
    nSdEta         <- controlVarNAP$nSdEta
    nSdEps         <- controlVarNAP$nSdEps
    nSdOmega       <- controlVarNAP$nSdOmega

    sigmaNu        <- sqrt(ParEst[UnobsPosInfo$sigmaSqNu][countryToUse])
    chi            <- sqrt(ParEst[UnobsPosInfo$chiSq][countryToUse])
    sigmaEps       <- sqrt(ParEst[UnobsPosInfo$sigmaSqConst][countryToUse])
    sigmaOmega     <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmega])

    #shockvec is : 'Nu','Eta','Eps','Omega'
    #Create gridpoints

    # Generate Nu Grid
    if (length(stateGridList$gridNu) == 1) {
        gridNu    <- 0
    } else {
        gridNuPos <- seq(0, nSdNu*sigmaNu, by = incNuGrid)
        gridNuNeg <- sort(-gridNuPos)
        gridNuNeg <- gridNuNeg[gridNuNeg!=0]
        gridNu    <- c(gridNuNeg,gridNuPos)
    }
    if (length(stateGridList$gridNu) == 1) {
        tempGridNu    <- 0
    } else {
        tempGridNu    <-  gridNu - incNuGrid/2
        tempGridNu    <- c(tempGridNu,tempGridNu(length(tempGridNu))+incNuGrid/2)
    }

    # Generate Eta Grid
    if (nIntGridEta == 1) {
        tempGridEta   <- 0
    } else {
        tempGridEta   <- seq(-nSdEta*sigmaEps*chi, nSdEta*sigmaEps*chi, length.out = (nIntGridEta+1))
    }
    if (nIntGridEta == 1) {
        gridEta   <- 0
    } else {
        gridEta   <-  (tempGridEta[2:(nIntGridEta+1)] + tempGridEta[1:nIntGridEta]) /2
    }

    # Generate Eps Grid
    if (length(stateGridList$gridXX) == 1) {
        gridEps   <- 0
    } else {
        gridEpsPos <- seq(0, nSdEps*sigmaEps, by = incEpsGrid)
        gridEpsNeg <- sort(-gridEpsPos)
        gridEpsNeg <- gridEpsNeg[gridEpsNeg!=0]
        gridEps    <- c(gridEpsNeg,gridEpsPos)
    }
    if (length(stateGridList$gridXX) == 1) {
        tempGridEps   <- 0
    } else {
        tempGridEps    <-  gridEps - incEpsGrid/2
        tempGridEps    <- c(tempGridEps,tempGridEps[length(tempGridEps)]+incEpsGrid/2)
    }

    # Generate Omega Grid
    if (length(stateGridList$gridSigmaSq) == 1) {
        gridOmega   <- 0
    } else {
        gridOmegaPos <- seq(0, nSdOmega*sigmaOmega, by = incOmegaGrid)
        gridOmegaNeg <- sort(-gridOmegaPos)
        gridOmegaNeg <- gridOmegaNeg[gridOmegaNeg!=0]
        gridOmega    <- c(gridOmegaNeg,gridOmegaPos)
    }
    if (length(stateGridList$gridSigmaSq) == 1) {
        tempGridOmega   <- 0
    } else {
        tempGridOmega    <-  gridOmega - incOmegaGrid/2
        tempGridOmega    <- c(tempGridOmega,tempGridOmega[length(tempGridOmega)]+incOmegaGrid/2)
    }

    nIntGridNu     <- length(gridNu)
    nIntGridEta    <- length(gridEta)
    nIntGridEps    <- length(gridEps)
    nIntGridOmega  <- length(gridOmega)

    nIntGrid <- nIntGridNu*nIntGridEta*nIntGridEps*nIntGridOmega

    filename <- file.path(outDir, APresultsFileName)
    sink(filename, append = TRUE)
    cat('nIntGrid:                 ',nIntGrid,'\n')
    cat('nIntNu:                   ',nIntGridNu,'\n')
    cat('nIntEta:                  ',nIntGridEta,'\n')
    cat('nIntEps:                  ',nIntGridEps,'\n')
    cat('nIntOmega:                ',nIntGridOmega,'\n')
    cat('\n')
    sink()

    #Create integration grid
    intGrid <- as.matrix(expand.grid(gridNu,gridEta,gridEps,gridOmega))
    dimnames(intGrid)[[2]] <- c('Nu','Eta','Eps','Omega')

    return(list(intGrid         = intGrid,

                nIntGridNu      = nIntGridNu,
                nIntGridEta     = nIntGridEta,
                nIntGridEps     = nIntGridEps,

                nIntGridOmega   = nIntGridOmega,
                nIntGrid        = nIntGrid,

                gridNu          = gridNu,
                gridEta         = gridEta,
                gridEps         = gridEps,
                gridOmega       = gridOmega,

                tempGridNu      = tempGridNu,
                tempGridEta     = tempGridEta,
                tempGridEps     = tempGridEps,
                tempGridOmega   = tempGridOmega))
}
# Create nextStateFunc
#####################################################################
nextStateFuncGen <- function(countryToUse,stateGridList,intGridList, 
                            controlVarNAP, ParEst, UnobsPosInfo)
{
    intGridNu         <- intGridList$gridNu
    intGridEta        <- intGridList$gridEta
    intGridEps        <- intGridList$gridEps
    intGridOmega      <- intGridList$gridOmega

    nIntGridNu        <- length(intGridNu)
    nIntGridEta       <- length(intGridEta)
    nIntGridEps       <- length(intGridEps)
    nIntGridOmega     <- length(intGridOmega)

    stateGridNu       <- stateGridList$gridNu
    stateGridXX       <- stateGridList$gridXX
    stateGridSigmaSq  <- stateGridList$gridSigmaSq

    nStateGridNu      <- length(stateGridNu)
    nStateGridXX      <- length(stateGridXX)
    nStateGridSigmaSq <- length(stateGridSigmaSq)

    nStates           <- dim(stateGridList$stateGrid)[1]
    nInt              <- dim(intGridList$intGrid)[1]

    rho               <- ParEst[UnobsPosInfo$rho]
    gammma            <- ParEst[UnobsPosInfo$gammma]
    sigmaEps          <- sqrt(ParEst[UnobsPosInfo$sigmaSqConst][countryToUse])

    nextStateFunc <- function(currentState)
    {
        oldXX      <- currentState[2]
        oldSigmaSq <- currentState[3]

        nextState <- numeric(nInt)

        for (iiOmega in 1:nIntGridOmega) {
            runSigmaSq    <- max(sigmaEps^2 + gammma * (oldSigmaSq - sigmaEps^2) + intGridOmega[iiOmega],controlVarNAP$cutOff)
            indRunSigmaSq <- which.min(abs(stateGridSigmaSq-runSigmaSq))

            for (iiEps in 1:nIntGridEps) {
                runXX <- rho * oldXX + intGridEps[iiEps]
                indRunXX  <- which.min(abs(stateGridXX-runXX))

                nextStateNu    <- numeric(nIntGridNu)

                for(iiNu in 1:nIntGridNu) {
                    runNu             <- intGridNu[iiNu]
                    indRunNu          <- which.min(abs(stateGridNu-runNu))

                    nextStateNu[iiNu] <- (indRunSigmaSq-1) * nStateGridXX * nStateGridNu + (indRunXX-1)*nStateGridNu + indRunNu
                }

                nextStateNu <- rep(nextStateNu,nIntGridEta)
                startInd    <- (iiOmega - 1)*nIntGridEps*nIntGridEta*nIntGridNu + (iiEps-1)*nIntGridEta*nIntGridNu + 1
                endInd      <- (iiOmega - 1)*nIntGridEps*nIntGridEta*nIntGridNu + iiEps*nIntGridEta*nIntGridNu
                nextState[startInd:endInd] <- nextStateNu
            }
        }
        #if (mean(nextStateNoDis) != 130) browser()
        #if (mean(nextStateDis) != 238) browser()

        #browser()

        return(list(nextState = nextState))
    }
    return(nextStateFunc)
}

nextStateFuncGenAndSave <- function(countryToUse,stateGridList,intGridList, 
                                    controlVarNAP, ParEst, UnobsPosInfo)
{
    nextStateFunc <- nextStateFuncGen(countryToUse,stateGridList, intGridList, controlVarNAP, ParEst, UnobsPosInfo)
    stateGrid     <- stateGridList$stateGrid
    nStateGrid    <- dim(stateGrid)[1]

    timer2        <- proc.time()[3]

    for (ii in 1:nStateGrid) {
        nextState <- nextStateFunc(stateGrid[ii,])
        filename  <- file.path(outDir,"nextState",allData$countryNames[countryToUse], paste(c('nextState',ii,'Rda'), collapse = '.'))
        save(nextState,file = filename)
    }

    timer2 <- proc.time()[3] - timer2
    # cat('Time Gen and Save nextState: ',timer2,'\n\n')
}


# Create probability distribution over intGrid
#####################################################################
calcWeightsFuncGen <- function(countryToUse,intGridList, controlVarNAP, 
                                ParEst, UnobsPosInfo)
{

    intGridNu      <- intGridList$gridNu
    intGridEta     <- intGridList$gridEta
    intGridEps     <- intGridList$gridEps
    intGridOmega   <- intGridList$gridOmega

    nIntGridNu     <- length(intGridNu)
    nIntGridEta    <- length(intGridEta)
    nIntGridEps    <- length(intGridEps)
    nIntGridOmega  <- length(intGridOmega)

    tempGridNu     <- intGridList$tempGridNu
    tempGridEta    <- intGridList$tempGridEta
    tempGridEps    <- intGridList$tempGridEps
    tempGridOmega  <- intGridList$tempGridOmega

    nTempGridNu     <- length(tempGridNu)
    nTempGridEta    <- length(tempGridEta)
    nTempGridEps    <- length(tempGridEps)
    nTempGridOmega  <- length(tempGridOmega)

    mu         <- ParEst[UnobsPosInfo$mu][countryToUse]
    rho        <- ParEst[UnobsPosInfo$rho]
    sigmaNu    <- sqrt(ParEst[UnobsPosInfo$sigmaSqNu][countryToUse])
    sigmaOmega <- sqrt(ParEst[UnobsPosInfo$sigmaSqOmega])
    chiSq      <- ParEst[UnobsPosInfo$chiSq][countryToUse]


    # Weights over Nu
    if (nIntGridNu == 1) {
        wNu <- 1
    } else {
        wNu <- (pnorm(tempGridNu[2:nTempGridNu], numeric(nTempGridNu-1), rep(sigmaNu,nIntGridNu)) - pnorm(tempGridNu[1:nTempGridNu-1], numeric(nTempGridNu-1), rep(sigmaNu,nIntGridNu)) )
        lowTailNu        <- pnorm(tempGridNu[1], 0, sigmaNu)
        highTailNu       <-  1- pnorm(tempGridNu[nTempGridNu], 0, sigmaNu)
        wNu[1]           <- wNu[1] + lowTailNu
        wNu[nIntGridNu]  <- wNu[nIntGridNu] + highTailNu
    }

    # Weights over Omega
    if (nIntGridOmega == 1) {
        wOmega <- 1
    } else {
        wOmega <- (pnorm(tempGridOmega[2:nTempGridOmega], numeric(nTempGridOmega-1), rep(sigmaOmega,nIntGridOmega)) - pnorm(tempGridOmega[1:nTempGridOmega-1], numeric(nTempGridOmega-1), rep(sigmaOmega,nIntGridOmega)))
        lowTailOmega          <- pnorm(tempGridOmega[1], 0, sigmaOmega)
        highTailOmega         <-  1- pnorm(tempGridOmega[nTempGridOmega], 0, sigmaOmega)
        wOmega[1]             <- wOmega[1] + lowTailOmega
        wOmega[nIntGridOmega] <- wOmega[nIntGridOmega] + highTailOmega
    }

    weightsOverIntGridFunc <-
        function(curSigmaSq)
    {

        # Weights over Eta
        if (nIntGridEta == 1) {
            wEta <- 1
        } else {
            wEta <- (pnorm(tempGridEta[2:nTempGridEta], numeric(nTempGridEta-1), rep(sqrt(chiSq*curSigmaSq),nIntGridEta)) - pnorm(tempGridEta[1:nTempGridEta-1], numeric(nTempGridEta-1), rep(sqrt(chiSq*curSigmaSq),nIntGridEta)) )
            lowTailEta        <- pnorm(tempGridEta[1], 0, sqrt(chiSq*curSigmaSq))
            highTailEta       <-  1- pnorm(tempGridEta[nTempGridEta], 0, sqrt(chiSq*curSigmaSq))
            wEta[1]           <- wEta[1] + lowTailEta
            wEta[nIntGridEta] <- wEta[nIntGridEta] + highTailEta
        }

        # Weights over Eps
        if (nIntGridEps == 1){
            wEps <- 1
        } else {
            wEps                   <- (pnorm(tempGridEps[2:nTempGridEps], numeric(nTempGridEps-1), rep(sqrt(curSigmaSq),nIntGridEps)) - pnorm(tempGridEps[1:nTempGridEps-1], numeric(nTempGridEps-1), rep(sqrt(curSigmaSq),nIntGridEps)) )
            lowTailEps             <- pnorm(tempGridEps[1], 0, sqrt(curSigmaSq))
            highTailEps            <-  1- pnorm(tempGridEps[nTempGridEps], 0, sqrt(curSigmaSq))
            wEps[1]                <- wEps[1] + lowTailEps
            wEps[nIntGridEps]      <- wEps[nIntGridEps] + highTailEps
        }

        #Create weights for all points on int grid
        weightsOverIntGrid <- kronecker(wEta, wNu)
        weightsOverIntGrid <- kronecker(wEps, weightsOverIntGrid)
        weightsOverIntGrid <- kronecker(wOmega, weightsOverIntGrid)

        return(weightsOverIntGrid)
    }

    return(weightsOverIntGridFunc)
}

calcWeightsFuncGenAndSave <- function(countryToUse,stateGridList,intGridList, 
                                        controlVarNAP, ParEst, UnobsPosInfo)
{
    weightsOverIntGridFunc <- calcWeightsFuncGen(countryToUse,intGridList, controlVarNAP, ParEst, UnobsPosInfo)

    stateGridSigmaSq  <- stateGridList$gridSigmaSq
    nGridSigmaSq      <- length(stateGridSigmaSq)

    timer2 <- proc.time()[3]

    for (ii in 1:nGridSigmaSq) {
        weightsOverIntGrid <- weightsOverIntGridFunc(stateGridSigmaSq[ii])
        filename <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse], paste(c('weightsOverIntGrid',ii,'Rda'), collapse = '.'))
        save(weightsOverIntGrid,file = filename)
    }

    timer2 <- proc.time()[3] - timer2
    # cat('Time Gen and Save nextState: ',timer2,'\n\n')
}

## Create PDivEqNextIntFunc
#####################################################################

PDivIntFuncGen <- function(countryToUse,stateGridList, intGridList, 
                            controlVarNAP, ParEst, UnobsPosInfo)
{
    NuOnIntGrid    <- intGridList$intGrid[,1]
    EtaOnIntGrid   <- intGridList$intGrid[,2]
    EpsOnIntGrid   <- intGridList$intGrid[,3]
    OmegaOnIntGrid <- intGridList$intGrid[,4]

    mu             <- ParEst[UnobsPosInfo$mu][countryToUse]
    rho            <- ParEst[UnobsPosInfo$rho]

    rhoU           <- controlVarNAP$rhoU
    gammaU         <- controlVarNAP$gammaU
    psiU           <- controlVarNAP$psiU
    thetaU         <- controlVarNAP$thetaU
    phi            <- controlVarNAP$phi

    debtEqRatio    <- controlVarNAP$debtEqRatio
    payGrowth      <- controlVarNAP$payGrowth

    stateGridSigmaSq  <- stateGridList$gridSigmaSq

    PDivEqIntFunc <-
        function(currentState, nextPDivVec)
    {
        curNu      <- currentState[1]
        curXX      <- currentState[2]
        curSigmaSq <- currentState[3]
        iiSigmaSq <- which.min(abs(stateGridSigmaSq-curSigmaSq))

        filename   <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse], paste(c('weightsOverIntGrid',iiSigmaSq,'Rda'), collapse = '.'))
        load(filename)

        # No Disasters case
        deltaLogC <- mu + curXX + NuOnIntGrid - curNu + EtaOnIntGrid

        intVal    <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) * (1 + exp(nextPDivVec))^thetaU)

        #Do the numerical integration
        PDiv        <- (weightsOverIntGrid %*% intVal)^(1/thetaU)
        PDiv        <- log(PDiv)

        return(PDiv)
    }

    PDivOnePerBondIntFunc <-
        function(currentState, curPDivEq, nextPDivEq)
    {
        curNu      <- currentState[1]
        curXX      <- currentState[2]
        curSigmaSq <- currentState[3]

        iiSigmaSq <- which.min(abs(stateGridSigmaSq-curSigmaSq))

        filename   <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse], paste(c('weightsOverIntGrid',iiSigmaSq,'Rda'), collapse = '.'))
        load(filename)

        deltaLogC <- mu + curXX + NuOnIntGrid - curNu + EtaOnIntGrid

        intVal <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU)  )

        #Do the numerical integration
        PDiv        <- weightsOverIntGrid %*% intVal
        PDiv        <- log(PDiv)

        return(PDiv)
    }

    PDivPerpetuityIntFunc <-
        function(currentState, curPDivEq, nextPDivEq, nextPDivPerp)
    {
        curNu      <- currentState[1]
        curXX      <- currentState[2]
        curSigmaSq <- currentState[3]

        deltaLogC <- mu + curXX + NuOnIntGrid - curNu + EtaOnIntGrid
        intVal    <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU) * payGrowth * (1 + exp(nextPDivPerp)) )
        PDiv      <- weightsOverIntGrid %*% intVal
        PDiv      <- log(PDiv)

        return(PDiv)
    }

    PDivLeveredXXEqIntFunc <-
        function(currentState, curPDivEq, nextPDivEq, nextPDivVec)
    {
        curNu      <- currentState[1]
        curXX      <- currentState[2]
        curSigmaSq <- currentState[3]
        iiSigmaSq  <- which.min(abs(stateGridSigmaSq-curSigmaSq))

        filename   <- file.path(outDir,"weightsOverIntGrid",allData$countryNames[countryToUse], paste(c('weightsOverIntGrid',iiSigmaSq,'Rda'), collapse = '.'))
        load(filename)

        deltaLogC <- mu + curXX + NuOnIntGrid - curNu + EtaOnIntGrid
        deltaLogD <- mu + phi * (curXX + EtaOnIntGrid)

        intVal <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEq))^(-1+thetaU)  * exp(deltaLogD) * (1 + exp(nextPDivVec)))

        #Do the numerical integration
        PDiv        <- weightsOverIntGrid %*% intVal
        PDiv        <- log(PDiv)

        return(PDiv)
    }


    return(list(PDivEqIntFunc          = PDivEqIntFunc,
                PDivOnePerBondIntFunc  = PDivOnePerBondIntFunc,
                PDivLeveredXXEqIntFunc = PDivLeveredXXEqIntFunc,
                PDivPerpetuityIntFunc  = PDivPerpetuityIntFunc))
}
# Calculate P-Div Ratio for Equity for Each Value on State Grid
################################################################################
getPDivs_EZW <- function(controlVarNAP, ParEst, UnobsPosInfo, printStuff = 1)
{
    #Create State Grid
    stateGridList          <- createStateGrid(countryToUse,controlVarNAP, ParEst, UnobsPosInfo)
    stateGrid              <- stateGridList$stateGrid
    #Create Integration grid
    intGridList            <- createIntGrid(countryToUse,controlVarNAP, ParEst, UnobsPosInfo,stateGridList)
    intGrid                <- intGridList$intGrid
    # Generate nextStateFunc
    if (controlVarNAP$createNextStateFiles == 1){
        nextStateFuncGenAndSave(countryToUse,stateGridList, intGridList, controlVarNAP, ParEst, UnobsPosInfo)
    }
    # Calculate weights over intGrid
    calcWeightsFuncGenAndSave(countryToUse,stateGridList,intGridList, controlVarNAP, ParEst, UnobsPosInfo)

    # Genernate PDivNextIntFuncGens
    PDivIntFunc            <- PDivIntFuncGen(countryToUse,stateGridList, intGridList, controlVarNAP, ParEst, UnobsPosInfo)
    PDivEqIntFunc          <- PDivIntFunc$PDivEqIntFunc
    PDivOnePerBondIntFunc  <- PDivIntFunc$PDivOnePerBondIntFunc
    DivPerpetuityIntFunc   <- PDivIntFunc$PDivPerpetuityIntFunc
    PDivLeveredXXEqIntFunc <- PDivIntFunc$PDivLeveredXXEqIntFunc

    #### Equity ####
    PDivVec    <- numeric(dim(stateGrid)[1]) + controlVarNAP$initPDivEq
    PDivVecOld <- PDivVec
    if (printStuff) cat('Calculating P-Div Ratio for Equity\n')
    timer2     <- proc.time()[3]
    nIter      <- 0
    maxDiff    <- 2*controlVarNAP$tolIntEq

    while (maxDiff > controlVarNAP$tolIntEq & nIter < controlVarNAP$maxIter & maxDiff < 10^5) {
        timer1 <- proc.time()[3]
        for (ii in 1:length(PDivVec)) {
            currentState <- stateGrid[ii,]
            load(file.path(outDir,"nextState",allData$countryNames[countryToUse], paste(c('nextState',ii,'Rda'), collapse = '.')))
            nextPDivVec <- PDivVecOld[nextState$nextState]
            PDivVec[ii] <- PDivEqIntFunc(currentState, nextPDivVec)
        }
        maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
        PDivVecOld  <- PDivVec
        nIter       <- nIter + 1

        timer1      <- proc.time()[3] - timer1
        if (printStuff) {
            cat(nIter,")",timer1,":",maxDiff,' ')
            if (nIter %% 10 == 0) cat('\n')
        }
    }
    if (printStuff) {
        cat('\n')
        timer2 <- proc.time()[3] - timer2
        cat('Total Time Int Equity: ', timer2, '\n')
        cat('Number of Iterations:  ', nIter,'\n')
        cat('sup norm:              ', maxDiff,'\n')
    }
    if (nIter == controlVarNAP$maxIter) {
        cat('\n')
        cat('#########################################\n')
        cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
        cat('#########################################\n')
        cat('\n')
    }
    if (maxDiff > 10^5) {
        cat('\n')
        cat('############################\n')
        cat('#### EQUITY DIVERGED #######\n')
        cat('############################\n')
        cat('\n')
    }

    output <- list(Equity = PDivVec)

    if (maxDiff < 10^5) {

        #### One Period Bond ####
        if (controlVarNAP$getOnePerBond == 1) {
            PDivVec    <- numeric(dim(stateGrid)[1]) + 4
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for a One Period Bond\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVarNAP$tolIntBond
            while (maxDiff > controlVarNAP$tolIntBond & nIter < controlVarNAP$maxIter) {

                timer1 <- proc.time()[3]
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDir,"nextState",allData$countryNames[countryToUse], paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEq  <- output$Equity[nextState$nextState]
                    PDivVec[ii] <- PDivOnePerBondIntFunc(currentState, output$Equity[ii],nextPDivEq)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int OnePerBond: ', timer2, '\n')
                cat('Number of Iterations:      ', nIter,'\n')
                cat('sup norm:                  ', maxDiff,'\n')
            }

            output$OnePerBond <- PDivVec
        }

        #### Perpetuity ####
        if (controlVarNAP$getPerpetuity == 1) {
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for a Perpetuity\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVarNAP$tolIntPerp
            while (maxDiff > controlVarNAP$tolIntPerp & nIter < controlVarNAP$maxIter) {

                timer1 <- proc.time()[3]
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDir,"nextState",allData$countryNames[countryToUse], paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEq   <- output$Equity[nextState$nextState]

                    PDivVec[ii] <- PDivPerpetuityIntFunc(currentState, output$Equity[ii],
                                                         nextPDivEq,nextPDivVecDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int Perpetuity: ', timer2, '\n')
                cat('Number of Iterations:      ', nIter,'\n')
                cat('sup norm:                  ', maxDiff,'\n')
            }
            if (nIter == controlVarNAP$maxIter) {
                cat('#########################################\n')
                cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
                cat('#########################################\n')
            }

            output$Perpetuity <- PDivVec
        }

        #### Levered XX Equity ####
        if (controlVarNAP$getLeveredXXEquity == 1) {
            PDivVec    <- numeric(dim(stateGrid)[1]) + controlVarNAP$initPDivEq
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for a a levered XX equity \n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVarNAP$tolIntLeveredXXEq
            while (maxDiff > controlVarNAP$tolIntLeveredXXEq & nIter < controlVarNAP$maxIter) {

                timer1 <- proc.time()[3]
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDir,"nextState",allData$countryNames[countryToUse], paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEq  <- output$Equity[nextState$nextState]
                    nextPDivVec <- PDivVecOld[nextState$nextState]

                    PDivVec[ii] <- PDivLeveredXXEqIntFunc(currentState, output$Equity[ii],nextPDivEq,nextPDivVec)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }
            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int LeveredXXEq:', timer2, '\n')
                cat('Number of Iterations:      ', nIter,'\n')
                cat('sup norm:                  ', maxDiff,'\n')
            }
            output$LeveredXXEq <- PDivVec
        }
    }
    return(output)
}

# Calculate Return on Equity Using Simulated Data From Model
#####################################################################
calcReturns <- function(countryToUse,simOutput, simOutputOnGrid, PDivs, 
                            controlVarNAP, ParEst, UnobsPosInfo, printTime = 1)
{
    timer1 <- proc.time()[3]

    stateGridList <- createStateGrid(countryToUse,controlVarNAP, ParEst, UnobsPosInfo)

    gridNu        <- stateGridList$gridNu
    gridXX        <- stateGridList$gridXX
    gridSigmaSq   <- stateGridList$gridSigmaSq

    nGridNu       <- length(gridNu)
    nGridXX       <- length(gridXX)
    nGridSigmaSq  <- length(gridSigmaSq)

    gammaU        <- controlVarNAP$gammaU     # Risk-Aversion
    psiU          <- controlVarNAP$psiU       # Intertemporal Elasticity of Substitution
    rhoU          <- controlVarNAP$rhoU       # Discount Rate
    thetaU        <- controlVarNAP$thetaU

    sigmaSqOmega  <- ParEst[bigDataPosInfo$sigmaSqOmega]
    gammma        <- ParEst[bigDataPosInfo$gammma]
    rho           <- ParEst[bigDataPosInfo$rho]
    mu            <- ParEst[bigDataPosInfo$mu][countryToUse]
    chiSq         <- ParEst[bigDataPosInfo$chiSq][countryToUse]
    sigmaSqNu     <- ParEst[bigDataPosInfo$sigmaSqNu][countryToUse]
    sigmaSqConst  <- ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]

    CCwithBreak <- simOutput$CCwithBreak
    CC          <- simOutput$CC
    DD          <- simOutput$DD
    Nu          <- simOutputOnGrid$Nu
    XX          <- simOutputOnGrid$XX
    SigmaSq     <- simOutputOnGrid$SigmaSq

    nSim <- length(CC)

    getCurPos <-
        function(Nu, XX, SigmaSq)
    {
        curNu      <- which(Nu[1]      == gridNu)
        curXX      <- which(XX[1]      == gridXX)
        curSigmaSq <- which(SigmaSq[1] == gridSigmaSq)

        curPos <- (curSigmaSq - 1)*nGridXX*nGridNu + (curXX - 1)*nGridNu + curNu
        return(curPos)
    }


    REq                <- numeric(nSim)
    PDivEq             <- numeric(nSim)
    PDivEqOld          <- exp(PDivs$Equity[getCurPos(Nu[1],XX[1],SigmaSq[1])])
    PDivEq[1]          <- PDivEqOld

    CGrowth   <- numeric(nSim)
    DGrowth   <- numeric(nSim)

    CGrowth[1]   <- NA
    DGrowth[1]   <- NA

    CGrowthWithBreak <- c(NA,exp(diff(CCwithBreak)))


    if (controlVarNAP$getOnePerBond == 1) {
        RBond                    <- numeric(nSim)
        PDivBond                 <- numeric(nSim)
        PDivBondOld              <- exp(PDivs$OnePerBond[getCurPos(Nu[1],XX[1],SigmaSq[1])])
        PDivBond[1]              <- PDivBondOld
    }
    if (controlVarNAP$getPerpetuity == 1) {
        RPerp       <- numeric(nSim)
        PDivPerp    <- numeric(nSim)
        PDivPerpOld <- exp(PDivs$Perpetuity[getCurPos(Nu[1],XX[1],SigmaSq[1])])
        PDivPerp[1] <- PDivPerpOld
    }
    if (controlVarNAP$getLeveredXXEq == 1) {
        RLeveredXXEq             <- numeric(nSim)
        PDivLeveredXXEq          <- numeric(nSim)
        PDivLeveredXXEqOld       <- exp(PDivs$LeveredXXEq[getCurPos(Nu[1],XX[1],SigmaSq[1])])
        PDivLeveredXXEq[1]       <- PDivLeveredXXEqOld
    }

    for (ii in 2:nSim) {
        PDivEqCur        <- exp(PDivs$Equity[getCurPos(Nu[ii],XX[ii],SigmaSq[ii])])

        REq[ii]          <- exp(CC[ii] - CC[ii-1])*PDivEqOld^(-1)*(1+PDivEqCur)

        PDivEq[ii]       <- PDivEqCur
        PDivEqOld        <- PDivEqCur

        CGrowth[ii]      <- exp(CC[ii] - CC[ii-1])
        DGrowth[ii]      <- exp(DD[ii] - DD[ii-1])

        if (controlVarNAP$getOnePerBond == 1) {
            PDivBondCur  <- exp(PDivs$OnePerBond[getCurPos(Nu[ii],XX[ii],SigmaSq[ii])])
            RBond[ii]    <- PDivBondOld^(-1)
            PDivBond[ii] <- PDivBondCur
            PDivBondOld  <- PDivBondCur
        }
        if (controlVarNAP$getPerpetuity == 1) {
            PDivPerpCur  <- exp(PDivs$Perpetuity[getCurPos(Nu[ii],XX[ii],SigmaSq[ii])])
            RPerp[ii]    <- payGrowth*PDivPerpOld^(-1)*(1+PDivPerpCur)
            PDivPerp[ii] <- PDivPerpCur
            PDivPerpOld  <- PDivPerpCur
        }
        if (controlVarNAP$getLeveredXXEquity == 1) {
            PDivLeveredXXEqCur  <- exp(PDivs$LeveredXXEq[getCurPos(Nu[ii],XX[ii],SigmaSq[ii])])
            RLeveredXXEq[ii]    <- exp(DD[ii] - DD[ii-1])*PDivLeveredXXEqOld^(-1)*(1+PDivLeveredXXEqCur)
            PDivLeveredXXEq[ii] <- PDivLeveredXXEqCur
            PDivLeveredXXEqOld  <- PDivLeveredXXEqCur
        }
    }

    output <- list(Equity = list(Return = c(NA,REq[2:length(REq)]),PDiv = PDivEq), CGrowth = CGrowth, CGrowthWithBreak = CGrowthWithBreak, DGrowth = DGrowth)
    if (controlVarNAP$getOnePerBond == 1) {
        output$OnePerBond        <- list(Return = c(NA,RBond[2:length(RBond)]), PDiv = PDivBond)
    }
    if (controlVarNAP$getPerpetuity == 1) {
        output$Perpetuity        <- list(Return = c(NA,RPerp[2:length(RPerp)]), PDiv = PDivPerp)
    }
    if (controlVarNAP$getLeveredXXEq == 1) {
        output$LeveredXXEq       <- list(Return = c(NA,RLeveredXXEq[2:length(RLeveredXXEq)]), PDiv = PDivLeveredXXEq)
    }

    timer1 <- proc.time()[3] - timer1
    if (printTime) {
        cat('Time Calc Returns:   ',timer1,'\n')
    }

    return(output)
}

## Simulate the Model
######################################################################
simulateModel_EZW <- function(countryToUse, controlVarNAP, ParEstimates, 
                                UnobsPosInfo,nSim,nSimBurnin, printStuff = 1)
{
    timer1 <- proc.time()[3]

    simOutput  <- list(NULL)

    #Get parameters
    paramNames <- c("mu",
                    "rho",
                    "gammma",
                    "rhobeta",
                    "sigmaSqConst",
                    "chiSq",
                    "sigmaSqNu",
                    "sigmaSqNuPre",
                    "sigmaSqOmega")

    for (ii in 1:length(paramNames)) {
        eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
        eval(parse(text = paste('simOutput$',paramNames[ii],'<-',paramNames[ii], sep='')))
    }
    utilityParamNames <- c("gammaU", "rhoU")
    for (ii in 1:length(utilityParamNames)){
        eval(parse(text = paste(utilityParamNames[ii],'<- controlVarNAP$',utilityParamNames[ii], sep='')))
        eval(parse(text = paste('simOutput$',utilityParamNames[ii],'<-',utilityParamNames[ii], sep='')))
    }

    phi    <- controlVarNAP$phi
    cutOff <- controlVarNAP$cutOff

    chiSq        <- chiSq[countryToUse]
    sigmaNu      <- sqrt(sigmaSqNu[countryToUse])
    sigmaNuPre   <- sqrt(sigmaSqNuPre[countryToUse])
    sigmaOmega   <- sqrt(sigmaSqOmega)
    sigmaSqConst <- sigmaSqConst[countryToUse]

    # Initialize variables
    XX      <- numeric(nSim+nSimBurnin)
    Eps     <- numeric(nSim+nSimBurnin)
    CC      <- numeric(nSim+nSimBurnin)
    YY      <- numeric(nSim+nSimBurnin)
    DD      <- numeric(nSim+nSimBurnin)
    Eta     <- numeric(nSim+nSimBurnin)
    Nu      <- numeric(nSim+nSimBurnin)
    Omega   <- numeric(nSim+nSimBurnin)
    SigmaSq <- numeric(nSim+nSimBurnin)

    ## Set initial values
    SigmaSq[1] <- max(sigmaSqConst + Omega[1],cutOff)
    XX[1]      <- rnorm(1,0,sqrt(sigmaSqConst))
    YY[1]      <- Eta[1]
    DD[1]      <- 0

    ## Simulate model
    for (ii in 2:(nSim+nSimBurnin)) {
        Eta[ii]     <- rnorm(1,0,sqrt(chiSq*SigmaSq[ii-1]))
        Omega[ii]   <- rnorm(1,0,sigmaOmega)
        SigmaSq[ii] <- max(sigmaSqConst + gammma * (SigmaSq[ii-1] - sigmaSqConst) + Omega[ii],cutOff)
        Eps[ii]     <- rnorm(1,0,sqrt(SigmaSq[ii-1]))
        XX[ii]      <- rho * XX[ii-1] + Eps[ii]
        YY[ii]      <- YY[ii-1] + mu[countryToUse] + XX[ii-1] + Eta[ii]
        DD[ii]      <- DD[ii-1] + mu[countryToUse] + phi * (XX[ii-1] + Eta[ii])
    }
    Nu          <- rnorm(nSim+nSimBurnin,0,sigmaNu)
    NuWithBreak <- c(rnorm(round(56/120*(nSim+nSimBurnin)),0,sigmaNuPre),rnorm(nSim+nSimBurnin - round(56/120*(nSim+nSimBurnin)),0,sigmaNu))

    CC          <- YY + Nu
    CCwithBreak <- YY + NuWithBreak

    simOutput$Eps         <- Eps[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Eta         <- Eta[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Nu          <- Nu[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Omega       <- Omega[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$XX          <- XX[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$SigmaSq     <- SigmaSq[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$CC          <- CC[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$CCwithBreak <- CCwithBreak[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$DD          <- DD[(nSimBurnin+1):(nSim+nSimBurnin)]

    timer1 <- proc.time()[3] - timer1
    if (printStuff) {
        cat('nSim:                  ',nSim,'\n')
        cat('time simulation =      ',timer1,'\n')
    }

    return(simOutput)
}

## Put Simulated Output on Grid
#####################################################################
putSimOutputOnStateGrid <- function(simOutput, controlVarNAP, ParEst, 
                                        UnobsPosInfo, printTime = 1)
{
    timer1 <- proc.time()[3]

    XX            <- simOutput$XX
    Nu            <- simOutput$Nu
    SigmaSq       <- simOutput$SigmaSq

    nSim          <- length(XX)

    XXOnGrid      <- numeric(nSim)
    NuOnGrid      <- numeric(nSim)
    SigmaSqOnGrid <- numeric(nSim)

    stateGridList    <- createStateGrid(countryToUse,controlVarNAP, ParEst, UnobsPosInfo)
    stateGridNu      <- stateGridList$gridNu
    stateGridXX      <- stateGridList$gridXX
    stateGridSigmaSq <- stateGridList$gridSigmaSq

    for (ii in 1:nSim) {
        NuInd <- which.min(abs(stateGridNu-Nu[ii]))
        NuOnGrid[ii] <- stateGridNu[NuInd]

        XXInd  <- which.min(abs(stateGridXX-XX[ii]))
        XXOnGrid[ii] <- stateGridXX[XXInd]

        SigmaSqInd  <- which.min(abs(stateGridSigmaSq-SigmaSq[ii]))
        SigmaSqOnGrid[ii] <- stateGridSigmaSq[SigmaSqInd]
    }

    timer1 <- proc.time()[3] - timer1
    if (printTime) {
        cat('Time Put Sim on Grid:  ',timer1,'\n')
    }

    return(list(Nu = NuOnGrid, XX = XXOnGrid, SigmaSq = SigmaSqOnGrid))
}

## Save Consumption and Asset Returns in a Text File
#####################################################################
saveCAndAPReturnsInTextFile <- function(simOutput, returnsEZW)
{
    lengthReturnsEZW <- length(returnsEZW)
    temp.output <- cbind(simOutput$CC, returnsEZW$Equity$Return, returnsEZW$Equity$PDiv)
    dimnames(temp.output)[[2]] <- c('CC', 'EquityR', 'EquityPDiv')

    if (lengthReturnsEZW > 2) {
        for (ii in 3:lengthReturnsEZW) {
            temp.output <- cbind(temp.output, returnsEZW[[ii]][[1]],returnsEZW[[ii]][[2]])
            dimnames(temp.output)[[2]][4+2*(ii-3)+1] <- paste(names(returnsEZW[ii]),'R', sep='')
            dimnames(temp.output)[[2]][4+2*(ii-3)+2] <- paste(names(returnsEZW[ii]),'PDiv', sep='')
        }
    }
    filename <-  file.path(outDir, 'CAndAPReturns.txt')
    write.table(temp.output, file = filename)

    return(temp.output)
}

## Print Results
#####################################################################
printSummaryStats <- function(returnsAP, controlVarNAP, Pref = 1)
{
    if (Pref == 1) {
        Pref <- 'EZW'
    } else if (Pref == 2) {
        Pref <- 'CRRA'
    } else {
        Pref <- ''
    }

    payGrowth <- controlVarNAP$payGrowth

    options(digits = 5)
    nPer <- length(returnsAP$Equity$Return)

    cat('\n')
    cat('Consumption and Dividend growth\n')
    cat('---------------------------------------\n')
    cat('Consumption: post WWII\n')
    cat('E[  log[C_{t+1}/C_{t}]] = ',mean(log(returnsAP$CGrowth[2:nPer])),'\n')
    cat('std[log[C_{t+1}/C_{t}]] = ',sd(log(returnsAP$CGrowth[2:nPer])),'\n')
    cat('AC1[log[C_{t+1}/C_{t}]] = ',cor(log(returnsAP$CGrowth[2:(nPer-1)]),log(returnsAP$CGrowth[3:nPer])),'\n')
    cat('Consumption: all sample with break\n')
    cat('E[  log[C_{t+1}/C_{t}]] = ',mean(log(returnsAP$CGrowthWithBreak[2:nPer])),'\n')
    cat('std[log[C_{t+1}/C_{t}]] = ',sd(log(returnsAP$CGrowthWithBreak[2:nPer])),'\n')
    cat('AC1[log[C_{t+1}/C_{t}]] = ',cor(log(returnsAP$CGrowthWithBreak[2:(nPer-1)]),log(returnsAP$CGrowthWithBreak[3:nPer])),'\n')
    cat('Dividends: post WWII\n')
    cat('E[log[D_{t+1}/D_{t}]]   = ',mean(log(returnsAP$DGrowth[2:nPer])),'\n')
    cat('std[log[D_{t+1}/D_{t}]] = ',sd(log(returnsAP$DGrowth[2:nPer])),'\n')
    cat('AC1[log[D_{t+1}/D_{t}]] = ',cor(log(returnsAP$DGrowth[2:(nPer-1)]),log(returnsAP$DGrowth[3:nPer])),'\n')

    cat('\n')
    cat('Asset Returns for ',Pref,' Rep Consumer\n')
    cat('---------------------------------------\n')
    cat('Unlevered Equity (nonlinear): \n')
    cat('   E[R]:               ',mean(returnsAP$Equity$Return[2:nPer]),'\n')
    cat('   std[R]:             ',sd(returnsAP$Equity$Return[2:nPer]),'\n')
    if (controlVarNAP$getOnePerBond == 1) {
        cat('One Per Bond (nonlinear):\n')
        cat('   E[R]:                 ',mean(returnsAP$OnePerBond$Return[2:nPer]),'\n')
        cat('   std[R]:               ',sd(returnsAP$OnePerBond$Return[2:nPer]),'\n')
        cat('Unlevered Equity Premium (nonlinear):\n')
        cat('   E[R - Rf]:            ',mean(returnsAP$Equity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]),'\n')
        cat('   std(R - Rf):          ',sd(returnsAP$Equity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
        cat('   E[R - Rf]/std(R - Rf):',(mean(returnsAP$Equity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$Equity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
    }
    if (controlVarNAP$getLeveredXXEq == 1) {
        cat('Levered XX Equity (nonlinear):\n')
        cat('   E[R]:                 ',mean(returnsAP$LeveredXXEq$Return[2:nPer]),'\n')
        cat('   std[R]:               ',sd(returnsAP$LeveredXXEq$Return[2:nPer]),'\n')
        cat('Levered XX Equity Premium (nonlinear): \n')
        cat('   E[R - Rf]:            ',mean(returnsAP$LeveredXXEq$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]),'\n')
        cat('   std(R - Rf):          ',sd(returnsAP$LeveredXXEq$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
        cat('   E[R - Rf]/std(R - Rf):',(mean(returnsAP$LeveredXXEq$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$LeveredXXEq$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer]),'\n')
    }

    cat('\n')
    cat('Price-Dividend Ratios for ',Pref,' Rep Consumer\n')
    cat('-----------------------------------------------------------\n')
    cat('Unlevered Equity (nonlinear):\n')
    cat('   E[Log[P/Div]]:           ',mean(log(returnsAP$Equity$PDiv)),'\n')
    cat('   Std[log[P/Div]]:         ',sd(log(returnsAP$Equity$PDiv)),'\n')
    cat('   AC1[log[P/Div]]:         ',cor(log(returnsAP$Equity$PDiv[1:(nPer-1)]),log(returnsAP$Equity$PDiv[2:nPer])),'\n')

    if (controlVarNAP$getOnePerBond == 1) {
        cat('One Per Bond (nonlinear):\n')
        cat('   E[log[P/Div]]:          ',mean(log(returnsAP$OnePerBond$PDiv)),'\n')
        cat('   std[log[P/Div]]:        ',sd(log(returnsAP$OnePerBond$PDiv)),'\n')
        cat('   AC1[log[P/Div]]:        ',cor(log(returnsAP$OnePerBond$PDiv[2:nPer]),log(returnsAP$OnePerBond$PDiv[1:(nPer-1)])),'\n')
    }
    if (controlVarNAP$getLeveredXXEq == 1) {
        cat('Levered XX equity (nonlinear):\n')
        cat('   E[Log[P/Div]]:          ',mean(log(returnsAP$LeveredXXEq$PDiv)),'\n')
        cat('   std[Log[P/Div]]:        ',sd(log(returnsAP$LeveredXXEq$PDiv)),'\n')
        cat('   AC1[Log[P/Div]]:        ',cor(log(returnsAP$LeveredXXEq$PDiv[1:(nPer-1)]),log(returnsAP$LeveredXXEq$PDiv[2:nPer])),'\n')
    }
}

## Plot Diagnostic Plots
#####################################################################
plotDiagnostics <- function(simOutput, returnsEZW)
{
    nSim <- length(simOutput$CC)

    ii <- which.max(abs(simOutput$ZZ)) - 1

    ReturnsToPlot <- max(ii-25,1):min(ii+25,nSim-1)

    filename <-  file.path(outDir, 'DiagnosticPlots.pdf')
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))

    plot(as.ts(returnsEZW$Equity$Return[ReturnsToPlot]), ylim = c(-1,3),
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$Return[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()

    filename <-  file.path(outDir, 'DiagnosticPlotsPDiv.pdf')
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))

    plot(as.ts(returnsEZW$Equity$PDiv[ReturnsToPlot]), ylim = c(-1,20),
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$PDiv[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()

    ReturnsToPlot <- 200:300
    filename <-  file.path(outDir, 'DiagnosticPlots2.pdf')
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))

    plot(as.ts(returnsEZW$Equity$Return[ReturnsToPlot]), ylim = c(-1,3),
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$Return[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()

    filename <-  file.path(outDir, 'DiagnosticPlots2PDiv.pdf')
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))

    plot(as.ts(returnsEZW$Equity$PDiv[ReturnsToPlot]), ylim = c(-1,20),
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$PDiv[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()
}

## Predictability Regressions
#####################################################################
predictability_LeveredLRR <- function(countryToUse,PDivs, ParEst, 
                                        controlVarNAP, bigDataPosInfo)
{
    nnMonteCarlo              <- 2000

    controlVarNAP$nSim        <- 77  # Number of years in Beeler-Campbell regressions plus one
    controlVarNAP$nSimBurnin  <- 100

    # Initialize variables for excess returns statistics
    beta.er1        <- matrix(0,1,nnMonteCarlo)
    beta.er3        <- matrix(0,1,nnMonteCarlo)
    beta.er5        <- matrix(0,1,nnMonteCarlo)
    beta.er10       <- matrix(0,1,nnMonteCarlo)

    r.squared.er1   <- matrix(0,1,nnMonteCarlo)
    r.squared.er3   <- matrix(0,1,nnMonteCarlo)
    r.squared.er5   <- matrix(0,1,nnMonteCarlo)
    r.squared.er10  <- matrix(0,1,nnMonteCarlo)

    # Initialize variables for START of the period consumption statistics
    beta.cgs1       <- matrix(0,1,nnMonteCarlo)
    beta.cgs3       <- matrix(0,1,nnMonteCarlo)
    beta.cgs5       <- matrix(0,1,nnMonteCarlo)
    beta.cgs10      <- matrix(0,1,nnMonteCarlo)

    r.squared.cgs1  <- matrix(0,1,nnMonteCarlo)
    r.squared.cgs3  <- matrix(0,1,nnMonteCarlo)
    r.squared.cgs5  <- matrix(0,1,nnMonteCarlo)
    r.squared.cgs10 <- matrix(0,1,nnMonteCarlo)

    # Initialize variables for END of the period consumption statistics
    beta.cge1       <- matrix(0,1,nnMonteCarlo)
    beta.cge3       <- matrix(0,1,nnMonteCarlo)
    beta.cge5       <- matrix(0,1,nnMonteCarlo)
    beta.cge10      <- matrix(0,1,nnMonteCarlo)

    r.squared.cge1  <- matrix(0,1,nnMonteCarlo)
    r.squared.cge3  <- matrix(0,1,nnMonteCarlo)
    r.squared.cge5  <- matrix(0,1,nnMonteCarlo)
    r.squared.cge10 <- matrix(0,1,nnMonteCarlo)

    # Initialize variables for dividend statistics
    beta.d1         <- matrix(0,1,nnMonteCarlo)
    beta.d3         <- matrix(0,1,nnMonteCarlo)
    beta.d5         <- matrix(0,1,nnMonteCarlo)
    beta.d10        <- matrix(0,1,nnMonteCarlo)

    r.squared.d1    <- matrix(0,1,nnMonteCarlo)
    r.squared.d3    <- matrix(0,1,nnMonteCarlo)
    r.squared.d5    <- matrix(0,1,nnMonteCarlo)
    r.squared.d10   <- matrix(0,1,nnMonteCarlo)

    # Initialize variables for simple volatility predictability stats
    beta.vol1       <- matrix(0,1,nnMonteCarlo)
    beta.vol3       <- matrix(0,1,nnMonteCarlo)
    beta.vol5       <- matrix(0,1,nnMonteCarlo)
    beta.vol10      <- matrix(0,1,nnMonteCarlo)

    r.squared.vol1  <- matrix(0,1,nnMonteCarlo)
    r.squared.vol3  <- matrix(0,1,nnMonteCarlo)
    r.squared.vol5  <- matrix(0,1,nnMonteCarlo)
    r.squared.vol10 <- matrix(0,1,nnMonteCarlo)

    # Initialize variables for model volatility predictability stats
    beta.ModelVol1       <- matrix(0,1,nnMonteCarlo)
    beta.ModelVol3       <- matrix(0,1,nnMonteCarlo)
    beta.ModelVol5       <- matrix(0,1,nnMonteCarlo)
    beta.ModelVol10      <- matrix(0,1,nnMonteCarlo)

    r.squared.ModelVol1  <- matrix(0,1,nnMonteCarlo)
    r.squared.ModelVol3  <- matrix(0,1,nnMonteCarlo)
    r.squared.ModelVol5  <- matrix(0,1,nnMonteCarlo)
    r.squared.ModelVol10 <- matrix(0,1,nnMonteCarlo)

    for (kk in 1:nnMonteCarlo){

        simOutput       <- simulateModel_EZW(countryToUse,controlVarNAP, ParEst, 
                                            bigDataPosInfo, controlVarNAP$nSim,
                                            controlVarNAP$nSimBurnin, printStuff = 0)
        
        simOutputOnGrid <- putSimOutputOnStateGrid(simOutput, controlVarNAP, 
                                        ParEst, bigDataPosInfo, printTime = 0)

        returnsEZW      <- calcReturns(countryToUse,simOutput, simOutputOnGrid, 
                                        PDivs, controlVarNAP, ParEst, 
                                        bigDataPosInfo, printTime = 0)

        nPeriods        <- length(returnsEZW$Equity$PDiv)

        xx              <- simOutputOnGrid$XX
        sigmaSq         <- simOutputOnGrid$SigmaSq

        pd              <- log(returnsEZW$LeveredXXEq$PDiv)
        er              <- log(returnsEZW$LeveredXXEq$Return) - log(returnsEZW$OnePerBond$Return)
        cg              <- log(returnsEZW$CGrowth)

        ## Excess Stock Predictability
        ##############################

        # 1-year horizon
        er1         <- er[2:nPeriods]
        pd1         <- pd[1:(nPeriods-1)]
        output      <- lm(er1 ~ pd1)
        beta1       <- output$coefficient[2]
        result      <- summary(output)
        r.squared1  <- result$r.squared

        # 3-year horizon
        er3         <- numeric((nPeriods-3))
        for (mm in 1:(nPeriods-3)){
             er3[mm] <- sum(er[(mm+1):(mm+3)])
        }
        pd3         <- pd[1:(nPeriods-3)]
        output      <- lm(er3 ~ pd3)
        beta3       <- output$coefficient[2]
        result      <- summary(output)
        r.squared3  <- result$r.squared

        # 5-year horizon
        er5         <- numeric((nPeriods-5))
        for (mm in 1:(nPeriods-5)){
             er5[mm] <- sum(er[(mm+1):(mm+5)])
        }
        pd5         <- pd[1:(nPeriods-5)]
        output      <- lm(er5 ~ pd5)
        beta5       <- output$coefficient[2]
        result      <- summary(output)
        r.squared5  <- result$r.squared

        # 10-year horizon
        er10        <- numeric((nPeriods-10))
        for (mm in 1:(nPeriods-10)){
             er10[mm] <- sum(er[(mm+1):(mm+10)])
        }
        pd10        <- pd[1:(nPeriods-10)]
        output      <- lm(er10 ~ pd10)
        beta10      <- output$coefficient[2]
        result      <- summary(output)
        r.squared10 <- result$r.squared

        # Save result
        beta.er1[1,kk]       <- beta1
        beta.er3[1,kk]       <- beta3
        beta.er5[1,kk]       <- beta5
        beta.er10[1,kk]      <- beta10

        r.squared.er1[1,kk]  <- r.squared1
        r.squared.er3[1,kk]  <- r.squared3
        r.squared.er5[1,kk]  <- r.squared5
        r.squared.er10[1,kk] <- r.squared10

        ## Beginning of period Consumption predictability
        #################################################
        cgs1        <- cg[2:nPeriods]
        pd1         <- pd[1:(nPeriods-1)]
        output      <- lm(cgs1 ~ pd1)
        beta1       <- output$coefficient[2]
        result      <- summary(output)
        r.squared1  <- result$r.squared

        # 3-year horizon
        cgs3        <- numeric((nPeriods-3))
        for (mm in 1:(nPeriods-3)){
             cgs3[mm] <- sum(cg[(mm+1):(mm+3)])
        }
        pd3         <- pd[1:(nPeriods-3)]
        output      <- lm(cgs3 ~ pd3)
        beta3       <- output$coefficient[2]
        result      <- summary(output)
        r.squared3  <- result$r.squared

        # 5-year horizon
        cgs5        <- numeric((nPeriods-5))
        for (mm in 1:(nPeriods-5)){
             cgs5[mm] <- sum(cg[(mm+1):(mm+5)])
        }
        pd5         <- pd[1:(nPeriods-5)]
        output      <- lm(cgs5 ~ pd5)
        beta5       <- output$coefficient[2]
        result      <- summary(output)
        r.squared5  <- result$r.squared

        # 10-year horizon
        cgs10       <- numeric((nPeriods-10))
        for (mm in 1:(nPeriods-10)){
             cgs10[mm] <- sum(cg[(mm+1):(mm+10)])
        }
        pd10        <- pd[1:(nPeriods-10)]
        output      <- lm(cgs10 ~ pd10)
        beta10      <- output$coefficient[2]
        result      <- summary(output)
        r.squared10 <- result$r.squared

        # Save result
        beta.cgs1[1,kk] <- beta1
        beta.cgs3[1,kk] <- beta3
        beta.cgs5[1,kk] <- beta5
        beta.cgs10[1,kk] <- beta10

        r.squared.cgs1[1,kk] <- r.squared1
        r.squared.cgs3[1,kk] <- r.squared3
        r.squared.cgs5[1,kk] <- r.squared5
        r.squared.cgs10[1,kk] <- r.squared10

        ## End of period Consumption predictability
        ###########################################
        cge1        <- cg[2:nPeriods]
        pd1         <- pd[2:nPeriods]
        output      <- lm(cge1 ~ pd1)
        beta1       <- output$coefficient[2]
        result      <- summary(output)
        r.squared1  <- result$r.squared

        # 3-year horizon
        cge3        <- numeric((nPeriods-3))
        for (mm in 1:(nPeriods-3)){
             cge3[mm] <- sum(cg[(mm+1):(mm+3)])
        }
        pd3         <- pd[2:(nPeriods-(3-1))]
        output      <- lm(cge3 ~ pd3)
        beta3       <- output$coefficient[2]
        result      <- summary(output)
        r.squared3  <- result$r.squared

        # 5-year horizon
        cge5        <- numeric((nPeriods-5))
        for (mm in 1:(nPeriods-5)){
             cge5[mm] <- sum(cg[(mm+1):(mm+5)])
        }
        pd5         <- pd[2:(nPeriods-(5-1))]
        output      <- lm(cge5 ~ pd5)
        beta5       <- output$coefficient[2]
        result      <- summary(output)
        r.squared5  <- result$r.squared

        # 10-year horizon
        cge10       <- numeric((nPeriods-10))
        for (mm in 1:(nPeriods-10)){
             cge10[mm] <- sum(cg[(mm+1):(mm+10)])
        }
        pd10        <- pd[2:(nPeriods-(10-1))]
        output      <- lm(cge10 ~ pd10)
        beta10      <- output$coefficient[2]
        result      <- summary(output)
        r.squared10 <- result$r.squared

        # Save result
        beta.cge1[1,kk]  <- beta1
        beta.cge3[1,kk]  <- beta3
        beta.cge5[1,kk]  <- beta5
        beta.cge10[1,kk] <- beta10

        r.squared.cge1[1,kk]  <- r.squared1
        r.squared.cge3[1,kk]  <- r.squared3
        r.squared.cge5[1,kk]  <- r.squared5
        r.squared.cge10[1,kk] <- r.squared10

        ## Simple Volatility predictability
        ###########################################
        regression <- ar(cg[-c(1)],aic = FALSE,order.max = 1) ## Estimate AR(1) process and extract residuals
        vol        <- abs(regression$resid)
        vol        <- vol[!is.na(vol)]

        # 1-year horizon
        vol1        <- log(vol)
        pd1         <- pd[2:(nPeriods-1)]
        output      <- lm(vol1 ~ pd1)
        beta1       <- output$coefficient[2]
        result      <- summary(output)
        r.squared1  <- result$r.squared

        # 3-year horizon
        vol3        <- runSum(vol,3)
        vol3        <- log(vol3[!is.na(vol3)])
        pd3         <- pd[2:(nPeriods-3)]
        output      <- lm(vol3 ~ pd3)
        beta3       <- output$coefficient[2]
        result      <- summary(output)
        r.squared3  <- result$r.squared

        # 5-year horizon
        vol5        <- runSum(vol,5)
        vol5        <- log(vol5[!is.na(vol5)])
        pd5         <- pd[2:(nPeriods-5)]
        output      <- lm(vol5 ~ pd5)
        beta5       <- output$coefficient[2]
        result      <- summary(output)
        r.squared5  <- result$r.squared

        # 10-year horizon
        vol10       <- runSum(vol,10)
        vol10       <- log(vol10[!is.na(vol10)])
        pd10        <- pd[2:(nPeriods-10)]
        output      <- lm(vol10 ~ pd10)
        beta10      <- output$coefficient[2]
        result      <- summary(output)
        r.squared10 <- result$r.squared

        # Save result
        beta.vol1[1,kk]       <- beta1
        beta.vol3[1,kk]       <- beta3
        beta.vol5[1,kk]       <- beta5
        beta.vol10[1,kk]      <- beta10

        r.squared.vol1[1,kk]  <- r.squared1
        r.squared.vol3[1,kk]  <- r.squared3
        r.squared.vol5[1,kk]  <- r.squared5
        r.squared.vol10[1,kk] <- r.squared10

        ## Model Volatility predictability
        ###########################################

        # 1-year horizon
        vol1        <- log(sigmaSq[3:nPeriods])
        pd1         <- pd[2:(nPeriods-1)]
        output      <- lm(vol1 ~ pd1)
        beta1       <- output$coefficient[2]
        result      <- summary(output)
        r.squared1  <- result$r.squared

        # 3-year horizon
        vol3        <- runSum(sigmaSq[3:nPeriods],3)
        vol3        <- log(vol3[!is.na(vol3)])
        pd3         <- pd[2:(nPeriods-3)]
        output      <- lm(vol3 ~ pd3)
        beta3       <- output$coefficient[2]
        result      <- summary(output)
        r.squared3  <- result$r.squared

        # 5-year horizon
        vol5        <- runSum(sigmaSq[3:nPeriods],5)
        vol5        <- log(vol5[!is.na(vol5)])
        pd5         <- pd[2:(nPeriods-5)]
        output      <- lm(vol5 ~ pd5)
        beta5       <- output$coefficient[2]
        result      <- summary(output)
        r.squared5  <- result$r.squared

        # 10-year horizon
        vol10       <- runSum(sigmaSq[3:nPeriods],10)
        vol10       <- log(vol10[!is.na(vol10)])
        pd10        <- pd[2:(nPeriods-10)]
        output      <- lm(vol10 ~ pd10)
        beta10      <- output$coefficient[2]
        result      <- summary(output)
        r.squared10 <- result$r.squared

        # Save result
        beta.ModelVol1[1,kk]       <- beta1
        beta.ModelVol3[1,kk]       <- beta3
        beta.ModelVol5[1,kk]       <- beta5
        beta.ModelVol10[1,kk]      <- beta10

        r.squared.ModelVol1[1,kk]  <- r.squared1
        r.squared.ModelVol3[1,kk]  <- r.squared3
        r.squared.ModelVol5[1,kk]  <- r.squared5
        r.squared.ModelVol10[1,kk] <- r.squared10
     }

     ## Create Statistics over Monte Carlo
     ######################################

     ## Excess Stock Predictability
     beta.er1.median  <- apply(beta.er1,1,median)
     beta.er3.median  <- apply(beta.er3,1,median)
     beta.er5.median  <- apply(beta.er5,1,median)
     beta.er10.median <- apply(beta.er10,1,median)

     r.squared.er1.median  <- apply(r.squared.er1,1,median)
     r.squared.er3.median  <- apply(r.squared.er3,1,median)
     r.squared.er5.median  <- apply(r.squared.er5,1,median)
     r.squared.er10.median <- apply(r.squared.er10,1,median)

     beta.er1.q025  <- apply(beta.er1,1,quantile, probs = 0.025)
     beta.er3.q025  <- apply(beta.er3,1,quantile, probs = 0.025)
     beta.er5.q025  <- apply(beta.er5,1,quantile, probs = 0.025)
     beta.er10.q025 <- apply(beta.er10,1,quantile, probs = 0.025)

     r.squared.er1.q025  <- apply(r.squared.er1,1,quantile, probs = 0.025)
     r.squared.er3.q025  <- apply(r.squared.er3,1,quantile, probs = 0.025)
     r.squared.er5.q025  <- apply(r.squared.er5,1,quantile, probs = 0.025)
     r.squared.er10.q025 <- apply(r.squared.er10,1,quantile, probs = 0.025)

     beta.er1.q975  <- apply(beta.er1,1,quantile, probs = 0.975)
     beta.er3.q975  <- apply(beta.er3,1,quantile, probs = 0.975)
     beta.er5.q975  <- apply(beta.er5,1,quantile, probs = 0.975)
     beta.er10.q975 <- apply(beta.er10,1,quantile, probs = 0.975)

     r.squared.er1.q975  <- apply(r.squared.er1,1,quantile, probs = 0.975)
     r.squared.er3.q975  <- apply(r.squared.er3,1,quantile, probs = 0.975)
     r.squared.er5.q975  <- apply(r.squared.er5,1,quantile, probs = 0.975)
     r.squared.er10.q975 <- apply(r.squared.er10,1,quantile, probs = 0.975)

     ## Consumption predictability
     beta.cgs1.median <- apply(beta.cgs1,1,median)
     beta.cgs3.median <- apply(beta.cgs3,1,median)
     beta.cgs5.median <- apply(beta.cgs5,1,median)
     beta.cgs10.median <- apply(beta.cgs10,1,median)

     r.squared.cgs1.median <- apply(r.squared.cgs1,1,median)
     r.squared.cgs3.median <- apply(r.squared.cgs3,1,median)
     r.squared.cgs5.median <- apply(r.squared.cgs5,1,median)
     r.squared.cgs10.median <- apply(r.squared.cgs10,1,median)

     beta.cgs1.q025  <- apply(beta.cgs1,1,quantile, probs = 0.025)
     beta.cgs3.q025  <- apply(beta.cgs3,1,quantile, probs = 0.025)
     beta.cgs5.q025  <- apply(beta.cgs5,1,quantile, probs = 0.025)
     beta.cgs10.q025 <- apply(beta.cgs10,1,quantile, probs = 0.025)

     r.squared.cgs1.q025  <- apply(r.squared.cgs1,1,quantile, probs = 0.025)
     r.squared.cgs3.q025  <- apply(r.squared.cgs3,1,quantile, probs = 0.025)
     r.squared.cgs5.q025  <- apply(r.squared.cgs5,1,quantile, probs = 0.025)
     r.squared.cgs10.q025 <- apply(r.squared.cgs10,1,quantile, probs = 0.025)

     beta.cgs1.q975  <- apply(beta.cgs1,1,quantile, probs = 0.975)
     beta.cgs3.q975  <- apply(beta.cgs3,1,quantile, probs = 0.975)
     beta.cgs5.q975  <- apply(beta.cgs5,1,quantile, probs = 0.975)
     beta.cgs10.q975 <- apply(beta.cgs10,1,quantile, probs = 0.975)

     r.squared.cgs1.q975  <- apply(r.squared.cgs1,1,quantile, probs = 0.975)
     r.squared.cgs3.q975  <- apply(r.squared.cgs3,1,quantile, probs = 0.975)
     r.squared.cgs5.q975  <- apply(r.squared.cgs5,1,quantile, probs = 0.975)
     r.squared.cgs10.q975 <- apply(r.squared.cgs10,1,quantile, probs = 0.975)


     ## Consumption predictability
     beta.cge1.median <- apply(beta.cge1,1,median)
     beta.cge3.median <- apply(beta.cge3,1,median)
     beta.cge5.median <- apply(beta.cge5,1,median)
     beta.cge10.median <- apply(beta.cge10,1,median)

     r.squared.cge1.median <- apply(r.squared.cge1,1,median)
     r.squared.cge3.median <- apply(r.squared.cge3,1,median)
     r.squared.cge5.median <- apply(r.squared.cge5,1,median)
     r.squared.cge10.median <- apply(r.squared.cge10,1,median)

     beta.cge1.q025  <- apply(beta.cge1,1,quantile, probs = 0.025)
     beta.cge3.q025  <- apply(beta.cge3,1,quantile, probs = 0.025)
     beta.cge5.q025  <- apply(beta.cge5,1,quantile, probs = 0.025)
     beta.cge10.q025 <- apply(beta.cge10,1,quantile, probs = 0.025)

     r.squared.cge1.q025  <- apply(r.squared.cge1,1,quantile, probs = 0.025)
     r.squared.cge3.q025  <- apply(r.squared.cge3,1,quantile, probs = 0.025)
     r.squared.cge5.q025  <- apply(r.squared.cge5,1,quantile, probs = 0.025)
     r.squared.cge10.q025 <- apply(r.squared.cge10,1,quantile, probs = 0.025)

     beta.cge1.q975  <- apply(beta.cge1,1,quantile, probs = 0.975)
     beta.cge3.q975  <- apply(beta.cge3,1,quantile, probs = 0.975)
     beta.cge5.q975  <- apply(beta.cge5,1,quantile, probs = 0.975)
     beta.cge10.q975 <- apply(beta.cge10,1,quantile, probs = 0.975)

     r.squared.cge1.q975  <- apply(r.squared.cge1,1,quantile, probs = 0.975)
     r.squared.cge3.q975  <- apply(r.squared.cge3,1,quantile, probs = 0.975)
     r.squared.cge5.q975  <- apply(r.squared.cge5,1,quantile, probs = 0.975)
     r.squared.cge10.q975 <- apply(r.squared.cge10,1,quantile, probs = 0.975)

     ## Simple Volatility predictability
     beta.vol1.median       <- apply(beta.vol1,1,median)
     beta.vol3.median       <- apply(beta.vol3,1,median)
     beta.vol5.median       <- apply(beta.vol5,1,median)
     beta.vol10.median      <- apply(beta.vol10,1,median)

     r.squared.vol1.median  <- apply(r.squared.vol1,1,median)
     r.squared.vol3.median  <- apply(r.squared.vol3,1,median)
     r.squared.vol5.median  <- apply(r.squared.vol5,1,median)
     r.squared.vol10.median <- apply(r.squared.vol10,1,median)

     beta.vol1.q025          <- apply(beta.vol1,1,quantile, probs = 0.025)
     beta.vol3.q025          <- apply(beta.vol3,1,quantile, probs = 0.025)
     beta.vol5.q025          <- apply(beta.vol5,1,quantile, probs = 0.025)
     beta.vol10.q025         <- apply(beta.vol10,1,quantile, probs = 0.025)

     r.squared.vol1.q025     <- apply(r.squared.vol1,1,quantile, probs = 0.025)
     r.squared.vol3.q025     <- apply(r.squared.vol3,1,quantile, probs = 0.025)
     r.squared.vol5.q025     <- apply(r.squared.vol5,1,quantile, probs = 0.025)
     r.squared.vol10.q025    <- apply(r.squared.vol10,1,quantile, probs = 0.025)

     beta.vol1.q975          <- apply(beta.vol1,1,quantile, probs = 0.975)
     beta.vol3.q975          <- apply(beta.vol3,1,quantile, probs = 0.975)
     beta.vol5.q975          <- apply(beta.vol5,1,quantile, probs = 0.975)
     beta.vol10.q975         <- apply(beta.vol10,1,quantile, probs = 0.975)

     r.squared.vol1.q975     <- apply(r.squared.vol1,1,quantile, probs = 0.975)
     r.squared.vol3.q975     <- apply(r.squared.vol3,1,quantile, probs = 0.975)
     r.squared.vol5.q975     <- apply(r.squared.vol5,1,quantile, probs = 0.975)
     r.squared.vol10.q975    <- apply(r.squared.vol10,1,quantile, probs = 0.975)



     ## Simple Volatility predictability
     beta.ModelVol1.median       <- apply(beta.ModelVol1,1,median)
     beta.ModelVol3.median       <- apply(beta.ModelVol3,1,median)
     beta.ModelVol5.median       <- apply(beta.ModelVol5,1,median)
     beta.ModelVol10.median      <- apply(beta.ModelVol10,1,median)

     r.squared.ModelVol1.median  <- apply(r.squared.ModelVol1,1,median)
     r.squared.ModelVol3.median  <- apply(r.squared.ModelVol3,1,median)
     r.squared.ModelVol5.median  <- apply(r.squared.ModelVol5,1,median)
     r.squared.ModelVol10.median <- apply(r.squared.ModelVol10,1,median)

     beta.ModelVol1.q025          <- apply(beta.ModelVol1,1,quantile, probs = 0.025)
     beta.ModelVol3.q025          <- apply(beta.ModelVol3,1,quantile, probs = 0.025)
     beta.ModelVol5.q025          <- apply(beta.ModelVol5,1,quantile, probs = 0.025)
     beta.ModelVol10.q025         <- apply(beta.ModelVol10,1,quantile, probs = 0.025)

     r.squared.ModelVol1.q025     <- apply(r.squared.ModelVol1,1,quantile, probs = 0.025)
     r.squared.ModelVol3.q025     <- apply(r.squared.ModelVol3,1,quantile, probs = 0.025)
     r.squared.ModelVol5.q025     <- apply(r.squared.ModelVol5,1,quantile, probs = 0.025)
     r.squared.ModelVol10.q025    <- apply(r.squared.ModelVol10,1,quantile, probs = 0.025)

     beta.ModelVol1.q975          <- apply(beta.ModelVol1,1,quantile, probs = 0.975)
     beta.ModelVol3.q975          <- apply(beta.ModelVol3,1,quantile, probs = 0.975)
     beta.ModelVol5.q975          <- apply(beta.ModelVol5,1,quantile, probs = 0.975)
     beta.ModelVol10.q975         <- apply(beta.ModelVol10,1,quantile, probs = 0.975)

     r.squared.ModelVol1.q975     <- apply(r.squared.ModelVol1,1,quantile, probs = 0.975)
     r.squared.ModelVol3.q975     <- apply(r.squared.ModelVol3,1,quantile, probs = 0.975)
     r.squared.ModelVol5.q975     <- apply(r.squared.ModelVol5,1,quantile, probs = 0.975)
     r.squared.ModelVol10.q975    <- apply(r.squared.ModelVol10,1,quantile, probs = 0.975)

    rm(er,er1,er3,er5,cgs1,cgs3,cgs5,cge1,cge3,cge5)

    er1 <- list(beta.median      = beta.er1.median,
                beta.q025         = beta.er1.q025,
                beta.q975         = beta.er1.q975,
                r.squared.median = r.squared.er1.median,
                r.squared.q025    = r.squared.er1.q025,
                r.squared.q975    = r.squared.er1.q975)

    er3 <- list(beta.median      = beta.er3.median,
                beta.q025         = beta.er3.q025,
                beta.q975         = beta.er3.q975,
                r.squared.median = r.squared.er3.median,
                r.squared.q025    = r.squared.er3.q025,
                r.squared.q975    = r.squared.er3.q975)

    er5 <- list(beta.median      = beta.er5.median,
                beta.q025         = beta.er5.q025,
                beta.q975         = beta.er5.q975,
                r.squared.median = r.squared.er5.median,
                r.squared.q025    = r.squared.er5.q025,
                r.squared.q975    = r.squared.er5.q975)

    er10 <- list(beta.median     = beta.er10.median,
                beta.q025         = beta.er10.q025,
                beta.q975         = beta.er10.q975,
                r.squared.median = r.squared.er10.median,
                r.squared.q025    = r.squared.er10.q025,
                r.squared.q975    = r.squared.er10.q975)

    er <- list(er1 = er1,
               er3 = er3,
               er5 = er5,
               er10 = er10)


    cgs1 <- list(beta.median     = beta.cgs1.median,
                beta.q025         = beta.cgs1.q025,
                beta.q975         = beta.cgs1.q975,
                r.squared.median = r.squared.cgs1.median,
                r.squared.q025    = r.squared.cgs1.q025,
                r.squared.q975    = r.squared.cgs1.q975)

    cgs3 <- list(beta.median     = beta.cgs3.median,
                beta.q025         = beta.cgs3.q025,
                beta.q975         = beta.cgs3.q975,
                r.squared.median = r.squared.cgs3.median,
                r.squared.q025    = r.squared.cgs3.q025,
                r.squared.q975    = r.squared.cgs3.q975)

    cgs5 <- list(beta.median     = beta.cgs5.median,
                beta.q025         = beta.cgs5.q025,
                beta.q975         = beta.cgs5.q975,
                r.squared.median = r.squared.cgs5.median,
                r.squared.q025    = r.squared.cgs5.q025,
                r.squared.q975    = r.squared.cgs5.q975)

    cgs10 <- list(beta.median    = beta.cgs10.median,
                beta.q025         = beta.cgs10.q025,
                beta.q975         = beta.cgs10.q975,
                r.squared.median = r.squared.cgs10.median,
                r.squared.q025    = r.squared.cgs10.q025,
                r.squared.q975    = r.squared.cgs10.q975)

    cgs <- list(cgs1 = cgs1,
               cgs3 = cgs3,
               cgs5 = cgs5,
               cgs10 = cgs10)

    cge1 <- list(beta.median     = beta.cge1.median,
                beta.q025         = beta.cge1.q025,
                beta.q975         = beta.cge1.q975,
                r.squared.median = r.squared.cge1.median,
                r.squared.q025    = r.squared.cge1.q025,
                r.squared.q975    = r.squared.cge1.q975)

    cge3 <- list(beta.median     = beta.cge3.median,
                beta.q025         = beta.cge3.q025,
                beta.q975         = beta.cge3.q975,
                r.squared.median = r.squared.cge3.median,
                r.squared.q025    = r.squared.cge3.q025,
                r.squared.q975    = r.squared.cge3.q975)

    cge5 <- list(beta.median     = beta.cge5.median,
                beta.q025         = beta.cge5.q025,
                beta.q975         = beta.cge5.q975,
                r.squared.median = r.squared.cge5.median,
                r.squared.q025    = r.squared.cge5.q025,
                r.squared.q975    = r.squared.cge5.q975)

    cge10 <- list(beta.median    = beta.cge10.median,
                beta.q025         = beta.cge10.q025,
                beta.q975         = beta.cge10.q975,
                r.squared.median = r.squared.cge10.median,
                r.squared.q025    = r.squared.cge10.q025,
                r.squared.q975    = r.squared.cge10.q975)

    cge <- list(cge1 = cge1,
                cge3 = cge3,
                cge5 = cge5,
                cge10 = cge10)

    vol1 <- list(beta.median     = beta.vol1.median,
                beta.q025         = beta.vol1.q025,
                beta.q975         = beta.vol1.q975,
                r.squared.median = r.squared.vol1.median,
                r.squared.q025    = r.squared.vol1.q025,
                r.squared.q975    = r.squared.vol1.q975)

    vol3 <- list(beta.median     = beta.vol3.median,
                beta.q025         = beta.vol3.q025,
                beta.q975         = beta.vol3.q975,
                r.squared.median = r.squared.vol3.median,
                r.squared.q025    = r.squared.vol3.q025,
                r.squared.q975    = r.squared.vol3.q975)

    vol5 <- list(beta.median     = beta.vol5.median,
                beta.q025         = beta.vol5.q025,
                beta.q975         = beta.vol5.q975,
                r.squared.median = r.squared.vol5.median,
                r.squared.q025    = r.squared.vol5.q025,
                r.squared.q975    = r.squared.vol5.q975)

    vol10 <- list(beta.median    = beta.vol10.median,
                beta.q025         = beta.vol10.q025,
                beta.q975         = beta.vol10.q975,
                r.squared.median = r.squared.vol10.median,
                r.squared.q025    = r.squared.vol10.q025,
                r.squared.q975    = r.squared.vol10.q975)

    vol <- list(vol1  = vol1,
                vol3  = vol3,
                vol5  = vol5,
                vol10 = vol10)



    modelVol1 <- list(beta.median      = beta.ModelVol1.median,
                      beta.q025         = beta.ModelVol1.q025,
                      beta.q975         = beta.ModelVol1.q975,
                      r.squared.median = r.squared.ModelVol1.median,
                      r.squared.q025    = r.squared.ModelVol1.q025,
                      r.squared.q975    = r.squared.ModelVol1.q975)

    modelVol3 <- list(beta.median      = beta.ModelVol3.median,
                      beta.q025         = beta.ModelVol3.q025,
                      beta.q975         = beta.ModelVol3.q975,
                      r.squared.median = r.squared.ModelVol3.median,
                      r.squared.q025    = r.squared.ModelVol3.q025,
                      r.squared.q975    = r.squared.ModelVol3.q975)

    modelVol5 <- list(beta.median      = beta.ModelVol5.median,
                      beta.q025         = beta.ModelVol5.q025,
                      beta.q975         = beta.ModelVol5.q975,
                      r.squared.median = r.squared.ModelVol5.median,
                      r.squared.q025    = r.squared.ModelVol5.q025,
                      r.squared.q975    = r.squared.ModelVol5.q975)

    modelVol10 <- list(beta.median      = beta.ModelVol10.median,
                       beta.q025         = beta.ModelVol10.q025,
                       beta.q975         = beta.ModelVol10.q975,
                       r.squared.median = r.squared.ModelVol10.median,
                       r.squared.q025    = r.squared.ModelVol10.q025,
                       r.squared.q975    = r.squared.ModelVol10.q975)

    modelVol <- list(modelVol1  = modelVol1,
                     modelVol3  = modelVol3,
                     modelVol5  = modelVol5,
                     modelVol10 = modelVol10)

    return(list(er  = er,
                cgs = cgs,
                cge = cge,
                vol = vol,
                modelVol = modelVol))
}

savePredictability_LeveredLRR <- function(predic,outDir,countryToUse)
{
     ## Data from Beeler and Campbell

     ## Excess Stock Predictability
     beta.er1.hat       <- -0.059
     beta.er3.hat       <- -0.229
     beta.er5.hat       <- -0.421

     r.squared.er1.hat  <- 0.022
     r.squared.er3.hat  <- 0.143
     r.squared.er5.hat  <- 0.278

     ## Consumption predictability
     beta.cgs1.hat      <- 0.001
     beta.cgs3.hat      <- -0.010
     beta.cgs5.hat      <- -0.016

     r.squared.cgs1.hat <- 0.000
     r.squared.cgs3.hat <- 0.018
     r.squared.cgs5.hat <- 0.040

     ## Consumption predictability
     beta.cge1.hat      <- 0.012
     beta.cge3.hat      <- 0.010
     beta.cge5.hat      <- -0.001

     r.squared.cge1.hat <- 0.068
     r.squared.cge3.hat <- 0.013
     r.squared.cge5.hat <-  0.000

     ## Dividend predictability
     beta.div1.hat      <- 0.064
     beta.div3.hat      <- 0.076
     beta.div5.hat      <- 0.051

     r.squared.div1.hat <- 0.074
     r.squared.div3.hat <- 0.034
     r.squared.div5.hat <- 0.013

     ## Volatility predictability
     beta.vol1.hat      <- -0.481
     beta.vol3.hat      <- -0.491
     beta.vol5.hat      <- -0.564

     r.squared.vol1.hat <- 0.035
     r.squared.vol3.hat <- 0.122
     r.squared.vol5.hat <- 0.235

     ## BY from Beeler and Campbell

     ## Excess Stock Predictability
     beta.er1.BY.median       <- -0.049
     beta.er3.BY.median       <- -0.144
     beta.er5.BY.median       <- -0.230

     beta.er1.BY.pop          <- -0.007
     beta.er3.BY.pop          <- -0.026
     beta.er5.BY.pop          <- -0.039

     r.squared.er1.BY.median  <- 0.007
     r.squared.er3.BY.median  <- 0.018
     r.squared.er5.BY.median  <- 0.027

     r.squared.er1.BY.pop     <- 0.000
     r.squared.er3.BY.pop     <- 0.000
     r.squared.er5.BY.pop     <- 0.000

     ## Consumption predictability
     beta.cgs1.BY.median      <- 0.092
     beta.cgs3.BY.median      <- 0.207
     beta.cgs5.BY.median      <- 0.259

     beta.cgs1.BY.pop         <- 0.097
     beta.cgs3.BY.pop         <- 0.230
     beta.cgs5.BY.pop         <- 0.308

     r.squared.cgs1.BY.median <- 0.242
     r.squared.cgs3.BY.median <- 0.228
     r.squared.cgs5.BY.median <- 0.176

     r.squared.cgs1.BY.pop    <- 0.280
     r.squared.cgs3.BY.pop    <- 0.280
     r.squared.cgs5.BY.pop    <- 0.235

     ## Consumption predictability
     beta.cge1.BY.median      <- 0.113
     beta.cge3.BY.median      <- 0.271
     beta.cge5.BY.median      <- 0.350

     beta.cge1.BY.pop         <- 0.114
     beta.cge3.BY.pop         <- 0.286
     beta.cge5.BY.pop         <- 0.388

     r.squared.cge1.BY.median <- 0.361
     r.squared.cge3.BY.median <- 0.394
     r.squared.cge5.BY.median <- 0.322

     r.squared.cge1.BY.pop    <- 0.390
     r.squared.cge3.BY.pop    <- 0.435
     r.squared.cge5.BY.pop    <- 0.373

     ## Dividend predictability
     beta.div1.BY.median      <- 0.339
     beta.div3.BY.median      <- 0.816
     beta.div5.BY.median      <- 1.053

     beta.div1.BY.pop         <- 0.343
     beta.div3.BY.pop         <- 0.860
     beta.div5.BY.pop         <- 1.171

     r.squared.div1.BY.median <- 0.207
     r.squared.div3.BY.median <- 0.257
     r.squared.div5.BY.median <- 0.224

     r.squared.div1.BY.pop    <- 0.228
     r.squared.div3.BY.pop    <- 0.288
     r.squared.div5.BY.pop    <- 0.265

     ## Volatility predictability
     beta.vol1.BY.median      <- -0.140
     beta.vol3.BY.median      <- -0.124
     beta.vol5.BY.median      <- -0.104

     beta.vol1.BY.pop         <- -0.128
     beta.vol3.BY.pop         <- -0.122
     beta.vol5.BY.pop         <- -0.113

     r.squared.vol1.BY.median <- 0.006
     r.squared.vol3.BY.median <- 0.015
     r.squared.vol5.BY.median <- 0.022

     r.squared.vol1.BY.pop    <- 0.000
     r.squared.vol3.BY.pop    <- 0.001
     r.squared.vol5.BY.pop    <- 0.002

     ## BKY from BKY (2009)

     ## Excess Stock Predictability (copied from BKY (2009))
     beta.er1.BKY.median      <- -0.121
     beta.er3.BKY.median      <- -0.344
     beta.er5.BKY.median      <- -0.537

     beta.er1.BKY.pop         <- -0.078
     beta.er3.BKY.pop         <- -0.226
     beta.er5.BKY.pop         <- -0.368

     r.squared.er1.BKY.median <- 0.012
     r.squared.er3.BKY.median <- 0.034
     r.squared.er5.BKY.median <- 0.053

     r.squared.er1.BKY.pop    <- 0.009
     r.squared.er3.BKY.pop    <- 0.026
     r.squared.er5.BKY.pop    <- 0.041

     ## Consumption predictability (copied from BKY (2009))
     beta.cgs1.BKY.median      <- NA
     beta.cgs3.BKY.median      <- NA
     beta.cgs5.BKY.median      <- NA

     beta.cgs1.BKY.pop         <- NA
     beta.cgs3.BKY.pop         <- NA
     beta.cgs5.BKY.pop         <- NA

     r.squared.cgs1.BKY.median <- NA
     r.squared.cgs3.BKY.median <- NA
     r.squared.cgs5.BKY.median <- NA

     r.squared.cgs1.BKY.pop    <- NA
     r.squared.cgs3.BKY.pop    <- NA
     r.squared.cgs5.BKY.pop    <- NA

     ## Consumption predictability (copied from BKY (2009))
     beta.cge1.BKY.median      <- 0.05
     beta.cge3.BKY.median      <- 0.10
     beta.cge5.BKY.median      <- 0.12

     beta.cge1.BKY.pop         <- 0.03
     beta.cge3.BKY.pop         <- 0.05
     beta.cge5.BKY.pop         <- 0.06

     r.squared.cge1.BKY.median <- 0.14
     r.squared.cge3.BKY.median <- 0.10
     r.squared.cge5.BKY.median <- 0.08

     r.squared.cge1.BKY.pop    <- 0.07
     r.squared.cge3.BKY.pop    <- 0.05
     r.squared.cge5.BKY.pop    <- 0.04

     ## Dividend predictability (copied from BKY (2009))
     beta.div1.BKY.median      <- 0.35
     beta.div3.BKY.median      <- 0.45
     beta.div5.BKY.median      <- 0.49

     beta.div1.BKY.pop         <- 0.19
     beta.div3.BKY.pop         <- 0.26
     beta.div5.BKY.pop         <- 0.30

     r.squared.div1.BKY.median <- 0.20
     r.squared.div3.BKY.median <- 0.09
     r.squared.div5.BKY.median <- 0.06

     r.squared.div1.BKY.pop    <- 0.11
     r.squared.div3.BKY.pop    <- 0.05
     r.squared.div5.BKY.pop    <- 0.04

     ## Volatility predictability (copied from BKY (2009))
     beta.vol1.BKY.median      <- -0.95
     beta.vol3.BKY.median      <- -0.90
     beta.vol5.BKY.median      <- -0.78

     beta.vol1.BKY.pop         <- -1.00
     beta.vol3.BKY.pop         <- -0.95
     beta.vol5.BKY.pop         <- -0.93

     r.squared.vol1.BKY.median <- 0.03
     r.squared.vol3.BKY.median <- 0.08
     r.squared.vol5.BKY.median <- 0.11

     r.squared.vol1.BKY.pop    <- 0.07
     r.squared.vol3.BKY.pop    <- 0.21
     r.squared.vol5.BKY.pop    <- 0.29


     ## Create Tables
     ########################

     ## Excess returns coefficients
     Table <- cbind(c(beta.er1.hat,              beta.er3.hat,              beta.er5.hat,              NA),
                    c(beta.er1.BY.median,        beta.er3.BY.median,        beta.er5.BY.median,        NA),
                    c(beta.er1.BKY.median,       beta.er3.BKY.median,       beta.er5.BKY.median,       NA),
                    c(predic$er$er1$beta.median, predic$er$er3$beta.median, predic$er$er5$beta.median, predic$er$er10$beta.median),
                    c(predic$er$er1$beta.q025,    predic$er$er3$beta.q025,    predic$er$er5$beta.q025,    predic$er$er10$beta.q025),
                    c(predic$er$er1$beta.q975,    predic$er$er3$beta.q975,    predic$er$er5$beta.q975,    predic$er$er10$beta.q975))

     TableXLS <- Table

     dimnames(TableXLS)[[2]] <- c('beta',
                                  'beta_{BY}(50%)',
                                  'beta_{BKY}(50%)',
                                  'beta_{NSS}(50%)',
                                  'beta_{NSS}(2.5%)',
                                  'beta_{NSS}(97.5%)')
     dimnames(TableXLS)[[1]] <- c('1','3','5','10')

    # XLS
    filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_ExcessReturnsBetaNAP.',allData$countryNames[countryToUse],'.csv',sep=""))
    write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
    
     ## Excess returns R-squared
     Table <- cbind(c(r.squared.er1.hat,r.squared.er3.hat,r.squared.er5.hat,NA),
                    c(r.squared.er1.BY.median,r.squared.er3.BY.median,r.squared.er5.BY.median,NA),
                    c(r.squared.er1.BKY.median,r.squared.er3.BKY.median,r.squared.er5.BKY.median,NA),
                    c(predic$er$er1$r.squared.median,predic$er$er3$r.squared.median,predic$er$er5$r.squared.median,predic$er$er10$r.squared.median),
                    c(predic$er$er1$r.squared.q025,predic$er$er3$r.squared.q025,predic$er$er5$r.squared.q025,predic$er$er10$r.squared.q025),
                    c(predic$er$er1$r.squared.q975,predic$er$er3$r.squared.q975,predic$er$er5$r.squared.q975,predic$er$er10$r.squared.q975))
     TableXLS <- Table
     dimnames(TableXLS)[[2]] <- c('R^2$',
                                  'R^2_{BY}(50%)',
                                  'R^2_{BKY}(50%)',
                                  'R^2_{NSS}(50%)',
                                  'R^2_{NSS}(2.5%)',
                                  'R^2_{NSS}(97.5%)')
     dimnames(TableXLS)[[1]] <- c('1','3','5','10')

    # XLS
    filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_ExcessReturnsRsquaredNAP.',allData$countryNames[countryToUse],'.csv',sep=""))
    write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")

     ## Beginning of the period consumption: coefficients
     Table <- cbind(c(beta.cgs1.hat,beta.cgs3.hat,beta.cgs5.hat,NA),
                          c(beta.cgs1.BY.median,beta.cgs3.BY.median,beta.cgs5.BY.median,NA),
                          c(beta.cgs1.BKY.median,beta.cgs3.BKY.median,beta.cgs5.BKY.median,NA),
                          c(predic$cgs$cgs1$beta.median,predic$cgs$cgs3$beta.median,predic$cgs$cgs5$beta.median,predic$cgs$cgs10$beta.median),
                          c(predic$cgs$cgs1$beta.q025,predic$cgs$cgs3$beta.q025,predic$cgs$cgs5$beta.q025,predic$cgs$cgs10$beta.q025),
                          c(predic$cgs$cgs1$beta.q975,predic$cgs$cgs3$beta.q975,predic$cgs$cgs5$beta.q975,predic$cgs$cgs10$beta.q975))
     TableXLS <- Table
     dimnames(TableXLS)[[2]] <- c('beta',
                                  'beta_{BY}(50%)',
                                  'beta_{BKY}(50%)',
                                  'beta_{NSS}(50%)',
                                  'beta_{NSS}(2.5%)',
                                  'beta_{NSS}(97.5%)')
     dimnames(TableXLS)[[1]] <- c('1','3','5','10')
        # XLS
        filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_BeginningConsumptionBetaNAP.',allData$countryNames[countryToUse],'.csv',sep=""))
        write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")

     ## Beginning of the period consumption: R-squared
     Table <- cbind(c(r.squared.cgs1.hat,r.squared.cgs3.hat,r.squared.cgs5.hat,NA),
                          c(r.squared.cgs1.BY.median,r.squared.cgs3.BY.median,r.squared.cgs5.BY.median,NA),
                          c(r.squared.cgs1.BKY.median,r.squared.cgs3.BKY.median,r.squared.cgs5.BKY.median,NA),
                          c(predic$cgs$cgs1$r.squared.median,predic$cgs$cgs3$r.squared.median,predic$cgs$cgs5$r.squared.median,predic$cgs$cgs10$r.squared.median),
                          c(predic$cgs$cgs1$r.squared.q025,predic$cgs$cgs3$r.squared.q025,predic$cgs$cgs5$r.squared.q025,predic$cgs$cgs10$r.squared.q025),
                          c(predic$cgs$cgs1$r.squared.q975,predic$cgs$cgs3$r.squared.q975,predic$cgs$cgs5$r.squared.q975,predic$cgs$cgs10$r.squared.q975))
     TableXLS <- Table
     dimnames(TableXLS)[[2]] <- c('R^2$',
                                  'R^2_{BY}(50%)',
                                  'R^2_{BKY}(50%)',
                                  'R^2_{NSS}(50%)',
                                  'R^2_{NSS}(2.5%)',
                                  'R^2_{NSS}(97.5%)')

     dimnames(TableXLS)[[1]] <- c('1','3','5','10')
        # XLS
        filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_BeginningConsumptionRsquaredNAP.',allData$countryNames[countryToUse],'.csv',sep=""))
        write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")

     ## End-of-period consumption: coefficients
     Table <- cbind(c(beta.cge1.hat,beta.cge3.hat,beta.cge5.hat,NA),
                  c(beta.cge1.BY.median,beta.cge3.BY.median,beta.cge5.BY.median,NA),
                  c(beta.cge1.BKY.median,beta.cge3.BKY.median,beta.cge5.BKY.median,NA),
                  c(predic$cge$cge1$beta.median,predic$cge$cge3$beta.median,predic$cge$cge5$beta.median,predic$cge$cge10$beta.median),
                  c(predic$cge$cge1$beta.q025,predic$cge$cge3$beta.q025,predic$cge$cge5$beta.q025,predic$cge$cge10$beta.q025),
                  c(predic$cge$cge1$beta.q975,predic$cge$cge3$beta.q975,predic$cge$cge5$beta.q975,predic$cge$cge10$beta.q975))

     TableXLS <- Table
     dimnames(TableXLS)[[2]] <- c('beta',
                                  'beta_{BY}(50%)',
                                  'beta_{BKY}(50%)',
                                  'beta_{NSS}(50%)',
                                  'beta_{NSS}(2.5%)',
                                  'beta_{NSS}(97.5%)')
     dimnames(TableXLS)[[1]] <- c('1','3','5','10')
        # XLS
        filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_EndConsumptionBetaNAP.',allData$countryNames[countryToUse],'.csv',sep=""))
        write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")

     ## End-of-period consumption: R-squared
    Table <- cbind(c(r.squared.cge1.hat,r.squared.cge3.hat,r.squared.cge5.hat,NA),
                  c(r.squared.cge1.BY.median,r.squared.cge3.BY.median,r.squared.cge5.BY.median,NA),
                  c(r.squared.cge1.BKY.median,r.squared.cge3.BKY.median,r.squared.cge5.BKY.median,NA),
                  c(predic$cge$cge1$r.squared.median,predic$cge$cge3$r.squared.median,predic$cge$cge5$r.squared.median,predic$cge$cge10$r.squared.median),
                  c(predic$cge$cge1$r.squared.q025,predic$cge$cge3$r.squared.q025,predic$cge$cge5$r.squared.q025,predic$cge$cge10$r.squared.q025),
                  c(predic$cge$cge1$r.squared.q975,predic$cge$cge3$r.squared.q975,predic$cge$cge5$r.squared.q975,predic$cge$cge10$r.squared.q975))
    TableXLS <- Table
    dimnames(TableXLS)[[2]] <- c('R^2$',
                                  'R^2_{BY}(50%)',
                                  'R^2_{BKY}(50%)',
                                  'R^2_{NSS}(50%)',
                                  'R^2_{NSS}(2.5%)',
                                  'R^2_{NSS}(97.5%)')
    dimnames(TableXLS)[[1]] <- c('1','3','5','10')
    # XLS
    filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_EndConsumptionRsquaredNAP.',allData$countryNames[countryToUse],'.csv',sep=""))
    write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")

    ## Simple Volatility: coefficients
    Table <- cbind(c(beta.vol1.hat,beta.vol3.hat,beta.vol5.hat,NA),
                          c(beta.vol1.BY.median,beta.vol3.BY.median,beta.vol5.BY.median,NA),
                          c(beta.vol1.BKY.median,beta.vol3.BKY.median,beta.vol5.BKY.median,NA),
                          c(predic$vol$vol1$beta.median,predic$vol$vol3$beta.median,predic$vol$vol5$beta.median,predic$vol$vol10$beta.median),
                          c(predic$vol$vol1$beta.q025,predic$vol$vol3$beta.q025,predic$vol$vol5$beta.q025,predic$vol$vol10$beta.q025),
                          c(predic$vol$vol1$beta.q975,predic$vol$vol3$beta.q975,predic$vol$vol5$beta.q975,predic$vol$vol10$beta.q975))
    TableXLS <- Table
    dimnames(TableXLS)[[2]] <- c('beta',
                                  'beta_{BY}(50%)',
                                  'beta_{BKY}(50%)',
                                  'beta_{NSS}(50%)',
                                  'beta_{NSS}(2.5%)',
                                  'beta_{NSS}(97.5%)')
    dimnames(TableXLS)[[1]] <- c('1','3','5','10')
    # XLS
    filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_VolatilityBetaNAP.',allData$countryNames[countryToUse],'.csv',sep=""))
    write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")

    ## Simple Volatility: R-squared
    Table <- cbind(c(r.squared.vol1.hat,r.squared.vol3.hat,r.squared.vol5.hat,NA),
                          c(r.squared.vol1.BY.median,r.squared.vol3.BY.median,r.squared.vol5.BY.median,NA),
                          c(r.squared.vol1.BKY.median,r.squared.vol3.BKY.median,r.squared.vol5.BKY.median,NA),
                          c(predic$vol$vol1$r.squared.median,predic$vol$vol3$r.squared.median,predic$vol$vol5$r.squared.median,predic$vol$vol10$r.squared.median),
                          c(predic$vol$vol1$r.squared.q025,predic$vol$vol3$r.squared.q025,predic$vol$vol5$r.squared.q025,predic$vol$vol10$r.squared.q025),
                          c(predic$vol$vol1$r.squared.q975,predic$vol$vol3$r.squared.q975,predic$vol$vol5$r.squared.q975,predic$vol$vol10$r.squared.q975))
    TableXLS <- Table
    dimnames(TableXLS)[[2]] <- c('R^2$',
                                  'R^2_{BY}(50%)',
                                  'R^2_{BKY}(50%)',
                                  'R^2_{NSS}(50%)',
                                  'R^2_{NSS}(2.5%)',
                                  'R^2_{NSS}(97.5%)')
    dimnames(TableXLS)[[1]] <- c('1','3','5','10')
    # XLS
    filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_VolatilityRsquaredNAP.',allData$countryNames[countryToUse],'.csv',sep="")  )
    write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")

    ## Model Volatility: coefficients
    Table <- cbind(c(NA,NA,NA,NA),
                    c(NA,NA,NA,NA),
                    c(NA,NA,NA,NA),
                    c(predic$modelVol$modelVol1$beta.median,predic$modelVol$modelVol3$beta.median,predic$modelVol$modelVol5$beta.median,predic$modelVol$modelVol10$beta.median),
                    c(predic$modelVol$modelVol1$beta.q025,predic$modelVol$modelVol3$beta.q025,predic$modelVol$modelVol5$beta.q025,predic$modelVol$modelVol10$beta.q025),
                    c(predic$modelVol$modelVol1$beta.q975,predic$modelVol$modelVol3$beta.q975,predic$modelVol$modelVol5$beta.q975,predic$modelVol$modelVol10$beta.q975))
    TableXLS <- Table
    dimnames(TableXLS)[[2]] <- c('beta',
                                  'beta_{BY}(50%)',
                                  'beta_{BKY}(50%)',
                                  'beta_{NSS}(50%)',
                                  'beta_{NSS}(2.5%)',
                                  'beta_{NSS}(97.5%)')
    dimnames(TableXLS)[[1]] <- c('1','3','5','10')
    # XLS
    filename <-  file.path(outDir, paste('predictabilityTable_LeveredLRR_ModelVolatilityBetaNAP.',
                                allData$countryNames[countryToUse],'.csv',sep=""))
    write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")

    ## Model Volatility: R-squared
    Table <- cbind(c(NA,NA,NA,NA),
                    c(NA,NA,NA,NA),
                    c(NA,NA,NA,NA),
                    c(predic$modelVol$modelVol1$r.squared.median,predic$modelVol$modelVol3$r.squared.median,predic$modelVol$modelVol5$r.squared.median,predic$modelVol$modelVol10$r.squared.median),
                    c(predic$modelVol$modelVol1$r.squared.q025,predic$modelVol$modelVol3$r.squared.q025,predic$modelVol$modelVol5$r.squared.q025,predic$modelVol$modelVol10$r.squared.q025),
                    c(predic$modelVol$modelVol1$r.squared.q975,predic$modelVol$modelVol3$r.squared.q975,predic$modelVol$modelVol5$r.squared.q975,predic$modelVol$modelVol10$r.squared.q975))
    
    TableXLS <- Table
    
    dimnames(TableXLS)[[2]] <- c('R^2$',
                                  'R^2_{BY}(50%)',
                                  'R^2_{BKY}(50%)',
                                  'R^2_{NSS}(50%)',
                                  'R^2_{NSS}(2.5%)',
                                  'R^2_{NSS}(97.5%)')
    dimnames(TableXLS)[[1]] <- c('1','3','5','10')

    # XLS
    filename <-  file.path(outDir, 
        paste('predictabilityTable_LeveredLRR_ModelVolatilityRsquaredNAP.',
            allData$countryNames[countryToUse],'.csv',sep=""))

    write.table(round(TableXLS,4), filename,row.names = T,col.names=NA, sep = ",")
}

initializeSummaryStatsBigFile <- function(allData,controlVarNAPi)
{

    rowNames <- c("cGrowthMean","cGrowthStd","cGrowthAC1","cGrowthMeanWithBreak",
                  "cGrowthStdWithBreak","cGrowthAR1WithBreak","dGrowthMean","dGrowthStd","dGrowthAC1","equityMean","equityStd",
                  "onePerBondMean","onePerBondStd","equityPremiumMean","equityPremiumStd","equitySharpRatio","leveredEquityMean",
                  "leveredEquityStd","leveredEquityPremiumMean","leveredEquityPremiumStd",
                  "leveredEquitySharpRatio","PDequityMean","PDequityStd","PDequityAC1",
                  "PDonePerBondMean","PDonePerBondStd","PDonePerBondAC1","PDleveredEquityMean","PDleveredEquityStd","PDleveredEquityAC1")

    summaryStats           <- matrix(NA,length(rowNames),1)
    rownames(summaryStats) <- rowNames

    filename       <- file.path(outDir,paste('summaryStatsBigFile','.Rda',sep=""))
    save(summaryStats, file = filename)
}

## Save
#####################################################################
saveSummaryStatsBigFile <- function(allData,countryToUse,returnsAP,controlVarNAPi)
{
    load(file.path(outDir,paste('summaryStatsBigFile','.Rda',sep="")))
    payGrowth <- controlVarNAPi$payGrowth
    nPer      <- length(returnsAP$Equity$Return)
    nRow      <- dim(summaryStats)[1]
    nCol      <- dim(summaryStats)[2]

    if ((nCol == 1) & (sum(!is.na(summaryStats[,1]))==0)){
        curCol <- 1
    } else {
        curCol <- nCol + 1
        # Add new row to summaryStats
        summaryStats <- cbind(summaryStats,matrix(NaN,nRow,1))
    }

    colnames(summaryStats)[curCol]                  <- allData$countryNames[countryToUse]

    summaryStats["cGrowthMean",curCol]              <- mean(log(returnsAP$CGrowth[2:nPer]))
    summaryStats["cGrowthStd",curCol]               <- sd(log(returnsAP$CGrowth[2:nPer]))
    summaryStats["cGrowthAC1",curCol]               <- cor(log(returnsAP$CGrowth[2:(nPer-1)]),log(returnsAP$CGrowth[3:nPer]))
    summaryStats["cGrowthMeanWithBreak",curCol]     <- mean(log(returnsAP$CGrowthWithBreak[2:nPer]))
    summaryStats["cGrowthStdWithBreak",curCol]      <- sd(log(returnsAP$CGrowthWithBreak[2:nPer]))
    summaryStats["cGrowthAR1WithBreak",curCol]      <- cor(log(returnsAP$CGrowthWithBreak[2:(nPer-1)]),log(returnsAP$CGrowthWithBreak[3:nPer]))
    summaryStats["dGrowthMean",curCol]              <- mean(log(returnsAP$DGrowth[2:nPer]))
    summaryStats["dGrowthStd",curCol]               <- sd(log(returnsAP$DGrowth[2:nPer]))
    summaryStats["dGrowthAC1",curCol]               <- cor(log(returnsAP$DGrowth[2:(nPer-1)]),log(returnsAP$DGrowth[3:nPer]))

    summaryStats["equityMean",curCol]               <- mean(returnsAP$Equity$Return[2:nPer])
    summaryStats["equityStd",curCol]                <- sd(returnsAP$Equity$Return[2:nPer])
    summaryStats["onePerBondMean",curCol]           <- mean(returnsAP$OnePerBond$Return[2:nPer])
    summaryStats["onePerBondStd",curCol]            <- sd(returnsAP$OnePerBond$Return[2:nPer])
    summaryStats["equityPremiumMean",curCol]        <- mean(returnsAP$Equity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer])
    summaryStats["equityPremiumStd",curCol]         <- sd(returnsAP$Equity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer])
    summaryStats["equitySharpRatio",curCol]         <- (mean(returnsAP$Equity$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$Equity$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer])

    summaryStats["leveredEquityMean",curCol]        <- mean(returnsAP$LeveredXXEq$Return[2:nPer])
    summaryStats["leveredEquityStd",curCol]         <- sd(returnsAP$LeveredXXEq$Return[2:nPer])
    summaryStats["leveredEquityPremiumMean",curCol] <- mean(returnsAP$LeveredXXEq$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer])
    summaryStats["leveredEquityPremiumStd",curCol]  <- sd(returnsAP$LeveredXXEq$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer])
    summaryStats["leveredEquitySharpRatio",curCol]  <- (mean(returnsAP$LeveredXXEq$Return[2:nPer]) - mean(returnsAP$OnePerBond$Return[2:nPer]))/sd(returnsAP$LeveredXXEq$Return[2:nPer] - returnsAP$OnePerBond$Return[2:nPer])

    summaryStats["PDequityMean",curCol]             <- mean(log(returnsAP$Equity$PDiv))
    summaryStats["PDequityStd",curCol]              <- sd(log(returnsAP$Equity$PDiv))
    summaryStats["PDequityAC1",curCol]              <- cor(log(returnsAP$Equity$PDiv[1:(nPer-1)]),log(returnsAP$Equity$PDiv[2:nPer]))

    summaryStats["PDonePerBondMean",curCol]         <- mean(log(returnsAP$OnePerBond$PDiv))
    summaryStats["PDonePerBondStd",curCol]          <- sd(log(returnsAP$OnePerBond$PDiv))
    summaryStats["PDonePerBondAC1",curCol]          <- cor(log(returnsAP$OnePerBond$PDiv[2:nPer]),log(returnsAP$OnePerBond$PDiv[1:(nPer-1)]))

    summaryStats["PDleveredEquityMean",curCol]      <- mean(log(returnsAP$LeveredXXEq$PDiv))
    summaryStats["PDleveredEquityStd",curCol]       <- sd(log(returnsAP$LeveredXXEq$PDiv))
    summaryStats["PDleveredEquityAC1",curCol]       <- cor(log(returnsAP$LeveredXXEq$PDiv[1:(nPer-1)]),log(returnsAP$LeveredXXEq$PDiv[2:nPer]))

    filename       <- file.path(outDir,paste('summaryStatsBigFile','.Rda',sep=""))
    save(summaryStats, file = filename)

}

saveSummaryStatsBigFileCSV <- function()
{
    load(file.path(outDir,paste('summaryStatsBigFile','.Rda',sep="")))
    filename <-  file.path(outDir, paste('summaryStatsBigFile','.csv',sep=""))
    write.table(round(summaryStats,5), filename,row.names = T,col.names=NA, sep = ",")
}