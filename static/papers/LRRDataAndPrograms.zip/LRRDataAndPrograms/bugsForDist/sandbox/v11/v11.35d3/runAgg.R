## This program aggregates the batches from the poterior that are
## created by runModel.R and then calculates various statistics and
## creates various plots and tables.            
##
## Emi Nakamura, Dmitriy Sergeyev, Jon Steinsson (July 2016)
################################################################################

rm(list = ls())
gc()
source('funcs.R')
source('funcsAgg.R')

# Define variables with directory information (second function in funcs.R)
dirInfo        <- getDirInfo()
outDir         <- dirInfo$outDir
prefixDir      <- dirInfo$prefixDir

# Import real world data (function in funcs.R)
allData        <- readData(prefixDir)   		

# Import control variables (see first function in funcs.R)  
controlVar     <- getControlVar()   			  

# Import more control variables (see first function in funcsAgg.R)
controlAgg     <- getControlAgg()   			  

# Load variables that contain parameter names and information about 
# their position in the parameter vector

# Names/Positions used for each batch (function in funcs.R)
NamesNPosInfo  <- getNamesNPosInfo(allData) 	  
UnobsPosInfo   <- NamesNPosInfo$UnobsPosInfo

# Names/Positions used for aggregated sample (function in funcsAgg.R)
bigDataPosInfo <- getBigDataPosInfo(UnobsPosInfo) 

# Gets information on which runs are to be aggregated (function in funcsAgg.R)
runsToUse      <- getRunsToUse() 				  

# Combine runs without combining chains (function in funcsAgg.R)
if (controlAgg$combineRuns)   combineRuns(UnobsPosInfo, bigDataPosInfo, runsToUse)

## If a run of runModel.R created more than one chain at once, this following 
## function will aggregate the chains. Otherwise this function just
## creates files with extension _pooled (e.g., bigDataDS_pooled.Rda) that are
## the same as the files without the extenssion (e.g., bigDataDS.Rda)
if (controlAgg$combineChains) combineChains(UnobsPosInfo, bigDataPosInfo) 		   

## Get parameter estimates
ParEst <- getParEstimates(bigDataPosInfo,controlAgg$usePooledChains,
                          controlAgg$chainToUse)

## Create summary of prior and posterior for parameters that are COMMON across 
## countries
summaryCommonParameters(controlAgg,bigDataPosInfo)  

## Create summary of prior and posterior for parameters that are DIFFERENT 
## across countries
summaryCountryParameters(controlAgg,bigDataPosInfo) 

## Create main figures
simPlotMany(bigDataPosInfo)   		   				

################################################################################
##                Results based on LONG simulation of the data
################################################################################

## Computes states statistics by simulating long data. In particulat, this
## function computes the frequency of hitting the lower bound for volatility
## The length of the simulated sample is controlAgg$simLengthLong 
modelStatesStats(controlAgg, allData, bigDataPosInfo, ParEst, prefixDir, outDir)

################################################################################
##              Stochastic Volatility Stats based on estimated data
################################################################################

## Compare amount of LRR across our results, BY,  and BKY using AR(5) regression
compareLRRinNSSvsBY(controlAgg,ParEst,bigDataPosInfo,allData,
                      countryToUse = "United.States") 

## Compare amount of SV across our results, BY,  and BKY using quantile method
compareSVinNSSvsBY(controlAgg,ParEst,bigDataPosInfo,allData,
                      countryToUse = "United.States")  
