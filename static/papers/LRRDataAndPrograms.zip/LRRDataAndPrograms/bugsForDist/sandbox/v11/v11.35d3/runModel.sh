#!/bin/sh
#runModel.sh
#Torque script to run R program

 
#Torque directives
#PBS -N runModel
#PBS -W group_list=hpcsscc
#PBS -l nodes=1,walltime=5:00:00:00,mem=1900mb
#PBS -M ds2635@columbia.edu
#PBS -m abe
#PBS -V

#set output and error directories (SSCC example here)
#PBS -o localhost:/hmt/hpcstorage1/hpc/sscc/work/projects/lrr/sandbox/v11/v11.35d3
#PBS -e localhost:/hmt/hpcstorage1/hpc/sscc/work/projects/lrr/sandbox/v11/v11.35d3

#Command to execute Matlab code
R CMD BATCH --no-save runModel.R $PBS_JOBNAME.routput

