#!/bin/sh
#runNAP.Denmark.sh

#Torque directives
#PSB -N runNAP.Denmark
#PBS -W group_list=yetisscc
#PBS -l nodes=1,walltime=2:23:59:59,mem=23900mb
#PBS -M ds2635@columbia.edu
#PBS -m abe
#PBS -V

#set output and error directories
#PBS -o localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.35d3
#PBS -e localhost:/vega/sscc/work/projects/lrr/sandbox/v11/v11.35d3

#Command to execute R code
R CMD BATCH --no-save --vanilla runNAP.Denmark.R $PBS_JOBNAME.routput

#End of script
