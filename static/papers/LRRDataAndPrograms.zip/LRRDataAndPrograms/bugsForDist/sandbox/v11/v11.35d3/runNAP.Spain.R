#####################################################################
## This program calculates asset prices for our LRR model            
##                                                                   
## Emi Nakamura, Dmitriy Sergeyev Jon Steinsson, April 2010          
#####################################################################

rm(list = ls())
gc()

###################################################################
GlobalCountryName           <- "Spain"
GlobalCountryToSimulateData <- "Spain"
GlobalCreateNextStateFiles  <- 1
GlobalUpdatePDivs           <- 1
GlobalSimulatePrices        <- 1
###################################################################

APresultsFileName <- paste("APresults",GlobalCountryName,"txt",sep=".")

source('funcs.R')
source('funcsAgg.R')
source('funcsNAP.R')

dirInfo          <- getDirInfo()
outDir           <- dirInfo$outDir
prefixDir        <- dirInfo$prefixDir
allData          <- readData(prefixDir)
countryToUse     <- which(allData$countryNames == GlobalCountryName) 

controlVar       <- getControlVar()
controlAgg       <- getControlAgg()
controlVarNAP    <- getControlVarNAP(allData, controlAgg)

NamesNPosInfo    <- getNamesNPosInfo(allData)
parameters       <- NamesNPosInfo$UnobsNames
UnobsPosInfo     <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo   <- getBigDataPosInfo(UnobsPosInfo)

## creates folders for nextState and weights
if (controlVarNAP$createFolders == 1) createFolders(allData,controlVarNAP,outDir) 
if (controlVarNAP$updatePDivs) {

    ParEst <- getParEstimates(bigDataPosInfo,controlAgg$usePooledChains,controlAgg$chainToUse) 
    
    filename <- file.path(outDir, APresultsFileName)
    sink(filename)
    cat('\n')
    cat('PARAMETERS\n')
    cat('\n')
    cat('rhoU:                     ',controlVarNAP$rhoU,'\n')
    cat('gammaU:                   ',controlVarNAP$gammaU,'\n')
    cat('psiU:                     ',controlVarNAP$psiU,'\n')
    cat('thetaU:                   ',controlVarNAP$thetaU,'\n')
    cat('\n')

    cat('Mu:                       ',ParEst[bigDataPosInfo$mu][countryToUse],'\n')
    cat('sigmaEps:                 ',sqrt(ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]),'\n')
    cat('chi:                      ',sqrt(ParEst[bigDataPosInfo$chiSq][countryToUse]),'\n')
    cat('sigmaOmega:               ',sqrt(ParEst[bigDataPosInfo$sigmaSqOmega]),'\n')    
    cat('\n')

    cat('gammma:                   ',ParEst[bigDataPosInfo$gammma],'\n')
    cat('rho:                      ',ParEst[bigDataPosInfo$rho],'\n')
    cat('\n')
    
    cat('Country:                  ',allData$countryNames[countryToUse],'\n')
    cat('\n')    

    cat('\n')
    cat('nStateGrid:               ',controlVarNAP$nStateGrid,'\n')
    cat('nStateNu:                 ',controlVarNAP$nStateGridNu,'\n')
    cat('nStateXX:                 ',controlVarNAP$nStateGridXX,'\n')
    cat('nStateSigmaSq:            ',controlVarNAP$nStateGridSigmaSq,'\n') 
       
    cat('\n')
    sink()
    
    PDivs             <- getPDivs_EZW(controlVarNAP, ParEst, bigDataPosInfo, printStuff = 1)  

    outputEZW <- list(allData = allData, controlVarNAP = controlVarNAP, ParEst = ParEst, bigDataPosInfo = bigDataPosInfo, PDivs = PDivs)    
    filename   <- file.path(outDir,paste('outputEZW.',allData$countryNames[countryToUse],'.Rda',sep=""))
    save(outputEZW, file = filename)           

} else {   
    timer1 <- proc.time()[3]

    filename        <- file.path(outDir,paste('outputEZW.',allData$countryNames[countryToUse],'.Rda',sep=""))
    load(filename)
       
    allData        <- outputEZW$allData
    controlVarNAP  <- outputEZW$controlVarNAP
    ParEst         <- outputEZW$ParEst
    bigDataPosInfo <- outputEZW$bigDataPosInfo
    PDivs          <- outputEZW$PDivs
           
    timer1 <- proc.time()[3] - timer1
    cat('Time to Load:       ',timer1,'\n')    
}

if (controlVarNAP$simulatePrices == 1){
    set.seed(-100000)

    simOutput        <- simulateModel_EZW(countryToUse, controlVarNAP, ParEst, bigDataPosInfo, controlVarNAP$nSim,controlVarNAP$nSimBurnin,printStuff = 1) 
    simOutputOnGrid  <- putSimOutputOnStateGrid(simOutput, controlVarNAP, ParEst, bigDataPosInfo)
    
    filename <- file.path(outDir,paste('simOutput.',allData$countryNames[countryToUse],'.Rda',sep=""))  
    save(simOutput, file = filename)   
    filename <- file.path(outDir,paste('simOutputOnGrid.',allData$countryNames[countryToUse],'.Rda',sep=""))   
    save(simOutputOnGrid, file = filename)   
    
    
    # Compute returns and other stats for a particular country
    returnsEZW     <- calcReturns(countryToUse,simOutput, simOutputOnGrid, PDivs, controlVarNAP, ParEst, bigDataPosInfo)
    filename       <- file.path(outDir,paste('returnsEZW.',allData$countryNames[countryToUse],'.Rda',sep=""))  
    save(returnsEZW, file = filename) 
    filename <- file.path(outDir, APresultsFileName)
    sink(filename, append = TRUE)
    printSummaryStats(returnsEZW, controlVarNAP, Pref = 1)
    sink()

}

## Predictability
predic <- predictability_LeveredLRR(countryToUse,PDivs, ParEst, controlVarNAP, bigDataPosInfo)
savePredictability_LeveredLRR(predic, outDir,countryToUse)         
 

                        
