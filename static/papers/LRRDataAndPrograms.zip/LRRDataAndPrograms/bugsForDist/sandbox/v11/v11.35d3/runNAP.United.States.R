## This program calculates asset prices for the LRR model
##
## Emi Nakamura, Dmitriy Sergeyev, Jon Steinsson, (July 2016)
################################################################################

rm(list = ls())
gc()

################################################################################
GlobalCountryName           <- "United.States"
GlobalCountryToSimulateData <- "United.States"
GlobalCreateNextStateFiles  <- 1
GlobalUpdatePDivs           <- 1
GlobalSimulatePrices        <- 1
################################################################################

## Set the name for global output file
APresultsFileName <- paste("APresults",GlobalCountryName,"txt",sep=".")

## Read functions libraries
source('funcs.R')
source('funcsAgg.R')
source('funcsNAP.R')

dirInfo          <- getDirInfo()
outDir           <- dirInfo$outDir
prefixDir        <- dirInfo$prefixDir
allData          <- readData(prefixDir)
countryToUse     <- which(allData$countryNames == GlobalCountryName) 
controlVar       <- getControlVar()
controlAgg       <- getControlAgg()
controlVarNAP    <- getControlVarNAP(allData, controlAgg)
NamesNPosInfo    <- getNamesNPosInfo(allData)
parameters       <- NamesNPosInfo$UnobsNames
UnobsPosInfo     <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo   <- getBigDataPosInfo(UnobsPosInfo)

## creates folders for nextState and weights
if (controlVarNAP$createFolders == 1) createFolders(allData,controlVarNAP,outDir) 
if (controlVarNAP$updatePDivs) {
    ParEst <- getParEstimates(bigDataPosInfo,controlAgg$usePooledChains,
                                controlAgg$chainToUse) 
    
    ## Starts sinking (saving screen output) to file
    sink(file.path(outDir, APresultsFileName))
    cat('\n')
    cat('PARAMETERS\n')
    cat('\n')
    cat('rhoU:          ',controlVarNAP$rhoU,'\n')
    cat('gammaU:        ',controlVarNAP$gammaU,'\n')
    cat('psiU:          ',controlVarNAP$psiU,'\n')
    cat('thetaU:        ',controlVarNAP$thetaU,'\n')
    cat('\n')
    cat('Mu:            ',ParEst[bigDataPosInfo$mu][countryToUse],'\n')
    cat('sigmaEps:      ',sqrt(ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]),'\n')
    cat('chi:           ',sqrt(ParEst[bigDataPosInfo$chiSq][countryToUse]),'\n')
    cat('sigmaOmega:    ',sqrt(ParEst[bigDataPosInfo$sigmaSqOmega]),'\n')    
    cat('\n')
    cat('gammma:        ',ParEst[bigDataPosInfo$gammma],'\n')
    cat('rho:           ',ParEst[bigDataPosInfo$rho],'\n')
    cat('\n')
    cat('Country:       ',allData$countryNames[countryToUse],'\n')
    cat('\n')    
    cat('\n')
    cat('nStateGrid:    ',controlVarNAP$nStateGrid,'\n')
    cat('nStateNu:      ',controlVarNAP$nStateGridNu,'\n')
    cat('nStateXX:      ',controlVarNAP$nStateGridXX,'\n')
    cat('nStateSigmaSq: ',controlVarNAP$nStateGridSigmaSq,'\n') 
    cat('\n')
    ## Finish sinking
    sink()
    
    PDivs <- getPDivs_EZW(controlVarNAP,ParEst,bigDataPosInfo,printStuff = 1)  
    outputEZW <- list(allData = allData, controlVarNAP = controlVarNAP, 
                        ParEst = ParEst, bigDataPosInfo = bigDataPosInfo, 
                        PDivs = PDivs)    
    filename  <- file.path(outDir,paste('outputEZW.',
                        allData$countryNames[countryToUse],'.Rda',sep=""))
    save(outputEZW, file = filename)           
} else {   
    timer1 <- proc.time()[3]

    load(file.path(outDir,paste('outputEZW.',
                allData$countryNames[countryToUse],'.Rda',sep="")))

    allData        <- outputEZW$allData
    controlVarNAP  <- outputEZW$controlVarNAP
    ParEst         <- outputEZW$ParEst
    bigDataPosInfo <- outputEZW$bigDataPosInfo
    PDivs          <- outputEZW$PDivs
           
    cat('Time to Load:       ',proc.time()[3] - timer1,'\n')    
}

if (controlVarNAP$simulatePrices == 1){
    set.seed(-100000) ## sets initial value for random numbers generator
    ## Simulate prices
    simOutput <- simulateModel_EZW(countryToUse, controlVarNAP, ParEst, 
                                    bigDataPosInfo, controlVarNAP$nSim,
                                    controlVarNAP$nSimBurnin,printStuff = 1) 
    simOutputOnGrid  <- putSimOutputOnStateGrid(simOutput, controlVarNAP, 
                                                ParEst, bigDataPosInfo)
    
    ## Save output
    save(simOutput,       file = file.path(outDir,paste('simOutput.',      
                            allData$countryNames[countryToUse],'.Rda',sep="")))   
    save(simOutputOnGrid, file = file.path(outDir,paste('simOutputOnGrid.',
                            allData$countryNames[countryToUse],'.Rda',sep="")))   
    
    ## Compute returns and other stats for a particular country
    returnsEZW <- calcReturns(countryToUse,simOutput, simOutputOnGrid, 
                                PDivs, controlVarNAP, ParEst, bigDataPosInfo)
    
    ## Save output
    save(returnsEZW, file = file.path(outDir,paste('returnsEZW.',
                            allData$countryNames[countryToUse],'.Rda',sep=""))) 
    
    ## Starts sinking (saving screen output) to file
    sink(file.path(outDir, APresultsFileName), append = TRUE)
    
    ## Prints summary onto the screen    
    printSummaryStats(returnsEZW, controlVarNAP, Pref = 1)
    
    ## Finish sinking
    sink()
}
## Predictability
predic <- predictability_LeveredLRR(countryToUse,PDivs, ParEst, 
                                        controlVarNAP, bigDataPosInfo)

savePredictability_LeveredLRR(predic, outDir,countryToUse)         