#####################################################################
## This program calculates asset prices for our LRR model
##
## Emi Nakamura, Dmitriy Sergeyev, Jon Steinsson, (July 2016)
#####################################################################

rm(list = ls())

###################################################################
GlobalCountryName           <- "United.States"
GlobalCountryToSimulateData <- c("Australia","Belgium","Canada","Denmark",
                                "Finland","France","Germany","Italy",
                                "Netherlands","Norway","Portugal",
                                "Spain","Sweden","Switzerland",
                                "United.Kingdom","United.States")
GlobalBaseCountry           <- "United.States"
GlobalCreateNextStateFiles  <- 0
GlobalUpdatePDivs           <- 0
GlobalSimulatePrices        <- 0
###################################################################

APresultsFileName <- paste("APresults",GlobalCountryName,"txt",sep=".")

source('funcs.R')
source('funcsAgg.R')
source('funcsNAP.R')

dirInfo                  <- getDirInfo()
outDir                   <- dirInfo$outDir
prefixDir                <- dirInfo$prefixDir

allData                  <- readData(prefixDir)

controlVar               <- getControlVar()
controlAgg               <- getControlAgg()
controlVarNAP            <- getControlVarNAP(allData, controlAgg)

NamesNPosInfo            <- getNamesNPosInfo(allData)
parameters               <- NamesNPosInfo$UnobsNames
UnobsPosInfo             <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo           <- getBigDataPosInfo(UnobsPosInfo)

## creates folders for nextState and weights
if (controlVarNAP$createFolders == 1){
    createFolders(allData,controlVarNAP,outDir)
}

if (controlVarNAP$updatePDivs) {
    ParEst <- getParEstimates(bigDataPosInfo,controlAgg$usePooledChains,controlAgg$chainToUse)
    sink(file.path(outDir, APresultsFileName))
    sink()

    for (nn in c(1:length(controlVarNAP$countryToComputePrice))){
        countryToUse <- controlVarNAP$countryToComputePrice[nn]

        sink(file.path(outDir, APresultsFileName),append = TRUE)
        cat('runNAP.R\n')
        cat('---------------------------------------------------------\n')
        cat(allData$countryNames[controlVarNAP$countryToComputePrice[nn]],'\n')
        cat('---------------------------------------------------------\n')
        cat('\n')
        cat('PARAMETERS\n')
        cat('\n')
        cat('rhoU:                     ',controlVarNAP$rhoU,'\n')
        cat('gammaU:                   ',controlVarNAP$gammaU,'\n')
        cat('psiU:                     ',controlVarNAP$psiU,'\n')
        cat('thetaU:                   ',controlVarNAP$thetaU,'\n')
        cat('\n')

        cat('Mu:                       ',ParEst[bigDataPosInfo$mu][countryToUse],'\n')
        cat('sigmaEpsW:                ',sqrt(ParEst[bigDataPosInfo$sigmaSqConstW]),'\n')
        cat('sigmaEps:                 ',sqrt(ParEst[bigDataPosInfo$sigmaSqConst][countryToUse]),'\n')
        cat('chi:                      ',sqrt(ParEst[bigDataPosInfo$chiSq][countryToUse]),'\n')
        cat('sigmaOmega:               ',sqrt(ParEst[bigDataPosInfo$sigmaSqOmega]),'\n')
        cat('sigmaOmegaW:              ',sqrt(ParEst[bigDataPosInfo$sigmaSqOmegaW]),'\n')
        cat('\n')

        cat('gammma:                   ',ParEst[bigDataPosInfo$gammma],'\n')
        cat('rho:                      ',ParEst[bigDataPosInfo$rho],'\n')
        cat('rhoW:                     ',ParEst[bigDataPosInfo$rhoW],'\n')
        cat('lambda:                   ',ParEst[bigDataPosInfo$lambda],'\n')
        cat('lambdaW:                  ',ParEst[bigDataPosInfo$lambdaW],'\n')
        cat('\n')

        cat('Country:                  ',allData$countryNames[countryToUse],'\n')
        cat('\n')

        cat('\n')
        cat('nCoarseStateGrid:         ',controlVarNAP$nCoarseStateGrid,'\n')
        cat('nCoarseStateNu:           ',controlVarNAP$nCoarseStateGridNu,'\n')
        cat('nCoarseStateXX:           ',controlVarNAP$nCoarseStateGridXX,'\n')
        cat('nCoarseStateXXW:          ',controlVarNAP$nCoarseStateGridXXW,'\n')
        cat('nCoarseStateSigmaSq:      ',controlVarNAP$nCoarseStateGridSigmaSq,'\n')
        cat('nCoarseStateSigmaSqW:     ',controlVarNAP$nCoarseStateGridSigmaSqW,'\n')

        cat('\n')
        cat('nFineStateGrid:         ',controlVarNAP$nFineStateGrid,'\n')
        cat('nFineStateNu:           ',controlVarNAP$nFineStateGridNu,'\n')
        cat('nFineStateXX:           ',controlVarNAP$nFineStateGridXX,'\n')
        cat('nFineStateXXW:          ',controlVarNAP$nFineStateGridXXW,'\n')
        cat('nFineStateSigmaSq:      ',controlVarNAP$nFineStateGridSigmaSq,'\n')
        cat('nFineStateSigmaSqW:     ',controlVarNAP$nFineStateGridSigmaSqW,'\n')

        cat('\n')
        sink()

        PDivs <- getPDivs_EZW(allData,countryToUse,controlVarNAP,
                                ParEst,bigDataPosInfo,printStuff = 1)

        outputEZW  <- list(allData        = allData,
                           controlVarNAP  = controlVarNAP,
                           ParEst         = ParEst,
                           bigDataPosInfo = bigDataPosInfo,
                           PDivs          = PDivs,
                           countryToUse   = countryToUse)

        filename   <- file.path(outDir,paste('outputEZW.',
                            allData$countryNames[countryToUse],'.Rda',sep=""))
        
        save(outputEZW, file = filename)
    }
}

if (controlVarNAP$simulatePrices == 1){
    set.seed(-100000)
    ## Simulate Global Components
    countryToUse    <- controlVarNAP$countryToSimulateData[1]

    filename        <- file.path(outDir,paste('outputEZW.',
                        allData$countryNames[countryToUse],'.Rda',sep=""))
    load(filename)

    ParEst          <- outputEZW$ParEst
    bigDataPosInfo  <- outputEZW$bigDataPosInfo

    simGlobalOutput <- simulateGlobal_EZW(controlVarNAP, ParEst, bigDataPosInfo, 
                                controlVarNAP$nSim,controlVarNAP$nSimBurnin,
                                printStuff = 1)

    filename        <- file.path(outDir,'simGlobalOutput.Rda')
    save(simGlobalOutput, file = filename)

    ## Initialize summaryStatsBigFile file
    initializeSummaryStatsBigFile(allData,controlVarNAP)

    ## Simulate Country Data + Calculate Returns + Calculate Predictability
    for (nn in 1:length(controlVarNAP$countryToSimulateData)){

        countryToUse    <- controlVarNAP$countryToSimulateData[nn]
        filename        <- file.path(outDir,paste('outputEZW.',
                            allData$countryNames[countryToUse],'.Rda',sep=""))
        load(filename)

        PDivs           <- outputEZW$PDivs
        ParEst          <- outputEZW$ParEst
        bigDataPosInfo  <- outputEZW$bigDataPosInfo

        simOutput       <- simulateModel_EZW(countryToUse, controlVarNAP, ParEst, 
                                bigDataPosInfo, simGlobalOutput ,controlVarNAP$nSim,
                                controlVarNAP$nSimBurnin,printStuff = 1)
        simOutputOnGrid <- putSimOutputOnStateGrid(countryToUse,simOutput, 
                                controlVarNAP, ParEst, bigDataPosInfo)

        filename <- file.path(outDir,paste('simOutput.',allData$countryNames[countryToUse],'.Rda',sep=""))
        save(simOutput, file = filename)

        filename <- file.path(outDir,paste('simOutputOnGrid.',allData$countryNames[countryToUse],'.Rda',sep=""))
        save(simOutputOnGrid, file = filename)

        ## Compute returns and other stats for a particular country
        returnsEZW     <- calcReturns(countryToUse,simOutput, simOutputOnGrid, PDivs, controlVarNAP, ParEst, bigDataPosInfo)
        filename       <- file.path(outDir,paste('returnsEZW.',allData$countryNames[countryToUse],'.Rda',sep=""))
        save(returnsEZW, file = filename)

        filename <- file.path(outDir, APresultsFileName)
        sink(filename, append = TRUE)
        cat('---------------------------------------------------------\n')
        cat(allData$countryNames[countryToUse],'\n')
        cat('---------------------------------------------------------\n')
        printSummaryStats(returnsEZW, controlVarNAP, Pref = 1)
        saveSummaryStatsBigFile(allData,countryToUse,returnsEZW,controlVarNAP)

        sink()
        ## Predictability
        predic <- predictability_LeveredLRR(countryToUse,PDivs, ParEst, controlVarNAP, bigDataPosInfo)
        savePredictability_LeveredLRR(predic, outDir, countryToUse)
    }
} else {
    ## Initialize summaryStatsBigFile file
    initializeSummaryStatsBigFile(allData,controlVarNAP)

    ## Simulate Country Data + Calculate Returns + Calculate Predictability
    for (nn in 1:length(controlVarNAP$countryToSimulateData)){

        # Load prices
        countryToUse    <- controlVarNAP$countryToSimulateData[nn]
        filename        <- file.path(outDir,paste('outputEZW.',allData$countryNames[countryToUse],'.Rda',sep=""))
        load(filename)

        PDivs           <- outputEZW$PDivs
        ParEst          <- outputEZW$ParEst
        bigDataPosInfo  <- outputEZW$bigDataPosInfo

        # Load returns
        filename       <- file.path(outDir,paste('returnsEZW.',allData$countryNames[countryToUse],'.Rda',sep=""))
        load(filename)

        filename <- file.path(outDir, APresultsFileName)
        sink(filename, append = TRUE)
        cat('---------------------------------------------------------\n')
        cat(allData$countryNames[countryToUse],'\n')
        cat('---------------------------------------------------------\n')
        printSummaryStats(returnsEZW, controlVarNAP, Pref = 1)
        saveSummaryStatsBigFile(allData,countryToUse,returnsEZW,controlVarNAP)

        sink()
    }
}
saveSummaryStatsBigFileCSV()

sink()