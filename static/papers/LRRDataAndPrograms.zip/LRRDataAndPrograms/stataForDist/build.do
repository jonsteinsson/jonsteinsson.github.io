*************************************************
*****build.do
*****
*****collates data from each country, runs assorted regressions, compares with bansal et al
************************************************


clear

local countrylist asl be ca de fi fr ge it ne no po sp sw sz uk us
local asl Australia
local be Belgium
local ca Canada
local de Denmark
local fi Finland
local fr France
local ge Germany
local it Italy
local ne Netherlands
local no Norway
local po Portugal
local sp Spain
local sw Sweden
local sz Switzerland
local uk UK
local us USA

local loop 1
local typelist normal disast post1930 post1945 post1970

file open YEARSDATA using "../output/available.txt", write replace
file write YEARSDATA "country|dpstart|dpend|dpmissings|epstart|epend|epmissings|pstart|pend|pmissings|barroursuastart|barroursuaend|barroursuamissings" _n
file open REGRESSIONS using "../output/regressions.txt", write replace
file write REGRESSIONS "country|type|depvar|indepvar|horizon|coef|se|r^2|N" _n
file open SUMSTATS using "../output/sumstats.txt", write replace
file write SUMSTATS "country|type|logpd_mean|logpe_mean|gc_mean|gd_mean|ge_mean|rm_mean|rf_mean|volatil_mean|abs_eta_mean" _n
file open SUMSTATS_PAPER using "../output/sumstats_paper.txt", write replace
file write SUMSTATS_PAPER "country|type|gc_mean|gc_sd|AC1(gc)|AC1_1945(gc)|gd_mean|gd_sd|rm_mean|rm_sd|rf_mean|rf_sd|tr_mean|tr_sd|tr_norm|logpd_mean|logpd_sd|AC1(logpd)|" _n
file open REG_MEDIANS using "../output/reg_medians.txt", write replace
file write REG_MEDIANS "type|depvar|indepvar|horizon|coef_median|r2_median|countries" _n

*draw figures
foreach country of local countrylist {
	use "../../../raw/gfd/data/gfd_series.dta", clear
	keep if country == "`country'"
	
	mmerge year using ../../../raw/barro-ursua/data/bonddata.dta, type(1:1) unmatched(master) ukeep(rtb`country'  rb10y`country' dp`country')
	
	*correcting for error value in GFD (see description)
	replace pe = . if pe == 100 | pe == 1000	
	
	*clean up variables
	tsset year
	gen dp = dividend*.01
	gen ep = 1/pe
	gen lastprice = l.price
	gen totalreturns = (1 + (price-lastprice)/(lastprice) + dp * (price/lastprice))*(1/(1+dp`country'))
	gen pd = 1/dp 
	gen logpd = log(1/dp)
	gen logpe = log(1/ep)
	gen logdp = log(dp)
	gen logep = log(ep)
	
	drop dividend
	mmerge year using "../../../raw/volatility/data/volatility.dta", type(1:1) unmatched(none) ukeep(vol`country')
	
	
***************
***draw figures; store length of each series in availability.txt
***************
	*volatility vs dp
	quietly sum year if logdp!= .
	*years available
	local start `r(min)'
	local end `r(max)'
	levelsof(year) if dp == . & year >=`start' & year <= `end', local(missings)
	file write YEARSDATA "`country'|`start'|`end'|`missings'|"
	
	graph twoway (tsline logdp if year <=`end' & year >= `start', yaxis(1) ytitle("log dp", axis(1)) legend(label(1 "log dp")) cmissing(no)) (tsline vol`country' if year <=`end' & year >= `start', yaxis(2) ytitle("volatility", axis(2)) legend(label(2 "volatility")) cmissing(no)), title("Stochastic Volatility vs. Log D-P: ``country'', `start'-`end'")
	graph export ../output//logdp_vs_volatility_`country'.eps, replace
	
	*volitility vs ep
	quietly sum year if logep!= .
	local start `r(min)'
	local end `r(max)'
	levelsof(year) if ep == . & year >=`start' & year <= `end', local(missings)
	file write YEARSDATA "`start'|`end'|`missings'|" 

	graph twoway (tsline logep if year <=`end' & year >= `start', yaxis(1) ytitle("log ep", axis(1)) legend(label(1 "log ep")) cmissing(no)) (tsline vol`country' if year <=`end' & year >= `start', yaxis(2) ytitle("volatility", axis(2)) legend(label(2 "volatility")) cmissing(no)), title("Stochastic Volatility vs. Log E/P: ``country'', `start'-`end'")
	graph export ../output//logep_vs_volatility_`country'.eps, replace
	
	quietly sum year if price != .
	local start `r(min)'
	local end `r(max)'
	levelsof(year) if price == . & year >=`start' & year <= `end', local(missings)
	file write YEARSDATA "`start'|`end'|`missings'|"

	save ../temp/`country'.dta, replace
		
*************************	
***check with Barro-Ursua data
*************************
	use ../../../raw/barro-ursua/data/stockdata.dta, clear
	keep year rstock`country'
		
	quietly sum year if rstock`country' != .
	local start `r(min)'
	local end `r(max)'
	levelsof(year) if rstock`country' == . & year >=`start' & year <= `end', local(missings)
	file write YEARSDATA "`start'|`end'|`missings'" _n
		
	mmerge year using ../temp/`country'.dta, type(1:1) unmatched(using)
	replace rstock`country' = rstock`country'+1
	graph twoway (tsline totalreturns, legend(label(1 "GFD")) cmissing(no)) (tsline rstock`country', legend(label(2 "Barro-Ursua")) cmissing(no)), title("Total returns: Barro-Ursua vs. GFD, ``country''")
	graph export ..\\output\\barroursua_check\\totalreturns_`country'.eps, replace

***************
***compile all-country dataset to run regressions
***************
	mmerge year using ../../../raw/barro-ursua/data/stockdata.dta, type(1:1) unmatched(master) ukeep(rstock`country')
	mmerge year using ../../../raw/barro-ursua/data/consumptiondata.dta, type(1:1) unmatched(master) ukeep( cpcinx`country')
	mmerge year using ../../../raw/barro-ursua/data/disindicators.dta, type(1:1) unmatched(master) ukeep( disast`country')
	mmerge year using ../../../raw/barro-ursua/data/GDP.dta, type(1:1) unmatched(master) ukeep(ypcinx`country')

	rename ypcinx`country' ypcinx
	rename rstock`country' rstock
	rename rtb`country' rtb
	rename rb10y`country' rb10y
	rename dp`country' dprice
	rename cpcinx`country' cpcinx
	rename disast`country' disast
	rename vol`country' volatil
	
	*run with all 'types'
	foreach type of local typelist {
		display "`country' regressions, type `type'"
		
		preserve
		sort year
		gen div = dp*price
		gen earn = ep*price		
		
		*GROSS growth variables
		gen deltad = div/l.div * 1/(1+dprice)
		gen deltae = earn/l.earn * 1/(1+dprice)
		gen deltac = cpcinx/l.cpcinx
		gen deltacy = (cpcinx/ypcinx)/(l.cpcinx/l.ypcinx)
		gen r_m = log(totalreturns)
		gen r_f = log(1+rtb)
		
		*dependent variables (g_c, g_d, g_e, etc)
		gen logdeltac = log(deltac)
		gen logdeltad = log(deltad)
		gen logdeltae = log(deltae)
		gen logdeltacy = log(deltacy)
		gen logvolatil = log(volatil)
		gen logexcessreturns = r_m - r_f
		
		*disaster indicators to missing
		if "`type'" == "disast" {
			foreach var in price pe dp ep lastprice totalreturns tr logdp logep volatil rstock rtb rb10y dprice cpcinx pd logpd logpe deltac logdeltac deltacy ypcinx logdeltacy logvolatil logexcessreturns r_f div earn deltad deltae logdeltad logdeltae {
				replace `var' = . if disast == 1
			}
		}
		*truncate sample, if required
		if regexm("`type'", "[0-9]+$") == 1 {
			foreach var in price pe dp ep lastprice totalreturns tr logdp logep volatil rstock rtb rb10y dprice cpcinx pd logpd logpe deltac logdeltac deltacy ypcinx logdeltacy logvolatil logexcessreturns r_m div earn deltad deltae logdeltad logdeltae {
				replace `var' = . if year < real(regexs(0))
			}
		}
		
		*Bansal's measure of volatility
		reg logdeltac l.logdeltac
		predict bansal_vol, r
		replace bansal_vol = abs(bansal_vol)
			
		local horizons 1 3 5
		foreach horizon of local horizons {
			display "horizon: `horizon' year"
			
			**generate horizon variables
			gen logconsump_`horizon'=0
			gen loglagconsump_`horizon'=0
			gen logvolatil_`horizon'=0
			gen logearnings_`horizon'=0
			gen logdividend_`horizon'=0
			gen logexcessreturns_`horizon'=0
			gen bansal_vol_`horizon'=0
			forval i=1(1)`horizon' {
				replace logconsump_`horizon' = logconsump_`horizon'+f`i'.logdeltac
				replace loglagconsump_`horizon' = loglagconsump_`horizon'+l`i'.logvolatil
				replace logvolatil_`horizon' = logvolatil_`horizon'+f`i'.logvolatil
				replace logearnings_`horizon' = logearnings_`horizon'+f`i'.logdeltae
				replace logdividend_`horizon' = logdividend_`horizon'+f`i'.logdeltad
				replace logexcessreturns_`horizon' = logexcessreturns_`horizon'+f`i'.logexcessreturns
				replace bansal_vol_`horizon' = bansal_vol_`horizon'+f`i'.bansal_vol
			}
			replace logvolatil_`horizon' = logvolatil_`horizon'/`horizon'
			gen logbansal_vol_`horizon' = log(bansal_vol_`horizon')
		}
		
		if `loop' == 1 {
			save ..\temp\\allcountries_`type'.dta, replace
		}
		else {
			append using ..\temp\\allcountries_`type'.dta
			save ..\temp\allcountries_`type'.dta, replace
		}
		restore
	}
	local loop = `loop'+1
}

*************************	
***regressions 
*************************

foreach type of local typelist {
	use ../temp/allcountries_`type'.dta, clear
	egen country_id = group(country)
	xtset country_id year
	
	*************************	
	***regressions by country
	*************************
	foreach country of local countrylist {
		foreach horizon of local horizons {
			foreach depvar in logconsump logvolatil logearnings logdividend logexcessreturns logbansal_vol {
				display "depvar: `depvar'"
				reg `depvar'_`horizon' logpe if country == "`country'"
				local beta=_b[logpe]
				local se=_se[logpe]
				file write REGRESSIONS "`country'|`type'|`depvar'|logpe|`horizon'|`beta'|`se'|`e(r2)'|`e(N)'" _n
				reg `depvar'_`horizon' logpd if country == "`country'"
				local beta=_b[logpd]
				local se=_se[logpd]
				file write REGRESSIONS "`country'|`type'|`depvar'|logpd|`horizon'|`beta'|`se'|`e(r2)'|`e(N)'" _n
				if "`depvar'" == "logconsump" | "`depvar'" == "logearnings" | "`depvar'" == "logdividend" {
					reg `depvar'_`horizon' logpd r_f if country == "`country'"
					local beta_pd=_b[logpd]
					local se_pd=_se[logpd]
					local beta_rf=_b[r_f]
					local se_rf=_se[r_f]
					file write REGRESSIONS "`country'|`type'|`depvar'|logpd,r_f|`horizon'|`beta_pd',`beta_rf'|`se_pd',`se_rf'|`e(r2)'|`e(N)'" _n	
					if "`depvar'" == "logconsump" {
						reg `depvar'_`horizon' logpd r_f logdeltacy if country == "`country'"
						local beta_pd=_b[logpd]
						local se_pd=_se[logpd]
						local beta_rf=_b[r_f]
						local se_rf=_se[r_f]			
						local beta_cy=_b[logdeltacy]
						local se_cy=_se[logdeltacy]
						file write REGRESSIONS "`country'|`type'|`depvar'|logpd,r_f,logdeltacy|`horizon'|`beta_pd',`beta_rf',`beta_cy'|`se_pd',`se_rf',`se_cy'|`e(r2)'|`e(N)'" _n							
						local beta_pd=_b[logpd]
						local se_pd=_se[logpd]
						local beta_rf=_b[r_f]
						local se_rf=_se[r_f]			
						local beta_cy=_b[logdeltacy]
						local se_cy=_se[logdeltacy]
						local beta_c=_b[logdeltac]
						local se_c=_se[logdeltac]
						file write REGRESSIONS "`country'|`type'|`depvar'|logpd,r_f,logdeltacy,logdeltac|`horizon'|`beta_pd',`beta_rf',`beta_cy',`beta_c'|`se_pd',`se_rf',`se_cy',`se_c'|`e(r2)'|`e(N)'" _n							
					}
				}
			}
		}
		foreach depvar in logdp logep logpd logpe {
			reg `depvar' l.logvolatil if country == "`country'"
			local beta=_b[l.logvolatil]
			local se=_se[l.logvolatil]
			file write REGRESSIONS "`country'|`type'|`depvar'|l.logvolatil|`horizon'|`beta'|`se'|`e(r2)'|`e(N)'" _n
		}
		foreach depvar in logpe logpd {
			reg `depvar' l1.logdeltac if country == "`country'"
			file write REGRESSIONS "`country'|`type'|`depvar'|l1.logdeltac|lag: 1|||`e(r2)'|`e(N)'" _n				

			reg `depvar' l3.logdeltac if country == "`country'"
			file write REGRESSIONS "`country'|`type'|`depvar'|l3.logdeltac|lag: 3|||`e(r2)'|`e(N)'" _n					

			reg `depvar' l5.logdeltac if country == "`country'"
			file write REGRESSIONS "`country'|`type'|`depvar'|l5.logdeltac|lag: 5|||`e(r2)'|`e(N)'" _n					
		}
	}
	
	*************************	
	***regressions over entire sample
	*************************	
	local country ALL
	foreach horizon of local horizons {
		foreach depvar in logconsump logvolatil logearnings logdividend logexcessreturns logbansal_vol {
			display "depvar: `depvar'"
			xtreg `depvar'_`horizon' logpe, vce(cluster country)
			local beta=_b[logpe]
			local se=_se[logpe]
			file write REGRESSIONS "`country'|`type'|`depvar'|logpe|`horizon'|`beta'|`se'|`e(r2_b)'|`e(N)'" _n
			xtreg `depvar'_`horizon' logpd, vce(cluster country)
			local beta=_b[logpd]
			local se=_se[logpd]
			file write REGRESSIONS "`country'|`type'|`depvar'|logpd|`horizon'|`beta'|`se'|`e(r2_b)'|`e(N)'" _n
			if "`depvar'" == "logconsump" | "`depvar'" == "logearnings" | "`depvar'" == "logdividend" {
				xtreg `depvar'_`horizon' logpd r_f, vce(cluster country)
				local beta_pd=_b[logpd]
				local se_pd=_se[logpd]
				local beta_rf=_b[r_f]
				local se_rf=_se[r_f]
				file write REGRESSIONS "`country'|`type'|`depvar'|logpd,r_f|`horizon'|`beta_pd',`beta_rf'|`se_pd',`se_rf'|`e(r2_b)'|`e(N)'" _n		
				if "`depvar'" == "logconsump" {
					xtreg `depvar'_`horizon' logpd r_f logdeltacy, vce(cluster country)
					local beta_pd=_b[logpd]
					local se_pd=_se[logpd]
					local beta_rf=_b[r_f]
					local se_rf=_se[r_f]			
					local beta_cy=_b[logdeltacy]
					local se_cy=_se[logdeltacy]
					file write REGRESSIONS "`country'|`type'|`depvar'|logpd,r_f,logdeltacy|`horizon'|`beta_pd',`beta_rf',`beta_cy'|`se_pd',`se_rf',`se_cy'|`e(r2_b)'|`e(N)'" _n								
					xtreg `depvar'_`horizon' logpd r_f logdeltacy logdeltac, vce(cluster country)
					local beta_pd=_b[logpd]
					local se_pd=_se[logpd]
					local beta_rf=_b[r_f]
					local se_rf=_se[r_f]			
					local beta_cy=_b[logdeltacy]
					local se_cy=_se[logdeltacy]
					local beta_c=_b[logdeltac]
					local se_c=_se[logdeltac]
					file write REGRESSIONS "`country'|`type'|`depvar'|logpd,r_f,logdeltacy,logdeltac|`horizon'|`beta_pd',`beta_rf',`beta_cy',`beta_c'|`se_pd',`se_rf',`se_cy',`se_c'|`e(r2_b)'|`e(N)'" _n								
				}
			}
		}
		foreach depvar in logpe logpd {
			xtreg `depvar' loglagconsump_`horizon', vce(cluster country)
			local beta=_b[loglagconsump_`horizon']
			local se=_se[loglagconsump_`horizon']
			file write REGRESSIONS "`country'|`type'|`depvar'|loglagconsump|`horizon'|`beta'|`se'|`e(r2_b)'|`e(N)'" _n					
		}
	}
	
	foreach depvar in logdp logep logpd logpe {
		xtreg `depvar' l.logvolatil, vce(cluster country)
		local beta=_b[l.logvolatil]
		local se=_se[l.logvolatil]
		file write REGRESSIONS "`country'|`type'|`depvar'|l.logvolatil|`horizon'|`beta'|`se'|`e(r2_b)'|`e(N)'" _n
	}
	foreach depvar in logpe logpd {
			xtreg `depvar' l1.logdeltac, vce(cluster country)
			file write REGRESSIONS "`country'|`type'|`depvar'|l1.logdeltac|lag: 1|||`e(r2_b)'|`e(N)'" _n			
			
			xtreg `depvar' l1.logdeltac l2.logdeltac l3.logdeltac, vce(cluster country)
			file write REGRESSIONS "`country'|`type'|`depvar'|l3.logdeltac|lag: 3|||`e(r2_b)'|`e(N)'" _n	
			
			xtreg `depvar' l1.logdeltac l2.logdeltac l3.logdeltac l4.logdeltac l5.logdeltac, vce(cluster country)
			file write REGRESSIONS "`country'|`type'|`depvar'|l5.logdeltac|lag: 5|||`e(r2_b)'|`e(N)'" _n	
	}
}

file close REGRESSIONS

*************************	
***regression medians
*************************

insheet using ../output/regressions.txt, delimiter("|") clear
drop if country == "ALL"
drop if indepvar != "logpd"
destring coef se, replace
foreach type of local typelist {
	foreach horizon of local horizons {
		foreach depvar in logconsump logvolatil logearnings logdividend logexcessreturns logbansal_vol {
			file write REG_MEDIANS "`type'|`depvar'|logpd|`horizon'|"
			preserve
			keep if depvar == "`depvar'"
			keep if horizon == "`horizon'"
			keep if type == "`type'"
			quietly sum coef, det
			local coef_median `r(p50)'
			quietly sum r2, det
			local r2_median `r(p50)'
			file write REG_MEDIANS "`coef_median'|`r2_median'|`r(N)'" _n
			restore
		}
	}
}

insheet using ../output/regressions.txt, delimiter("|") clear
drop if country == "ALL"
drop if (dep != "logpd" & dep != "logpe")
drop if indep != "l.logvolatil"
destring coef se, replace
foreach type of local typelist {
	foreach depvar in logpd logpe {
		file write REG_MEDIANS "`type'|`depvar'|l.logvolatil|`horizon'|"
		preserve
		keep if depvar == "`depvar'"
		keep if type == "`type'"
		quietly sum coef, det
		local coef_median `r(p50)'
		quietly sum r2, det
		local r2_median `r(p50)'
		file write REG_MEDIANS "`coef_median'|`r2_median'|`r(N)'" _n
		restore
	}
}


insheet using ../output/regressions.txt, delimiter("|") clear
drop if country == "ALL"
drop if (indep != "logpd,r_f") & (dep != "logconsump" | (indep != "logpd" & indep != "logpd,r_f" & indep != "logpd,r_f,logdeltacy" & indep != "logpd,r_f,logdeltacy,logdeltac")) & (dep != "logpd" | (indep != "l1.logdeltac" & indep != "l3.logdeltac" & indep != "l5.logdeltac"))
drop coef se
foreach type of local typelist {
	foreach depvar in logconsump logearnings logdividend {
		foreach horizon of local horizons {
			file write REG_MEDIANS "`type'|`depvar'|logpd,r_f|`horizon'|"
			preserve
			keep if depvar == "`depvar'"
			keep if horizon == "`horizon'"
			keep if type == "`type'"
			quietly sum r2, det
			local r2_median `r(p50)'
			file write REG_MEDIANS "|`r2_median'|`r(N)'" _n
			restore
		}
	}
	foreach indepvar in logpd logpd,r_f,logdeltacy logpd,r_f,logdeltacy,logdeltac {
		foreach horizon of local horizons {
			file write REG_MEDIANS "`type'|logconsump|`indepvar'|`horizon'|"
			preserve
			keep if indepvar == "`indepvar'"
			keep if horizon == "`horizon'"
			keep if type == "`type'"
			quietly sum r2, det
			local r2_median `r(p50)'
			file write REG_MEDIANS "|`r2_median'|`r(N)'" _n
			restore
		}
	}
	foreach horizon of local horizons {
		file write REG_MEDIANS "`type'|logpd|l`horizon'.logdeltac|`horizon'|"
		preserve
		keep if depvar == "logpd"
		keep if indepvar == "l`horizon'.logdeltac"
		keep if type == "`type'"
		quietly sum r2, det
		local r2_median `r(p50)'
		file write REG_MEDIANS "|`r2_median'|`r(N)'" _n
		restore	
	}
}

			
*************************	
***summarize data
*************************
foreach type of local typelist {
	use ../temp/allcountries_`type'.dta, clear
	egen country_id = group(country)
	xtset country_id year
	

	*** GENERAL SUMMARY STATS
	foreach country of local countrylist {
		file write SUMSTATS "`country'|`type'|"
		sum logpd if country == "`country'"
		file write SUMSTATS "`r(mean)'|"
		sum logpe if country == "`country'"
		file write SUMSTATS "`r(mean)'|"
		sum logdeltac if country == "`country'"
		file write SUMSTATS "`r(mean)'|"
		sum logdeltad if country == "`country'"
		file write SUMSTATS "`r(mean)'|"
		sum logdeltae if country == "`country'"
		file write SUMSTATS "`r(mean)'|"
		sum r_m if country == "`country'"
		file write SUMSTATS "`r(mean)'|"
		sum r_f if country == "`country'"
		file write SUMSTATS "`r(mean)'|"
		sum logvolatil if country == "`country'"
		file write SUMSTATS "`r(mean)'|"
		sum bansal_vol if country == "`country'"
		file write SUMSTATS "`r(mean)'" _n
	}
	
	local country ALL
	file write SUMSTATS "`country'|`type'|"
	sum logpd 
	file write SUMSTATS "`r(mean)'|"
	sum logpe 
	file write SUMSTATS "`r(mean)'|"
	sum logdeltac 
	file write SUMSTATS "`r(mean)'|"
	sum logdeltad 
	file write SUMSTATS "`r(mean)'|"
	sum logdeltae 
	file write SUMSTATS "`r(mean)'|"
	sum r_m 
	file write SUMSTATS "`r(mean)'|"
	sum r_f 
	file write SUMSTATS "`r(mean)'|"
	sum logvolatil 
	file write SUMSTATS "`r(mean)'|"
	sum bansal_vol 
	file write SUMSTATS "`r(mean)'" _n

	
	***SUMMARY STATS FOR PAPER
	gen sum_logpd = log(price) - log(div)
	gen sum_logpe = log(price) - log(ep*price)
	gen sum_deltac = log(cpcinx) - log(l.cpcinx)
	gen sum_deltad = log(div) - log(l.div) - log(1+dprice)
	gen sum_r_f = 1+rtb
	gen sum_r_m = totalreturns
	gen sum_excessreturns = sum_r_m-sum_r_f
	
	foreach country of local countrylist {
		file write SUMSTATS_PAPER "`country'|`type'|"
		sum sum_deltac if country == "`country'"
		file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
		corr(sum_deltac l.sum_deltac) if country == "`country'"
		file write SUMSTATS_PAPER "`r(rho)'|"
		corr(sum_deltac l.sum_deltac) if country == "`country'" & year >=1945
		file write SUMSTATS_PAPER "`r(rho)'|"
		sum sum_deltad if country == "`country'"
		file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
		sum sum_r_m if country == "`country'"
		file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
		sum sum_r_f if country == "`country'"
		file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
		sum sum_excessreturns if country == "`country'"
		local normalized=`r(mean)'/`r(sd)'
		file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|`normalized'|"
		sum sum_logpd if country == "`country'"
		file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
		corr(sum_logpd l.sum_logpd) if country == "`country'"
		file write SUMSTATS_PAPER "`r(rho)'|" _n
	}
	
	*all countries
	file write SUMSTATS_PAPER "ALL|`type'|"
	sum sum_deltac
	file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
	corr(sum_deltac l.sum_deltac)
	file write SUMSTATS_PAPER "`r(rho)'|"
	corr(sum_deltac l.sum_deltac) if year >=1945
	file write SUMSTATS_PAPER "`r(rho)'|"
	sum sum_deltad
	file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
	sum sum_r_m
	file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
	sum sum_r_f
	file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
	sum sum_excessreturns
	local normalized=`r(mean)'/`r(sd)'
	file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|`normalized'|"
	sum sum_logpd 
	file write SUMSTATS_PAPER "`r(mean)'|`r(sd)'|"
	corr(sum_logpd l.sum_logpd)
	file write SUMSTATS_PAPER "`r(rho)'|" _n
}


file close REG_MEDIANS
file close YEARSDATA
file close SUMSTATS
file close SUMSTATS_PAPER

