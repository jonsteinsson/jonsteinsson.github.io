clear

local countrylist asl be ca de fi fr ge it ne no po sp sw sz uk us

insheet using ../orig/stockdata.csv, clear
	rename v1 year
save ..\data\stockdata.dta, replace

insheet using ../orig/consumptiondata.csv, clear
save ../data/consumptiondata.dta, replace

insheet using ../orig/bonddata.csv, clear
save ../data/bonddata.dta, replace

insheet using ../orig/country_acnym.csv, clear names
save ../data/country_acnym.dta, replace

insheet using ../orig/DisIndicators.xls, clear
local asl australia
local be belgium
local ca canada
local de denmark
local fi finland
local fr france
local ge germany
local it italy
local ne netherlands
local no norway
local po portugal
local sp spain
local sw sweden
local sz switzerland
local uk unitedkingdom
local us unitedstates
foreach country of local countrylist {
	rename ``country'' disast`country'
	destring(disast`country'), replace ignore("NA")
}
rename v1 year
save ../data/disindicators.dta, replace

use ../data/GDP.dta, clear
rename  Indexes__2006_100 year
save ../data/GDP.dta, replace


