clear

local countrylist asl be ca de fi fr ge it ne no po sp sw sz uk us


*filenames (can easily change)
local asl_sto CJ_Verbeck_AORDD_20110425_csv
local asl_div CJ_Verbeck_SYAUSYM_20110425_csv
local asl_pe CJ_Verbeck_SYAUSPM_20110425_csv
local asl_tr CJ_Verbeck_AORDAD_20110510_csv
local be_sto CJ_Verbeck_BSPTD_20110425_csv
local be_div CJ_Verbeck_SYBELYM_20110425_csv
local be_pe CJ_Verbeck_SYBELPM_20110425_csv
local be_tr CJ_Verbeck_BCSHD_20110510_csv
local ca_sto CJ_Verbeck_GSPTSED_20110425_csv
local ca_div CJ_Verbeck_SYCANYTM_20110425_csv
local ca_pe CJ_Verbeck_SYCANPTM_20110425_csv
local ca_tr CJ_Verbeck_TRGSPTD_20110510_csv
local de_sto CJ_Verbeck_OMXCPID_20110425_csv
local de_div CJ_Verbeck_SYDNKYM_20110425_csv
local de_pe CJ_Verbeck_SYDNKPM_20110425_csv
local de_tr CJ_Verbeck_OMXCGID_20110510_csv
local fi_sto CJ_Verbeck_OMXHPID_20110425_csv
local fi_div CJ_Verbeck_SYFINYM_20110425_csv
local fi_pe CJ_Verbeck_SYFINPM_20110425_csv
local fi_tr CJ_Verbeck_OMXHGID_20110510_csv
local fr_sto CJ_Verbeck_SBF250D_20110425_csv
local fr_div CJ_Verbeck_SYFRAYM_20110425_csv
local fr_pe CJ_Verbeck_SYFRAPM_20110425_csv
local fr_tr CJ_Verbeck_TRSBF250D_20110510_csv
local ge_sto CJ_Verbeck_FWBXXD_20110425_csv
local ge_div CJ_Verbeck_SYDEUYM_20110425_csv
local ge_pe CJ_Verbeck_SYDEUPM_20110425_csv
local ge_tr CJ_Verbeck_CDAXD_20110510_csv
local it_sto CJ_Verbeck_BCIID_20110425_csv
local it_div CJ_Verbeck_SYITAYM_20110425_csv
local it_pe CJ_Verbeck_SYITAPM_20110425_csv
local it_tr CJ_Verbeck_BCIPRD_20110510_csv
local ne_sto CJ_Verbeck_AAXD_20110425_csv
local ne_div CJ_Verbeck_SYNLDYAM_20110425_csv
local ne_pe CJ_Verbeck_SYNLDPM_20110425_csv
local ne_tr CJ_Verbeck_AAXRD_20110510_csv
local no_sto CJ_Verbeck_OBXPD_20110425_csv
local no_div CJ_Verbeck_SYNORYM_20110425_csv
local no_pe CJ_Verbeck_SYNORPM_20110425_csv
local no_tr CJ_Verbeck_OBXD_20110510_csv
local po_sto CJ_Verbeck_PSI20D_20110425_csv
local po_div CJ_Verbeck_SYPRTYM_20110425_csv
local po_pe CJ_Verbeck_SYPRTPM_20110425_csv
local po_tr CJ_Verbeck_TRPSI2D_20110510_csv
local sp_sto CJ_Verbeck_SMSID_20110425_csv
local sp_div CJ_Verbeck_SYESPYM_20110425_csv
local sp_pe CJ_Verbeck_SYESPPM_20110425_csv
local sp_tr CJ_Verbeck_BCNPR3D_20110510_csv
local sw_sto CJ_Verbeck_OMXAFGD_20110425_csv
local sw_div CJ_Verbeck_SYSWEYM_20110425_csv
local sw_pe CJ_Verbeck_SYSWEPM_20110425_csv
local sw_tr CJ_Verbeck_SWAID_20110510_csv
local sz_sto CJ_Verbeck_SPIXD_20110425_csv
local sz_div CJ_Verbeck_SYCHEYM_20110425_csv
local sz_pe CJ_Verbeck_SYCHEPM_20110425_csv
local sz_tr CJ_Verbeck_SSHID_20110510_csv
local uk_sto CJ_Verbeck_FTASD_20110425_csv
local uk_div CJ_Verbeck_DFTASD_20110425_csv
local uk_pe CJ_Verbeck_PFTASD_20110425_csv
local uk_tr CJ_Verbeck_SPXTRD_20110510_csv
local us_sto CJ_Verbeck_SPXD_20110425_csv
local us_div CJ_Verbeck_SYUSAYM_20110425_csv
local us_pe CJ_Verbeck_SYUSAPM_20110425_csv
local us_tr CJ_Verbeck_TFTASD_20110510_csv

*generate time series
local flag 1
foreach country of local countrylist {
	insheet using ..\\orig\\``country'_sto'.csv, clear
	foreach var of varlist _all {
		local name=`var'[3]
		if "`name'" != "" rename `var' `name'
	}
	drop in 1/3
	if "`country'" == "us" {
		drop if _n>221
	}
	gen year = regexs(0) if regexm(Date,"[0-9]+$")
	rename Close price
	keep year price
	destring _all, replace
	save ../temp/`country'_stocks.dta, replace
	
	
	insheet using ../orig/``country'_div'.csv, clear
	foreach var of varlist _all {
		local name=`var'[3]
		if "`name'" != "" rename `var' `name'
	}
	drop in 1/3
	gen year = regexs(0) if regexm(Date,"[0-9]+$")
	rename Close dividend
	keep year dividend
	destring _all, replace
	save ../temp/`country'_dividend.dta, replace

	insheet using ../orig/``country'_pe'.csv, clear
	foreach var of varlist _all {
		local name=`var'[3]
		if "`name'" != "" rename `var' `name'
	}
	drop in 1/3
	gen year = regexs(0) if regexm(Date,"[0-9]+$")
	rename Close pe
	keep year pe
	destring _all, replace
	save ../temp/`country'_pe.dta, replace

	insheet using ../orig/``country'_tr'.csv, clear
	foreach var of varlist _all {
		local name=`var'[3]
		if "`name'" != "" rename `var' `name'
	}
	drop in 1/3
	gen year = regexs(0) if regexm(Date,"[0-9]+$")
	rename Close tr
	keep year tr
	destring _all, replace
	drop if year == .
	destring _all, replace
	save ../temp/`country'_tr.dta, replace

	
	use "../temp/`country'_stocks.dta", clear
	mmerge year using "../temp/`country'_dividend.dta", type(1:1) unmatched(master)
	mmerge year using "../temp/`country'_pe.dta", type(1:1) unmatched(master)
	mmerge year using "../temp/`country'_tr.dta", type(1:1) unmatched(master)

	drop _merge
	gen country = "`country'"
	order year country 
	
	if `flag' == 1 {
		save ../data/gfd_series.dta, replace
	} 
	else {
		append using ../data/gfd_series.dta
		sort country year
		save ../data/gfd_series.dta, replace
	}
	local flag=`flag'+1
}

label variable dividend "Dividend Yield"
label variable price "Stock Prices"
local variable pe "Price/Earnings"
label variable tr "Total Returns on Stocks"
save ../data/gfd_series.dta, replace

