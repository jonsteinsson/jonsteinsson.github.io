clear

**************Stochastic Volatility (from model)
use ..\data\volatility.dta, clear
rename C1 year
rename Australia volasl
rename Belgium volbe
rename Canada volca
rename Denmark volde
rename Finland volfi
rename France volfr
rename Germany volge
rename Italy volit
rename Netherlands volne
rename Norway volno
rename Portugal volpo
rename Spain volsp
rename Sweden volsw
rename Switzerland volsz
rename United_Kingdom voluk
rename United_States volus

save ..\data\volatility.dta, replace
