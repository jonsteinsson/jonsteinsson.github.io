% Calculates the autoregressive coefficients of 
% and AR(p) model in ADF form
%
% Jon Steinsson, July 2005
%************************************************

function ar_coeff = adfarcoeff(alpha,psi)

p = size(psi,1)+1;


ar_coeff = zeros(p,1);
if p == 1
    ar_coeff(1,1) = alpha;
else
    ar_coeff(1,1) = alpha+psi(1,1);
    if p > 2
        for j = 2:p-1
            ar_coeff(j,1) = -(psi(j-1,1)-psi(j,1));
        end
    end
    ar_coeff(end,1) = -psi(end,1);
end