% Calculates the half-life, up-life and quarter-life 
% of an AR(p) process
%
% Inputs: ar -- a vector with the autoregressive
%               coefficients of the AR(p) model
%               for which the half-life is to be
%               estimated
%
% Output: hl -- the half-life of the process
%         ul -- the up-life of the process
%         ql -- the quarter-life of the process
%
% The half-life is defined as the largest T such that
%
% IR(T-1) >= 0.5 and IR(T) < 0.5
%
% The up-life is defined as the largest T such that
%
% IR(T-1) >+ 1 and IR(T) < 1 (except that if IR never >1 then UL=0)
%
% The quarter-life is defined as the largest T such that
%
% IR(T-1) >= 0.25 and IR(T) < 0.25
%
% Jon Steinsson, September 2005
%*********************************************

function [hl,ul,ql] = ar_lives(alpha)

p = length(alpha);
A = zeros(p);
A(1,:) = alpha';
for i = 2:p
    A(i,i-1) = 1;
end
impact = zeros(p,1);
impact(1,1) = 1;
T = 400;
shock = 1;
y = VarImpulse(A,impact,shock,T);
y = y(2:end,1);
dt = 0:1:T; dt = dt';

i = 1;
ultrue = 0;
hltrue = 0;
qltrue = 0;
while qltrue == 0
    if i == 1
        if max(abs(y(i:end,1))) <= 1
            ul = 0;
            ultrue = 1;
        end
    elseif ultrue == 0
        if max(abs(y(i:end,1))) <= 1
            frac = (1-abs(y(i,1)))/(abs(y(i-1,1))-abs(y(i,1)));
            ul = (i-frac-1)/4;
            ultrue = 1;
        end
    end
    if hltrue == 0
        if max(abs(y(i:end,1))) <= 0.5
            frac = (0.5-abs(y(i,1)))/(abs(y(i-1,1))-abs(y(i,1)));
            hl = (i-frac-1)/4;
            hltrue = 1;
        end
    end
    if max(abs(y(i:end,1))) <= 0.25
        frac = (0.25-abs(y(i,1)))/(abs(y(i-1,1))-abs(y(i,1)));
        ql = (i-frac-1)/4;
        qltrue = 1;
    end
    i = i + 1;
    if i > 399
        hl = 1000;
        ql = 5000;
        ul = 1000;
        qltrue = 1;
    end
end
