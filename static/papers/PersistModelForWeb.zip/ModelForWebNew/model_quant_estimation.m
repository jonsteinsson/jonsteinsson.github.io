% Data is repeatedly simulated from the model described by 
% (G1,impact,relative). 
%
% An AR(p) model is fit to the real exchange rate.
%
% A grid-bootstrap is used to calculate a median unbiased
% estimate of alpha (the sum of the coefficients). The other 
% parameters of the AR(p) in augmented Dickey Fuller form are 
% estimates by OLS conditional on alpha. Given these estimates
% of the parameters, statistics such as the half-life, up-life
% quarter-life and impulse response function are calculated.
% 
% The distribution of these estimates is simulated by repeatedly 
% simulating data from the model and then calculating the statistics
% discribed above. The median and CI % confidence interval are 
% reported
%
% Jon Steinsson, Sept 2005
%***********************************************

function [alpha_med,psi_med,hl_med,ul_med,ql_med,ulhl_med,qlhl_med,thlql_med,...
        log2hlql_med,irf_med,rho_med,relstd_med,alpha_quant,hl_quant,...
        ul_quant,ql_quant,ulhl_quant,qlhl_quant,thlql_quant,log2hlql_quant,...
        irf_quant,rho_quant,relstd_quant] = model_quant_estimation(G1,impact,...
        relative,corr,corr_sup,T,quantiles,G,B,Gs,Nboot)

% Define variable that hold upper and lower quantiles
alpha_med = zeros(1,1);
psi_med = zeros(1,4);
hl_med = zeros(1,1);
ul_med = zeros(1,1);
ql_med = zeros(1,1);
qlhl_med = zeros(1,1);
ulhl_med = zeros(1,1);
thlql_med = zeros(1,1);
log2hlql_med = zeros(1,1);
irf_med = zeros(1,21);
rho_med = zeros(1,1);
relstd_med = zeros(1,1);
    
% Define variable that hold upper and lower quantiles
alpha_quant = zeros(2,1);
hl_quant = zeros(2,1);
ul_quant = zeros(2,1);
ql_quant = zeros(2,1);
qlhl_quant = zeros(2,1);
ulhl_quant = zeros(2,1);
thlql_quant = zeros(2,1);
log2hlql_quant = zeros(2,1);
irf_quant = zeros(2,21);
rho_quant = zeros(2,1);
relstd_quant = zeros(2,1);
    
Burn = 100;
    
qlow = quantiles(1,1)*(Nboot+1)-mod(quantiles(1,1)*(Nboot+1),1);
if qlow == 0
    qlow = 1;
end
qmed = 0.5*(Nboot+1)-mod(0.5*(Nboot+1),1);
if qmed == 0
    qmed = 1;
end
qhigh = quantiles(2,1)*(Nboot+1)-mod(quantiles(2,1)*(Nboot+1),1);
if qhigh == 0
    qhigh = 1;
end

fprintf('qlow qmed qhigh')
[qlow qmed qhigh]

p = 5;

pl = 0; % Indicator as to whether ar_gb_alpha should create a plot
intpr = 0; %Indicator as to whether ar_gb_alpha should print progress signals

dimG1 = size(G1,1);

% Preliminary OLS Estimation
%******************************************************

% Simulate data from model
mu = zeros(T+Burn,2);
sigma = [1 corr; corr 1];
sigma2 = [1 corr_sup; corr_sup 1];
shocks = mvnrnd(mu,sigma);
shocks2 = mvnrnd(mu,sigma2);
shocks = [shocks2 shocks];
X = VarSimulation(G1,impact,shocks,relative,T,Burn);
q = X(:,dimG1);

% Variables for the regressions
qt = q(p+1:end,1);
qt_1 = q(p:end-1,1);
TT = size(qt,1);
Dqt = zeros(TT,p-1);
for i = 1:(p-1)
    Dqt(:,i) = q(p+1-i:end-i,1)-q(p-i:end-1-i,1);
end
YY = qt;
XX = [ones(TT,1) qt_1 Dqt];
b_ols = inv(XX'*XX)*XX'*YY;
alpha_ols = b_ols(2,1);
psi_ols = b_ols(3:end,1);

alpha_range = [alpha_ols-0.05;1];

% Simulate Distribution of Estimates
%***************************************************

%Define variable that hold distributions
alphaDist = zeros(Nboot,1);
psiDist = zeros(Nboot,4);
hlDist = zeros(Nboot,1);
ulDist = zeros(Nboot,1);
qlDist = zeros(Nboot,1);
qlhlDist = zeros(Nboot,1);
ulhlDist = zeros(Nboot,1);
thlqlDist = zeros(Nboot,1);
log2hlqlDist = zeros(Nboot,1);
irfDist = zeros(Nboot,21);
rhoDist = zeros(Nboot,1);
relstdDist = zeros(Nboot,1);

% Define variables that hold the number of times a certain variable is
% defined
ulhlNum = 0;
qlhlNum = 0;
thlqlNum = 0;
log2hlqlNum = 0;

for i = 1:Nboot
    % Simulate new data series
    mu = zeros(T+Burn,2);
    sigma = [1 1/2; 1/2 1];
    sigma2 = [1 0; 0 1];
    shocks = mvnrnd(mu,sigma);
    shocks2 = mvnrnd(mu,sigma2);
    shocks = [shocks2 shocks];
    X = VarSimulation(G1,impact,shocks,relative,T,Burn);
    qsim = X(:,15);
    csim = X(:,2);
    % Calculate MU estimate of alpha
    alphaDist(i,1) = ar_mu_alpha(qsim,p,alpha_range,G,B,Gs,0,0);
    % Estimate psi by OLS conditional on alpha
    qt = qsim(p+1:end,1);
    qt_1 = qsim(p:end-1,1);
    TT = size(qt,1);
    Dqt = zeros(TT,p-1);
    for j = 1:(p-1)
        Dqt(:,j) = qsim(p+1-j:end-j,1)-qsim(p-j:end-1-j,1);
    end
    XX = [ones(TT,1) Dqt];
    YY = qt - alphaDist(i,1)*qt_1;
    b = inv(XX'*XX)*XX'*YY;
    psiDist(i,:) = b(2:end,1)';    
    % Calculate MU estimates of other statistics
    ar_coeff_dist = adfarcoeff(alphaDist(i,1),psiDist(i,:)');
    [hlDist(i,1), ulDist(i,1), qlDist(i,1)] = ar_lives(ar_coeff_dist);
    if ulDist(i,1) == 1000
        ulhlDist(i,1) = NaN;
        qlhlDist(i,1) = NaN;
        thlqlDist(i,1) = NaN;
        log2hlqlDist(i,1) = NaN;
    elseif hlDist(i,1) == 1000
        ulhlDist(i,1) = 0;
        ulhlNum = ulhlNum + 1;
        qlhlDist(i,1) = NaN;
        thlqlDist(i,1) = NaN;
        log2hlqlDist(i,1) = NaN;
    elseif qlDist(i,1) == 5000
        ulhlDist(i,1) = ulDist(i,1)/hlDist(i,1);
        ulhlNum = ulhlNum + 1;
        qlhlDist(i,1) = 1000;
        qlhlNum = qlhlNum + 1;
        thlqlDist(i,1) = -1000;
        thlqlNum = thlqlNum + 1;
        log2hlqlDist(i,1) = -Inf;
        log2hlqlNum = log2hlqlNum + 1;
    else
        ulhlDist(i,1) = ulDist(i,1)/hlDist(i,1);
        ulhlNum = ulhlNum + 1;
        qlhlDist(i,1) = qlDist(i,1) - hlDist(i,1);
        qlhlNum = qlhlNum + 1;
        thlqlDist(i,1) = 2*hlDist(i,1) - qlDist(i,1);
        thlqlNum = thlqlNum + 1;
        log2hlqlDist(i,1) = log(2*hlDist(i,1)/qlDist(i,1));
        log2hlqlNum = log2hlqlNum + 1;
    end
    irf_dist = ar_irf(ar_coeff_dist,20,0);
    irfDist(i,:) = irf_dist';
    % Calculate CKM statistics
    q_hpc_sim = qsim-hpf(qsim,1600);
    rhoq_sim = corrcoef(q_hpc_sim(2:end,1),q_hpc_sim(1:end-1,1));
    rhoDist(i,1) = rhoq_sim(2,1);
    c_hpc_sim = csim-hpf(csim,1600);
    relstdDist(i,1) = std(q_hpc_sim)/std(c_hpc_sim);
    if mod(i,5) == 0
        fprintf('%1.0f ',i)
    end
    if mod(i,75) == 0
        fprintf('\n')
    end
end
fprintf('\n\n')    

alphaDist = sort(alphaDist);
psiDist = sort(psiDist);
hlDist = sort(hlDist);
ulDist = sort(ulDist);
qlDist = sort(qlDist);
qlhlDist = sort(qlhlDist);
ulhlDist = sort(ulhlDist);
thlqlDist = sort(thlqlDist);
log2hlqlDist = sort(log2hlqlDist);
irfDist = sort(irfDist);
rhoDist = sort(rhoDist);
relstdDist = sort(relstdDist);

qlowulhl = quantiles(1,1)*(ulhlNum+1)-mod(quantiles(1,1)*(ulhlNum+1),1);
if qlowulhl == 0
    qlowulhl = 1;
end
qmedulhl = 0.5*(ulhlNum+1)-mod(0.5*(ulhlNum+1),1);
if qmedulhl == 0
    qmedulhl = 1;
end
qhighulhl = quantiles(2,1)*(ulhlNum+1)-mod(quantiles(2,1)*(ulhlNum+1),1);
if qhighulhl == 0
    qhighulhl = 1;
end

qlowqlhl = quantiles(1,1)*(qlhlNum+1)-mod(quantiles(1,1)*(qlhlNum+1),1);
if qlowqlhl == 0
    qlowqlhl = 1;
end
qmedqlhl = 0.5*(qlhlNum+1)-mod(0.5*(qlhlNum+1),1);
if qmedqlhl == 0
    qmedqlhl = 1;
end
qhighqlhl = quantiles(2,1)*(qlhlNum+1)-mod(quantiles(2,1)*(qlhlNum+1),1);
if qhighqlhl == 0
    qhighqlhl = 1;
end

qlowthlql = quantiles(1,1)*(thlqlNum+1)-mod(quantiles(1,1)*(thlqlNum+1),1);
if qlowthlql == 0
    qlowthlql = 1;
end
qmedthlql = 0.5*(thlqlNum+1)-mod(0.5*(thlqlNum+1),1);
if qmedthlql == 0
    qmedthlql = 1;
end
qhighthlql = quantiles(2,1)*(thlqlNum+1)-mod(quantiles(2,1)*(thlqlNum+1),1);
if qhighthlql == 0
    qhighthlql = 1;
end

qlowlog2hlql = quantiles(1,1)*(log2hlqlNum+1)-mod(quantiles(1,1)*(log2hlqlNum+1),1);
if qlowlog2hlql == 0
    qlowlog2hlql = 1;
end
qmedlog2hlql = 0.5*(log2hlqlNum+1)-mod(0.5*(log2hlqlNum+1),1);
if qmedlog2hlql == 0
    qmedlog2hlql = 1;
end
qhighlog2hlql = quantiles(2,1)*(log2hlqlNum+1)-mod(quantiles(2,1)*(log2hlqlNum+1),1);
if qhighlog2hlql == 0
    qhighlog2hlql = 1;
end

alpha_med(1,1) = alphaDist(qmed,1);
psi_med(1,:) = psiDist(qmed,:);
hl_med(1,1) = hlDist(qmed,1);
ul_med(1,1) = ulDist(qmed,1);
ql_med(1,1) = qlDist(qmed,1);
qlhl_med(1,1) = qlhlDist(qmedqlhl,1);
ulhl_med(1,1) = ulhlDist(qmedulhl,1);
thlql_med(1,1) = thlqlDist(qmedthlql,1);
log2hlql_med(1,1) = log2hlqlDist(qmedlog2hlql,1);
irf_med(1,:) = irfDist(qmed,:);
rho_med(1,1) = rhoDist(qmed,1);
relstd_med(1,1) = relstdDist(qmed,1);

alpha_quant(1,1) = alphaDist(qlow,1); alpha_quant(2,1) = alphaDist(qhigh,1);
hl_quant(1,1) = hlDist(qlow,1); hl_quant(2,1) = hlDist(qhigh,1);
ul_quant(1,1) = ulDist(qlow,1); ul_quant(2,1) = ulDist(qhigh,1);
ql_quant(1,1) = qlDist(qlow,1); ql_quant(2,1) = qlDist(qhigh,1);
qlhl_quant(1,1) = qlhlDist(qlowqlhl,1); qlhl_quant(2,1) = qlhlDist(qhighqlhl,1);
ulhl_quant(1,1) = ulhlDist(qlowulhl,1); ulhl_quant(2,1) = ulhlDist(qhighulhl,1);
thlql_quant(1,1) = thlqlDist(qlowthlql,1); thlql_quant(2,1) = thlqlDist(qhighthlql,1);
log2hlql_quant(1,1) = log2hlqlDist(qlowlog2hlql,1); log2hlql_quant(2,1) = log2hlqlDist(qhighlog2hlql,1);
irf_quant(1,:) = irfDist(qlow,:); irf_quant(2,:) = irfDist(qhigh,:);
rho_quant(1,1) = rhoDist(qlow,1); rho_quant(2,1) = rhoDist(qhigh,1);
relstd_quant(1,1) = relstdDist(qlow,1); relstd_quant(2,1) = relstdDist(qhigh,1);
