% Model analyzed in "The Dynamic Behavior of the Real Exchange Rate in 
% Sticky Price Models", AER forthcoming.
%
% This program uses:
%   gensys.m written by Chris Sims
%   hpf.m written by Marianne Baxter and Robert King
%
% Jon Steinsson, Sept 2005
%*************************************************************************

clear;
tic

% Parameters that are the same accross all simulations
%*************************************************************************

b = 0.99;         % Discount factor
s = 1/5;          % Intertemporal elasticity of substitution
w = 3;            % Marginal Cost Elasticity
theta = 10;       % Elasticity of Demand
alpha = 0.75;     % Calvo probability that price is unchanged
p_r = 0.85;       % Coefficient on lagged interest rate in Taylor Rule
a_pi = 2;         % Coefficient on inflation in Taylor Rule
a_y = 0.5;        % Coefficient on output in Taylor Rule
p_m = 0.9;          % Autocorrelation of monetary shocks
corr = 0.5;       % Correlation of home and foreign monetary shocks
p_sup = 0.9;      % Autocorrelation of real shocks
corr_sup = 0.0;   % Correlation of home and foreign real shocks
phiH = 0.94;      % Home bias parameter
phiF = 1-phiH;
Cbar = 0.8;       % Steady state C/Y ratio

k = (1-alpha)*(1-alpha*b)/alpha;
g_q = 2*phiF*phiH;

% Structure of the labor market
%*************************************************************************
% These three choices of zeta correspond to the heterogeneous labor markets
% model, the homogeneous labor market model and the extreme model.

zeta = (w*Cbar+s^(-1))/(1+w*theta); % Heterogeneous Labor
%zeta = s^(-1);              % Homogeneous Labor
%zeta = 0.01;                  % Extreme Model

fprintf('\n')
fprintf('zeta = %5.3f\n',zeta)
fprintf('\n')

% Relative variance of shocks
%*************************************************************************
% The vector "relative" governs the relative variance of the four different
% shocks in the simulation. The four elements refer to:
% 1. home phillips curve shock, 2. foreign Phillips curve shock,
% 3. home money shock, 4. foreign money shock.

relative = [1; 0; 0; 0];

% Simulation Parameters
%*****************************************************************

runtype = 0; 
% If runtype = 2, then the program calculated impulse response functions 
% for the real exchange rate and other variables in response to the shock 
% vector "relative". From the IRF for the real exchange rate the program
% calculates various statistics and if pl=1 (see below) then it plots 
% a number of IRFs.
%
% If runtype = 1, then the program calculates statistics based on one long
% simulation of the model with the relative variances of the shocks given 
% by "relative".
%
% If runtype = 0, then the program calculates quantiles of distribution of 
% estimators using the bootstrap methods described in the paper.

T = 127; % Corresponds to 1975:1-2006:3

Burn = 100;
Tlong = 1000;

G = 80;
B = 249;
Gs = 250;
Nboot = 1000;

fprintf('G:     %5.3f\n',G)
fprintf('B:     %5.3f\n',B)
fprintf('Gs:    %5.3f\n',Gs)
fprintf('Nboot: %5.3f\n',Nboot)
fprintf('\n')

quantiles = [0.025;0.975];

pl = 1;    % If pl = 1, the program returns plots
intpr = 1; % If intpr = 1, q_mu_estimation prints progress signals

%***************************************************************
% Definition of the model in gensys.m form
%
% g0*y(t) = g1*y(t-1) + C + Psi*z(t) + Pi*eta(t) (See Sims, 2000)
%
% y(t) = [ E_t c_t+1, c_t, E_t c*_t+1, c*_t, E_t pi_t+1, pi_t,
%          E_t pi*_t+1, pi*_t, i_t, i*_t, a_t, a*_t, m_t, m*_t, q_t] 
%          (15 variables)

g0 = [1 -1 0 0 s 0 0 0 -s 0 0 0 0 0 0;
    0 0 1 -1 0 0 s 0 0 -s 0 0 0 0 0;
    0 1 0 -1 0 0 0 0 0 0 0 0 0 0 -s;
    0 (phiH^2+phiF^2)*k*zeta 0 2*phiH*phiF*k*zeta b -1 0 0 0 0 -phiH -phiF 0 0 k*g_q;
    0 2*phiH*phiF*k*zeta 0 (phiH^2+phiF^2)*k*zeta 0 0 b -1 0 0 -phiF -phiH 0 0 -k*g_q;
    0 -(1-p_r)*a_y 0 0 0 -(1-p_r)*a_pi 0 0 1 0 0 0 1 0 0;
    0 0 0 -(1-p_r)*a_y 0 0 0 -(1-p_r)*a_pi 0 1 0 0 0 1 0;
    0 0 0 0 0 0 0 0 0 0 1 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0 0 1 0 0 0;
    0 0 0 0 0 0 0 0 0 0 0 0 1 0 0;
    0 0 0 0 0 0 0 0 0 0 0 0 0 1 0;
    0 1 0 0 0 0 0 0 0 0 0 0 0 0 0;
    0 0 0 1 0 0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 1 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 1 0 0 0 0 0 0 0];

g1 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 p_r 0 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 p_r 0 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0 p_sup 0 0 0 0;
    0 0 0 0 0 0 0 0 0 0 0 p_sup 0 0 0;
    0 0 0 0 0 0 0 0 0 0 0 0 p_m 0 0;
    0 0 0 0 0 0 0 0 0 0 0 0 0 p_m 0;
    1 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
    0 0 1 0 0 0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 1 0 0 0 0 0 0 0 0 0 0;
    0 0 0 0 0 0 1 0 0 0 0 0 0 0 0];

pi = zeros(15,4);
pi(12,1) = 1; pi(13,2) = 1; 
pi(14,3) = 1; pi(15,4) = 1;

psi = zeros(15,4);
% 1. home phillips curve shock, 2. foreign Phillips curve shock,
% 3. home money shock, 4. foreign money shock.
psi(8,1) = 1; psi(9,2) = 1;
psi(10,3) = 1; psi(11,4) = 1;

c = zeros(15,1);

[G1,C,impact,fmat,fwt,ywt,gev,eu] = gensys(g0,g1,c,psi,pi);

% Calculate Persistence Properties of the Real 
% Exchange Rate
%***************************************************

p = 5; % Number of lags in AR(p) empirical model

if runtype == 2
    [hl,ul,ql] = model_lives(G1,impact,relative);
    ulhl = ul/hl;
    qlhl = ql - hl;
    thlql = 2*hl - ql;
    log2hlql = log(2*hl/ql);
    shock = relative.*ones(size(relative,1),1);
    irf = VarImpulse(G1,impact,shock,30);
    qirfnorm = irf(:,15)./irf(2,15);
        
    % Printout 
    fprintf('\n')
    fprintf('            True values \n')
    fprintf('half-life:    %5.3f \n',hl)
    fprintf('up-life:      %5.3f \n',ul)
    fprintf('quarter-life: %5.3f \n',ql)
    fprintf('UL/HL:        %5.3f \n',ulhl)
    fprintf('QL-HL:        %5.3f \n',qlhl)
    fprintf('2HL-QL:       %5.3f \n',thlql)
    fprintf('log(2HL/Ql):  %5.3f \n',log2hlql)
    fprintf('\n')
    
    % Plot Impulse Response
    if pl == 1
        dt  = 0:1:30;
        dt = dt';
        figure(1)
        plot(dt,irf(:,end),'k-',dt,zeros(31,1),'k-')
        title('Real Exchange Rate')
        figure(2)
        plot(dt,irf(:,2),'k-',dt,irf(:,6),'k:',dt,zeros(31,1),'k-')
        title('Consumption and Inflation')
        figure(3)
        plot(dt,irf(:,9),'k-',dt,irf(:,9)-irf(:,5),'k:',dt,zeros(31,1),'k-')
        title('Nominal Interest Rate and Real Interest Rate')
        figure(4)
        plot(dt,irf(:,2),'k-',dt,irf(:,4),'k:',dt,zeros(31,1),'k-')
        title('Home and Foreign Consumption')
    end
    
elseif runtype == 1
    % Sample shocks from mulitvariate normals
    mu = zeros(Tlong+Burn,2);
    sigma = [1 corr; corr 1];
    sigma2 = [1 corr_sup; corr_sup 1];
    shocks = mvnrnd(mu,sigma);
    shocks2 = mvnrnd(mu,sigma2);
    shocks = [shocks2 shocks];
    
    % Simulating the Model
    X = VarSimulation(G1,impact,shocks,relative,Tlong,Burn);
    Q = X(:,15);
    C = X(:,2);
    
    % Calculate MU estimates
    [alpha_mu,psi_mu,hl_mu,ul_mu,ql_mu,ulhl_mu,qlhl_mu,thlql_mu,...
        log2hlql_mu,irf_mu] = q_mu_estimation(Q,p,G,B,Gs,intpr);
    
    % Calculate CKM statistics
    q_hpc = Q-hpf(Q,1600);
    c_hpc = C-hpf(C,1600);
    rho1_q_hpc = corrcoef(q_hpc(2:end,1),q_hpc(1:end-1,1));
    rho1_q_hpc = rho1_q_hpc(2,1);
    c_std = std(c_hpc);
    rel_std_hpc = std(q_hpc)/c_std;
    
    % Printout 
    fprintf('\n')
    fprintf('            MU estimates \n')
    fprintf('alpha:        %5.3f \n',alpha_mu)
    fprintf('half-life:    %5.3f \n',hl_mu)
    fprintf('up-life:      %5.3f \n',ul_mu)
    fprintf('quarter-life: %5.3f \n',ql_mu)
    fprintf('UL/HL:        %5.3f \n',ulhl_mu)
    fprintf('QL-HL:        %5.3f \n',qlhl_mu)
    fprintf('2HL-QL:       %5.3f \n',thlql_mu)
    fprintf('log(2HL/Ql:   %5.3f \n',log2hlql_mu)
    fprintf('Rho_1 of HP:  %5.3f \n',rho1_q_hpc)
    fprintf('Rel. St.Dev.  %5.3f \n',rel_std_hpc)
    fprintf('\n')
    for i = 1:p-1
        fprintf('psi_%1.0f:       %6.3f\n',i,psi_mu(i,1))
    end
    
    % Plot Impulse Response
    if pl == 1
        dt  = 0:1:20;
        dt = dt';
        figure(1)
        plot(dt,irf_mu,'k-', dt,zeros(21,1),'k-')
        set(gca,'FontName','times')
        title('Impulse Response Function of the Real Exchange Rate');
    end
else
    [alpha_med,psi_med,hl_med,ul_med,ql_med,ulhl_med,qlhl_med,thlql_med,...
        log2hlql_med,irf_med,rho_med,relstd_med,alpha_quant,hl_quant,...
        ul_quant,ql_quant,ulhl_quant,qlhl_quant,thlql_quant,log2hlql_quant,...
        irf_quant,rho_quant,relstd_quant] = model_quant_estimation(G1,impact,...
        relative,corr,corr_sup,T,quantiles,G,B,Gs,Nboot);
    % Printout
    fprintf('\n')
    fprintf('             median      %2.0f percent CI \n',...
        (quantiles(2,1)-quantiles(1,1))*100)
    fprintf('alpha:       %5.3f   [%5.3f, %9.3f]\n',...
        alpha_med,alpha_quant(1,1),alpha_quant(2,1))
    fprintf('half-life:   %5.3f   [%5.3f, %9.3f]\n',...
        hl_med,hl_quant(1,1),hl_quant(2,1))
    fprintf('up-life:     %5.3f   [%5.3f, %9.3f]\n',...
        ul_med,ul_quant(1,1),ul_quant(2,1))
    fprintf('quarter-life:%5.3f   [%5.3f, %9.3f]\n',...
        ql_med,ql_quant(1,1),ql_quant(2,1))
    fprintf('UL/HL:       %5.3f   [%5.3f, %9.3f]\n',...
        ulhl_med,ulhl_quant(1,1),ulhl_quant(2,1))
    fprintf('QL-HL:       %5.3f   [%5.3f, %9.3f]\n',...
        qlhl_med,qlhl_quant(1,1),qlhl_quant(2,1))
    fprintf('2HL-Ql       %5.3f   [%5.3f, %9.3f]\n',...
        thlql_med,thlql_quant(1,1),thlql_quant(2,1)) 
    fprintf('log(2HL/Ql)  %5.3f   [%5.3f, %9.3f]\n',...
        log2hlql_med,log2hlql_quant(1,1),log2hlql_quant(2,1))
    fprintf('Rho_1 of HP  %5.3f   [%5.3f, %9.3f]\n',...
        rho_med,rho_quant(1,1),rho_quant(2,1))
    fprintf('Rel. St.Dev. %5.3f   [%5.3f, %9.3f]\n',...
        relstd_med,relstd_quant(1,1),relstd_quant(2,1))
    fprintf('\n')
    for i = 1:p-1
        fprintf('psi_%1.0f:       %6.3f\n',i,psi_med(1,i))
    end
end

% End
%***************************************************

toc

