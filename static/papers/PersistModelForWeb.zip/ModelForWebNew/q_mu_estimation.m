% 
% A grid-bootstrap is used to calculate a median unbiased
% estimate of alpha (the sum of the coefficients). The other 
% parameters of the AR(p) in augmented Dickey Fuller form are 
% estimates by OLS conditional on alpha. Given these estimates
% of the parameters, statistics such as the half-life, up-life
% quarter-life and impulse response function are calculated.
% 
%
% Jon Steinsson, Sept 2005
%***********************************************

function [alpha_mu,psi_mu,hl_mu,ul_mu,ql_mu,ulhl_mu,qlhl_mu,thlql_mu,...
        log2hlql_mu,irf_mu] = q_mu_estimation(q,p,G,B,Gs,intpr)

T = size(q,1);
pl = 0;

% Preliminary OLS Estimation
%******************************************************

% Variables for the regressions
qt = q(p+1:end,1);
qt_1 = q(p:end-1,1);
TT = size(qt,1);
Dqt = zeros(TT,p-1);
for i = 1:(p-1)
    Dqt(:,i) = q(p+1-i:end-i,1)-q(p-i:end-1-i,1);
end
YY = qt;
XX = [ones(TT,1) qt_1 Dqt];
b_ols = inv(XX'*XX)*XX'*YY;
alpha_ols = b_ols(2,1);
psi_ols = b_ols(3:end,1);


% MU Estimation
%******************************************************

% Calculate MU estimate of alpha
alpha_range = [alpha_ols-0.05;1];
alpha_mu = ar_mu_alpha(q,p,alpha_range,G,B,Gs,pl,intpr);

% Estimate psi by OLS conditional on alpha
XX = [ones(TT,1) Dqt];
YY = qt - alpha_mu*qt_1;
b = inv(XX'*XX)*XX'*YY;
psi_mu = b(2:end,1);
e_mu = YY-XX*b;

% Calculate MU estimates of other statistics
ar_coeff_mu = adfarcoeff(alpha_mu,psi_mu);
[hl_mu, ul_mu, ql_mu] = ar_lives(ar_coeff_mu);
ulhl_mu = ul_mu/hl_mu;
qlhl_mu = ql_mu - hl_mu;
thlql_mu = 2*hl_mu - ql_mu;
log2hlql_mu = log(2*hl_mu/ql_mu);
irf_mu = ar_irf(ar_coeff_mu,20,0);
