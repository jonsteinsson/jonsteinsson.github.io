% Two Region - Common Currency - Sticky price - 
% Homogeneous Factor - Small open economy limit
%
% July 2010
% Written by Emi Nakamura, Jon Steinsson and Thuy Lan Nguyen
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all

% Parameter values
sigma = 1;
alpha = 0.75;
beta = 0.99;
psi_v = 1;
eta = 1;
phi_H = 0.75;
phi_F = 1-phi_H;
Gbar = 0.05;
C_H = phi_H/(1+Gbar);
C_Hstar = 1/(1+Gbar)-C_H;
C_Fstar = 1/(1+Gbar); 
kappa = (1-alpha)*(1-alpha*beta)/alpha; 
rho_G = 0.9;
rho_Gf = 0.9;
phi_pi = 1.5;
phi_y = 0;


% %%%% DEFINE the system g0*x(t)=g1*x(t-1)+C+Psi*z(t)+Pi*eta(t)
% x_(t)= [
%  [1]   E_t c_t+1
%  [2]   c_t
%  [3]   E_t c*_t+1
%  [4]   c*_t
%  [5]   E_t pi_t+1
%  [6]   pi_t
%  [7]   E_t pi*_t+1
%  [8]   pi*_t
%  [9]   y_t
%  [10]  y*_t
%  [11]  tau_t
%  [12]  g_Ht
%  [13]  g_Ft
%  [14]  i_t]
  
c = zeros(14,1);

g0 = zeros(14,14);
g1 = zeros(14,14);
pi = zeros(14,4); % expectational errors
psi = zeros(14,2); % disturbances

% Euler home
g0(1,1) = 1;
g0(1,2) = -1;
g0(1,14) = -sigma;
g0(1,5) = sigma;

% Euler foreign
g0(2,3) = 1;
g0(2,4) = -1;
g0(2,14) = -sigma;
g0(2,7) = sigma;

% PC home
g0(3,6) = -1;
g0(3,5) = beta;
g0(3,9) = kappa*phi_H*psi_v;
g0(3,10) = kappa*phi_F*psi_v;
g0(3,2) = kappa*1/sigma*phi_H;
g0(3,4) = kappa*sigma^(-1)*phi_F;
g0(3,11) = -kappa*phi_H*phi_F;

% PC foreign
g0(4,8) = -1;
g0(4,7) = beta;
g0(4,10) = kappa*psi_v;
g0(4,4) = kappa*sigma^(-1);

% Resource constraint home
g0(5,9) = -1;
g0(5,2) = C_H;
g0(5,4) = C_Hstar;
g0(5,12) = 1;
g0(5,11) = -eta*(phi_F*C_H+C_Hstar);

% Resource constraint foreign
g0(6,10) = -1;
g0(6,4) = C_Fstar;
g0(6,13) = 1;

% Backus-Smith condition 
g0(7,2) = 1;
g0(7,4) = -1;
g0(7,11) = -sigma*(1-phi_H);

% monetary policy
g0(8,14) = -1;
g0(8,8) = phi_pi;
g0(8,10) = phi_y;

% government spending
g0(9,12) = 1;
g1(9,12) = rho_G; % government spending home
psi(9,1) = 1;
g0(10,13) = 1;
g1(10,13) = rho_Gf; % government spending foreign
psi(10,2) = 1;

% expectational error
g0(11,2) = 1;
g1(11,1) = 1; % expectational error of home consumption
pi(11,1) = 1;
g0(12,4) = 1;
g1(12,3) = 1; % expectational error of foreign consumption
pi(12,2) = 1;
g0(13,6) = 1;
g1(13,5) = 1;
pi(13,3) = 1;
g0(14,8) = 1;
g1(14,7) = 1;
pi(14,4) = 1;

[G1,C,impact,fmat,fwt,ywt,gev,eu] = gensys(g0,g1,c,psi,pi);

  
% shock to g
shock = [1;0];
%shock = [0;1];
period = 30; % specify number of period
irf = VarImpulse(G1,impact,shock,period);

fprintf('\n')
fprintf('Dg = %5.3f\n',irf(2,12))
fprintf('Dg* = %5.3f\n',irf(2,13))
fprintf('Dy = %5.3f\n',irf(2,9))
fprintf('Dy* = %5.3f\n',irf(2,10))
fprintf('Dc = %5.3f\n',irf(2,2))
fprintf('Dc* = %5.3f\n',irf(2,4))
fprintf('Di = %5.3f\n',irf(2,14))
fprintf('Di - Epi+1 = %5.3f\n',irf(2,14)-irf(2,5))
fprintf('Di - Epi*+1 = %5.3f\n',irf(2,14)-irf(2,7))
fprintf('Dtau = %5.3f\n',irf(2,11))
fprintf('\n')

dt = 0:1:30;

figure(1)
plot(dt,irf(:,9),'k-',dt,irf(:,12),'r-',dt,irf(:,2),'g-')
title('Y, C and G IR to shock in g_t')

figure(2)
plot(dt,irf(:,11),'k-')
title('Terms of Trade IR to shock in g_t')
 
 
 
 
 
 
 
 
 
 