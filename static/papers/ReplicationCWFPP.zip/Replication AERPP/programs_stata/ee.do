clear
set more off
pause on

local dir1 "data_stata/"
local dir2 "data_working/"

***************************************
use `dir2'roe_aggdata_all, clear
drop unemployment*
sort year
merge 1:m year using `dir2'three_state_flows_quarter, nogenerate

drop if year<1978
tsset time
save `dir2'merged_data , replace

// Detrend with HP filter
foreach var of varlist unemployment_rate employment_rate  flow* {
hprescott `var', stub(hp) s(1000000)
egen mean`var'=mean(`var')
gen `var'_det=`var'-hp_`var'_sm_1+mean`var'
drop hp_`var'_sm_1 hp_`var'_1 mean`var'
}

*************************************
// Add self-employment inflows to our ROE measure of job finding
bysort year: egen temp = mean(selfemp_st_x12)
gen hiring_all = hiring_ins2 + temp
drop temp

// Construct hiring rates using 3 state model
// Average monthly hiring from non-employment
bysort year: egen temp = mean(flow_ue*u)
bysort year: egen tempb = mean(flow_oe*o)
gen etoe_fromhiring_3uo = hiring_all - temp - tempb
// etoe adjusting for self employed
gen rate_etoe_fromhiring_3uo = etoe_fromhiring_3uo/employment
drop temp*

sort time
save `dir2'ee, replace

// Continuous transformation for etoe rates
foreach var of varlist rate_etoe*{
	replace `var' = - ln(1-`var')
	}

// Caculate etoe rate over working age pop
gen rate_etoe_3uo_pop = -ln(1 - etoe_fromhiring_3uo / (e + u + o))

**************************************
save `dir2'ee, replace

// Since some the variables have been detrended already in read_roe.do, we just detrend the remaining vars
foreach var of varlist rate_etoe_fromhiring* {
di "`var'"
hprescott `var', stub(hp) s(1000000)
egen mean`var'=mean(`var')
gen `var'_det=`var'-hp_`var'_sm_1+mean`var'
drop hp_`var'_sm_1 hp_`var'_1 mean`var'
}

sort time
***************************************

sort time
save `dir2'ee, replace

***************************************
//  Export file to excel for graphing

//  Order variables
order _all, alphabetic
order year quarter time

keep year quarter time rate_etoe_fromhiring_3uo_det unemployment_rate_det

//  Create an annual file and export to excel
//  Get list of all variables except for year
quietly ds year, not
collapse (mean) `r(varlist)', by(year)
drop time quarter

export excel using "figures_and_output\graph_input.xlsx", firstrow(variables) sheet("data") sheetreplace
