
clear
set more off
version 13

// Set to your working directory
cd "D:\Google Drive\Research\labour_cyc\EEreplication"

local dir1 "data_raw/"
local dir2 "data_working/"
local dir3 "figures_and_output/"
local dir5 "winx12i\data\"
local dir6 "programs_stata/"

// Process raw files
// Un-comment the next if you have the LFS public use microdata files
//do `dir6'read_microlfs
do `dir6'read_insurable_emp

// Calculate transitions between labor force states using LFS data
do `dir6'three_state_1
do `dir6'three_state_2

// Read and process ROE data
do `dir6'read_roe

// Merge LFS data with ROE data and calculate employer-to-employer flows
do `dir6'ee

// Produce statistics used in Table
do `dir6'produce_stats
