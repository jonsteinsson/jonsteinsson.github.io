
clear
set more off

pause on

local dir1 "data_stata/"
local dir2 "data_working/"
local dir3 "figures_and_output/"

// Compute averages and correlations
use `dir2'ee , clear
set logtype text
log using `dir3'statistics.txt, replace

// Calculate basic statistics
tabstat rate_hiring_ins2_pop rate_etoe_3uo_pop flowrate_ue_pop flowrate_oe_pop rate_separation_tot2_pop flowrate_eu_pop flowrate_eo_pop rate_layoff_tot2_pop rate_quit_tot2_pop rate_other_tot2_pop flowrate_ou_pop flowrate_uo_pop, stat(n mean sd min max) col(stat) varwidth(16)

// Calculate correlations with non-HP-filtered rates with detrended unemployment
corr unemployment_rate_det rate_hiring_ins2 rate_etoe_fromhiring_3uo flowrate_ue flowrate_oe rate_separation_tot2 flowrate_eu flowrate_eo rate_layoff_tot2 rate_quit_tot2 rate_other_tot2 flowrate_ou flowrate_uo

log close
