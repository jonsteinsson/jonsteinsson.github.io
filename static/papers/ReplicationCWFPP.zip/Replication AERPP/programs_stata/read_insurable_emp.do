clear
set more off

local dir1 "data_raw/"
local dir2 "data_working/"

// Read in raw insurable labor data
import delimited `dir1'insurable_employment.csv, rowrange(6:) delimiters("-,")

// Name variables
rename (v1 v2 v3) (month year employment_ins)

// Destring year and employment_ins
destring year employment_ins, replace force
drop if year == .
drop if year < 1976

keep if month=="Jan"
drop month
sort year
destring year, replace
save `dir2'insurable_emp , replace
