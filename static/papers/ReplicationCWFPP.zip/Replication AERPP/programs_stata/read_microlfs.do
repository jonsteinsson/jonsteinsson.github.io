clear
set more off
pause off

local dir1 "data_raw/"
local dir2 "data_working/"

// Set last year of complete LFS microdata
local lastyr = 2017

// Loop through stata files
forvalues yr = 1976/`lastyr' {
	forvalues i = 1/12 {
	local mh : display %02.0f `i'

	* Load initial file
	if `yr' == 1976 & `i' == 1 {
		use `dir1'lfs`yr'`mh', clear
		keep survyear survmnth lfsstat durjless durunemp flowunem tenure cowmain everwork ynolkold ynolook fweight
	}
	else if `yr' < 2017 {
		append using `dir1'lfs`yr'`mh', keep(survyear survmnth lfsstat durjless durunemp flowunem tenure cowmain everwork ynolkold ynolook fweight) nolabel
	}
	else {
		append using `dir1'lfs`yr'`mh', keep(survyear survmnth lfsstat durjless durunemp flowunem tenure cowmain everwork ynolook fweight) nolabel
	}
	}
}

// Generate variables of interest
gen O_ind = fweight if lfsstat == 6
gen E_ind = fweight if lfsstat == 1 | lfsstat == 2
gen U_ind = fweight if lfsstat == 3 | lfsstat == 4 | lfsstat == 5
gen N_s_ind = fweight if durjless <= 1 & durjless != .
gen U_s_ind4 = fweight if durunemp <= 4 & durunemp != .
gen EU_s_ind = fweight if durunemp <= 4 & durunemp != . & durjless <= 1 & durjless != .
gen E_s_self = fweight if (lfsstat == 1 | lfsstat == 2) & tenure <= 1 & tenure != . & cowmain >= 3 & cowmain <= 6

rename (fweight survmnth survyear)  (weight month year)

// Drop original variables
drop lfsstat durjless durunemp flowunem tenure cowmain everwork ynolkold ynolook

// Sum variables
foreach var of varlist weight-E_s_self {
bysort year month : egen `var'_1 = total(`var'), missing
}

// Drop the unsummed variables and rename the summed variables
drop weight-E_s_self
rename *_1 *

// Collapse variables
collapse (first) weight-E_s_self, by(year month)

// Rename all variables to lower case
rename _all, lower

sort year month
gen time= _n
gen pop = e_ind + o_ind + u_ind
gen n_ind = o_ind + u_ind

// Save
export delimited `dir1'lfs.txt, delimiter(tab) replace
