*/clear
set more off
pause off

local dir1 "data_raw/"
local dir2 "data_working/"
local dir3 "output_stata/"

//Set last complete year of ROE data
local lastyr = 2016

//Check if HP filter package is installed
capture which hprescott
if _rc==111 ssc install hprescott

//Read in separations and hiring data
import delimited using `dir1'roe.txt, clear
sort year
//Recalculate totals - the totals are not summed correctly in the 2016 file
replace separation_tot = unknown_label + shortage + strike + school + illness + quit + pregnancy + retiremnt + work_sharing + apprentice + other + retiremt + dismissal + leave_of_abse + parental + compassion
save `dir2'roe_aggdata , replace

//Merge together
use `dir2'roe_aggdata, clear
merge 1:1 year using `dir2'lfs_annual, nogenerate
sort year
merge 1:1 year using `dir2'insurable_emp, nogenerate

//Divide some variables by 1000
//After this step, all variables are denominated in thousands
foreach var of varlist unknown_label	shortage 	strike   	school    	illness     	quit          	pregnancy 	retiremnt 	work_sharing  	apprentice    	other	retiremt 	dismissal     	leave_of_abse 	parental	compassion	separation_tot {
replace `var'  = `var' /1000
}

tsset year
save `dir2'roe_aggdata_plus , replace

**************************************************
//Create aggregate series

gen separation_tot_plp = perm_tot + temp_tot
gen quit_tot_plp = perm_quit
gen layoff_tot_plp = perm_layoff + temp_layoff
gen other_tot_plp = separation_tot_plp - layoff_tot_plp - quit_tot_plp

gen quit_tot = quit
gen layoff_tot = shortage
gen  other_tot = separation_tot - quit_tot - layoff_tot

//keep only relevant series
keep separation_tot* quit_tot* layoff_tot* other_tot* population labour_force employment employment_ins unemployment not_in_labour_force unemployment_rate participation_rate employment_rate year
replace unemployment_rate = unemployment_rate/100

**************************************************
//Create hiring statistics
gen hiring_ins_plp =  F.D.employment_ins + separation_tot_plp
gen hiring_ins = F.D.employment_ins + separation_tot

//Create continuous variables (incorporating data from both Picot-Lin-Pyper and newer statscan data)
foreach var of varlist separation_tot quit_tot layoff_tot other_tot hiring_ins {
gen `var'2 = `var'
replace `var'2 = `var'_plp if `var'==.
}

//Make all flow variables monthly and create rates
foreach var of varlist separation_tot* quit_tot* layoff_tot* other_tot* {
	replace `var' = `var'/12
	gen rawrate_`var' = `var' / employment_ins
	gen temp =  - ln(1-rawrate_`var')
	gen rate_`var' = temp
	drop temp
	}

//Make hiring monthly
foreach var of varlist hiring* {
	replace `var' = `var'/12
	}

//Calculate hiring rate
gen pop = employment_ins + unemployment + not_in_labour_force
gen rate_hiring_ins2 = - ln(1 - hiring_ins2 / pop)
drop pop

// Calculate hiring and separation rates over working age population
foreach var of varlist hiring_ins2 separation_tot2 quit_tot2 layoff_tot2 other_tot2 {
	gen rate_`var'_pop = -ln(1 - `var' / population)
}

//Detrend using HP filter and filter
tsset year
foreach var of varlist *separation_tot2 *hiring_ins2 rate_quit_tot2	rate_layoff_tot2	rate_other_tot2	unemployment_rate {
	hprescott `var', stub(hp) s(10000)
	egen mean`var'=mean(`var')
	gen `var'_det=`var'-hp_`var'_sm_1+mean`var'
	drop hp_`var'_sm_1 hp_`var'_1 mean`var'
}

//Drop unnecessary variables
keep separation_tot2 quit_tot2 layoff_tot2 other_tot2 hiring_ins2 rate_separation_tot2* rate_quit_tot2* rate_layoff_tot2* rate_other_tot2* rate_hiring_ins2* population labour_force	employment employment_ins unemployment	  not_in_labour_force	unemployment_rate	participation_rate	employment_rate year *det

//Multiply levels by 1000 (This returns reporting of units to ones instead of thousands)
foreach var of varlist separation_tot2* quit_tot2* layoff_tot2* other_tot2* hiring_ins2* population labour_force	    employment employment_ins 	      unemployment	  not_in_labour_force	{
	replace `var' = `var'*1000
}

sort year

drop if year > `lastyr'

save `dir2'roe_aggdata_all , replace
