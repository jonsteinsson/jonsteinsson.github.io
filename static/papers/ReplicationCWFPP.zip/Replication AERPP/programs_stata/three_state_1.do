clear
set more off
pause on

local dir1 "data_raw/"
local dir2 "data_working/"
local dir5 "winx12i\data\"

// Set last year of data
local lastyr = 2016

//Read in employment data
import delimited using `dir1'lfs.txt, clear
drop if year > `lastyr'

save `dir2'lfs, replace
export delimited year month e_ind using `dir5'xemp\xemp.txt, delimiter(tab) replace nolabel novarnames
export delimited year month e_s using `dir5'xemp_st\xemp_st.txt, delimiter(tab) replace nolabel novarnames
export delimited year month u_ind using `dir5'xunemp\xunemp.txt, delimiter(tab) replace nolabel novarnames
export delimited year month n_ind using `dir5'xnonemp\xnonemp.txt, delimiter(tab) replace nolabel novarnames
export delimited year month n_s_ind using `dir5'xnonemp_st\xnonemp_st.txt, delimiter(tab) replace nolabel novarnames
export delimited year month eu_s_ind using `dir5'xeu_st\xeu_st.txt, delimiter(tab) replace nolabel novarnames
export delimited year month u_s_ind4 using `dir5'xu_st4\xu_st4.txt, delimiter(tab) replace nolabel novarnames

export delimited year month e_s_self using `dir5'xselfemp_st\xselfemp_st.txt, delimiter(tab) replace nolabel novarnames

pause Run x12 filter, then type 'q' or 'end' to continue...

//Read in deseasonalized data (used x12 filter)
local x12 "emp emp_st unemp nonemp nonemp_st eu_st selfemp_st u_st4"
foreach name of local x12 {
import delimited tempdate temp using `dir5'x`name'\x`name'.d11 , clear
gen `name'_x12 = real(temp)
drop if `name'_x12==.
gen year = substr(tempdate, 1, 4)
gen month = substr(tempdate, 5,6)
destring year month, replace
sort year month
gen time= _n
drop temp*
sort time
save `dir1'x`name'_x12, replace
}

use `dir2'lfs, clear
foreach name of local x12 {
	merge 1:1 time using `dir1'x`name'_x12, nogenerate
	sort time
	}

drop if year > `lastyr'

gen quarter = 1 if month>=1 & month<=3
replace quarter = 2 if month>=4 & month<=6
replace quarter = 3 if month>=7 & month<=9
replace quarter = 4 if month>=10 & month<=12

tsset time

// Generate terms needed to calculate flows
gen l = emp_x12
gen u = unemp_x12
gen u_s = u_st4_x12
gen n= nonemp_x12
gen n_s = nonemp_st_x12

gen lf = u+l
gen unemployment_rate = u/lf
gen employment_monthly = l
gen unemployment = u
gen employment_rate = l / (l + n)

gen e = emp_x12
gen o = n-u
gen eu_s = eu_st_x12

gen flow_eu= F.eu_s/e
gen flow_eo= (F.n_s - F.eu_s )/e
gen flow_ou =(F.u_s - F.eu_s)/o
//Kyle: we assume the oe flow rate
gen flow_oe = 0.006
gen flow_uo = (e+u-F.e-F.u+F.u_s-F.n_s + o * flow_oe)/u
gen flow_ue = (u-F.u + F.u_s - flow_uo * u)/u

//Perform continuous transform
foreach flow in "oe" "ou" "eo" "eu" "ue" "uo" {
	gen flowrate_`flow' = -ln(1- flow_`flow')
}

//Calculate levels
gen flowlev_oe = flow_oe * o
gen flowlev_ou = flow_ou * o
gen flowlev_eo = flow_eo * e
gen flowlev_eu = flow_eu * e
gen flowlev_ue = flow_ue * u
gen flowlev_uo = flow_uo * u

// Generate rates over working age population
gen population = e + u + n
foreach flow in "oe" "ou" "eo" "eu" "ue" "uo" {
	gen flowrate_`flow'_pop = -ln(1- flowlev_`flow' / population)
}

drop if year>`lastyr'
sort time

//Rename variables from microlfs
rename (e_ind u_ind u_s_ind4) (emp unemp_tot unemp_st)
rename n nonemp

save `dir2'three_state_flows, replace

// Create annual averages of stocks for use with ROE
keep year emp unemp_tot o_ind pop
collapse (mean) emp unemp_tot o_ind pop, by(year)
rename (emp unemp_tot o_ind pop) (employment unemployment not_in_labour_force population)
foreach var of varlist employment unemployment not_in_labour_force population {
	replace `var' = `var' / 1000
}
gen labour_force = employment + unemployment
gen unemployment_rate = unemployment / labour_force * 100
gen participation_rate = labour_force / population * 100
gen employment_rate = employment / population * 100
save `dir2'lfs_annual, replace
