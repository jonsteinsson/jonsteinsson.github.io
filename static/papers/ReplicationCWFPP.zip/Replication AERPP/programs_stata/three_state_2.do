clear
set more off

local dir1 "data_stata/"
local dir2 "data_working/"
local dir3 "output_stata/"

use `dir2'three_state_flows

//Note: the following variables are all quarterly means of monthly variables!
collapse (mean) employment_monthly selfemp_st emp_st* flow* unemployment_rate unemployment employment_rate unemp_st nonemp_st nonemp emp unemp_tot n_ind l u e o lf pop u_s* n_s* e_* eu* , by(year quarter)
sort year quarter

//Create time variable
egen temp = min(year)
gen time = year*4+quarter - temp*4
drop temp*

sort year quarter
save `dir2'three_state_flows_quarter , replace
