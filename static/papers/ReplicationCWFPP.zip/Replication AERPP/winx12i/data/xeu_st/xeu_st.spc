
series{
  start=1976.01
  file=xeu_st.txt 
  format=datevalue
}
transform{ function=auto }
automdl{  
  savelog=automodel  
}
outlier{ }

x11{ savelog=q  save=(d11)}
