% A Function which calculates the reduced form of the economy in my
% Inflation Persistence model with optimal policy under commitment 
% by calling Chris Sims� gensys function
%
% The function takes three arguments, w, ltype and lambda1
%
% w is the fraction of irrational price setters in the model
%
% ltype is the type of loss funciton to be used
% If ltype == 1 the my loss function will be used. Otherwise the
% traditional loss function will be used
%
% lambda1 is the weight on output in the loss function when 
% ltype != 1.
%
% Created by Jon Steinsson, May 2002
% **************************************************************  

function [G1, impact, eu] = stjme_commitment(w,ltype,lambda1)

%***************************************************************
% Definition of variables in the model 

b = 0.99;
a = 0.7;
psi = 2;
theta = 5;
sigma = 5;
delta = 0.052;
Xf = a/(a+(1-a+a*b)*w);
Xb = w/(a+(1-a+a*b)*w);
k1 = ((1-a)*(1-a*b)*(1-w)*(sigma+psi))/(sigma*(a+(1-a+a*b)*w)*(psi+theta)) ...
-(a*b*w*delta*(1-a))/(a+(1-a+a*b)*w);
k2 = (w*delta*(1-a))/(a+(1-a+a*b)*w);
L1 = ((1-a)*(1-a*b)*(sigma+psi))/(theta*a*sigma*(psi+theta));

%***************************************************************
% Definition of LD according to input

if ltype == 1
L2 = w/((1-w)*a);
L3 = ((1-a)^2*w*delta^2)/(a*(1-w));
L4 = -(2*(1-a)*w*delta)/(a*(1-w));
else 
   L1 = lambda1;
   L2 = 0;
   L3 = 0;
   L4 = 0;
end;       

%***************************************************************
% Model in gensys.m form
%
% y = [E_t pi_t+1, pi_t, x_t, E_t phi_t+1, phi_t]


g0 = [ -b*L2 (1+L2+b*L2) -b*L4/2 Xb*b -1;
   b*L4/2 -b*L4/2 (L1+b*L3) k2*b k1;
   -b*Xf 1 -k1 0 0;
   0 0 0 0 1;
   0 1 0 0 0];

g1 = [ 0 L2 -L4/2 0 -Xf;
   0 0 0 0 0;
   0 Xb k2 0 0;
   0 0 0 1 0;
   1 0 0 0 0];

c = zeros(5,1);

psi = zeros(5,1);
psi(3,1) = 1;

pi = zeros(5,2);
pi(4,2) = 1;
pi(5,1) = 1;

%********************************************************
% gensys call

[G1,C,impact,fmat,fwt,ywt,gev,eu] = gensys(g0,g1,c,psi,pi);

