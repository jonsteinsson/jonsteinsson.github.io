% A Function which calculates the reduced form of the economy in my
% Inflation Persistence paper with optimal policy under discretion 
% by calling on Paul Soderlind's DiscAlg.m.
%
% The function takes three arguments, w, ltype, lambda1
%
% w is the fraction of irrational price setters in the st model
%
% ltype is the type of loss funciton to be used
% If ltype == 1 the my loss function will be used. Otherwise the
% traditional loss function will be used
%
% lambda1 is the weight on output in the loss function when 
% ltype != 1.
%
% Created by Jon Steinsson, May 2002
% **************************************************************

function [M,C,V,F] = stjme_discretion(w,ltype, lambda1)

%***************************************************************
% Definition of variables in the model

b = 0.99;
a = 0.7;
psi = 2;
theta = 5;
sigma = 5;
delta = 0.052;
Xf = a/(a+(1-a+a*b)*w);
Xb = w/(a+(1-a+a*b)*w);
k1 = ((1-a)*(1-a*b)*(1-w)*(sigma+psi))/(sigma*(a+(1-a+a*b)*w)*(psi+theta)) ...
-(a*b*w*delta*(1-a))/(a+(1-a+a*b)*w);
k2 = (w*delta*(1-a))/(a+(1-a+a*b)*w);
L1 = ((1-a)*(1-a*b)*(sigma+psi))/(theta*a*sigma*(psi+theta));
n1 = 4;
n2 = 2;

%***************************************************************
% Definition of LD according to input

if ltype == 1
L2 = w/((1-w)*a);
L3 = ((1-a)^2*w*delta^2)/(a*(1-w));
L4 = -(2*(1-a)*w*delta)/(a*(1-w));
else 
   L1 = lambda1;
   L2 = 0;
   L3 = 0;
   L4 = 0;
end;       

%***************************************************************
% Definition of matrices
%
% y_t = [pi_t, x_t, eta_t+1, epsilon_t+1, E_t pi_t+1, E_t x_t+1]
%
% x_t = i_t

H1 = [1 0 0 0 0 0;
   0 1 0 0 0 0;
   0 0 1 0 0 0;
   0 0 0 1 0 0;
   0 0 0 0 1 0;
   0 0 0 0 sigma 1];

A1 = [0 0 0 0 1 0;
   0 0 0 0 0 1;
   0 0 0 0 0 0;
   0 0 0 0 0 0;
   -Xb/(Xf*b) -k2/(Xf*b) -1/(Xf*b) 0 1/(Xf*b) -k1/(Xf*b);
   0 0 0 1 0 1];

B1 = [0; 0; 0; 0; 0; sigma];

A = inv(H1)*A1;
B = inv(H1)*B1;

Q = [L2 -L4/2 0 0 -L2 0;
   -L4/2 L3 0 0 L4/2 0;
   0 0 0 0 0 0;
   0 0 0 0 0 0;
   -L2 L4/2 0 0 1+L2 0;
   0 0 0 0 0 L1];

R = 0;

U = [0; 0; 0; 0; 0; 0];


%***************************************************************
% Call to DiscAlg.m

[ M,C,V,F ] = DiscAlg( A,B,Q,R,U,b,n1,n2,eye(n1),zeros(n2,n1),...
                                 [1E-8;1E-10],0,1,0,1,0);
