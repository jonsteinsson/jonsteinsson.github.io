% Calculates impulse data
% 
% A function which calculates impulse data for the following 
% system:
%
% y(t) = G1*y(t-1) + impact*e(t)
%
% Created by Jon Steinsson, May 2002.
%*********************************************************

function X = stjme_impulse(G1,impact,e,T);

%*********************************************************
% Definition of variables

n = size(G1,1);
k = size(impact,2);
y = zeros(n,1);
X = zeros(T,n);

%*********************************************************
% Calculation of Impulse data

for t = 1:T;
   y = G1*y + impact*e(t,1);
   X(t,:) = y';
end;