% A function that creates impulse response functions of 
% inflation and output for the economy in my Inflation 
% Persistence paper. The impulse is a temporary one percent 
% change in the desired mark up (\bar{theta} in the paper).
%
% The function takes three inputs:
%
% w is the fraction of irrational price setters in the model.
%
% T is the number of periods to be plotted.
%
% lambda1 is the weight on output in the loss function when 
% ltype != 1.
%
% Created by Jon Steinsson, May 2002
%********************************************************

function stjme_irf2(w,T,lambda1)

%********************************************************
% Create shocks

e = zeros(T+1,1);

b = 0.99;
a = 0.7;
psi = 2;
theta = 5;
sigma = 5;

e(1,1) = 0.2*(1-a)*(1-a*b)*(1-w)...
    /((a+(1-a+a*b)*w)*(theta-1)*(1+psi^(-1)*theta));

%********************************************************
% Calculate impulse response date

X = zeros(T,8);

[G1, impact, eu] = stjme_commitment(w,1,lambda1);
Y = stjme_impulse(G1,impact,e,T);
X(:,1:2) = Y(:,2:3);

[G1, impact, eu] = stjme_commitment(w,0,lambda1);
Y = stjme_impulse(G1,impact,e,T);
X(:,3:4) = Y(:,2:3);

[M,C,V,F] = stjme_discretion(w,1,lambda1);
impact = [0;0;1;0];
Y = stjme_impulse(M,impact,e,T+1);
X(:,5:6) = Y(2:(T+1),1:2);

[M,C,V,F] = stjme_discretion(w,0,lambda1);
impact = [0;0;1;0];
Y = stjme_impulse(M,impact,e,T+1);
X(:,7:8) = Y(2:(T+1),1:2);

%********************************************************
% Figures

figure(1)

periods = 0:1:size(X,1)-1;
periods = periods';
null = zeros(size(X,1),1);

subplot(2,1,1);
fig_legend = ['Inflation, Commit, theoretical L.F.';
   'Inflation, Commit, traditional L.F.';
   'Inflation, Discr, theoretical L.F. ';
   'Inflation, Discr, traditional L.F. '];
plot(periods,X(:,1),'k-',periods,X(:,3),'k--', ...
   periods,X(:,5),'k-.',periods,X(:,7),'k:',periods,null,'k-')
title('Figure 7: Inflation when \omega = 0.99');
leg1 = legend(fig_legend(1,:),fig_legend(2,:), ...
   fig_legend(3,:),fig_legend(4,:));
set(gca,'FontName','times')
set(leg1,'FontName','times')

subplot(2,1,2);
fig_legend = ['Output, Commit, theoretical L.F.';
   'Output, Commit, traditional L.F.';
   'Output, Discr, theoretical L.F. ';
   'Output, Discr, traditional L.F. '];
plot(periods,X(:,2),'k-',periods,X(:,4),'k--', ...
   periods,X(:,6),'k-.',periods,X(:,8),'k:',periods,null,'k-')
title('Figure 8: Output when \omega = 0.99');
leg1 = legend(fig_legend(1,:),fig_legend(2,:), ...
   fig_legend(3,:),fig_legend(4,:));
set(gca,'FontName','times')
set(leg1,'FontName','times')