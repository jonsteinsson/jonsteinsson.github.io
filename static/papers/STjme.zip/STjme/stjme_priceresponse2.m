% Creates impulse response functions of the price level for 
% the economy in my Inflation Persistence paper. The impulse 
% is a temporary one percent change in the desired mark up 
% (\bar{theta} in the paper).
%
% Created by Jon Steinsson, May 2002
%********************************************************

T = 20;
X = zeros(T+1,4);

b = 0.99;
a = 0.7;
psi = 2;
theta = 5;
sigma = 5;

%*********************************************************
% Create Price Data

w = 0.01;
e = zeros(T,1);
e(1,1) = 0.2*(1-a)*(1-a*b)*(1-w)...
    /((a+(1-a+a*b)*w)*(theta-1)*(1+psi^(-1)*theta));
[G1, impact, eu] = stjme_commitment(0,1,0.5);
Y = stjme_impulse(G1,impact,e,T);
P = 0;
for t = 1:T
   P = P + Y(t,2);
   X(t+1,1) = P;
end

w = 0.2;
e = zeros(T,1);
e(1,1) = 0.2*(1-a)*(1-a*b)*(1-w)...
    /((a+(1-a+a*b)*w)*(theta-1)*(1+psi^(-1)*theta));
[G1, impact, eu] = stjme_commitment(w,1,0.5);
Y = stjme_impulse(G1,impact,e,T);
P = 0;
for t = 1:T
   P = P + Y(t,2);
   X(t+1,2) = P;
end

w = 0.7;
e = zeros(T,1);
e(1,1) = 0.2*(1-a)*(1-a*b)*(1-w)...
    /((a+(1-a+a*b)*w)*(theta-1)*(1+psi^(-1)*theta));
[G1, impact, eu] = stjme_commitment(w,1,0.5);
Y = stjme_impulse(G1,impact,e,T);
P = 0;
for t = 1:T
   P = P + Y(t,2);
   X(t+1,3) = P;
end

%********************************************************
% Figure

figure(1)

periods = 0:1:size(X,1)-1;
periods = periods';
null = zeros(size(X,1),1);

fig_legend = ['w = 0.01';'w = 0.2 ';'w = 0.7 '];
plot(periods,X(:,1),'k-',periods,X(:,2),'k--', ...
   periods,X(:,3),'k-.',periods,null,'k-')
leg1 = legend(fig_legend(1,:),fig_legend(2,:), ...
   fig_legend(3,:));
title('Figure 9: Price level for different \omega');
set(gca,'FontName','times')
set(leg1,'FontName','times')
