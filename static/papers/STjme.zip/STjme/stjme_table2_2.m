% Calculated welfare for different value of omega and 
% different assumptions about the loss function of 
% the central bank in my Inflation Persistence paper
%
% The output of this program is a matrix that corresponds 
% to table 2 in the paper.
%
% Created by Jon Steinsson, May 2002
%***************************************************

Table = zeros(11,5);
omega = [0.01 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 0.99];

%***************************************************************
% Definition of variables in the model 

t = 500;
b = 0.99;
a = 0.7;
psi = 2;
theta = 5;
sigma = 5;
delta = 0.052;
lambda1 = 0.5;

for i = 1:11
   T = i*t;
   w = omega(1,i);
   e = zeros(T+1,1);
   e(1,1) = 0.2*(1-a)*(1-a*b)*(1-w)...
    /((a+(1-a+a*b)*w)*(theta-1)*(1+psi^(-1)*theta));
   
   Table(i,1) = w;
   
   % Theoretical, Commitment
   [G1, impact, eu] = stjme_commitment(w,1,lambda1);
   Y = stjme_impulse(G1,impact,e,T);
   Y = [zeros(1,size(G1,1));Y];
   L1 = ((1-a)*(1-a*b)*(sigma+psi))/(theta*a*sigma*(psi+theta));
   L2 = w/((1-w)*a);
   L3 = ((1-a)^2*w*delta^2)/(a*(1-w));
   L4 = (2*(1-a)*w*delta)/(a*(1-w));
   M1 = zeros(size(G1,1));
   M1(2,2) = 1+L2; M1(3,3) = L1; 
   M2 = zeros(size(G1,1));   
   M2(2,2) = L2; M2(3,3) = L3; M2(2,3) = -L4;
   M3 = zeros(size(G1,1));   
   M3(2,2) = -2*L2; M3(2,3) = L4;
   Table(i,2) = stjme_welfare(Y,M1,M2,M3,b);
   
   %Theoretical, Discretion
   [M,C,V,F] = stjme_discretion(w,1,lambda1);
   impact = [0;0;1;0];
   Y = stjme_impulse(M,impact,e,T+1);
   M1 = zeros(size(M,1));
   M1(1,1) = 1+L2; M1(2,2) = L1; 
   M2 = zeros(size(M,1));   
   M2(1,1) = L2; M2(2,2) = L3; M2(1,2) = -L4;
   M3 = zeros(size(M,1));   
   M3(1,1) = -2*L2; M3(1,2) = L4;
   Table(i,3) = stjme_welfare(Y,M1,M2,M3,b);
   
   %Traditional, Commitment
   [G1, impact, eu] = stjme_commitment(w,0,lambda1);
   Y = stjme_impulse(G1,impact,e,T);
   Y = [zeros(1,size(G1,1));Y];
   L1 = lambda1; L2 = 0; L3 = 0; L4 = 0;
   M1 = zeros(size(G1,1));
   M1(2,2) = 1+L2; M1(3,3) = L1; 
   M2 = zeros(size(G1,1));   
   M2(2,2) = L2; M2(3,3) = L3; M2(2,3) = -L4;
   M3 = zeros(size(G1,1));   
   M3(2,2) = -2*L2; M3(2,3) = L4;
   Table(i,4) = stjme_welfare(Y,M1,M2,M3,b);
   
   %Traditional, Discretion
   [M,C,V,F] = stjme_discretion(w,0,lambda1);
   impact = [0;0;1;0];
   Y = stjme_impulse(M,impact,e,T+1);
   M1 = zeros(size(M,1));
   M1(1,1) = 1+L2; M1(2,2) = L1; 
   M2 = zeros(size(M,1));   
   M2(1,1) = L2; M2(2,2) = L3; M2(1,2) = -L4;
   M3 = zeros(size(M,1));   
   M3(1,1) = -2*L2; M3(1,2) = L4;
   Table(i,5) = stjme_welfare(Y,M1,M2,M3,b);
end

one = ones(11,1);

Table2 = zeros(11,7);
Table2(:,1) = Table(:,1);
Table2(:,2) = Table(:,2)/Table(1,2);
Table2(:,3) = Table(:,3)/Table(1,2);
Table2(:,4) = Table2(:,3)./Table2(:,2)-one;
Table2(:,5) = Table(:,4)/Table(1,4);
Table2(:,6) = Table(:,5)/Table(1,4);
Table2(:,7) = Table2(:,6)./Table2(:,5)-one;

Table2