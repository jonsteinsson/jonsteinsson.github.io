% Calculates the welfare loss associated with business cycles
%
% Takes business cycles data as input, X, and calculates the 
% the welfare loss, depending on input, for the following 
% loss function:
%
%   L = sum_0^T b^t*[y(t)'*M1*y(t) + y(t-1)'*M2*y(t-1)
%                                  + y(t)'*M3*y(t-1)]
%
% Inputs:
%
%   X       --- (T+1)xn matrix, contains the data to by evaluated
%                 output from VarImpulse.m or VarSimulation.m
%   M1      --- nxn matrix, contains the coefficients of the
%                 contemporaneous part of the loss function
%   M2      --- nxn matrix, contains the coefficients of the 
%                 lagged part of the loss function
%   M3      --- nxn matrix, contains the coefficients of the 
%                 cross part of the loss function
%   b       --- scalar, discount factor in loss function
%
% Output:
%
%   W       --- scalar, welfare or loss depending on inputs
%
% Created by Jon Steinsson, June 2001
%************************************************************

function W = stjme_welfare(X,M1,M2,M3,b)

%************************************************************
% Check whether business cycle has died out sufficiently

T = size(X,1);



if (abs(max(X(T,:)./(X(2,:)+0.0001))) > 0.00001)
   fprintf(1,'Business cycle has not died out. Longer X needed.');
end

%*************************************************************
% Calculation of welfare

W = 0;

if M2 == zeros(size(M2,1)) & M3 == zeros(size(M2,1))
   for j = 1:(T-1)
      W = W + b^(j-1)*(X(j+1,:)*M1*X(j+1,:)');
   end
elseif M3 == zeros(size(M2,1))
   for j = 1:(T-1)
      W = W + b^(j-1)*(X(j+1,:)*M1*X(j+1,:)' + X(j,:)*M2*X(j,:)');
   end
else
   for j = 1:(T-1)
      W = W + b^(j-1)*(X(j+1,:)*M1*X(j+1,:)' + X(j,:)*M2*X(j,:)' + X(j+1,:)*M3*X(j,:)');
   end
end


